import { Module } from "@nestjs/common";
import { ConfigModule } from "@nestjs/config";
import { ScheduleModule } from "@nestjs/schedule";
import { StorageModule } from "./common/storage/storage.module";
import { QueueModule } from "./common/queue/queue.module";
import { StreamModule } from "./common/stream/stream.module";
import { ProjectAccessModule } from "./common/project-access/project-access.module";


import { PrismaModule } from "./common/prisma/prisma.module";
import { ProjectsModule } from "./projects/projects.module";
import { OrdersModule } from "./orders/orders.module";
import { CreativesModule } from "./modules/creatives/creatives.module";
import { PlannerModule } from "./modules/planner/planner.module";
import { HealthModule } from './health/health.module';
import { AuthModule } from "./modules/auth/auth.module";
import { AdminModule } from "./modules/admin/admin.module";
import { MastersModule } from "./modules/masters/masters.module";
import { ApprovalsModule } from "./modules/approvals/approvals.module";
import { WorkersModule } from "./workers/workers.module";
import { DamModule } from "./modules/dam/dam.module";
import { PresetsModule } from "./modules/presets/presets.module";
import { BulkModule } from "./modules/bulk/bulk.module";
import { BillingModule } from "./modules/billing/billing.module";
import { NotificationsModule } from "./modules/notifications/notifications.module";
import { EmailOutboxModule } from "./modules/email-outbox/email-outbox.module";
import { DashboardModule } from "./modules/dashboard/dashboard.module";


@Module({
  imports: [
    ConfigModule.forRoot({ isGlobal: true }),
    StorageModule,
    QueueModule,
    StreamModule,
    ProjectAccessModule,
    PrismaModule,
    AuthModule,
    AdminModule,
    MastersModule,
    ProjectsModule,
    OrdersModule,
    CreativesModule,
    PlannerModule,
    HealthModule,
    ApprovalsModule,
    ScheduleModule.forRoot(),
    WorkersModule,
    DamModule,
    PresetsModule,
    BulkModule,
    BillingModule,
    NotificationsModule,
    EmailOutboxModule,
    DashboardModule,
  ],
})
export class AppModule {}
