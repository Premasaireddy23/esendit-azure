import "dotenv/config";
import "reflect-metadata";
import { NestFactory } from "@nestjs/core";
import { ValidationPipe } from "@nestjs/common";
import { AppModule } from "./app.module";

async function bootstrap() {
  /**
   * APP_MODE controls whether this process runs the HTTP API, the background worker, or both.
   * - api   (default): start HTTP server; disable MediaWorker unless MEDIA_WORKER_ENABLED is explicitly set
   * - worker: start Nest application context only (no HTTP); enable MediaWorker unless explicitly disabled
   * - both  : start HTTP server and MediaWorker (previous behavior)
   */
  const mode = (process.env.APP_MODE || "api").toLowerCase();

  const setDefault = (k: string, v: string) => {
    if (process.env[k] == null) process.env[k] = v;
  };

  // Safe defaults: in production we usually want to separate API and worker.
  if (mode === "api") {
    // Disable all background loops unless explicitly enabled.
    setDefault("MEDIA_WORKER_ENABLED", "false");
    setDefault("BULK_MEDIA_WORKER_ENABLED", "false");
    setDefault("PRESET_WORKER_ENABLED", "false");
    setDefault("DELIVERY_WORKER_ENABLED", "false");
    setDefault("HOT_FOLDER_WORKER_ENABLED", "false");
    setDefault("AUTO_SEND_WORKER_ENABLED", "false");
    setDefault("EMAIL_OUTBOX_ENABLED", "false");
  }
  if (mode === "worker") {
    // Enable background loops unless explicitly disabled.
    setDefault("MEDIA_WORKER_ENABLED", "true");
    setDefault("BULK_MEDIA_WORKER_ENABLED", "true");
    setDefault("PRESET_WORKER_ENABLED", "true");
    setDefault("DELIVERY_WORKER_ENABLED", "true");
    setDefault("HOT_FOLDER_WORKER_ENABLED", "true");
    // Safety: auto-send can have production impact, keep it opt-in.
    setDefault("AUTO_SEND_WORKER_ENABLED", "false");
    setDefault("EMAIL_OUTBOX_ENABLED", "true");
  }

  if (mode === "worker") {
    const app = await NestFactory.createApplicationContext(AppModule);

    // Optional: keep BigInt JSON safety in case any background code stringifies objects
    (BigInt.prototype as any).toJSON = function () {
      return this.toString();
    };

    // Start providers (OnModuleInit hooks will run, including MediaWorkerService)
    await app.init();

    const shutdown = async () => {
      try {
        await app.close();
      } finally {
        process.exit(0);
      }
    };
    process.on("SIGTERM", shutdown);
    process.on("SIGINT", shutdown);

    // Do not exit; keep process alive via Service Bus receiver / timers
    return;
  }

  const app = await NestFactory.create(AppModule);

  // ✅ Fix: Prisma BigInt fields can't be JSON.stringified by default (Express)
  const http = app.getHttpAdapter().getInstance();
  if (http?.set) {
    http.set("json replacer", (_key: string, value: any) =>
      typeof value === "bigint" ? value.toString() : value,
    );
  }

  // ✅ Extra safety (covers any JSON.stringify usage outside Express too)
  (BigInt.prototype as any).toJSON = function () {
    return this.toString();
  };

  app.useGlobalPipes(new ValidationPipe({ whitelist: true, transform: true }));

  // ---- CORS (ACA + local dev) ----
  const corsOrigins = (process.env.CORS_ORIGINS || "")
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);

  const defaultOrigins = ["http://127.0.0.1:5173", "http://localhost:5173"];
  const allowedOrigins = corsOrigins.length ? corsOrigins : defaultOrigins;

  app.enableCors({
    origin: (origin, cb) => {
      // Allow non-browser clients (curl/postman) with no Origin header
      if (!origin) return cb(null, true);
      return cb(null, allowedOrigins.includes(origin));
    },
    methods: ["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"],
    allowedHeaders: ["Content-Type", "Authorization"],
    exposedHeaders: ["Content-Disposition"], // useful for downloads
    // credentials: true, // enable only if you use cookies later
  });

  // ✅ ACA + local: listen on PORT or CONTAINER_APP_PORT
  const port = Number(process.env.PORT || process.env.CONTAINER_APP_PORT || 3000);
  await app.listen(port, "0.0.0.0");
}

bootstrap();
