import "dotenv/config";

import { PrismaClient, AccountType, PermissionType, UserType } from "@prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
import { Pool } from "pg";
import * as bcrypt from "bcryptjs";
import * as path from "node:path";
import { readdir, readFile, stat } from "node:fs/promises";

import { PERMISSIONS as REGISTRY_PERMISSIONS } from "../common/auth/permission.registry";

function envBool(v: string | undefined) {
  return String(v ?? "").toLowerCase() === "true";
}

function envBoolDefault(v: string | undefined, def: boolean) {
  if (v === undefined || v === null || String(v).trim() === "") return def;
  return ["1", "true", "yes", "y", "on"].includes(String(v).toLowerCase());
}

function pick(...vals: Array<string | undefined>) {
  for (const v of vals) {
    if (v !== undefined && v !== null && String(v).trim() !== "") return String(v);
  }
  return undefined;
}

function prettyNameFromKey(key: string) {
  const k = String(key).trim();
  const parts = k.includes("_") ? k.toLowerCase().split("_") : k.toLowerCase().split(/[:.]/g);

  return parts
    .filter(Boolean)
    .map((w) => (w ? w[0].toUpperCase() + w.slice(1) : w))
    .join(" ");
}

function inferPermissionTypeFromKey(key: string): PermissionType {
  const k = String(key).trim().toLowerCase();
  // Common patterns for "page" permissions in this repo:
  //   - "page:..." (preferred)
  //   - "page_..."  (legacy)
  //   - "Page_Planner" (legacy)
  if (k.startsWith("page:") || k.startsWith("page_") || k === "page_planner" || k === "page:planner") {
    return PermissionType.PAGE;
  }
  return PermissionType.ACTION;
}

type SeedPermission = { key: string; name: string; type: PermissionType };

async function walkFiles(dir: string, out: string[] = []): Promise<string[]> {
  const entries = await readdir(dir);
  for (const e of entries) {
    if (e === "node_modules" || e === "dist" || e === ".git") continue;

    const full = path.join(dir, e);
    const s = await stat(full);

    if (s.isDirectory()) {
      await walkFiles(full, out);
      continue;
    }

    if (!s.isFile()) continue;
    if (!full.endsWith(".ts")) continue;
    if (full.endsWith(".d.ts")) continue;
    if (full.endsWith(".spec.ts") || full.endsWith(".test.ts")) continue;

    out.push(full);
  }
  return out;
}

function extractPermissionKeysFromSource(src: string): string[] {
  const keys: string[] = [];

  // decorator supports multiple args: @RequirePermissions("A", "B")
  const outer = /RequirePermissions\(([\s\S]*?)\)/g;
  let m: RegExpExecArray | null;
  while ((m = outer.exec(src))) {
    const inside = m[1] ?? "";
    const str = /['"`]([^'"`]+)['"`]/g;
    let sm: RegExpExecArray | null;
    while ((sm = str.exec(inside))) {
      const raw = sm[1];
      if (!raw) continue;
      keys.push(raw);
    }
  }

  return keys;
}

async function gatherPermissionSeeds() {
  const registryMap = new Map<string, { name: string }>();
  // REGISTRY_PERMISSIONS is declared as a readonly array (`as const`).
  // We only need to iterate; avoid casting to mutable `any[]` (TS2352).
  for (const p of REGISTRY_PERMISSIONS as ReadonlyArray<any>) {
    if (!p?.key) continue;
    const k = String(p.key);
    const n = String(p.name ?? prettyNameFromKey(k));
    registryMap.set(k, { name: n });
  }

  const srcRoot = path.resolve(__dirname, ".."); // .../src
  const files = await walkFiles(srcRoot);

  const fromCode = new Set<string>();
  const whitespaceKeys: string[] = [];

  for (const f of files) {
    const content = await readFile(f, "utf8");
    for (const k of extractPermissionKeysFromSource(content)) {
      if (k.trim() !== k) whitespaceKeys.push(k);

      // Keep exact key (matches runtime check)
      fromCode.add(k);

      // Also seed trimmed version (helps if code is later fixed)
      const t = k.trim();
      if (t && t !== k) fromCode.add(t);
    }
  }

  const allKeys = new Set<string>();
  for (const k of registryMap.keys()) allKeys.add(k);
  for (const k of fromCode) allKeys.add(k);

  const seeds: SeedPermission[] = Array.from(allKeys)
    .filter((k) => k && String(k).trim() !== "")
    .sort((a, b) => a.localeCompare(b))
    .map((key) => {
      const trimmed = key.trim();
      const name = registryMap.get(trimmed)?.name ?? prettyNameFromKey(trimmed);
      const type = inferPermissionTypeFromKey(trimmed);
      return { key, name, type };
    });

  return { seeds, whitespaceKeys };
}

async function ensurePermissions(prisma: PrismaClient) {
  const { seeds, whitespaceKeys } = await gatherPermissionSeeds();

  if (whitespaceKeys.length) {
    const uniq = Array.from(new Set(whitespaceKeys)).slice(0, 50);
    console.warn(
      `[seed-admin] WARNING: found permission keys with leading/trailing whitespace in code (showing up to 50):\n` +
        uniq.map((k) => `  - "${k}"`).join("\n"),
    );
  }

  for (const p of seeds) {
    await prisma.permission.upsert({
      where: { key: p.key },
      update: { name: p.name, type: p.type },
      create: { key: p.key, name: p.name, type: p.type },
    });
  }

  return { upserted: seeds.length };
}

async function main() {
  const databaseUrl = pick(process.env.DATABASE_URL, process.env.PG_URL);
  if (!databaseUrl) {
    console.error("[seed-admin] Missing DATABASE_URL or PG_URL.");
    process.exit(1);
  }

  const pool = new Pool({ connectionString: databaseUrl });
  const adapter = new PrismaPg(pool);
  const prisma = new PrismaClient({ adapter });

  try {
    const accountCode = (pick(process.env.BOOTSTRAP_ACCOUNT_CODE, process.env.ACCOUNT_CODE) ?? "default").trim();
    const adminRoleName = (pick(process.env.ADMIN_ROLE_NAME) ?? "Admin").trim();

    const adminEmail = (pick(process.env.BOOTSTRAP_ADMIN_EMAIL, process.env.ADMIN_EMAIL) ?? "admin@example.com").trim();
    const adminPasswordPlain = pick(process.env.BOOTSTRAP_ADMIN_PASSWORD, process.env.ADMIN_PASSWORD) ?? "Admin@123";
    const adminName = (pick(process.env.BOOTSTRAP_ADMIN_NAME, process.env.ADMIN_NAME) ?? "Admin").trim();

    const resetAdminRolePerms = envBoolDefault(process.env.RESET_ADMIN_ROLE_PERMS, true);
    const ensurePerms = envBoolDefault(process.env.ENSURE_PERMISSIONS, true);

    console.log(
      `[seed-admin] accountCode=${accountCode} adminEmail=${adminEmail} role=${adminRoleName} resetRolePerms=${resetAdminRolePerms} ensurePerms=${ensurePerms}`,
    );

    // 1) Ensure Account exists (minimal bootstrap)
    const account = await prisma.account.upsert({
      where: { code: accountCode },
      update: { name: accountCode, isActive: true },
      create: {
        code: accountCode,
        name: accountCode,
        type: AccountType.SENDER,
        isActive: true,
      },
    });

    // 1b) Ensure project-number sequence exists (safe + minimal)
    await prisma.accountSequence.upsert({
      where: { accountId_key: { accountId: account.id, key: "PROJECT_NUMBER" } },
      update: {},
      create: { accountId: account.id, key: "PROJECT_NUMBER", nextValue: 1 },
    });

    // 2) Ensure Permission rows exist (so we can assign ALL permissions to Admin role)
    if (ensurePerms) {
      const r = await ensurePermissions(prisma);
      console.log(`[seed-admin] Permissions ensured: upserted=${r.upserted}`);
    }

    // 3) Ensure Admin role exists
    const adminRole = await prisma.role.upsert({
      where: { accountId_name: { accountId: account.id, name: adminRoleName } },
      update: { isSystem: true, description: "System admin role" },
      create: {
        accountId: account.id,
        name: adminRoleName,
        isSystem: true,
        description: "System admin role",
      },
    });

    // 4) Assign ALL permissions in DB to this Admin role
    const perms = await prisma.permission.findMany({ select: { id: true } });

    if (resetAdminRolePerms) {
      await prisma.rolePermission.deleteMany({ where: { roleId: adminRole.id } });
    }

    await prisma.rolePermission.createMany({
      data: perms.map((p) => ({ roleId: adminRole.id, permissionId: p.id })),
      skipDuplicates: true,
    });

    // 5) Upsert admin user
    const passwordHash = await bcrypt.hash(adminPasswordPlain, 10);

    const adminUser = await prisma.user.upsert({
      where: { accountId_email: { accountId: account.id, email: adminEmail } },
      update: {
        displayName: adminName,
        passwordHash,
        isActive: true,
        userType: UserType.INTERNAL,
      },
      create: {
        accountId: account.id,
        email: adminEmail,
        displayName: adminName,
        passwordHash,
        isActive: true,
        userType: UserType.INTERNAL,
      },
      select: { id: true, email: true },
    });

    // 6) Ensure UserRole mapping
    await prisma.userRole.createMany({
      data: [{ userId: adminUser.id, roleId: adminRole.id }],
      skipDuplicates: true,
    });

    console.log(`[seed-admin] OK: account=${account.code} user=${adminUser.email} permsAssigned=${perms.length}`);

    if (!envBool(process.env.ADMIN_PASSWORD_SET)) {
      console.warn(
        "[seed-admin] NOTE: You are using the default password unless you set ADMIN_PASSWORD / BOOTSTRAP_ADMIN_PASSWORD."
      );
    }
  } catch (e) {
    console.error("[seed-admin] FAILED", e);
    process.exitCode = 1;
  } finally {
    await prisma.$disconnect().catch(() => undefined);
    await pool.end().catch(() => undefined);
  }
}

main().catch((e) => {
  console.error("[seed-admin] FAILED", e);
  process.exit(1);
});
