import "dotenv/config";

import { PrismaClient } from "@prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
import { Pool } from "pg";
import { readFile } from "node:fs/promises";
import { DEFAULT_DOWNLOAD_PRESETS } from "../common/presets/default-download-presets";

function envBoolDefault(v: string | undefined, def: boolean) {
  if (v === undefined || v === null || String(v).trim() === "") return def;
  return ["1", "true", "yes", "y", "on"].includes(String(v).toLowerCase());
}

function pick(...vals: Array<string | undefined>) {
  for (const v of vals) {
    if (v !== undefined && v !== null && String(v).trim() !== "") return String(v);
  }
  return undefined;
}

type PresetDef = {
  key: string;
  label?: string;
  ext: string;
  mimeType: string;
  args?: string[];
  // future-proof: if later you add pipeline support
  steps?: any[];
};

function validatePresets(p: any): asserts p is PresetDef[] {
  if (!Array.isArray(p)) throw new Error("Presets JSON must be an array");
  for (const [i, x] of p.entries()) {
    if (!x || typeof x !== "object") throw new Error(`Preset[${i}] must be an object`);
    if (!x.key || typeof x.key !== "string") throw new Error(`Preset[${i}].key missing/invalid`);
    if (!x.ext || typeof x.ext !== "string") throw new Error(`Preset[${i}].ext missing/invalid`);
    if (!x.mimeType || typeof x.mimeType !== "string") throw new Error(`Preset[${i}].mimeType missing/invalid`);
    if (x.args !== undefined && !Array.isArray(x.args)) throw new Error(`Preset[${i}].args must be array`);
  }
}

async function loadPresets(): Promise<PresetDef[]> {
  // 1) base64 env (best for AKS secret/config)
  const b64 = pick(process.env.PRESETS_JSON_B64);
  if (b64) {
    const raw = Buffer.from(b64, "base64").toString("utf8");
    const p = JSON.parse(raw);
    validatePresets(p);
    return p;
  }

  // 2) raw JSON env
  const rawJson = pick(process.env.PRESETS_JSON);
  if (rawJson) {
    const p = JSON.parse(rawJson);
    validatePresets(p);
    return p;
  }

  // 3) file path (best for local)
  // Default to the Linux profile pack shipped with the repo; override via PRESETS_FILE.
  const file = pick(process.env.PRESETS_FILE, "./downloadPresets_linux_profiles.json");
  if (file) {
    try {
      const raw = await readFile(file, "utf8");
      const p = JSON.parse(raw);
      validatePresets(p);
      return p;
    } catch {
      // Fall back to the built-in library below.
    }
  }

  // 4) built-in defaults
  validatePresets(DEFAULT_DOWNLOAD_PRESETS);
  return DEFAULT_DOWNLOAD_PRESETS;
}

// ---- ENV ----
const SEED_ACCOUNT_PRESETS = envBoolDefault(process.env.SEED_ACCOUNT_PRESETS, true);
const ACCOUNT_CODE = (pick(process.env.ACCOUNT_CODE, process.env.BOOTSTRAP_ACCOUNT_CODE) ?? "default").trim();

// DB URL: match your app behavior
const databaseUrl = pick(process.env.DATABASE_URL, process.env.PG_URL);
if (!databaseUrl) {
  console.error("[seed-account-presets] Missing DATABASE_URL or PG_URL.");
  process.exit(1);
}

// Prisma driver adapter (same pattern as your seed-permissions.ts)
const pool = new Pool({ connectionString: databaseUrl });
const adapter = new PrismaPg(pool);
const prisma = new PrismaClient({ adapter });

async function main() {
  if (!SEED_ACCOUNT_PRESETS) {
    console.log("[seed-account-presets] SEED_ACCOUNT_PRESETS=false => skipping");
    return;
  }

  const presets = await loadPresets();

  const account = await prisma.account.findUnique({
    where: { code: ACCOUNT_CODE },
    select: { id: true, code: true },
  });

  if (!account) {
    console.error(`[seed-account-presets] Account not found for code="${ACCOUNT_CODE}"`);
    process.exit(1);
  }

  await prisma.account.update({
    where: { id: account.id },
    data: { downloadPresets: presets as any },
  });

  console.log(
    `[seed-account-presets] OK: account=${account.code} presets=${presets.length} source=` +
      (process.env.PRESETS_JSON_B64 ? "PRESETS_JSON_B64" : process.env.PRESETS_JSON ? "PRESETS_JSON" : "PRESETS_FILE")
  );
}

main()
  .catch((e) => {
    console.error("[seed-account-presets] FAILED", e);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect().catch(() => undefined);
    await pool.end().catch(() => undefined);
  });
