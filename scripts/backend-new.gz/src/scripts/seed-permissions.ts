import "dotenv/config";

import { PrismaClient, PermissionType } from "@prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
import { Pool } from "pg";

import { PERMISSIONS as REGISTRY_PERMISSIONS } from "../common/auth/permission.registry";

function envBoolDefault(v: string | undefined, def: boolean) {
  if (v === undefined || v === null || String(v).trim() === "") return def;
  return ["1", "true", "yes", "y", "on"].includes(String(v).toLowerCase());
}

function pick(...vals: Array<string | undefined>) {
  for (const v of vals) {
    if (v !== undefined && v !== null && String(v).trim() !== "") return String(v);
  }
  return undefined;
}

const SEED_PERMISSIONS = envBoolDefault(process.env.SEED_PERMISSIONS, true);
const ACCOUNT_CODE = (pick(process.env.ACCOUNT_CODE, process.env.BOOTSTRAP_ACCOUNT_CODE) ?? "default").trim();
const RESET_ADMIN_ROLE_PERMS = envBoolDefault(process.env.RESET_ADMIN_ROLE_PERMS, true);
const ADMIN_ROLE_NAME = (process.env.ADMIN_ROLE_NAME ?? "Admin").trim();

const databaseUrl = pick(process.env.DATABASE_URL, process.env.PG_URL);
if (!databaseUrl) {
  console.error("[seed-permissions] Missing DATABASE_URL or PG_URL.");
  process.exit(1);
}

const permissionSeeds = Array.from(REGISTRY_PERMISSIONS as ReadonlyArray<any>).map((p) => ({
  key: String(p.key),
  name: String(p.name ?? p.key),
  type: String(p.key).toLowerCase().startsWith("page:") || String(p.key) === "Page_Planner"
    ? PermissionType.PAGE
    : PermissionType.ACTION,
}));

const pool = new Pool({ connectionString: databaseUrl });
const adapter = new PrismaPg(pool);
const prisma = new PrismaClient({ adapter });

async function main() {
  if (!SEED_PERMISSIONS) {
    console.log("[seed-permissions] SEED_PERMISSIONS=false => skipping");
    return;
  }

  console.log(`[seed-permissions] DB URL source: ${process.env.DATABASE_URL ? "DATABASE_URL" : "PG_URL"}`);
  console.log(`[seed-permissions] Upserting ${permissionSeeds.length} Permission rows...`);

  for (const perm of permissionSeeds) {
    await prisma.permission.upsert({
      where: { key: perm.key },
      update: {
        name: perm.name,
        type: perm.type,
      },
      create: {
        key: perm.key,
        name: perm.name,
        type: perm.type,
      },
    });
  }

  const account = await prisma.account.findUnique({ where: { code: ACCOUNT_CODE } });

  if (!account) {
    console.log(
      `[seed-permissions] Account not found for code="${ACCOUNT_CODE}". Seeded Permission rows only (no role mapping).`
    );
    return;
  }

  const adminRole = await prisma.role.upsert({
    where: { accountId_name: { accountId: account.id, name: ADMIN_ROLE_NAME } },
    update: { isSystem: true, description: "System admin role" },
    create: {
      accountId: account.id,
      name: ADMIN_ROLE_NAME,
      isSystem: true,
      description: "System admin role",
    },
  });

  const perms = await prisma.permission.findMany({
    where: { key: { in: permissionSeeds.map((p) => p.key) } },
    select: { id: true },
  });

  if (RESET_ADMIN_ROLE_PERMS) {
    await prisma.rolePermission.deleteMany({ where: { roleId: adminRole.id } });
  }

  await prisma.rolePermission.createMany({
    data: perms.map((p) => ({ roleId: adminRole.id, permissionId: p.id })),
    skipDuplicates: true,
  });

  console.log(
    `[seed-permissions] OK: account=${ACCOUNT_CODE} role=${ADMIN_ROLE_NAME} perms=${perms.length} reset=${RESET_ADMIN_ROLE_PERMS}`
  );
}

main()
  .catch((e) => {
    console.error("[seed-permissions] FAILED", e);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect().catch(() => undefined);
    await pool.end().catch(() => undefined);
  });
