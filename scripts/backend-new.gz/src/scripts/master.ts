import 'dotenv/config';

import { PrismaClient, Prisma, AccountType, PermissionType, UserType } from '@prisma/client';
import { PrismaPg } from '@prisma/adapter-pg';
import { Pool } from 'pg';
import * as bcrypt from 'bcryptjs';

import { PERMISSIONS } from '../common/auth/permission.registry';


const PERMISSION_KEYS_ALL = Array.from(PERMISSIONS).map((p: any) => p.key);


/**
 * Consolidated DB maintenance runner (bootstrap + backfills).
 *
 * Place this file in your backend repo (example):
 *   backend/src/scripts/maintenance-all.ts
 *
 * Run locally:
 *   npx ts-node -r dotenv/config src/scripts/maintenance-all.ts
 *
 * Common flags:
 *   --dry-run                 Print what would change (no writes)
 *   --only <k1,k2>            Run only these tasks
 *   --skip <k1,k2>            Skip these tasks
 *   --continue                Continue even if a task fails
 *
 * Task-specific flags:
 *   --approval-template-name "Default Pre-Send"
 *   --projectId <uuid>        (limits enqueue-media-jobs to a single project)
 */

type Task = {
  key: string;
  title: string;
  run: () => Promise<void>;
};

const argv = process.argv.slice(2);
const DRY_RUN = argv.includes('--dry-run');
const CONTINUE_ON_ERROR = argv.includes('--continue');
const HELP = argv.includes('--help') || argv.includes('-h');

function getArgValue(flag: string): string | undefined {
  const i = argv.findIndex((x) => x === flag);
  return i >= 0 ? argv[i + 1] : undefined;
}

function parseCsvSet(v?: string): Set<string> | undefined {
  if (!v) return undefined;
  const s = v
    .split(',')
    .map((x) => x.trim())
    .filter(Boolean);
  return s.length ? new Set(s) : undefined;
}

const ONLY = parseCsvSet(getArgValue('--only'));
const SKIP = parseCsvSet(getArgValue('--skip'));
const APPROVAL_TEMPLATE_NAME = getArgValue('--approval-template-name') || getArgValue('--name') || 'Default Pre-Send';
const PROJECT_ID_FILTER = getArgValue('--projectId');

function shouldRunTask(key: string) {
  if (ONLY && !ONLY.has(key)) return false;
  if (SKIP && SKIP.has(key)) return false;
  return true;
}

function envBool(v: string | undefined) {
  return String(v ?? '').toLowerCase() === 'true';
}

function envBoolDefault(v: string | undefined, def: boolean) {
  if (v === undefined || v === null || String(v).trim() === '') return def;
  return ['1', 'true', 'yes', 'y', 'on'].includes(String(v).toLowerCase());
}

function pick(...vals: Array<string | undefined>) {
  for (const v of vals) {
    if (v !== undefined && v !== null && String(v).trim() !== '') return String(v);
  }
  return undefined;
}

function permNameFromKey(key: string) {
  return key
    .toLowerCase()
    .split('_')
    .map((w) => (w ? w[0].toUpperCase() + w.slice(1) : w))
    .join(' ');
}

function toNumber(v: unknown): number {
  // pg numeric/bigint may come as bigint, number, or string
  if (typeof v === 'number') return v;
  if (typeof v === 'bigint') return Number(v);
  if (typeof v === 'string') return Number.parseInt(v, 10);
  return 0;
}

const databaseUrl = pick(process.env.DATABASE_URL, process.env.PG_URL);
if (!databaseUrl) {
  console.error('[maintenance] DATABASE_URL or PG_URL is missing.');
  process.exit(1);
}

// Repo uses Prisma Driver Adapters
const pool = new Pool({ connectionString: databaseUrl });
const adapter = new PrismaPg(pool);
const prisma = new PrismaClient({ adapter });

async function hasTable(tableName: string): Promise<boolean> {
  const r = await pool.query(
    'select exists (select 1 from information_schema.tables where table_schema=$1 and table_name=$2) as ok',
    ['public', tableName],
  );
  return r.rows?.[0]?.ok === true;
}


async function hasColumn(tableName: string, columnName: string): Promise<boolean> {
  const r = await pool.query(
    'select exists (select 1 from information_schema.columns where table_schema=$1 and table_name=$2 and column_name=$3) as ok',
    ['public', tableName, columnName],
  );
  return r.rows?.[0]?.ok === true;
}


type Runner<T = any> = () => Promise<T>;

async function countRaw(label: string, runnerOrSql: Runner<any> | string, params: any[] = []) {
  let n = 0;

  if (typeof runnerOrSql === 'function') {
    const res = await runnerOrSql();
    if (typeof res === 'number' || typeof res === 'bigint') {
      n = Number(res);
    } else if (Array.isArray(res)) {
      const row: any = res[0] ?? {};
      const v = row.count ?? row.c ?? Object.values(row)[0];
      n = Number(v ?? 0);
    } else if (res && typeof res === 'object') {
      const row: any = res as any;
      const v = row.count ?? row.c ?? Object.values(row)[0];
      n = Number(v ?? 0);
    }
  } else {
    const r = await pool.query(runnerOrSql, params);
    const row: any = r.rows?.[0] ?? {};
    const v = row.count ?? row.c ?? Object.values(row)[0];
    n = Number(v ?? 0);
  }

  console.log(`[count] ${label}: ${n}`);
  return n;
}

async function execRaw(sql: string, params: any[] = []) {
  await pool.query(sql, params);
}

// execMaybe: keeps existing usage pattern:
//   await execMaybe('label', async () => countRaw(...), async () => prisma.$executeRaw`UPDATE ...`)
//
// Also supports raw SQL execution if you ever want it:
//   await execMaybe('label', async () => countRaw(...), 'UPDATE ... WHERE x=$1', [x])
async function execMaybe(
  label: string,
  countFn: Runner<number>,
  execFnOrSql: Runner<any> | string,
  params: any[] = [],
) {
  const would = await countFn();
  if (would <= 0) {
    console.log(`[backfill] ${label}: nothing to do`);
    return;
  }

  if (DRY_RUN) {
    console.log(`[dry-run] ${label}: would affect ~${would}`);
    return;
  }

  let affected: any;
  if (typeof execFnOrSql === 'function') {
    affected = await execFnOrSql();
  } else {
    const r = await pool.query(execFnOrSql, params);
    affected = r.rowCount ?? 0;
  }

  console.log(`[backfill] ${label}: affected=${Number(affected ?? 0)}`);
}

function printHelp(tasks: Task[]) {
  console.log(`\nConsolidated maintenance runner\n`);
  console.log(`DATABASE_URL is required.`);
  console.log(`\nFlags:`);
  console.log(`  --dry-run`);
  console.log(`  --only <comma-separated keys>`);
  console.log(`  --skip <comma-separated keys>`);
  console.log(`  --continue`);
  console.log(`  --approval-template-name "Default Pre-Send"`);
  console.log(`  --projectId <uuid>`);
  console.log(`\nTasks:`);
  for (const t of tasks) console.log(`  - ${t.key}  : ${t.title}`);
  console.log(`\nExamples:`);
  console.log(`  npx ts-node -r dotenv/config src/scripts/maintenance-all.ts`);
  console.log(`  npx ts-node -r dotenv/config src/scripts/maintenance-all.ts --dry-run --only creatives-p1_7,enqueue-media-jobs`);
  console.log(`  npx ts-node -r dotenv/config src/scripts/maintenance-all.ts --only bootstrap`);
  console.log('');
}


// ----------------------
// PERMISSIONS (union of controller @RequirePermissions keys + bootstrap keys)
// ----------------------
// ----------------------
// PERMISSIONS (single source of truth)
// ----------------------
// Pulled from src/common/auth/permission.registry.ts
// DB Permission.type is Prisma enum PermissionType (PAGE|ACTION).
// We infer PAGE vs ACTION from the key format.


function inferPermissionTypeFromKey(key: string): PermissionType {
  const k = key.toLowerCase();
  // Common patterns for "page" permissions in this repo:
  //   - "page:..." (preferred)
  //   - "page_..."  (legacy)
  //   - "page..."   (legacy)
  //   - "page_planner" / "Page_Planner" (legacy)
  if (k.startsWith('page:') || k.startsWith('page_') || k === 'page_planner' || k === 'page:planner') {
    return PermissionType.PAGE;
  }
  return PermissionType.ACTION;
}

type PermissionSeedRow = {
  key: string;
  name: string;
  type: PermissionType; // Prisma enum: PAGE | ACTION
};

const PERMISSIONS_SEED: PermissionSeedRow[] = Array.from(PERMISSIONS).map((p: any) => ({
  key: p.key,
  name: p.name,
  type: String(p.key).startsWith("page:") ? PermissionType.PAGE : PermissionType.ACTION,
}));

// backwards compat: keep old variable name (used by bootstrap tasks)

// ----------------------
// TASKS
// ----------------------

async function taskBootstrap() {
  const enabled = envBool(process.env.BOOTSTRAP_ADMIN) || envBool(process.env.BOOTSTRAP);
  if (!enabled) {
    console.log('[bootstrap] Skipping (set BOOTSTRAP_ADMIN=true or BOOTSTRAP=true to run).');
    return;
  }

  // sanity: tables
  const neededTables = ['Account', 'Permission', 'Role', 'RolePermission', 'User', 'UserRole', 'AccountSequence'];
  for (const t of neededTables) {
    if (!(await hasTable(t))) {
      console.log(`[bootstrap] Skipping: required table "${t}" not found (run migrations first).`);
      return;
    }
  }

  const accountCode = pick(process.env.BOOTSTRAP_ACCOUNT_CODE, process.env.ACCOUNT_CODE) ?? 'default';
  const adminEmail = pick(process.env.BOOTSTRAP_ADMIN_EMAIL, process.env.ADMIN_EMAIL) ?? 'admin@example.com';
  const adminPasswordPlain = pick(process.env.BOOTSTRAP_ADMIN_PASSWORD, process.env.ADMIN_PASSWORD) ?? 'Admin@123';
  const adminName = pick(process.env.BOOTSTRAP_ADMIN_NAME, process.env.ADMIN_NAME) ?? 'Admin';

  const permissionKeys = PERMISSION_KEYS_ALL;

  console.log(`[bootstrap] accountCode=${accountCode} admin=${adminEmail}`);

  if (DRY_RUN) {
    console.log('[dry-run] bootstrap would upsert Account, AccountSequence, Permission(s), Admin Role, Admin User, mappings.');
    return;
  }

  // 1) Account
  const account = await prisma.account.upsert({
    where: { code: accountCode },
    update: { name: accountCode, isActive: true },
    create: {
      code: accountCode,
      name: accountCode,
      type: AccountType.SENDER,
      isActive: true,
    },
  });

  // 1b) Ensure project number sequence exists
  await prisma.accountSequence.upsert({
    where: { accountId_key: { accountId: account.id, key: 'PROJECT_NUMBER' } },
    update: {},
    create: { accountId: account.id, key: 'PROJECT_NUMBER', nextValue: 1 },
  });
// 2) Permissions (from permission.registry.ts)
for (const p of PERMISSIONS_SEED) {
  await prisma.permission.upsert({
    where: { key: p.key },
    update: { type: p.type, name: p.name },
    create: { key: p.key, type: p.type, name: p.name },
  });
}

  // 3) Admin role
  const adminRole = await prisma.role.upsert({
    where: { accountId_name: { accountId: account.id, name: 'Admin' } },
    update: {},
    create: { accountId: account.id, name: 'Admin' },
  });

  // 4) RolePermission mapping (reset -> recreate)
  const perms = await prisma.permission.findMany({
    where: { key: { in: [...permissionKeys] } },
    select: { id: true },
  });

  await prisma.rolePermission.deleteMany({ where: { roleId: adminRole.id } });
  await prisma.rolePermission.createMany({
    data: perms.map((p) => ({ roleId: adminRole.id, permissionId: p.id })),
    skipDuplicates: true,
  });

  // 5) Admin user
  const passwordHashed = await bcrypt.hash(adminPasswordPlain, 10);

  const adminUser = await prisma.user.upsert({
    where: { accountId_email: { accountId: account.id, email: adminEmail } },
    update: {
      displayName: adminName,
      passwordHash: passwordHashed,
      isActive: true,
      userType: UserType.INTERNAL,
    },
    create: {
      accountId: account.id,
      email: adminEmail,
      displayName: adminName,
      passwordHash: passwordHashed,
      isActive: true,
      userType: UserType.INTERNAL,
    },
  });

  // 6) UserRole mapping
  await prisma.userRole.createMany({
    data: [{ userId: adminUser.id, roleId: adminRole.id }],
    skipDuplicates: true,
  });

  console.log('[bootstrap] OK');
}


async function taskSeedPermissions() {
  // Runs when selected via --only seed-permissions (no env required)
  // Optional env:
  //   ACCOUNT_CODE / BOOTSTRAP_ACCOUNT_CODE (default 'default')
  //   ADMIN_ROLE_NAME (default 'Admin')
  //   ADMIN_EMAIL / BOOTSTRAP_ADMIN_EMAIL (optional; if provided, fixes user.accountId + assigns role)
  //   RESET_ADMIN_ROLE_PERMS=true|false (default true)

  // sanity: tables
  const neededTables = ['Account', 'Permission', 'Role', 'RolePermission', 'User', 'UserRole'];
  for (const t of neededTables) {
    if (!(await hasTable(t))) {
      console.log(`[seed-permissions] Skipping: required table "${t}" not found (run migrations first).`);
      return;
    }
  }

  const accountCode = pick(process.env.BOOTSTRAP_ACCOUNT_CODE, process.env.ACCOUNT_CODE) ?? 'default';
  const adminRoleName = pick(process.env.ADMIN_ROLE_NAME) ?? 'Admin';
  const adminEmail = pick(process.env.BOOTSTRAP_ADMIN_EMAIL, process.env.ADMIN_EMAIL);
  const resetAdminRolePerms = envBoolDefault(process.env.RESET_ADMIN_ROLE_PERMS, true);
  const permissionKeys = PERMISSION_KEYS_ALL;

  console.log(`[seed-permissions] accountCode=${accountCode} adminEmail=${adminEmail ?? '(none)'} reset=${resetAdminRolePerms}`);

  if (DRY_RUN) {
    console.log('[dry-run] seed-permissions would upsert Permission(s), ensure Admin role, map RolePermission(s), and optionally fix user.accountId + UserRole.');
    return;
  }

  // 1) Ensure Account exists (safe)
  const account = await prisma.account.upsert({
    where: { code: accountCode },
    update: { name: accountCode, isActive: true },
    create: {
      code: accountCode,
      name: accountCode,
      type: AccountType.SENDER,
      isActive: true,
    },
  });
// 2) Upsert permissions (global) — from permission.registry.ts
for (const p of PERMISSIONS_SEED) {
  await prisma.permission.upsert({
    where: { key: p.key },
    update: { type: p.type, name: p.name },
    create: { key: p.key, type: p.type, name: p.name },
  });
}

  // 3) Ensure Admin role exists for this account
  const adminRole = await prisma.role.upsert({
    where: { accountId_name: { accountId: account.id, name: adminRoleName } },
    update: { isSystem: true, description: 'System admin role' },
    create: { accountId: account.id, name: adminRoleName, isSystem: true, description: 'System admin role' },
  });

  // 4) Map ALL permissions to Admin role (reset optional)
  const perms = await prisma.permission.findMany({
    where: { key: { in: [...permissionKeys] } },
    select: { id: true },
  });

  if (resetAdminRolePerms) {
    await prisma.rolePermission.deleteMany({ where: { roleId: adminRole.id } });
  }

  await prisma.rolePermission.createMany({
    data: perms.map((p) => ({ roleId: adminRole.id, permissionId: p.id })),
    skipDuplicates: true,
  });

  // 5) Optionally: fix user.accountId and assign Admin role
  if (adminEmail) {
    const user = await prisma.user.findFirst({ where: { email: adminEmail }, select: { id: true, accountId: true } });
    if (!user) {
      console.log(`[seed-permissions] Note: user not found for email=${adminEmail} (skipping user mapping).`);
    } else {
      if (user.accountId !== account.id) {
        await prisma.user.update({ where: { id: user.id }, data: { accountId: account.id } });
        console.log('[seed-permissions] user.accountId updated');
      }

      await prisma.userRole.upsert({
        where: { userId_roleId: { userId: user.id, roleId: adminRole.id } },
        update: {},
        create: { userId: user.id, roleId: adminRole.id },
      });

      console.log('[seed-permissions] user assigned Admin role');
    }
  }

  console.log('[seed-permissions] OK');
}


async function taskBackfillChannelDestination() {
  const ok = (await hasTable('Account')) && (await hasTable('Destination')) && (await hasTable('Channel'));
  if (!ok) {
    console.log('[backfill-channel-destination] Skipping: required tables missing.');
    return;
  }

  const accounts = await prisma.account.findMany({ select: { id: true } });

  let wouldCreate = 0;
  let wouldUpdate = 0;

  for (const a of accounts) {
    const dest = await prisma.destination.findFirst({
      where: { accountId: a.id, name: 'UNASSIGNED' },
      select: { id: true },
    });

    if (!dest) wouldCreate++;

    const channels = await prisma.channel.findMany({
      where: { accountId: a.id, destinationId: null },
      select: { id: true },
    });

    wouldUpdate += channels.length;

    if (DRY_RUN) continue;

    const ensuredDest =
      dest ??
      (await prisma.destination.create({
        data: {
          account: { connect: { id: a.id } },
          name: 'UNASSIGNED',
          uri: 'n/a',
        },
        select: { id: true },
      }));

    if (channels.length) {
      await prisma.channel.updateMany({
        where: { accountId: a.id, destinationId: null },
        data: { destinationId: ensuredDest.id },
      });
    }
  }

  if (DRY_RUN) {
    console.log(`[dry-run] backfill-channel-destination: would create ${wouldCreate} Destination(s), update ${wouldUpdate} Channel(s).`);
  } else {
    console.log(`[backfill] backfill-channel-destination: created~${wouldCreate}, updated~${wouldUpdate}`);
  }
}

async function taskBackfillProjectNotificationConfig() {
  const ok = (await hasTable('Project')) && (await hasTable('ProjectNotificationConfig'));
  if (!ok) {
    console.log('[backfill-project-notification-config] Skipping: required tables missing.');
    return;
  }

  const DEFAULT_TYPES = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11];

  function mergeEnabledTypes(existing: number[] | null | undefined) {
    const set = new Set<number>(Array.isArray(existing) ? existing : []);
    for (const t of DEFAULT_TYPES) set.add(t);
    return Array.from(set).sort((a, b) => a - b);
  }

  const projects = await prisma.project.findMany({
    select: { id: true, notificationConfig: { select: { id: true } } },
  });

  const missing = projects.filter((p) => !p.notificationConfig);

  const configs = await prisma.projectNotificationConfig.findMany({
    select: { id: true, enabledTypes: true },
  });

  let wouldCreate = missing.length;
  let wouldUpdate = 0;

  for (const c of configs) {
    const merged = mergeEnabledTypes(c.enabledTypes);
    const same =
      Array.isArray(c.enabledTypes) &&
      c.enabledTypes.length === merged.length &&
      c.enabledTypes.every((v, i) => v === merged[i]);

    if (!same) wouldUpdate++;

    if (DRY_RUN || same) continue;

    await prisma.projectNotificationConfig.update({
      where: { id: c.id },
      data: { enabledTypes: merged },
    });
  }

  if (DRY_RUN) {
    console.log(
      `[dry-run] backfill-project-notification-config: would create ${wouldCreate} row(s), update ${wouldUpdate} row(s) (enabledTypes merge).`,
    );
    return;
  }

  if (missing.length) {
    await prisma.projectNotificationConfig.createMany({
      data: missing.map((p) => ({
        projectId: p.id,
        notifyAdvertiserGroup: true,
        notifyAdvertiser: true,
        notifyBrand: true,
        notifyMediaAgency: true,
        notifyCreativeAgency: true,
        notifyPostHouse: true,
        notifyAudioAgency: true,
        extraEmails: [],
        enabledTypes: DEFAULT_TYPES,
        allowThirdPartyEditBase: false,
        allowThirdPartyAddExtras: true,
      })),
      skipDuplicates: true,
    });
  }

  console.log(`[backfill] backfill-project-notification-config: created=${wouldCreate}, updated=${wouldUpdate}`);
}

async function taskBackfillCreativesP1_7() {
  const creativeTable = 'Creative';
  const assetTable = 'CreativeAsset';

  if (!(await hasTable(creativeTable)) || !(await hasTable(assetTable))) {
    console.log('[backfill-creatives-p1_7] Skipping: tables missing.');
    return;
  }

  const creativeHasValid = await hasColumn(creativeTable, 'valid');
  const creativeHasTitle = await hasColumn(creativeTable, 'title');

  const assetHasFilename = await hasColumn(assetTable, 'filename');
  const assetHasUploadStatus = await hasColumn(assetTable, 'uploadStatus');

  console.log('[backfill-creatives-p1_7] column checks:', {
    'Creative.valid': creativeHasValid,
    'Creative.title': creativeHasTitle,
    'CreativeAsset.filename': assetHasFilename,
    'CreativeAsset.uploadStatus': assetHasUploadStatus,
  });

  // 1) Backfill Creative.valid OR Creative.title
  if (creativeHasValid) {
    await execMaybe(
      'Creative.valid = name where valid is null',
      async () => {
        return countRaw(
          'Creative.valid null count',
          () => prisma.$queryRaw<Array<{ count: bigint }>>`SELECT count(*)::bigint as count FROM "Creative" WHERE "valid" IS NULL`,
        );
      },
      async () =>
        prisma.$executeRaw`
          UPDATE "Creative"
          SET "valid" = "name"
          WHERE "valid" IS NULL
        `,
    );
  } else if (creativeHasTitle) {
    await execMaybe(
      'Creative.title = name where title is null',
      async () => {
        return countRaw(
          'Creative.title null count',
          () => prisma.$queryRaw<Array<{ count: bigint }>>`SELECT count(*)::bigint as count FROM "Creative" WHERE "title" IS NULL`,
        );
      },
      async () =>
        prisma.$executeRaw`
          UPDATE "Creative"
          SET "title" = "name"
          WHERE "title" IS NULL
        `,
    );
  } else {
    console.log('[backfill-creatives-p1_7] Skipping Creative backfill (no valid/title column).');
  }

  // 2) Backfill CreativeAsset.filename from path basename
  if (assetHasFilename) {
    await execMaybe(
      'CreativeAsset.filename from path basename where filename is null',
      async () => {
        return countRaw(
          'CreativeAsset.filename null count',
          () =>
            prisma.$queryRaw<Array<{ count: bigint }>>`
              SELECT count(*)::bigint as count
              FROM "CreativeAsset"
              WHERE "filename" IS NULL
                AND "path" IS NOT NULL
                AND "path" <> ''
            `,
        );
      },
      async () =>
        prisma.$executeRaw`
          UPDATE "CreativeAsset"
          SET "filename" = regexp_replace("path", '^.*/', '')
          WHERE "filename" IS NULL
            AND "path" IS NOT NULL
            AND "path" <> ''
        `,
    );
  } else {
    console.log('[backfill-creatives-p1_7] Skipping filename backfill (column missing).');
  }

  // 3) Mark existing assets as UPLOADED if path exists
  if (assetHasUploadStatus) {
    await execMaybe(
      `CreativeAsset.uploadStatus='UPLOADED' where path exists and status null/PENDING`,
      async () => {
        return countRaw(
          'CreativeAsset.uploadStatus needs backfill',
          () =>
            prisma.$queryRaw<Array<{ count: bigint }>>`
              SELECT count(*)::bigint as count
              FROM "CreativeAsset"
              WHERE "path" IS NOT NULL
                AND "path" <> ''
                AND ("uploadStatus" IS NULL OR "uploadStatus" = 'PENDING')
            `,
        );
      },
      async () =>
        prisma.$executeRaw`
          UPDATE "CreativeAsset"
          SET "uploadStatus" = 'UPLOADED'
          WHERE "path" IS NOT NULL
            AND "path" <> ''
            AND ("uploadStatus" IS NULL OR "uploadStatus" = 'PENDING')
        `,
    );
  } else {
    console.log('[backfill-creatives-p1_7] Skipping uploadStatus backfill (column missing).');
  }

  console.log('[backfill-creatives-p1_7] done');
}

async function taskEnqueueMediaJobs() {
  const creativeTable = 'Creative';
  const assetTable = 'CreativeAsset';
  const jobTable = 'MediaJob';

  if (!(await hasTable(jobTable))) {
    console.log(`[backfill-enqueue-media-jobs] Skipping: "${jobTable}" table not found.`);
    return;
  }

  const creativeHasId = await hasColumn(creativeTable, 'id');
  const creativeHasAccountId = await hasColumn(creativeTable, 'accountId');
  const creativeHasProjectId = await hasColumn(creativeTable, 'projectId');
  const creativeHasQcStatus = await hasColumn(creativeTable, 'qcStatus');

  const assetHasCreativeId = await hasColumn(assetTable, 'creativeId');
  const assetHasType = await hasColumn(assetTable, 'type');
  const assetHasPath = await hasColumn(assetTable, 'path');
  const assetHasUploadStatus = await hasColumn(assetTable, 'uploadStatus');

  const jobHasAccountId = await hasColumn(jobTable, 'accountId');
  const jobHasProjectId = await hasColumn(jobTable, 'projectId');
  const jobHasCreativeId = await hasColumn(jobTable, 'creativeId');
  const jobHasType = await hasColumn(jobTable, 'type');
  const jobHasStatus = await hasColumn(jobTable, 'status');

  console.log('[backfill-enqueue-media-jobs] column checks:', {
    'Creative.id': creativeHasId,
    'Creative.accountId': creativeHasAccountId,
    'Creative.projectId': creativeHasProjectId,
    'Creative.qcStatus': creativeHasQcStatus,
    'CreativeAsset.creativeId': assetHasCreativeId,
    'CreativeAsset.type': assetHasType,
    'CreativeAsset.path': assetHasPath,
    'CreativeAsset.uploadStatus': assetHasUploadStatus,
    'MediaJob.accountId': jobHasAccountId,
    'MediaJob.projectId': jobHasProjectId,
    'MediaJob.creativeId': jobHasCreativeId,
    'MediaJob.type': jobHasType,
    'MediaJob.status': jobHasStatus,
  });

  const ok =
    creativeHasId &&
    creativeHasAccountId &&
    creativeHasProjectId &&
    assetHasCreativeId &&
    assetHasType &&
    assetHasPath &&
    jobHasAccountId &&
    jobHasProjectId &&
    jobHasCreativeId &&
    jobHasType &&
    jobHasStatus;

  if (!ok) {
    console.log('[backfill-enqueue-media-jobs] Skipping: required columns missing (schema not ready).');
    return;
  }

  const hasProjectFilter = Boolean(PROJECT_ID_FILTER);
  if (hasProjectFilter) console.log(`[backfill-enqueue-media-jobs] projectId filter = ${PROJECT_ID_FILTER}`);

  // AUTO_QC
  await execMaybe(
    'enqueue AUTO_QC jobs',
    async () => {
      if (assetHasUploadStatus && creativeHasQcStatus) {
        return countRaw(
          'AUTO_QC to enqueue',
          () =>
            prisma.$queryRaw<Array<{ count: bigint }>>`
              SELECT count(*)::bigint as count
              FROM "Creative" c
              WHERE (c."qcStatus" IS NULL OR c."qcStatus" <> 'PASSED')
                ${hasProjectFilter ? Prisma.sql`AND c."projectId" = ${PROJECT_ID_FILTER}` : Prisma.empty}
                AND EXISTS (
                  SELECT 1 FROM "CreativeAsset" a
                  WHERE a."creativeId" = c."id"
                    AND a."type" = 'SOURCE'
                    AND a."uploadStatus" = 'UPLOADED'
                )
                AND NOT EXISTS (
                  SELECT 1 FROM "MediaJob" j
                  WHERE j."creativeId" = c."id"
                    AND j."type" = 'AUTO_QC'
                    AND j."status" IN ('PENDING','RUNNING')
                )
            `,
        );
      }

      if (assetHasUploadStatus && !creativeHasQcStatus) {
        return countRaw(
          'AUTO_QC to enqueue',
          () =>
            prisma.$queryRaw<Array<{ count: bigint }>>`
              SELECT count(*)::bigint as count
              FROM "Creative" c
              WHERE 1=1
                ${hasProjectFilter ? Prisma.sql`AND c."projectId" = ${PROJECT_ID_FILTER}` : Prisma.empty}
                AND EXISTS (
                  SELECT 1 FROM "CreativeAsset" a
                  WHERE a."creativeId" = c."id"
                    AND a."type" = 'SOURCE'
                    AND a."uploadStatus" = 'UPLOADED'
                )
                AND NOT EXISTS (
                  SELECT 1 FROM "MediaJob" j
                  WHERE j."creativeId" = c."id"
                    AND j."type" = 'AUTO_QC'
                    AND j."status" IN ('PENDING','RUNNING')
                )
            `,
        );
      }

      // fallback: no uploadStatus
      return countRaw(
        'AUTO_QC to enqueue (path fallback)',
        () =>
          prisma.$queryRaw<Array<{ count: bigint }>>`
            SELECT count(*)::bigint as count
            FROM "Creative" c
            WHERE 1=1
              ${hasProjectFilter ? Prisma.sql`AND c."projectId" = ${PROJECT_ID_FILTER}` : Prisma.empty}
              AND EXISTS (
                SELECT 1 FROM "CreativeAsset" a
                WHERE a."creativeId" = c."id"
                  AND a."type" = 'SOURCE'
                  AND a."path" IS NOT NULL
                  AND a."path" <> ''
              )
              AND NOT EXISTS (
                SELECT 1 FROM "MediaJob" j
                WHERE j."creativeId" = c."id"
                  AND j."type" = 'AUTO_QC'
                  AND j."status" IN ('PENDING','RUNNING')
              )
          `,
      );
    },
    async () => {
      if (assetHasUploadStatus && creativeHasQcStatus) {
        return prisma.$executeRaw`
          INSERT INTO "MediaJob" ("accountId","projectId","creativeId","type","status")
          SELECT c."accountId", c."projectId", c."id", 'AUTO_QC', 'PENDING'
          FROM "Creative" c
          WHERE (c."qcStatus" IS NULL OR c."qcStatus" <> 'PASSED')
            ${hasProjectFilter ? Prisma.sql`AND c."projectId" = ${PROJECT_ID_FILTER}` : Prisma.empty}
            AND EXISTS (
              SELECT 1 FROM "CreativeAsset" a
              WHERE a."creativeId" = c."id"
                AND a."type" = 'SOURCE'
                AND a."uploadStatus" = 'UPLOADED'
            )
            AND NOT EXISTS (
              SELECT 1 FROM "MediaJob" j
              WHERE j."creativeId" = c."id"
                AND j."type" = 'AUTO_QC'
                AND j."status" IN ('PENDING','RUNNING')
            )
        `;
      }

      if (assetHasUploadStatus && !creativeHasQcStatus) {
        return prisma.$executeRaw`
          INSERT INTO "MediaJob" ("accountId","projectId","creativeId","type","status")
          SELECT c."accountId", c."projectId", c."id", 'AUTO_QC', 'PENDING'
          FROM "Creative" c
          WHERE 1=1
            ${hasProjectFilter ? Prisma.sql`AND c."projectId" = ${PROJECT_ID_FILTER}` : Prisma.empty}
            AND EXISTS (
              SELECT 1 FROM "CreativeAsset" a
              WHERE a."creativeId" = c."id"
                AND a."type" = 'SOURCE'
                AND a."uploadStatus" = 'UPLOADED'
            )
            AND NOT EXISTS (
              SELECT 1 FROM "MediaJob" j
              WHERE j."creativeId" = c."id"
                AND j."type" = 'AUTO_QC'
                AND j."status" IN ('PENDING','RUNNING')
            )
        `;
      }

      return prisma.$executeRaw`
        INSERT INTO "MediaJob" ("accountId","projectId","creativeId","type","status")
        SELECT c."accountId", c."projectId", c."id", 'AUTO_QC', 'PENDING'
        FROM "Creative" c
        WHERE 1=1
          ${hasProjectFilter ? Prisma.sql`AND c."projectId" = ${PROJECT_ID_FILTER}` : Prisma.empty}
          AND EXISTS (
            SELECT 1 FROM "CreativeAsset" a
            WHERE a."creativeId" = c."id"
              AND a."type" = 'SOURCE'
              AND a."path" IS NOT NULL
              AND a."path" <> ''
          )
          AND NOT EXISTS (
            SELECT 1 FROM "MediaJob" j
            WHERE j."creativeId" = c."id"
              AND j."type" = 'AUTO_QC'
              AND j."status" IN ('PENDING','RUNNING')
          )
      `;
    },
  );

  // PROXY_GEN
  await execMaybe(
    'enqueue PROXY_GEN jobs',
    async () => {
      if (assetHasUploadStatus) {
        return countRaw(
          'PROXY_GEN to enqueue',
          () =>
            prisma.$queryRaw<Array<{ count: bigint }>>`
              SELECT count(*)::bigint as count
              FROM "Creative" c
              WHERE 1=1
                ${hasProjectFilter ? Prisma.sql`AND c."projectId" = ${PROJECT_ID_FILTER}` : Prisma.empty}
                AND EXISTS (
                  SELECT 1 FROM "CreativeAsset" a
                  WHERE a."creativeId" = c."id"
                    AND a."type" = 'SOURCE'
                    AND a."uploadStatus" = 'UPLOADED'
                )
                AND NOT EXISTS (
                  SELECT 1 FROM "CreativeAsset" p
                  WHERE p."creativeId" = c."id"
                    AND p."type" = 'PROXY'
                    AND p."uploadStatus" = 'UPLOADED'
                )
                AND NOT EXISTS (
                  SELECT 1 FROM "MediaJob" j
                  WHERE j."creativeId" = c."id"
                    AND j."type" = 'PROXY_GEN'
                    AND j."status" IN ('PENDING','RUNNING')
                )
            `,
        );
      }

      return countRaw(
        'PROXY_GEN to enqueue (path fallback)',
        () =>
          prisma.$queryRaw<Array<{ count: bigint }>>`
            SELECT count(*)::bigint as count
            FROM "Creative" c
            WHERE 1=1
              ${hasProjectFilter ? Prisma.sql`AND c."projectId" = ${PROJECT_ID_FILTER}` : Prisma.empty}
              AND EXISTS (
                SELECT 1 FROM "CreativeAsset" a
                WHERE a."creativeId" = c."id"
                  AND a."type" = 'SOURCE'
                  AND a."path" IS NOT NULL
                  AND a."path" <> ''
              )
              AND NOT EXISTS (
                SELECT 1 FROM "CreativeAsset" p
                WHERE p."creativeId" = c."id"
                  AND p."type" = 'PROXY'
                  AND p."path" IS NOT NULL
                  AND p."path" <> ''
              )
              AND NOT EXISTS (
                SELECT 1 FROM "MediaJob" j
                WHERE j."creativeId" = c."id"
                  AND j."type" = 'PROXY_GEN'
                  AND j."status" IN ('PENDING','RUNNING')
              )
          `,
      );
    },
    async () => {
      if (assetHasUploadStatus) {
        return prisma.$executeRaw`
          INSERT INTO "MediaJob" ("accountId","projectId","creativeId","type","status")
          SELECT c."accountId", c."projectId", c."id", 'PROXY_GEN', 'PENDING'
          FROM "Creative" c
          WHERE 1=1
            ${hasProjectFilter ? Prisma.sql`AND c."projectId" = ${PROJECT_ID_FILTER}` : Prisma.empty}
            AND EXISTS (
              SELECT 1 FROM "CreativeAsset" a
              WHERE a."creativeId" = c."id"
                AND a."type" = 'SOURCE'
                AND a."uploadStatus" = 'UPLOADED'
            )
            AND NOT EXISTS (
              SELECT 1 FROM "CreativeAsset" p
              WHERE p."creativeId" = c."id"
                AND p."type" = 'PROXY'
                AND p."uploadStatus" = 'UPLOADED'
            )
            AND NOT EXISTS (
              SELECT 1 FROM "MediaJob" j
              WHERE j."creativeId" = c."id"
                AND j."type" = 'PROXY_GEN'
                AND j."status" IN ('PENDING','RUNNING')
            )
        `;
      }

      return prisma.$executeRaw`
        INSERT INTO "MediaJob" ("accountId","projectId","creativeId","type","status")
        SELECT c."accountId", c."projectId", c."id", 'PROXY_GEN', 'PENDING'
        FROM "Creative" c
        WHERE 1=1
          ${hasProjectFilter ? Prisma.sql`AND c."projectId" = ${PROJECT_ID_FILTER}` : Prisma.empty}
          AND EXISTS (
            SELECT 1 FROM "CreativeAsset" a
            WHERE a."creativeId" = c."id"
              AND a."type" = 'SOURCE'
              AND a."path" IS NOT NULL
              AND a."path" <> ''
          )
          AND NOT EXISTS (
            SELECT 1 FROM "CreativeAsset" p
            WHERE p."creativeId" = c."id"
              AND p."type" = 'PROXY'
              AND p."path" IS NOT NULL
              AND p."path" <> ''
          )
          AND NOT EXISTS (
            SELECT 1 FROM "MediaJob" j
            WHERE j."creativeId" = c."id"
              AND j."type" = 'PROXY_GEN'
              AND j."status" IN ('PENDING','RUNNING')
          )
      `;
    },
  );

  console.log('[backfill-enqueue-media-jobs] done');
}

async function taskApprovalTemplate() {
  const accountTable = 'Account';
  const templateTable = 'ApprovalTemplate';
  const projectTable = 'Project';

  if (!(await hasTable(accountTable))) {
    console.log(`[backfill-approval-template] Skipping: "${accountTable}" table not found.`);
    return;
  }
  if (!(await hasTable(templateTable))) {
    console.log(`[backfill-approval-template] Skipping: "${templateTable}" table not found (run migration first).`);
    return;
  }

  const accountHasId = await hasColumn(accountTable, 'id');

  const tplHasAccountId = await hasColumn(templateTable, 'accountId');
  const tplHasName = await hasColumn(templateTable, 'name');
  const tplHasMode = await hasColumn(templateTable, 'mode');
  const tplHasSteps = await hasColumn(templateTable, 'steps');
  const tplHasIsActive = await hasColumn(templateTable, 'isActive');
  const tplHasCreatedAt = await hasColumn(templateTable, 'createdAt');
  const tplHasUpdatedAt = await hasColumn(templateTable, 'updatedAt');

  const projectTableExists = await hasTable(projectTable);
  const projectHasAccountId = projectTableExists ? await hasColumn(projectTable, 'accountId') : false;
  const projectHasApprovalsEnabled = projectTableExists ? await hasColumn(projectTable, 'approvalsEnabled') : false;
  const projectHasApprovalTemplateId = projectTableExists ? await hasColumn(projectTable, 'approvalTemplateId') : false;

  console.log('[backfill-approval-template] column checks:', {
    'Account.id': accountHasId,
    'ApprovalTemplate.accountId': tplHasAccountId,
    'ApprovalTemplate.name': tplHasName,
    'ApprovalTemplate.mode': tplHasMode,
    'ApprovalTemplate.steps': tplHasSteps,
    'ApprovalTemplate.isActive': tplHasIsActive,
    'ApprovalTemplate.createdAt': tplHasCreatedAt,
    'ApprovalTemplate.updatedAt': tplHasUpdatedAt,
    'Project exists': projectTableExists,
    'Project.accountId': projectHasAccountId,
    'Project.approvalsEnabled': projectHasApprovalsEnabled,
    'Project.approvalTemplateId': projectHasApprovalTemplateId,
  });

  const ok =
    accountHasId &&
    tplHasAccountId &&
    tplHasName &&
    tplHasMode &&
    tplHasSteps &&
    tplHasIsActive &&
    tplHasUpdatedAt;

  if (!ok) {
    console.log('[backfill-approval-template] Skipping: required columns missing (schema not ready).');
    return;
  }

  const DEFAULT_STEPS = [
    { key: 'MEDIA', label: 'Media Review', order: 1, required: true, approverEmails: [] as string[] },
    { key: 'COMPLIANCE', label: 'Compliance', order: 2, required: false, approverEmails: [] as string[] },
    { key: 'CLIENT', label: 'Client Approval', order: 3, required: true, approverEmails: [] as string[] },
  ];

  const stepsJson = JSON.stringify(DEFAULT_STEPS);

  // 1) Create template per account if missing
  await execMaybe(
    `create default templates if missing (name="${APPROVAL_TEMPLATE_NAME}")`,
    async () => {
      return countRaw(
        'templates missing per account',
        () =>
          prisma.$queryRaw<Array<{ count: bigint }>>`
            SELECT count(*)::bigint as count
            FROM "Account" a
            WHERE NOT EXISTS (
              SELECT 1 FROM "ApprovalTemplate" t
              WHERE t."accountId" = a."id" AND t."name" = ${APPROVAL_TEMPLATE_NAME}
            )
          `,
      );
    },
    async () => {
      if (tplHasCreatedAt) {
        return prisma.$executeRaw`
          INSERT INTO "ApprovalTemplate" ("accountId","name","mode","steps","isActive","createdAt","updatedAt")
          SELECT a."id", ${APPROVAL_TEMPLATE_NAME}, 'SEQUENTIAL', CAST(${stepsJson} AS jsonb), false, now(), now()
          FROM "Account" a
          WHERE NOT EXISTS (
            SELECT 1 FROM "ApprovalTemplate" t
            WHERE t."accountId" = a."id" AND t."name" = ${APPROVAL_TEMPLATE_NAME}
          )
        `;
      }

      return prisma.$executeRaw`
        INSERT INTO "ApprovalTemplate" ("accountId","name","mode","steps","isActive","updatedAt")
        SELECT a."id", ${APPROVAL_TEMPLATE_NAME}, 'SEQUENTIAL', CAST(${stepsJson} AS jsonb), false, now()
        FROM "Account" a
        WHERE NOT EXISTS (
          SELECT 1 FROM "ApprovalTemplate" t
          WHERE t."accountId" = a."id" AND t."name" = ${APPROVAL_TEMPLATE_NAME}
        )
      `;
    },
  );

  // 2) Activate this template only for accounts that have no active template
  await execMaybe(
    'activate default template where none active',
    async () => {
      return countRaw(
        'templates to activate',
        () =>
          prisma.$queryRaw<Array<{ count: bigint }>>`
            SELECT count(*)::bigint as count
            FROM "ApprovalTemplate" t
            WHERE t."name" = ${APPROVAL_TEMPLATE_NAME}
              AND t."isActive" = false
              AND NOT EXISTS (
                SELECT 1 FROM "ApprovalTemplate" x
                WHERE x."accountId" = t."accountId" AND x."isActive" = true
              )
          `,
      );
    },
    async () =>
      prisma.$executeRaw`
        UPDATE "ApprovalTemplate" t
        SET "isActive" = true,
            "updatedAt" = now()
        WHERE t."name" = ${APPROVAL_TEMPLATE_NAME}
          AND NOT EXISTS (
            SELECT 1 FROM "ApprovalTemplate" x
            WHERE x."accountId" = t."accountId" AND x."isActive" = true
          )
      `,
  );

  // 3) Optional: link approvalsEnabled projects to the active template
  if (projectTableExists && projectHasAccountId && projectHasApprovalsEnabled && projectHasApprovalTemplateId) {
    await execMaybe(
      'link approvalsEnabled projects to active template',
      async () => {
        return countRaw(
          'projects to link',
          () =>
            prisma.$queryRaw<Array<{ count: bigint }>>`
              SELECT count(*)::bigint as count
              FROM "Project" p
              JOIN "ApprovalTemplate" t
                ON p."accountId" = t."accountId"
              WHERE p."approvalsEnabled" = true
                AND p."approvalTemplateId" IS NULL
                AND t."isActive" = true
            `,
        );
      },
      async () =>
        prisma.$executeRaw`
          UPDATE "Project" p
          SET "approvalTemplateId" = t."id"
          FROM "ApprovalTemplate" t
          WHERE p."accountId" = t."accountId"
            AND p."approvalsEnabled" = true
            AND p."approvalTemplateId" IS NULL
            AND t."isActive" = true
        `,
    );
  } else {
    console.log('[backfill-approval-template] Skipping project linking (Project.approvalTemplateId not present).');
  }

  console.log('[backfill-approval-template] done');
}

const TASKS: Task[] = [
  { key: 'bootstrap', title: 'Bootstrap admin/account/permissions', run: taskBootstrap },
  { key: 'seed-permissions', title: 'Seed permissions + map Admin role (+fix user.accountId/UserRole)', run: taskSeedPermissions },
  { key: 'channel-destination', title: 'Backfill Channel.destinationId (UNASSIGNED per account)', run: taskBackfillChannelDestination },
  { key: 'project-notifications', title: 'Backfill ProjectNotificationConfig + enabledTypes(1..11)', run: taskBackfillProjectNotificationConfig },
  { key: 'creatives-p1_7', title: 'Backfill Creative.valid/title, CreativeAsset.filename/uploadStatus', run: taskBackfillCreativesP1_7 },
  { key: 'enqueue-media-jobs', title: 'Backfill P1.8: enqueue AUTO_QC + PROXY_GEN (idempotent)', run: taskEnqueueMediaJobs },
  { key: 'approval-template', title: 'Backfill P1.9: ApprovalTemplate default + activation + optional project linking', run: taskApprovalTemplate },
];

async function main() {
  if (HELP) {
    printHelp(TASKS);
    return;
  }

  console.log('[maintenance] starting', {
    dryRun: DRY_RUN,
    only: ONLY ? Array.from(ONLY) : undefined,
    skip: SKIP ? Array.from(SKIP) : undefined,
    continueOnError: CONTINUE_ON_ERROR,
    approvalTemplateName: APPROVAL_TEMPLATE_NAME,
    projectId: PROJECT_ID_FILTER,
  });

  for (const t of TASKS) {
    if (!shouldRunTask(t.key)) continue;

    console.log(`\n========== ${t.key} ==========`);
    console.log(t.title);

    try {
      await t.run();
    } catch (e) {
      console.error(`[maintenance] Task failed: ${t.key}`, e);
      process.exitCode = 1;
      if (!CONTINUE_ON_ERROR) throw e;
    }
  }

  console.log('\n[maintenance] done');
}

main()
  .catch((e) => {
    console.error('[maintenance] FAILED', e);
    process.exitCode = 1;
  })
  .finally(async () => {
    await prisma.$disconnect().catch(() => undefined);
    await pool.end().catch(() => undefined);
  });
