import "dotenv/config";

import * as bcrypt from "bcryptjs";
import { PrismaClient } from "@prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
import { Pool } from "pg";

/**
 * Backfill People login users from existing Partner Accounts.
 *
 * Rules:
 * - only ACTIVE partner accounts are scanned
 * - first valid email in partnerAccount.emails[] is used
 * - displayName is the email local part (before @)
 * - default password comes from PARTNER_ACCOUNT_DEFAULT_PASSWORD,
 *   AUTO_USER_DEFAULT_PASSWORD, or falls back to ChangeMe@123
 * - users are created with NO roles (no access)
 * - existing users for the same accountId + email are left unchanged
 *
 * Run:
 *   npx ts-node -r dotenv/config src/scripts/backfill-partner-account-people.ts
 */

function pick(...vals: Array<string | undefined>) {
  for (const v of vals) {
    if (v !== undefined && v !== null && String(v).trim() !== "") return String(v);
  }
  return undefined;
}

function normalizeEmail(raw?: string | null) {
  const email = String(raw ?? "").trim().toLowerCase();
  return email.includes("@") ? email : "";
}

function firstEmail(emails?: string[] | null) {
  if (!Array.isArray(emails)) return "";
  for (const raw of emails) {
    const email = normalizeEmail(raw);
    if (email) return email;
  }
  return "";
}

async function main() {
  const databaseUrl = pick(process.env.DATABASE_URL, process.env.PG_URL);
  if (!databaseUrl) {
    console.error("[backfill-partner-account-people] DATABASE_URL or PG_URL is missing");
    process.exit(1);
  }

  const defaultPassword = pick(
    process.env.PARTNER_ACCOUNT_DEFAULT_PASSWORD,
    process.env.AUTO_USER_DEFAULT_PASSWORD,
    "ChangeMe@123",
  )!;

  const pool = new Pool({ connectionString: databaseUrl });
  const adapter = new PrismaPg(pool);
  const prisma = new PrismaClient({ adapter });

  try {
    const accounts = await prisma.partnerAccount.findMany({
      where: { status: "ACTIVE" as any },
      select: { id: true, accountId: true, name: true, emails: true },
      orderBy: { name: "asc" },
    });

    let created = 0;
    let existing = 0;
    let skipped = 0;

    for (const row of accounts) {
      const email = firstEmail(row.emails);
      if (!email) {
        skipped += 1;
        console.log(`[skip] ${row.name} (${row.id}) -> no valid email`);
        continue;
      }

      const found = await prisma.user.findFirst({
        where: { accountId: row.accountId, email },
        select: { id: true },
      });

      if (found) {
        existing += 1;
        console.log(`[exists] ${row.name} (${row.id}) -> ${email}`);
        continue;
      }

      const passwordHash = await bcrypt.hash(defaultPassword, 10);
      const displayName = email.split("@")[0] || email;

      await prisma.user.create({
        data: {
          account: { connect: { id: row.accountId } },
          email,
          displayName,
          passwordHash,
          isActive: true,
        },
        select: { id: true },
      });

      created += 1;
      console.log(`[created] ${row.name} (${row.id}) -> ${email}`);
    }

    console.log(`[backfill-partner-account-people] scanned=${accounts.length} created=${created} existing=${existing} skipped=${skipped}`);
  } finally {
    await pool.end();
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
