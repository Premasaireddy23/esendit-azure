import "dotenv/config";

import { PrismaClient } from "@prisma/client";
import { PrismaPg } from "@prisma/adapter-pg";
import { Pool } from "pg";

/**
 * Backfill new RateCardItem columns: sdAmount / hdAmount.
 *
 * Expand → Migrate → Contract strategy:
 *   1) Add new nullable columns (sdAmount, hdAmount)
 *   2) Backfill existing rows (this script)
 *   3) Update code/UI to use sdAmount/hdAmount
 *   4) (Later) Make sdAmount/hdAmount required and remove legacy `amount`
 *
 * Run:
 *   npx ts-node -r dotenv/config src/scripts/backfill-ratecard-sd-hd.ts
 */

function pick(...vals: Array<string | undefined>) {
  for (const v of vals) {
    if (v !== undefined && v !== null && String(v).trim() !== "") return String(v);
  }
  return undefined;
}

async function main() {
  const databaseUrl = pick(process.env.DATABASE_URL, process.env.PG_URL);
  if (!databaseUrl) {
    console.error("[backfill-ratecard-sd-hd] DATABASE_URL or PG_URL is missing");
    process.exit(1);
  }

  const pool = new Pool({ connectionString: databaseUrl });
  const adapter = new PrismaPg(pool);
  const prisma = new PrismaClient({ adapter });

  try {
    // Prisma doesn't support cross-column assignment in updateMany,
    // so we do it via a single SQL statement.
    const sql = `
      UPDATE "RateCardItem"
      SET
        "sdAmount" = COALESCE("sdAmount", "amount"),
        "hdAmount" = COALESCE("hdAmount", "amount")
      WHERE "sdAmount" IS NULL OR "hdAmount" IS NULL;
    `;

    const r = await pool.query(sql);
    console.log(`[backfill-ratecard-sd-hd] updated rows: ${r.rowCount ?? 0}`);
    // keep prisma referenced so ts doesn't tree-shake / for future extensions
    void prisma;
  } finally {
    await pool.end();
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
