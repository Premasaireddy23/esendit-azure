import { Body, Controller, Delete, Get, Param, Patch, Post, Put, UseGuards } from "@nestjs/common";
import { CurrentUser } from "../../common/auth/current-user.decorator";
import { RequirePermissions } from "../../common/auth/require-permissions.decorator";
import { JwtAuthGuard } from "../../common/auth/jwt-auth.guard";
import { PermissionsGuard } from "../../common/auth/permissions.guard";
import { UsersService } from "./users.service";
import { CreateUserDto } from "./dto/create-user.dto";
import { SetUserStatusDto } from "./dto/set-user-status.dto";
import { SetUserRolesDto } from "./dto/set-user-roles.dto";
import { ResetUserPasswordDto } from "./dto/reset-user-password.dto";
import { DeleteUserDto } from "./dto/delete-user.dto";

@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller("admin/users")
export class UsersController {
  constructor(private users: UsersService) {}

  @Get()
  @RequirePermissions("ADMIN_USERS_READ")
  list(@CurrentUser() user: any) {
    return this.users.list(user.accountId);
  }

  @Post()
  @RequirePermissions("ADMIN_USERS_WRITE")
  create(@CurrentUser() user: any, @Body() dto: CreateUserDto) {
    return this.users.create(user.accountId, dto.email, dto.password, dto.roleIds, dto.displayName);
  }

  @Post("sync-from-accounts")
  @RequirePermissions("ADMIN_USERS_WRITE")
  syncFromAccounts(@CurrentUser() user: any) {
    return this.users.syncFromAccounts(user.accountId);
  }


  @Post(":id/support-session")
  @RequirePermissions("action:admin:support-view")
  createSupportSession(@CurrentUser() user: any, @Param("id") id: string, @Body() dto: { reason?: string; ticket?: string }) {
    return this.users.createSupportSession(user.accountId, user, id, dto);
  }

  @Patch(":id/status")
  @RequirePermissions("ADMIN_USERS_WRITE")
  setStatus(@CurrentUser() user: any, @Param("id") id: string, @Body() dto: SetUserStatusDto) {
    return this.users.setStatus(user.accountId, id, dto.isActive);
  }

  @Put(":id/roles")
  @RequirePermissions("ADMIN_USERS_WRITE")
  setRoles(@CurrentUser() user: any, @Param("id") id: string, @Body() dto: SetUserRolesDto) {
    return this.users.setRoles(user.accountId, id, dto.roleIds);
  }

  @Patch(":id/password")
  @RequirePermissions("ADMIN_USERS_WRITE")
  resetPassword(@CurrentUser() user: any, @Param("id") id: string, @Body() dto: ResetUserPasswordDto) {
    return this.users.resetPassword(user.accountId, user.id, id, dto.newPassword);
  }

  @Delete(":id")
  @RequirePermissions("ADMIN_USERS_WRITE")
  remove(@CurrentUser() user: any, @Param("id") id: string, @Body() dto: DeleteUserDto) {
    return this.users.remove(user.accountId, user.id, id, dto?.reason);
  }
}
