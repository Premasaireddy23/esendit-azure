import { Controller, Get, UseGuards } from "@nestjs/common";
import { PrismaService } from "../../common/prisma/prisma.service";
import { RequirePermissions } from "../../common/auth/require-permissions.decorator";
import { JwtAuthGuard } from "../../common/auth/jwt-auth.guard";
import { PermissionsGuard } from "../../common/auth/permissions.guard";

@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller("admin/permissions")
export class PermissionsController {
  constructor(private prisma: PrismaService) {}

  @Get()
  @RequirePermissions("ADMIN_ROLES_READ")
  async list() {
    return this.prisma.permission.findMany({
      orderBy: [{ type: "asc" }, { key: "asc" }],
      // Include a human-friendly name for UI. (Does not affect enforcement.)
      select: { id: true, key: true, type: true, name: true },
    });
  }
}
