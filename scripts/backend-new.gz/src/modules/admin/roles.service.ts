import { BadRequestException, Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../../common/prisma/prisma.service";

@Injectable()
export class RolesService {
  constructor(private prisma: PrismaService) {}

  async list(accountId: string) {
    const roles = await this.prisma.role.findMany({
      where: { accountId },
      orderBy: { name: "asc" },
      select: {
        id: true,
        name: true,
        description: true,
        isSystem: true,
        // ✅ in YOUR schema it's called perms (RolePermission[])
        perms: {
          select: {
            permission: { select: { key: true, type: true } },
          },
        },
      },
    });

    // ✅ keep API response clean: return "permissions" to UI
    return roles.map((r) => ({
      id: r.id,
      name: r.name,
      description: r.description,
      isSystem: r.isSystem,
      permissions: r.perms.map((p) => p.permission),
    }));
  }

  async create(accountId: string, name: string, description?: string) {
    const existing = await this.prisma.role.findFirst({ where: { accountId, name } });
    if (existing) throw new BadRequestException("Role name already exists in this account");

    return this.prisma.role.create({
      data: {
        account: { connect: { id: accountId } },
        name,
        description,
      },
      select: { id: true, name: true, description: true, isSystem: true },
    });
  }

  async setPermissions(accountId: string, roleId: string, permissionKeys: string[]) {
    const role = await this.prisma.role.findFirst({ where: { id: roleId, accountId } });
    if (!role) throw new NotFoundException("Role not found");

    const perms = await this.prisma.permission.findMany({
      where: { key: { in: permissionKeys } },
      select: { id: true },
    });
    if (perms.length !== permissionKeys.length) {
      throw new BadRequestException("Unknown permissionKeys");
    }

    await this.prisma.rolePermission.deleteMany({ where: { roleId } });

    if (perms.length) {
      await this.prisma.rolePermission.createMany({
        data: perms.map((p) => ({ roleId, permissionId: p.id })),
      });
    }

    return { ok: true };
  }
}
