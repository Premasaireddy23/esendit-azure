import { BadRequestException, Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../../common/prisma/prisma.service';

@Injectable()
export class GroupsService {
  constructor(private readonly prisma: PrismaService) {}

  async meta(accountId: string) {
    const [groups, users, roles] = await Promise.all([
      this.prisma.group.findMany({
        where: { accountId },
        orderBy: { name: 'asc' },
        select: {
          id: true,
          name: true,
          description: true,
          createdAt: true,
          updatedAt: true,
          _count: { select: { members: true, roles: true } },
        },
      }),
      this.prisma.user.findMany({
        where: { accountId, isActive: true },
        orderBy: { displayName: 'asc' },
        select: { id: true, displayName: true, email: true, isActive: true },
      }),
      this.prisma.role.findMany({
        where: { accountId },
        orderBy: { name: 'asc' },
        select: { id: true, name: true, description: true },
      }),
    ]);

    return {
      groups: groups.map((g) => ({
        id: g.id,
        name: g.name,
        description: g.description,
        isSystem: false, // schema has no isSystem
        memberCount: g._count.members,
        roleCount: g._count.roles,
        createdAt: g.createdAt,
        updatedAt: g.updatedAt,
      })),
      // Map displayName -> name to keep frontend stable
      users: users.map((u) => ({
        id: u.id,
        name: u.displayName,
        email: u.email,
        isActive: u.isActive,
      })),
      roles,
    };
  }

  async list(accountId: string) {
    const groups = await this.prisma.group.findMany({
      where: { accountId },
      orderBy: { name: 'asc' },
      select: {
        id: true,
        name: true,
        description: true,
        createdAt: true,
        updatedAt: true,
        _count: { select: { members: true, roles: true } },
      },
    });

    return groups.map((g) => ({
      id: g.id,
      name: g.name,
      description: g.description,
      isSystem: false,
      memberCount: g._count.members,
      roleCount: g._count.roles,
      createdAt: g.createdAt,
      updatedAt: g.updatedAt,
    }));
  }

  async get(accountId: string, groupId: string) {
    const g = await this.prisma.group.findFirst({
      where: { id: groupId, accountId },
      include: {
        members: {
          include: {
            user: { select: { id: true, displayName: true, email: true, isActive: true } },
          },
        },
        roles: {
          include: {
            role: { select: { id: true, name: true, description: true } },
          },
        },
      },
    });

    if (!g) throw new NotFoundException('Group not found');

    return {
      id: g.id,
      name: g.name,
      description: g.description,
      isSystem: false,
      members: g.members.map((m) => ({
        id: m.user.id,
        name: m.user.displayName,
        email: m.user.email,
        isActive: m.user.isActive,
      })),
      roles: g.roles.map((r) => r.role),
      createdAt: g.createdAt,
      updatedAt: g.updatedAt,
    };
  }

  async create(accountId: string, input: { name: string; description?: string | null }) {
    const name = (input.name || '').trim();
    if (!name) throw new BadRequestException('Group name is required');

    const existing = await this.prisma.group.findFirst({ where: { accountId, name } });
    if (existing) throw new BadRequestException('Group with this name already exists');

    const g = await this.prisma.group.create({
      data: { accountId, name, description: input.description ?? null },
      select: { id: true, name: true, description: true, createdAt: true, updatedAt: true },
    });

    return { ...g, isSystem: false };
  }

  async setMembers(accountId: string, groupId: string, userIds: string[]) {
    const group = await this.prisma.group.findFirst({ where: { id: groupId, accountId } });
    if (!group) throw new NotFoundException('Group not found');

    await this.prisma.groupMember.deleteMany({ where: { groupId } });

    if (userIds?.length) {
      await this.prisma.groupMember.createMany({
        data: userIds.map((userId) => ({ groupId, userId })),
        skipDuplicates: true,
      });
    }

    return { ok: true };
  }

  async setRoles(accountId: string, groupId: string, roleIds: string[]) {
    const group = await this.prisma.group.findFirst({ where: { id: groupId, accountId } });
    if (!group) throw new NotFoundException('Group not found');

    await this.prisma.groupRole.deleteMany({ where: { groupId } });

    if (roleIds?.length) {
      await this.prisma.groupRole.createMany({
        data: roleIds.map((roleId) => ({ groupId, roleId })),
        skipDuplicates: true,
      });
    }

    return { ok: true };
  }
}
