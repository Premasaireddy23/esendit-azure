import { BadRequestException, Injectable, NotFoundException } from "@nestjs/common";
import { JwtService } from "@nestjs/jwt";
import * as bcrypt from "bcryptjs";
import { PrismaService } from "../../common/prisma/prisma.service";
import { syncMissingPeopleFromPartnerAccounts } from "../../common/users/partner-account-user-sync";

@Injectable()
export class UsersService {
  constructor(
    private prisma: PrismaService,
    private readonly jwt: JwtService,
  ) {}

  async list(accountId: string) {
    return this.prisma.user.findMany({
      where: { accountId },
      orderBy: { createdAt: "desc" },
      select: {
        id: true,
        email: true,
        displayName: true,
        isActive: true,
        createdAt: true,
        roles: {
          select: {
            role: { select: { id: true, name: true } },
          },
        },
      },
    });
  }

  async create(accountId: string, email: string, password: string, roleIds?: string[], displayName?: string) {
    const existing = await this.prisma.user.findFirst({ where: { accountId, email } });
    if (existing) throw new BadRequestException("Email already exists in this account");

    const passwordHash = await bcrypt.hash(password, 10);

    if (roleIds?.length) {
      const roles = await this.prisma.role.findMany({
        where: { id: { in: roleIds }, accountId },
        select: { id: true },
      });
      if (roles.length !== roleIds.length) throw new BadRequestException("Invalid roleIds for this account");
    }

    const finalDisplayName = displayName?.trim() || email.split("@")[0];

    return this.prisma.user.create({
      data: {
        account: { connect: { id: accountId } },
        email,
        displayName: finalDisplayName,
        passwordHash,
        isActive: true,
        roles: roleIds?.length
          ? {
              create: roleIds.map((roleId) => ({ roleId })),
            }
          : undefined,
      },
      select: { id: true, email: true, displayName: true, isActive: true },
    });
  }

  async setStatus(accountId: string, userId: string, isActive: boolean) {
    const user = await this.prisma.user.findFirst({ where: { id: userId, accountId } });
    if (!user) throw new NotFoundException("User not found");

    return this.prisma.user.update({
      where: { id: userId },
      data: { isActive },
      select: { id: true, email: true, isActive: true },
    });
  }

  async resetPassword(accountId: string, actorUserId: string, userId: string, newPassword: string) {
    void actorUserId;

    const user = await this.prisma.user.findFirst({ where: { id: userId, accountId } });
    if (!user) throw new NotFoundException("User not found");

    const passwordHash = await bcrypt.hash(newPassword, 10);

    await this.prisma.$transaction(async (tx) => {
      await tx.user.update({
        where: { id: userId },
        data: { passwordHash },
      });

      await tx.passwordResetToken.deleteMany({ where: { accountId, userId } });
    });

    return { ok: true, id: user.id, email: user.email };
  }

  async remove(accountId: string, actorUserId: string, userId: string, reason?: string) {
    void reason;

    if (actorUserId === userId) {
      throw new BadRequestException("You cannot delete your own account while signed in");
    }

    const user = await this.prisma.user.findFirst({
      where: { id: userId, accountId },
      select: { id: true, email: true },
    });
    if (!user) throw new NotFoundException("User not found");

    try {
      await this.prisma.$transaction(async (tx) => {
        await tx.groupMember.deleteMany({ where: { userId } });
        await tx.userRole.deleteMany({ where: { userId } });
        await tx.passwordResetToken.deleteMany({ where: { userId } });
        await tx.userPreference.deleteMany({ where: { userId } });
        await tx.user.delete({ where: { id: userId } });
      });
    } catch (error: any) {
      const code = String(error?.code || "");
      if (code === "P2003" || code === "P2014") {
        throw new BadRequestException(
          "This user is linked to existing operational records and cannot be deleted safely. Disable the user instead."
        );
      }
      throw error;
    }

    return { ok: true, id: user.id, email: user.email };
  }

  async setRoles(accountId: string, userId: string, roleIds: string[]) {
    const user = await this.prisma.user.findFirst({ where: { id: userId, accountId } });
    if (!user) throw new NotFoundException("User not found");

    const roles = await this.prisma.role.findMany({
      where: { id: { in: roleIds }, accountId },
      select: { id: true },
    });
    if (roles.length !== roleIds.length) throw new BadRequestException("Invalid roleIds for this account");

    await this.prisma.userRole.deleteMany({ where: { userId } });
    if (roleIds.length) {
      await this.prisma.userRole.createMany({
        data: roleIds.map((roleId) => ({ userId, roleId })),
      });
    }

    return { ok: true };
  }


  async createSupportSession(accountId: string, actorUser: any, targetUserId: string, dto: { reason?: string; ticket?: string }) {
    const reason = String(dto?.reason || "").trim();
    const ticket = String(dto?.ticket || "").trim();
    if (!reason) throw new BadRequestException("Support reason is required");
    if (actorUser?.id === targetUserId) throw new BadRequestException("You are already signed in as this person");

    const target = await this.prisma.user.findFirst({
      where: { id: targetUserId, accountId, isActive: true },
      select: { id: true, accountId: true, email: true, displayName: true },
    });
    if (!target) throw new NotFoundException("User not found / inactive");

    const startedAt = new Date().toISOString();
    const accessToken = await this.jwt.signAsync(
      {
        sub: target.id,
        accountId: target.accountId,
        supportMode: true,
        impersonatedByUserId: actorUser?.id || null,
        impersonatedByEmail: actorUser?.email || null,
        supportReason: reason,
        supportTicket: ticket || undefined,
        supportStartedAt: startedAt,
      },
      { expiresIn: "60m" },
    );

    // Keep this lightweight and schema-safe. If a SupportSession table is added later,
    // this method can be extended without changing the FE contract.
    console.info("[support-view] started", {
      accountId,
      actorUserId: actorUser?.id || null,
      actorEmail: actorUser?.email || null,
      targetUserId: target.id,
      targetEmail: target.email,
      ticket: ticket || null,
      startedAt,
    });

    return {
      accessToken,
      expiresInMinutes: 60,
      targetUser: { id: target.id, email: target.email, displayName: target.displayName ?? null },
      supportView: {
        active: true,
        impersonatedByUserId: actorUser?.id || null,
        impersonatedByEmail: actorUser?.email || null,
        reason,
        ticket: ticket || null,
        startedAt,
      },
    };
  }

  async syncFromAccounts(accountId: string) {
    return syncMissingPeopleFromPartnerAccounts(this.prisma, accountId);
  }
}
