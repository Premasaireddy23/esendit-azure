import { BadRequestException, Body, Controller, Delete, Get, NotFoundException, Param, Post, Put, UseGuards } from "@nestjs/common";
import { PrismaService } from "../../common/prisma/prisma.service";
import { JwtAuthGuard } from "../../common/auth/jwt-auth.guard";
import { PermissionsGuard } from "../../common/auth/permissions.guard";
import { RequirePermissions } from "../../common/auth/require-permissions.decorator";
import { CurrentUser } from "../../common/auth/current-user.decorator";
import type { AuthUser } from "../../common/auth/current-user.decorator";

type AccessProfileTemplateDto = {
  id?: string | null;
  name?: string | null;
  description?: string | null;
  bestFor?: string | null;
  examples?: string[] | null;
  permissionKeys?: string[] | null;
};

type UiConfigDto = {
  creativeCodeLabel?: string | null;
  accessProfileTemplates?: AccessProfileTemplateDto[] | null;
  notificationAdminEmail?: string | null;
  notificationAdminOnlyMode?: boolean | null;
};

type DownloadPresetsDto = {
  downloadPresets?: any[] | null;
};

type PresetPipelineStep = {
  key?: string | null;
  label?: string | null;
  tool?: string | null;
  binary?: string | null;
  input?: string | null;
  output?: string | null;
  ext?: string | null;
  args: string[];
};

type PresetDef = {
  key: string;
  label?: string | null;
  tool?: string | null;
  ext: string;
  mimeType: string;
  args: string[];
  steps: PresetPipelineStep[];
};

type PresetUsageSummary = {
  destinationAllowedCount: number;
  destinationDefaultCount: number;
  channelDefaultCount: number;
  activeJobCount: number;
};

function validateDownloadPresets(p: any) {
  if (p === null || p === undefined) return;
  if (!Array.isArray(p)) throw new Error("downloadPresets must be an array");
  for (const [i, x] of p.entries()) {
    if (!x || typeof x !== "object") throw new Error(`downloadPresets[${i}] must be an object`);
    if (!x.key || typeof x.key !== "string") throw new Error(`downloadPresets[${i}].key missing/invalid`);
    if (!x.ext || typeof x.ext !== "string") throw new Error(`downloadPresets[${i}].ext missing/invalid`);
    if (!x.mimeType || typeof x.mimeType !== "string") throw new Error(`downloadPresets[${i}].mimeType missing/invalid`);
    if (x.tool !== undefined && x.tool !== null && typeof x.tool !== "string") throw new Error(`downloadPresets[${i}].tool must be a string`);
    if (x.args !== undefined && !Array.isArray(x.args)) throw new Error(`downloadPresets[${i}].args must be an array`);
    if (x.steps !== undefined && !Array.isArray(x.steps)) throw new Error(`downloadPresets[${i}].steps must be an array`);
    if (Array.isArray(x.steps)) {
      for (const [stepIndex, step] of x.steps.entries()) {
        if (!step || typeof step !== "object") throw new Error(`downloadPresets[${i}].steps[${stepIndex}] must be an object`);
        if (step.tool !== undefined && step.tool !== null && typeof step.tool !== "string") throw new Error(`downloadPresets[${i}].steps[${stepIndex}].tool must be a string`);
        if (step.args !== undefined && !Array.isArray(step.args)) throw new Error(`downloadPresets[${i}].steps[${stepIndex}].args must be an array`);
      }
    }
  }
}

function normalizeLabel(v: any) {
  const s = String(v ?? "").trim();
  if (!s) return null;
  const cleaned = s.replace(/\s+/g, " ").slice(0, 30);
  return cleaned || null;
}
function normalizeTemplateExamples(v: any): string[] {
  if (v == null) return [];
  const source = Array.isArray(v) ? v : String(v).split(",");
  return [...new Set(source
    .map((item) => String(item ?? "").trim())
    .filter(Boolean)
    .map((item) => item.replace(/\s+/g, " ").slice(0, 80))
    .filter(Boolean))].slice(0, 12);
}

function normalizeTemplatePermissionKeys(v: any): string[] {
  if (!Array.isArray(v)) return [];
  return [...new Set(v
    .map((item) => String(item ?? "").trim())
    .filter(Boolean)
    .map((item) => item.replace(/\s+/g, " ")))].sort((a, b) => a.localeCompare(b));
}

function normalizeAccessProfileTemplate(input: any, index: number) {
  if (!input || typeof input !== "object") throw new BadRequestException(`accessProfileTemplates[${index}] is invalid`);
  const name = String(input.name ?? "").trim().replace(/\s+/g, " ").slice(0, 120);
  if (!name) throw new BadRequestException(`accessProfileTemplates[${index}].name is required`);

  return {
    id: String(input.id ?? "").trim().slice(0, 120) || `template-${Date.now()}-${index + 1}`,
    name,
    description: normalizeOptionalText(input.description, 220),
    bestFor: normalizeOptionalText(input.bestFor, 180),
    examples: normalizeTemplateExamples(input.examples),
    permissionKeys: normalizeTemplatePermissionKeys(input.permissionKeys),
  };
}

function normalizeAccessProfileTemplates(v: any) {
  if (v == null) return [];
  if (!Array.isArray(v)) throw new BadRequestException("accessProfileTemplates must be an array");
  const seenIds = new Set<string>();
  const seenNames = new Set<string>();
  return v.map((item, index) => normalizeAccessProfileTemplate(item, index)).filter((item) => {
    const nameKey = item.name.toLowerCase();
    if (seenIds.has(item.id) || seenNames.has(nameKey)) return false;
    seenIds.add(item.id);
    seenNames.add(nameKey);
    return true;
  });
}

function cleanText(v: any, field: string, max = 200) {
  const s = String(v ?? "").trim();
  if (!s) throw new BadRequestException(`${field} is required`);
  return s.replace(/\s+/g, " ").slice(0, max);
}

function normalizeExt(v: any) {
  const clean = cleanText(v, "ext", 20).replace(/^\./, "").toLowerCase();
  if (!/^[a-z0-9]+$/i.test(clean)) throw new BadRequestException("ext must be letters/numbers only");
  return clean;
}

function normalizeMimeType(v: any) {
  const clean = cleanText(v, "mimeType", 120).toLowerCase();
  if (!clean.includes("/")) throw new BadRequestException("mimeType must look like type/subtype");
  return clean;
}

function normalizePresetKey(v: any) {
  const clean = cleanText(v, "key", 120);
  return clean;
}

function normalizeTool(v: any, fallback = "ffmpeg") {
  const clean = String(v ?? fallback).trim().toLowerCase();
  return clean === "ffmbc" ? "ffmbc" : "ffmpeg";
}

function normalizeOptionalText(v: any, max = 120) {
  const s = String(v ?? "").trim();
  if (!s) return null;
  return s.slice(0, max);
}

function normalizeEmailOrNull(v: any) {
  const s = String(v ?? "").trim().toLowerCase();
  if (!s) return null;
  const ok = /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s);
  if (!ok) throw new BadRequestException("notificationAdminEmail must be a valid email");
  return s;
}

function normalizeArgs(v: any): string[] {
  if (v == null) return [];
  if (!Array.isArray(v)) throw new BadRequestException("args must be an array");
  return v
    .map((x) => String(x ?? ""))
    .map((x) => x.trim())
    .filter((x) => x.length > 0);
}

function normalizePresetStep(input: any, index: number): PresetPipelineStep {
  if (!input || typeof input !== "object") throw new BadRequestException(`steps[${index}] is invalid`);
  return {
    key: normalizeOptionalText(input.key, 120) || `step${index + 1}`,
    label: normalizeOptionalText(input.label, 120),
    tool: normalizeTool(input.tool),
    binary: normalizeOptionalText(input.binary, 260),
    input: normalizeOptionalText(input.input, 120),
    output: normalizeOptionalText(input.output, 120),
    ext: normalizeOptionalText(input.ext, 20)?.replace(/^\./, "").toLowerCase() || null,
    args: normalizeArgs(input.args),
  };
}

function normalizePreset(input: any): PresetDef {
  if (!input || typeof input !== "object") throw new BadRequestException("Preset is invalid");
  const steps = Array.isArray(input.steps) ? input.steps.map((step, index) => normalizePresetStep(step, index)) : [];
  return {
    key: normalizePresetKey(input.key),
    label: String(input.label ?? "").trim() || null,
    tool: normalizeTool(input.tool),
    ext: normalizeExt(input.ext),
    mimeType: normalizeMimeType(input.mimeType),
    args: normalizeArgs(input.args),
    steps,
  };
}

function parsePresetLibrary(raw: any): PresetDef[] {
  if (!Array.isArray(raw)) return [];
  const out: PresetDef[] = [];
  const seen = new Set<string>();
  for (const item of raw) {
    if (!item || typeof item !== "object") continue;
    const key = String((item as any).key ?? "").trim();
    const ext = String((item as any).ext ?? "").trim();
    const mimeType = String((item as any).mimeType ?? "").trim();
    if (!key || !ext || !mimeType || seen.has(key)) continue;
    seen.add(key);
    out.push({
      key,
      label: String((item as any).label ?? "").trim() || null,
      tool: normalizeTool((item as any).tool),
      ext,
      mimeType,
      args: Array.isArray((item as any).args) ? (item as any).args.map((x: any) => String(x ?? "")).filter(Boolean) : [],
      steps: Array.isArray((item as any).steps) ? (item as any).steps.map((step: any, index: number) => normalizePresetStep(step, index)) : [],
    });
  }
  return out;
}

function clonePresetLibrary(list: PresetDef[]) {
  return list.map((item) => ({
    ...item,
    args: Array.isArray(item.args) ? [...item.args] : [],
    steps: Array.isArray(item.steps)
      ? item.steps.map((step) => ({
          ...step,
          args: Array.isArray(step.args) ? [...step.args] : [],
        }))
      : [],
  }));
}

function sortPresetLibrary(list: PresetDef[]) {
  return [...list].sort((a, b) => {
    const al = String(a.label || a.key).toLowerCase();
    const bl = String(b.label || b.key).toLowerCase();
    return al.localeCompare(bl) || a.key.localeCompare(b.key);
  });
}

@Controller("admin/account")
@UseGuards(JwtAuthGuard, PermissionsGuard)
export class AccountSettingsController {
  constructor(private prisma: PrismaService) {}

  private async readAccountPresetLibrary(accountId: string): Promise<PresetDef[]> {
    const acc = await this.prisma.account.findUnique({
      where: { id: accountId },
      select: { downloadPresets: true },
    });
    return parsePresetLibrary((acc as any)?.downloadPresets);
  }

  private async saveAccountPresetLibrary(accountId: string, presets: PresetDef[]) {
    validateDownloadPresets(presets);
    const updated = await this.prisma.account.update({
      where: { id: accountId },
      data: { downloadPresets: presets as any },
      select: { id: true, downloadPresets: true },
    });
    return parsePresetLibrary((updated as any)?.downloadPresets);
  }

  private async getPresetUsageSummary(accountId: string) {
    const [destinations, channels, activeJobs] = await Promise.all([
      this.prisma.destination.findMany({
        where: { accountId },
        select: { id: true, name: true, config: true },
      }),
      this.prisma.channel.findMany({
        where: { accountId },
        select: { id: true, name: true, config: true },
      }),
      (((this.prisma as any).presetDownloadJob && typeof (this.prisma as any).presetDownloadJob.findMany === "function")
        ? (this.prisma as any).presetDownloadJob.findMany({
            where: {
              accountId,
              status: { in: ["PENDING", "RUNNING", "PROCESSING"] },
            },
            select: { presetKey: true },
          }).catch(() => [])
        : Promise.resolve([])),
    ]);

    const usage = new Map<string, PresetUsageSummary>();
    const ensure = (key: string) => {
      const clean = String(key || "").trim();
      if (!clean) return null;
      if (!usage.has(clean)) {
        usage.set(clean, {
          destinationAllowedCount: 0,
          destinationDefaultCount: 0,
          channelDefaultCount: 0,
          activeJobCount: 0,
        });
      }
      return usage.get(clean)!;
    };

    for (const row of destinations as any[]) {
      const cfg = (row as any)?.config || {};
      const allowed = Array.isArray(cfg?.allowedPresetKeys) ? cfg.allowedPresetKeys : [];
      for (const key of allowed) {
        const item = ensure(String(key || ""));
        if (item) item.destinationAllowedCount += 1;
      }
      const defaultKey = String(cfg?.defaultPresetKey || "").trim();
      if (defaultKey) {
        const item = ensure(defaultKey);
        if (item) item.destinationDefaultCount += 1;
      }
    }

    for (const row of channels as any[]) {
      const cfg = (row as any)?.config || {};
      const defaultKey = String(cfg?.defaultPresetKey || "").trim();
      if (defaultKey) {
        const item = ensure(defaultKey);
        if (item) item.channelDefaultCount += 1;
      }
    }

    for (const row of (Array.isArray(activeJobs) ? activeJobs : []) as any[]) {
      const key = String((row as any)?.presetKey || "").trim();
      if (!key) continue;
      const item = ensure(key);
      if (item) item.activeJobCount += 1;
    }

    return usage;
  }

  @Get("ui-config")
  @RequirePermissions("ACCOUNT_SETTINGS_READ")
  async getUiConfig(@CurrentUser() user: AuthUser) {
    const acc = await this.prisma.account.findUnique({
      where: { id: user.accountId },
      select: { id: true, code: true, uiConfig: true },
    });

    return {
      account: acc ? { id: acc.id, code: acc.code } : null,
      uiConfig: (acc as any)?.uiConfig ?? {},
    };
  }

  @Put("ui-config")
  @RequirePermissions("ACCOUNT_SETTINGS_WRITE")
  async setUiConfig(@CurrentUser() user: AuthUser, @Body() dto: UiConfigDto) {
    const acc = await this.prisma.account.findUnique({
      where: { id: user.accountId },
      select: { id: true, uiConfig: true },
    });
    if (!acc) return { ok: false, error: "Account not found" };

    const next = { ...(((acc as any).uiConfig as any) ?? {}) } as any;
    const label = normalizeLabel(dto?.creativeCodeLabel);
    if (label) next.creativeCodeLabel = label;
    else delete next.creativeCodeLabel;

    if (dto && Object.prototype.hasOwnProperty.call(dto, "accessProfileTemplates")) {
      const templates = normalizeAccessProfileTemplates(dto?.accessProfileTemplates);
      if (templates.length) next.accessProfileTemplates = templates;
      else delete next.accessProfileTemplates;
    }

    if (dto && Object.prototype.hasOwnProperty.call(dto, "notificationAdminEmail")) {
      const adminEmail = normalizeEmailOrNull(dto?.notificationAdminEmail);
      if (adminEmail) next.notificationAdminEmail = adminEmail;
      else delete next.notificationAdminEmail;
    }

    if (dto && Object.prototype.hasOwnProperty.call(dto, "notificationAdminOnlyMode")) {
      if (dto?.notificationAdminOnlyMode === true) next.notificationAdminOnlyMode = true;
      else delete next.notificationAdminOnlyMode;
    }

    const updated = await this.prisma.account.update({
      where: { id: user.accountId },
      data: { uiConfig: next },
      select: { id: true, uiConfig: true },
    });

    return { ok: true, uiConfig: (updated as any).uiConfig ?? {} };
  }

  @Get("download-presets")
  @RequirePermissions("ACCOUNT_SETTINGS_READ")
  async getDownloadPresets(@CurrentUser() user: AuthUser) {
    const acc = await this.prisma.account.findUnique({
      where: { id: user.accountId },
      select: { id: true, code: true, downloadPresets: true },
    });

    return {
      account: acc ? { id: acc.id, code: acc.code } : null,
      downloadPresets: (acc as any)?.downloadPresets ?? [],
    };
  }

  @Put("download-presets")
  @RequirePermissions("ACCOUNT_SETTINGS_WRITE")
  async setDownloadPresets(@CurrentUser() user: AuthUser, @Body() dto: DownloadPresetsDto) {
    try {
      validateDownloadPresets(dto?.downloadPresets);
    } catch (e: any) {
      return { ok: false, error: String(e?.message || e || "Invalid downloadPresets") };
    }

    const updated = await this.prisma.account.update({
      where: { id: user.accountId },
      data: { downloadPresets: (dto?.downloadPresets ?? []) as any },
      select: { id: true, downloadPresets: true },
    });

    return { ok: true, downloadPresets: (updated as any)?.downloadPresets ?? [] };
  }

  @Get("preset-library")
  @RequirePermissions("ACCOUNT_SETTINGS_READ")
  async getPresetLibrary(@CurrentUser() user: AuthUser) {
    const [presets, usage] = await Promise.all([
      this.readAccountPresetLibrary(user.accountId),
      this.getPresetUsageSummary(user.accountId),
    ]);

    return {
      items: sortPresetLibrary(presets).map((preset) => {
        const counts = usage.get(preset.key) || {
          destinationAllowedCount: 0,
          destinationDefaultCount: 0,
          channelDefaultCount: 0,
          activeJobCount: 0,
        };
        const totalRefs =
          counts.destinationAllowedCount + counts.destinationDefaultCount + counts.channelDefaultCount + counts.activeJobCount;
        const deleteBlockedReason =
          totalRefs > 0
            ? "This preset is already used by destinations, channels, or active transcode jobs. Duplicate it instead of deleting."
            : null;
        return {
          ...preset,
          args: Array.isArray(preset.args) ? preset.args : [],
          usage: counts,
          inUse: totalRefs > 0,
          deleteBlockedReason,
        };
      }),
    };
  }

  @Post("preset-library")
  @RequirePermissions("ACCOUNT_SETTINGS_WRITE")
  async createPreset(@CurrentUser() user: AuthUser, @Body() dto: any) {
    const nextPreset = normalizePreset(dto);
    const current = await this.readAccountPresetLibrary(user.accountId);
    if (current.some((preset) => preset.key === nextPreset.key)) {
      throw new BadRequestException(`Preset key already exists: ${nextPreset.key}`);
    }

    const updated = await this.saveAccountPresetLibrary(user.accountId, sortPresetLibrary([...current, nextPreset]));
    return { ok: true, preset: updated.find((preset) => preset.key === nextPreset.key) || nextPreset };
  }

  @Put("preset-library/:key")
  @RequirePermissions("ACCOUNT_SETTINGS_WRITE")
  async updatePreset(@CurrentUser() user: AuthUser, @Param("key") key: string, @Body() dto: any) {
    const current = await this.readAccountPresetLibrary(user.accountId);
    const cleanKey = String(key || "").trim();
    const index = current.findIndex((preset) => preset.key === cleanKey);
    if (index < 0) throw new NotFoundException("Preset not found");

    const existing = current[index];
    const requestedKey = String(dto?.key ?? existing.key).trim();
    if (requestedKey !== existing.key) {
      throw new BadRequestException("Internal key cannot be changed here. Duplicate this preset with a new key instead.");
    }

    const nextPreset = normalizePreset({
      ...existing,
      ...dto,
      key: existing.key,
    });

    const next = clonePresetLibrary(current);
    next[index] = nextPreset;
    const updated = await this.saveAccountPresetLibrary(user.accountId, sortPresetLibrary(next));
    return { ok: true, preset: updated.find((preset) => preset.key === existing.key) || nextPreset };
  }

  @Post("preset-library/:key/duplicate")
  @RequirePermissions("ACCOUNT_SETTINGS_WRITE")
  async duplicatePreset(@CurrentUser() user: AuthUser, @Param("key") key: string, @Body() dto: any) {
    const current = await this.readAccountPresetLibrary(user.accountId);
    const source = current.find((preset) => preset.key === String(key || "").trim());
    if (!source) throw new NotFoundException("Preset not found");

    const nextKey = normalizePresetKey(dto?.key);
    if (current.some((preset) => preset.key === nextKey)) {
      throw new BadRequestException(`Preset key already exists: ${nextKey}`);
    }

    const duplicated = normalizePreset({
      ...source,
      ...dto,
      key: nextKey,
      label: String(dto?.label ?? `${source.label || source.key} Copy`).trim(),
    });

    const updated = await this.saveAccountPresetLibrary(user.accountId, sortPresetLibrary([...current, duplicated]));
    return { ok: true, preset: updated.find((preset) => preset.key === duplicated.key) || duplicated };
  }

  @Delete("preset-library/:key")
  @RequirePermissions("ACCOUNT_SETTINGS_WRITE")
  async deletePreset(@CurrentUser() user: AuthUser, @Param("key") key: string) {
    const current = await this.readAccountPresetLibrary(user.accountId);
    const cleanKey = String(key || "").trim();
    const existing = current.find((preset) => preset.key === cleanKey);
    if (!existing) throw new NotFoundException("Preset not found");

    const usage = await this.getPresetUsageSummary(user.accountId);
    const counts = usage.get(cleanKey);
    const totalRefs = counts
      ? counts.destinationAllowedCount + counts.destinationDefaultCount + counts.channelDefaultCount + counts.activeJobCount
      : 0;
    if (totalRefs > 0) {
      throw new BadRequestException(
        "This preset is in use by destinations, channels, or active transcode jobs. Remove those references first, or duplicate the preset and move traffic gradually.",
      );
    }

    const updated = await this.saveAccountPresetLibrary(
      user.accountId,
      current.filter((preset) => preset.key !== cleanKey),
    );
    return { ok: true, items: updated };
  }
}
