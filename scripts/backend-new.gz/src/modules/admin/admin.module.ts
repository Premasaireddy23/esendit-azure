import { Module } from "@nestjs/common";
import { JwtModule } from "@nestjs/jwt";
import { PrismaModule } from "../../common/prisma/prisma.module";
import { UsersController } from "./users.controller";
import { UsersService } from "./users.service";
import { RolesController } from "./roles.controller";
import { RolesService } from "./roles.service";
import { PermissionsController } from "./permissions.controller";
import { AccountSettingsController } from "./account-settings.controller";
import { GroupsController } from "./groups.controller";
import { GroupsService } from "./groups.service";

@Module({
  imports: [
    PrismaModule,
    JwtModule.register({
      secret: process.env.JWT_SECRET,
      signOptions: { expiresIn: "12h" },
    }),
  ],
  controllers: [UsersController, RolesController, PermissionsController, AccountSettingsController, GroupsController],
  providers: [UsersService, RolesService, GroupsService],
})
export class AdminModule {}
