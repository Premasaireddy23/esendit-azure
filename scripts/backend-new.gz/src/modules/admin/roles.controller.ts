import { Body, Controller, Get, Param, Post, Put, UseGuards } from "@nestjs/common";
import { CurrentUser } from "../../common/auth/current-user.decorator";
import { RequirePermissions } from "../../common/auth/require-permissions.decorator";
import { JwtAuthGuard } from "../../common/auth/jwt-auth.guard";
import { PermissionsGuard } from "../../common/auth/permissions.guard";
import { RolesService } from "./roles.service";
import { CreateRoleDto } from "./dto/create-role.dto";
import { SetRolePermissionsDto } from "./dto/set-role-permissions.dto";

@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller("admin/roles")
export class RolesController {
  constructor(private roles: RolesService) {}

  @Get()
  @RequirePermissions("ADMIN_ROLES_READ")
  list(@CurrentUser() user: any) {
    return this.roles.list(user.accountId);
  }

  @Post()
  @RequirePermissions("ADMIN_ROLES_WRITE")
  create(@CurrentUser() user: any, @Body() dto: CreateRoleDto) {
    return this.roles.create(user.accountId, dto.name, dto.description);
  }

  @Put(":id/permissions")
  @RequirePermissions("ADMIN_ROLES_WRITE")
  setPermissions(@CurrentUser() user: any, @Param("id") id: string, @Body() dto: SetRolePermissionsDto) {
    return this.roles.setPermissions(user.accountId, id, dto.permissionKeys);
  }
}
