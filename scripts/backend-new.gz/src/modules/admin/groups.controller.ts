import { Body, Controller, Get, Param, Post, Put, UseGuards } from "@nestjs/common";
import { CurrentUser } from "../../common/auth/current-user.decorator";
import { RequirePermissions } from "../../common/auth/require-permissions.decorator";
import { JwtAuthGuard } from "../../common/auth/jwt-auth.guard";
import { PermissionsGuard } from "../../common/auth/permissions.guard";
import { GroupsService } from "./groups.service";
import { CreateGroupDto } from "./dto/create-group.dto";
import { SetGroupMembersDto } from "./dto/set-group-members.dto";
import { SetGroupRolesDto } from "./dto/set-group-roles.dto";

@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller("admin/groups")
export class GroupsController {
  constructor(private groups: GroupsService) {}

  @Get()
  @RequirePermissions("ADMIN_GROUPS_READ")
  list(@CurrentUser() user: any) {
    return this.groups.list(user.accountId);
  }

  @Get("meta")
  @RequirePermissions("ADMIN_GROUPS_READ")
  meta(@CurrentUser() user: any) {
    return this.groups.meta(user.accountId);
  }

  @Get(":id")
  @RequirePermissions("ADMIN_GROUPS_READ")
  get(@CurrentUser() user: any, @Param("id") id: string) {
    return this.groups.get(user.accountId, id);
  }

  @Post()
  @RequirePermissions("ADMIN_GROUPS_WRITE")
  create(@CurrentUser() user: any, @Body() dto: CreateGroupDto) {
    return this.groups.create(user.accountId, { name: dto.name, description: dto.description });

  }

  @Put(":id/members")
  @RequirePermissions("ADMIN_GROUPS_WRITE")
  setMembers(@CurrentUser() user: any, @Param("id") id: string, @Body() dto: SetGroupMembersDto) {
    return this.groups.setMembers(user.accountId, id, dto.userIds);
  }

  @Put(":id/roles")
  @RequirePermissions("ADMIN_GROUPS_WRITE")
  setRoles(@CurrentUser() user: any, @Param("id") id: string, @Body() dto: SetGroupRolesDto) {
    return this.groups.setRoles(user.accountId, id, dto.roleIds);
  }
}
