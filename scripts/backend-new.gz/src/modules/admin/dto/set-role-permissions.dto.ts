import { IsArray } from "class-validator";

export class SetRolePermissionsDto {
  @IsArray()
  permissionKeys!: string[];
}
