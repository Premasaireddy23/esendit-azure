import { IsArray, IsUUID } from "class-validator";

export class SetGroupMembersDto {
  @IsArray()
  @IsUUID("4", { each: true })
  userIds!: string[];
}
