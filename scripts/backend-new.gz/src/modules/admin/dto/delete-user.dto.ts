import { IsOptional, IsString } from "class-validator";

export class DeleteUserDto {
  @IsOptional()
  @IsString()
  reason?: string;
}
