import { IsArray, IsUUID } from "class-validator";

export class SetGroupRolesDto {
  @IsArray()
  @IsUUID("4", { each: true })
  roleIds!: string[];
}
