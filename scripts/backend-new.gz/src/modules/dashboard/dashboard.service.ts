import { Injectable } from "@nestjs/common";
import { PrismaService } from "../../common/prisma/prisma.service";
import { ApprovalRequestStatus, DeliveryTaskStatus, ProjectStatus, MasterStatus } from "@prisma/client";

export type DashboardRange = "today" | "weekly" | "monthly" | "yearly";



export type DashboardQuickCount = {
  total: number;
  active: number | null;
};

export type DashboardQuickCounts = {
  destinations: DashboardQuickCount | null;
  channels: DashboardQuickCount | null;
  deliveryProfiles: DashboardQuickCount | null;
  accounts: DashboardQuickCount | null;
  people: DashboardQuickCount | null;
};

type Overview = {
  range: DashboardRange;
  totals: {
    projectsTotal: number;
    projectsOpen: number;
    activeDeliveries: number;
    deliveriesCompleted: number;
    deliveriesPending: number;
    approvalsPending: number;
  };
  series: {
    buckets: string[]; // ISO start of bucket (UTC)
    activeDeliveries: number[];
    deliveriesCompleted: number[];
    deliveriesPending: number[];
    approvalsPending: number[];
  };
};

@Injectable()
export class DashboardService {
  constructor(private prisma: PrismaService) {}

  async quickCounts(accountId: string, permissions: string[] = []): Promise<DashboardQuickCounts> {
    const perms = new Set((permissions || []).map((p) => String(p || "").trim()).filter(Boolean));
    const hasAny = (...keys: string[]) => keys.some((key) => perms.has(key));

    const canMastersRead = hasAny("action:masters:read", "MASTERS_READ");
    const canAccountsRead = hasAny("page:masters:accounts", "action:masters:read", "MASTERS_READ");
    const canPeopleRead = hasAny("action:admin:users:read", "ADMIN_USERS_READ");

    const [destinationsTotal, destinationsActive, channelsTotal, channelsActive, profilesTotal, profilesActive, accountsTotal, accountsActive, peopleTotal, peopleActive] = await Promise.all([
      canMastersRead ? this.prisma.destination.count({ where: { accountId } }) : 0,
      canMastersRead ? this.prisma.destination.count({ where: { accountId, status: { not: MasterStatus.INACTIVE } } }) : 0,
      canMastersRead ? this.prisma.channel.count({ where: { accountId } }) : 0,
      canMastersRead ? this.prisma.channel.count({ where: { accountId, status: { not: MasterStatus.INACTIVE } } }) : 0,
      canMastersRead ? this.prisma.deliveryProfile.count({ where: { accountId } }) : 0,
      canMastersRead ? this.prisma.deliveryProfile.count({ where: { accountId, status: { not: MasterStatus.INACTIVE } } }) : 0,
      canAccountsRead ? this.prisma.partnerAccount.count({ where: { accountId } }) : 0,
      canAccountsRead ? this.prisma.partnerAccount.count({ where: { accountId, status: { not: MasterStatus.INACTIVE } } }) : 0,
      canPeopleRead ? this.prisma.user.count({ where: { accountId } }) : 0,
      canPeopleRead ? this.prisma.user.count({ where: { accountId, isActive: true } }) : 0,
    ]);

    return {
      destinations: canMastersRead ? { total: destinationsTotal, active: destinationsActive } : null,
      channels: canMastersRead ? { total: channelsTotal, active: channelsActive } : null,
      deliveryProfiles: canMastersRead ? { total: profilesTotal, active: profilesActive } : null,
      accounts: canAccountsRead ? { total: accountsTotal, active: accountsActive } : null,
      people: canPeopleRead ? { total: peopleTotal, active: peopleActive } : null,
    };
  }

  async overview(accountId: string, range?: DashboardRange): Promise<Overview> {
    const r: DashboardRange = ["today", "weekly", "monthly", "yearly"].includes(range || "")
      ? (range as DashboardRange)
      : "weekly";

    const now = new Date();
    const { unit, buckets, start } = this.makeBucketsUTC(now, r);

    // ---- totals (all-time) ----
    const grouped = await this.prisma.deliveryTask.groupBy({
      by: ["status"],
      where: { accountId },
      _count: { _all: true },
    });

    const getCount = (s: DeliveryTaskStatus) =>
      grouped.find((g) => g.status === s)?._count._all ?? 0;

    const approvalsPending = await this.prisma.approvalRequest.count({
      where: {
        accountId,
        status: { in: [ApprovalRequestStatus.PENDING, ApprovalRequestStatus.IN_PROGRESS] },
      },
    });

    const projectsTotal = await this.prisma.project.count({ where: { accountId } });
    const projectsOpen = await this.prisma.project.count({
      where: { accountId, status: ProjectStatus.OPEN },
    });

    // ---- series (range-based) ----
    const bucketKey = (d: Date) => new Date(d).toISOString();
    const idx = new Map<string, number>();
    buckets.forEach((b, i) => idx.set(bucketKey(b), i));

    const activeArr = new Array(buckets.length).fill(0);
    const completedArr = new Array(buckets.length).fill(0);
    const pendingArr = new Array(buckets.length).fill(0);
    const approvalsArr = new Array(buckets.length).fill(0);

    const taskRows = await this.prisma.$queryRaw<
      Array<{ bucket: Date; status: string; count: number }>
    >`
      SELECT
        date_trunc(${unit}, "createdAt") AS bucket,
        "status"::text AS status,
        count(*)::int AS count
      FROM "DeliveryTask"
      WHERE "accountId" = ${accountId}
        AND "createdAt" >= ${start}
      GROUP BY 1, 2
      ORDER BY 1 ASC
    `;

    for (const row of taskRows) {
      const k = bucketKey(row.bucket);
      const i = idx.get(k);
      if (i === undefined) continue;

      if (row.status === "RUNNING") activeArr[i] += row.count;
      if (row.status === "SUCCESS") completedArr[i] += row.count;
      if (row.status === "QUEUED") pendingArr[i] += row.count;
    }

    const approvalRows = await this.prisma.$queryRaw<Array<{ bucket: Date; count: number }>>`
      SELECT
        date_trunc(${unit}, "createdAt") AS bucket,
        count(*)::int AS count
      FROM "ApprovalRequest"
      WHERE "accountId" = ${accountId}
        AND "createdAt" >= ${start}
        AND "status" IN ('PENDING','IN_PROGRESS')
      GROUP BY 1
      ORDER BY 1 ASC
    `;

    for (const row of approvalRows) {
      const k = bucketKey(row.bucket);
      const i = idx.get(k);
      if (i === undefined) continue;
      approvalsArr[i] += row.count;
    }

    return {
      range: r,
      totals: {
        projectsTotal,
        projectsOpen,
        activeDeliveries: getCount(DeliveryTaskStatus.RUNNING),
        deliveriesCompleted: getCount(DeliveryTaskStatus.SUCCESS),
        deliveriesPending: getCount(DeliveryTaskStatus.QUEUED),
        approvalsPending,
      },
      series: {
        buckets: buckets.map(bucketKey),
        activeDeliveries: activeArr,
        deliveriesCompleted: completedArr,
        deliveriesPending: pendingArr,
        approvalsPending: approvalsArr,
      },
    };
  }

  private makeBucketsUTC(now: Date, range: DashboardRange) {
    const y = now.getUTCFullYear();
    const m = now.getUTCMonth();
    const d = now.getUTCDate();
    const h = now.getUTCHours();

    if (range === "today") {
      const unit = "hour";
      const end = new Date(Date.UTC(y, m, d, h, 0, 0, 0));
      const buckets: Date[] = [];
      for (let i = 23; i >= 0; i--) buckets.push(new Date(end.getTime() - i * 3600_000));
      return { unit, buckets, start: buckets[0] };
    }

    if (range === "weekly") {
      const unit = "day";
      const end = new Date(Date.UTC(y, m, d, 0, 0, 0, 0));
      const buckets: Date[] = [];
      for (let i = 6; i >= 0; i--) buckets.push(new Date(end.getTime() - i * 86400_000));
      return { unit, buckets, start: buckets[0] };
    }

    if (range === "monthly") {
      const unit = "day";
      const end = new Date(Date.UTC(y, m, d, 0, 0, 0, 0));
      const buckets: Date[] = [];
      for (let i = 29; i >= 0; i--) buckets.push(new Date(end.getTime() - i * 86400_000));
      return { unit, buckets, start: buckets[0] };
    }

    // yearly
    const unit = "month";
    const buckets: Date[] = [];
    const endMonthStart = new Date(Date.UTC(y, m, 1, 0, 0, 0, 0));
    for (let i = 11; i >= 0; i--) {
      const dt = new Date(Date.UTC(endMonthStart.getUTCFullYear(), endMonthStart.getUTCMonth() - i, 1));
      buckets.push(dt);
    }
    return { unit, buckets, start: buckets[0] };
  }
}
