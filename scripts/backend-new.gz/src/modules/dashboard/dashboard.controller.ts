import { Controller, Get, Query, UseGuards } from "@nestjs/common";
import { JwtAuthGuard } from "../../common/auth/jwt-auth.guard";
import { PermissionsGuard } from "../../common/auth/permissions.guard";
import { CurrentUser, AuthUser } from "../../common/auth/current-user.decorator";
import { DashboardService, DashboardRange } from "./dashboard.service";
import { canonicalizePermissionKey } from "../../common/auth/permission.normalize";

@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller("dashboard")
export class DashboardController {
  constructor(private readonly svc: DashboardService) {}

  @Get("overview")
  overview(@CurrentUser() user: AuthUser, @Query("range") range?: DashboardRange) {
    return this.svc.overview(user.accountId, range);
  }

  @Get("quick-counts")
  quickCounts(@CurrentUser() user: AuthUser) {
    const permissions = Array.isArray(user?.permissions)
      ? user.permissions.map((p) => canonicalizePermissionKey(String(p || "")))
      : [];
    return this.svc.quickCounts(user.accountId, permissions);
  }
}
