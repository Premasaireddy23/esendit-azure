import { IsBoolean, IsEnum, IsOptional, IsUUID } from "class-validator";
import { ApprovalPhase } from "@prisma/client";

export class PatchApprovalsConfigDto {
  @IsOptional()
  @IsBoolean()
  approvalsEnabled?: boolean;

  @IsOptional()
  @IsEnum(ApprovalPhase)
  approvalsPhase?: ApprovalPhase;

  @IsOptional()
  @IsUUID()
  approvalTemplateId?: string | null;
}
