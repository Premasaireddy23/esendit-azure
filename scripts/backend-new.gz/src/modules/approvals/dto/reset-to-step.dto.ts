import { IsInt, Min } from "class-validator";

export class ResetToStepDto {
  @IsInt()
  @Min(1)
  stepOrder!: number;
}
