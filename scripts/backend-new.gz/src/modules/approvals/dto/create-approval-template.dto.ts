import { Type } from "class-transformer";
import { IsArray, IsEnum, IsNotEmpty, IsString, ValidateNested } from "class-validator";

export enum ApprovalTemplateModeDto {
  SEQUENTIAL = "SEQUENTIAL",
  PARALLEL = "PARALLEL",
}

export class ApprovalTemplateStepDto {
  @IsString() @IsNotEmpty() key!: string;
  @IsString() @IsNotEmpty() label!: string;
  order!: number;
  required?: boolean;
  @IsArray() approverEmails!: string[];
}

export class CreateApprovalTemplateDto {
  @IsString() @IsNotEmpty() name!: string;

  @IsEnum(ApprovalTemplateModeDto)
  mode!: ApprovalTemplateModeDto;

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => ApprovalTemplateStepDto)
  steps!: ApprovalTemplateStepDto[];
}
