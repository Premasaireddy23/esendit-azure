import { Body, Controller, Get, Param, Patch, Post, Req, UseGuards } from "@nestjs/common";
import { JwtAuthGuard } from "../../common/auth/jwt-auth.guard";
import { RequirePermissions } from "../../common/auth/require-permissions.decorator";
import { PermissionsGuard } from "../../common/auth/permissions.guard";
import { ApprovalsService } from "./approvals.service";
import { CreateApprovalTemplateDto } from "./dto/create-approval-template.dto";

@Controller("approval-templates")
@UseGuards(JwtAuthGuard)
export class ApprovalTemplatesController {
  constructor(private readonly approvals: ApprovalsService) {}

  @Get()
  @UseGuards(PermissionsGuard)
  @RequirePermissions("APPROVALS_TEMPLATES_MANAGE")
  async list(@Req() req: any) {
    return this.approvals.listTemplates(req.user.accountId);
  }

  @Post()
  @UseGuards(PermissionsGuard)
  @RequirePermissions("APPROVALS_TEMPLATES_MANAGE")
  async create(@Req() req: any, @Body() dto: CreateApprovalTemplateDto) {
    return this.approvals.createTemplate(req.user.accountId, req.user.id, dto);
  }

  @Patch(":id")
  @UseGuards(PermissionsGuard)
  @RequirePermissions("APPROVALS_TEMPLATES_MANAGE")
  async update(@Req() req: any, @Param("id") id: string, @Body() dto: Partial<CreateApprovalTemplateDto>) {
    return this.approvals.updateTemplate(req.user.accountId, req.user.id, id, dto);
  }

  @Post(":id/activate")
  @UseGuards(PermissionsGuard)
  @RequirePermissions("APPROVALS_TEMPLATES_MANAGE")
  async activate(@Req() req: any, @Param("id") id: string) {
    return this.approvals.activateTemplate(req.user.accountId, req.user.id, id);
  }
}
