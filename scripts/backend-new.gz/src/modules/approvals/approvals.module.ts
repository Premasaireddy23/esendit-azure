import { Module } from "@nestjs/common";
import { ApprovalsService } from "./approvals.service";
import { ApprovalsController } from "./approvals.controller";
import { ApprovalTemplatesController } from "./approval-templates.controller";
import { ServerStatusController } from "../server-status/server-status.controller";
import { ServerStatusService } from "../server-status/server-status.service";
// Adjust this import to your actual Prisma module/service setup.
// If you already have PrismaModule imported in AppModule globally, you can remove PrismaModule here.
import { PrismaModule } from "../../common/prisma/prisma.module";
import { ProjectAccessModule } from "../../common/project-access/project-access.module";

@Module({
  imports: [PrismaModule, ProjectAccessModule],
  controllers: [ApprovalsController, ApprovalTemplatesController, ServerStatusController],
  providers: [ApprovalsService, ServerStatusService],
  exports: [ApprovalsService],
})
export class ApprovalsModule {}
