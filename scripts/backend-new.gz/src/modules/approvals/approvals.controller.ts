import { Body, Controller, Get, Param, Patch, Post, Req, UseGuards } from "@nestjs/common";
import { JwtAuthGuard } from "../../common/auth/jwt-auth.guard";
import { RequirePermissions } from "../../common/auth/require-permissions.decorator";
import { RequireAnyPermissions } from "../../common/auth/require-any-permissions.decorator";
import { PermissionsGuard } from "../../common/auth/permissions.guard";
import { ApprovalsService } from "./approvals.service";
import { ApprovalActionDto } from "./dto/approval-action.dto";
import { PatchApprovalsConfigDto } from "./dto/patch-approvals-config.dto";
import { ResetToStepDto } from "./dto/reset-to-step.dto";

@Controller("projects/:projectId/approvals")
@UseGuards(JwtAuthGuard)
export class ApprovalsController {
  constructor(private readonly approvals: ApprovalsService) {}

  @Get("tracker")
  @UseGuards(PermissionsGuard)
  @RequirePermissions("APPROVAL_TRACKER_READ")
  async tracker(@Req() req: any, @Param("projectId") projectId: string) {
    return this.approvals.getTracker(req.user.accountId, projectId);
  }

  @Patch("config")
  @UseGuards(PermissionsGuard)
  @RequirePermissions("APPROVALS_CONFIG_WRITE")
  async patchConfig(@Req() req: any, @Param("projectId") projectId: string, @Body() dto: PatchApprovalsConfigDto) {
    return this.approvals.patchProjectApprovalsConfig(req.user.accountId, projectId, req.user, dto);
  }

  @Post("requests/:requestId/steps/:stepId/approve")
  @UseGuards(PermissionsGuard)
  @RequireAnyPermissions("approvals.decide", "approvals.decide.scoped", "page:projects")
  async approve(
    @Req() req: any,
    @Param("projectId") projectId: string,
    @Param("requestId") requestId: string,
    @Param("stepId") stepId: string,
    @Body() dto: ApprovalActionDto,
  ) {
    return this.approvals.approveStep(req.user.accountId, projectId, requestId, stepId, req.user, dto);
  }

  @Post("requests/:requestId/steps/:stepId/reject")
  @UseGuards(PermissionsGuard)
  @RequireAnyPermissions("approvals.decide", "approvals.decide.scoped", "page:projects")
  async reject(
    @Req() req: any,
    @Param("projectId") projectId: string,
    @Param("requestId") requestId: string,
    @Param("stepId") stepId: string,
    @Body() dto: ApprovalActionDto,
  ) {
    return this.approvals.rejectStep(req.user.accountId, projectId, requestId, stepId, req.user, dto);
  }

  @Post("requests/:requestId/reset")
  @UseGuards(PermissionsGuard)
  @RequirePermissions("approvals.reset")
  async reset(@Req() req: any, @Param("projectId") projectId: string, @Param("requestId") requestId: string) {
    return this.approvals.resetRequest(req.user.accountId, projectId, requestId, req.user);
  }

  @Post("requests/:requestId/reset-to-step")
  @UseGuards(PermissionsGuard)
  @RequirePermissions("approvals.reset")
  async resetToStep(
    @Req() req: any,
    @Param("projectId") projectId: string,
    @Param("requestId") requestId: string,
    @Body() dto: ResetToStepDto,
  ) {
    return this.approvals.resetRequestToStep(req.user.accountId, projectId, requestId, req.user, dto.stepOrder);
  }
}
