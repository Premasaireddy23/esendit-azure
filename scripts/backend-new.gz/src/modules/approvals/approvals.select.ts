import { Prisma } from "@prisma/client";

export const approvalTemplateSelect = Prisma.validator<Prisma.ApprovalTemplateSelect>()({
  id: true,
  accountId: true,
  name: true,
  mode: true,
  steps: true,
  isActive: true,
  createdAt: true,
  updatedAt: true,
});

export const approvalStepSelect = Prisma.validator<Prisma.ApprovalStepSelect>()({
  id: true,
  requestId: true,
  key: true,
  label: true,
  order: true,
  required: true,
  approverEmails: true,
  status: true,
  decidedAt: true,
  decidedByUserId: true,
  decidedByUser: { select: { id: true, displayName: true, email: true } },
  notes: true,
});

export const approvalRequestSelectForTracker = Prisma.validator<Prisma.ApprovalRequestSelect>()({
  id: true,
  accountId: true,
  projectId: true,
  creativeId: true,
  templateId: true,
  status: true,
  startedAt: true,
  completedAt: true,
  resetAt: true,
  templateSnapshot: true,
  template: { select: approvalTemplateSelect },
  steps: { select: approvalStepSelect, orderBy: { order: "asc" } },
});
