export type ApprovalStepDef = {
  key: string;
  label: string;
  order: number;
  required: boolean;
  approverEmails: string[];
};

function normEmail(v?: unknown) {
  return String(v ?? "").trim().toLowerCase();
}

/**
 * Normalizes ApprovalTemplate.steps (JSON) into a stable, ordered array.
 * - enforces sequential order numbers (1..N)
 * - trims strings
 * - lowercases approver emails
 */
export function normalizeApprovalSteps(raw: any): ApprovalStepDef[] {
  const arr = Array.isArray(raw) ? raw : [];

  const cleaned: ApprovalStepDef[] = arr
    .map((s: any, idx: number) => {
      const key = String(s?.key ?? "").trim();
      const label = String(s?.label ?? key ?? `Step ${idx + 1}`).trim();
      const order = Number.isFinite(Number(s?.order)) ? Number(s.order) : idx + 1;
      const required = s?.required === false ? false : true;
      const approverEmails = Array.isArray(s?.approverEmails)
        ? s.approverEmails.map((e: any) => normEmail(e)).filter(Boolean)
        : [];
      return { key, label, order, required, approverEmails };
    })
    .filter((s) => s.key && s.label);

  cleaned.sort((a, b) => a.order - b.order);
  return cleaned.map((s, i) => ({ ...s, order: i + 1 }));
}
