import { BadRequestException, ForbiddenException, Injectable, NotFoundException } from "@nestjs/common";
import {
  ApprovalActionType,
  ApprovalRequestStatus,
  ApprovalStepStatus,
  ApprovalTemplateMode,
  Prisma,
} from "@prisma/client";
import { PrismaService } from "../../common/prisma/prisma.service";
import { parseSlaTargetMinutes } from "../masters/sla-duration";
import { ServiceBusService } from "../../common/queue/service-bus.service";
import { NotificationsService } from "../notifications/notifications.service";
import { CreateApprovalTemplateDto } from "./dto/create-approval-template.dto";
import { ApprovalActionDto } from "./dto/approval-action.dto";
import { PatchApprovalsConfigDto } from "./dto/patch-approvals-config.dto";
import { approvalRequestSelectForTracker, approvalTemplateSelect } from "./approvals.select";
import { ensureCreativePresetJob, resolveChannelCommitPreset } from "../../common/presets/channel-default-preset";
import { ProjectAccessService } from "../../common/project-access/project-access.service";

type AuthedUser = {
  id?: string;
  accountId?: string;
  email?: string;
  permissions?: string[];
  roleNames?: string[];
};

type StepDef = {
  key: string;
  label: string;
  order: number;
  required: boolean;
  approverEmails: string[];
};

@Injectable()
export class ApprovalsService {
  constructor(
    private prisma: PrismaService,
    private readonly notifications: NotificationsService,
    private readonly bus: ServiceBusService,
    private readonly projectAccess: ProjectAccessService,
  ) {}

  // ----------------------------
  // Template helpers
  // ----------------------------
  private normEmail(v?: string | null) {
    return String(v ?? "").trim().toLowerCase();
  }

  private uniqEmails(list: Array<string | null | undefined>) {
    const out: string[] = [];
    for (const e of list) {
      const n = this.normEmail(e);
      if (n) out.push(n);
    }
    return Array.from(new Set(out));
  }

  private async getEffectiveTemplate(accountId: string, projectId: string) {
    const project = await this.prisma.project.findFirst({
      where: { id: projectId, accountId },
      select: { id: true, approvalsEnabled: true, approvalsPhase: true, approvalTemplateId: true },
    });
    if (!project) throw new NotFoundException("Project not found");

    const template =
      (project.approvalTemplateId
        ? await this.prisma.approvalTemplate.findFirst({
            where: { id: project.approvalTemplateId, accountId },
            select: approvalTemplateSelect,
          })
        : null) ??
      (await this.prisma.approvalTemplate.findFirst({
        where: { accountId, isActive: true },
        select: approvalTemplateSelect,
      }));

    return { project, template };
  }

  async ensureRequestsForCommittedCreatives(accountId: string, projectId: string, creativeIds: string[], phase?: string) {
    const uniqueCreativeIds = Array.from(new Set((creativeIds ?? []).map((id) => String(id)).filter(Boolean)));
    if (!uniqueCreativeIds.length) return [];

    const { project, template } = await this.getEffectiveTemplate(accountId, projectId);
    if (!project.approvalsEnabled || project.approvalsPhase === "POST") return [];
    if (!template) throw new BadRequestException("Approvals enabled but no template configured/active");

    const createdRequestIds = await this.ensureRequestsForCreatives(accountId, projectId, uniqueCreativeIds, template, phase ?? project.approvalsPhase ?? "PRE");
    for (const id of createdRequestIds) {
      await this.notifications.emitType9ReadyForApproval(accountId, id).catch(() => undefined);
    }
    return createdRequestIds;
  }

  private async holdCreativePlanLinesForApproval(accountId: string, projectId: string, creativeId: string) {
    const activePlan = await this.prisma.planVersion.findFirst({
      where: { accountId, projectId, isActive: true },
      select: { id: true },
    });
    if (!activePlan) return;

    await this.prisma.planLine.updateMany({
      where: {
        accountId,
        planVersionId: activePlan.id,
        creativeId,
        sentAt: null,
      },
      data: { autoSendAt: null },
    });
  }

  private async releaseApprovedCreativePlanLines(accountId: string, projectId: string, creativeId: string, approvedAt: Date, actorUserId?: string | null) {
    const activePlan = await this.prisma.planVersion.findFirst({
      where: { accountId, projectId, isActive: true },
      select: { id: true },
    });
    if (!activePlan) return { updatedLines: 0, transcodesQueued: 0 };

    const lines = await this.prisma.planLine.findMany({
      where: {
        accountId,
        planVersionId: activePlan.id,
        creativeId,
        sentAt: null,
      },
      select: {
        id: true,
        creativeId: true,
        slaId: true,
        channel: {
          select: { id: true, destinationId: true, config: true },
        },
      },
    });

    if (!lines.length) return { updatedLines: 0, transcodesQueued: 0 };

    const slaIds = Array.from(new Set(lines.map((l) => l.slaId).filter((id): id is string => typeof id === "string" && id.length > 0)));
    const slas = slaIds.length
      ? await this.prisma.sla.findMany({
          where: { accountId, id: { in: slaIds } },
          select: { id: true, hoursTarget: true, description: true },
        })
      : [];
    const slaTargetMinutes = new Map(slas.map((s) => [s.id, parseSlaTargetMinutes(s)] as const));
    const addMinutesUtc = (d: Date, minutes: number) => new Date(d.getTime() + minutes * 60 * 1000);

    for (const line of lines) {
      await this.prisma.planLine.update({
        where: { id: line.id },
        data: {
          autoSendAt: line.slaId && slaTargetMinutes.has(line.slaId)
            ? addMinutesUtc(approvedAt, slaTargetMinutes.get(line.slaId) as number)
            : approvedAt,
        },
      });
    }

    const presetRequests: Array<{ creativeId: string; destinationId: string | null; presetKey: string }> = [];
    const seen = new Set<string>();
    for (const line of lines) {
      const selectedPreset = await resolveChannelCommitPreset(this.prisma, accountId, (line as any).channel);
      if (!selectedPreset?.key) continue;
      const dedupe = `${creativeId}::${selectedPreset.key}`;
      if (seen.has(dedupe)) continue;
      seen.add(dedupe);
      presetRequests.push({
        creativeId,
        destinationId: selectedPreset.destinationId ?? null,
        presetKey: selectedPreset.key,
      });
    }

    for (const req of presetRequests) {
      await ensureCreativePresetJob(this.prisma, this.bus, {
        accountId,
        creativeId: req.creativeId,
        destinationId: req.destinationId,
        presetKey: req.presetKey,
        userId: actorUserId ?? null,
      }).catch(() => undefined);
    }

    return { updatedLines: lines.length, transcodesQueued: presetRequests.length };
  }

  /**
   * Admin = role name "Admin" (seed-permissions default) OR has any admin write permission.
   * This is intentionally tolerant so it works even if role naming changes.
   */
  private isAdmin(actor: AuthedUser) {
    const roles = (actor.roleNames ?? []).map((r) => String(r).trim().toLowerCase());
    if (roles.includes("admin")) return true;

    const perms = actor.permissions ?? [];
    return perms.includes("ADMIN_USERS_WRITE") || perms.includes("ADMIN_ROLES_WRITE");
  }

  /**
   * Returns the allowed approver email list for the project, based on the agency/team chosen in the wizard.
   *
   * IMPORTANT: We include **all** of these (if set):
   * - Media team + Media agency emails
   * - Creative team + Creative agency emails
   * - Production-house team + Production-house agency emails
   * - Post-house team + Post-house agency emails
   * - Audio team + Audio agency emails
   *
   * Reason: approvals may be done by any of the project-attached groups depending on the workflow.
   */
  private async getProjectTeamEmails(accountId: string, projectId: string): Promise<string[]> {
    const p = await this.prisma.project.findFirst({
      where: { id: projectId, accountId },
      select: {
        id: true,
        advertiserGroup: { select: { emails: true } },
        advertiser: { select: { emails: true } },
        brand: { select: { emails: true } },
        billableParty: { select: { emails: true } },

        mediaAgency: { select: { emails: true } },
        mediaAgencyTeam: { select: { emails: true } },

        creativeAgency: { select: { emails: true } },
        creativeAgencyTeam: { select: { emails: true } },

        productionHouse: { select: { emails: true } },
        productionHouseTeam: { select: { emails: true } },

        postHouse: { select: { emails: true } },
        postHouseTeam: { select: { emails: true } },

        audioAgency: { select: { emails: true } },
        audioAgencyTeam: { select: { emails: true } },
      },
    });
    if (!p) throw new NotFoundException("Project not found");

    const list: string[] = [];

    const push = (arr?: string[] | null) => {
      for (const e of arr ?? []) {
        const n = this.normEmail(e);
        if (n) list.push(n);
      }
    };

    // Teams
    push(p.mediaAgencyTeam?.emails);
    push(p.creativeAgencyTeam?.emails);
    push(p.productionHouseTeam?.emails);
    push(p.postHouseTeam?.emails);
    push(p.audioAgencyTeam?.emails);

    // Agencies (also include these even when teams exist)
    push(p.mediaAgency?.emails);
    push(p.creativeAgency?.emails);
    push(p.productionHouse?.emails);
    push(p.postHouse?.emails);
    push(p.audioAgency?.emails);

    // Account-selected masters (also valid approver pools)
    push(p.advertiserGroup?.emails);
    push(p.advertiser?.emails);
    push(p.brand?.emails);
    push(p.billableParty?.emails);

    return Array.from(new Set(list));
  }

  /**
   * Authorization rule requested:
   * - Admin can always decide
   * - Otherwise: user must belong to the project-selected team (or agency fallback)
   * - AND if step has approverEmails configured, user must be in that list too
   */
  private async assertCanDecideStep(accountId: string, projectId: string, actor: AuthedUser, stepApproverEmails: string[]) {
    if (this.isAdmin(actor)) return;

    const actorEmail = this.normEmail(actor.email);
    if (!actorEmail) throw new ForbiddenException("Approval decision requires a user email");

    const teamEmails = await this.getProjectTeamEmails(accountId, projectId);
    const stepEmails = this.uniqEmails(stepApproverEmails ?? []);

    // New additive stakeholder permission path:
    // if Admin grants action:stakeholder:<type>:approve and the user belongs to the
    // matching project stakeholder, allow the decision while still respecting an
    // explicit step approver list when the step defines one.
    const scopedAccess = await this.projectAccess.getProjectAccess(actor, projectId).catch(() => null);
    if (scopedAccess?.canApprove) {
      if (stepEmails.length && !stepEmails.includes(actorEmail)) {
        throw new ForbiddenException("You are not an approver for this step");
      }
      return;
    }

    // Hard guard: never allow "open approvals" for non-admin users.
    // If the project has no team/agency emails AND the step has no explicit approver list, block.
    if (!teamEmails.length && !stepEmails.length) {
      throw new ForbiddenException("Approvals are not configured for this project (no approver emails). Ask Admin to set agency/team emails or step approvers.");
    }

    if (teamEmails.length && !teamEmails.includes(actorEmail)) {
      throw new ForbiddenException("Only users from the project-attached agencies/teams (or Admin) can approve/reject");
    }

    if (stepEmails.length && !stepEmails.includes(actorEmail)) {
      throw new ForbiddenException("You are not an approver for this step");
    }
  }

  private normalizeSteps(raw: any): StepDef[] {
    const arr = Array.isArray(raw) ? raw : [];
    const cleaned: StepDef[] = arr
      .map((s: any, idx: number) => {
        const key = String(s?.key ?? "").trim();
        const label = String(s?.label ?? key ?? `Step ${idx + 1}`).trim();
        const order = Number.isFinite(Number(s?.order)) ? Number(s.order) : idx + 1;
        const required = s?.required === false ? false : true;
        const approverEmails = Array.isArray(s?.approverEmails)
          ? s.approverEmails.map((e: any) => String(e).trim()).filter(Boolean)
          : [];
        return { key, label, order, required, approverEmails };
      })
      .filter((s) => s.key && s.label);

    cleaned.sort((a, b) => a.order - b.order);
    // re-number orders sequentially (avoid duplicates)
    return cleaned.map((s, i) => ({ ...s, order: i + 1 }));
  }

  // ----------------------------
  // Templates
  // ----------------------------
  async listTemplates(accountId: string) {
    return this.prisma.approvalTemplate.findMany({
      where: { accountId },
      orderBy: { name: "asc" },
      select: approvalTemplateSelect,
    });
  }

  async createTemplate(accountId: string, userId: string | undefined, dto: CreateApprovalTemplateDto) {
    const steps = this.normalizeSteps((dto as any).steps);

    if (!dto?.name?.trim()) throw new BadRequestException("Template name is required");
    if (!steps.length) throw new BadRequestException("Template must have at least 1 step");

    return this.prisma.approvalTemplate.create({
      data: {
        accountId,
        name: dto.name.trim(),
        mode: (dto.mode as any) ?? "SEQUENTIAL",
        steps: steps as any,
        isActive: false,
        createdByUserId: userId ?? null,
      },
      select: approvalTemplateSelect,
    });
  }

  async updateTemplate(
    accountId: string,
    userId: string | undefined,
    id: string,
    dto: Partial<CreateApprovalTemplateDto>,
  ) {
    const existing = await this.prisma.approvalTemplate.findFirst({
      where: { id, accountId },
      select: { id: true },
    });
    if (!existing) throw new NotFoundException("ApprovalTemplate not found");

    const data: Prisma.ApprovalTemplateUpdateInput = {};

    if (dto.name !== undefined) {
      const name = String(dto.name ?? "").trim();
      if (!name) throw new BadRequestException("Template name cannot be empty");
      data.name = name;
    }

    if ((dto as any).mode !== undefined) {
      data.mode = (dto as any).mode;
    }

    if ((dto as any).steps !== undefined) {
      const steps = this.normalizeSteps((dto as any).steps);
      if (!steps.length) throw new BadRequestException("Template must have at least 1 step");
      data.steps = steps as any;
    }

    // (Optional) keep last editor in payload etc later; not needed now

    return this.prisma.approvalTemplate.update({
      where: { id },
      data,
      select: approvalTemplateSelect,
    });
  }

  async activateTemplate(accountId: string, userId: string | undefined, id: string) {
    const tpl = await this.prisma.approvalTemplate.findFirst({ where: { id, accountId }, select: { id: true } });
    if (!tpl) throw new NotFoundException("ApprovalTemplate not found");

    await this.prisma.$transaction([
      this.prisma.approvalTemplate.updateMany({ where: { accountId }, data: { isActive: false } }),
      this.prisma.approvalTemplate.update({ where: { id }, data: { isActive: true } }),
    ]);

    return { ok: true };
  }

  // ----------------------------
  // Project config
  // ----------------------------
  async patchProjectApprovalsConfig(accountId: string, projectId: string, actor: AuthedUser, dto: PatchApprovalsConfigDto) {
    const project = await this.prisma.project.findFirst({
      where: { id: projectId, accountId },
      select: { id: true, approvalTemplateId: true, approvalsEnabled: true,
        approvalsPhase: true },
    });
    if (!project) throw new NotFoundException("Project not found");

    let finalTemplateId: string | undefined;

    if (dto.approvalTemplateId !== undefined) {
      if (dto.approvalTemplateId === null) {
        finalTemplateId = undefined;
      } else {
        const t = await this.prisma.approvalTemplate.findFirst({
          where: { id: dto.approvalTemplateId, accountId },
          select: { id: true },
        });
        if (!t) throw new BadRequestException("Invalid approvalTemplateId");
        finalTemplateId = t.id;
      }
    }

    // If enabling approvals and no template configured, auto-pick active
    if (dto.approvalsEnabled === true) {
      const currentTid = finalTemplateId ?? project.approvalTemplateId;
      if (!currentTid) {
        const active = await this.prisma.approvalTemplate.findFirst({
          where: { accountId, isActive: true },
          select: { id: true },
        });
        if (!active) throw new BadRequestException("Approvals enabled but no active approval template exists");
        finalTemplateId = active.id;
      }
    }

    const updated = await this.prisma.project.update({
      where: { id: projectId },
      data: {
        ...(dto.approvalsEnabled !== undefined ? { approvalsEnabled: dto.approvalsEnabled } : {}),
        ...(dto.approvalsPhase !== undefined ? { approvalsPhase: dto.approvalsPhase } : {}),
        ...(finalTemplateId !== undefined ? { approvalTemplateId: finalTemplateId } : {}),
      },
      select: { id: true, approvalsEnabled: true,
        approvalsPhase: true, approvalTemplateId: true },
    });

    return { ok: true, project: updated };
  }

  // ----------------------------
  // Tracker (dynamic columns)
  // ----------------------------
  private async ensureRequestsForCreatives(
    accountId: string,
    projectId: string,
    creativeIds: string[],
    template: any,
    phase: any,
  ): Promise<string[]> {
    const createdRequestIds: string[] = [];
    if (!creativeIds.length) return createdRequestIds;

    const existing = await this.prisma.approvalRequest.findMany({
      where: { accountId, projectId, creativeId: { in: creativeIds } },
      select: { id: true, creativeId: true, templateId: true, phase: true },
    });
    const byCreative = new Map(existing.map((r) => [r.creativeId, r]));

    const templateSteps = this.normalizeSteps(template.steps);

    for (const creativeId of creativeIds) {
      const r = byCreative.get(creativeId);

      if (!r) {
        await this.prisma.$transaction(async (tx) => {
          const created = await tx.approvalRequest.create({
            data: {
              accountId,
              projectId,
              creativeId,
              templateId: template.id,
              phase: (phase ?? "PRE") as any,
              templateSnapshot: template.steps as any,
              status: "PENDING",
              steps: {
                createMany: {
                  data: templateSteps.map((s) => ({
                    key: s.key,
                    label: s.label,
                    order: s.order,
                    required: s.required,
                    approverEmails: s.approverEmails,
                    status: "PENDING",
                  })),
                },
              },
            },
            select: { id: true },
          });

          createdRequestIds.push(created.id);

          await tx.creative.update({
            where: { id: creativeId },
            data: { approvals: "PENDING" as any },
          });

          await tx.approvalAction.create({
            data: {
              accountId,
              requestId: created.id,
              stepId: null,
              action: "COMMENT" as any,
              actorUserId: null,
              payload: { message: "Approval request created" } as any,
            },
          });
        });
      } else if (r.phase !== (phase ?? "PRE")) {
        await this.prisma.approvalRequest.update({ where: { id: r.id }, data: { phase: phase ?? "PRE" } });
      } else if (r.templateId !== template.id) {
        // Template changed → reset to current template so tracker columns remain consistent
        await this.prisma.$transaction(async (tx) => {
          await tx.approvalStep.deleteMany({ where: { requestId: r.id } });

          await tx.approvalRequest.update({
            where: { id: r.id },
            data: {
              templateId: template.id,
              phase: (phase ?? "PRE") as any,
              templateSnapshot: template.steps as any,
              status: "PENDING",
              startedAt: null,
              completedAt: null,
              resetAt: new Date(),
              steps: {
                createMany: {
                  data: templateSteps.map((s) => ({
                    key: s.key,
                    label: s.label,
                    order: s.order,
                    required: s.required,
                    approverEmails: s.approverEmails,
                    status: "PENDING",
                  })),
                },
              },
            },
          });

          await tx.creative.update({
            where: { id: creativeId },
            data: { approvals: "PENDING" as any },
          });

          await tx.approvalAction.create({
            data: {
              accountId,
              requestId: r.id,
              stepId: null,
              action: "RESET" as any,
              actorUserId: null,
              payload: { reason: "Template changed, auto-reset" } as any,
            },
          });
        });
      }
    }

    return createdRequestIds;
  }

  async getTracker(accountId: string, projectId: string) {
    const project = await this.prisma.project.findFirst({
      where: { id: projectId, accountId },
      select: {
        id: true,
        approvalsEnabled: true,
        approvalsPhase: true,
        approvalTemplateId: true,
        projectNumber: true,
        name: true,
        advertiserGroup: { select: { id: true, name: true } },
        advertiser: { select: { id: true, name: true } },
        brand: { select: { id: true, name: true } },
        productCategory: { select: { id: true, name: true } },
        billableParty: { select: { id: true, name: true } },
        mediaAgency: { select: { id: true, name: true } },
        mediaAgencyTeam: { select: { id: true, name: true } },
        creativeAgency: { select: { id: true, name: true } },
        creativeAgencyTeam: { select: { id: true, name: true } },
        productionHouse: { select: { id: true, name: true } },
        productionHouseTeam: { select: { id: true, name: true } },
        postHouse: { select: { id: true, name: true } },
        postHouseTeam: { select: { id: true, name: true } },
        audioAgency: { select: { id: true, name: true } },
        audioAgencyTeam: { select: { id: true, name: true } },
      },
    });
    if (!project) throw new NotFoundException("Project not found");

    const creativesRaw = await this.prisma.creative.findMany({
      where: { projectId, accountId },
      orderBy: { updatedAt: "desc" },
      select: {
        id: true,
        name: true,
        valid: true,
        caption: true,
        format: true,
        audio: true,
        languages: true,
        duration: true,
        qcStatus: true,
        qcNotes: true,
        qcFailureReasons: true,
        qcReport: true,
        autoQcStartedAt: true,
        autoQcEndedAt: true,
        approvals: true,
        createdAt: true,
        updatedAt: true,
        assets: {
          where: { type: "SOURCE" },
          orderBy: { updatedAt: "desc" },
          take: 1,
          select: {
            id: true,
            filename: true,
            mimeType: true,
            sizeBytes: true,
            uploadedByUserId: true,
            uploadedByUser: { select: { id: true, email: true, displayName: true } },
            uploadEndedAt: true,
          },
        },
      },
    });

    const creatives = creativesRaw.map((c: any) => {
      const source = Array.isArray(c.assets) ? c.assets[0] : null;
      return {
        ...c,
        sourceFilename: source?.filename ?? null,
        sourceMimeType: source?.mimeType ?? null,
        sourceSizeBytes: source?.sizeBytes ?? null,
        uploadedByUser: source?.uploadedByUser ?? null,
        // Keep for safety: some UIs refer to these keys
        uploader: source?.uploadedByUser ?? null,
        filename: source?.filename ?? null,
      };
    });

    if (!project.approvalsEnabled) {
      return {
        enabled: false,
        projectId,
        project,
        phase: project.approvalsPhase ?? "PRE",
        template: null,
        templateSteps: [],
        rows: creatives.map((c: any) => ({ creative: c, request: null })),
      };
    }

    const template =
      (project.approvalTemplateId
        ? await this.prisma.approvalTemplate.findFirst({
            where: { id: project.approvalTemplateId, accountId },
            select: approvalTemplateSelect,
          })
        : null) ??
      (await this.prisma.approvalTemplate.findFirst({
        where: { accountId, isActive: true },
        select: approvalTemplateSelect,
      }));

    if (!template) throw new BadRequestException("Approvals enabled but no template configured/active");

    const creativeIds = creatives.map((c: any) => c.id);
    const createdRequestIds = await this.ensureRequestsForCreatives(accountId, projectId, creativeIds, template, project.approvalsPhase ?? "PRE");
    for (const id of createdRequestIds) {
      await this.notifications.emitType9ReadyForApproval(accountId, id).catch(() => undefined);
    }

    const requests = await this.prisma.approvalRequest.findMany({
      where: { accountId, projectId, creativeId: { in: creativeIds } },
      select: approvalRequestSelectForTracker,
    });

    const byCreative = new Map(requests.map((r) => [r.creativeId, r]));
    const templateSteps = this.normalizeSteps(template.steps);

    return {
      enabled: true,
      projectId,
      project,
      phase: project.approvalsPhase ?? "PRE",
      template,
      templateSteps,
      rows: creatives.map((c: any) => ({ creative: c, request: byCreative.get(c.id) ?? null })),
    };
  }

  // ----------------------------
  // Email outbox
  // ----------------------------
  private async enqueueEmail(tx: PrismaService, args: {
    accountId: string;
    projectId?: string;
    creativeId?: string;
    eventType: string;
    to: string[];
    subject: string;
    bodyText?: string;
    payload?: any;
  }) {
    const to = Array.from(new Set((args.to ?? []).map((e) => String(e).trim()).filter(Boolean)));
    if (!to.length) return;

    await tx.emailOutbox.create({
      data: {
        accountId: args.accountId,
        projectId: args.projectId ?? null,
        creativeId: args.creativeId ?? null,
        eventType: args.eventType,
        to,
        subject: args.subject,
        bodyText: args.bodyText ?? null,
        payload: (args.payload ?? {}) as any,
        status: "PENDING",
      },
    });
  }

  // ----------------------------
  // Actions
  // ----------------------------
  async approveStep(
    accountId: string,
    projectId: string,
    requestId: string,
    stepId: string,
    actor: AuthedUser,
    dto: ApprovalActionDto,
  ) {
    return this.actOnStep(accountId, projectId, requestId, stepId, actor, "APPROVE", dto);
  }

  async rejectStep(
    accountId: string,
    projectId: string,
    requestId: string,
    stepId: string,
    actor: AuthedUser,
    dto: ApprovalActionDto,
  ) {
    return this.actOnStep(accountId, projectId, requestId, stepId, actor, "REJECT", dto);
  }

  private async actOnStep(
    accountId: string,
    projectId: string,
    requestId: string,
    stepId: string,
    actor: AuthedUser,
    action: "APPROVE" | "REJECT",
    dto: ApprovalActionDto,
  ) {
    const request = await this.prisma.approvalRequest.findFirst({
      where: { id: requestId, accountId, projectId },
      select: {
        id: true,
        creativeId: true,
        status: true,
        template: { select: { mode: true } },
        steps: { select: { id: true, order: true, required: true, approverEmails: true, status: true }, orderBy: { order: "asc" } },
      },
    });
    if (!request) throw new NotFoundException("ApprovalRequest not found");

    const step = request.steps.find((s) => s.id === stepId);
    if (!step) throw new NotFoundException("ApprovalStep not found");
    if (step.status !== "PENDING") throw new BadRequestException("Step is not PENDING");

    // ✅ Enforce: only project-assigned team members (or Admin) can decide
    await this.assertCanDecideStep(accountId, projectId, actor, (step.approverEmails ?? []) as any);

    const mode = (request.template?.mode ?? "SEQUENTIAL") as ApprovalTemplateMode;

    // Sequential enforcement: only earliest pending required step is actionable
    if (mode === "SEQUENTIAL") {
      const pendingRequired = request.steps.filter((s) => s.required && s.status === "PENDING").sort((a, b) => a.order - b.order);
      if (pendingRequired.length && pendingRequired[0].id !== stepId) {
        throw new BadRequestException("Only the next pending required step can be decided in SEQUENTIAL mode");
      }
    }

    const now = new Date();
    const decidedStatus: ApprovalStepStatus = action === "APPROVE" ? "APPROVED" : "REJECTED";

    const result = await this.prisma.$transaction(async (tx) => {
      await tx.approvalStep.update({
        where: { id: stepId },
        data: {
          status: decidedStatus,
          decidedAt: now,
          decidedByUserId: actor.id ?? null,
          notes: (dto as any)?.notes ?? null,
        },
      });

      await tx.approvalAction.create({
        data: {
          accountId,
          requestId,
          stepId,
          action: action as any,
          actorUserId: actor.id ?? null,
          payload: { notes: (dto as any)?.notes ?? null } as any,
        },
      });

      // Recompute request status
      const steps = await tx.approvalStep.findMany({
        where: { requestId },
        orderBy: { order: "asc" },
        select: { status: true, required: true, approverEmails: true, key: true, label: true, order: true },
      });

      const required = steps.filter((s) => s.required);
      const anyRejected = required.some((s) => s.status === "REJECTED");
      const allApproved = required.length > 0 && required.every((s) => s.status === "APPROVED");
      const anyDecided = required.some((s) => s.status !== "PENDING");

      let newStatus: ApprovalRequestStatus = "PENDING";
      if (anyRejected) newStatus = "REJECTED";
      else if (allApproved) newStatus = "APPROVED";
      else if (anyDecided) newStatus = "IN_PROGRESS";

      await tx.approvalRequest.update({
        where: { id: requestId },
        data: {
          status: newStatus,
          startedAt: anyDecided ? now : null,
          completedAt: newStatus === "APPROVED" || newStatus === "REJECTED" ? now : null,
        },
      });

      // Update Creative approval summary
      const creativeApprovals =
        newStatus === "APPROVED" ? ("APPROVED" as any) : newStatus === "REJECTED" ? ("REJECTED" as any) : ("PENDING" as any);

      await tx.creative.update({
        where: { id: request.creativeId },
        data: { approvals: creativeApprovals },
      });

      // Email per action (outbox)
      const stepEmails = (step.approverEmails ?? []).map((e) => String(e).trim()).filter(Boolean);

      // next-step emails for sequential approvals
      let nextStepEmails: string[] = [];
      if (action === "APPROVE" && mode === "SEQUENTIAL" && step.required) {
        const nextPendingRequired = steps
          .filter((s) => s.required && s.status === "PENDING")
          .sort((a, b) => a.order - b.order)[0];
        if (nextPendingRequired) nextStepEmails = (nextPendingRequired.approverEmails ?? []) as any;
      }

      // Customer-friendly email labels (IDs are not useful for most recipients)
      let projectLabel = projectId;
      let creativeLabel = request.creativeId;
      let creativeTitle: string | null = null;
      try {
        const [proj, cr] = await Promise.all([
          (tx as any).project.findFirst({ where: { accountId, id: projectId }, select: { name: true, projectCode: true } }),
          (tx as any).creative.findFirst({ where: { accountId, id: request.creativeId }, select: { valid: true, title: true, name: true } }),
        ]);
        if (proj?.name) projectLabel = proj.projectCode ? `${proj.name} (${proj.projectCode})` : proj.name;
        if (cr?.valid) creativeLabel = cr.valid;
        creativeTitle = cr?.title ?? cr?.name ?? null;
      } catch {
        // best-effort only
      }

      const actionText = action === "APPROVE" ? "approved" : "rejected";
      const actorLabel = actor.email ?? actor.id ?? "unknown";

      await this.enqueueEmail(tx as any, {
        accountId,
        projectId,
        creativeId: request.creativeId,
        eventType: `approvals.${action.toLowerCase()}`,
        to: Array.from(new Set([...stepEmails, ...nextStepEmails])),
        subject: `[eSendIT] Approval ${actionText} — ${projectLabel} — ${creativeLabel}`,
        bodyText: [
          `Approval ${actionText}.`,
          "",
          `Project: ${projectLabel}`,
          `Creative: ${creativeLabel}${creativeTitle ? ` — ${creativeTitle}` : ""}`,
          `Step: ${step.order} (${stepId})`,
          `By: ${actorLabel}`,
          "",
          "Details:",
          JSON.stringify({ requestId, stepId, status: newStatus }, null, 2),
        ].join("\n"),
        payload: { requestId, stepId, status: newStatus, projectLabel, creativeLabel },
      });

      return { ok: true, requestId, status: newStatus };
    });

    if (result.status === "APPROVED") {
      await this.releaseApprovedCreativePlanLines(accountId, projectId, request.creativeId, now, actor.id ?? null).catch(() => undefined);
      await this.notifications.emitType10Approved(accountId, requestId).catch(() => undefined);
    } else {
      await this.holdCreativePlanLinesForApproval(accountId, projectId, request.creativeId).catch(() => undefined);
      // ✅ Step-aware Type 9 (SEQUENTIAL): when a step is approved and the next required step becomes actionable,
      // send a new Ready-for-Approval notification for that next step.
      if (action === "APPROVE" && mode === "SEQUENTIAL" && step.required) {
        await this.notifications.emitType9ReadyForApproval(accountId, requestId).catch(() => undefined);
      }
    }

    return result;
  }

  async resetRequest(accountId: string, projectId: string, requestId: string, actor: AuthedUser) {
    // ✅ Requested: only Admin can reset approvals
    if (!this.isAdmin(actor)) {
      throw new ForbiddenException("Only Admin can reset approvals");
    }

    const req = await this.prisma.approvalRequest.findFirst({
      where: { id: requestId, accountId, projectId },
      select: { id: true, creativeId: true, steps: { select: { id: true, order: true, approverEmails: true }, orderBy: { order: "asc" } } },
    });
    if (!req) throw new NotFoundException("ApprovalRequest not found");

    const now = new Date();
    const firstStepEmails = (req.steps[0]?.approverEmails ?? []).map((e) => String(e).trim()).filter(Boolean);

    await this.prisma.$transaction(async (tx) => {
      await tx.approvalStep.updateMany({
        where: { requestId },
        data: {
          status: "PENDING",
          decidedAt: null,
          decidedByUserId: null,
          notes: null,
        },
      });

      await tx.approvalRequest.update({
        where: { id: requestId },
        data: {
          status: "PENDING",
          startedAt: null,
          completedAt: null,
          resetAt: now,
        },
      });

      await tx.creative.update({
        where: { id: req.creativeId },
        data: { approvals: "PENDING" as any },
      });

      await tx.approvalAction.create({
        data: {
          accountId,
          requestId,
          stepId: null,
          action: ApprovalActionType.RESET,
          actorUserId: actor.id ?? null,
          payload: { reason: "Manual reset" } as any,
        },
      });

      // Customer-friendly email labels
      let projectLabel = projectId;
      let creativeLabel = req.creativeId;
      let creativeTitle: string | null = null;
      try {
        const [proj, cr] = await Promise.all([
          (tx as any).project.findFirst({ where: { accountId, id: projectId }, select: { name: true, projectCode: true } }),
          (tx as any).creative.findFirst({ where: { accountId, id: req.creativeId }, select: { valid: true, title: true, name: true } }),
        ]);
        if (proj?.name) projectLabel = proj.projectCode ? `${proj.name} (${proj.projectCode})` : proj.name;
        if (cr?.valid) creativeLabel = cr.valid;
        creativeTitle = cr?.title ?? cr?.name ?? null;
      } catch {
        // best-effort
      }

      const actorLabel = actor.email ?? actor.id ?? "unknown";

      await this.enqueueEmail(tx as any, {
        accountId,
        projectId,
        creativeId: req.creativeId,
        eventType: "approvals.reset",
        to: firstStepEmails,
        subject: `[eSendIT] Approval reset — ${projectLabel} — ${creativeLabel}`,
        bodyText: [
          "Approval request reset.",
          "",
          `Project: ${projectLabel}`,
          `Creative: ${creativeLabel}${creativeTitle ? ` — ${creativeTitle}` : ""}`,
          `By: ${actorLabel}`,
          "",
          "Details:",
          JSON.stringify({ requestId }, null, 2),
        ].join("\n"),
        payload: { requestId, projectLabel, creativeLabel },
      });
    });

    await this.holdCreativePlanLinesForApproval(accountId, projectId, req.creativeId).catch(() => undefined);
    await this.notifications.emitType9ReadyForApproval(accountId, requestId).catch(() => undefined);

    return { ok: true };
  }

  async resetRequestToStep(accountId: string, projectId: string, requestId: string, actor: AuthedUser, stepOrder: number) {
    if (!this.isAdmin(actor)) {
      throw new ForbiddenException("Only Admin can reset approvals");
    }

    const req = await this.prisma.approvalRequest.findFirst({
      where: { id: requestId, accountId, projectId },
      select: {
        id: true,
        creativeId: true,
        status: true,
        steps: { select: { id: true, order: true, approverEmails: true }, orderBy: { order: "asc" } },
      },
    });
    if (!req) throw new NotFoundException("ApprovalRequest not found");

    const steps = req.steps ?? [];
    if (!steps.length) throw new BadRequestException("No steps configured for this request");

    const target = steps.find((s) => s.order === stepOrder);
    if (!target) throw new BadRequestException(`Invalid stepOrder ${stepOrder}. Must match an existing step order.`);

    const now = new Date();
    const targetEmails = (target.approverEmails ?? []).map((e) => String(e).trim()).filter(Boolean);

    await this.prisma.$transaction(async (tx) => {
      // 1) Reset all steps to PENDING
      await tx.approvalStep.updateMany({
        where: { requestId },
        data: {
          status: "PENDING",
          decidedAt: null,
          decidedByUserId: null,
          notes: null,
        },
      });

      // 2) Mark earlier steps as APPROVED (admin override)
      const earlier = steps.filter((s) => s.order < stepOrder);
      for (const s of earlier) {
        await tx.approvalStep.update({
          where: { id: s.id },
          data: {
            status: "APPROVED",
            decidedAt: now,
            decidedByUserId: actor.id ?? null,
            notes: `Admin reset: auto-approved to move flow to step ${stepOrder}`,
          },
        });
      }

      // 3) Update request
      await tx.approvalRequest.update({
        where: { id: requestId },
        data: {
          status: "IN_PROGRESS",
          startedAt: now,
          completedAt: null,
          resetAt: now,
        },
      });

      // 4) Update creative
      await tx.creative.update({
        where: { id: req.creativeId },
        data: { approvals: "PENDING" as any },
      });

      // 5) Audit
      await tx.approvalAction.create({
        data: {
          accountId,
          requestId,
          stepId: null,
          action: ApprovalActionType.RESET,
          actorUserId: actor.id ?? null,
          payload: { reason: "Manual reset-to-step", stepOrder } as any,
        },
      });

      // 6) Notify target step approvers
      // Customer-friendly email labels
      let projectLabel = projectId;
      let creativeLabel = req.creativeId;
      let creativeTitle: string | null = null;
      try {
        const [proj, cr] = await Promise.all([
          (tx as any).project.findFirst({ where: { accountId, id: projectId }, select: { name: true, projectCode: true } }),
          (tx as any).creative.findFirst({ where: { accountId, id: req.creativeId }, select: { valid: true, title: true, name: true } }),
        ]);
        if (proj?.name) projectLabel = proj.projectCode ? `${proj.name} (${proj.projectCode})` : proj.name;
        if (cr?.valid) creativeLabel = cr.valid;
        creativeTitle = cr?.title ?? cr?.name ?? null;
      } catch {
        // best-effort
      }

      const actorLabel = actor.email ?? actor.id ?? "unknown";

      await this.enqueueEmail(tx as any, {
        accountId,
        projectId,
        creativeId: req.creativeId,
        eventType: "approvals.reset",
        to: targetEmails,
        subject: `[eSendIT] Approval reset to step ${stepOrder} — ${projectLabel} — ${creativeLabel}`,
        bodyText: [
          `Approval request reset to step ${stepOrder}.`,
          "",
          `Project: ${projectLabel}`,
          `Creative: ${creativeLabel}${creativeTitle ? ` — ${creativeTitle}` : ""}`,
          `By: ${actorLabel}`,
          "",
          "Details:",
          JSON.stringify({ requestId, stepOrder }, null, 2),
        ].join("\n"),
        payload: { requestId, stepOrder, projectLabel, creativeLabel },
      });
    });

    await this.holdCreativePlanLinesForApproval(accountId, projectId, req.creativeId).catch(() => undefined);
    await this.notifications.emitType9ReadyForApproval(accountId, requestId).catch(() => undefined);

    return { ok: true };
  }
}
