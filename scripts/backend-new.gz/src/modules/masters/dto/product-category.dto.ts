import { IsEnum, IsOptional, IsString, MinLength } from "class-validator";
import { MasterStatus } from "@prisma/client";

export class CreateProductCategoryDto {
  @IsString()
  @MinLength(2)
  name!: string;

  @IsOptional()
  @IsEnum(MasterStatus)
  status?: MasterStatus;
}

export class UpdateProductCategoryDto {
  @IsOptional()
  @IsString()
  @MinLength(2)
  name?: string;

  @IsOptional()
  @IsEnum(MasterStatus)
  status?: MasterStatus;
}
