import { IsBoolean, IsEnum, IsInt, IsOptional, IsString, Min, MinLength } from "class-validator";
import { HotFolderSourceType, MasterStatus } from "@prisma/client";

export class CreateHotFolderDto {
  @IsString()
  @MinLength(2)
  name!: string;

  @IsEnum(HotFolderSourceType)
  sourceType!: HotFolderSourceType;

  @IsString()
  @MinLength(1)
  basePath!: string;

  @IsOptional()
  @IsInt()
  @Min(5)
  pollIntervalSec?: number;

  @IsOptional()
  @IsBoolean()
  enabled?: boolean;

  // Flexible connector configuration (SMB/SFTP/Azure/S3 etc.)
  // NOTE: must have a decorator to survive whitelist validation.
  @IsOptional()
  connectionConfig?: any;

  // Flexible mapping rules JSON (regex, templates, routing)
  @IsOptional()
  mappingRules?: any;

  @IsOptional()
  @IsBoolean()
  qcEnabled?: boolean;

  @IsOptional()
  qcConfig?: any;

  @IsOptional()
  @IsString()
  remarks?: string;

  @IsOptional()
  @IsEnum(MasterStatus)
  status?: MasterStatus;
}

export class UpdateHotFolderDto {
  @IsOptional()
  @IsString()
  @MinLength(2)
  name?: string;

  @IsOptional()
  @IsEnum(HotFolderSourceType)
  sourceType?: HotFolderSourceType;

  @IsOptional()
  @IsString()
  @MinLength(1)
  basePath?: string;

  @IsOptional()
  @IsInt()
  @Min(5)
  pollIntervalSec?: number;

  @IsOptional()
  @IsBoolean()
  enabled?: boolean;

  @IsOptional()
  connectionConfig?: any;

  @IsOptional()
  mappingRules?: any;

  @IsOptional()
  @IsBoolean()
  qcEnabled?: boolean;

  @IsOptional()
  qcConfig?: any;

  @IsOptional()
  @IsString()
  remarks?: string | null;

  @IsOptional()
  @IsEnum(MasterStatus)
  status?: MasterStatus;
}
