import { IsBoolean, IsOptional, IsString, IsUUID } from "class-validator";

export class MoveSlaDto {
  @IsUUID()
  toSlaId!: string;

  @IsOptional()
  @IsBoolean()
  dryRun?: boolean;
}
