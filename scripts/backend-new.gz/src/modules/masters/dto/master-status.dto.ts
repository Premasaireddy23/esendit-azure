import { IsEnum } from "class-validator";
import { MasterStatus } from "@prisma/client";

export class SetMasterStatusDto {
  @IsEnum(MasterStatus)
  status!: MasterStatus;
}
