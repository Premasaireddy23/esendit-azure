import { IsArray, IsDateString, IsEnum, IsInt, IsObject, IsOptional, IsString, IsUUID, MaxLength, ValidateNested } from "class-validator";
import { Type } from "class-transformer";
import { BillingAction, Status } from "@prisma/client";

export class RateCardItemDto {
  // Component identity / custom fields support
  @IsOptional()
  @IsString()
  @MaxLength(80)
  code?: string;

  @IsOptional()
  @IsString()
  @MaxLength(200)
  label?: string;

  @IsOptional()
  @IsInt()
  sortOrder?: number;

  @IsOptional()
  @IsObject()
  meta?: any;

  @IsEnum(BillingAction)
  action!: BillingAction;

  @IsOptional()
  @IsUUID()
  slaId?: string;

  // Send as string to preserve decimals; Prisma accepts string for Decimal fields.
  // Legacy single amount (kept for backward compatibility).
  @IsOptional()
  @IsString()
  amount?: string;

  // New spec fields (SD/HD rates). Use these going forward.
  @IsOptional()
  @IsString()
  sdAmount?: string;

  @IsOptional()
  @IsString()
  hdAmount?: string;

  @IsOptional()
  @IsString()
  currency?: string; // default EUR in DB

  @IsOptional()
  @IsString()
  unit?: string; // e.g. "per_file"
}

export class CreateRateCardDto {
  @IsString()
  @MaxLength(200)
  name!: string;

  @IsOptional()
  @IsUUID()
  billablePartyId?: string;

  @IsDateString()
  effectiveFrom!: string;

  @IsOptional()
  @IsDateString()
  effectiveTo?: string;

  @IsOptional()
  status?: Status;

  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => RateCardItemDto)
  items!: RateCardItemDto[];
}

export class UpdateRateCardDto {
  @IsOptional()
  @IsString()
  @MaxLength(200)
  name?: string;

  @IsOptional()
  @IsUUID()
  billablePartyId?: string | null; // allow clearing

  @IsOptional()
  @IsDateString()
  effectiveFrom?: string;

  @IsOptional()
  @IsDateString()
  effectiveTo?: string | null;

  @IsOptional()
  status?: Status;

  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => RateCardItemDto)
  items?: RateCardItemDto[];
}
