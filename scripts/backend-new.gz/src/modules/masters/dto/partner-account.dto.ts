import { IsArray, IsEnum, IsOptional, IsString, MinLength } from "class-validator";
import { AccountType, DestinationCategory, MasterStatus } from "@prisma/client";

export class CreatePartnerAccountDto {
  @IsString()
  @MinLength(2)
  name!: string;

  @IsEnum(AccountType)
  accountType!: AccountType;

  @IsOptional()
  @IsEnum(DestinationCategory)
  receiverCategory?: DestinationCategory;

  @IsOptional()
  @IsString()
  contactNo?: string;

  @IsOptional()
  @IsString()
  gstNumber?: string;

  @IsOptional()
  @IsString()
  panNumber?: string;

  @IsOptional()
  @IsString()
  address?: string;

  @IsOptional()
  @IsArray()
  emails?: string[];

  @IsOptional()
  @IsString()
  remarks?: string;

  @IsOptional()
  @IsEnum(MasterStatus)
  status?: MasterStatus;
}

export class UpdatePartnerAccountDto {
  @IsOptional()
  @IsString()
  @MinLength(2)
  name?: string;

  @IsOptional()
  @IsEnum(AccountType)
  accountType?: AccountType;

  @IsOptional()
  @IsEnum(DestinationCategory)
  receiverCategory?: DestinationCategory;

  @IsOptional()
  @IsString()
  contactNo?: string;

  @IsOptional()
  @IsString()
  gstNumber?: string;

  @IsOptional()
  @IsString()
  panNumber?: string;

  @IsOptional()
  @IsString()
  address?: string;

  @IsOptional()
  @IsArray()
  emails?: string[];

  @IsOptional()
  @IsString()
  remarks?: string;

  @IsOptional()
  @IsEnum(MasterStatus)
  status?: MasterStatus;
}
