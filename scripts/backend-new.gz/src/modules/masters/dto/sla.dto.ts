import { IsEnum, IsInt, IsOptional, IsString, Min, MinLength } from "class-validator";
import { Status } from "@prisma/client";

export class CreateSlaDto {
  @IsString()
  @MinLength(2)
  name!: string;

  @IsOptional()
  @IsString()
  code?: string;

  @IsOptional()
  @IsString()
  description?: string;

  @IsOptional()
  @IsInt()
  @Min(1)
  hoursTarget?: number;

  @IsOptional()
  @IsInt()
  @Min(1)
  targetMinutes?: number;

  @IsOptional()
  @IsEnum(Status)
  status?: Status;
}

export class UpdateSlaDto {
  @IsOptional()
  @IsString()
  @MinLength(2)
  name?: string;

  @IsOptional()
  @IsString()
  code?: string;

  @IsOptional()
  @IsString()
  description?: string;

  @IsOptional()
  @IsInt()
  @Min(1)
  hoursTarget?: number;

  @IsOptional()
  @IsInt()
  @Min(1)
  targetMinutes?: number;

  @IsOptional()
  @IsEnum(Status)
  status?: Status;
}
