import { IsEnum, IsOptional, IsString, IsUUID, MinLength } from "class-validator";
import { MasterStatus } from "@prisma/client";

export class CreateCityDto {
  @IsUUID()
  countryId!: string;

  @IsString()
  @MinLength(2)
  name!: string;

  @IsOptional()
  @IsEnum(MasterStatus)
  status?: MasterStatus;
}

export class UpdateCityDto {
  @IsOptional()
  @IsUUID()
  countryId?: string;

  @IsOptional()
  @IsString()
  @MinLength(2)
  name?: string;

  @IsOptional()
  @IsEnum(MasterStatus)
  status?: MasterStatus;
}
