import { IsEnum, IsOptional, IsString, MinLength } from "class-validator";
import { MasterStatus } from "@prisma/client";

export class CreateCountryDto {
  @IsString()
  @MinLength(2)
  name!: string;

  @IsOptional()
  @IsString()
  iso2?: string;

  @IsOptional()
  @IsEnum(MasterStatus)
  status?: MasterStatus;
}

export class UpdateCountryDto {
  @IsOptional()
  @IsString()
  @MinLength(2)
  name?: string;

  @IsOptional()
  @IsString()
  iso2?: string | null;

  @IsOptional()
  @IsEnum(MasterStatus)
  status?: MasterStatus;
}
