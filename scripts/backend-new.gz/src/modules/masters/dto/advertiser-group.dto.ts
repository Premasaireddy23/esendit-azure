import { IsArray, IsEnum, IsOptional, IsString, MinLength, IsEmail } from "class-validator";
import { MasterStatus } from "@prisma/client";

export class CreateAdvertiserGroupDto {
  @IsString()
  @MinLength(2)
  name!: string;

  @IsOptional()
  @IsEnum(MasterStatus)
  status?: MasterStatus;

  @IsOptional()
  @IsArray()
  @IsEmail({}, { each: true })
  emails?: string[];
}

export class UpdateAdvertiserGroupDto {
  @IsOptional()
  @IsString()
  @MinLength(2)
  name?: string;

  @IsOptional()
  @IsEnum(MasterStatus)
  status?: MasterStatus;

  @IsOptional()
  @IsArray()
  @IsEmail({}, { each: true })
  emails?: string[];
}
