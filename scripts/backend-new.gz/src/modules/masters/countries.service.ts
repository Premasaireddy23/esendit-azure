import { Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../../common/prisma/prisma.service";
import { MasterChangeService } from "./master-change.service";
import { MasterChangeAction, MasterEntityType, MasterStatus } from "@prisma/client";
import { CreateCountryDto, UpdateCountryDto } from "./dto/country.dto";

@Injectable()
export class CountriesService {
  constructor(private prisma: PrismaService, private changes: MasterChangeService) {}

  async list(accountId: string, q?: string) {
    return this.prisma.country.findMany({
      where: { accountId, ...(q ? { name: { contains: q, mode: "insensitive" } } : {}) },
      orderBy: { name: "asc" },
    });
  }

  async get(accountId: string, id: string) {
    const row = await this.prisma.country.findFirst({ where: { accountId, id } });
    if (!row) throw new NotFoundException("Country not found");
    return row;
  }

  async create(accountId: string, userId: string, dto: CreateCountryDto) {
    const row = await this.prisma.country.create({
      data: {
        accountId,
        name: dto.name,
        iso2: dto.iso2 ?? null,
        status: dto.status ?? MasterStatus.ACTIVE,
      },
    });

    await this.changes.emit({
      accountId,
      entityType: MasterEntityType.COUNTRY,
      entityId: row.id,
      action: MasterChangeAction.CREATED,
      changedByUserId: userId,
      payload: { name: row.name },
    });

    return row;
  }

  async update(accountId: string, userId: string, id: string, dto: UpdateCountryDto) {
    await this.get(accountId, id);

    const row = await this.prisma.country.update({
      where: { id },
      data: {
        name: dto.name ?? undefined,
        iso2: dto.iso2 ?? undefined,
        status: dto.status ?? undefined,
      },
    });

    await this.changes.emit({
      accountId,
      entityType: MasterEntityType.COUNTRY,
      entityId: row.id,
      action: MasterChangeAction.UPDATED,
      changedByUserId: userId,
      payload: { name: row.name },
    });

    return row;
  }

  async remove(accountId: string, userId: string, id: string) {
    await this.get(accountId, id);

    const row = await this.prisma.country.update({
      where: { id },
      data: { status: MasterStatus.INACTIVE },
    });

    await this.changes.emit({
      accountId,
      entityType: MasterEntityType.COUNTRY,
      entityId: row.id,
      action: MasterChangeAction.UPDATED,
      changedByUserId: userId,
      payload: { status: row.status },
    });

    return { ok: true };
  }
}
