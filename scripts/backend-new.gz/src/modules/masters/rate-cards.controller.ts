import { Body, Controller, Delete, Get, Param, Post, Put, Query, Req, UseGuards } from "@nestjs/common";
import { RateCardsService } from "./rate-cards.service";
import { CreateRateCardDto, UpdateRateCardDto } from "./dto/rate-card.dto";

// ✅ IMPORTANT: copy these from slas.controller.ts so paths are correct
import { JwtAuthGuard } from "../../common/auth/jwt-auth.guard";
import { PermissionsGuard } from "../../common/auth/permissions.guard";
import { RequireAnyPermissions } from "../../common/auth/require-any-permissions.decorator";

@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller("masters/rate-cards")
export class RateCardsController {
  constructor(private readonly service: RateCardsService) {}

  @Get()
  @RequireAnyPermissions("page:billing:rate-cards", "BILLING_READ")
  list(@Req() req: any, @Query("includeInactive") includeInactive?: string, @Query("q") q?: string) {
    return this.service.list(req.user.accountId, includeInactive === "true", q);
  }

  @Get(":id")
  @RequireAnyPermissions("page:billing:rate-cards", "BILLING_READ")
  get(@Req() req: any, @Param("id") id: string) {
    return this.service.get(req.user.accountId, id);
  }

  @Post()
  @RequireAnyPermissions("action:billing:rate-cards:create", "BILLING_CREATE")
  create(@Req() req: any, @Body() dto: CreateRateCardDto) {
    return this.service.create(req.user.accountId, req.user.id, dto);
  }

  @Put(":id")
  @RequireAnyPermissions("action:billing:rate-cards:update", "BILLING_UPDATE")
  update(@Req() req: any, @Param("id") id: string, @Body() dto: UpdateRateCardDto) {
    return this.service.update(req.user.accountId, req.user.id, id, dto);
  }

  @Delete(":id")
  @RequireAnyPermissions("action:billing:rate-cards:delete", "BILLING_DELETE")
  remove(@Req() req: any, @Param("id") id: string) {
    return this.service.softDelete(req.user.accountId, req.user.id, id);
  }
}
