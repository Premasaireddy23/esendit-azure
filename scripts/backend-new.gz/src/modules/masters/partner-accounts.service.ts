import { BadRequestException, ConflictException, Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../../common/prisma/prisma.service";
import { MasterChangeService } from "./master-change.service";
import { AccountType, MasterChangeAction, MasterEntityType, MasterStatus, Prisma } from "@prisma/client";
import { CreatePartnerAccountDto, UpdatePartnerAccountDto } from "./dto/partner-account.dto";
import { ensurePartnerAccountPeopleUser } from "../../common/users/partner-account-user-sync";

function normalizePartnerAccountEmails(values: any): string[] {
  if (Array.isArray(values)) {
    return Array.from(new Set(values.map((value) => String(value || "").trim().toLowerCase()).filter(Boolean)));
  }
  if (typeof values === "string") {
    return Array.from(new Set(values.split(/[;,\n]+/g).map((value) => String(value || "").trim().toLowerCase()).filter(Boolean)));
  }
  return [];
}

function receiverAccountIdFromConfig(config: any) {
  if (!config || typeof config !== "object") return "";
  return String((config as any).receiverAccountId || "").trim();
}

function withDestinationClientEmails(config: any, values: any) {
  const next = config && typeof config === "object" ? { ...config } : {};
  const emails = normalizePartnerAccountEmails(values);
  if (emails.length) (next as any).clientEmails = emails;
  else delete (next as any).clientEmails;
  delete (next as any).clientNotificationEmails;
  delete (next as any).notificationEmails;
  delete (next as any).emails;
  return next;
}

@Injectable()
export class PartnerAccountsService {
  constructor(private prisma: PrismaService, private changes: MasterChangeService) {}

  private async syncLinkedDestinationClientEmails(accountId: string, receiverAccountId: string, values: any) {
    const linkedDestinations = await this.prisma.destination.findMany({
      where: { accountId },
      select: { id: true, config: true },
    });
    const linked = linkedDestinations.filter((row: any) => receiverAccountIdFromConfig(row?.config) === receiverAccountId);
    if (!linked.length) return { updatedCount: 0 };

    await this.prisma.$transaction(
      linked.map((row: any) =>
        this.prisma.destination.update({
          where: { id: row.id },
          data: { config: withDestinationClientEmails(row?.config, values) },
        }),
      ),
    );

    return { updatedCount: linked.length };
  }

  async list(accountId: string, q?: string, includeInactive = false) {
    const qv = (q ?? "").trim();
    return this.prisma.partnerAccount.findMany({
      where: {
        accountId,
        ...(qv ? { name: { contains: qv, mode: "insensitive" } } : {}),
        ...(includeInactive ? {} : { status: MasterStatus.ACTIVE }),
      },
      orderBy: { name: "asc" },
    });
  }

  async get(accountId: string, id: string) {
    const row = await this.prisma.partnerAccount.findFirst({ where: { accountId, id } });
    if (!row) throw new NotFoundException("Account not found");
    return row;
  }

  private validate(dto: { accountType: AccountType; receiverCategory?: any }) {
    if (dto.accountType === AccountType.RECEIVER) {
      if (!dto.receiverCategory) throw new BadRequestException("receiverCategory is required when accountType=RECEIVER");
    }
  }

  async create(accountId: string, userId: string, dto: CreatePartnerAccountDto) {
    this.validate(dto as any);

    try {
      const created = await this.prisma.partnerAccount.create({
        data: {
          accountId,
          name: dto.name,
          accountType: dto.accountType,
          receiverCategory: dto.accountType === AccountType.RECEIVER ? dto.receiverCategory! : null,
          contactNo: dto.contactNo ?? null,
          gstNumber: dto.gstNumber ?? null,
          panNumber: dto.panNumber ?? null,
          address: dto.address ?? null,
          emails: dto.emails ?? [],
          remarks: dto.remarks ?? null,
          status: dto.status ?? MasterStatus.ACTIVE,
        },
      });

      await this.changes.emit({
        accountId,
        changedByUserId: userId,
        entityType: MasterEntityType.PARTNER_ACCOUNT,
        entityId: created.id,
        action: MasterChangeAction.CREATED,
        payload: { name: created.name, accountType: created.accountType, receiverCategory: created.receiverCategory, status: created.status },
      });

      await ensurePartnerAccountPeopleUser(this.prisma, created);

      return created;
    } catch (e: any) {
      if (e?.code === "P2002") throw new ConflictException("Account already exists");
      throw e;
    }
  }

  async update(accountId: string, userId: string, id: string, dto: UpdatePartnerAccountDto) {
    const existing = await this.prisma.partnerAccount.findFirst({ where: { id, accountId } });
    if (!existing) throw new NotFoundException("Account not found");

    const nextType = dto.accountType ?? existing.accountType;
    const nextReceiver = dto.receiverCategory ?? existing.receiverCategory ?? undefined;
    this.validate({ accountType: nextType as any, receiverCategory: nextReceiver } as any);

    const updated = await this.prisma.partnerAccount.update({
      where: { id },
      data: {
        name: dto.name ?? undefined,
        accountType: dto.accountType ?? undefined,
        receiverCategory: nextType === AccountType.RECEIVER ? (dto.receiverCategory ?? existing.receiverCategory) : null,
        contactNo: dto.contactNo ?? undefined,
        gstNumber: dto.gstNumber ?? undefined,
        panNumber: dto.panNumber ?? undefined,
        address: dto.address ?? undefined,
        emails: dto.emails ?? undefined,
        remarks: dto.remarks ?? undefined,
        status: dto.status ?? undefined,
      },
    });

    await this.changes.emit({
      accountId,
      changedByUserId: userId,
      entityType: MasterEntityType.PARTNER_ACCOUNT,
      entityId: updated.id,
      action: MasterChangeAction.UPDATED,
      payload: { before: existing, after: updated },
    });

    if (updated.accountType === AccountType.RECEIVER) {
      await this.syncLinkedDestinationClientEmails(accountId, updated.id, updated.emails ?? []);
    }

    await ensurePartnerAccountPeopleUser(this.prisma, updated);

    return updated;
  }

  async syncDestinationEmails(accountId: string, id: string) {
    const existing = await this.prisma.partnerAccount.findFirst({ where: { id, accountId } });
    if (!existing) throw new NotFoundException("Account not found");
    if (existing.accountType !== AccountType.RECEIVER) {
      throw new BadRequestException("Only receiver accounts can sync destination client emails");
    }

    const result = await this.syncLinkedDestinationClientEmails(accountId, existing.id, existing.emails ?? []);
    return { ok: true, updatedCount: result.updatedCount };
  }

  async enable(accountId: string, userId: string, id: string) {
    const existing = await this.prisma.partnerAccount.findFirst({ where: { id, accountId } });
    if (!existing) throw new NotFoundException("Account not found");

    const updated = await this.prisma.partnerAccount.update({
      where: { id },
      data: { status: MasterStatus.ACTIVE },
    });

    await this.changes.emit({
      accountId,
      changedByUserId: userId,
      entityType: MasterEntityType.PARTNER_ACCOUNT,
      entityId: updated.id,
      action: MasterChangeAction.UPDATED,
      payload: { before: existing, after: updated },
    });

    if (updated.accountType === AccountType.RECEIVER) {
      await this.syncLinkedDestinationClientEmails(accountId, updated.id, updated.emails ?? []);
    }

    await ensurePartnerAccountPeopleUser(this.prisma, updated);

    return updated;
  }

  async permanentRemove(accountId: string, userId: string, id: string) {
    const existing = await this.prisma.partnerAccount.findFirst({ where: { id, accountId } });
    if (!existing) throw new NotFoundException("Account not found");
    if (existing.status !== MasterStatus.INACTIVE) throw new BadRequestException("Only inactive accounts can be permanently deleted");

    try {
      await this.prisma.partnerAccount.delete({ where: { id } });
    } catch (e) {
      if (e instanceof Prisma.PrismaClientKnownRequestError && ["P2003", "P2014"].includes(e.code)) {
        throw new ConflictException("Cannot permanently delete this account because it is referenced by existing records");
      }
      throw e;
    }

    await this.changes.emit({
      accountId,
      changedByUserId: userId,
      entityType: MasterEntityType.PARTNER_ACCOUNT,
      entityId: id,
      action: MasterChangeAction.DELETED,
      payload: existing,
    });

    return { ok: true };
  }

  async remove(accountId: string, userId: string, id: string) {
    const existing = await this.prisma.partnerAccount.findFirst({ where: { id, accountId } });
    if (!existing) throw new NotFoundException("Account not found");

    const updated = await this.prisma.partnerAccount.update({
      where: { id },
      data: { status: MasterStatus.INACTIVE },
    });

    await this.changes.emit({
      accountId,
      changedByUserId: userId,
      entityType: MasterEntityType.PARTNER_ACCOUNT,
      entityId: updated.id,
      action: MasterChangeAction.DELETED,
      payload: { before: existing, after: updated },
    });

    return updated;
  }
}
