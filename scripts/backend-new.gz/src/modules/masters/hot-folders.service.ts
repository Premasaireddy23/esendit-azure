import { BadRequestException, Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../../common/prisma/prisma.service";
import { MasterChangeService } from "./master-change.service";
import { HotFolderIngestStatus, MasterChangeAction, MasterEntityType, MasterStatus } from "@prisma/client";
import { CreateHotFolderDto, UpdateHotFolderDto } from "./dto/hot-folder.dto";

@Injectable()
export class HotFoldersService {
  constructor(private prisma: PrismaService, private changes: MasterChangeService) {}

  private asBool(v: any, def = false) {
    if (v === undefined || v === null) return def;
    if (typeof v === "boolean") return v;
    if (typeof v === "string") return v.toLowerCase() === "true";
    return Boolean(v);
  }

  private asObj(v: any) {
    if (v === undefined || v === null) return {};
    if (typeof v === "object" && !Array.isArray(v)) return v;
    // DTO may pass strings in edge cases
    if (typeof v === "string") {
      try {
        const parsed = JSON.parse(v);
        if (typeof parsed === "object" && parsed && !Array.isArray(parsed)) return parsed;
      } catch {
        // ignore
      }
    }
    throw new BadRequestException("Invalid JSON object");
  }

  private validateMappingRules(mappingRules: any) {
    const mr = this.asObj(mappingRules);

    // Option A: { creativeId, queueAutoQc?, queueProxy? }
    // Option A+: { projectId, validIdFromFilename: true, ... }
    const hasCreativeId = typeof mr.creativeId === "string" && mr.creativeId.length > 5;
    const validFromFilename = this.asBool(mr.validIdFromFilename, false);
    const hasProjectId = typeof mr.projectId === "string" && mr.projectId.length > 5;

    if (!hasCreativeId && !(validFromFilename && hasProjectId)) {
      throw new BadRequestException(
        "mappingRules must include either {creativeId} or {projectId, validIdFromFilename:true} when Hot Folder is enabled",
      );
    }

    // Validate token transforms (optional)
    if (mr.captionReplaceTokens !== undefined) {
      const rep = this.asObj(mr.captionReplaceTokens);
      const entries = Object.entries(rep);
      if (entries.length > 50) throw new BadRequestException("captionReplaceTokens supports max 50 entries");
      for (const [k, v] of entries) {
        if (!/^[A-Z0-9]+$/.test(String(k))) {
          throw new BadRequestException("captionReplaceTokens keys must be A-Z0-9 only");
        }
        if (typeof v !== "string") throw new BadRequestException("captionReplaceTokens values must be strings");
      }
    }

    if (mr.captionStripTokens !== undefined) {
      if (!Array.isArray(mr.captionStripTokens)) {
        throw new BadRequestException("captionStripTokens must be an array of strings");
      }
      if (mr.captionStripTokens.length > 50) throw new BadRequestException("captionStripTokens supports max 50 tokens");
      for (const t of mr.captionStripTokens) {
        if (typeof t !== "string" || !t.trim()) throw new BadRequestException("captionStripTokens must contain strings");
        if (!/^[A-Z0-9]+$/.test(t.trim().toUpperCase())) {
          throw new BadRequestException("captionStripTokens values must be A-Z0-9 only");
        }
      }
    }

    // If enforceMonthYearPrefix is true, allow explicit monthYearPrefix or filename prefix derivation.
    // (worker handles details; this is just basic shape validation.)
    if (mr.monthYearPrefix !== undefined && typeof mr.monthYearPrefix !== "string") {
      throw new BadRequestException("monthYearPrefix must be a string");
    }

    return mr;
  }

  async list(accountId: string, q?: string, includeInactive = false) {
    return this.prisma.hotFolderConfig.findMany({
      where: {
        accountId,
        ...(q ? { name: { contains: q, mode: "insensitive" } } : {}),
        ...(includeInactive ? {} : { status: MasterStatus.ACTIVE }),
      },
      orderBy: { name: "asc" },
    });
  }

  async get(accountId: string, id: string) {
    const row = await this.prisma.hotFolderConfig.findFirst({ where: { accountId, id } });
    if (!row) throw new NotFoundException("Hot folder config not found");
    return row;
  }

  async listItems(accountId: string, hotFolderId: string, status?: HotFolderIngestStatus, take = 50) {
    await this.get(accountId, hotFolderId);
    return this.prisma.hotFolderIngestItem.findMany({
      where: {
        accountId,
        hotFolderId,
        ...(status ? { status } : {}),
      },
      orderBy: [{ createdAt: "desc" }],
      take,
    });
  }

  async create(accountId: string, userId: string, dto: CreateHotFolderDto) {
    const enabled = dto.enabled ?? false; // safer default (user requested)
    const mappingRules = (dto.mappingRules ?? {}) as any;

    // Only enforce mapping rules shape when enabling.
    if (enabled) this.validateMappingRules(mappingRules);

    const row = await this.prisma.hotFolderConfig.create({
      data: {
        accountId,
        name: dto.name,
        sourceType: dto.sourceType,
        basePath: dto.basePath,
        pollIntervalSec: dto.pollIntervalSec ?? 60,
        enabled,
        connectionConfig: (dto.connectionConfig ?? {}) as any,
        mappingRules,
        qcEnabled: dto.qcEnabled ?? false,
        qcConfig: (dto.qcConfig ?? {}) as any,
        remarks: dto.remarks ?? undefined,
        status: dto.status ?? MasterStatus.ACTIVE,
      },
    });

    await this.changes.emit({
      accountId,
      entityType: MasterEntityType.HOT_FOLDER,
      entityId: row.id,
      action: MasterChangeAction.CREATED,
      changedByUserId: userId,
      payload: { name: row.name, sourceType: row.sourceType, basePath: row.basePath },
    });

    return row;
  }

  async update(accountId: string, userId: string, id: string, dto: UpdateHotFolderDto) {
    const existing = await this.get(accountId, id);

    const finalEnabled = dto.enabled ?? existing.enabled;
    const finalMappingRules = dto.mappingRules === undefined ? existing.mappingRules : (dto.mappingRules ?? {});
    if (finalEnabled) this.validateMappingRules(finalMappingRules);

    const row = await this.prisma.hotFolderConfig.update({
      where: { id },
      data: {
        name: dto.name ?? undefined,
        sourceType: dto.sourceType ?? undefined,
        basePath: dto.basePath ?? undefined,
        pollIntervalSec: dto.pollIntervalSec ?? undefined,
        enabled: dto.enabled ?? undefined,
        connectionConfig: dto.connectionConfig === undefined ? undefined : (dto.connectionConfig ?? {}) as any,
        mappingRules: dto.mappingRules === undefined ? undefined : (dto.mappingRules ?? {}) as any,
        qcEnabled: dto.qcEnabled ?? undefined,
        qcConfig: dto.qcConfig === undefined ? undefined : (dto.qcConfig ?? {}) as any,
        remarks: dto.remarks ?? undefined,
        status: dto.status ?? undefined,
      },
    });

    await this.changes.emit({
      accountId,
      entityType: MasterEntityType.HOT_FOLDER,
      entityId: row.id,
      action: MasterChangeAction.UPDATED,
      changedByUserId: userId,
      payload: { name: row.name, sourceType: row.sourceType, basePath: row.basePath, status: row.status },
    });

    return row;
  }

  async remove(accountId: string, userId: string, id: string) {
    await this.get(accountId, id);

    const row = await this.prisma.hotFolderConfig.update({
      where: { id },
      data: { status: MasterStatus.INACTIVE, enabled: false },
    });

    await this.changes.emit({
      accountId,
      entityType: MasterEntityType.HOT_FOLDER,
      entityId: row.id,
      action: MasterChangeAction.UPDATED,
      changedByUserId: userId,
      payload: { status: row.status, enabled: row.enabled },
    });

    return { ok: true };
  }
}
