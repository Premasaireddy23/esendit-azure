import { Body, Controller, Delete, Get, Param, Post, Put, Query, UseGuards } from "@nestjs/common";
import { JwtAuthGuard } from "../../common/auth/jwt-auth.guard";
import { PermissionsGuard } from "../../common/auth/permissions.guard";
import { RequireAnyPermissions } from "../../common/auth/require-any-permissions.decorator";
import { CurrentUser } from "../../common/auth/current-user.decorator";
import { AgencyTeamsService } from "./agency-teams.service";
import { CreateAgencyTeamDto, UpdateAgencyTeamDto } from "./dto/agency-team.dto";

@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller("masters/agency-teams")
export class AgencyTeamsController {
  constructor(private svc: AgencyTeamsService) {}

  @Get()
  @RequireAnyPermissions("page:masters:agency-teams", "MASTERS_READ")
  list(@CurrentUser() u: any, @Query("q") q?: string) {
    return this.svc.list(u.accountId, q);
  }

  @Get(":id")
  @RequireAnyPermissions("page:masters:agency-teams", "MASTERS_READ")
  get(@CurrentUser() u: any, @Param("id") id: string) {
    return this.svc.get(u.accountId, id);
  }

  @Post()
  @RequireAnyPermissions("action:masters:agency-teams:create", "MASTERS_CREATE")
  create(@CurrentUser() u: any, @Body() dto: CreateAgencyTeamDto) {
    return this.svc.create(u.accountId, u.userId ?? u.id, dto);
  }

  @Put(":id")
  @RequireAnyPermissions("action:masters:agency-teams:update", "MASTERS_UPDATE")
  update(@CurrentUser() u: any, @Param("id") id: string, @Body() dto: UpdateAgencyTeamDto) {
    return this.svc.update(u.accountId, u.userId ?? u.id, id, dto);
  }

  @Delete(":id")
  @RequireAnyPermissions("action:masters:agency-teams:delete", "MASTERS_DELETE")
  remove(@CurrentUser() u: any, @Param("id") id: string) {
    return this.svc.remove(u.accountId, u.userId ?? u.id, id);
  }
}
