import { BadRequestException, Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../../common/prisma/prisma.service";
import { MasterChangeService } from "./master-change.service";
import { CreateSlaDto, UpdateSlaDto } from "./dto/sla.dto";
import { decorateSlaRow, mergeSlaDescriptionWithMinutes, minutesToStoredHours, parseSlaTargetMinutes } from "./sla-duration";
import { MasterChangeAction, MasterEntityType, Status } from "@prisma/client";

const SLA_SELECT = {
  id: true,
  name: true,
  code: true,
  description: true,
  hoursTarget: true,
  status: true,
  createdAt: true,
  updatedAt: true,
} as const;

@Injectable()
export class SlasService {
  constructor(private prisma: PrismaService, private changes: MasterChangeService) {}

  async list(accountId: string, q?: string, includeInactive = false) {
    const qNorm = (q ?? "").trim();
    const rows = await this.prisma.sla.findMany({
      where: {
        accountId,
        ...(qNorm
          ? {
              OR: [
                { name: { contains: qNorm, mode: "insensitive" } },
                { code: { contains: qNorm, mode: "insensitive" } },
                { description: { contains: qNorm, mode: "insensitive" } },
              ],
            }
          : {}),
        ...(includeInactive ? {} : { status: Status.ACTIVE }),
      },
      select: SLA_SELECT,
      orderBy: { name: "asc" },
    });
    return rows.map((row) => decorateSlaRow(row));
  }

  async get(accountId: string, id: string) {
    const row = await this.prisma.sla.findFirst({ where: { accountId, id }, select: SLA_SELECT });
    if (!row) throw new NotFoundException("SLA not found");
    return decorateSlaRow(row);
  }

  async create(accountId: string, userId: string, dto: CreateSlaDto) {
    const targetMinutes = dto.targetMinutes != null
      ? Math.trunc(dto.targetMinutes)
      : dto.hoursTarget != null
        ? Math.trunc(dto.hoursTarget) * 60
        : 0;
    if (!Number.isFinite(targetMinutes) || targetMinutes <= 0) throw new BadRequestException("SLA target is required");

    const row = await this.prisma.sla.create({
      data: {
        accountId,
        name: dto.name,
        code: dto.code ?? null,
        description: mergeSlaDescriptionWithMinutes(dto.description ?? null, targetMinutes),
        hoursTarget: dto.targetMinutes != null ? minutesToStoredHours(targetMinutes) : Math.trunc(dto.hoursTarget as number),
        status: dto.status ?? Status.ACTIVE,
      },
      select: SLA_SELECT,
    });

    const shaped = decorateSlaRow(row);

    await this.changes.emit({
      accountId,
      entityType: MasterEntityType.SLA,
      entityId: row.id,
      action: MasterChangeAction.CREATED,
      changedByUserId: userId,
      payload: { name: row.name, hoursTarget: row.hoursTarget, targetMinutes: shaped.targetMinutes },
    });

    return shaped;
  }

  async update(accountId: string, userId: string, id: string, dto: UpdateSlaDto) {
    const existing = await this.prisma.sla.findFirst({ where: { accountId, id }, select: SLA_SELECT });
    if (!existing) throw new NotFoundException("SLA not found");

    const nextTargetMinutes = dto.targetMinutes != null
      ? Math.trunc(dto.targetMinutes)
      : dto.hoursTarget != null
        ? Math.trunc(dto.hoursTarget) * 60
        : parseSlaTargetMinutes(existing);
    if (!Number.isFinite(nextTargetMinutes) || nextTargetMinutes <= 0) throw new BadRequestException("SLA target is required");

    const row = await this.prisma.sla.update({
      where: { id },
      data: {
        name: dto.name ?? undefined,
        code: dto.code ?? undefined,
        description: mergeSlaDescriptionWithMinutes(dto.description !== undefined ? dto.description : existing.description, nextTargetMinutes),
        hoursTarget: dto.targetMinutes != null
          ? minutesToStoredHours(nextTargetMinutes)
          : dto.hoursTarget ?? undefined,
        status: dto.status ?? undefined,
      },
      select: SLA_SELECT,
    });

    const shaped = decorateSlaRow(row);

    await this.changes.emit({
      accountId,
      entityType: MasterEntityType.SLA,
      entityId: row.id,
      action: MasterChangeAction.UPDATED,
      changedByUserId: userId,
      payload: { name: row.name, hoursTarget: row.hoursTarget, targetMinutes: shaped.targetMinutes, status: row.status },
    });

    return shaped;
  }

  async remove(accountId: string, userId: string, id: string) {
    await this.get(accountId, id);

    const row = await this.prisma.sla.update({
      where: { id },
      data: { status: Status.INACTIVE },
      select: SLA_SELECT,
    });

    await this.changes.emit({
      accountId,
      entityType: MasterEntityType.SLA,
      entityId: row.id,
      action: MasterChangeAction.DELETED,
      changedByUserId: userId,
      payload: { name: row.name },
    });

    return decorateSlaRow(row);
  }
}
