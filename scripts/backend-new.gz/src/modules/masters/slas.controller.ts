import { Body, Controller, Delete, Get, Param, Post, Put, Query, UseGuards } from "@nestjs/common";
import { JwtAuthGuard } from "../../common/auth/jwt-auth.guard";
import { PermissionsGuard } from "../../common/auth/permissions.guard";
import { RequireAnyPermissions } from "../../common/auth/require-any-permissions.decorator";
import { CurrentUser } from "../../common/auth/current-user.decorator";
import { SlasService } from "./slas.service";
import { CreateSlaDto, UpdateSlaDto } from "./dto/sla.dto";

@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller("masters/slas")
export class SlasController {
  constructor(private svc: SlasService) {}

  @Get()
  @RequireAnyPermissions("page:masters:slas", "MASTERS_READ")
  list(@CurrentUser() u: any, @Query("q") q?: string, @Query("includeInactive") includeInactive?: string) {
    return this.svc.list(u.accountId, q, includeInactive === "true");
  }

  @Get(":id")
  @RequireAnyPermissions("page:masters:slas", "MASTERS_READ")
  get(@CurrentUser() u: any, @Param("id") id: string) {
    return this.svc.get(u.accountId, id);
  }

  @Post()
  @RequireAnyPermissions("action:masters:slas:create", "MASTERS_CREATE")
  create(@CurrentUser() u: any, @Body() dto: CreateSlaDto) {
    return this.svc.create(u.accountId, u.id, dto);
  }

  @Put(":id")
  @RequireAnyPermissions("action:masters:slas:update", "MASTERS_UPDATE")
  update(@CurrentUser() u: any, @Param("id") id: string, @Body() dto: UpdateSlaDto) {
    return this.svc.update(u.accountId, u.id, id, dto);
  }

  @Delete(":id")
  @RequireAnyPermissions("action:masters:slas:delete", "MASTERS_DELETE")
  remove(@CurrentUser() u: any, @Param("id") id: string) {
    return this.svc.remove(u.accountId, u.id, id);
  }
}
