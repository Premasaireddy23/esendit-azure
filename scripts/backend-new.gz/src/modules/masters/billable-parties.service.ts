import { ConflictException, Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../../common/prisma/prisma.service";
import { MasterChangeService } from "./master-change.service";
import { CreateBillablePartyDto, UpdateBillablePartyDto } from "./dto/billable-party.dto";
import { MasterChangeAction, MasterEntityType, Status } from "@prisma/client";

@Injectable()
export class BillablePartiesService {
  constructor(private readonly prisma: PrismaService, private readonly changes: MasterChangeService) {}

  async list(accountId: string, opts?: { includeInactive?: boolean; q?: string }) {
    const includeInactive = !!opts?.includeInactive;
    const q = String(opts?.q ?? "").trim();

    return this.prisma.billableParty.findMany({
      where: {
        accountId,
        ...(includeInactive ? {} : { status: Status.ACTIVE }),
        ...(q
          ? {
              OR: [
                { name: { contains: q, mode: "insensitive" } },
                { code: { contains: q, mode: "insensitive" } },
                { gstNumber: { contains: q, mode: "insensitive" } },
                { panNumber: { contains: q, mode: "insensitive" } },
              ],
            }
          : {}),
      },
      orderBy: { name: "asc" },
    });
  }

  async create(accountId: string, userId: string, dto: CreateBillablePartyDto) {
    try {
      const created = await this.prisma.billableParty.create({
        data: {
          accountId,
          name: dto.name,
          code: dto.code,
          address: dto.address,
          gstNumber: dto.gstNumber,
          panNumber: dto.panNumber,
          paymentTerms: dto.paymentTerms,
          emails: dto.emails ?? [],
          status: dto.status ?? Status.ACTIVE,
        },
      });

      await this.changes.emit({
        accountId,
        changedByUserId: userId,
        entityType: MasterEntityType.BILLABLE_PARTY,
        entityId: created.id,
        action: MasterChangeAction.CREATED,
        payload: {
          name: created.name,
          code: created.code,
          address: created.address,
          gstNumber: created.gstNumber,
          panNumber: created.panNumber,
          paymentTerms: created.paymentTerms,
          emails: created.emails,
          status: created.status,
        },
      });

      return created;
    } catch (e: any) {
      if (e?.code === "P2002") throw new ConflictException("Billable party already exists");
      throw e;
    }
  }

  async update(accountId: string, userId: string, id: string, dto: UpdateBillablePartyDto) {
    const existing = await this.prisma.billableParty.findFirst({ where: { id, accountId } });
    if (!existing) throw new NotFoundException("Billable party not found");

    const updated = await this.prisma.billableParty.update({
      where: { id },
      data: {
        name: dto.name ?? undefined,
        code: dto.code ?? undefined,
        address: dto.address ?? undefined,
        gstNumber: dto.gstNumber ?? undefined,
        panNumber: dto.panNumber ?? undefined,
        paymentTerms: dto.paymentTerms ?? undefined,
        emails: dto.emails ?? undefined,
        status: dto.status ?? undefined,
      },
    });

    await this.changes.emit({
      accountId,
      changedByUserId: userId,
      entityType: MasterEntityType.BILLABLE_PARTY,
      entityId: updated.id,
      action: MasterChangeAction.UPDATED,
      payload: { before: existing, after: updated },
    });

    return updated;
  }

  async softDelete(accountId: string, userId: string, id: string) {
    const existing = await this.prisma.billableParty.findFirst({ where: { id, accountId } });
    if (!existing) throw new NotFoundException("Billable party not found");

    const updated = await this.prisma.billableParty.update({
      where: { id },
      data: { status: Status.INACTIVE },
    });

    await this.changes.emit({
      accountId,
      changedByUserId: userId,
      entityType: MasterEntityType.BILLABLE_PARTY,
      entityId: updated.id,
      action: MasterChangeAction.DELETED,
      payload: { before: existing, after: updated },
    });

    return updated;
  }
}
