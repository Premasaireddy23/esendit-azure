import { Body, Controller, Delete, Get, Param, Post, Put, Query, UseGuards } from "@nestjs/common";
import { JwtAuthGuard } from "../../common/auth/jwt-auth.guard";
import { PermissionsGuard } from "../../common/auth/permissions.guard";
import { RequireAnyPermissions } from "../../common/auth/require-any-permissions.decorator";
import { CurrentUser } from "../../common/auth/current-user.decorator";
import { AgenciesService } from "./agencies.service";
import { CreateAgencyDto, UpdateAgencyDto } from "./dto/agency.dto";
import { AgencyType } from "@prisma/client";

@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller("masters/agencies")
export class AgenciesController {
  constructor(private svc: AgenciesService) {}

  @Get()
  @RequireAnyPermissions("page:masters:agencies", "page:masters:agency-teams", "action:masters:agency-teams:create", "action:masters:agency-teams:update", "MASTERS_READ")
  list(@CurrentUser() u: any, @Query("q") q?: string, @Query("type") type?: string) {
    // Frontend calls /masters/agencies without type (e.g. when selecting agency in team create).
    // Allow optional `type=MEDIA|CREATIVE|...` filtering when provided.
    const t = typeof type === "string" ? type.toUpperCase() : undefined;
    const validType = t && (Object.values(AgencyType) as string[]).includes(t) ? (t as AgencyType) : undefined;
    return this.svc.list(u.accountId, q, validType);
  }

  @Get(":id")
  @RequireAnyPermissions("page:masters:agencies", "page:masters:agency-teams", "action:masters:agency-teams:create", "action:masters:agency-teams:update", "MASTERS_READ")
  get(@CurrentUser() u: any, @Param("id") id: string) {
    return this.svc.get(u.accountId, id);
  }

  @Post()
  @RequireAnyPermissions("action:masters:agencies:create", "MASTERS_CREATE")
  create(@CurrentUser() u: any, @Body() dto: CreateAgencyDto) {
    return this.svc.create(u.accountId, u.userId ?? u.id, dto);
  }

  @Put(":id")
  @RequireAnyPermissions("action:masters:agencies:update", "MASTERS_UPDATE")
  update(@CurrentUser() u: any, @Param("id") id: string, @Body() dto: UpdateAgencyDto) {
    return this.svc.update(u.accountId, u.userId ?? u.id, id, dto);
  }

  @Post(":id/enable")
  @RequireAnyPermissions("action:masters:agencies:update", "MASTERS_UPDATE")
  enable(@CurrentUser() u: any, @Param("id") id: string) {
    return this.svc.enable(u.accountId, u.userId ?? u.id, id);
  }

  @Delete(":id/permanent")
  @RequireAnyPermissions("action:masters:agencies:delete", "MASTERS_DELETE")
  permanentRemove(@CurrentUser() u: any, @Param("id") id: string) {
    return this.svc.permanentRemove(u.accountId, u.userId ?? u.id, id);
  }

  @Delete(":id")
  @RequireAnyPermissions("action:masters:agencies:delete", "MASTERS_DELETE")
  remove(@CurrentUser() u: any, @Param("id") id: string) {
    return this.svc.remove(u.accountId, u.userId ?? u.id, id);
  }
}
