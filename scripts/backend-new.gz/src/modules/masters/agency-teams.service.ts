import { BadRequestException, Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../../common/prisma/prisma.service";
import { MasterChangeService } from "./master-change.service";
import { MasterChangeAction, MasterEntityType, MasterStatus } from "@prisma/client";
import { CreateAgencyTeamDto, UpdateAgencyTeamDto } from "./dto/agency-team.dto";

@Injectable()
export class AgencyTeamsService {
  constructor(private prisma: PrismaService, private changes: MasterChangeService) {}

  async list(accountId: string, agencyId: string, q?: string) {
    return this.prisma.agencyTeam.findMany({
      where: {
        accountId,
        agencyId,
        ...(q ? { name: { contains: q, mode: "insensitive" } } : {}),
      },
      orderBy: { name: "asc" },
    });
  }

  async get(accountId: string, id: string) {
    const row = await this.prisma.agencyTeam.findFirst({ where: { accountId, id }, include: { agency: true } });
    if (!row) throw new NotFoundException("Agency team not found");
    return row;
  }

  async create(accountId: string, userId: string, dto: CreateAgencyTeamDto) {
    const agency = await this.prisma.agency.findFirst({ where: { accountId, id: dto.agencyId } });
    if (!agency) throw new BadRequestException("Invalid agencyId");

    const row = await this.prisma.agencyTeam.create({
      data: {
        accountId,
        agencyId: dto.agencyId,
        name: dto.name,
        emails: dto.emails ?? [],
        contactNo: dto.contactNo ?? null,
        address: dto.address ?? null,
        remarks: dto.remarks ?? null,
        gstNumber: dto.gstNumber ?? null,
        panNumber: dto.panNumber ?? null,
        status: dto.status ?? MasterStatus.ACTIVE,
      },
    });

    await this.changes.emit({
      accountId,
      entityType: MasterEntityType.AGENCY_TEAM,
      entityId: row.id,
      action: MasterChangeAction.CREATED,
      changedByUserId: userId,
      payload: { name: row.name },
    });

    return row;
  }

  async update(accountId: string, userId: string, id: string, dto: UpdateAgencyTeamDto) {
    await this.get(accountId, id);

    if (dto.agencyId) {
      const agency = await this.prisma.agency.findFirst({ where: { accountId, id: dto.agencyId } });
      if (!agency) throw new BadRequestException("Invalid agencyId");
    }

    const data: any = {};
    if (dto.agencyId !== undefined) data.agencyId = dto.agencyId;
    if (dto.name !== undefined) data.name = dto.name;
    if (dto.emails !== undefined) data.emails = dto.emails;
    if (dto.contactNo !== undefined) data.contactNo = dto.contactNo;
    if (dto.address !== undefined) data.address = dto.address;
    if (dto.remarks !== undefined) data.remarks = dto.remarks;
    if (dto.gstNumber !== undefined) data.gstNumber = dto.gstNumber;
    if (dto.panNumber !== undefined) data.panNumber = dto.panNumber;
    if (dto.status !== undefined) data.status = dto.status;

    const row = await this.prisma.agencyTeam.update({ where: { id }, data });

    await this.changes.emit({
      accountId,
      entityType: MasterEntityType.AGENCY_TEAM,
      entityId: row.id,
      action: MasterChangeAction.UPDATED,
      changedByUserId: userId,
      payload: { name: row.name },
    });

    return row;
  }

  async remove(accountId: string, userId: string, id: string) {
    await this.get(accountId, id);

    const row = await this.prisma.agencyTeam.update({
      where: { id },
      data: { status: MasterStatus.INACTIVE },
    });

    await this.changes.emit({
      accountId,
      entityType: MasterEntityType.AGENCY_TEAM,
      entityId: row.id,
      action: MasterChangeAction.UPDATED,
      changedByUserId: userId,
      payload: { status: row.status },
    });

    return { ok: true };
  }
}
