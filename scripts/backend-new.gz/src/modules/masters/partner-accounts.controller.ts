import { Body, Controller, Delete, Get, Param, Post, Put, Query, UseGuards } from "@nestjs/common";
import { JwtAuthGuard } from "../../common/auth/jwt-auth.guard";
import { PermissionsGuard } from "../../common/auth/permissions.guard";
import { RequireAnyPermissions } from "../../common/auth/require-any-permissions.decorator";
import { CurrentUser } from "../../common/auth/current-user.decorator";
import { PartnerAccountsService } from "./partner-accounts.service";
import { CreatePartnerAccountDto, UpdatePartnerAccountDto } from "./dto/partner-account.dto";

@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller("masters/partner-accounts")
export class PartnerAccountsController {
  constructor(private svc: PartnerAccountsService) {}

  @Get()
  @RequireAnyPermissions("page:masters:accounts", "MASTERS_READ")
  list(@CurrentUser() u: any, @Query("q") q?: string, @Query("includeInactive") includeInactive?: string) {
    return this.svc.list(u.accountId, q, includeInactive === "true");
  }

  @Get(":id")
  @RequireAnyPermissions("page:masters:accounts", "MASTERS_READ")
  get(@CurrentUser() u: any, @Param("id") id: string) {
    return this.svc.get(u.accountId, id);
  }

  @Post()
  @RequireAnyPermissions("action:masters:accounts:create", "MASTERS_CREATE")
  create(@CurrentUser() u: any, @Body() dto: CreatePartnerAccountDto) {
    return this.svc.create(u.accountId, u.userId ?? u.id, dto);
  }

  @Put(":id")
  @RequireAnyPermissions("action:masters:accounts:update", "MASTERS_UPDATE")
  update(@CurrentUser() u: any, @Param("id") id: string, @Body() dto: UpdatePartnerAccountDto) {
    return this.svc.update(u.accountId, u.userId ?? u.id, id, dto);
  }

  @Post(":id/sync-destination-emails")
  @RequireAnyPermissions("action:masters:accounts:update", "MASTERS_UPDATE")
  syncDestinationEmails(@CurrentUser() u: any, @Param("id") id: string) {
    return this.svc.syncDestinationEmails(u.accountId, id);
  }

  @Post(":id/enable")
  @RequireAnyPermissions("action:masters:accounts:update", "MASTERS_UPDATE")
  enable(@CurrentUser() u: any, @Param("id") id: string) {
    return this.svc.enable(u.accountId, u.userId ?? u.id, id);
  }

  @Delete(":id/permanent")
  @RequireAnyPermissions("action:masters:accounts:delete", "MASTERS_DELETE")
  permanentRemove(@CurrentUser() u: any, @Param("id") id: string) {
    return this.svc.permanentRemove(u.accountId, u.userId ?? u.id, id);
  }

  @Delete(":id")
  @RequireAnyPermissions("action:masters:accounts:delete", "MASTERS_DELETE")
  remove(@CurrentUser() u: any, @Param("id") id: string) {
    return this.svc.remove(u.accountId, u.userId ?? u.id, id);
  }
}
