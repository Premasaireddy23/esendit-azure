import { Body, Controller, Delete, Get, Param, Post, Put, Query, Req, UseGuards } from "@nestjs/common";
import { BillablePartiesService } from "./billable-parties.service";
import { CreateBillablePartyDto, UpdateBillablePartyDto } from "./dto/billable-party.dto";

// ✅ IMPORTANT: copy these from slas.controller.ts so paths are correct
import { JwtAuthGuard } from "../../common/auth/jwt-auth.guard";
import { PermissionsGuard } from "../../common/auth/permissions.guard";
import { RequireAnyPermissions } from "../../common/auth/require-any-permissions.decorator";

@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller("masters/billable-parties")
export class BillablePartiesController {
  constructor(private readonly service: BillablePartiesService) {}

  @Get()
  @RequireAnyPermissions("page:billing:billable-parties", "BILLING_READ")
  list(@Req() req: any, @Query("includeInactive") includeInactive?: string, @Query("q") q?: string) {
    return this.service.list(req.user.accountId, { includeInactive: includeInactive === "true", q });
  }

  @Post()
  @RequireAnyPermissions("action:billing:billable-parties:create", "BILLING_CREATE")
  create(@Req() req: any, @Body() dto: CreateBillablePartyDto) {
    return this.service.create(req.user.accountId, req.user.id, dto);
  }

  @Put(":id")
  @RequireAnyPermissions("action:billing:billable-parties:update", "BILLING_UPDATE")
  update(@Req() req: any, @Param("id") id: string, @Body() dto: UpdateBillablePartyDto) {
    return this.service.update(req.user.accountId, req.user.id, id, dto);
  }

  @Delete(":id")
  @RequireAnyPermissions("action:billing:billable-parties:delete", "BILLING_DELETE")
  remove(@Req() req: any, @Param("id") id: string) {
    return this.service.softDelete(req.user.accountId, req.user.id, id);
  }
}
