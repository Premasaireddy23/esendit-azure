import { BadRequestException, ConflictException, Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../../common/prisma/prisma.service";
import { CreateRateCardDto, UpdateRateCardDto } from "./dto/rate-card.dto";
import { MasterChangeAction, Status } from "@prisma/client";

function ensureNoDuplicateItems(items: { action: string; slaId?: string; code?: string | null }[]) {
  const seen = new Set<string>();
  for (const it of items) {
    const key = `${it.action}::${it.slaId ?? "NONE"}::${(it.code ?? "").trim().toLowerCase() || "NO_CODE"}`;
    if (seen.has(key)) {
      throw new BadRequestException(
        `Duplicate rate item for action=${it.action} slaId=${it.slaId ?? "null"} code=${(it.code ?? "").trim() || "null"}`,
      );
    }
    seen.add(key);
  }
}

function normalizeAmounts(it: { amount?: string; sdAmount?: string; hdAmount?: string }) {
  // Backward compatible:
  // - old clients send only `amount`
  // - new UI sends `sdAmount` + `hdAmount`
  const sdAmount = it.sdAmount ?? it.amount;
  const hdAmount = it.hdAmount ?? it.amount;
  const legacyAmount = it.amount ?? it.sdAmount ?? it.hdAmount;
  return { sdAmount, hdAmount, legacyAmount };
}

@Injectable()
export class RateCardsService {
  constructor(private readonly prisma: PrismaService) {}

  private async validateRefs(accountId: string, billablePartyId?: string | null, items?: { slaId?: string }[]) {
    if (billablePartyId) {
      const bp = await this.prisma.billableParty.findFirst({ where: { id: billablePartyId, accountId, status: Status.ACTIVE } });
      if (!bp) throw new BadRequestException("Invalid billablePartyId (not found / not ACTIVE / wrong tenant)");
    }

    const slaIds = [...new Set((items ?? []).map(i => i.slaId).filter(Boolean))] as string[];
    if (slaIds.length) {
      const slas = await this.prisma.sla.findMany({ where: { id: { in: slaIds }, accountId, status: Status.ACTIVE }, select: { id: true } });
      const ok = new Set(slas.map(s => s.id));
      const bad = slaIds.filter(id => !ok.has(id));
      if (bad.length) throw new BadRequestException(`Invalid slaId(s): ${bad.join(", ")}`);
    }
  }

  async list(accountId: string, includeInactive = false, q?: string) {
    const search = (q || "").trim();
    return this.prisma.rateCard.findMany({
      where: {
        accountId,
        ...(includeInactive ? {} : { status: Status.ACTIVE }),
        ...(search
          ? {
              OR: [
                { name: { contains: search, mode: "insensitive" } },
                { items: { some: { code: { contains: search, mode: "insensitive" } } } },
                { items: { some: { label: { contains: search, mode: "insensitive" } } } },
              ],
            }
          : {}),
      },
      include: {
        billableParty: { select: { id: true, name: true } },
        items: {
          orderBy: [{ sortOrder: "asc" }, { action: "asc" }],
          include: { sla: { select: { id: true, name: true } } },
        },
      },
      orderBy: [{ effectiveFrom: "desc" }, { name: "asc" }],
    });
  }

  async get(accountId: string, id: string) {
    const rc = await this.prisma.rateCard.findFirst({
      where: { id, accountId },
      include: {
        billableParty: { select: { id: true, name: true } },
        items: { include: { sla: { select: { id: true, name: true } } }, orderBy: [{ sortOrder: "asc" }, { action: "asc" }] },
      },
    });
    if (!rc) throw new NotFoundException("Rate card not found");
    return rc;
  }

  async create(accountId: string, userId: string, dto: CreateRateCardDto) {
    if (!dto.items?.length) throw new BadRequestException("items is required");
    ensureNoDuplicateItems(dto.items);

    const effectiveFrom = new Date(dto.effectiveFrom);
    const effectiveTo = dto.effectiveTo ? new Date(dto.effectiveTo) : null;
    if (effectiveTo && effectiveTo < effectiveFrom) throw new BadRequestException("effectiveTo must be >= effectiveFrom");

    await this.validateRefs(accountId, dto.billablePartyId, dto.items);

    try {
      const created = await this.prisma.rateCard.create({
        data: {
          accountId,
          name: dto.name,
          billablePartyId: dto.billablePartyId,
          effectiveFrom,
          effectiveTo,
          status: dto.status ?? Status.ACTIVE,
          items: {
            create: dto.items.map(it => ({
              action: it.action,
              slaId: it.slaId,
              code: (it as any).code ? String((it as any).code).trim() : null,
              label: (it as any).label ? String((it as any).label).trim() : null,
              sortOrder: Number.isFinite((it as any).sortOrder) ? Number((it as any).sortOrder) : 0,
              meta: (it as any).meta ?? null,
              amount: (() => {
                const { sdAmount, hdAmount, legacyAmount } = normalizeAmounts(it as any);
                if (!sdAmount || !hdAmount || !legacyAmount) {
                  throw new BadRequestException("Each rate item must have sdAmount+hdAmount (or legacy amount)");
                }
                return legacyAmount;
              })(),
              sdAmount: normalizeAmounts(it as any).sdAmount as any,
              hdAmount: normalizeAmounts(it as any).hdAmount as any,
              currency: it.currency ?? "EUR",
              unit: it.unit,
            })),
          },
        },
        include: { items: true },
      });

      await this.prisma.masterChangeEvent.create({
        data: {
          accountId,
          changedByUserId: userId,
          entityType: "RATE_CARD",
          entityId: created.id,
          action: MasterChangeAction.CREATED,
          payload: { name: created.name, effectiveFrom: created.effectiveFrom, effectiveTo: created.effectiveTo, status: created.status },
        },
      });

      return this.get(accountId, created.id);
    } catch (e: any) {
      if (e?.code === "P2002") throw new ConflictException("Rate card already exists for that name/date");
      throw e;
    }
  }

  async update(accountId: string, userId: string, id: string, dto: UpdateRateCardDto) {
    const existing = await this.prisma.rateCard.findFirst({ where: { id, accountId }, include: { items: true } });
    if (!existing) throw new NotFoundException("Rate card not found");

    const effectiveFrom = dto.effectiveFrom ? new Date(dto.effectiveFrom) : existing.effectiveFrom;
    const effectiveTo =
      dto.effectiveTo === undefined ? existing.effectiveTo : dto.effectiveTo === null ? null : new Date(dto.effectiveTo);

    if (effectiveTo && effectiveTo < effectiveFrom) throw new BadRequestException("effectiveTo must be >= effectiveFrom");

    if (dto.items) {
      if (!dto.items.length) throw new BadRequestException("items cannot be empty");
      ensureNoDuplicateItems(dto.items);
    }

    await this.validateRefs(accountId, dto.billablePartyId ?? existing.billablePartyId, dto.items ?? existing.items);

    const updated = await this.prisma.$transaction(async tx => {
      const rc = await tx.rateCard.update({
        where: { id },
        data: {
          name: dto.name ?? undefined,
          billablePartyId: dto.billablePartyId === undefined ? undefined : dto.billablePartyId, // can be null
          effectiveFrom: dto.effectiveFrom ? effectiveFrom : undefined,
          effectiveTo: dto.effectiveTo === undefined ? undefined : effectiveTo,
          status: dto.status ?? undefined,
        },
      });

      if (dto.items) {
        await tx.rateCardItem.deleteMany({ where: { rateCardId: id } });
        await tx.rateCardItem.createMany({
          data: dto.items.map(it => ({
            rateCardId: id,
            action: it.action,
            slaId: it.slaId ?? null,
            code: (it as any).code ? String((it as any).code).trim() : null,
            label: (it as any).label ? String((it as any).label).trim() : null,
            sortOrder: Number.isFinite((it as any).sortOrder) ? Number((it as any).sortOrder) : 0,
            meta: (it as any).meta ?? null,
            amount: (() => {
              const { sdAmount, hdAmount, legacyAmount } = normalizeAmounts(it as any);
              if (!sdAmount || !hdAmount || !legacyAmount) {
                throw new BadRequestException("Each rate item must have sdAmount+hdAmount (or legacy amount)");
              }
              return legacyAmount;
            })(),
            sdAmount: normalizeAmounts(it as any).sdAmount as any,
            hdAmount: normalizeAmounts(it as any).hdAmount as any,
            currency: it.currency ?? "EUR",
            unit: it.unit ?? null,
          })),
        });
      }

      return rc;
    });

    await this.prisma.masterChangeEvent.create({
      data: {
        accountId,
        changedByUserId: userId,
        entityType: "RATE_CARD",
        entityId: updated.id,
        action: MasterChangeAction.UPDATED,
        payload: { before: existing, after: await this.get(accountId, id) },
      },
    });

    return this.get(accountId, id);
  }

  async softDelete(accountId: string, userId: string, id: string) {
    const existing = await this.prisma.rateCard.findFirst({ where: { id, accountId } });
    if (!existing) throw new NotFoundException("Rate card not found");

    const updated = await this.prisma.rateCard.update({
      where: { id },
      data: { status: Status.INACTIVE },
    });

    await this.prisma.masterChangeEvent.create({
      data: {
        accountId,
        changedByUserId: userId,
        entityType: "RATE_CARD",
        entityId: updated.id,
        action: MasterChangeAction.DELETED,
        payload: { before: existing, after: updated },
      },
    });

    return updated;
  }
}
