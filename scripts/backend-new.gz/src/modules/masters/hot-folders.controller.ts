import { Body, Controller, Delete, Get, Param, Post, Put, Query, UseGuards } from "@nestjs/common";
import { JwtAuthGuard } from "../../common/auth/jwt-auth.guard";
import { PermissionsGuard } from "../../common/auth/permissions.guard";
import { RequireAnyPermissions } from "../../common/auth/require-any-permissions.decorator";
import { CurrentUser } from "../../common/auth/current-user.decorator";
import { HotFoldersService } from "./hot-folders.service";
import { CreateHotFolderDto, UpdateHotFolderDto } from "./dto/hot-folder.dto";
import { HotFolderIngestStatus } from "@prisma/client";

@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller("masters/hot-folders")
export class HotFoldersController {
  constructor(private svc: HotFoldersService) {}

  @Get()
  @RequireAnyPermissions("page:masters:hot-folders", "MASTERS_READ")
  list(
    @CurrentUser() u: any,
    @Query("q") q?: string,
    @Query("includeInactive") includeInactive?: string,
  ) {
    return this.svc.list(u.accountId, q, includeInactive === "true");
  }

  @Get(":id")
  @RequireAnyPermissions("page:masters:hot-folders", "MASTERS_READ")
  get(@CurrentUser() u: any, @Param("id") id: string) {
    return this.svc.get(u.accountId, id);
  }

  // HF-2 debug/ops: view ingestion queue for this hot folder
  @Get(":id/items")
  @RequireAnyPermissions("page:masters:hot-folders", "MASTERS_READ")
  listItems(
    @CurrentUser() u: any,
    @Param("id") id: string,
    @Query("status") status?: HotFolderIngestStatus,
    @Query("take") take?: string,
  ) {
    const n = Number(take || 50);
    return this.svc.listItems(u.accountId, id, status, Number.isFinite(n) ? Math.min(200, Math.max(1, n)) : 50);
  }

  @Post()
  @RequireAnyPermissions("action:masters:hot-folders:create", "MASTERS_CREATE")
  create(@CurrentUser() u: any, @Body() dto: CreateHotFolderDto) {
    return this.svc.create(u.accountId, u.userId ?? u.id, dto);
  }

  @Put(":id")
  @RequireAnyPermissions("action:masters:hot-folders:update", "MASTERS_UPDATE")
  update(@CurrentUser() u: any, @Param("id") id: string, @Body() dto: UpdateHotFolderDto) {
    return this.svc.update(u.accountId, u.userId ?? u.id, id, dto);
  }

  @Delete(":id")
  @RequireAnyPermissions("action:masters:hot-folders:delete", "MASTERS_DELETE")
  remove(@CurrentUser() u: any, @Param("id") id: string) {
    return this.svc.remove(u.accountId, u.userId ?? u.id, id);
  }
}
