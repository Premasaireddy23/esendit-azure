import { BadRequestException, Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../../../common/prisma/prisma.service";
import { destinationSelect } from "../../../common/prisma/selects";
import { CreateDestinationDto, UpdateDestinationDto } from "./dto";
import { AccountType, MasterChangeAction, MasterEntityType, MasterStatus } from "@prisma/client";

function destinationProfileIdsFromConfig(config: any) {
  const cfg = config && typeof config === "object" ? config : {};
  const defaults = cfg.deliveryProfileDefaults && typeof cfg.deliveryProfileDefaults === "object" ? cfg.deliveryProfileDefaults : {};
  return Array.from(
    new Set(
      [cfg.defaultDeliveryProfileId, cfg.mainDeliveryProfileId, cfg.backupDeliveryProfileId, defaults.defaultProfileId, defaults.mainProfileId, defaults.backupProfileId]
        .map((v) => String(v || "").trim())
        .filter(Boolean),
    ),
  );
}

function parsePresets(downloadPresets: any) {
  return Array.isArray(downloadPresets) ? downloadPresets : [];
}

function pickPresetsByKeys(all: any[], keys: any) {
  const list = Array.isArray(keys) ? keys.map((k) => String(k).trim()).filter(Boolean) : [];
  if (!list.length) return [] as any[];
  const map = new Map(all.map((p: any) => [String(p?.key || ""), p] as const));
  const seen = new Set<string>();
  const out: any[] = [];
  for (const key of list) {
    if (seen.has(key)) continue;
    const preset = map.get(key);
    if (!preset) continue;
    seen.add(key);
    out.push(preset);
  }
  return out;
}

function normalizePresetKey(v: any) {
  const raw = String(v ?? "").trim();
  return raw || null;
}

function normalizeTranscodeOnCommit(v: any) {
  if (v === undefined || v === null || v === "") return null;
  if (v === false || v === "false" || v === 0 || v === "0") return false;
  return true;
}

function normalizeReceiverAccountId(config: any) {
  if (!config || typeof config !== "object") return "";
  return String((config as any).receiverAccountId || "").trim();
}

function withNormalizedReceiverAccountId(config: any) {
  const next = config && typeof config === "object" ? { ...config } : {};
  const receiverAccountId = normalizeReceiverAccountId(next);
  if (receiverAccountId) (next as any).receiverAccountId = receiverAccountId;
  else delete (next as any).receiverAccountId;
  return next;
}

function normalizeApprovalRequired(config: any) {
  if (!config || typeof config !== "object") return false;
  const raw = (config as any).approvalRequired;
  return raw === true || raw === "true" || raw === 1 || raw === "1";
}

function withNormalizedApprovalRequired(config: any) {
  const next = config && typeof config === "object" ? { ...config } : {};
  if (normalizeApprovalRequired(next)) (next as any).approvalRequired = true;
  else delete (next as any).approvalRequired;
  return next;
}

function normalizeEmailList(values: any): string[] {
  if (Array.isArray(values)) {
    return Array.from(new Set(values.map((value) => String(value || "").trim().toLowerCase()).filter(Boolean)));
  }
  if (typeof values === "string") {
    return Array.from(new Set(values.split(/[;,\n]+/g).map((value) => String(value || "").trim().toLowerCase()).filter(Boolean)));
  }
  return [];
}

function withSyncedDestinationClientEmails(config: any, values: any) {
  const next = config && typeof config === "object" ? { ...config } : {};
  const emails = normalizeEmailList(values);
  if (emails.length) (next as any).clientEmails = emails;
  else delete (next as any).clientEmails;
  delete (next as any).clientNotificationEmails;
  delete (next as any).notificationEmails;
  delete (next as any).emails;
  return next;
}

function hasHouseIdToken(fileNameTemplate: any) {
  return /\{\s*HOUSE_ID\s*\}/i.test(String(fileNameTemplate || ""));
}

@Injectable()
export class DestinationsService {
  constructor(private prisma: PrismaService) {}

  private async syncDestinationClientEmailsFromReceiver(accountId: string, config: any) {
    const receiverAccountId = normalizeReceiverAccountId(config);
    if (!receiverAccountId) return config;

    const receiver = await this.prisma.partnerAccount.findFirst({
      where: {
        accountId,
        id: receiverAccountId,
        accountType: AccountType.RECEIVER,
      },
      select: { emails: true },
    });
    if (!receiver) return config;
    return withSyncedDestinationClientEmails(config, (receiver as any).emails);
  }

  private async validateReceiverAccountLink(accountId: string, dto: CreateDestinationDto | UpdateDestinationDto, existing?: any) {
    const effectiveCategory = dto?.category ?? existing?.category ?? undefined;
    const cfg = dto?.config !== undefined
      ? withNormalizedReceiverAccountId(dto.config)
      : withNormalizedReceiverAccountId(existing?.config);
    const receiverAccountId = normalizeReceiverAccountId(cfg);
    if (!receiverAccountId) return cfg;

    const receiver = await this.prisma.partnerAccount.findFirst({
      where: {
        accountId,
        id: receiverAccountId,
        accountType: AccountType.RECEIVER,
      },
      select: { id: true, name: true, receiverCategory: true, status: true },
    });
    if (!receiver) {
      throw new BadRequestException("Invalid receiver account selected for destination");
    }
    const existingReceiverAccountId = normalizeReceiverAccountId(existing?.config);
    if (receiver.status !== MasterStatus.ACTIVE && existingReceiverAccountId !== receiverAccountId) {
      throw new BadRequestException("Only active receiver accounts can be linked to a destination");
    }
    if (effectiveCategory && receiver.receiverCategory && receiver.receiverCategory !== effectiveCategory) {
      throw new BadRequestException("Receiver account category must match destination category");
    }
    return cfg;
  }

  private validateApprovalConfig(dto: CreateDestinationDto | UpdateDestinationDto, existing: any, config: any) {
    const approvalRequired = normalizeApprovalRequired(config);
    if (!approvalRequired) return;

    const template = String(dto?.fileNameTemplate ?? existing?.fileNameTemplate ?? "").trim();
    if (!hasHouseIdToken(template)) {
      throw new BadRequestException("File nomenclature must include {HOUSE_ID} when destination approval is required");
    }
  }

  private async validatePresetFallback(accountId: string, dto: CreateDestinationDto | UpdateDestinationDto, existing?: any) {
    const cfg = dto?.config !== undefined
      ? dto.config
      : existing?.config && typeof existing.config === "object"
        ? existing.config
        : {};
    const presetKey = normalizePresetKey((cfg as any)?.defaultPresetKey);
    if (!presetKey) return;

    const account = await this.prisma.account.findFirst({
      where: { id: accountId },
      select: { downloadPresets: true } as any,
    });
    const library = parsePresets((account as any)?.downloadPresets);
    const destinationPresets = parsePresets(dto?.downloadPresets !== undefined ? dto.downloadPresets : existing?.downloadPresets);
    const allowed = destinationPresets.length
      ? destinationPresets
      : (() => {
          const filtered = pickPresetsByKeys(library, (cfg as any)?.allowedPresetKeys);
          return filtered.length ? filtered : library;
        })();

    if (allowed.length && !allowed.some((preset: any) => String(preset?.key || "") === presetKey)) {
      throw new BadRequestException("Invalid destination defaultPresetKey for the allowed preset list");
    }

    const normalizedTranscode = normalizeTranscodeOnCommit((cfg as any)?.transcodeOnCommit);
    if (cfg && typeof cfg === "object") {
      if (presetKey) (cfg as any).defaultPresetKey = presetKey;
      if (normalizedTranscode === null) delete (cfg as any).transcodeOnCommit;
      else (cfg as any).transcodeOnCommit = normalizedTranscode;
    }
  }

  list(accountId: string) {
    return this.prisma.destination.findMany({
      where: { accountId },
      orderBy: { name: "asc" },
      select: destinationSelect,
    });
  }

  async create(accountId: string, userId: string, dto: CreateDestinationDto) {
    const receiverLinkedConfig = await this.validateReceiverAccountLink(accountId, dto);
    const syncedClientConfig = await this.syncDestinationClientEmailsFromReceiver(accountId, receiverLinkedConfig);
    const normalizedConfig = withNormalizedApprovalRequired(syncedClientConfig);
    this.validateApprovalConfig(dto, null, normalizedConfig);
    const dtoWithConfig = { ...dto, config: normalizedConfig };
    const profileIds = destinationProfileIdsFromConfig(dtoWithConfig.config);
    if (profileIds.length) {
      const cnt = await this.prisma.deliveryProfile.count({ where: { accountId, id: { in: profileIds } } });
      if (cnt !== profileIds.length) throw new BadRequestException("Invalid destination delivery profile id(s)");
    }
    await this.validatePresetFallback(accountId, dtoWithConfig);

    const row = await this.prisma.destination.create({
      data: { accountId, ...dtoWithConfig, config: dtoWithConfig.config ?? {} },
      select: destinationSelect,
    });

    await this.prisma.masterChangeEvent.create({
      data: {
        accountId,
        changedByUserId: userId,
        entityType: MasterEntityType.DESTINATION,
        entityId: row.id,
        action: MasterChangeAction.CREATED,
        payload: row as any,
      },
    });

    return row;
  }

  async update(accountId: string, userId: string, id: string, dto: UpdateDestinationDto) {
    const existing = await this.prisma.destination.findFirst({ where: { id, accountId } });
    if (!existing) throw new NotFoundException("Destination not found");

    const nextConfigSource: UpdateDestinationDto = dto.config === undefined
      ? {
          ...dto,
          config: existing.config && typeof existing.config === "object"
            ? (existing.config as Record<string, any>)
            : {},
        }
      : dto;
    const receiverLinkedConfig = await this.validateReceiverAccountLink(accountId, nextConfigSource, existing);
    const syncedClientConfig = await this.syncDestinationClientEmailsFromReceiver(accountId, receiverLinkedConfig);
    const normalizedConfig = withNormalizedApprovalRequired(syncedClientConfig);
    this.validateApprovalConfig(dto, existing, normalizedConfig);
    const profileIds = destinationProfileIdsFromConfig(normalizedConfig);
    if (profileIds.length) {
      const cnt = await this.prisma.deliveryProfile.count({ where: { accountId, id: { in: profileIds } } });
      if (cnt !== profileIds.length) throw new BadRequestException("Invalid destination delivery profile id(s)");
    }
    const dtoWithConfig = { ...dto, config: normalizedConfig };
    await this.validatePresetFallback(accountId, dtoWithConfig, existing);

    const row = await this.prisma.destination.update({
      where: { id },
      data: { ...dtoWithConfig, config: dtoWithConfig.config ?? undefined },
      select: destinationSelect,
    });

    await this.prisma.masterChangeEvent.create({
      data: {
        accountId,
        changedByUserId: userId,
        entityType: MasterEntityType.DESTINATION,
        entityId: row.id,
        action: MasterChangeAction.UPDATED,
        payload: row as any,
      },
    });

    return row;
  }

  async remove(accountId: string, userId: string, id: string) {
    const existing = await this.prisma.destination.findFirst({ where: { id, accountId } });
    if (!existing) throw new NotFoundException("Destination not found");

    await this.prisma.destination.delete({ where: { id } });

    await this.prisma.masterChangeEvent.create({
      data: {
        accountId,
        changedByUserId: userId,
        entityType: MasterEntityType.DESTINATION,
        entityId: id,
        action: MasterChangeAction.DELETED,
        payload: existing as any,
      },
    });

    return { ok: true };
  }
}
