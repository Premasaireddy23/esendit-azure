import { IsArray, IsEnum, IsOptional, IsString, IsUUID, IsObject } from "class-validator";
import { DestinationCategory, MasterStatus } from "@prisma/client";

export class CreateDestinationDto {
  @IsString() name!: string;
  @IsString() uri!: string;

  @IsOptional() @IsEnum(DestinationCategory) category?: DestinationCategory;
  @IsOptional() @IsString() destinationAccount?: string;
  @IsOptional() @IsUUID() countryId?: string;
  @IsOptional() @IsUUID() cityId?: string;
  @IsOptional() @IsEnum(MasterStatus) status?: MasterStatus;

  @IsOptional() @IsObject() config?: Record<string, any>;
  @IsOptional() @IsString() fileNameTemplate?: string;

  // optional presets used by the UI (stored as Json)
  @IsOptional() @IsArray()
  downloadPresets?: any[];
}

export class UpdateDestinationDto extends CreateDestinationDto {}
