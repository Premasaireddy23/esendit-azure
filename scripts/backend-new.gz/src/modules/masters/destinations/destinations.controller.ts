import { Body, Controller, Delete, Get, Param, Patch, Post, UseGuards } from "@nestjs/common";
import { DestinationsService } from "./destinations.service";
import { CreateDestinationDto, UpdateDestinationDto } from "./dto";
import { JwtAuthGuard } from "../../../common/auth/jwt-auth.guard";
import { PermissionsGuard } from "../../../common/auth/permissions.guard";
import { RequireAnyPermissions } from "../../../common/auth/require-any-permissions.decorator";
import { CurrentUser } from "../../../common/auth/current-user.decorator";

@Controller("masters/destinations")
@UseGuards(JwtAuthGuard, PermissionsGuard)
export class DestinationsController {
  constructor(private readonly svc: DestinationsService) {}

  @Get()
  @RequireAnyPermissions("page:masters:destinations", "MASTERS_READ")
  list(@CurrentUser() user: any) {
    return this.svc.list(user.accountId);
  }

  @Post()
  @RequireAnyPermissions("action:masters:destinations:create", "MASTERS_CREATE")
  create(@CurrentUser() user: any, @Body() dto: CreateDestinationDto) {
    return this.svc.create(user.accountId, user.id, dto);
  }

  @Patch(":id")
  @RequireAnyPermissions("action:masters:destinations:update", "MASTERS_UPDATE")
  update(@CurrentUser() user: any, @Param("id") id: string, @Body() dto: UpdateDestinationDto) {
    return this.svc.update(user.accountId, user.id, id, dto);
  }

  @Delete(":id")
  @RequireAnyPermissions("action:masters:destinations:delete", "MASTERS_DELETE")
  remove(@CurrentUser() user: any, @Param("id") id: string) {
    return this.svc.remove(user.accountId, user.id, id);
  }
}
