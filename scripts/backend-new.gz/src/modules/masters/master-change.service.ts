import { Injectable } from "@nestjs/common";
import { PrismaService } from "../../common/prisma/prisma.service";
import { MasterChangeAction, MasterEntityType, MasterStatus } from "@prisma/client";
import { PERM } from "../../common/auth/permission.registry";

type MasterChangeEventInput = {
  accountId: string;
  entityType: MasterEntityType;
  entityId: string;
  action: MasterChangeAction;
  changedByUserId: string;
  payload?: any;
};

@Injectable()
export class MasterChangeService {
  constructor(private prisma: PrismaService) {}

  async emit(evt: MasterChangeEventInput) {
    const row = await this.prisma.masterChangeEvent.create({
      data: {
        accountId: evt.accountId,
        entityType: evt.entityType,
        entityId: evt.entityId,
        action: evt.action,
        changedByUserId: evt.changedByUserId,
        payload: evt.payload ?? {},
      },
    });

    // Queue notification email (if email outbox is configured)
    await this.queueMasterChangeEmail(evt).catch(() => {
      // Never fail the request if email queuing fails
    });

    return row;
  }

  private emailConfigured(): boolean {
    // EmailOutbox worker uses these; if missing, skip queueing
    return Boolean(process.env.ACS_EMAIL_CONNECTION_STRING && process.env.ACS_EMAIL_FROM);
  }

  private async queueMasterChangeEmail(evt: MasterChangeEventInput) {
    if (!this.emailConfigured()) return;

    const isBillingMaster =
      evt.entityType === MasterEntityType.BILLABLE_PARTY || evt.entityType === MasterEntityType.RATE_CARD;

    const [adminEmails, financeEmails] = await Promise.all([
      this.resolveEmailsByPerms(evt.accountId, [
        PERM.MASTERS_CREATE,
        PERM.MASTERS_UPDATE,
        PERM.MASTERS_DELETE,
        PERM.ADMIN_USERS_READ,
        PERM.ADMIN_USERS_WRITE,
        PERM.ADMIN_ROLES_READ,
        PERM.ADMIN_ROLES_WRITE,
        PERM.ACCOUNT_SETTINGS_WRITE,
      ]),
      this.resolveEmailsByPerms(evt.accountId, [PERM.BILLING_CREATE, PERM.BILLING_UPDATE, PERM.BILLING_DELETE]),
    ]);

    const to = Array.from(
      new Set([
        ...adminEmails,
        ...(isBillingMaster ? financeEmails : []),
      ].map((e) => (e ?? "").trim()).filter(Boolean).map((e) => e.toLowerCase())),
    );

    if (!to.length) return;

    const actor = await this.prisma.user.findFirst({
      where: { accountId: evt.accountId, id: evt.changedByUserId },
      select: { email: true, displayName: true },
    });

    const label = await this.tryResolveEntityLabel(evt.accountId, evt.entityType, evt.entityId, evt.payload);

    const actionText = this.humanAction(evt.action, evt.payload);

    const subject = `[eSendIT] Master ${actionText}: ${evt.entityType}${label ? ` — ${label}` : ""}`;

    const when = new Date().toISOString();
    const actorLine = actor ? `${actor.displayName} <${actor.email}>` : evt.changedByUserId;

    const bodyLines = [
      `Master change detected (${when}).`,
      "",
      `AccountId: ${evt.accountId}`,
      `Changed by: ${actorLine}`,
      `Entity: ${evt.entityType}`,
      `Action: ${actionText}`,
      `EntityId: ${evt.entityId}`,
      ...(label ? [`Name: ${label}`] : []),
      "",
      "Payload:",
      JSON.stringify(evt.payload ?? {}, null, 2),
    ];

    const bodyText = bodyLines.join("\n");
    const bodyHtml = `<pre>${this.escapeHtml(bodyText)}</pre>`;

    await this.prisma.emailOutbox.create({
      data: {
        accountId: evt.accountId,
        eventType: "MASTER_CHANGE",
        to,
        subject,
        bodyText,
        bodyHtml,
        payload: {
          masterChange: {
            entityType: evt.entityType,
            entityId: evt.entityId,
            action: evt.action,
            payload: evt.payload ?? {},
          },
        },
      },
    });
  }

  private humanAction(action: MasterChangeAction, payload?: any): string {
    // Most deletes are implemented as status=INACTIVE updates
    if (payload && payload.status === MasterStatus.INACTIVE) return "Deleted";
    if (action === MasterChangeAction.CREATED) return "Added";
    if (action === MasterChangeAction.UPDATED) return "Updated";
    return String(action);
  }

  private async resolveEmailsByPerms(accountId: string, keys: string[]): Promise<string[]> {
    const users = await this.prisma.user.findMany({
      where: { accountId, isActive: true, userType: "INTERNAL" },
      select: {
        email: true,
        roles: {
          select: {
            role: {
              select: {
                perms: { select: { permission: { select: { key: true } } } },
              },
            },
          },
        },
      },
    });

    const wanted = new Set(keys);

    return users
      .filter((u) => {
        const perms = new Set<string>();
        for (const ur of u.roles) {
          for (const rp of ur.role.perms) {
            perms.add(rp.permission.key);
          }
        }
        for (const k of wanted) if (perms.has(k)) return true;
        return false;
      })
      .map((u) => u.email)
      .filter(Boolean);
  }

  private async tryResolveEntityLabel(accountId: string, entityType: MasterEntityType, entityId: string, payload?: any) {
    // Fast-path: many callers pass {name}
    if (payload && typeof payload.name === "string" && payload.name.trim()) return payload.name.trim();

    const map: Record<string, { model: keyof PrismaService; where: any; select: any } | null> = {
      ADVERTISER_GROUP: { model: "advertiserGroup" as any, where: { accountId, id: entityId }, select: { name: true } },
      ADVERTISER: { model: "advertiser" as any, where: { accountId, id: entityId }, select: { name: true } },
      BRAND: { model: "brand" as any, where: { accountId, id: entityId }, select: { name: true } },
      COUNTRY: { model: "country" as any, where: { accountId, id: entityId }, select: { name: true } },
      CITY: { model: "city" as any, where: { accountId, id: entityId }, select: { name: true } },
      PRODUCT_CATEGORY: { model: "productCategory" as any, where: { accountId, id: entityId }, select: { name: true } },
      AGENCY: { model: "agency" as any, where: { accountId, id: entityId }, select: { name: true, type: true } },
      AGENCY_TEAM: { model: "agencyTeam" as any, where: { accountId, id: entityId }, select: { name: true } },
      SLA: { model: "sla" as any, where: { accountId, id: entityId }, select: { name: true } },
      BILLABLE_PARTY: { model: "billableParty" as any, where: { accountId, id: entityId }, select: { name: true } },
      PARTNER_ACCOUNT: { model: "partnerAccount" as any, where: { accountId, id: entityId }, select: { name: true } },
      RATE_CARD: { model: "rateCard" as any, where: { accountId, id: entityId }, select: { name: true } },
      DESTINATION: { model: "destination" as any, where: { accountId, id: entityId }, select: { name: true } },
      CHANNEL: { model: "channel" as any, where: { accountId, id: entityId }, select: { name: true } },
      DELIVERY_PROFILE: { model: "deliveryProfile" as any, where: { accountId, id: entityId }, select: { name: true } },
      HOT_FOLDER: { model: "hotFolderConfig" as any, where: { accountId, id: entityId }, select: { name: true, sourceType: true } },
    };

    const key = String(entityType);
    const cfg = map[key];
    if (!cfg) return null;

    const row = await (this.prisma as any)[cfg.model].findFirst({ where: cfg.where, select: cfg.select });
    if (!row) return null;

    if (row.type) return `${row.name} (${row.type})`;
    if ((row as any).sourceType) return `${row.name} (${(row as any).sourceType})`;
    return row.name ?? null;
  }

  private escapeHtml(s: string): string {
    return s
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/\"/g, "&quot;");
  }
}
