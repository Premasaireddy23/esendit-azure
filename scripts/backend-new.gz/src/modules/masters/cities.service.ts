import { BadRequestException, Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../../common/prisma/prisma.service";
import { MasterChangeService } from "./master-change.service";
import { MasterChangeAction, MasterEntityType, MasterStatus } from "@prisma/client";
import { CreateCityDto, UpdateCityDto } from "./dto/city.dto";

@Injectable()
export class CitiesService {
  constructor(private prisma: PrismaService, private changes: MasterChangeService) {}

  async list(accountId: string, q?: string) {
    return this.prisma.city.findMany({
      where: { accountId, ...(q ? { name: { contains: q, mode: "insensitive" } } : {}) },
      orderBy: { name: "asc" },
    });
  }

  async get(accountId: string, id: string) {
    const row = await this.prisma.city.findFirst({ where: { accountId, id } });
    if (!row) throw new NotFoundException("City not found");
    return row;
  }

  async create(accountId: string, userId: string, dto: CreateCityDto) {
    const country = await this.prisma.country.findFirst({ where: { accountId, id: dto.countryId } });
    if (!country) throw new BadRequestException("Invalid countryId");

    const row = await this.prisma.city.create({
      data: {
        accountId,
        countryId: dto.countryId,
        name: dto.name,
        status: dto.status ?? MasterStatus.ACTIVE,
      },
    });

    await this.changes.emit({
      accountId,
      entityType: MasterEntityType.CITY,
      entityId: row.id,
      action: MasterChangeAction.CREATED,
      changedByUserId: userId,
      payload: { name: row.name },
    });

    return row;
  }

  async update(accountId: string, userId: string, id: string, dto: UpdateCityDto) {
    await this.get(accountId, id);

    if (dto.countryId) {
      const country = await this.prisma.country.findFirst({ where: { accountId, id: dto.countryId } });
      if (!country) throw new BadRequestException("Invalid countryId");
    }

    const row = await this.prisma.city.update({
      where: { id },
      data: {
        countryId: dto.countryId ?? undefined,
        name: dto.name ?? undefined,
        status: dto.status ?? undefined,
      },
    });

    await this.changes.emit({
      accountId,
      entityType: MasterEntityType.CITY,
      entityId: row.id,
      action: MasterChangeAction.UPDATED,
      changedByUserId: userId,
      payload: { name: row.name },
    });

    return row;
  }

  async remove(accountId: string, userId: string, id: string) {
    await this.get(accountId, id);

    const row = await this.prisma.city.update({
      where: { id },
      data: { status: MasterStatus.INACTIVE },
    });

    await this.changes.emit({
      accountId,
      entityType: MasterEntityType.CITY,
      entityId: row.id,
      action: MasterChangeAction.UPDATED,
      changedByUserId: userId,
      payload: { status: row.status },
    });

    return { ok: true };
  }
}
