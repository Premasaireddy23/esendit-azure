import { Body, Controller, Delete, Get, Param, Post, Put, Query, UseGuards } from "@nestjs/common";
import { JwtAuthGuard } from "../../common/auth/jwt-auth.guard";
import { PermissionsGuard } from "../../common/auth/permissions.guard";
import { RequirePermissions } from "../../common/auth/require-permissions.decorator";
import { CurrentUser } from "../../common/auth/current-user.decorator";
import { CitiesService } from "./cities.service";
import { CreateCityDto, UpdateCityDto } from "./dto/city.dto";

@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller("masters/cities")
export class CitiesController {
  constructor(private svc: CitiesService) {}

  @Get()
  @RequirePermissions("MASTERS_READ")
  list(@CurrentUser() u: any, @Query("q") q?: string) {
    return this.svc.list(u.accountId, q);
  }

  @Get(":id")
  @RequirePermissions("MASTERS_READ")
  get(@CurrentUser() u: any, @Param("id") id: string) {
    return this.svc.get(u.accountId, id);
  }

  @Post()
  @RequirePermissions("MASTERS_CREATE")
  create(@CurrentUser() u: any, @Body() dto: CreateCityDto) {
    return this.svc.create(u.accountId, u.userId ?? u.id, dto);
  }

  @Put(":id")
  @RequirePermissions("MASTERS_UPDATE")
  update(@CurrentUser() u: any, @Param("id") id: string, @Body() dto: UpdateCityDto) {
    return this.svc.update(u.accountId, u.userId ?? u.id, id, dto);
  }

  @Delete(":id")
  @RequirePermissions("MASTERS_DELETE")
  remove(@CurrentUser() u: any, @Param("id") id: string) {
    return this.svc.remove(u.accountId, u.userId ?? u.id, id);
  }
}
