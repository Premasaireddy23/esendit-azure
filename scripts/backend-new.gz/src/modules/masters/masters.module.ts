import { Module } from "@nestjs/common";
import { PrismaService } from "../../common/prisma/prisma.service";
import { MasterChangeService } from "./master-change.service";

import { AdvertiserGroupsController } from "./advertiser-groups.controller";
import { AdvertiserGroupsService } from "./advertiser-groups.service";
import { AdvertisersController } from "./advertisers.controller";
import { AdvertisersService } from "./advertisers.service";
import { BrandsController } from "./brands.controller";
import { BrandsService } from "./brands.service";
import { CountriesController } from "./countries.controller";
import { CountriesService } from "./countries.service";
import { CitiesController } from "./cities.controller";
import { CitiesService } from "./cities.service";
import { ProductCategoriesController } from "./product-categories.controller";
import { ProductCategoriesService } from "./product-categories.service";
import { AgenciesController } from "./agencies.controller";
import { AgenciesService } from "./agencies.service";
import { AgencyTeamsController } from "./agency-teams.controller";
import { AgencyTeamsService } from "./agency-teams.service";
import { SlasController } from "./slas.controller";
import { SlasService } from "./slas.service";
import { BillablePartiesController } from "./billable-parties.controller";
import { BillablePartiesService } from "./billable-parties.service";
import { RateCardsController } from "./rate-cards.controller";
import { RateCardsService } from "./rate-cards.service";
import { DestinationsController } from "./destinations/destinations.controller";
import { DestinationsService } from "./destinations/destinations.service";

import { ChannelsController } from "./channels/channels.controller";
import { ChannelsService } from "./channels/channels.service";

import { DeliveryProfilesController } from "./delivery-profiles/delivery-profiles.controller";
import { DeliveryProfilesService } from "./delivery-profiles/delivery-profiles.service";

import { HotFoldersController } from "./hot-folders.controller";
import { HotFoldersService } from "./hot-folders.service";
import { PartnerAccountsController } from "./partner-accounts.controller";
import { PartnerAccountsService } from "./partner-accounts.service";

@Module({
  controllers: [
    AdvertiserGroupsController,
    AdvertisersController,
    BrandsController,
    CountriesController,
    CitiesController,
    ProductCategoriesController,
    AgenciesController,
    AgencyTeamsController,
    SlasController,
    BillablePartiesController,
    RateCardsController,
    DestinationsController,
    ChannelsController,
    DeliveryProfilesController,
    HotFoldersController,
    PartnerAccountsController,
  ],
  providers: [
    PrismaService,
    MasterChangeService,
    AdvertiserGroupsService,
    AdvertisersService,
    BrandsService,
    CountriesService,
    CitiesService,
    ProductCategoriesService,
    AgenciesService,
    AgencyTeamsService,
    SlasService,
    BillablePartiesService,
    RateCardsService,
    DestinationsService,
    ChannelsService,
    DeliveryProfilesService,
    HotFoldersService,
    PartnerAccountsService,
  ],
})
export class MastersModule {}
