import { BadRequestException, Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../../common/prisma/prisma.service";
import { MasterChangeService } from "./master-change.service";
import { MasterChangeAction, MasterEntityType, MasterStatus, Prisma } from "@prisma/client";
import { CreateAdvertiserDto, UpdateAdvertiserDto } from "./dto/advertiser.dto";

@Injectable()
export class AdvertisersService {
  constructor(private prisma: PrismaService, private changes: MasterChangeService) {}

  private parseGstPan(input?: string | null): { gstNumber: string | null; panNumber: string | null } {
    const v = (input ?? "").trim();
    if (!v) return { gstNumber: null, panNumber: null };

    // common separators: "/", ",", "|"
    const parts = v.split(/\s*[\/\,|]\s*/).filter(Boolean);
    if (parts.length >= 2) return { gstNumber: parts[0] ?? null, panNumber: parts[1] ?? null };

    // fallback: store as GST (better than losing it)
    return { gstNumber: v, panNumber: null };
  }

  async list(accountId: string, q?: string, includeInactive = false) {
    return this.prisma.advertiser.findMany({
      where: {
        accountId,
        ...(q ? { name: { contains: q, mode: "insensitive" } } : {}),
        ...(includeInactive ? {} : { status: MasterStatus.ACTIVE }),
      },
      orderBy: { name: "asc" },
    });
  }

  async get(accountId: string, id: string) {
    const row = await this.prisma.advertiser.findFirst({ where: { accountId, id } });
    if (!row) throw new NotFoundException("Advertiser not found");
    return row;
  }

  async create(accountId: string, userId: string, dto: CreateAdvertiserDto) {
    if (dto.advertiserGroupId) {
      const grp = await this.prisma.advertiserGroup.findFirst({ where: { accountId, id: dto.advertiserGroupId } });
      if (!grp) throw new BadRequestException("Invalid advertiserGroupId");
    }

    const tax = dto.gstNumber || dto.panNumber ? { gstNumber: dto.gstNumber ?? null, panNumber: dto.panNumber ?? null } : this.parseGstPan(dto.gstPan);

    const row = await this.prisma.advertiser.create({
      data: {
        accountId,
        advertiserGroupId: dto.advertiserGroupId ?? null,
        name: dto.name,
        emails: dto.emails ?? [],
        contactNo: dto.contactNo ?? null,
        gstNumber: tax.gstNumber,
        panNumber: tax.panNumber,
        address: dto.address ?? null,
        remarks: dto.remarks ?? null,
        status: dto.status ?? MasterStatus.ACTIVE,
      },
    });

    await this.changes.emit({
      accountId,
      entityType: MasterEntityType.ADVERTISER,
      entityId: row.id,
      action: MasterChangeAction.CREATED,
      changedByUserId: userId,
      payload: { name: row.name },
    });

    return row;
  }

  async update(accountId: string, userId: string, id: string, dto: UpdateAdvertiserDto) {
    await this.get(accountId, id);

    if (dto.advertiserGroupId) {
      const grp = await this.prisma.advertiserGroup.findFirst({ where: { accountId, id: dto.advertiserGroupId } });
      if (!grp) throw new BadRequestException("Invalid advertiserGroupId");
    }

    const data: any = {};
    if (dto.advertiserGroupId !== undefined) data.advertiserGroupId = dto.advertiserGroupId;
    if (dto.name !== undefined) data.name = dto.name;
    if (dto.emails !== undefined) data.emails = dto.emails;
    if (dto.contactNo !== undefined) data.contactNo = dto.contactNo;
    if (dto.address !== undefined) data.address = dto.address;
    if (dto.remarks !== undefined) data.remarks = dto.remarks;
    if (dto.status !== undefined) data.status = dto.status;

    // Support either gstNumber/panNumber OR deprecated gstPan
    const tax =
      dto.gstNumber !== undefined || dto.panNumber !== undefined
        ? { gstNumber: dto.gstNumber ?? null, panNumber: dto.panNumber ?? null }
        : dto.gstPan !== undefined
          ? this.parseGstPan(dto.gstPan)
          : null;

    if (tax) {
      data.gstNumber = tax.gstNumber;
      data.panNumber = tax.panNumber;
    }

    const row = await this.prisma.advertiser.update({ where: { id }, data });

    await this.changes.emit({
      accountId,
      entityType: MasterEntityType.ADVERTISER,
      entityId: row.id,
      action: MasterChangeAction.UPDATED,
      changedByUserId: userId,
      payload: { name: row.name },
    });

    return row;
  }

  async enable(accountId: string, userId: string, id: string) {
    await this.get(accountId, id);

    const row = await this.prisma.advertiser.update({
      where: { id },
      data: { status: MasterStatus.ACTIVE },
    });

    await this.changes.emit({
      accountId,
      entityType: MasterEntityType.ADVERTISER,
      entityId: row.id,
      action: MasterChangeAction.UPDATED,
      changedByUserId: userId,
      payload: { status: row.status },
    });

    return row;
  }

  async permanentRemove(accountId: string, userId: string, id: string) {
    const existing = await this.get(accountId, id);
    if (existing.status !== MasterStatus.INACTIVE) throw new BadRequestException("Only inactive items can be permanently deleted");

    try {
      await this.prisma.advertiser.delete({ where: { id } });
    } catch (e) {
      if (e instanceof Prisma.PrismaClientKnownRequestError && ["P2003", "P2014"].includes(e.code)) {
        throw new BadRequestException("Cannot permanently delete this item because it is referenced by existing records");
      }
      throw e;
    }

    await this.changes.emit({
      accountId,
      entityType: MasterEntityType.ADVERTISER,
      entityId: id,
      action: MasterChangeAction.DELETED,
      changedByUserId: userId,
      payload: existing,
    });

    return { ok: true };
  }

  async remove(accountId: string, userId: string, id: string) {
    await this.get(accountId, id);

    const row = await this.prisma.advertiser.update({
      where: { id },
      data: { status: MasterStatus.INACTIVE },
    });

    await this.changes.emit({
      accountId,
      entityType: MasterEntityType.ADVERTISER,
      entityId: row.id,
      action: MasterChangeAction.UPDATED,
      changedByUserId: userId,
      payload: { status: row.status },
    });

    return { ok: true };
  }
}
