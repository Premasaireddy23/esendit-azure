import { Body, Controller, Delete, Get, Param, Post, Put, Query, UseGuards } from "@nestjs/common";
import { JwtAuthGuard } from "../../common/auth/jwt-auth.guard";
import { PermissionsGuard } from "../../common/auth/permissions.guard";
import { RequirePermissions } from "../../common/auth/require-permissions.decorator";
import { CurrentUser } from "../../common/auth/current-user.decorator";
import { CountriesService } from "./countries.service";
import { CreateCountryDto, UpdateCountryDto } from "./dto/country.dto";

@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller("masters/countries")
export class CountriesController {
  constructor(private svc: CountriesService) {}

  @Get()
  @RequirePermissions("MASTERS_READ")
  list(@CurrentUser() u: any, @Query("q") q?: string) {
    return this.svc.list(u.accountId, q);
  }

  @Get(":id")
  @RequirePermissions("MASTERS_READ")
  get(@CurrentUser() u: any, @Param("id") id: string) {
    return this.svc.get(u.accountId, id);
  }

  @Post()
  @RequirePermissions("MASTERS_CREATE")
  create(@CurrentUser() u: any, @Body() dto: CreateCountryDto) {
    return this.svc.create(u.accountId, u.userId ?? u.id, dto);
  }

  @Put(":id")
  @RequirePermissions("MASTERS_UPDATE")
  update(@CurrentUser() u: any, @Param("id") id: string, @Body() dto: UpdateCountryDto) {
    return this.svc.update(u.accountId, u.userId ?? u.id, id, dto);
  }

  @Delete(":id")
  @RequirePermissions("MASTERS_DELETE")
  remove(@CurrentUser() u: any, @Param("id") id: string) {
    return this.svc.remove(u.accountId, u.userId ?? u.id, id);
  }
}
