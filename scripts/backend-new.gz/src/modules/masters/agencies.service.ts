import { BadRequestException, Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../../common/prisma/prisma.service";
import { MasterChangeService } from "./master-change.service";
import { AgencyType, MasterChangeAction, MasterEntityType, MasterStatus, Prisma } from "@prisma/client";
import { CreateAgencyDto, UpdateAgencyDto } from "./dto/agency.dto";

@Injectable()
export class AgenciesService {
  constructor(private prisma: PrismaService, private changes: MasterChangeService) {}

  // `type` is optional because some UIs need to fetch all agencies (e.g. when selecting
  // an agency in the Agency Team create form).
  async list(accountId: string, q?: string, type?: AgencyType) {
    return this.prisma.agency.findMany({
      where: {
        accountId,
        ...(type ? { type } : {}),
        ...(q ? { name: { contains: q, mode: "insensitive" } } : {}),
      },
      orderBy: { name: "asc" },
      include: { teams: { orderBy: { name: "asc" } } },
    });
  }

  async get(accountId: string, id: string) {
    const row = await this.prisma.agency.findFirst({ where: { accountId, id }, include: { teams: true } });
    if (!row) throw new NotFoundException("Agency not found");
    return row;
  }

  async create(accountId: string, userId: string, dto: CreateAgencyDto) {
    const row = await this.prisma.agency.create({
      data: {
        accountId,
        type: dto.type,
        name: dto.name,
        emails: dto.emails ?? [],
        contactNo: dto.contactNo ?? null,
        address: dto.address ?? null,
        remarks: dto.remarks ?? null,
        gstNumber: dto.gstNumber ?? null,
        panNumber: dto.panNumber ?? null,
        status: dto.status ?? MasterStatus.ACTIVE,
        teams:
          dto.teams && dto.teams.length
            ? {
                create: dto.teams.map((t) => ({
                  accountId,
                  name: t.name,
                  emails: t.emails ?? [],
                  contactNo: t.contactNo ?? null,
                  address: t.address ?? null,
                  remarks: t.remarks ?? null,
                  gstNumber: t.gstNumber ?? null,
                  panNumber: t.panNumber ?? null,
                  status: t.status ?? MasterStatus.ACTIVE,
                })),
              }
            : undefined,
      },
      include: { teams: true },
    });

    await this.changes.emit({
      accountId,
      entityType: MasterEntityType.AGENCY,
      entityId: row.id,
      action: MasterChangeAction.CREATED,
      changedByUserId: userId,
      payload: { name: row.name },
    });

    return row;
  }

  async update(accountId: string, userId: string, id: string, dto: UpdateAgencyDto) {
    await this.get(accountId, id);

    const data: any = {};
    if (dto.type !== undefined) data.type = dto.type;
    if (dto.name !== undefined) data.name = dto.name;
    if (dto.emails !== undefined) data.emails = dto.emails;
    if (dto.contactNo !== undefined) data.contactNo = dto.contactNo;
    if (dto.address !== undefined) data.address = dto.address;
    if (dto.remarks !== undefined) data.remarks = dto.remarks;
    if (dto.gstNumber !== undefined) data.gstNumber = dto.gstNumber;
    if (dto.panNumber !== undefined) data.panNumber = dto.panNumber;
    if (dto.status !== undefined) data.status = dto.status;

    const row = await this.prisma.agency.update({ where: { id }, data });

    await this.changes.emit({
      accountId,
      entityType: MasterEntityType.AGENCY,
      entityId: row.id,
      action: MasterChangeAction.UPDATED,
      changedByUserId: userId,
      payload: { name: row.name },
    });

    return row;
  }

  async enable(accountId: string, userId: string, id: string) {
    await this.get(accountId, id);

    const row = await this.prisma.agency.update({
      where: { id },
      data: { status: MasterStatus.ACTIVE },
    });

    await this.changes.emit({
      accountId,
      entityType: MasterEntityType.AGENCY,
      entityId: row.id,
      action: MasterChangeAction.UPDATED,
      changedByUserId: userId,
      payload: { status: row.status },
    });

    return row;
  }

  async permanentRemove(accountId: string, userId: string, id: string) {
    const existing = await this.get(accountId, id);
    if (existing.status !== MasterStatus.INACTIVE) throw new BadRequestException("Only inactive agencies can be permanently deleted");

    try {
      await this.prisma.agency.delete({ where: { id } });
    } catch (e) {
      if (e instanceof Prisma.PrismaClientKnownRequestError && ["P2003", "P2014"].includes(e.code)) {
        throw new BadRequestException("Cannot permanently delete this agency because it is referenced by existing records");
      }
      throw e;
    }

    await this.changes.emit({
      accountId,
      entityType: MasterEntityType.AGENCY,
      entityId: id,
      action: MasterChangeAction.DELETED,
      changedByUserId: userId,
      payload: existing,
    });

    return { ok: true };
  }

  async remove(accountId: string, userId: string, id: string) {
    await this.get(accountId, id);

    const row = await this.prisma.agency.update({
      where: { id },
      data: { status: MasterStatus.INACTIVE },
    });

    // Teams remain for history; they can be disabled separately.

    await this.changes.emit({
      accountId,
      entityType: MasterEntityType.AGENCY,
      entityId: row.id,
      action: MasterChangeAction.UPDATED,
      changedByUserId: userId,
      payload: { status: row.status },
    });

    return { ok: true };
  }
}
