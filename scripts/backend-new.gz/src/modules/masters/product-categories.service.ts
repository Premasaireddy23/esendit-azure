import { BadRequestException, Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../../common/prisma/prisma.service";
import { MasterChangeService } from "./master-change.service";
import { MasterChangeAction, MasterEntityType, MasterStatus, Prisma } from "@prisma/client";
import { CreateProductCategoryDto, UpdateProductCategoryDto } from "./dto/product-category.dto";

@Injectable()
export class ProductCategoriesService {
  constructor(private prisma: PrismaService, private changes: MasterChangeService) {}

  async list(accountId: string, q?: string, includeInactive = false) {
    return this.prisma.productCategory.findMany({
      where: { accountId, ...(q ? { name: { contains: q, mode: "insensitive" } } : {}), ...(includeInactive ? {} : { status: MasterStatus.ACTIVE }) },
      orderBy: { name: "asc" },
    });
  }

  async get(accountId: string, id: string) {
    const row = await this.prisma.productCategory.findFirst({ where: { accountId, id } });
    if (!row) throw new NotFoundException("Product category not found");
    return row;
  }

  async create(accountId: string, userId: string, dto: CreateProductCategoryDto) {
    const row = await this.prisma.productCategory.create({
      data: {
        accountId,
        name: dto.name,
        status: dto.status ?? MasterStatus.ACTIVE,
      },
    });

    await this.changes.emit({
      accountId,
      entityType: MasterEntityType.PRODUCT_CATEGORY,
      entityId: row.id,
      action: MasterChangeAction.CREATED,
      changedByUserId: userId,
      payload: { name: row.name },
    });

    return row;
  }

  async update(accountId: string, userId: string, id: string, dto: UpdateProductCategoryDto) {
    await this.get(accountId, id);

    const row = await this.prisma.productCategory.update({
      where: { id },
      data: {
        name: dto.name ?? undefined,
        status: dto.status ?? undefined,
      },
    });

    await this.changes.emit({
      accountId,
      entityType: MasterEntityType.PRODUCT_CATEGORY,
      entityId: row.id,
      action: MasterChangeAction.UPDATED,
      changedByUserId: userId,
      payload: { name: row.name },
    });

    return row;
  }

  async enable(accountId: string, userId: string, id: string) {
    await this.get(accountId, id);

    const row = await this.prisma.productCategory.update({
      where: { id },
      data: { status: MasterStatus.ACTIVE },
    });

    await this.changes.emit({
      accountId,
      entityType: MasterEntityType.PRODUCT_CATEGORY,
      entityId: row.id,
      action: MasterChangeAction.UPDATED,
      changedByUserId: userId,
      payload: { status: row.status },
    });

    return row;
  }

  async permanentRemove(accountId: string, userId: string, id: string) {
    const existing = await this.get(accountId, id);
    if (existing.status !== MasterStatus.INACTIVE) throw new BadRequestException("Only inactive items can be permanently deleted");

    try {
      await this.prisma.productCategory.delete({ where: { id } });
    } catch (e) {
      if (e instanceof Prisma.PrismaClientKnownRequestError && ["P2003", "P2014"].includes(e.code)) {
        throw new BadRequestException("Cannot permanently delete this item because it is referenced by existing records");
      }
      throw e;
    }

    await this.changes.emit({
      accountId,
      entityType: MasterEntityType.PRODUCT_CATEGORY,
      entityId: id,
      action: MasterChangeAction.DELETED,
      changedByUserId: userId,
      payload: existing,
    });

    return { ok: true };
  }

  async remove(accountId: string, userId: string, id: string) {
    await this.get(accountId, id);

    const row = await this.prisma.productCategory.update({
      where: { id },
      data: { status: MasterStatus.INACTIVE },
    });

    await this.changes.emit({
      accountId,
      entityType: MasterEntityType.PRODUCT_CATEGORY,
      entityId: row.id,
      action: MasterChangeAction.UPDATED,
      changedByUserId: userId,
      payload: { status: row.status },
    });

    return { ok: true };
  }
}
