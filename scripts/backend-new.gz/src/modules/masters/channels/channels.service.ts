import { BadRequestException, Injectable, NotFoundException } from "@nestjs/common";
import { ApprovalTemplateMode } from "@prisma/client";
import { PrismaService } from "../../../common/prisma/prisma.service";
import { channelSelect } from "../../../common/prisma/selects";
import { CHANNEL_ALIGNMENT_VALUES, type ChannelAlignment, CreateChannelDto, UpdateChannelDto } from "./dto";

function uniqEmails(v?: string[]) {
  return Array.from(new Set((v ?? []).map((x) => String(x || "").trim().toLowerCase()).filter(Boolean)));
}

type PresetDef = {
  key: string;
  label?: string;
  ext?: string;
  mimeType?: string;
  args?: string[];
  steps?: any[];
};

function parsePresets(downloadPresets: any): PresetDef[] {
  return Array.isArray(downloadPresets) ? (downloadPresets as PresetDef[]) : [];
}

function pickPresetsByKeys(all: PresetDef[], keys: any): PresetDef[] {
  const list = Array.isArray(keys) ? keys.map((k) => String(k).trim()).filter(Boolean) : [];
  if (!list.length) return [];
  const map = new Map(all.map((p) => [p.key, p] as const));
  const seen = new Set<string>();
  const out: PresetDef[] = [];
  for (const k of list) {
    if (seen.has(k)) continue;
    const p = map.get(k);
    if (!p) continue;
    out.push(p);
    seen.add(k);
  }
  return out;
}

function normalizeAlignment(v: any): ChannelAlignment | null {
  const raw = String(v ?? "").trim().toUpperCase();
  return (CHANNEL_ALIGNMENT_VALUES as readonly string[]).includes(raw) ? (raw as ChannelAlignment) : null;
}

function normalizeDefaultPresetKey(v: any): string | null {
  const raw = String(v ?? "").trim();
  return raw || null;
}

function normalizeTranscodeOnCommit(v: any): boolean | null {
  if (v === true || v === "true" || v === 1 || v === "1") return true;
  if (v === false || v === "false" || v === 0 || v === "0") return false;
  return null;
}

function mergeChannelConfig(existing: any, incoming: any, alignment: any, defaultPresetKey: any, transcodeOnCommit: any) {
  const base = incoming && typeof incoming === "object" ? { ...incoming } : existing && typeof existing === "object" ? { ...existing } : {};
  if (alignment !== undefined) {
    const normalizedAlignment = normalizeAlignment(alignment);
    if (normalizedAlignment) base.alignment = normalizedAlignment;
    else delete base.alignment;
  } else if (base.alignment != null) {
    const normalizedExisting = normalizeAlignment(base.alignment);
    if (normalizedExisting) base.alignment = normalizedExisting;
    else delete base.alignment;
  }
  if (defaultPresetKey !== undefined) {
    const normalizedPresetKey = normalizeDefaultPresetKey(defaultPresetKey);
    if (normalizedPresetKey) base.defaultPresetKey = normalizedPresetKey;
    else delete base.defaultPresetKey;
  } else if (base.defaultPresetKey != null) {
    const normalizedExistingPresetKey = normalizeDefaultPresetKey(base.defaultPresetKey);
    if (normalizedExistingPresetKey) base.defaultPresetKey = normalizedExistingPresetKey;
    else delete base.defaultPresetKey;
  }
  if (transcodeOnCommit !== undefined) {
    const normalizedTranscodeOnCommit = normalizeTranscodeOnCommit(transcodeOnCommit);
    if (normalizedTranscodeOnCommit === null) delete base.transcodeOnCommit;
    else base.transcodeOnCommit = normalizedTranscodeOnCommit;
  } else if (base.transcodeOnCommit != null) {
    const normalizedExistingTranscodeOnCommit = normalizeTranscodeOnCommit(base.transcodeOnCommit);
    if (normalizedExistingTranscodeOnCommit === null) delete base.transcodeOnCommit;
    else base.transcodeOnCommit = normalizedExistingTranscodeOnCommit;
  } else {
    base.transcodeOnCommit = true;
  }
  return Object.keys(base).length ? base : undefined;
}

type ApprovalStepCfg = {
  order: number;
  teamName?: string | null;
  label?: string | null;
  approverEmails: string[];
  ccEmails: string[];
};

function toStepCfg(input: any, idx: number): ApprovalStepCfg | null {
  if (!input || typeof input !== "object") return null;

  const orderRaw = input.order;
  const order = Number.isFinite(orderRaw) ? Number(orderRaw) : idx + 1;

  const teamName = String(input.teamName ?? "").trim() || null;
  const label = String(input.label ?? "").trim() || null;

  // Support a few keys to be forgiving:
  // - approverEmails (preferred)
  // - to / emails (legacy)
  const approverEmails = uniqEmails(input.approverEmails ?? input.to ?? input.emails ?? []);
  const ccEmails = uniqEmails(input.ccEmails ?? input.cc ?? []);

  if (!approverEmails.length && !ccEmails.length) return null;

  return { order: Math.max(1, order), teamName, label, approverEmails, ccEmails };
}

function approvalsConfig(dto: {
  approverMode?: ApprovalTemplateMode;
  approverEmails?: string[];
  approvalSteps?: any[];
}) {
  const mode = dto.approverMode ?? ApprovalTemplateMode.PARALLEL;

  // NEW: multi-step config
  if (Array.isArray(dto.approvalSteps)) {
    const steps = dto.approvalSteps
      .map((s, idx) => toStepCfg(s, idx))
      .filter(Boolean) as ApprovalStepCfg[];

    steps.sort((a, b) => a.order - b.order);

    if (!steps.length) return null;

    const emails = uniqEmails(steps.flatMap((s) => s.approverEmails));
    return { mode, steps, emails };
  }

  // Legacy single list
  const emails = uniqEmails(dto.approverEmails);
  if (!emails.length) return null;

  const steps: ApprovalStepCfg[] = [{ order: 1, teamName: "Approvals", label: null, approverEmails: emails, ccEmails: [] }];
  return { mode, steps, emails };
}

@Injectable()
export class ChannelsService {
  constructor(private prisma: PrismaService) {}

  private async resolvePresetLibrary(accountId: string, destinationId?: string | null): Promise<PresetDef[]> {
    const a = await this.prisma.account.findFirst({
      where: { id: accountId },
      select: { downloadPresets: true } as any,
    });
    const library = parsePresets((a as any)?.downloadPresets);
    if (!destinationId) return library;

    const d = await this.prisma.destination.findFirst({
      where: { id: destinationId, accountId },
      select: { downloadPresets: true, config: true },
    });

    const destinationPresets = parsePresets((d as any)?.downloadPresets);
    if (destinationPresets.length) return destinationPresets;

    const filtered = pickPresetsByKeys(library, (d as any)?.config?.allowedPresetKeys);
    return filtered.length ? filtered : library;
  }

  private async validateDefaultPresetKey(accountId: string, destinationId: string | null | undefined, presetKey: string | null) {
    const normalizedPresetKey = normalizeDefaultPresetKey(presetKey);
    if (!normalizedPresetKey) return null;

    const library = await this.resolvePresetLibrary(accountId, destinationId);
    if (!library.find((p) => p.key === normalizedPresetKey)) {
      throw new BadRequestException("Invalid defaultPresetKey for this destination");
    }

    return normalizedPresetKey;
  }

  private mapRow(r: any) {
    const cfg = (r.approvalsConfig ?? null) as any;
    const steps: ApprovalStepCfg[] = Array.isArray(cfg?.steps)
      ? (cfg.steps
          .map((s: any, idx: number) => toStepCfg(s, idx))
          .filter(Boolean) as ApprovalStepCfg[])
      : [];

    const legacyEmails: string[] = Array.isArray(cfg?.emails) ? uniqEmails(cfg.emails) : [];

    const approvalSteps = steps.length
      ? steps.sort((a, b) => a.order - b.order)
      : legacyEmails.length
        ? [{ order: 1, teamName: "Approvals", label: null, approverEmails: legacyEmails, ccEmails: [] }]
        : [];

    const flattenedApproverEmails = uniqEmails(approvalSteps.flatMap((s) => s.approverEmails));

    return {
      id: r.id,
      name: r.name,
      destinationId: r.destinationId ?? null,

      destination: r.destination ?? null,

      // keep frontend compatibility:
      mainProfileId: r.mainDeliveryProfileId ?? null,
      backupProfileId: r.backupDeliveryProfileId ?? null,

      mainDeliveryProfile: r.mainDeliveryProfile ?? null,
      backupDeliveryProfile: r.backupDeliveryProfile ?? null,

      notificationEmails: r.notificationEmails ?? [],

      alignment: normalizeAlignment(r.config?.alignment),
      defaultPresetKey: normalizeDefaultPresetKey(r.config?.defaultPresetKey),
      transcodeOnCommit: normalizeTranscodeOnCommit(r.config?.transcodeOnCommit) ?? true,
      config: r.config ?? {},

      // legacy fields (still returned for existing UI)
      approverMode: cfg?.mode ?? ApprovalTemplateMode.PARALLEL,
      approverEmails: flattenedApproverEmails,

      // NEW field
      approvalSteps,

      serverStatus: r.serverStatus ?? "UNKNOWN",
      serverCheckedAt: r.serverCheckedAt ?? null,
      serverLatencyMs: r.serverLatencyMs ?? null,
      serverMessage: r.serverMessage ?? null,
    };
  }

  async list(accountId: string, destinationId?: string) {
    const rows = await this.prisma.channel.findMany({
      where: {
        accountId,
        ...(destinationId
          ? destinationId === 'UNASSIGNED'
            ? { destinationId: null }
            : { destinationId }
          : {}),
      },
      orderBy: { name: "asc" },
      select: channelSelect,
    });
    return rows.map((r) => this.mapRow(r));
  }

  async create(accountId: string, dto: CreateChannelDto) {
    if (!dto.name?.trim()) throw new BadRequestException("name required");

    if (dto.destinationId) {
      const ok = await this.prisma.destination.findFirst({
        where: { accountId, id: dto.destinationId },
        select: { id: true },
      });
      if (!ok) throw new BadRequestException("Invalid destinationId");
    }

    const profileIds = [dto.mainProfileId, dto.backupProfileId].filter(Boolean) as string[];
    if (profileIds.length) {
      const cnt = await this.prisma.deliveryProfile.count({ where: { accountId, id: { in: profileIds } } });
      if (cnt !== profileIds.length) throw new BadRequestException("Invalid delivery profile id(s)");
    }

    const defaultPresetKey = await this.validateDefaultPresetKey(
      accountId,
      dto.destinationId ?? null,
      dto.defaultPresetKey ?? (dto?.config as any)?.defaultPresetKey ?? null,
    );
    const safeConfig = mergeChannelConfig(
      undefined,
      dto?.config && typeof dto.config === "object" ? (dto.config as any) : undefined,
      dto.alignment,
      defaultPresetKey,
      dto.transcodeOnCommit,
    );

    const created = await this.prisma.channel.create({
      data: {
        accountId,
        name: dto.name.trim(),
        ...(safeConfig ? { config: safeConfig } : {}),
        destinationId: dto.destinationId ?? null,
        mainDeliveryProfileId: dto.mainProfileId ?? null,
        backupDeliveryProfileId: dto.backupProfileId ?? null,
        notificationEmails: uniqEmails(dto.notificationEmails),
        approvalsConfig: approvalsConfig(dto as any),
      },
    });

    const row = await this.prisma.channel.findFirst({
      where: { id: created.id, accountId },
      select: channelSelect,
    });

    return this.mapRow(row);
  }

  async update(accountId: string, id: string, dto: UpdateChannelDto) {
    const existingRow = await this.prisma.channel.findFirst({ where: { id, accountId }, select: { id: true, config: true, destinationId: true } });
    const exists = existingRow ? { id: existingRow.id } : null;
    if (!exists) throw new NotFoundException("Channel not found");

    if (dto.destinationId) {
      const ok = await this.prisma.destination.findFirst({
        where: { accountId, id: dto.destinationId },
        select: { id: true },
      });
      if (!ok) throw new BadRequestException("Invalid destinationId");
    }

    const profileIds = [dto.mainProfileId, dto.backupProfileId].filter(Boolean) as string[];
    if (profileIds.length) {
      const cnt = await this.prisma.deliveryProfile.count({ where: { accountId, id: { in: profileIds } } });
      if (cnt !== profileIds.length) throw new BadRequestException("Invalid delivery profile id(s)");
    }

    const effectiveDestinationId = dto.destinationId !== undefined ? dto.destinationId ?? null : existingRow?.destinationId ?? null;
    const defaultPresetKeyInput = dto.defaultPresetKey !== undefined
      ? dto.defaultPresetKey
      : dto?.config && typeof dto.config === "object" && Object.prototype.hasOwnProperty.call(dto.config, "defaultPresetKey")
        ? (dto.config as any).defaultPresetKey
        : (existingRow?.config as any)?.defaultPresetKey ?? null;
    const defaultPresetKey = await this.validateDefaultPresetKey(accountId, effectiveDestinationId, defaultPresetKeyInput);
    const safeConfig = mergeChannelConfig(
      existingRow?.config,
      dto?.config && typeof dto.config === "object" ? (dto.config as any) : undefined,
      dto.alignment,
      defaultPresetKeyInput !== undefined ? defaultPresetKey : undefined,
      dto.transcodeOnCommit,
    );

    const data: any = {};
    if (dto.name !== undefined) data.name = dto.name?.trim();
    if (dto.destinationId !== undefined) data.destinationId = dto.destinationId;
    if (dto.mainProfileId !== undefined) data.mainDeliveryProfileId = dto.mainProfileId;
    if (dto.backupProfileId !== undefined) data.backupDeliveryProfileId = dto.backupProfileId;
    if (dto.notificationEmails !== undefined) data.notificationEmails = uniqEmails(dto.notificationEmails);
    if (dto.config !== undefined || dto.alignment !== undefined || dto.defaultPresetKey !== undefined || dto.transcodeOnCommit !== undefined) data.config = safeConfig ?? {};

    if (dto.approverMode !== undefined || dto.approverEmails !== undefined || (dto as any).approvalSteps !== undefined) {
      data.approvalsConfig = approvalsConfig(dto as any);
    }

    const updated = await this.prisma.channel.update({ where: { id }, data });

    const row = await this.prisma.channel.findFirst({ where: { id: updated.id, accountId }, select: channelSelect });
    return this.mapRow(row);
  }

  async remove(accountId: string, id: string) {
    const exists = await this.prisma.channel.findFirst({ where: { id, accountId }, select: { id: true } });
    if (!exists) throw new NotFoundException("Channel not found");

    const used = await this.prisma.planLine.count({ where: { accountId, channelId: id } });
    if (used > 0) throw new BadRequestException("Channel is used by plan lines; cannot delete");

    await this.prisma.channel.delete({ where: { id } });
    return { ok: true };
  }
}
