import { Type } from "class-transformer";
import { IsArray, IsBoolean, IsEmail, IsEnum, IsInt, IsOptional, IsString, IsUUID, Min, ValidateNested } from "class-validator";
import { ApprovalTemplateMode } from "@prisma/client";

export const CHANNEL_ALIGNMENT_VALUES = ["LHS", "RHS", "BLHS", "BRHS"] as const;
export type ChannelAlignment = (typeof CHANNEL_ALIGNMENT_VALUES)[number];

export class ApprovalStepDto {
  @IsOptional() @IsInt() @Min(1)
  order?: number;

  // Team name / label shown in UI and emails
  @IsOptional() @IsString()
  teamName?: string;

  @IsOptional() @IsString()
  label?: string;

  // Primary recipients for this approval step
  @IsOptional() @IsArray() @IsEmail({}, { each: true })
  approverEmails?: string[];

  // Optional CC list
  @IsOptional() @IsArray() @IsEmail({}, { each: true })
  ccEmails?: string[];
}

export class CreateChannelDto {
  @IsString() name!: string;

  @IsOptional() @IsUUID() destinationId?: string | null;

  // frontend keys (ChannelsPage)
  @IsOptional() @IsUUID() mainProfileId?: string | null;
  @IsOptional() @IsUUID() backupProfileId?: string | null;

  @IsOptional() @IsArray() @IsEmail({}, { each: true })
  notificationEmails?: string[];

  @IsOptional() @IsEnum(CHANNEL_ALIGNMENT_VALUES)
  alignment?: ChannelAlignment;

  @IsOptional() @IsString()
  defaultPresetKey?: string | null;

  @IsOptional() @IsBoolean()
  transcodeOnCommit?: boolean | null;

  // Advanced channel config (JSON). Used for features like XML metadata sidecar.
  @IsOptional()
  config?: any;

  @IsOptional() @IsEnum(ApprovalTemplateMode)
  approverMode?: ApprovalTemplateMode;

  // legacy single-list approvals
  @IsOptional() @IsArray() @IsEmail({}, { each: true })
  approverEmails?: string[];

  // NEW: multi-step approval routing per channel (Team name + email ids per step)
  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => ApprovalStepDto)
  approvalSteps?: ApprovalStepDto[];
}

export class UpdateChannelDto {
  @IsOptional() @IsString()
  name?: string;

  @IsOptional() @IsUUID() destinationId?: string | null;

  @IsOptional() @IsUUID() mainProfileId?: string | null;
  @IsOptional() @IsUUID() backupProfileId?: string | null;

  @IsOptional() @IsArray() @IsEmail({}, { each: true })
  notificationEmails?: string[];

  @IsOptional() @IsEnum(CHANNEL_ALIGNMENT_VALUES)
  alignment?: ChannelAlignment;

  @IsOptional() @IsString()
  defaultPresetKey?: string | null;

  @IsOptional() @IsBoolean()
  transcodeOnCommit?: boolean | null;

  @IsOptional()
  config?: any;

  @IsOptional() @IsEnum(ApprovalTemplateMode)
  approverMode?: ApprovalTemplateMode;

  @IsOptional() @IsArray() @IsEmail({}, { each: true })
  approverEmails?: string[];

  @IsOptional()
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => ApprovalStepDto)
  approvalSteps?: ApprovalStepDto[];
}
