import { Body, Controller, Delete, Get, Param, Patch, Post, Query, UseGuards } from "@nestjs/common";
import { JwtAuthGuard } from "../../../common/auth/jwt-auth.guard";
import { PermissionsGuard } from "../../../common/auth/permissions.guard";
import { RequireAnyPermissions } from "../../../common/auth/require-any-permissions.decorator";
import { CurrentUser } from "../../../common/auth/current-user.decorator";
import { ChannelsService } from "./channels.service";
import { CreateChannelDto, UpdateChannelDto } from "./dto";

@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller("masters/channels")
export class ChannelsController {
  constructor(private svc: ChannelsService) {}

  @Get()
  @RequireAnyPermissions("page:masters:channels", "MASTERS_READ")
  list(@CurrentUser() u: any, @Query("destinationId") destinationId?: string) {
    return this.svc.list(u.accountId, destinationId);
  }

  @Post()
  @RequireAnyPermissions("action:masters:channels:create", "MASTERS_CREATE")
  create(@CurrentUser() u: any, @Body() dto: CreateChannelDto) {
    return this.svc.create(u.accountId, dto);
  }

  @Patch(":id")
  @RequireAnyPermissions("action:masters:channels:update", "MASTERS_UPDATE")
  update(@CurrentUser() u: any, @Param("id") id: string, @Body() dto: UpdateChannelDto) {
    return this.svc.update(u.accountId, id, dto);
  }

  @Delete(":id")
  @RequireAnyPermissions("action:masters:channels:delete", "MASTERS_DELETE")
  remove(@CurrentUser() u: any, @Param("id") id: string) {
    return this.svc.remove(u.accountId, id);
  }
}
