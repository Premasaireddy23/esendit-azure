import { Body, Controller, Delete, Get, Param, Post, Put, Query, UseGuards } from "@nestjs/common";
import { JwtAuthGuard } from "../../common/auth/jwt-auth.guard";
import { PermissionsGuard } from "../../common/auth/permissions.guard";
import { RequireAnyPermissions } from "../../common/auth/require-any-permissions.decorator";
import { CurrentUser } from "../../common/auth/current-user.decorator";
import { AdvertisersService } from "./advertisers.service";
import { CreateAdvertiserDto, UpdateAdvertiserDto } from "./dto/advertiser.dto";

@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller("masters/advertisers")
export class AdvertisersController {
  constructor(private svc: AdvertisersService) {}

  @Get()
  @RequireAnyPermissions("page:masters:advertisers", "page:masters:brands", "action:masters:brands:create", "action:masters:brands:update", "MASTERS_READ")
  list(@CurrentUser() u: any, @Query("q") q?: string, @Query("includeInactive") includeInactive?: string) {
    return this.svc.list(u.accountId, q, includeInactive === "true");
  }

  @Get(":id")
  @RequireAnyPermissions("page:masters:advertisers", "page:masters:brands", "action:masters:brands:create", "action:masters:brands:update", "MASTERS_READ")
  get(@CurrentUser() u: any, @Param("id") id: string) {
    return this.svc.get(u.accountId, id);
  }

  @Post()
  @RequireAnyPermissions("action:masters:advertisers:create", "MASTERS_CREATE")
  create(@CurrentUser() u: any, @Body() dto: CreateAdvertiserDto) {
    return this.svc.create(u.accountId, u.userId ?? u.id, dto);
  }

  @Put(":id")
  @RequireAnyPermissions("action:masters:advertisers:update", "MASTERS_UPDATE")
  update(@CurrentUser() u: any, @Param("id") id: string, @Body() dto: UpdateAdvertiserDto) {
    return this.svc.update(u.accountId, u.userId ?? u.id, id, dto);
  }

  @Post(":id/enable")
  @RequireAnyPermissions("action:masters:advertisers:update", "MASTERS_UPDATE")
  enable(@CurrentUser() u: any, @Param("id") id: string) {
    return this.svc.enable(u.accountId, u.userId ?? u.id, id);
  }

  @Delete(":id/permanent")
  @RequireAnyPermissions("action:masters:advertisers:delete", "MASTERS_DELETE")
  permanentRemove(@CurrentUser() u: any, @Param("id") id: string) {
    return this.svc.permanentRemove(u.accountId, u.userId ?? u.id, id);
  }

  @Delete(":id")
  @RequireAnyPermissions("action:masters:advertisers:delete", "MASTERS_DELETE")
  remove(@CurrentUser() u: any, @Param("id") id: string) {
    return this.svc.remove(u.accountId, u.userId ?? u.id, id);
  }
}
