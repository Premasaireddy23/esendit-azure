import { Body, Controller, Delete, Get, Param, Patch, Post, UseGuards } from "@nestjs/common";
import { JwtAuthGuard } from "../../../common/auth/jwt-auth.guard";
import { PermissionsGuard } from "../../../common/auth/permissions.guard";
import { RequireAnyPermissions } from "../../../common/auth/require-any-permissions.decorator";
import { CurrentUser } from "../../../common/auth/current-user.decorator";
import { DeliveryProfilesService } from "./delivery-profiles.service";
import { CreateDeliveryProfileDto, TestDeliveryProfileConnectionDto, UpdateDeliveryProfileDto } from "./dto";

@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller("masters/delivery-profiles")
export class DeliveryProfilesController {
  constructor(private svc: DeliveryProfilesService) {}

  @Get()
  @RequireAnyPermissions("page:masters:delivery-profiles", "MASTERS_READ")
  list(@CurrentUser() u: any) {
    return this.svc.list(u.accountId);
  }


  @Post("test")
  @RequireAnyPermissions("page:masters:delivery-profiles", "MASTERS_READ")
  testConnection(@CurrentUser() u: any, @Body() dto: TestDeliveryProfileConnectionDto) {
    return this.svc.testConnection(u.accountId, dto);
  }

  @Post()
  @RequireAnyPermissions("action:masters:delivery-profiles:create", "MASTERS_CREATE")
  create(@CurrentUser() u: any, @Body() dto: CreateDeliveryProfileDto) {
    return this.svc.create(u.accountId, dto);
  }

  @Patch(":id")
  @RequireAnyPermissions("action:masters:delivery-profiles:update", "MASTERS_UPDATE")
  update(@CurrentUser() u: any, @Param("id") id: string, @Body() dto: UpdateDeliveryProfileDto) {
    return this.svc.update(u.accountId, id, dto);
  }

  @Delete(":id")
  @RequireAnyPermissions("action:masters:delivery-profiles:delete", "MASTERS_DELETE")
  remove(@CurrentUser() u: any, @Param("id") id: string) {
    return this.svc.remove(u.accountId, id);
  }
}
