import { IsEnum, IsInt, IsObject, IsOptional, IsString, Max, Min } from "class-validator";
import { DeliveryProtocol, MasterStatus } from "@prisma/client";

export class CreateDeliveryProfileDto {
  @IsString() name!: string;

  @IsEnum(DeliveryProtocol)
  protocol!: DeliveryProtocol;

  // backend uses these fields
  @IsOptional() @IsEnum(MasterStatus)
  status?: MasterStatus;

  @IsOptional() @IsObject()
  config?: Record<string, any>;

  @IsOptional() @IsString()
  stagingPath?: string | null;

  @IsOptional() @IsString()
  finalPath?: string | null;

  // optional (if FE sends active instead of status)
  @IsOptional()
  active?: boolean;
}

export class UpdateDeliveryProfileDto {
  @IsOptional() @IsString()
  name?: string;

  @IsOptional() @IsEnum(DeliveryProtocol)
  protocol?: DeliveryProtocol;

  @IsOptional() @IsEnum(MasterStatus)
  status?: MasterStatus;

  @IsOptional() @IsObject()
  config?: Record<string, any>;

  @IsOptional() @IsString()
  stagingPath?: string | null;

  @IsOptional() @IsString()
  finalPath?: string | null;

  @IsOptional()
  active?: boolean;
}


export class TestDeliveryProfileConnectionDto {
  @IsEnum(DeliveryProtocol)
  protocol!: DeliveryProtocol;

  @IsOptional() @IsObject()
  config?: Record<string, any>;

  @IsOptional() @IsInt() @Min(500) @Max(20000)
  timeoutMs?: number;
}
