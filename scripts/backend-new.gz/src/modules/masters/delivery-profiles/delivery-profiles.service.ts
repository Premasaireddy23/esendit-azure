import { BadRequestException, Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../../../common/prisma/prisma.service";
import { MasterStatus } from "@prisma/client";
import { checkEndpoint } from "../../server-status/server-checker";
import { CreateDeliveryProfileDto, TestDeliveryProfileConnectionDto, UpdateDeliveryProfileDto } from "./dto";

@Injectable()
export class DeliveryProfilesService {
  constructor(private prisma: PrismaService) {}

  async list(accountId: string) {
    return this.prisma.deliveryProfile.findMany({
      where: { accountId },
      orderBy: { name: "asc" },
    });
  }


  async testConnection(accountId: string, dto: TestDeliveryProfileConnectionDto) {
    void accountId;
    const config = (dto.config ?? {}) as Record<string, any>;
    const res = await checkEndpoint({
      protocol: dto.protocol,
      host: typeof config.host === "string" ? config.host : undefined,
      port: typeof config.port === "number" ? config.port : (typeof config.port === "string" && config.port.trim() ? Number(config.port) : undefined),
      timeoutMs: dto.timeoutMs ?? 3000,
    });

    return {
      checkedAt: new Date().toISOString(),
      protocol: dto.protocol,
      status: res.status,
      latencyMs: res.latencyMs ?? null,
      message: res.message ?? null,
    };
  }

  async create(accountId: string, dto: CreateDeliveryProfileDto) {
    if (!dto.name?.trim()) throw new BadRequestException("name required");

    const status =
      dto.status ??
      (dto.active === false ? MasterStatus.INACTIVE : MasterStatus.ACTIVE);

    return this.prisma.deliveryProfile.create({
      data: {
        accountId,
        name: dto.name.trim(),
        protocol: dto.protocol,
        status,
        config: dto.config ?? {},
        stagingPath: dto.stagingPath ?? null,
        finalPath: dto.finalPath ?? null,
      },
    });
  }

  async update(accountId: string, id: string, dto: UpdateDeliveryProfileDto) {
    const exists = await this.prisma.deliveryProfile.findFirst({
      where: { id, accountId },
      select: { id: true },
    });
    if (!exists) throw new NotFoundException("DeliveryProfile not found");

    const data: any = {};
    if (dto.name !== undefined) data.name = dto.name?.trim();
    if (dto.protocol !== undefined) data.protocol = dto.protocol;
    if (dto.config !== undefined) data.config = dto.config ?? {};
    if (dto.stagingPath !== undefined) data.stagingPath = dto.stagingPath;
    if (dto.finalPath !== undefined) data.finalPath = dto.finalPath;

    if (dto.status !== undefined) data.status = dto.status;
    if (dto.active !== undefined) data.status = dto.active ? MasterStatus.ACTIVE : MasterStatus.INACTIVE;

    return this.prisma.deliveryProfile.update({
      where: { id },
      data,
    });
  }

  async remove(accountId: string, id: string) {
    const exists = await this.prisma.deliveryProfile.findFirst({
      where: { id, accountId },
      select: { id: true },
    });
    if (!exists) throw new NotFoundException("DeliveryProfile not found");

    await this.prisma.deliveryProfile.delete({ where: { id } });
    return { ok: true };
  }
}
