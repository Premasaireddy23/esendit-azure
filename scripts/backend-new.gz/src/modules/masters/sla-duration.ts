const SLA_TARGET_MINUTES_RE = /\n?\s*\[\[SLA_TARGET_MINUTES:(\d+)\]\]\s*$/;

type SlaDurationSource = {
  hoursTarget?: number | null;
  description?: string | null;
};

export function stripSlaDurationMetadata(description?: string | null): string {
  return String(description ?? "").replace(SLA_TARGET_MINUTES_RE, "").trim();
}

export function parseSlaTargetMinutes(source: SlaDurationSource): number {
  const description = String(source?.description ?? "");
  const match = description.match(SLA_TARGET_MINUTES_RE);
  const fromMeta = match ? Number(match[1]) : NaN;
  if (Number.isFinite(fromMeta) && fromMeta > 0) return Math.trunc(fromMeta);

  const hours = Number(source?.hoursTarget ?? 0);
  if (Number.isFinite(hours) && hours > 0) return Math.trunc(hours) * 60;
  return 60;
}

export function minutesToStoredHours(targetMinutes: number): number {
  const minutes = Math.trunc(Number(targetMinutes) || 0);
  if (minutes <= 0) return 1;
  return Math.max(1, Math.ceil(minutes / 60));
}

export function mergeSlaDescriptionWithMinutes(description: string | null | undefined, targetMinutes: number): string | null {
  const cleanDescription = stripSlaDurationMetadata(description);
  const minutes = Math.trunc(Number(targetMinutes) || 0);
  if (minutes <= 0) return cleanDescription || null;

  const token = `[[SLA_TARGET_MINUTES:${minutes}]]`;
  return cleanDescription ? `${cleanDescription}\n\n${token}` : token;
}

export function getSlaDurationView(source: SlaDurationSource) {
  const targetMinutes = parseSlaTargetMinutes(source);
  if (targetMinutes % 60 === 0) {
    const hours = targetMinutes / 60;
    return {
      targetMinutes,
      durationValue: hours,
      durationUnit: "HOURS" as const,
      durationLabel: `${hours} hour${hours === 1 ? "" : "s"}`,
    };
  }

  return {
    targetMinutes,
    durationValue: targetMinutes,
    durationUnit: "MINUTES" as const,
    durationLabel: `${targetMinutes} minute${targetMinutes === 1 ? "" : "s"}`,
  };
}

export function decorateSlaRow<T extends SlaDurationSource & { description?: string | null }>(row: T) {
  const cleanDescription = stripSlaDurationMetadata(row?.description);
  return {
    ...row,
    description: cleanDescription || null,
    ...getSlaDurationView(row),
  };
}
