import { Body, Controller, Delete, Get, Param, Post, Put, Query, UseGuards } from "@nestjs/common";
import { JwtAuthGuard } from "../../common/auth/jwt-auth.guard";
import { PermissionsGuard } from "../../common/auth/permissions.guard";
import { RequireAnyPermissions } from "../../common/auth/require-any-permissions.decorator";
import { CurrentUser } from "../../common/auth/current-user.decorator";
import { AdvertiserGroupsService } from "./advertiser-groups.service";
import { CreateAdvertiserGroupDto, UpdateAdvertiserGroupDto } from "./dto/advertiser-group.dto";

@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller("masters/advertiser-groups")
export class AdvertiserGroupsController {
  constructor(private svc: AdvertiserGroupsService) {}

  @Get()
  @RequireAnyPermissions("page:masters:advertiser-groups", "page:masters:advertisers", "action:masters:advertisers:create", "action:masters:advertisers:update", "MASTERS_READ")
  list(@CurrentUser() u: any, @Query("q") q?: string, @Query("includeInactive") includeInactive?: string) {
    return this.svc.list(u.accountId, q, includeInactive === "true");
  }

  @Get(":id")
  @RequireAnyPermissions("page:masters:advertiser-groups", "page:masters:advertisers", "action:masters:advertisers:create", "action:masters:advertisers:update", "MASTERS_READ")
  get(@CurrentUser() u: any, @Param("id") id: string) {
    return this.svc.get(u.accountId, id);
  }

  @Post()
  @RequireAnyPermissions("action:masters:advertiser-groups:create", "MASTERS_CREATE")
  create(@CurrentUser() u: any, @Body() dto: CreateAdvertiserGroupDto) {
    return this.svc.create(u.accountId, u.userId ?? u.id, dto);
  }

  @Put(":id")
  @RequireAnyPermissions("action:masters:advertiser-groups:update", "MASTERS_UPDATE")
  update(@CurrentUser() u: any, @Param("id") id: string, @Body() dto: UpdateAdvertiserGroupDto) {
    return this.svc.update(u.accountId, u.userId ?? u.id, id, dto);
  }

  @Post(":id/enable")
  @RequireAnyPermissions("action:masters:advertiser-groups:update", "MASTERS_UPDATE")
  enable(@CurrentUser() u: any, @Param("id") id: string) {
    return this.svc.enable(u.accountId, u.userId ?? u.id, id);
  }

  @Delete(":id/permanent")
  @RequireAnyPermissions("action:masters:advertiser-groups:delete", "MASTERS_DELETE")
  permanentRemove(@CurrentUser() u: any, @Param("id") id: string) {
    return this.svc.permanentRemove(u.accountId, u.userId ?? u.id, id);
  }

  @Delete(":id")
  @RequireAnyPermissions("action:masters:advertiser-groups:delete", "MASTERS_DELETE")
  remove(@CurrentUser() u: any, @Param("id") id: string) {
    return this.svc.remove(u.accountId, u.userId ?? u.id, id);
  }
}
