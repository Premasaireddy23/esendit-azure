import { BadRequestException, Injectable, Logger } from "@nestjs/common";
import { PrismaService } from "../../common/prisma/prisma.service";
import { ListChargesQueryDto } from "./dto/list-charges.dto";
import { InvoiceQueryDto } from "./dto/invoice-query.dto";
import { chargeRowSelect } from "./charges.select";
import { findClientRateProfileByName } from "./client-rate-profiles";

function toDate(v?: string): Date | undefined {
  if (!v) return undefined;
  const raw = String(v).trim();
  if (!raw) return undefined;

  const direct = new Date(raw);
  if (!Number.isNaN(direct.getTime())) return direct;

  const dmy = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(raw);
  if (dmy) {
    const day = dmy[1].padStart(2, "0");
    const month = dmy[2].padStart(2, "0");
    const year = dmy[3];
    const parsed = new Date(`${year}-${month}-${day}T00:00:00.000Z`);
    if (!Number.isNaN(parsed.getTime())) return parsed;
  }

  return undefined;
}

function toNumber(v: any, fallback = 0): number {
  const n = Number(v);
  return Number.isFinite(n) ? n : fallback;
}

function clampPercent(v: any, fallback = 0): number {
  const n = toNumber(v, fallback);
  return Math.max(0, n);
}

function formatDate(v: Date | string | undefined) {
  if (!v) return "";
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return "";
  return d.toISOString().slice(0, 10);
}

function round2(v: number) {
  return Math.round((Number(v) + Number.EPSILON) * 100) / 100;
}

function isPlainObject(v: unknown): v is Record<string, any> {
  return !!v && typeof v === "object" && !Array.isArray(v);
}

function asMetaObject(v: unknown): Record<string, any> {
  return isPlainObject(v) ? v : {};
}

function isPrismaSchemaMismatchError(err: any) {
  const code = String(err?.code ?? "");
  const msg = String(err?.message ?? "");
  return code === "P2021" || code === "P2022" || /Unknown arg|Unknown field|does not exist|column .* does not exist|relation .* does not exist|Cannot read properties of undefined/.test(msg);
}

function firstNonEmpty(...values: any[]) {
  for (const value of values) {
    if (value === undefined || value === null) continue;
    const normalized = String(value).trim();
    if (normalized) return normalized;
  }
  return "";
}

function firstEmail(value?: string[] | null) {
  return Array.isArray(value) ? String(value.find((item) => String(item || "").trim()) || "") : "";
}

function extractBillablePartySnapshot(meta: unknown) {
  const obj = asMetaObject(meta);
  const snapshot = asMetaObject(obj.billablePartySnapshot);
  if (!Object.keys(snapshot).length) return null;
  return {
    advertiser: firstNonEmpty(snapshot.advertiser, obj.advertiser),
    billingName: firstNonEmpty(snapshot.billingName),
    address: firstNonEmpty(snapshot.address),
    panNumber: firstNonEmpty(snapshot.panNumber, snapshot.pan),
    gstNumber: firstNonEmpty(snapshot.gstNumber, snapshot.gst),
    currency: firstNonEmpty(snapshot.currency),
    invoiceMode: firstNonEmpty(snapshot.invoiceMode),
    defaultGstPercent: firstNonEmpty(snapshot.defaultGstPercent),
  };
}

function cleanInvoiceText(value: any, fallback = "") {
  const raw = firstNonEmpty(value);
  return raw || fallback;
}

function resolveInvoiceMetadata(q: InvoiceQueryDto | any) {
  const invoiceFrom = {
    name: cleanInvoiceText(q.invoiceFromName, process.env.INVOICE_FROM_NAME || "eSendIT"),
    address: cleanInvoiceText(q.invoiceFromAddress, process.env.INVOICE_FROM_ADDRESS || ""),
    email: cleanInvoiceText(q.invoiceFromEmail, process.env.INVOICE_FROM_EMAIL || ""),
    phone: cleanInvoiceText(q.invoiceFromPhone, process.env.INVOICE_FROM_PHONE || ""),
    gstNumber: cleanInvoiceText(q.invoiceFromGstNumber, process.env.INVOICE_FROM_GST_NUMBER || ""),
    panNumber: cleanInvoiceText(q.invoiceFromPanNumber, process.env.INVOICE_FROM_PAN_NUMBER || ""),
  };

  const bankDetails = {
    beneficiaryName: cleanInvoiceText(q.bankBeneficiaryName, process.env.INVOICE_BANK_BENEFICIARY_NAME || invoiceFrom.name),
    bankName: cleanInvoiceText(q.bankName, process.env.INVOICE_BANK_NAME || ""),
    bankBranch: cleanInvoiceText(q.bankBranch, process.env.INVOICE_BANK_BRANCH || ""),
    accountNumber: cleanInvoiceText(q.bankAccountNumber, process.env.INVOICE_BANK_ACCOUNT_NUMBER || ""),
    ifscCode: cleanInvoiceText(q.bankIfscCode, process.env.INVOICE_BANK_IFSC_CODE || ""),
    accountType: cleanInvoiceText(q.bankAccountType, process.env.INVOICE_BANK_ACCOUNT_TYPE || ""),
  };

  return { invoiceFrom, bankDetails };
}

function resolveManualInvoiceBillableParty(baseBillableParty: any, q: any) {
  return {
    id: firstNonEmpty(baseBillableParty?.id),
    name: firstNonEmpty(q?.billToName, q?.customerName, baseBillableParty?.name),
    contactName: firstNonEmpty(q?.billToContactName, q?.customerContactName, baseBillableParty?.contactName),
    advertiser: firstNonEmpty(q?.billToAdvertiser, q?.advertiser, baseBillableParty?.advertiser),
    address: firstNonEmpty(q?.billToAddress, q?.billingAddress, baseBillableParty?.address),
    email: firstNonEmpty(q?.billToEmail, q?.customerEmail, baseBillableParty?.email),
    phone: firstNonEmpty(q?.billToPhone, q?.customerPhone, baseBillableParty?.phone),
    projectNo: firstNonEmpty(q?.billToProjectNo, q?.projectNo, baseBillableParty?.projectNo),
    brand: firstNonEmpty(q?.billToBrand, q?.brand, baseBillableParty?.brand),
    poNumber: firstNonEmpty(q?.billToPoNumber, q?.poNumber, baseBillableParty?.poNumber),
    gstNumber: firstNonEmpty(q?.billToGstNumber, q?.gstNumber, baseBillableParty?.gstNumber),
    panNumber: firstNonEmpty(q?.billToPanNumber, q?.panNumber, baseBillableParty?.panNumber),
    paymentTerms: firstNonEmpty(q?.billToPaymentTerms, q?.paymentTerms, baseBillableParty?.paymentTerms),
  };
}

@Injectable()
export class ChargesService {
  private readonly logger = new Logger(ChargesService.name);

  constructor(private prisma: PrismaService) {}

  buildWhere(accountId: string, q: ListChargesQueryDto) {
    const where: any = { accountId };

    if (q.projectId) where.projectId = q.projectId;
    if (q.billablePartyId) where.billablePartyId = q.billablePartyId;
    if (q.destinationId) where.destinationId = q.destinationId;
    if (q.channelId) where.channelId = q.channelId;
    if (q.slaId) where.slaId = q.slaId;
    if (q.action) where.action = q.action;

    const from = toDate(q.from);
    const to = toDate(q.to);
    if (from || to) {
      where.occurredAt = {};
      if (from) where.occurredAt.gte = from;
      if (to) where.occurredAt.lte = to;
    }

    return where;
  }

  async listCharges(accountId: string, q: ListChargesQueryDto) {
    const take = q.take ?? 200;
    const skip = q.skip ?? 0;

    const where = this.buildWhere(accountId, q);

    const rows = await this.prisma.chargeRow.findMany({
      where,
      orderBy: { occurredAt: "desc" },
      take,
      skip,
      select: chargeRowSelect as any,
    });

    return rows;
  }

  async exportCharges(accountId: string, q: ListChargesQueryDto) {
    const exportQ: ListChargesQueryDto = { ...q };
    exportQ.skip = q.skip ?? 0;
    exportQ.take = Math.min(q.take ?? 50000, 50000);
    return this.listCharges(accountId, exportQ);
  }

  private describeCharge(row: any) {
    const itemLabel = firstNonEmpty(row.rateCardItem?.label);
    const contextualParts = [
      row.creative?.valid || row.creative?.title || row.creative?.name,
      row.destination?.name,
      row.channel?.name,
      row.sla?.name,
    ].filter(Boolean);

    if (itemLabel) {
      return [itemLabel, ...contextualParts].filter(Boolean).join(" • ");
    }

    const parts = [
      row.creative?.valid || row.creative?.title || row.creative?.name,
      row.destination?.name,
      row.channel?.name,
      row.sla?.name,
      row.action,
    ].filter(Boolean);
    return parts.join(" • ");
  }

  private buildInvoiceRow(row: any, q: InvoiceQueryDto) {
    const meta = asMetaObject(row?.rateCardItem?.meta);
    const invoiceMode = (q.invoiceMode || "GLOBAL") as "INDIA" | "GLOBAL";
    const indiaTaxType = (q.indiaTaxType || "INTRA") as "INTRA" | "INTER";
    const billingMode = String(meta.billingMode || "BOTH").trim().toUpperCase();

    if (billingMode === "INDIA" && invoiceMode === "GLOBAL") return null;
    if (billingMode === "GLOBAL" && invoiceMode === "INDIA") return null;

    const quantity = toNumber(row.quantity, 1);
    const unitRate = toNumber(
      row.amount ?? row.rateCardItem?.amount ?? row.rateCardItem?.sdAmount ?? row.rateCardItem?.hdAmount,
      0,
    );
    const lineTotal = round2(quantity * unitRate);

    const gstPercent = clampPercent(meta.gstPercent ?? q.defaultGstPercent ?? meta.defaultGstPercent, 0);
    const taxSlabPercent = clampPercent(meta.taxSlabPercent ?? meta.globalTaxSlabPercent ?? q.defaultTaxSlabPercent, 0);

    let cgstAmount = 0;
    let sgstAmount = 0;
    let igstAmount = 0;
    let taxAmount = 0;

    if (invoiceMode === "INDIA") {
      if (indiaTaxType === "INTER") {
        igstAmount = round2((lineTotal * gstPercent) / 100);
      } else {
        cgstAmount = round2((lineTotal * gstPercent) / 200);
        sgstAmount = round2((lineTotal * gstPercent) / 200);
      }
      taxAmount = round2(cgstAmount + sgstAmount + igstAmount);
    } else {
      taxAmount = round2((lineTotal * taxSlabPercent) / 100);
    }

    return {
      id: row.id,
      date: row.occurredAt,
      description: this.describeCharge(row),
      project: row.project?.name || row.project?.projectCode || row.project?.projectNumber || "",
      creative: row.creative?.valid || row.creative?.title || row.creative?.name || "",
      destination: row.destination?.name || "",
      channel: row.channel?.name || "",
      sla: row.sla?.name || "",
      action: row.action || "",
      itemCode: row.rateCardItem?.code || null,
      hsnSacCode: meta.hsnSacCode || meta.hsnSac || null,
      quantity,
      unit: row.unit || row.rateCardItem?.unit || "per_file",
      unitRate,
      lineTotal,
      currency: row.currency || row.rateCardItem?.currency || meta.currency || "EUR",
      gstPercent,
      taxSlabPercent,
      cgstAmount,
      sgstAmount,
      igstAmount,
      taxAmount,
      totalWithTax: round2(lineTotal + taxAmount),
    };
  }

  private buildManualInvoiceRow(row: any, q: any, index: number) {
    const invoiceMode = (q?.invoiceMode || "GLOBAL") as "INDIA" | "GLOBAL";
    const indiaTaxType = (q?.indiaTaxType || "INTRA") as "INTRA" | "INTER";

    const quantity = toNumber(row?.quantity, 1);
    const unitRate = toNumber(row?.unitRate, 0);
    const lineTotal = round2(quantity * unitRate);
    const gstPercent = clampPercent(row?.gstPercent ?? q?.defaultGstPercent, 0);
    const taxSlabPercent = clampPercent(row?.taxSlabPercent ?? q?.defaultTaxSlabPercent, 0);

    let cgstAmount = 0;
    let sgstAmount = 0;
    let igstAmount = 0;
    let taxAmount = 0;

    if (invoiceMode === "INDIA") {
      if (indiaTaxType === "INTER") {
        igstAmount = round2((lineTotal * gstPercent) / 100);
      } else {
        cgstAmount = round2((lineTotal * gstPercent) / 200);
        sgstAmount = round2((lineTotal * gstPercent) / 200);
      }
      taxAmount = round2(cgstAmount + sgstAmount + igstAmount);
    } else {
      taxAmount = round2((lineTotal * taxSlabPercent) / 100);
    }

    return {
      id: firstNonEmpty(row?.id) || `manual-${index + 1}`,
      date: toDate(row?.date) || toDate(q?.invoiceDate) || new Date(),
      description: firstNonEmpty(row?.description) || `Manual invoice line ${index + 1}`,
      project: firstNonEmpty(row?.project),
      creative: firstNonEmpty(row?.creative),
      destination: firstNonEmpty(row?.destination),
      channel: firstNonEmpty(row?.channel),
      sla: firstNonEmpty(row?.sla),
      action: firstNonEmpty(row?.action),
      itemCode: firstNonEmpty(row?.itemCode) || null,
      hsnSacCode: firstNonEmpty(row?.hsnSacCode) || null,
      quantity,
      unit: firstNonEmpty(row?.unit) || "each",
      unitRate,
      lineTotal,
      currency: firstNonEmpty(row?.currency) || "EUR",
      gstPercent,
      taxSlabPercent,
      cgstAmount,
      sgstAmount,
      igstAmount,
      taxAmount,
      totalWithTax: round2(lineTotal + taxAmount),
    };
  }

  private async resolveInvoiceBillableParty(accountId: string, billablePartyId: string, warnings: string[]) {
    let billableParty: any = null;
    try {
      billableParty = await this.prisma.billableParty.findFirst({
        where: { accountId, id: billablePartyId },
        select: {
          id: true,
          name: true,
          address: true,
          gstNumber: true,
          panNumber: true,
          paymentTerms: true,
          emails: true,
        },
      });
    } catch (err: any) {
      if (isPrismaSchemaMismatchError(err)) {
        this.logger.warn(`Invoice preview billable party fallback used because optional billing columns are not fully available: ${err?.message || err}`);
        warnings.push("Some billable party billing columns are not available yet. Using basic billable party details for preview.");
        billableParty = await this.prisma.billableParty.findFirst({
          where: { accountId, id: billablePartyId },
          select: {
            id: true,
            name: true,
            emails: true,
          },
        });
      } else {
        throw err;
      }
    }

    if (!billableParty) {
      throw new BadRequestException("Invalid billablePartyId");
    }

    let rateCardSnapshot: any = null;
    try {
      const candidateRateCard = await this.prisma.rateCard.findFirst({
        where: { accountId, billablePartyId },
        orderBy: [{ effectiveFrom: "desc" }],
        select: {
          items: {
            orderBy: [{ sortOrder: "asc" }],
            take: 10,
            select: { meta: true },
          },
        },
      });
      rateCardSnapshot = (candidateRateCard?.items || [])
        .map((item: any) => extractBillablePartySnapshot(item?.meta))
        .find((snapshot: any) => !!snapshot) || null;
    } catch (err: any) {
      if (!isPrismaSchemaMismatchError(err)) {
        this.logger.warn(`Invoice preview rate card snapshot lookup failed: ${err?.message || err}`);
      }
    }

    const embeddedProfile = findClientRateProfileByName(billableParty?.name);
    const fallbackSnapshot = rateCardSnapshot || (embeddedProfile
      ? {
          advertiser: embeddedProfile.advertiser,
          billingName: embeddedProfile.billingName,
          address: embeddedProfile.address,
          panNumber: embeddedProfile.pan,
          gstNumber: embeddedProfile.gst,
          currency: embeddedProfile.currency,
          invoiceMode: embeddedProfile.invoiceMode,
          defaultGstPercent: embeddedProfile.defaultGstPercent,
        }
      : null);

    return {
      id: billableParty.id,
      name: billableParty.name || fallbackSnapshot?.billingName || "",
      advertiser: firstNonEmpty(billableParty.advertiser, fallbackSnapshot?.advertiser),
      address: firstNonEmpty(billableParty.address, fallbackSnapshot?.address),
      gstNumber: firstNonEmpty(billableParty.gstNumber, fallbackSnapshot?.gstNumber),
      panNumber: firstNonEmpty(billableParty.panNumber, fallbackSnapshot?.panNumber),
      paymentTerms: billableParty.paymentTerms || "",
      email: firstEmail((billableParty as any).emails),
    };
  }

  private async resolveInvoiceContext(accountId: string, q: InvoiceQueryDto, warnings: string[]) {
    let effectiveBillablePartyId = firstNonEmpty(q.billablePartyId);
    let projectSummary: any = null;

    if (q.projectId) {
      try {
        projectSummary = await this.prisma.project.findFirst({
          where: { accountId, id: q.projectId },
          select: {
            id: true,
            name: true,
            projectCode: true,
            ...( {
              billablePartyId: true,
              billableParty: { select: { id: true, name: true } },
            } as any),
          } as any,
        });
      } catch (err: any) {
        if (isPrismaSchemaMismatchError(err)) {
          this.logger.warn(`Invoice preview project lookup fallback used because project billing columns are not fully available: ${err?.message || err}`);
          warnings.push("Project billable party mapping is not fully available yet. Using billing charge rows as a fallback.");
          projectSummary = await this.prisma.project.findFirst({
            where: { accountId, id: q.projectId },
            select: { id: true, name: true, projectCode: true },
          });
        } else {
          throw err;
        }
      }

      if (!projectSummary) {
        throw new BadRequestException("Invalid projectId");
      }

      if (!effectiveBillablePartyId) {
        effectiveBillablePartyId = firstNonEmpty((projectSummary as any)?.billablePartyId, (projectSummary as any)?.billableParty?.id);
      }

      if (!effectiveBillablePartyId) {
        const projectChargeRow = await this.prisma.chargeRow.findFirst({
          where: { accountId, projectId: q.projectId },
          orderBy: { occurredAt: "desc" },
          select: { billablePartyId: true, billableParty: { select: { id: true, name: true } } } as any,
        }).catch(() => null);
        effectiveBillablePartyId = firstNonEmpty(projectChargeRow?.billablePartyId, projectChargeRow?.billableParty?.id);
      }
    }

    if (!effectiveBillablePartyId) {
      throw new BadRequestException(q.projectId ? "The selected project does not have a billable party linked yet." : "billablePartyId is required");
    }

    const baseBillableParty = await this.resolveInvoiceBillableParty(accountId, effectiveBillablePartyId, warnings);
    const billableParty = resolveManualInvoiceBillableParty(baseBillableParty, q);

    return {
      effectiveBillablePartyId,
      billableParty,
      projectSummary,
    };
  }

  private finalizeInvoicePreview(q: InvoiceQueryDto | any, invoiceRows: any[], warnings: string[], billableParty: any) {
    const totalsMap = new Map<string, any>();
    for (const row of invoiceRows) {
      const key = row.currency || "EUR";
      if (!totalsMap.has(key)) {
        totalsMap.set(key, {
          currency: key,
          subTotal: 0,
          taxTotal: 0,
          cgstTotal: 0,
          sgstTotal: 0,
          igstTotal: 0,
          grandTotal: 0,
        });
      }
      const t = totalsMap.get(key);
      t.subTotal = round2(t.subTotal + row.lineTotal);
      t.taxTotal = round2(t.taxTotal + row.taxAmount);
      t.cgstTotal = round2(t.cgstTotal + row.cgstAmount);
      t.sgstTotal = round2(t.sgstTotal + row.sgstAmount);
      t.igstTotal = round2(t.igstTotal + row.igstAmount);
      t.grandTotal = round2(t.grandTotal + row.totalWithTax);
    }

    const today = formatDate(new Date());
    const normalizedInvoiceDate = formatDate(toDate(q.invoiceDate) || today);
    const normalizedDueDate = formatDate(toDate(q.dueDate) || q.invoiceDate || today);
    const invoiceMeta = resolveInvoiceMetadata(q);

    return {
      invoiceNumber: q.invoiceNumber || `INV-${today}`,
      invoiceDate: normalizedInvoiceDate,
      dueDate: normalizedDueDate,
      invoiceMode: (q.invoiceMode || "GLOBAL") as "INDIA" | "GLOBAL",
      indiaTaxType: (q.indiaTaxType || "INTRA") as "INTRA" | "INTER",
      notes: q.notes || "",
      rowCount: invoiceRows.length,
      warnings,
      invoiceFrom: invoiceMeta.invoiceFrom,
      bankDetails: invoiceMeta.bankDetails,
      billableParty,
      rows: invoiceRows,
      totals: Array.from(totalsMap.values()),
    };
  }

  async buildInvoicePreview(accountId: string, q: InvoiceQueryDto) {
    const warnings: string[] = [];
    const invoiceContext = await this.resolveInvoiceContext(accountId, q, warnings);
    const effectiveBillablePartyId = invoiceContext.effectiveBillablePartyId;
    const billableParty = invoiceContext.billableParty;

    let rows: any[] = [];
    try {
      rows = await this.exportCharges(accountId, {
        ...q,
        billablePartyId: effectiveBillablePartyId,
      });
    } catch (err: any) {
      if (isPrismaSchemaMismatchError(err)) {
        this.logger.warn(`Invoice preview fallback used because billing charge schema is not fully available: ${err?.message || err}`);
        warnings.push("Billing charge rows are not fully available yet. Invoice preview is showing zero rows instead of failing.");
        rows = [];
      } else {
        this.logger.error(`Invoice preview could not load charge rows. Returning empty preview to avoid a hard failure. ${err?.message || err}`);
        warnings.push("Invoice preview could not load billing rows in the current environment. Preview is shown with zero rows instead of failing.");
        rows = [];
      }
    }

    const invoiceRows = rows.flatMap((row) => {
      try {
        const invoiceRow = this.buildInvoiceRow(row, q);
        return invoiceRow ? [invoiceRow] : [];
      } catch (err: any) {
        this.logger.warn(`Skipping invoice row ${row?.id || "unknown"}: ${err?.message || err}`);
        warnings.push("Skipped one charge row during invoice preview because it contained incomplete billing data.");
        return [];
      }
    });

    return this.finalizeInvoicePreview(q, invoiceRows, warnings, billableParty);
  }

  async buildManualInvoicePreview(accountId: string, q: any) {
    const warnings: string[] = [];

    let baseBillableParty: any = null;
    if (q?.billablePartyId) {
      baseBillableParty = await this.resolveInvoiceBillableParty(accountId, q.billablePartyId, warnings);
    }
    const billableParty = resolveManualInvoiceBillableParty(baseBillableParty, q);

    const inputRows = Array.isArray(q?.rows)
      ? q.rows
      : Array.isArray(q?.manualRows)
        ? q.manualRows
        : [];

    const invoiceRows = inputRows.flatMap((row: any, index: number) => {
      try {
        const hasContent = [
          row?.description,
          row?.project,
          row?.creative,
          row?.destination,
          row?.channel,
          row?.sla,
          row?.action,
          row?.itemCode,
          row?.hsnSacCode,
        ].some((value) => firstNonEmpty(value));
        if (!hasContent) return [];
        return [this.buildManualInvoiceRow(row, q, index)];
      } catch (err: any) {
        this.logger.warn(`Skipping manual invoice row ${index + 1}: ${err?.message || err}`);
        warnings.push("Skipped one manual invoice row because it contained invalid values.");
        return [];
      }
    });

    if (!invoiceRows.length) {
      warnings.push("No manual invoice rows were provided, so the preview contains zero line items.");
    }
    if (!billableParty?.name) {
      warnings.push("Bill To name was not provided. Add a Bill To name or choose a billable party base for a complete invoice.");
    }

    return this.finalizeInvoicePreview(q, invoiceRows, warnings, billableParty);
  }
}
