export type ClientRateProfile = {
  key: string;
  advertiser: string;
  billingName: string;
  address: string;
  pan: string;
  gst: string;
  currency: string;
  invoiceMode: "INDIA";
  defaultGstPercent: string;
};

export const CLIENT_RATE_PROFILES: ClientRateProfile[] = [
  {
    key: "tata-digital-private-limited",
    advertiser: "Tata Digital Private Limited",
    billingName: "Tata Digital Private Limited",
    address: "Army & Navy Building, 148 MG Road, Opposite Kala Ghoda Fort, Mumbai 400001",
    pan: "AAHCT2205N",
    gst: "27AAHCT2205N1Z6",
    currency: "INR",
    invoiceMode: "INDIA",
    defaultGstPercent: "18",
  },
  {
    key: "reliance-retail-limited",
    advertiser: "Reliance Retail Limited",
    billingName: "Reliance Retail Limited",
    address: "0,5 TTC INDUSTRIAL AREA, RELIANCE CORPORATE PARK, GHANSOLI, NAVI MUMBAI, Thane, Maharashtra, 400701",
    pan: "AABCR1718E",
    gst: "27AABCR1718E2ZO",
    currency: "INR",
    invoiceMode: "INDIA",
    defaultGstPercent: "18",
  },
  {
    key: "vibrant-advertising-pvt-ltd",
    advertiser: "Reliance Retail Limited",
    billingName: "Vibrant Advertising Pvt Ltd.",
    address: "3rd Floor, Court House, Lokmanaya Tilak Marg, Dhobi Talao, Mumbai 400002, Maharashtra",
    pan: "AACV7737Q1",
    gst: "27AAACV7737Q1ZI",
    currency: "INR",
    invoiceMode: "INDIA",
    defaultGstPercent: "18",
  },
];

export function normalizeClientRateText(value?: string | null) {
  return String(value || "")
    .trim()
    .toLowerCase()
    .replace(/\s+/g, " ");
}

export function findClientRateProfileByName(name?: string | null) {
  const normalized = normalizeClientRateText(name);
  return CLIENT_RATE_PROFILES.find((profile) => normalizeClientRateText(profile.billingName) === normalized) || null;
}
