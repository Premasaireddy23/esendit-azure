import { IsIn, IsOptional, IsString, MaxLength } from "class-validator";
import { ListChargesQueryDto } from "./list-charges.dto";

export class InvoiceQueryDto extends ListChargesQueryDto {
  @IsOptional()
  @IsString()
  billablePartyId?: string;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  invoiceNumber?: string;

  @IsOptional()
  @IsString()
  invoiceDate?: string;

  @IsOptional()
  @IsString()
  dueDate?: string;

  @IsOptional()
  @IsString()
  @MaxLength(2000)
  notes?: string;

  @IsOptional()
  @IsIn(["INDIA", "GLOBAL"])
  invoiceMode?: "INDIA" | "GLOBAL";

  @IsOptional()
  @IsIn(["INTRA", "INTER"])
  indiaTaxType?: "INTRA" | "INTER";

  @IsOptional()
  @IsString()
  defaultGstPercent?: string;

  @IsOptional()
  @IsString()
  defaultTaxSlabPercent?: string;


  @IsOptional()
  @IsString()
  @MaxLength(200)
  invoiceFromName?: string;

  @IsOptional()
  @IsString()
  @MaxLength(2000)
  invoiceFromAddress?: string;

  @IsOptional()
  @IsString()
  @MaxLength(200)
  invoiceFromEmail?: string;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  invoiceFromPhone?: string;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  invoiceFromGstNumber?: string;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  invoiceFromPanNumber?: string;

  @IsOptional()
  @IsString()
  @MaxLength(200)
  bankBeneficiaryName?: string;

  @IsOptional()
  @IsString()
  @MaxLength(200)
  bankName?: string;

  @IsOptional()
  @IsString()
  @MaxLength(200)
  bankBranch?: string;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  bankAccountNumber?: string;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  bankIfscCode?: string;

  @IsOptional()
  @IsString()
  @MaxLength(200)
  billToName?: string;

  @IsOptional()
  @IsString()
  @MaxLength(200)
  billToContactName?: string;

  @IsOptional()
  @IsString()
  @MaxLength(200)
  billToAdvertiser?: string;

  @IsOptional()
  @IsString()
  @MaxLength(2000)
  billToAddress?: string;

  @IsOptional()
  @IsString()
  @MaxLength(200)
  billToEmail?: string;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  billToPhone?: string;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  billToProjectNo?: string;

  @IsOptional()
  @IsString()
  @MaxLength(200)
  billToBrand?: string;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  billToPoNumber?: string;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  billToPaymentTerms?: string;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  billToGstNumber?: string;

  @IsOptional()
  @IsString()
  @MaxLength(100)
  billToPanNumber?: string;

}
