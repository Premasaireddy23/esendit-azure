import { Body, Controller, Get, Post, Query, Res, UseGuards } from "@nestjs/common";
import { JwtAuthGuard } from "../../common/auth/jwt-auth.guard";
import { PermissionsGuard } from "../../common/auth/permissions.guard";
import { RequireAnyPermissions } from "../../common/auth/require-any-permissions.decorator";
import { CurrentUser } from "../../common/auth/current-user.decorator";
import { ChargesService } from "./charges.service";
import { ListChargesQueryDto } from "./dto/list-charges.dto";
import { InvoiceQueryDto } from "./dto/invoice-query.dto";
import { chargesToCsv, chargesToExcel } from "./charges.export";
import { invoiceToCsv, invoiceToExcel, invoiceToPdf } from "./invoice.export";

@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller("billing")
export class ChargesController {
  constructor(private readonly charges: ChargesService) {}

  @Get("charges")
  @RequireAnyPermissions("page:billing:charges", "BILLING_READ")
  list(@CurrentUser() user: any, @Query() q: ListChargesQueryDto) {
    return this.charges.listCharges(user.accountId, q);
  }

  @Get("charges/export.csv")
  @RequireAnyPermissions("page:billing:charges", "BILLING_READ")
  async exportCsv(@CurrentUser() user: any, @Query() q: ListChargesQueryDto, @Res() res: any) {
    const rows = await this.charges.exportCharges(user.accountId, q);
    const csv = chargesToCsv(rows);

    const fname = `charges_${new Date().toISOString().slice(0, 10)}.csv`;
    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader("Content-Disposition", `attachment; filename="${fname}"`);
    res.status(200).send(csv);
  }

  @Get("charges/export.xlsx")
  @RequireAnyPermissions("page:billing:charges", "BILLING_READ")
  async exportXlsx(@CurrentUser() user: any, @Query() q: ListChargesQueryDto, @Res() res: any) {
    const rows = await this.charges.exportCharges(user.accountId, q);
    const buf = await chargesToExcel(rows);

    const fname = `charges_${new Date().toISOString().slice(0, 10)}.xlsx`;
    res.setHeader(
      "Content-Type",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    );
    res.setHeader("Content-Disposition", `attachment; filename="${fname}"`);
    res.status(200).send(buf);
  }

  @Get("invoices/preview")
  @RequireAnyPermissions("page:billing:invoices", "BILLING_READ")
  previewInvoice(@CurrentUser() user: any, @Query() q: InvoiceQueryDto) {
    return this.charges.buildInvoicePreview(user.accountId, q);
  }


  @Post("invoices/manual/preview")
  @RequireAnyPermissions("page:billing:invoices", "BILLING_READ")
  previewManualInvoice(@CurrentUser() user: any, @Body() body: any) {
    return this.charges.buildManualInvoicePreview(user.accountId, body || {});
  }

  @Post("invoices/manual/export.csv")
  @RequireAnyPermissions("page:billing:invoices", "BILLING_READ")
  async exportManualInvoiceCsv(@CurrentUser() user: any, @Body() body: any, @Res() res: any) {
    const invoice = await this.charges.buildManualInvoicePreview(user.accountId, body || {});
    const csv = invoiceToCsv(invoice);
    const fname = `${invoice.invoiceNumber || "invoice"}.csv`;
    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader("Content-Disposition", `attachment; filename="${fname}"`);
    res.status(200).send(csv);
  }

  @Post("invoices/manual/export.xlsx")
  @RequireAnyPermissions("page:billing:invoices", "BILLING_READ")
  async exportManualInvoiceXlsx(@CurrentUser() user: any, @Body() body: any, @Res() res: any) {
    const invoice = await this.charges.buildManualInvoicePreview(user.accountId, body || {});
    const buf = await invoiceToExcel(invoice);
    const fname = `${invoice.invoiceNumber || "invoice"}.xlsx`;
    res.setHeader(
      "Content-Type",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    );
    res.setHeader("Content-Disposition", `attachment; filename="${fname}"`);
    res.status(200).send(buf);
  }

  @Post("invoices/manual/export.pdf")
  @RequireAnyPermissions("page:billing:invoices", "BILLING_READ")
  async exportManualInvoicePdf(@CurrentUser() user: any, @Body() body: any, @Res() res: any) {
    const invoice = await this.charges.buildManualInvoicePreview(user.accountId, body || {});
    const buf = invoiceToPdf(invoice);
    const fname = `${invoice.invoiceNumber || "invoice"}.pdf`;
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `attachment; filename="${fname}"`);
    res.status(200).send(buf);
  }

  @Get("invoices/export.csv")
  @RequireAnyPermissions("page:billing:invoices", "BILLING_READ")
  async exportInvoiceCsv(@CurrentUser() user: any, @Query() q: InvoiceQueryDto, @Res() res: any) {
    const invoice = await this.charges.buildInvoicePreview(user.accountId, q);
    const csv = invoiceToCsv(invoice);
    const fname = `${invoice.invoiceNumber || "invoice"}.csv`;
    res.setHeader("Content-Type", "text/csv; charset=utf-8");
    res.setHeader("Content-Disposition", `attachment; filename="${fname}"`);
    res.status(200).send(csv);
  }

  @Get("invoices/export.xlsx")
  @RequireAnyPermissions("page:billing:invoices", "BILLING_READ")
  async exportInvoiceXlsx(@CurrentUser() user: any, @Query() q: InvoiceQueryDto, @Res() res: any) {
    const invoice = await this.charges.buildInvoicePreview(user.accountId, q);
    const buf = await invoiceToExcel(invoice);
    const fname = `${invoice.invoiceNumber || "invoice"}.xlsx`;
    res.setHeader(
      "Content-Type",
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    );
    res.setHeader("Content-Disposition", `attachment; filename="${fname}"`);
    res.status(200).send(buf);
  }

  @Get("invoices/export.pdf")
  @RequireAnyPermissions("page:billing:invoices", "BILLING_READ")
  async exportInvoicePdf(@CurrentUser() user: any, @Query() q: InvoiceQueryDto, @Res() res: any) {
    const invoice = await this.charges.buildInvoicePreview(user.accountId, q);
    const buf = invoiceToPdf(invoice);
    const fname = `${invoice.invoiceNumber || "invoice"}.pdf`;
    res.setHeader("Content-Type", "application/pdf");
    res.setHeader("Content-Disposition", `attachment; filename="${fname}"`);
    res.status(200).send(buf);
  }
}
