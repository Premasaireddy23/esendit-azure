import * as ExcelJS from "exceljs";

type InvoiceLike = any;
type FontKey = "F1" | "F2" | "F3" | "F4";
type Rgb = [number, number, number];

type TextOptions = {
  font?: FontKey;
  size?: number;
  color?: Rgb;
  align?: "left" | "center" | "right";
};

function csvEscape(v: any): string {
  if (v === null || v === undefined) return "";
  const s = String(v);
  if (/[\n\r,\"]/g.test(s)) return '"' + s.replace(/"/g, '""') + '"';
  return s;
}

function n(v: any) {
  const x = Number(v);
  return Number.isFinite(x) ? x : 0;
}

function money(v: any) {
  return n(v).toFixed(2);
}

export function invoiceToCsv(invoice: InvoiceLike): string {
  const out: string[] = [];
  out.push(["Invoice Number", invoice.invoiceNumber].map(csvEscape).join(","));
  out.push(["Invoice Date", invoice.invoiceDate].map(csvEscape).join(","));
  out.push(["Due Date", invoice.dueDate].map(csvEscape).join(","));
  out.push(["Mode", invoice.invoiceMode].map(csvEscape).join(","));
  if (invoice.invoiceMode === "INDIA") out.push(["GST Type", invoice.indiaTaxType].map(csvEscape).join(","));
  out.push(["Bill To Name", invoice.billableParty?.name].map(csvEscape).join(","));
  out.push(["Bill To Contact", invoice.billableParty?.contactName].map(csvEscape).join(","));
  out.push(["Advertiser", invoice.billableParty?.advertiser].map(csvEscape).join(","));
  out.push(["Address", invoice.billableParty?.address].map(csvEscape).join(","));
  out.push(["Bill To Email", invoice.billableParty?.email].map(csvEscape).join(","));
  out.push(["Bill To Phone", invoice.billableParty?.phone].map(csvEscape).join(","));
  out.push(["Project No", invoice.billableParty?.projectNo].map(csvEscape).join(","));
  out.push(["Brand", invoice.billableParty?.brand].map(csvEscape).join(","));
  out.push(["PO Number", invoice.billableParty?.poNumber].map(csvEscape).join(","));
  out.push(["PAN", invoice.billableParty?.panNumber].map(csvEscape).join(","));
  out.push(["GST", invoice.billableParty?.gstNumber].map(csvEscape).join(","));
  out.push(["Payment Terms", invoice.billableParty?.paymentTerms].map(csvEscape).join(","));
  out.push(["Invoice From Name", invoice.invoiceFrom?.name].map(csvEscape).join(","));
  out.push(["Invoice From Address", invoice.invoiceFrom?.address].map(csvEscape).join(","));
  out.push(["Invoice From Email", invoice.invoiceFrom?.email].map(csvEscape).join(","));
  out.push(["Invoice From Phone", invoice.invoiceFrom?.phone].map(csvEscape).join(","));
  out.push(["Invoice From GST", invoice.invoiceFrom?.gstNumber].map(csvEscape).join(","));
  out.push(["Invoice From PAN", invoice.invoiceFrom?.panNumber].map(csvEscape).join(","));
  out.push(["Bank Beneficiary", invoice.bankDetails?.beneficiaryName].map(csvEscape).join(","));
  out.push(["Bank Name", invoice.bankDetails?.bankName].map(csvEscape).join(","));
  out.push(["Bank Branch", invoice.bankDetails?.bankBranch].map(csvEscape).join(","));
  out.push(["Bank Account Number", invoice.bankDetails?.accountNumber].map(csvEscape).join(","));
  out.push(["Bank IFSC", invoice.bankDetails?.ifscCode].map(csvEscape).join(","));
  out.push(["Bank Account Type", invoice.bankDetails?.accountType].map(csvEscape).join(","));
  if (invoice.notes) out.push(["Notes", invoice.notes].map(csvEscape).join(","));
  out.push("");
  out.push([
    "Date",
    "Description",
    "Project",
    "Creative",
    "Destination",
    "Channel",
    "SLA",
    "Action",
    "Item Code",
    "HSN/SAC",
    "Qty",
    "Unit",
    "Unit Rate",
    "Line Total",
    "GST %",
    "Tax Slab %",
    "CGST",
    "SGST",
    "IGST",
    "Tax Total",
    "Grand Total",
    "Currency",
  ].map(csvEscape).join(","));
  for (const row of invoice.rows || []) {
    out.push([
      row.date,
      row.description,
      row.project,
      row.creative,
      row.destination,
      row.channel,
      row.sla,
      row.action,
      row.itemCode,
      row.hsnSacCode,
      row.quantity,
      row.unit,
      row.unitRate,
      row.lineTotal,
      row.gstPercent,
      row.taxSlabPercent,
      row.cgstAmount,
      row.sgstAmount,
      row.igstAmount,
      row.taxAmount,
      row.totalWithTax,
      row.currency,
    ].map(csvEscape).join(","));
  }
  out.push("");
  out.push(["Currency", "Sub Total", "Tax Total", "CGST", "SGST", "IGST", "Grand Total"].map(csvEscape).join(","));
  for (const t of invoice.totals || []) {
    out.push([t.currency, t.subTotal, t.taxTotal, t.cgstTotal, t.sgstTotal, t.igstTotal, t.grandTotal].map(csvEscape).join(","));
  }
  return out.join("\n");
}

export async function invoiceToExcel(invoice: InvoiceLike): Promise<Buffer> {
  const wb = new ExcelJS.Workbook();
  wb.creator = "eSendIT";
  wb.created = new Date();

  const ws = wb.addWorksheet("Invoice");
  ws.columns = [
    { header: "Date", key: "date", width: 14 },
    { header: "Description", key: "description", width: 34 },
    { header: "Project", key: "project", width: 22 },
    { header: "Creative", key: "creative", width: 22 },
    { header: "Destination", key: "destination", width: 18 },
    { header: "Channel", key: "channel", width: 18 },
    { header: "SLA", key: "sla", width: 16 },
    { header: "Action", key: "action", width: 14 },
    { header: "Item Code", key: "itemCode", width: 18 },
    { header: "HSN/SAC", key: "hsnSacCode", width: 18 },
    { header: "Qty", key: "quantity", width: 8 },
    { header: "Unit", key: "unit", width: 12 },
    { header: "Unit Rate", key: "unitRate", width: 12 },
    { header: "Line Total", key: "lineTotal", width: 12 },
    { header: "GST %", key: "gstPercent", width: 10 },
    { header: "Tax Slab %", key: "taxSlabPercent", width: 12 },
    { header: "CGST", key: "cgstAmount", width: 12 },
    { header: "SGST", key: "sgstAmount", width: 12 },
    { header: "IGST", key: "igstAmount", width: 12 },
    { header: "Tax Total", key: "taxAmount", width: 12 },
    { header: "Grand Total", key: "totalWithTax", width: 14 },
    { header: "Currency", key: "currency", width: 10 },
  ];

  ws.mergeCells("A1:E1");
  ws.getCell("A1").value = "Invoice";
  ws.getCell("A1").font = { size: 16, bold: true };

  const info: [string, any][] = [
    ["Invoice Number", invoice.invoiceNumber],
    ["Invoice Date", invoice.invoiceDate],
    ["Due Date", invoice.dueDate],
    ["Mode", invoice.invoiceMode],
    ["GST Type", invoice.invoiceMode === "INDIA" ? invoice.indiaTaxType : ""],
    ["Bill To Name", invoice.billableParty?.name],
    ["Bill To Contact", invoice.billableParty?.contactName],
    ["Advertiser", invoice.billableParty?.advertiser],
    ["Address", invoice.billableParty?.address],
    ["Bill To Email", invoice.billableParty?.email],
    ["Bill To Phone", invoice.billableParty?.phone],
    ["Project No", invoice.billableParty?.projectNo],
    ["Brand", invoice.billableParty?.brand],
    ["PO Number", invoice.billableParty?.poNumber],
    ["PAN", invoice.billableParty?.panNumber],
    ["GST", invoice.billableParty?.gstNumber],
    ["Payment Terms", invoice.billableParty?.paymentTerms],
  ];
  if (invoice.notes) info.push(["Notes", invoice.notes]);

  let rowNo = 3;
  for (const [label, value] of info) {
    ws.getCell(`A${rowNo}`).value = label;
    ws.getCell(`A${rowNo}`).font = { bold: true };
    ws.mergeCells(`B${rowNo}:F${rowNo}`);
    ws.getCell(`B${rowNo}`).value = value ?? "";
    rowNo += 1;
  }

  rowNo += 1;
  const headerRow = ws.getRow(rowNo);
  headerRow.values = ws.columns.map((c: any) => c.header);
  headerRow.font = { bold: true };
  rowNo += 1;

  for (const row of invoice.rows || []) {
    ws.getRow(rowNo).values = [
      row.date,
      row.description,
      row.project,
      row.creative,
      row.destination,
      row.channel,
      row.sla,
      row.action,
      row.itemCode,
      row.hsnSacCode,
      n(row.quantity),
      row.unit,
      n(row.unitRate),
      n(row.lineTotal),
      n(row.gstPercent),
      n(row.taxSlabPercent),
      n(row.cgstAmount),
      n(row.sgstAmount),
      n(row.igstAmount),
      n(row.taxAmount),
      n(row.totalWithTax),
      row.currency,
    ];
    rowNo += 1;
  }

  const firstDataRow = info.length + 5;
  for (let i = firstDataRow; i < rowNo; i += 1) {
    for (const col of ["K", "M", "N", "O", "P", "Q", "R", "S", "T", "U"]) {
      ws.getCell(`${col}${i}`).numFmt = "0.00";
    }
  }

  rowNo += 1;
  ws.getCell(`A${rowNo}`).value = "Totals";
  ws.getCell(`A${rowNo}`).font = { bold: true };
  rowNo += 1;
  ws.getRow(rowNo).values = ["Currency", "Sub Total", "Tax Total", "CGST", "SGST", "IGST", "Grand Total"];
  ws.getRow(rowNo).font = { bold: true };
  rowNo += 1;
  for (const total of invoice.totals || []) {
    ws.getRow(rowNo).values = [
      total.currency,
      n(total.subTotal),
      n(total.taxTotal),
      n(total.cgstTotal),
      n(total.sgstTotal),
      n(total.igstTotal),
      n(total.grandTotal),
    ];
    for (const col of ["B", "C", "D", "E", "F", "G"]) ws.getCell(`${col}${rowNo}`).numFmt = "0.00";
    rowNo += 1;
  }

  ws.views = [{ state: "frozen", ySplit: info.length + 4 }];
  const buf = (await wb.xlsx.writeBuffer()) as ArrayBuffer;
  return Buffer.from(buf);
}

function pdfEscape(s: string) {
  return String(s).replace(/\\/g, "\\\\").replace(/\(/g, "\\(").replace(/\)/g, "\\)");
}

function asciiText(value: any): string {
  const raw = String(value ?? "")
    .replace(/[“”]/g, '"')
    .replace(/[‘’]/g, "'")
    .replace(/[–—]/g, "-")
    .replace(/•/g, " | ")
    .replace(/\u00a0/g, " ")
    .replace(/\s+/g, " ")
    .trim();
  return raw.normalize("NFKD").replace(/[^\x20-\x7E]/g, "");
}

function fmtDate(value: any): string {
  if (!value) return "";
  const asDate = new Date(value);
  if (Number.isNaN(asDate.getTime())) return asciiText(value);
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  return `${String(asDate.getDate()).padStart(2, "0")} ${months[asDate.getMonth()]} ${asDate.getFullYear()}`;
}

function rgb(color: Rgb): string {
  return color.map((part) => (part / 255).toFixed(3)).join(" ");
}

function estimateTextWidth(text: string, size: number, font: FontKey = "F1"): number {
  const weights: Record<FontKey, number> = { F1: 0.50, F2: 0.56, F3: 0.50, F4: 0.56 };
  return asciiText(text).length * size * weights[font];
}

function wrapText(text: string, maxWidth: number, size: number, font: FontKey = "F1"): string[] {
  const cleaned = asciiText(text);
  if (!cleaned) return [""];
  const lines: string[] = [];
  for (const rawLine of cleaned.split(/\n+/)) {
    const words = rawLine.split(/\s+/).filter(Boolean);
    if (!words.length) {
      lines.push("");
      continue;
    }
    let current = "";
    for (const word of words) {
      const candidate = current ? `${current} ${word}` : word;
      if (estimateTextWidth(candidate, size, font) <= maxWidth || !current) {
        current = candidate;
      } else {
        lines.push(current);
        current = word;
      }
    }
    if (current) lines.push(current);
  }
  return lines.length ? lines : [""];
}

function drawText(commands: string[], text: string, x: number, y: number, options: TextOptions = {}) {
  const cleaned = asciiText(text);
  if (!cleaned) return;
  const font = options.font || "F1";
  const size = options.size || 10;
  const color = options.color || ([35, 29, 27] as Rgb);
  const align = options.align || "left";
  let xPos = x;
  const width = estimateTextWidth(cleaned, size, font);
  if (align === "center") xPos -= width / 2;
  if (align === "right") xPos -= width;
  commands.push("BT");
  commands.push(`/${font} ${size} Tf`);
  commands.push(`${rgb(color)} rg`);
  commands.push(`1 0 0 1 ${xPos.toFixed(2)} ${y.toFixed(2)} Tm`);
  commands.push(`(${pdfEscape(cleaned)}) Tj`);
  commands.push("ET");
}

function drawTextBlock(commands: string[], text: string, x: number, yTop: number, width: number, options: TextOptions & { leading?: number } = {}): number {
  const font = options.font || "F1";
  const size = options.size || 10;
  const leading = options.leading || size * 1.35;
  const lines = wrapText(text, width, size, font);
  let y = yTop;
  for (const line of lines) {
    drawText(commands, line, x, y, options);
    y -= leading;
  }
  return lines.length * leading;
}

function rect(commands: string[], x: number, y: number, w: number, h: number, fill?: Rgb, stroke?: Rgb, lineWidth = 1) {
  commands.push("q");
  if (fill) commands.push(`${rgb(fill)} rg`);
  if (stroke) {
    commands.push(`${rgb(stroke)} RG`);
    commands.push(`${lineWidth.toFixed(2)} w`);
  }
  commands.push(`${x.toFixed(2)} ${y.toFixed(2)} ${w.toFixed(2)} ${h.toFixed(2)} re ${fill && stroke ? "B" : fill ? "f" : "S"}`);
  commands.push("Q");
}

function line(commands: string[], x1: number, y1: number, x2: number, y2: number, stroke: Rgb, lineWidth = 1) {
  commands.push("q");
  commands.push(`${rgb(stroke)} RG`);
  commands.push(`${lineWidth.toFixed(2)} w`);
  commands.push(`${x1.toFixed(2)} ${y1.toFixed(2)} m ${x2.toFixed(2)} ${y2.toFixed(2)} l S`);
  commands.push("Q");
}

function circle(commands: string[], cx: number, cy: number, r: number, fill?: Rgb, stroke?: Rgb, lineWidth = 1) {
  const k = 0.5522847498;
  const c = r * k;
  commands.push("q");
  if (fill) commands.push(`${rgb(fill)} rg`);
  if (stroke) {
    commands.push(`${rgb(stroke)} RG`);
    commands.push(`${lineWidth.toFixed(2)} w`);
  }
  commands.push([
    `${(cx + r).toFixed(2)} ${cy.toFixed(2)} m`,
    `${(cx + r).toFixed(2)} ${(cy + c).toFixed(2)} ${(cx + c).toFixed(2)} ${(cy + r).toFixed(2)} ${cx.toFixed(2)} ${(cy + r).toFixed(2)} c`,
    `${(cx - c).toFixed(2)} ${(cy + r).toFixed(2)} ${(cx - r).toFixed(2)} ${(cy + c).toFixed(2)} ${(cx - r).toFixed(2)} ${cy.toFixed(2)} c`,
    `${(cx - r).toFixed(2)} ${(cy - c).toFixed(2)} ${(cx - c).toFixed(2)} ${(cy - r).toFixed(2)} ${cx.toFixed(2)} ${(cy - r).toFixed(2)} c`,
    `${(cx + c).toFixed(2)} ${(cy - r).toFixed(2)} ${(cx + r).toFixed(2)} ${(cy - c).toFixed(2)} ${(cx + r).toFixed(2)} ${cy.toFixed(2)} c`,
    fill && stroke ? "B" : fill ? "f" : "S",
  ].join("\n"));
  commands.push("Q");
}

function polygon(commands: string[], points: Array<[number, number]>, fill?: Rgb, stroke?: Rgb, lineWidth = 1) {
  if (!points.length) return;
  commands.push("q");
  if (fill) commands.push(`${rgb(fill)} rg`);
  if (stroke) {
    commands.push(`${rgb(stroke)} RG`);
    commands.push(`${lineWidth.toFixed(2)} w`);
  }
  const [firstX, firstY] = points[0];
  const segments = [`${firstX.toFixed(2)} ${firstY.toFixed(2)} m`];
  for (let i = 1; i < points.length; i += 1) {
    const [x, y] = points[i];
    segments.push(`${x.toFixed(2)} ${y.toFixed(2)} l`);
  }
  segments.push("h");
  segments.push(fill && stroke ? "B" : fill ? "f" : "S");
  commands.push(segments.join("\n"));
  commands.push("Q");
}

function buildPdfDocument(pageStreams: string[]): Buffer {
  const objects: string[] = [];
  const addObject = (body: string) => {
    objects.push(body);
    return objects.length;
  };

  const catalogId = addObject("");
  const pagesId = addObject("");
  const helveticaId = addObject("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>");
  const helveticaBoldId = addObject("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>");
  const helveticaObliqueId = addObject("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Oblique >>");
  const helveticaBoldObliqueId = addObject("<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-BoldOblique >>");

  const pageIds: number[] = [];
  for (const stream of pageStreams) {
    const contentId = addObject(`<< /Length ${Buffer.byteLength(stream, "utf8")} >>\nstream\n${stream}\nendstream`);
    const pageId = addObject(`<< /Type /Page /Parent ${pagesId} 0 R /MediaBox [0 0 595 842] /Resources << /Font << /F1 ${helveticaId} 0 R /F2 ${helveticaBoldId} 0 R /F3 ${helveticaObliqueId} 0 R /F4 ${helveticaBoldObliqueId} 0 R >> >> /Contents ${contentId} 0 R >>`);
    pageIds.push(pageId);
  }

  objects[pagesId - 1] = `<< /Type /Pages /Count ${pageIds.length} /Kids [${pageIds.map((id) => `${id} 0 R`).join(" ")}] >>`;
  objects[catalogId - 1] = `<< /Type /Catalog /Pages ${pagesId} 0 R >>`;

  const chunks: string[] = ["%PDF-1.4\n"];
  const offsets: number[] = [0];
  let cursor = chunks[0].length;
  for (let i = 0; i < objects.length; i += 1) {
    offsets.push(cursor);
    const obj = `${i + 1} 0 obj\n${objects[i]}\nendobj\n`;
    chunks.push(obj);
    cursor += obj.length;
  }

  const xrefOffset = cursor;
  chunks.push(`xref\n0 ${objects.length + 1}\n`);
  chunks.push("0000000000 65535 f \n");
  for (let i = 1; i <= objects.length; i += 1) {
    chunks.push(`${String(offsets[i]).padStart(10, "0")} 00000 n \n`);
  }
  chunks.push(`trailer\n<< /Size ${objects.length + 1} /Root ${catalogId} 0 R >>\nstartxref\n${xrefOffset}\n%%EOF`);
  return Buffer.from(chunks.join(""), "utf8");
}

function deriveServicePeriod(invoice: InvoiceLike): string {
  const dates = (invoice.rows || []).map((row: any) => new Date(row.date)).filter((d: Date) => !Number.isNaN(d.getTime())).sort((a: Date, b: Date) => a.getTime() - b.getTime());
  if (!dates.length) return fmtDate(invoice.invoiceDate);
  return `${fmtDate(dates[0])} - ${fmtDate(dates[dates.length - 1])}`;
}

function describeRow(row: any) {
  const headline = asciiText(row.description || row.action || row.itemCode || "Service");
  const detail = [row.project, row.creative, row.destination, row.channel, row.sla].map((part) => asciiText(part)).filter(Boolean).join(" | ");
  const meta = [row.itemCode ? `Code ${asciiText(row.itemCode)}` : "", row.hsnSacCode ? `HSN/SAC ${asciiText(row.hsnSacCode)}` : "", row.currency ? `Curr ${asciiText(row.currency)}` : ""].filter(Boolean).join(" | ");
  return { headline, detail, meta };
}

function drawPageBackground(commands: string[]) {
  const bg: Rgb = [234, 227, 213];
  const inkDark: Rgb = [49, 40, 40];
  const softAccent: Rgb = [112, 95, 90];
  rect(commands, 0, 0, 595, 842, bg);
  polygon(commands, [[0, 842], [0, 780], [185, 806], [138, 842]], inkDark);
  polygon(commands, [[360, 842], [595, 842], [595, 692], [500, 732], [462, 700]], inkDark);
  polygon(commands, [[0, 0], [0, 90], [190, 54], [245, 0]], softAccent);
  polygon(commands, [[380, 0], [595, 0], [595, 138], [522, 110], [468, 72]], inkDark);
}

function drawBrand(commands: string[], companyName: string) {
  const dark: Rgb = [40, 32, 31];
  const light: Rgb = [244, 239, 232];
  circle(commands, 500, 735, 28, dark);
  circle(commands, 500, 735, 12, light);
  drawText(commands, companyName, 500, 684, { font: "F2", size: 16, color: dark, align: "center" });
  drawText(commands, "MEDIA DELIVERY", 500, 668, { font: "F1", size: 8, color: dark, align: "center" });
}

function drawInfoCard(commands: string[], title: string, lines: string[], x: number, yTop: number, width: number, height: number) {
  const card: Rgb = [248, 244, 238];
  const border: Rgb = [188, 177, 162];
  const ink: Rgb = [43, 35, 33];
  const muted: Rgb = [110, 95, 88];
  rect(commands, x, yTop - height, width, height, card, border, 0.8);
  drawText(commands, title, x + 14, yTop - 24, { font: "F2", size: 12, color: ink });
  line(commands, x + 14, yTop - 34, x + width - 14, yTop - 34, border, 0.8);
  let cursor = yTop - 54;
  if (!lines.length) lines = ["-"];
  for (let i = 0; i < lines.length && cursor > yTop - height + 18; i += 1) {
    const used = drawTextBlock(commands, lines[i], x + 14, cursor, width - 28, { font: i === 0 ? "F2" : "F1", size: i === 0 ? 11 : 9, color: i === 0 ? ink : muted, leading: i === 0 ? 13 : 11 });
    cursor -= used + 1;
  }
}


function buildSectionText(title: string, lines: string[]): string {
  const cleaned = lines.map((lineText) => asciiText(lineText)).filter(Boolean);
  if (!cleaned.length) return "";
  return `${asciiText(title)}\n${cleaned.join("\n")}`;
}

function buildPaymentAndNotesText(invoice: InvoiceLike): string {
  const sections = [
    buildSectionText("Invoice From", [
      invoice.invoiceFrom?.name || "",
      invoice.invoiceFrom?.address || "",
      invoice.invoiceFrom?.email ? `Email: ${invoice.invoiceFrom.email}` : "",
      invoice.invoiceFrom?.phone ? `Phone: ${invoice.invoiceFrom.phone}` : "",
      invoice.invoiceFrom?.gstNumber ? `GST: ${invoice.invoiceFrom.gstNumber}` : "",
      invoice.invoiceFrom?.panNumber ? `PAN: ${invoice.invoiceFrom.panNumber}` : "",
    ]),
    buildSectionText("Bank Details", [
      invoice.bankDetails?.beneficiaryName ? `Beneficiary: ${invoice.bankDetails.beneficiaryName}` : "",
      invoice.bankDetails?.bankName ? `Bank: ${invoice.bankDetails.bankName}` : "",
      invoice.bankDetails?.bankBranch ? `Branch: ${invoice.bankDetails.bankBranch}` : "",
      invoice.bankDetails?.accountNumber ? `Account No: ${invoice.bankDetails.accountNumber}` : "",
      invoice.bankDetails?.ifscCode ? `IFSC: ${invoice.bankDetails.ifscCode}` : "",
      invoice.bankDetails?.accountType ? `Type: ${invoice.bankDetails.accountType}` : "",
    ]),
    buildSectionText("Notes & Terms", [
      invoice.notes || "",
      invoice.billableParty?.paymentTerms ? `Payment Terms: ${invoice.billableParty.paymentTerms}` : "",
      invoice.invoiceMode === "INDIA" ? `Tax treatment: ${invoice.indiaTaxType === "INTER" ? "IGST" : "CGST + SGST"}` : "Tax treatment: Global slab",
    ]),
  ].filter(Boolean);

  return sections.join("\n\n");
}

function invoiceToPdf(invoice: InvoiceLike): Buffer {
  const accentDark: Rgb = [40, 32, 31];
  const accentSoft: Rgb = [116, 100, 94];
  const panel: Rgb = [248, 244, 238];
  const panelAlt: Rgb = [242, 237, 231];
  const border: Rgb = [184, 172, 159];
  const warning: Rgb = [120, 86, 45];
  const pages: string[] = [];
  const companyName = "eSendIT";

  const billToLines = [
    invoice.billableParty?.name || "",
    invoice.billableParty?.contactName ? `Contact: ${invoice.billableParty.contactName}` : "",
    invoice.billableParty?.advertiser ? `Advertiser: ${invoice.billableParty.advertiser}` : "",
    invoice.billableParty?.projectNo ? `Project No: ${invoice.billableParty.projectNo}` : "",
    invoice.billableParty?.brand ? `Brand: ${invoice.billableParty.brand}` : "",
    invoice.billableParty?.poNumber ? `PO Number: ${invoice.billableParty.poNumber}` : "",
    invoice.billableParty?.address || "",
    invoice.billableParty?.email ? `Email: ${invoice.billableParty.email}` : "",
    invoice.billableParty?.phone ? `Phone: ${invoice.billableParty.phone}` : "",
    invoice.billableParty?.panNumber ? `PAN: ${invoice.billableParty.panNumber}` : "",
    invoice.billableParty?.gstNumber ? `GST: ${invoice.billableParty.gstNumber}` : "",
  ].filter(Boolean).map((lineText) => asciiText(lineText));

  const servicePeriod = deriveServicePeriod(invoice);
  const totals = Array.isArray(invoice.totals) ? invoice.totals : [];
  const totalsHeight = Math.max(96, 32 + totals.length * (invoice.invoiceMode === "INDIA" ? 72 : 50));
  const paymentAndNotesText = buildPaymentAndNotesText(invoice);
  const paymentAndNotesLines = paymentAndNotesText ? paymentAndNotesText.split(/\n/).length : 0;
  const notesHeight = Math.max(104, 44 + paymentAndNotesLines * 12);
  const summaryReserveHeight = Math.max(totalsHeight, notesHeight);

  let pageIndex = 0;
  let commands: string[] = [];
  let y = 0;

  const startPage = (compact = false) => {
    pageIndex += 1;
    commands = [];
    drawPageBackground(commands);
    if (compact) {
      drawText(commands, "INVOICE", 44, 786, { font: "F2", size: 22, color: accentDark });
      drawText(commands, asciiText(invoice.invoiceNumber || ""), 44, 765, { font: "F3", size: 11, color: accentSoft });
      circle(commands, 520, 762, 18, accentDark);
      circle(commands, 520, 762, 8, [244, 239, 232]);
      line(commands, 44, 742, 551, 742, border, 1);
      y = 714;
      return;
    }

    drawText(commands, "INVOICE", 44, 754, { font: "F2", size: 34, color: accentDark });
    drawText(commands, asciiText(invoice.invoiceNumber || ""), 44, 724, { font: "F3", size: 14, color: accentSoft });
    drawText(commands, `Invoice Date: ${fmtDate(invoice.invoiceDate)}`, 44, 698, { font: "F1", size: 10, color: accentSoft });
    drawText(commands, `Due Date: ${fmtDate(invoice.dueDate)}`, 210, 698, { font: "F1", size: 10, color: accentSoft });
    drawBrand(commands, companyName);
    drawInfoCard(commands, "Bill To", billToLines, 44, 650, 280, 132);
    drawInfoCard(commands, "Invoice Details", [
      `Mode: ${asciiText(invoice.invoiceMode || "GLOBAL")}`,
      invoice.invoiceMode === "INDIA" ? `GST Type: ${asciiText(invoice.indiaTaxType || "INTRA")}` : "Tax Model: Global slab",
      `Service Period: ${servicePeriod}`,
      `Rows Included: ${String(invoice.rowCount || (invoice.rows || []).length || 0)}`,
      invoice.billableParty?.projectNo ? `Project No: ${asciiText(invoice.billableParty.projectNo)}` : "",
      invoice.billableParty?.brand ? `Brand: ${asciiText(invoice.billableParty.brand)}` : "",
      invoice.billableParty?.poNumber ? `PO Number: ${asciiText(invoice.billableParty.poNumber)}` : "",
      invoice.billableParty?.paymentTerms ? `Payment Terms: ${asciiText(invoice.billableParty.paymentTerms)}` : "",
    ].filter(Boolean), 338, 650, 213, 132);

    rect(commands, 44, 478, 507, 58, panelAlt, border, 0.8);
    drawText(commands, "Invoice For", 58, 515, { font: "F2", size: 12, color: accentDark });
    drawTextBlock(commands, "Media delivery, transcode, QC and related workflow services covered by the selected billing filters.", 58, 495, 350, { font: "F3", size: 10, color: accentSoft, leading: 12 });
    drawText(commands, `Service Period: ${servicePeriod}`, 535, 512, { font: "F2", size: 10, color: accentDark, align: "right" });
    drawText(commands, `Mode: ${asciiText(invoice.invoiceMode || "GLOBAL")}`, 535, 494, { font: "F1", size: 9, color: accentSoft, align: "right" });
    y = 452;
  };

  const finishPage = () => {
    drawText(commands, `Page ${String(pageIndex)}`, 551, 24, { font: "F1", size: 8, color: accentSoft, align: "right" });
    pages.push(commands.join("\n"));
  };

  const drawTableHeader = () => {
    rect(commands, 44, y - 28, 507, 28, panel, border, 0.8);
    drawText(commands, "Item", 58, y - 18, { font: "F2", size: 11, color: accentDark });
    drawText(commands, "Qty", 318, y - 18, { font: "F2", size: 11, color: accentDark, align: "center" });
    drawText(commands, "Unit Price", 390, y - 18, { font: "F2", size: 11, color: accentDark, align: "center" });
    drawText(commands, "Tax", 462, y - 18, { font: "F2", size: 11, color: accentDark, align: "center" });
    drawText(commands, "Total", 530, y - 18, { font: "F2", size: 11, color: accentDark, align: "right" });
    y -= 36;
  };

  const drawRow = (row: any) => {
    const parts = describeRow(row);
    const mainLines = wrapText(parts.headline, 250, 10, "F2");
    const detailLines = parts.detail ? wrapText(parts.detail, 250, 8.5, "F1") : [];
    const metaLines = parts.meta ? wrapText(parts.meta, 250, 8.5, "F3") : [];
    const textLines = mainLines.length + detailLines.length + metaLines.length;
    const rowHeight = Math.max(34, 12 + textLines * 11);

    rect(commands, 44, y - rowHeight + 4, 507, rowHeight, [250, 248, 244]);
    line(commands, 44, y - rowHeight + 4, 551, y - rowHeight + 4, border, 0.6);

    let textY = y - 14;
    for (const lineText of mainLines) {
      drawText(commands, lineText, 58, textY, { font: "F2", size: 10, color: accentDark });
      textY -= 12;
    }
    for (const lineText of detailLines) {
      drawText(commands, lineText, 58, textY, { font: "F1", size: 8.5, color: accentSoft });
      textY -= 10;
    }
    for (const lineText of metaLines) {
      drawText(commands, lineText, 58, textY, { font: "F3", size: 8.5, color: accentSoft });
      textY -= 10;
    }

    drawText(commands, String(n(row.quantity)), 318, y - 18, { font: "F1", size: 10, color: accentDark, align: "center" });
    drawText(commands, money(row.unitRate), 430, y - 18, { font: "F1", size: 10, color: accentDark, align: "right" });
    drawText(commands, money(row.taxAmount), 485, y - 18, { font: "F1", size: 10, color: accentDark, align: "right" });
    drawText(commands, money(row.totalWithTax), 530, y - 18, { font: "F2", size: 10, color: accentDark, align: "right" });

    y -= rowHeight;
  };

  const drawTotalsBox = () => {
    const notesBoxWidth = 250;
    const totalsBoxWidth = 237;
    const boxTop = y;

    rect(commands, 44, boxTop - notesHeight, notesBoxWidth, notesHeight, panelAlt, border, 0.8);
    drawText(commands, "Payment & Notes", 58, boxTop - 22, { font: "F2", size: 12, color: accentDark });
    const notesContent = paymentAndNotesText || "Payment notes were not added for this invoice.";
    drawTextBlock(commands, notesContent, 58, boxTop - 44, notesBoxWidth - 28, { font: "F1", size: 8.5, color: accentSoft, leading: 11 });

    rect(commands, 314, boxTop - totalsHeight, totalsBoxWidth, totalsHeight, panel, border, 0.8);
    drawText(commands, "Total Amount Due", 328, boxTop - 22, { font: "F2", size: 12, color: accentDark });

    let totalsY = boxTop - 46;
    for (const total of totals) {
      drawText(commands, asciiText(total.currency || "EUR"), 328, totalsY, { font: "F2", size: 10, color: accentDark });
      drawText(commands, `${asciiText(total.currency || "EUR")} ${money(total.grandTotal)}`, 535, totalsY, { font: "F2", size: 12, color: accentDark, align: "right" });
      totalsY -= 16;

      const rows: Array<[string, string]> = [["Sub Total", money(total.subTotal)], ["Tax Total", money(total.taxTotal)]];
      if (invoice.invoiceMode === "INDIA") {
        rows.push(["CGST", money(total.cgstTotal)]);
        rows.push(["SGST", money(total.sgstTotal)]);
        rows.push(["IGST", money(total.igstTotal)]);
      }
      rows.push(["Grand Total", money(total.grandTotal)]);

      for (const [label, amount] of rows) {
        drawText(commands, label, 328, totalsY, { font: label === "Grand Total" ? "F2" : "F1", size: 9.5, color: accentSoft });
        drawText(commands, amount, 535, totalsY, { font: label === "Grand Total" ? "F2" : "F1", size: 9.5, color: accentSoft, align: "right" });
        totalsY -= 12;
      }

      if (total !== totals[totals.length - 1]) {
        line(commands, 328, totalsY + 2, 535, totalsY + 2, border, 0.7);
        totalsY -= 12;
      }
    }

    y = Math.min(boxTop - totalsHeight, boxTop - notesHeight) - 12;
  };

  startPage(false);
  if (Array.isArray(invoice.warnings) && invoice.warnings.length) {
    rect(commands, 44, y - 34, 507, 28, [247, 239, 225], [214, 182, 136], 0.8);
    drawText(commands, asciiText(invoice.warnings[0]), 58, y - 23, { font: "F1", size: 9, color: warning });
    y -= 44;
  }

  drawTableHeader();

  const invoiceRows = Array.isArray(invoice.rows) && invoice.rows.length ? invoice.rows : [{ description: "No billable rows matched the current invoice filters.", quantity: 0, unitRate: 0, taxAmount: 0, totalWithTax: 0, currency: totals[0]?.currency || "EUR", project: "", creative: "", destination: "", channel: "", sla: "", itemCode: "", hsnSacCode: "" }];

  for (let i = 0; i < invoiceRows.length; i += 1) {
    const row = invoiceRows[i];
    const parts = describeRow(row);
    const mainLines = wrapText(parts.headline, 250, 10, "F2");
    const detailLines = parts.detail ? wrapText(parts.detail, 250, 8.5, "F1") : [];
    const metaLines = parts.meta ? wrapText(parts.meta, 250, 8.5, "F3") : [];
    const rowHeight = Math.max(34, 12 + (mainLines.length + detailLines.length + metaLines.length) * 11);
    const reserveForTotals = i === invoiceRows.length - 1 ? summaryReserveHeight + 42 : 24;
    if (y - rowHeight < 96 + reserveForTotals) {
      finishPage();
      startPage(true);
      drawTableHeader();
    }
    drawRow(row);
  }

  if (y < summaryReserveHeight + 72) {
    finishPage();
    startPage(true);
  }

  drawTotalsBox();
  drawText(commands, "Thank you for your business.", 44, 46, { font: "F4", size: 10, color: accentDark });
  drawText(commands, "This invoice was generated from eSendIT billing data.", 44, 32, { font: "F1", size: 8.5, color: accentSoft });
  finishPage();

  return buildPdfDocument(pages);
}

export { invoiceToPdf };
