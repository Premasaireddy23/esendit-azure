export const chargeRowSelect = {
  id: true,
  originKey: true,
  action: true,
  quantity: true,
  unit: true,
  amount: true,
  currency: true,
  occurredAt: true,
  missingReason: true,
  meta: true,

  billablePartyId: true,
  projectId: true,
  creativeId: true,
  creativeAssetId: true,
  destinationId: true,
  channelId: true,
  slaId: true,

  billableParty: { select: { id: true, name: true, code: true } },
  project: { select: { id: true, name: true, projectNumber: true, projectCode: true } },
  creative: { select: { id: true, name: true, valid: true, title: true } },
  creativeAsset: { select: { id: true, type: true, filename: true } },

  destination: { select: { id: true, name: true, code: true } },
  channel: { select: { id: true, name: true, code: true } },
  sla: { select: { id: true, name: true } },

  rateCard: { select: { id: true, name: true } },
  rateCardItem: { select: { id: true, action: true, code: true, label: true, amount: true, sdAmount: true, hdAmount: true, currency: true, unit: true, slaId: true, meta: true } },
} as const;
