import * as ExcelJS from "exceljs";

type ChargeRowLike = any;

function csvEscape(v: any): string {
  if (v === null || v === undefined) return "";
  const s = String(v);
  if (/[\n\r,\"]/g.test(s)) {
    return '"' + s.replace(/"/g, '""') + '"';
  }
  return s;
}

function pick(row: ChargeRowLike, path: string): any {
  const parts = path.split(".");
  let cur: any = row;
  for (const p of parts) {
    if (cur == null) return undefined;
    cur = cur[p];
  }
  return cur;
}

export const EXPORT_COLUMNS = [
  { key: "occurredAt", header: "Occurred At", getter: (r: any) => r.occurredAt },
  { key: "action", header: "Action", getter: (r: any) => r.action },
  { key: "quantity", header: "Qty", getter: (r: any) => r.quantity },
  { key: "unit", header: "Unit", getter: (r: any) => r.unit },
  { key: "amount", header: "Amount", getter: (r: any) => r.amount },
  { key: "currency", header: "Currency", getter: (r: any) => r.currency },

  { key: "billableParty", header: "Billable Party", getter: (r: any) => pick(r, "billableParty.name") },
  { key: "projectNumber", header: "Project #", getter: (r: any) => pick(r, "project.projectNumber") },
  { key: "projectCode", header: "Project Code", getter: (r: any) => pick(r, "project.projectCode") },
  { key: "projectName", header: "Project Name", getter: (r: any) => pick(r, "project.name") },
  { key: "creative", header: "Creative", getter: (r: any) => pick(r, "creative.name") ?? pick(r, "creative.valid") },
  { key: "destination", header: "Destination", getter: (r: any) => pick(r, "destination.name") },
  { key: "channel", header: "Channel", getter: (r: any) => pick(r, "channel.name") },
  { key: "sla", header: "SLA", getter: (r: any) => pick(r, "sla.name") },

  { key: "originKey", header: "Origin Key", getter: (r: any) => r.originKey },
  { key: "missingReason", header: "Missing Reason", getter: (r: any) => r.missingReason },
  { key: "id", header: "ChargeRow ID", getter: (r: any) => r.id },
];

export function chargesToCsv(rows: any[]): string {
  const headers = EXPORT_COLUMNS.map((c) => c.header);
  const out: string[] = [];
  out.push(headers.map(csvEscape).join(","));

  for (const r of rows) {
    const line = EXPORT_COLUMNS.map((c) => {
      const v = c.getter(r);
      // Dates: ensure stable string
      if (v instanceof Date) return csvEscape(v.toISOString());
      return csvEscape(v);
    }).join(",");
    out.push(line);
  }

  return out.join("\n");
}

export async function chargesToExcel(rows: any[]): Promise<Buffer> {
  const wb = new ExcelJS.Workbook();
  wb.creator = "eSendIT";
  wb.created = new Date();

  const ws = wb.addWorksheet("Charges");
  ws.columns = EXPORT_COLUMNS.map((c) => ({ header: c.header, key: c.key, width: 22 }));

  for (const r of rows) {
    const obj: any = {};
    for (const c of EXPORT_COLUMNS) {
      const v = c.getter(r);
      if (v instanceof Date) obj[c.key] = v;
      else obj[c.key] = v;
    }
    ws.addRow(obj);
  }

  // Basic formats
  const occurredAtCol = ws.getColumn("occurredAt");
  occurredAtCol.numFmt = "yyyy-mm-dd hh:mm:ss";

  const qtyCol = ws.getColumn("quantity");
  qtyCol.numFmt = "0";

  const amtCol = ws.getColumn("amount");
  amtCol.numFmt = "0.00";

  // Header styling (light)
  ws.getRow(1).font = { bold: true };
  ws.views = [{ state: "frozen", ySplit: 1 }];

  const buf = (await wb.xlsx.writeBuffer()) as ArrayBuffer;
  return Buffer.from(buf);
}
