import { IsArray, IsBoolean, IsInt, IsOptional, IsUUID, Max, Min } from "class-validator";

export class RunServerCheckDto {
  @IsOptional()
  @IsUUID()
  destinationId?: string;

  @IsOptional()
  @IsArray()
  @IsUUID("4", { each: true })
  channelIds?: string[];

  @IsOptional()
  @IsBoolean()
  onlyActive?: boolean;

  @IsOptional()
  @IsInt()
  @Min(500)
  @Max(20000)
  timeoutMs?: number;

  @IsOptional()
  @IsInt()
  @Min(1)
  @Max(200)
  limit?: number;
}
