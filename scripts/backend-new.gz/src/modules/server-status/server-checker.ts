import * as net from "node:net";
import { ServerStatus } from "@prisma/client";

export type CheckInput = {
  protocol: string;
  host?: string;
  port?: number;
  // optional fallback parse from URI if config is missing
  uriFallback?: string;
  timeoutMs: number;
};

export type CheckResult = {
  status: ServerStatus;
  latencyMs?: number;
  message?: string;
  raw?: any;
};

function parseHostPortFromUri(uri?: string | null): { host?: string; port?: number } {
  if (!uri) return {};
  try {
    const u = new URL(uri);
    return { host: u.hostname, port: u.port ? Number(u.port) : undefined };
  } catch {
    return {};
  }
}

export async function tcpCheck(host: string, port: number, timeoutMs: number): Promise<CheckResult> {
  const start = Date.now();

  return new Promise((resolve) => {
    const socket = new net.Socket();
    let done = false;

    const finish = (res: CheckResult) => {
      if (done) return;
      done = true;
      try { socket.destroy(); } catch {}
      resolve(res);
    };

    socket.setTimeout(timeoutMs);

    socket.once("connect", () => {
      const latencyMs = Date.now() - start;
      finish({ status: ServerStatus.ONLINE, latencyMs });
    });

    socket.once("timeout", () => {
      finish({ status: ServerStatus.OFFLINE, message: `Timeout after ${timeoutMs}ms` });
    });

    socket.once("error", (err) => {
      finish({ status: ServerStatus.OFFLINE, message: err?.message || "Connection error" });
    });

    socket.connect(port, host);
  });
}

export async function checkEndpoint(input: CheckInput): Promise<CheckResult> {
  const cfgHost = input.host;
  const cfgPort = input.port;

  const fallback = parseHostPortFromUri(input.uriFallback);
  const host = cfgHost || fallback.host;
  const port =
    cfgPort ||
    fallback.port ||
    (input.protocol === "SFTP" ? 22 : input.protocol === "FTP" ? 21 : input.protocol === "ASPERA" ? 33001 : input.protocol === "FILECATALYST" ? 21 : undefined);

  if (!host || !port) {
    return { status: ServerStatus.UNKNOWN, message: "Missing host/port in config (or uri fallback)" };
  }

  if (input.protocol === "SFTP" || input.protocol === "FTP" || input.protocol === "ASPERA" || input.protocol === "FILECATALYST") {
    return tcpCheck(host, port, input.timeoutMs);
  }

  // For now, do not attempt auth-based checks for S3/EMAIL
  return { status: ServerStatus.UNKNOWN, message: `Protocol ${input.protocol} not supported for ping` };
}
