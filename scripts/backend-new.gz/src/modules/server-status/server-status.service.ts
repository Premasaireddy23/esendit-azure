import { Injectable } from "@nestjs/common";
import { PrismaService } from "../../common/prisma/prisma.service";
import { MasterStatus, ServerCheckTargetKind, ServerStatus } from "@prisma/client";
import { channelForServerCheckSelect } from "../../common/prisma/selects";
import { checkEndpoint } from "./server-checker";
import { RunServerCheckDto } from "./dto/run-server-check.dto";

type CheckRow = {
  targetKind: ServerCheckTargetKind;
  channelId?: string | null;
  deliveryProfileId?: string | null;
  status: ServerStatus;
  latencyMs?: number | null;
  message?: string | null;
};

@Injectable()
export class ServerStatusService {
  constructor(private prisma: PrismaService) {}

  async run(accountId: string, userId: string, dto: RunServerCheckDto) {
    const onlyActive = dto.onlyActive ?? true;
    const timeoutMs = dto.timeoutMs ?? 3000;
    const limit = dto.limit ?? 200;

    const where: any = { accountId };
    if (dto.destinationId) where.destinationId = dto.destinationId;
    if (dto.channelIds?.length) where.id = { in: dto.channelIds };
    if (onlyActive) where.status = MasterStatus.ACTIVE;

    const channels = await this.prisma.channel.findMany({
      where,
      take: limit,
      orderBy: { name: "asc" },
      select: channelForServerCheckSelect,
    });

    const startedAt = new Date();

    return this.prisma.$transaction(async (tx) => {
      const batch = await tx.serverCheckBatch.create({
        data: {
          accountId,
          createdById: userId,
          filters: { ...dto, onlyActive, timeoutMs, limit },
        },
        select: { id: true, createdAt: true },
      });

      const allChecks: CheckRow[] = [];

      for (const ch of channels as any[]) {
        const destUri = ch?.destination?.uri ?? null;

        // MAIN
        if (ch.mainDeliveryProfile) {
          const cfg = ch.mainDeliveryProfile.config ?? {};
          const res = await checkEndpoint({
            protocol: ch.mainDeliveryProfile.protocol,
            host: cfg.host,
            port: cfg.port,
            uriFallback: destUri,
            timeoutMs,
          });

          allChecks.push({
            targetKind: ServerCheckTargetKind.CHANNEL_MAIN,
            channelId: ch.id,
            deliveryProfileId: ch.mainDeliveryProfile.id,
            status: res.status,
            latencyMs: res.latencyMs ?? null,
            message: res.message ?? null,
          });

          await tx.deliveryProfile.update({
            where: { id: ch.mainDeliveryProfile.id },
            data: {
              lastStatus: res.status,
              lastCheckedAt: startedAt,
              lastError: res.status === ServerStatus.ONLINE ? null : (res.message ?? "Offline"),
            },
          });
        }

        // BACKUP
        if (ch.backupDeliveryProfile) {
          const cfg = ch.backupDeliveryProfile.config ?? {};
          const res = await checkEndpoint({
            protocol: ch.backupDeliveryProfile.protocol,
            host: cfg.host,
            port: cfg.port,
            uriFallback: destUri,
            timeoutMs,
          });

          allChecks.push({
            targetKind: ServerCheckTargetKind.CHANNEL_BACKUP,
            channelId: ch.id,
            deliveryProfileId: ch.backupDeliveryProfile.id,
            status: res.status,
            latencyMs: res.latencyMs ?? null,
            message: res.message ?? null,
          });

          await tx.deliveryProfile.update({
            where: { id: ch.backupDeliveryProfile.id },
            data: {
              lastStatus: res.status,
              lastCheckedAt: startedAt,
              lastError: res.status === ServerStatus.ONLINE ? null : (res.message ?? "Offline"),
            },
          });
        }

        // Compute channel overall
        const main = allChecks.find((c) => c.channelId === ch.id && c.targetKind === "CHANNEL_MAIN");
        const backup = allChecks.find((c) => c.channelId === ch.id && c.targetKind === "CHANNEL_BACKUP");

        const overall =
          main?.status === ServerStatus.ONLINE || backup?.status === ServerStatus.ONLINE
            ? ServerStatus.ONLINE
            : main?.status === ServerStatus.OFFLINE || backup?.status === ServerStatus.OFFLINE
              ? ServerStatus.OFFLINE
              : ServerStatus.UNKNOWN;

        const msg = [
          main ? `main:${main.status}` : null,
          backup ? `backup:${backup.status}` : null,
        ].filter(Boolean).join(" ");

        // latency: prefer main latency, else backup
        const latency = (main?.latencyMs ?? backup?.latencyMs) ?? null;

        await tx.channel.update({
          where: { id: ch.id },
          data: {
            serverStatus: overall,
            serverCheckedAt: startedAt,
            serverLatencyMs: latency,
            serverMessage: msg || null,
          },
        });
      }

      // persist history rows
      for (const r of allChecks) {
        await tx.serverCheck.create({
          data: {
            accountId,
            batchId: batch.id,
            targetKind: r.targetKind,
            channelId: r.channelId ?? null,
            deliveryProfileId: r.deliveryProfileId ?? null,
            status: r.status,
            latencyMs: r.latencyMs ?? null,
            message: r.message ?? null,
          },
        });
      }

      return {
        batchId: batch.id,
        checkedAt: batch.createdAt,
        totalChannels: channels.length,
        totalChecks: allChecks.length,
        checks: allChecks,
      };
    });
  }

  async history(accountId: string, q: { channelId?: string; deliveryProfileId?: string; limit?: number }) {
    const take = Math.min(Math.max(q.limit ?? 50, 1), 200);

    return this.prisma.serverCheck.findMany({
      where: {
        accountId,
        ...(q.channelId ? { channelId: q.channelId } : {}),
        ...(q.deliveryProfileId ? { deliveryProfileId: q.deliveryProfileId } : {}),
      },
      orderBy: { createdAt: "desc" },
      take,
    });
  }
}
