import { Controller, Get, Post, Query, UseGuards, Body } from "@nestjs/common";
import { JwtAuthGuard } from "../../common/auth/jwt-auth.guard";
import { PermissionsGuard } from "../../common/auth/permissions.guard";
import { RequirePermissions } from "../../common/auth/require-permissions.decorator";
import { CurrentUser } from "../../common/auth/current-user.decorator";
import { RunServerCheckDto } from "./dto/run-server-check.dto";
import { ServerStatusService } from "./server-status.service";

@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller("admin/server-status")
export class ServerStatusController {
  constructor(private svc: ServerStatusService) {}

  @Post("run")
  @RequirePermissions("SERVER_STATUS_RUN")
  run(@CurrentUser() u: any, @Body() dto: RunServerCheckDto) {
    return this.svc.run(u.accountId, u.id, dto);
  }

  @Get("history")
  @RequirePermissions("SERVER_STATUS_READ")
  history(
    @CurrentUser() u: any,
    @Query("channelId") channelId?: string,
    @Query("deliveryProfileId") deliveryProfileId?: string,
    @Query("limit") limit?: string,
  ) {
    return this.svc.history(u.accountId, {
      channelId,
      deliveryProfileId,
      limit: limit ? Number(limit) : undefined,
    });
  }
}
