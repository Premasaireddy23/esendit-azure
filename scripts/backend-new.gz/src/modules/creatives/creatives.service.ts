import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  Injectable,
  NotFoundException,
} from "@nestjs/common";
import { CreativeAssetType, CreativeAssetUploadStatus, CreativeQcStatus, MediaJobType, Prisma } from "@prisma/client";
import { MediaJobsService } from "./media/media-jobs.service";
import { MediaToolsService } from "./media/media-tools.service";
import { PrismaService } from "../../common/prisma/prisma.service";
import { AzureBlobService } from "../../common/storage/azure-blob.service";
import { Inject } from "@nestjs/common";
import { STORAGE } from "../../common/storage/storage.token";
import type { StorageService } from "../../common/storage/storage.types";
import type { AuthUser } from "../../common/auth/current-user.decorator";
import { getValidConfig, getValidLabel } from "./valid/valid-config";
import { generateValidFromFilename, generateValidFromSpec } from "./valid/valid-generator";
import { CreateCreativeDto } from "./dto/create-creative.dto";
import { UpdateCreativeDto } from "./dto/update-creative.dto";
import { BulkImportCreativesDto } from "./dto/bulk-import-creatives.dto";
import { ProjectAccessService } from "../../common/project-access/project-access.service";

import * as fs from "fs";
import * as fsp from "fs/promises";
import * as path from "path";

function normalizeLangs(raw?: string[] | null): string[] {
  const arr = Array.isArray(raw) ? raw : [];
  return arr
    .map((x) => String(x || "").trim())
    .filter(Boolean)
    .map((x) => x.toUpperCase());
}

function looksLikeLocalPath(p: string): boolean {
  if (!p) return false;
  return p.startsWith("/") || /^[A-Za-z]:\\/.test(p);
}

function safeBlobSegment(name: string): string {
  const base = path.basename(String(name || ""));
  return base.replace(/[\r\n\t]/g, " ").replace(/[^a-zA-Z0-9._ -]+/g, "_").trim() || "file";
}

@Injectable()
export class CreativesService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly mediaJobs: MediaJobsService,
    private readonly mediaTools: MediaToolsService,
    private readonly blobs: AzureBlobService,
    @Inject(STORAGE) private readonly storage: StorageService,
    private readonly projectAccess: ProjectAccessService,
  ) {}

  private async assertCanReadCreative(user: AuthUser, creativeId: string) {
    const projectId = await this.projectAccess.projectIdForCreative(user.accountId, creativeId);
    const canView = await this.projectAccess.canViewCreativeInProject(user, projectId, creativeId);
    if (!canView) throw new ForbiddenException("Unauthorised");
    return projectId;
  }

  private async assertCanUploadCreative(user: AuthUser, projectId: string) {
    if (this.projectAccess.hasAnyPerm(user, ["PROJECT_UPDATE", "action:projects:update"])) return;
    await this.projectAccess.assertCanUploadCreatives(user, projectId);
  }

  private async resetQcAndQueueMediaJobs(accountId: string, projectId: string, creativeId: string, now: Date) {
    // Any fresh SOURCE upload/replacement must always restart QC + proxy generation.
    // This avoids stale/stuck prior jobs leaving the creative without a new QC run.
    await this.prisma.creative.update({
      where: { id: creativeId },
      data: {
        qcStatus: CreativeQcStatus.IN_PROGRESS,
        autoQcStartedAt: now,
        autoQcEndedAt: null,
        qcNotes: null,
        qcFailureReasons: [],
        qcReport: null,
      } as any,
    });

    await this.mediaJobs.enqueue(accountId, projectId, creativeId, MediaJobType.AUTO_QC, true);
    await this.mediaJobs.enqueue(accountId, projectId, creativeId, MediaJobType.PROXY_GEN, true);
  }

  async getMeta(accountId: string, countryId?: string | null) {
    const account = await this.prisma.account.findFirst({
      where: { id: accountId },
      select: { id: true, uiConfig: true },
    });
    if (!account) throw new BadRequestException("Invalid account");

    const label = getValidLabel(account.uiConfig, countryId || null);
    const cfg = getValidConfig(account.uiConfig, countryId || null);

    return {
      label,
      strategy: cfg.strategy || "FILENAME_DRIVEN",
      defaults: {
        stereoRequired: cfg.stereoRequired ?? null,
        defaultLanguages: cfg.defaultLanguages ?? [],
      },
      raw: cfg,
    };
  }

  async listByProject(user: AuthUser, projectId: string) {
    const accountId = user.accountId;
    await this.projectAccess.assertCanViewProject(user, projectId);
    const project = await this.prisma.project.findFirst({
      where: { id: projectId, accountId },
      select: { id: true },
    });
    if (!project) throw new NotFoundException("Project not found");

    const visibleCreativeIds = await this.projectAccess.visibleCreativeIdsForProject(user, projectId);
    if (visibleCreativeIds && visibleCreativeIds.size === 0) return [];

    return this.prisma.creative.findMany({
      where: {
        accountId,
        projectId,
        ...(visibleCreativeIds ? { id: { in: Array.from(visibleCreativeIds) } } : {}),
      },
      orderBy: { createdAt: "asc" },
      select: {
        id: true,
        projectId: true,
        accountId: true,
        valid: true,
        caption: true,
        format: true,
        languages: true,
        duration: true,
        remarks: true,
        countryId: true,
        qcStatus: true,
        qcNotes: true,
        qcFailureReasons: true,
        qcReport: true,
        primaryDamItemId: true,
        uniqueEditKey: true,
        assets: {
          select: {
            id: true,
            type: true,
            filename: true,
            mimeType: true,
            sizeBytes: true,
            uploadStatus: true,
            bytesTotal: true,
            bytesReceived: true,
            speedBps: true,
            uploadStartedAt: true,
            uploadEndedAt: true,
            error: true,
          },
        },
        createdAt: true,
        updatedAt: true,
      },
    });
  }

  private async getAccountUiConfig(accountId: string) {
    const a = await this.prisma.account.findFirst({ where: { id: accountId }, select: { uiConfig: true } });
    return a?.uiConfig || {};
  }

  private async resolveDefaults(accountId: string, countryId?: string | null) {
    const uiConfig = await this.getAccountUiConfig(accountId);
    const cfg = getValidConfig(uiConfig, countryId || null);
    return { uiConfig, cfg };
  }

  private async maybeGenerateValid(params: {
    accountId: string;
    projectId: string;
    creativeId: string;
    countryId?: string | null;
    filename?: string | null;
  }) {
    const { uiConfig, cfg } = await this.resolveDefaults(params.accountId, params.countryId || null);
    const strategy = cfg.strategy || "FILENAME_DRIVEN";

    const creative = await this.prisma.creative.findFirst({
      where: { id: params.creativeId, accountId: params.accountId, projectId: params.projectId },
      select: {
        id: true,
        valid: true,
        caption: true,
        format: true,
        languages: true,
        duration: true,
        project: {
          select: {
            advertiserGroup: { select: { name: true } },
            advertiser: { select: { name: true } },
            brand: { select: { name: true } },
          },
        },
      },
    });
    if (!creative) throw new NotFoundException("Creative not found");

    if (creative.valid && String(creative.valid).trim()) return creative.valid;

    let valid: string;
    if (strategy === "SPEC_DRIVEN") {
      valid = generateValidFromSpec({
        advertiserGroup: creative.project.advertiserGroup?.name || null,
        advertiser: creative.project.advertiser?.name || null,
        brand: creative.project.brand?.name || null,
        caption: creative.caption || null,
        format: creative.format || null,
        languages: creative.languages || [],
        duration: creative.duration || null,
        cfg,
      });
    } else {
      valid = generateValidFromFilename(params.filename || "", cfg);
    }

    valid = (valid || "").trim();
    if (!valid) return null;

    // Uniqueness per project (allow many nulls)
    const exists = await this.prisma.creative.findFirst({
      where: { accountId: params.accountId, projectId: params.projectId, valid },
      select: { id: true },
    });
    if (exists) throw new ConflictException("VALID already exists in this project");

    await this.prisma.creative.update({
      where: { id: creative.id },
      data: { valid },
      select: { id: true },
    });

    return valid;
  }

  async createLine(user: AuthUser, projectId: string, dto: CreateCreativeDto) {
    const accountId = user.accountId;

    const project = await this.prisma.project.findFirst({
      where: { id: projectId, accountId },
      select: { id: true, accountId: true },
    });
    if (!project) throw new NotFoundException("Project not found");

    // IMPORTANT:
    // Use scalar FK fields here instead of nested relation connects.
    // Prisma's XOR(CreateInput, UncheckedCreateInput) will treat presence of
    // relation fields (account/project) as CreateInput, which does NOT allow
    // setting foreign-key scalar fields like countryId/primaryDamItemId.
    // That results in a runtime PrismaClientValidationError and a 500.
    let data: Prisma.CreativeUncheckedCreateInput = {
      accountId,
      projectId,
      name: "creative",
      title: null,
      valid: dto.valid ? String(dto.valid).trim() : null,
      caption: dto.caption ? String(dto.caption).trim() : null,
      format: dto.format ? String(dto.format).trim() : null,
      languages: normalizeLangs(dto.languages),
      duration: dto.duration ? String(dto.duration).trim() : null,
      remarks: dto.remarks ? String(dto.remarks).trim() : null,
      countryId: dto.countryId || null,
      primaryDamItemId: dto.primaryDamItemId || null,
      uniqueEditKey: dto.uniqueEditKey || null,
    } as any;

    if (dto.copyFromCreativeId) {
      const src = await this.prisma.creative.findFirst({
        where: { id: dto.copyFromCreativeId, accountId, projectId },
        select: {
          caption: true,
          format: true,
          languages: true,
          duration: true,
          remarks: true,
          countryId: true,
          primaryDamItemId: true,
          uniqueEditKey: true,
        },
      });
      if (src) {
        data = {
          ...data,
          caption: data.caption ?? src.caption,
          format: data.format ?? src.format,
          languages: (data.languages as any)?.length ? data.languages : src.languages,
          duration: data.duration ?? src.duration,
          remarks: data.remarks ?? src.remarks,
          countryId: (data as any).countryId ?? src.countryId,
          primaryDamItemId: (data as any).primaryDamItemId ?? src.primaryDamItemId,
          uniqueEditKey: (data as any).uniqueEditKey ?? src.uniqueEditKey,
        } as any;
      }
    }

    // Apply default languages if none provided
    const { cfg } = await this.resolveDefaults(accountId, (data as any).countryId);
    if (!(data as any).languages || (data as any).languages.length === 0) {
      (data as any).languages = normalizeLangs(cfg.defaultLanguages || []);
    }

    const created = await this.prisma.creative.create({
      data,
      select: { id: true, projectId: true, accountId: true },
    });

    return this.prisma.creative.findFirst({
      where: { id: created.id },
      select: {
        id: true,
        valid: true,
        caption: true,
        format: true,
        languages: true,
        duration: true,
        remarks: true,
        countryId: true,
        qcStatus: true,
        qcNotes: true,
        qcReport: true,
        assets: { select: { id: true, type: true, filename: true, uploadStatus: true } },
      },
    });
  }

  async updateLine(user: AuthUser, creativeId: string, dto: UpdateCreativeDto) {
    const accountId = user.accountId;
    const existing = await this.prisma.creative.findFirst({
      where: { id: creativeId, accountId },
      select: { id: true, projectId: true, countryId: true, uniqueEditKey: true },
    });
    if (!existing) throw new NotFoundException("Creative not found");

    // If switching uniqueEditKey manually, keep it consistent.
    if (dto.uniqueEditKey !== undefined && dto.uniqueEditKey && existing.uniqueEditKey && dto.uniqueEditKey !== existing.uniqueEditKey) {
      throw new BadRequestException("This line is already linked to a different unique edit.");
    }

    const data: Prisma.CreativeUpdateInput = {
      valid: dto.valid === undefined ? undefined : (dto.valid ? String(dto.valid).trim() : null),
      caption: dto.caption === undefined ? undefined : (dto.caption ? String(dto.caption).trim() : null),
      format: dto.format === undefined ? undefined : (dto.format ? String(dto.format).trim() : null),
      languages: dto.languages === undefined ? undefined : normalizeLangs(dto.languages),
      duration: dto.duration === undefined ? undefined : (dto.duration ? String(dto.duration).trim() : null),
      remarks: dto.remarks === undefined ? undefined : (dto.remarks ? String(dto.remarks).trim() : null),
      countryId: dto.countryId === undefined ? undefined : (dto.countryId || null),
      primaryDamItemId: dto.primaryDamItemId === undefined ? undefined : (dto.primaryDamItemId || null),
      uniqueEditKey: dto.uniqueEditKey === undefined ? undefined : (dto.uniqueEditKey || null),
    } as any;

    await this.prisma.creative.update({ where: { id: creativeId }, data, select: { id: true } });

    return this.prisma.creative.findFirst({
      where: { id: creativeId, accountId },
      select: {
        id: true,
        valid: true,
        caption: true,
        format: true,
        languages: true,
        duration: true,
        remarks: true,
        countryId: true,
        qcStatus: true,
        qcNotes: true,
        qcFailureReasons: true,
        qcReport: true,
        primaryDamItemId: true,
        uniqueEditKey: true,
        assets: {
          select: {
            id: true,
            type: true,
            filename: true,
            uploadStatus: true,
            bytesTotal: true,
            bytesReceived: true,
            speedBps: true,
            uploadStartedAt: true,
            uploadEndedAt: true,
          },
        },
      },
    });
  }

  async deleteLine(user: AuthUser, creativeId: string) {
    const accountId = user.accountId;
    const c = await this.prisma.creative.findFirst({
      where: { id: creativeId, accountId },
      select: { id: true, projectId: true },
    });
    if (!c) throw new NotFoundException("Creative not found");

    const approvalReq = await this.prisma.approvalRequest.findFirst({ where: { accountId, creativeId: c.id }, select: { id: true } });
    if (approvalReq) throw new ConflictException("Cannot delete: approval request exists");

    const planLines = await this.prisma.planLine.findMany({
      where: { accountId, creativeId: c.id },
      select: { id: true },
    });
    const planLineIds = planLines.map((x) => x.id);

    if (planLineIds.length) {
      const deliveryTaskCount = await this.prisma.deliveryTask.count({
        where: { accountId, planLineId: { in: planLineIds } },
      });
      if (deliveryTaskCount > 0) {
        throw new ConflictException("Cannot delete: creative already has delivery tasks");
      }
    }

    // Hard delete from Blob Storage (Phase-1: browser -> blob uploads)
    // We delete the whole creative prefix to remove source/proxy/qc-artifacts, etc.
    // If this fails, we DO NOT delete the DB rows.
    const blobPrefix = `creatives/${accountId}/${c.projectId}/${c.id}/`;
    if (this.blobs.isConfigured()) {
      await this.blobs.deletePrefix(blobPrefix);

      // If QC artifacts are stored in a separate container, delete them too.
      const defaultContainer = process.env.AZURE_STORAGE_CONTAINER || "";
      const qcContainer = process.env.QC_OUTPUT_CONTAINER || process.env.QC_ARTIFACTS_CONTAINER || "";
      if (qcContainer && qcContainer !== defaultContainer) {
        const qcPrefix = `${qcContainer}::creatives/${accountId}/${c.projectId}/${c.id}/qc/`;
        await this.blobs.deletePrefix(qcPrefix);
      }
    }

    // Best-effort delete files from disk (DB is source of truth).
    const dir = path.join(process.cwd(), "uploads", "creatives", accountId, c.projectId, c.id);
    try {
      if (fs.existsSync(dir)) fs.rmSync(dir, { recursive: true, force: true });
    } catch {
      // ignore filesystem errors
    }

    await this.prisma.$transaction(async (tx) => {
      await tx.mediaJob.deleteMany({ where: { accountId, creativeId: c.id } });
      await tx.creativeAsset.deleteMany({ where: { accountId, creativeId: c.id } });
      await tx.planLine.deleteMany({ where: { accountId, creativeId: c.id } });
      await tx.creative.delete({ where: { id: c.id } });
    });
    return { ok: true };
  }

  async bulkImport(user: AuthUser, projectId: string, dto: BulkImportCreativesDto) {
    const accountId = user.accountId;
    const project = await this.prisma.project.findFirst({ where: { id: projectId, accountId }, select: { id: true } });
    if (!project) throw new NotFoundException("Project not found");

    const rows = Array.isArray(dto.rows) ? dto.rows : [];
    const results: any[] = [];

    for (const r of rows) {
      const langs = String(r.languages || "")
        .split(/[,;\n\t ]+/)
        .map((x) => x.trim())
        .filter(Boolean);

      if (r.id) {
        const updated = await this.prisma.creative.updateMany({
          where: { id: r.id, accountId, projectId },
          data: {
            valid: r.valid ? String(r.valid).trim() : undefined,
            caption: r.caption ? String(r.caption).trim() : undefined,
            format: r.format ? String(r.format).trim() : undefined,
            languages: langs.length ? normalizeLangs(langs) : undefined,
            duration: r.duration ? String(r.duration).trim() : undefined,
            remarks: r.remarks ? String(r.remarks).trim() : undefined,
            countryId: r.countryId || undefined,
          } as any,
        });
        results.push({ id: r.id, updated: updated.count });
      } else {
        const created = await this.prisma.creative.create({
          data: {
            accountId,
            projectId,
            name: "creative",
            title: null,
            valid: r.valid ? String(r.valid).trim() : null,
            caption: r.caption ? String(r.caption).trim() : null,
            format: r.format ? String(r.format).trim() : null,
            languages: normalizeLangs(langs),
            duration: r.duration ? String(r.duration).trim() : null,
            remarks: r.remarks ? String(r.remarks).trim() : null,
            countryId: r.countryId || null,
          } as any,
          select: { id: true },
        });
        results.push({ id: created.id, created: true });
      }
    }

    return { ok: true, results };
  }

    async initUploadSource(user: AuthUser, creativeId: string, dto: any) {
    const accountId = user.accountId;

    const creative = await this.prisma.creative.findFirst({
      where: { id: creativeId, accountId },
      select: { id: true, projectId: true, countryId: true },
    });
    if (!creative) throw new NotFoundException("Creative not found");
    await this.assertCanUploadCreative(user, creative.projectId);

    const filename = safeBlobSegment(dto?.filename || dto?.name || "source");
    const contentType = String(dto?.contentType || dto?.mimeType || "application/octet-stream");
    const size = dto?.sizeBytes ?? dto?.size ?? null;

    const blobKey = `creatives/${accountId}/${creative.projectId}/${creativeId}/source/${Date.now()}_${filename}`;

    const now = new Date();

    const existing = await this.prisma.creativeAsset.findFirst({
      where: { accountId, creativeId, type: CreativeAssetType.SOURCE },
      select: { id: true },
    });

    const bytesTotal = size != null ? BigInt(size) : null;

    const asset = existing
      ? await this.prisma.creativeAsset.update({
          where: { id: existing.id },
          data: {
            filename,
            mimeType: contentType,
            path: blobKey,
            uploadStatus: CreativeAssetUploadStatus.UPLOADING,
            bytesTotal: bytesTotal as any,
            bytesReceived: BigInt(0) as any,
            uploadStartedAt: now,
            uploadEndedAt: null,
            error: null,
          } as any,
        })
      : await this.prisma.creativeAsset.create({
          data: {
            accountId,
            creativeId,
            type: CreativeAssetType.SOURCE,
            filename,
            mimeType: contentType,
            path: blobKey,
            uploadStatus: CreativeAssetUploadStatus.UPLOADING,
            bytesTotal: bytesTotal as any,
            bytesReceived: BigInt(0) as any,
            uploadStartedAt: now,
          } as any,
        });

    const sas = await this.blobs.createWriteSasUrl(blobKey, contentType, 15);

    return {
      blobKey,
      sasUrl: sas.url,
      requiredHeaders: sas.headers,
      expiresInMinutes: 15,
      asset,
    };
  }

  async completeUploadSource(user: AuthUser, creativeId: string, dto: any) {
    const accountId = user.accountId;

    const creative = await this.prisma.creative.findFirst({
      where: { id: creativeId, accountId },
      select: { id: true, projectId: true, countryId: true, qcStatus: true },
    });
    if (!creative) throw new NotFoundException("Creative not found");
    await this.assertCanUploadCreative(user, creative.projectId);

    const src = await this.prisma.creativeAsset.findFirst({
      where: { accountId, creativeId, type: CreativeAssetType.SOURCE },
      select: { id: true, path: true, filename: true, mimeType: true, bytesTotal: true },
    });
    if (!src?.id) throw new NotFoundException("Source asset not initialized");

    const blobKey = String(dto?.blobKey || src.path || "");
    if (!blobKey) throw new BadRequestException("Missing blobKey");

    const size = await this.blobs.getSize(blobKey);
    if (size == null) throw new NotFoundException("Uploaded blob not found");

    const now = new Date();
    const sizeB = BigInt(size);

    const asset = await this.prisma.creativeAsset.update({
      where: { id: src.id },
      data: {
        path: blobKey,
        uploadStatus: CreativeAssetUploadStatus.UPLOADED,
        sizeBytes: sizeB as any,
        bytesTotal: (src.bytesTotal ?? sizeB) as any,
        bytesReceived: sizeB as any,
        uploadEndedAt: now,
        error: null,
      } as any,
    });

    await this.resetQcAndQueueMediaJobs(accountId, creative.projectId, creative.id, now);

    await this.maybeGenerateValid({
      accountId,
      projectId: creative.projectId,
      creativeId: creative.id,
      countryId: (creative as any).countryId,
      filename: asset.filename || "source",
    });

    return { ok: true, asset };
  }

async uploadSourceAsset(user: AuthUser, creativeId: string, file: Express.Multer.File) {
    const accountId = user.accountId;

    const creative = await this.prisma.creative.findFirst({
      where: { id: creativeId, accountId },
      select: { id: true, projectId: true, countryId: true, qcStatus: true },
    });
    if (!creative) throw new NotFoundException("Creative not found");
    await this.assertCanUploadCreative(user, creative.projectId);

    if (!file || !file.originalname) throw new BadRequestException("Missing file");

    // Ensure directory
    const dir = path.join(process.cwd(), "uploads", "creatives", accountId, creative.projectId, creative.id);
    fs.mkdirSync(dir, { recursive: true });

    const dest = path.join(dir, file.originalname);
    fs.writeFileSync(dest, file.buffer);

    const now = new Date();
    const size = BigInt(file.size || file.buffer.length);

    // Upsert SOURCE asset record (schema doesn't guarantee unique(type) per creative, so do it manually)
    const existingAsset = await this.prisma.creativeAsset.findFirst({
      where: { accountId, creativeId: creative.id, type: CreativeAssetType.SOURCE },
      select: { id: true },
    });

    const asset = existingAsset
      ? await this.prisma.creativeAsset.update({
          where: { id: existingAsset.id },
          data: {
            filename: file.originalname,
            mimeType: file.mimetype,
            sizeBytes: size,
            bytesTotal: size,
            bytesReceived: size,
            uploadStatus: CreativeAssetUploadStatus.UPLOADED,
            uploadEndedAt: now,
            uploadStartedAt: now,
            path: dest,
            uploadedByUserId: user.id,
          } as any,
          select: { id: true, type: true, filename: true, path: true },
        })
      : await this.prisma.creativeAsset.create({
          data: {
            accountId,
            creativeId: creative.id,
            type: CreativeAssetType.SOURCE,
            filename: file.originalname,
            mimeType: file.mimetype,
            sizeBytes: size,
            bytesTotal: size,
            bytesReceived: size,
            uploadStatus: CreativeAssetUploadStatus.UPLOADED,
            uploadEndedAt: now,
            uploadStartedAt: now,
            path: dest,
            uploadedByUserId: user.id,
          } as any,
          select: { id: true, type: true, filename: true, path: true },
        });

    await this.resetQcAndQueueMediaJobs(accountId, creative.projectId, creative.id, now);

    // VALID generation if missing
    await this.maybeGenerateValid({
      accountId,
      projectId: creative.projectId,
      creativeId: creative.id,
      countryId: creative.countryId,
      filename: file.originalname,
    });

    return {
      ok: true,
      asset,
    };
  }

  async downloadProxy(user: AuthUser, creativeId: string) {
    await this.assertCanReadCreative(user, creativeId);
    const accountId = user.accountId;
    const asset = await this.prisma.creativeAsset.findFirst({
      where: { creativeId, accountId, type: CreativeAssetType.PROXY },
      select: { id: true, filename: true, path: true, mimeType: true },
    });
    if (!asset) throw new NotFoundException("Proxy not found");
        if (asset.path && !looksLikeLocalPath(asset.path)) {
      const fname = asset.filename || "proxy.mp4";
      const disposition = `attachment; filename=\"${fname}\"`;
      const redirectUrl = await this.blobs.createReadSasUrl(asset.path, asset.mimeType || undefined, disposition, 30);
      return { ...asset, redirectUrl } as any;
    }
    return asset;
  }

  async applyDamToLine(user: AuthUser, creativeId: string, damItemId: string) {
    const accountId = user.accountId;

    const creative = await this.prisma.creative.findFirst({
      where: { id: creativeId, accountId },
      select: {
        id: true,
        projectId: true,
        valid: true,
        caption: true,
        format: true,
        languages: true,
        duration: true,
        remarks: true,
        uniqueEditKey: true,
        primaryDamItemId: true,
      },
    });
    if (!creative) throw new NotFoundException("Creative not found");

    const dam = await this.prisma.damItem.findFirst({
      where: { id: damItemId, accountId },
      select: {
        id: true,
        uniqueEditKey: true,
        valid: true,
        caption: true,
        format: true,
        languages: true,
        duration: true,
        remarks: true,
        assets: { select: { type: true, path: true, filename: true, mimeType: true, sizeBytes: true, bytesTotal: true, bytesReceived: true } },
      },
    });
    if (!dam) throw new NotFoundException("DAM item not found");

    if (creative.uniqueEditKey && creative.uniqueEditKey !== dam.uniqueEditKey) {
      throw new BadRequestException("This line is already linked to a different unique edit.");
    }

    // Ensure unique edit not already used by another line in this project
    const already = await this.prisma.creative.findFirst({
      where: {
        accountId,
        projectId: creative.projectId,
        uniqueEditKey: dam.uniqueEditKey,
        NOT: { id: creative.id },
      },
      select: { id: true },
    });
    if (already) throw new ConflictException("This DAM unique edit is already used in this project");

    // Fill only blank fields (unique edit rules)
    const data: Prisma.CreativeUpdateInput = {
      primaryDamItemId: dam.id as any,
      uniqueEditKey: dam.uniqueEditKey,
      valid: creative.valid ? undefined : (dam.valid || null),
      caption: creative.caption ? undefined : (dam.caption || null),
      format: creative.format ? undefined : (dam.format || null),
      languages: (creative.languages && creative.languages.length) ? undefined : (dam.languages || []),
      duration: creative.duration ? undefined : (dam.duration || null),
      remarks: creative.remarks ? undefined : (dam.remarks || null),
    } as any;

    await this.prisma.creative.update({ where: { id: creative.id }, data, select: { id: true } });

    // If creative has no SOURCE/PROXY, link DAM assets (paths reused)
    const existingAssets = await this.prisma.creativeAsset.findMany({
      where: { accountId, creativeId: creative.id },
      select: { type: true },
    });
    const hasSource = existingAssets.some((a) => a.type === CreativeAssetType.SOURCE);
    const hasProxy = existingAssets.some((a) => a.type === CreativeAssetType.PROXY);

    const damSource = dam.assets.find((a) => a.type === CreativeAssetType.SOURCE);
    const damProxy = dam.assets.find((a) => a.type === CreativeAssetType.PROXY);

    const toCreate: Prisma.CreativeAssetCreateManyInput[] = [];
    const now = new Date();

    if (!hasSource && damSource) {
      toCreate.push({
        accountId,
        creativeId: creative.id,
        type: CreativeAssetType.SOURCE,
        path: damSource.path,
        filename: damSource.filename,
        mimeType: damSource.mimeType,
        sizeBytes: damSource.sizeBytes as any,
        bytesTotal: damSource.bytesTotal as any,
        bytesReceived: damSource.bytesReceived as any,
        uploadStatus: CreativeAssetUploadStatus.UPLOADED,
        uploadStartedAt: now,
        uploadEndedAt: now,
        uploadedByUserId: user.id,
      } as any);
    }

    if (!hasProxy && damProxy) {
      toCreate.push({
        accountId,
        creativeId: creative.id,
        type: CreativeAssetType.PROXY,
        path: damProxy.path,
        filename: damProxy.filename,
        mimeType: damProxy.mimeType,
        sizeBytes: damProxy.sizeBytes as any,
        bytesTotal: damProxy.bytesTotal as any,
        bytesReceived: damProxy.bytesReceived as any,
        uploadStatus: CreativeAssetUploadStatus.UPLOADED,
        uploadStartedAt: now,
        uploadEndedAt: now,
        uploadedByUserId: user.id,
      } as any);
    }

    if (toCreate.length) {
      await this.prisma.creativeAsset.createMany({ data: toCreate, skipDuplicates: true });
    }

    return this.prisma.creative.findFirst({
      where: { id: creative.id, accountId },
      select: {
        id: true,
        valid: true,
        caption: true,
        format: true,
        languages: true,
        duration: true,
        remarks: true,
        qcStatus: true,
        primaryDamItemId: true,
        uniqueEditKey: true,
        assets: { select: { id: true, type: true, filename: true, uploadStatus: true } },
      },
    });
  }

  // ------------------------------
  // Expand-only helpers for QC UI
  // ------------------------------

  private workDir(meta: { accountId: string; projectId: string; id: string }) {
    const root = process.env.TMPDIR || "/tmp";
    return path.join(root, "esendit", "creatives", meta.accountId, meta.projectId, meta.id);
  }

  private async ensureLocalSource(meta: { accountId: string; projectId: string; id: string }, sourcePathOrBlobKey: string) {
    if (looksLikeLocalPath(sourcePathOrBlobKey)) return { localPath: sourcePathOrBlobKey, isBlob: false };

    const wd = this.workDir(meta);
    const fileName = path.basename(sourcePathOrBlobKey);
    const localPath = path.join(wd, "source", fileName);
    await this.blobs.downloadToFile(sourcePathOrBlobKey, localPath);
    return { localPath, isBlob: true, blobKey: sourcePathOrBlobKey, workDir: wd };
  }

  private async uploadDirToBlob(localDir: string, blobPrefix: string) {
    const walk = async (dir: string) => {
      const items = await fsp.readdir(dir, { withFileTypes: true }).catch(() => [] as any[]);
      for (const it of items as any[]) {
        const full = path.join(dir, it.name);
        if (it.isDirectory()) await walk(full);
        else if (it.isFile()) {
          const rel = path.relative(localDir, full).replace(/\\/g, "/");
          const key = `${blobPrefix}${rel}`;
          await this.blobs.uploadFile(key, full);
        }
      }
    };
    await walk(localDir);
  }

  private getArtifactPath(artifacts: any, keys: string[]): string | null {
    for (const key of keys) {
      const value = artifacts?.[key];
      if (typeof value === "string" && value) return value;
      const candidate = value?.path ?? value?.name ?? value?.blobKey ?? value?.blobPath ?? value?.file ?? value?.key;
      if (typeof candidate === "string" && candidate) return candidate;
    }
    return null;
  }

  private setArtifact(artifacts: Record<string, any>, key: string, type: string, relPath: string) {
    artifacts[key] = { type, path: relPath };
  }

  async generateQcVisuals(user: AuthUser, creativeId: string) {
    const accountId = user.accountId;
    const creative = await this.prisma.creative.findFirst({
      where: { id: creativeId, accountId },
      select: {
        id: true,
        accountId: true,
        projectId: true,
        qcReport: true,
      },
    });
    if (!creative) throw new NotFoundException("Creative not found");

    const source = await this.prisma.creativeAsset.findFirst({
      where: { accountId, creativeId, type: CreativeAssetType.SOURCE },
      select: { path: true, filename: true },
    });
    if (!source?.path) throw new BadRequestException("Upload SOURCE first");

    const local = await this.ensureLocalSource(creative, source.path);
    const qcDir = local.isBlob ? path.join(this.workDir(creative), "qc") : path.join(path.dirname(local.localPath), "qc");
    await fsp.mkdir(qcDir, { recursive: true });

    const prevReport: any = creative.qcReport && typeof creative.qcReport === "object" ? creative.qcReport : {};
    const prevQcTools: any = prevReport.qcTools && typeof prevReport.qcTools === "object" ? prevReport.qcTools : {};
    const artifacts: Record<string, any> = prevQcTools.artifacts && typeof prevQcTools.artifacts === "object" ? { ...prevQcTools.artifacts } : {};

    const qctoolsPath = this.getArtifactPath(artifacts, ["qctoolsMkv", "qctools.mkv", "qctools_mkv"]);
    if (qctoolsPath) {
      const qctoolsLocalPath = path.join(qcDir, path.basename(qctoolsPath));
      const isAlreadyLocal = fs.existsSync(qctoolsLocalPath);
      if (!isAlreadyLocal) {
        if (local.isBlob) {
          const qcContainer = process.env.QC_OUTPUT_CONTAINER || process.env.QC_ARTIFACTS_CONTAINER || "";
          const qcBasePrefix = `creatives/${accountId}/${creative.projectId}/${creativeId}/qc/`;
          const blobKey = qcContainer ? `${qcContainer}::${qcBasePrefix}${path.basename(qctoolsPath)}` : `${qcBasePrefix}${path.basename(qctoolsPath)}`;
          await this.blobs.downloadToFile(blobKey, qctoolsLocalPath).catch(() => undefined);
        } else if (fs.existsSync(path.join(path.dirname(local.localPath), "qc", path.basename(qctoolsPath)))) {
          await fsp.copyFile(path.join(path.dirname(local.localPath), "qc", path.basename(qctoolsPath)), qctoolsLocalPath).catch(() => undefined);
        }
      }
      if (fs.existsSync(qctoolsLocalPath) && !this.getArtifactPath(artifacts, ["qctoolsPreview", "qctools_preview", "qctools_preview.jpg"])) {
        try {
          await this.mediaTools.extractStillImage(qctoolsLocalPath, path.join(qcDir, "qctools_preview.jpg"), 1);
          this.setArtifact(artifacts, "qctoolsPreview", "image/jpeg", "qctools_preview.jpg");
        } catch {
          // preview is optional
        }
      }
    }

    const generated = await this.mediaTools.generateQcToolsReport(local.localPath, qcDir, { force: true });
    const mergedArtifacts = { ...artifacts, ...(generated?.artifacts || {}) };
    if (!this.getArtifactPath(mergedArtifacts, ["qctoolsPreview", "qctools_preview", "qctools_preview.jpg"])) {
      try {
        await this.mediaTools.extractStillImage(local.localPath, path.join(qcDir, "qctools_preview.jpg"), 1);
        this.setArtifact(mergedArtifacts, "qctoolsPreview", "image/jpeg", "qctools_preview.jpg");
      } catch {
        // preview is optional
      }
    }

    const nextQcTools = {
      ...prevQcTools,
      enabled: true,
      skipped: false,
      generatedAt: new Date().toISOString(),
      primaryProbeTool: prevQcTools.primaryProbeTool || prevReport.probeTool || "qcli+mediainfo",
      artifacts: mergedArtifacts,
      measures: {
        ...(prevQcTools.measures || {}),
        ...(generated?.measures || {}),
      },
      visualsGeneratedAt: new Date().toISOString(),
    };

    try {
      await fsp.writeFile(path.join(qcDir, "qc_tools.json"), JSON.stringify(nextQcTools, null, 2), { encoding: "utf8" });
      this.setArtifact(mergedArtifacts, "qcToolsJson", "application/json", "qc_tools.json");
    } catch {
      // ignore write failures
    }

    if (local.isBlob) {
      const qcContainer = process.env.QC_OUTPUT_CONTAINER || process.env.QC_ARTIFACTS_CONTAINER || "";
      const qcBasePrefix = `creatives/${accountId}/${creative.projectId}/${creativeId}/qc/`;
      const qcPrefix = qcContainer ? `${qcContainer}::${qcBasePrefix}` : qcBasePrefix;
      await this.uploadDirToBlob(qcDir, qcPrefix).catch(() => undefined);
    }

    const mergedReport = {
      ...prevReport,
      qcTools: nextQcTools,
    };

    await this.prisma.creative.update({
      where: { id: creativeId },
      data: { qcReport: mergedReport } as any,
    });

    return { ok: true, creativeId, qcReport: mergedReport };
  }

  async removeSourceAsset(user: AuthUser, creativeId: string) {
    const accountId = user.accountId;
    const creative = await this.prisma.creative.findFirst({
      where: { id: creativeId, accountId },
      select: { id: true, projectId: true },
    });
    if (!creative) throw new NotFoundException("Creative not found");
    await this.assertCanUploadCreative(user, creative.projectId);

    const src = await this.prisma.creativeAsset.findFirst({
      where: { accountId, creativeId, type: CreativeAssetType.SOURCE },
      select: { id: true, path: true },
    });

    if (src?.path) {
      try {
        if (looksLikeLocalPath(src.path)) {
          if (fs.existsSync(src.path)) fs.unlinkSync(src.path);
        } else {
          await this.blobs.delete(src.path);
        }
      } catch {
        // ignore (DB remains source of truth)
      }
    }

    if (src?.id) {
      await this.prisma.creativeAsset.delete({ where: { id: src.id } }).catch(() => undefined);
    }

    // do NOT reset QC status automatically here to avoid unintended workflow changes
    return { ok: true };
  }

  async startAutoQc(user: AuthUser, creativeId: string, force = false) {
    const accountId = user.accountId;
    const creative = await this.prisma.creative.findFirst({
      where: { id: creativeId, accountId },
      select: { id: true, projectId: true },
    });
    if (!creative) throw new NotFoundException("Creative not found");

    // mark in-progress (worker will set PASSED/FAILED)
    await this.prisma.creative.update({
      where: { id: creative.id },
      data: { qcStatus: CreativeQcStatus.IN_PROGRESS, autoQcStartedAt: new Date() } as any,
    });

    return this.mediaJobs.enqueue(accountId, creative.projectId, creative.id, MediaJobType.AUTO_QC, force);
  }

  async startProxy(user: AuthUser, creativeId: string, force = false) {
    const accountId = user.accountId;
    const creative = await this.prisma.creative.findFirst({
      where: { id: creativeId, accountId },
      select: { id: true, projectId: true },
    });
    if (!creative) throw new NotFoundException("Creative not found");
    return this.mediaJobs.enqueue(accountId, creative.projectId, creative.id, MediaJobType.PROXY_GEN, force);
  }

  async listJobs(user: AuthUser, creativeId: string) {
    await this.assertCanReadCreative(user, creativeId);
    // security: ensure creative is in the user's account
    const c = await this.prisma.creative.findFirst({ where: { id: creativeId, accountId: user.accountId }, select: { id: true } });
    if (!c) throw new NotFoundException("Creative not found");
    return this.mediaJobs.listForCreative(creativeId);
  }

  async getQcReport(user: AuthUser, creativeId: string) {
    const c = await this.prisma.creative.findFirst({
      where: { id: creativeId, accountId: user.accountId },
      select: {
        id: true,
        projectId: true,
        qcStatus: true,
        qcFailureReasons: true,
        qcNotes: true,
        autoQcStartedAt: true,
        autoQcEndedAt: true,
        qcReport: true,
      },
    });
    if (!c) throw new NotFoundException("Creative not found");
    const canView = await this.projectAccess.canViewCreativeInProject(user, c.projectId, creativeId);
    if (!canView) throw new ForbiddenException("Unauthorised");
    return c;
  }

  async getAssetForStream(user: AuthUser, creativeId: string, type: string) {
    await this.assertCanReadCreative(user, creativeId);
    const accountId = user.accountId;
    const c = await this.prisma.creative.findFirst({ where: { id: creativeId, accountId }, select: { id: true } });
    if (!c) throw new NotFoundException("Creative not found");

    const t = String(type || "").toUpperCase();
    const allowed = ["SOURCE", "PROXY", "OUTPUT"];
    if (!allowed.includes(t)) throw new BadRequestException("Invalid asset type");

    const asset = await this.prisma.creativeAsset.findFirst({
      where: { accountId, creativeId, type: t as any },
      select: { id: true, filename: true, path: true, mimeType: true },
    });
    if (!asset || !asset.path) throw new NotFoundException("Asset not found");
        // If blob-backed, return redirectUrl (controller will 302 to it)
    if (!looksLikeLocalPath(asset.path)) {
      const fname = asset.filename || `${t.toLowerCase()}`;
      const disposition = `inline; filename=\"${fname}\"`;
      const redirectUrl = await this.blobs.createReadSasUrl(asset.path, asset.mimeType || undefined, disposition, 30);
      return { ...asset, redirectUrl } as any;
    }

    return asset;
  }

  async getQcArtifactForStream(user: AuthUser, creativeId: string, name: string) {
    await this.assertCanReadCreative(user, creativeId);
    // Wildcard route params can differ across adapters/versions. Normalize here so
    // nested paths like "filmstrip/frame_001.jpg" always resolve correctly.
    let raw = String(name || "");
    try {
      raw = decodeURIComponent(raw);
    } catch {
      // ignore malformed escape sequences
    }
    // Some adapters may accidentally include the action suffix in the wildcard.
    raw = raw.replace(/\/(stream-url|stream)\/?$/i, "");
    name = raw;
    const accountId = user.accountId;
    const creative = await this.prisma.creative.findFirst({
      where: { id: creativeId, accountId },
      select: { id: true, projectId: true },
    });
    if (!creative) throw new NotFoundException("Creative not found");

    const src = await this.prisma.creativeAsset.findFirst({
      where: { accountId, creativeId, type: CreativeAssetType.SOURCE },
      select: { path: true },
    });

    // 1) Local fallback (old behavior)
    const qcDirLocal = src?.path && looksLikeLocalPath(src.path) ? path.join(path.dirname(src.path), "qc") : "";
    if (qcDirLocal) {
      const base = path.resolve(qcDirLocal);
      const req = String(name || "").replace(/^\/+/, "");
      if (!req || req.includes("..")) throw new BadRequestException("Invalid artifact path");

      const filePath = path.resolve(path.join(qcDirLocal, req));
      if (!filePath.startsWith(base)) throw new BadRequestException("Invalid artifact path");
      if (fs.existsSync(filePath)) {
        return { path: filePath, filename: path.basename(filePath) };
      }
    }

    // 2) Blob-backed artifacts (Phase-1)
    let req = String(name || "").replace(/^\/+/, "");
    if (!req || req.includes("..")) throw new BadRequestException("Invalid artifact path");

    // Safety: older wildcard parsing bugs could turn "filmstrip/frame_001.jpg" into "filmstrip,frame_001.jpg".
    // Normalize that specific case so we still resolve the correct blob.
    if (/^filmstrip,frame_/i.test(req)) req = req.replace(",", "/");

    const qcContainer = process.env.QC_OUTPUT_CONTAINER || process.env.QC_ARTIFACTS_CONTAINER || "";
    const containerPrefix = qcContainer ? `${qcContainer}::` : "";
    const basePrefixRaw = `creatives/${accountId}/${creative.projectId}/${creativeId}/qc/`;
    const basePrefix = `${containerPrefix}${basePrefixRaw}`;

    // IMPORTANT: avoid calling `exists()` here.
    // In some environments, the existence probe can return false even when the blob is present.
    // Generating a SAS URL is safe and the blob request itself will 404 if truly missing.
    let key = `${basePrefix}${req}`;

    // If caller points to a directory/prefix (rare but supported), return the first blob under it.
    if (req.endsWith("/")) {
      const prefix = `${basePrefix}${req}`;
      const keys = await this.blobs.listKeys(prefix);
      if (!keys.length) throw new NotFoundException("QC artifact not found");
      key = keys[0];
      if (qcContainer && !key.includes("::")) key = `${containerPrefix}${key}`;
    }

    const fname = path.basename(req.replace(/\/+$/g, "")) || "qc";
    const disposition = `inline; filename=\"${fname}\"`;
    const redirectUrl = await this.blobs.createReadSasUrl(key, undefined, disposition, 30);
    return { redirectUrl, filename: fname };
  }
}
