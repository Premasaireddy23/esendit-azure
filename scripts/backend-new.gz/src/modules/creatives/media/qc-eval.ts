
function buildClientQcMetadata(mediainfo: any, sourcePath?: string | null, loudness?: number | null) {
  const miG = miTrack(mediainfo, "General");
  const miV = miTrack(mediainfo, "Video");
  const miAudioAll = miTracks(mediainfo, "Audio");
  const audio = miAudioAll[0] || null;
  const fileName = sourcePath ? sourcePath.split(/[\/]/).pop() || sourcePath : null;
  const formatProfile = [miStr(miV, "Format_Profile"), miStr(miV, "Format_Level")].filter(Boolean).join("@");
  const formatSettings = buildVideoFormatSettings(miV);
  const bitRate = miNum(miV, "BitRate");
  const frameRate = miNum(miV, "FrameRate");
  const bitPerFrame = bitRate != null && frameRate ? bitRate / frameRate : null;
  return {
    general: {
      Path: sourcePath || miStr(miG, "CompleteName") || null,
      FileName: fileName || miStr(miG, "FileNameExtension", "FileName") || null,
      Format: miStr(miG, "Format") || null,
      Size: miNum(miG, "FileSize") || null,
      Duration: miDurationSec(miG),
      BitRate: miNum(miG, "OverallBitRate", "BitRate") || null,
      EncodedDate: miStr(miG, "Encoded_Date") || null,
    },
    video: {
      FrameRate: miNum(miV, "FrameRate") || null,
      Duration: miDurationSec(miV),
      Width: miNum(miV, "Width") || null,
      Height: miNum(miV, "Height") || null,
      BitDepth: miNum(miV, "BitDepth") || null,
      BitRate: bitRate,
      BitPerFrame: bitPerFrame,
      ScanType: miStr(miV, "ScanType") || null,
      Format: miStr(miV, "Format") || null,
      Format_Settings: formatSettings,
      DisplayAspectRatio:
        (
          normDar(miVal(
            miV,
            "DisplayAspectRatio/String",
            "DisplayAspectRatio_String",
            "DisplayAspectRatio_Original/String",
            "DisplayAspectRatio_Original_String",
            "DisplayAspectRatio",
          ))
          ?? deriveDarFromGeometry(
            miNum(miV, "Width"),
            miNum(miV, "Height"),
            miVal(miV, "PixelAspectRatio/String", "PixelAspectRatio_String", "PixelAspectRatio"),
          )
        ) || null,
      PixelAspectRatio: miStr(miV, "PixelAspectRatio/String", "PixelAspectRatio_String", "PixelAspectRatio") || null,
      BitRateMode: normalizeBitRateMode(miStr(miV, "BitRate_Mode")) || null,
      CodecId: miStr(miV, "CodecID") || null,
      Format_Profile: formatProfile || null,
      ChromaSubsampling: miStr(miV, "ChromaSubsampling") || null,
      StreamSize: miNum(miV, "StreamSize") || null,
    },
    audio: miAudioAll.map((track: any, idx: number) => ({
      index: idx,
      Loudness: idx === 0 && loudness != null ? `${Number(loudness).toFixed(1)} LUFS` : null,
      Channels: miNum(track, "Channels", "Channel(s)") || null,
      SampleRate: miNum(track, "SamplingRate") || null,
      Format: miStr(track, "Format") || null,
      CodecId: miStr(track, "CodecID") || null,
      BitRate: miNum(track, "BitRate") || null,
      BitDepth: miNum(track, "BitDepth") || null,
      Size: miNum(track, "StreamSize") || null,
    })),
    audioSummary: audio ? {
      Loudness: loudness != null ? `${Number(loudness).toFixed(1)} LUFS` : null,
      Channels: miNum(audio, "Channels", "Channel(s)") || null,
      SampleRate: miNum(audio, "SamplingRate") || null,
      Format: miStr(audio, "Format") || null,
      CodecId: miStr(audio, "CodecID") || null,
      BitRate: miNum(audio, "BitRate") || null,
      BitDepth: miNum(audio, "BitDepth") || null,
      Size: miNum(audio, "StreamSize") || null,
    } : null,
  };
}

type QcEvalResult = {
  status: "PASSED" | "FAILED";
  reasons: string[];
  report: any;
};

type QcCheckStatus = "PASS" | "FAIL" | "WARN" | "NA";

type QcCheck = {
  group: "General" | "Video" | "Audio";
  name: string;
  value: string;
  status: QcCheckStatus;
  expected?: string;
  message?: string;
};

type QcExpected = {
  // General
  durationSec?: number;
  durationToleranceSec?: number;
  durationTc?: string;
  generalFormat?: string;
  overallBitRate?: number;
  overallBitRateTolerance?: number;
  overallBitRateMode?: string;
  sizeBytes?: number;
  sizeToleranceBytes?: number;

  // Video
  width?: number;
  height?: number;
  /** Display aspect ratio (DAR) like "4:3" or "16:9" */
  displayAspectRatio?: string;
  frameRate?: number;
  frameRateTolerance?: number;
  scanType?: "INTERLACED" | "PROGRESSIVE";
  chromaSubsampling?: "4:2:0" | "4:2:2" | "4:4:4";
  videoProfile?: string;
  videoCodecId?: string;
  videoFormat?: string;
  videoFormatSettings?: string;
  videoBitRate?: number;
  videoBitRateTolerance?: number;
  videoBitRateMode?: string;
  videoBitDepth?: number;
  videoPixelAspectRatio?: string;
  videoStreamSize?: number;
  videoStreamSizeTolerance?: number;

  // Audio
  audioChannels?: number;
  audioSampleRate?: number;
  integratedLufs?: number;
  lufsTolerance?: number;
  audioFormat?: string;
  audioCodecId?: string;
  audioBitRate?: number;
  audioBitRateTolerance?: number;
  audioBitRateMode?: string;
  audioBitDepth?: number;
  audioStreamSize?: number;
  audioStreamSizeTolerance?: number;
};

function num(v: any): number | null {
  if (v === null || v === undefined) return null;
  const n = typeof v === "number" ? v : Number(String(v).trim());
  return Number.isFinite(n) ? n : null;
}

function fracToNumber(v: any): number | null {
  if (!v) return null;
  const s = String(v);
  const m = s.match(/^\s*([0-9.]+)\s*\/\s*([0-9.]+)\s*$/);
  if (!m) return num(s);
  const a = num(m[1]);
  const b = num(m[2]);
  if (a == null || b == null || b === 0) return null;
  return a / b;
}

function canonicalFrameRate(fps?: number | null): number | null {
  if (typeof fps !== "number" || !Number.isFinite(fps) || fps <= 0) return null;
  if (Math.abs(fps - 25) <= 0.05) return 25;
  if (Math.abs(fps - 29.97) <= 0.05 || Math.abs(fps - 30000 / 1001) <= 0.05) return 30000 / 1001;
  return fps;
}

function classifyBroadcastStandard(fps?: number | null): { label: string; fps: number } | null {
  const rate = canonicalFrameRate(fps);
  if (rate == null) return null;
  if (Math.abs(rate - 25) <= 0.05) return { label: "PAL", fps: 25 };
  if (Math.abs(rate - 30000 / 1001) <= 0.05 || Math.abs(rate - 29.97) <= 0.05) return { label: "NTSC", fps: 30000 / 1001 };
  return null;
}

function parseDurationTimecode(raw?: string | null, fps?: number | null): { seconds: number; totalFrames: number; tc: string } | null {
  if (!raw) return null;
  const s = String(raw).trim();
  const m = /^(\d{1,2}):(\d{2}):(\d{2})(?::(\d{2}))?$/.exec(s);
  if (!m) return null;
  const hh = Number(m[1]);
  const mm = Number(m[2]);
  const ss = Number(m[3]);
  const ff = Number(m[4] || 0);
  if (![hh, mm, ss, ff].every((n) => Number.isFinite(n) && n >= 0)) return null;
  const rate = canonicalFrameRate(fps);
  if (!rate || rate <= 0) return null;
  const seconds = (hh * 3600) + (mm * 60) + ss + (ff / rate);
  const totalFrames = Math.round(seconds * rate);
  const tc = `${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}:${String(ss).padStart(2, '0')}:${String(ff).padStart(2, '0')}`;
  return { seconds, totalFrames, tc };
}

function formatDurationTimecode(seconds?: number | null, fps?: number | null, explicitFrameCount?: number | null): string | null {
  const rate = canonicalFrameRate(fps);
  if (!rate || typeof seconds !== "number" || !Number.isFinite(seconds) || seconds < 0) return null;
  const totalFrames = typeof explicitFrameCount === "number" && Number.isFinite(explicitFrameCount) && explicitFrameCount >= 0
    ? Math.round(explicitFrameCount)
    : Math.round(seconds * rate);
  const wholeSeconds = Math.floor(totalFrames / rate);
  const ff = Math.round(totalFrames - (wholeSeconds * rate));
  const hh = Math.floor(wholeSeconds / 3600);
  const mm = Math.floor((wholeSeconds % 3600) / 60);
  const ss = wholeSeconds % 60;
  return `${String(hh).padStart(2, '0')}:${String(mm).padStart(2, '0')}:${String(ss).padStart(2, '0')}:${String(ff).padStart(2, '0')}`;
}

function normStr(v: any): string | null {
  if (v === null || v === undefined) return null;
  const s = String(v).trim();
  return s ? s : null;
}

function pickFirst(...vals: any[]): any {
  for (const v of vals) {
    const s = normStr(v);
    if (s != null) return s;
  }
  return null;
}

function miTrack(mi: any, type: string): any | null {
  const tracks = mi?.media?.track;
  if (!Array.isArray(tracks)) return null;
  const want = String(type || "").toLowerCase();
  return (
    tracks.find((t: any) => String(t?.["@type"] || t?.["@Type"] || t?.type || "").toLowerCase() === want) ||
    null
  );
}

function miTracks(mi: any, type: string): any[] {
  const tracks = mi?.media?.track;
  if (!Array.isArray(tracks)) return [];
  const want = String(type || "").toLowerCase();
  return tracks.filter((t: any) => String(t?.["@type"] || t?.["@Type"] || t?.type || "").toLowerCase() === want);
}

function miVal(track: any, ...keys: string[]): any {
  if (!track) return null;
  for (const k of keys) {
    if (track[k] !== undefined && track[k] !== null) return track[k];
  }
  return null;
}

function miStr(track: any, ...keys: string[]): string | null {
  return normStr(miVal(track, ...keys));
}

function miNumRaw(v: any): number | null {
  if (v === null || v === undefined) return null;
  if (typeof v === "number") return Number.isFinite(v) ? v : null;

  let s = String(v).trim();
  if (!s) return null;

  // strip thousand separators/spaces (e.g. "1 920")
  const sNoSpaces = s.replace(/,/g, "").replace(/\s+/g, "");

  // common units
  let m = sNoSpaces.match(/^([-0-9.]+)kHz$/i);
  if (m) {
    const n = num(m[1]);
    return n == null ? null : n * 1000;
  }
  m = sNoSpaces.match(/^([-0-9.]+)Hz$/i);
  if (m) return num(m[1]);

  m = sNoSpaces.match(/^([-0-9.]+)Mbps$/i);
  if (m) {
    const n = num(m[1]);
    return n == null ? null : n * 1000000;
  }
  m = sNoSpaces.match(/^([-0-9.]+)kbps$/i);
  if (m) {
    const n = num(m[1]);
    return n == null ? null : n * 1000;
  }
  m = sNoSpaces.match(/^([-0-9.]+)bps$/i);
  if (m) return num(m[1]);

  return num(sNoSpaces);
}

function miNum(track: any, ...keys: string[]): number | null {
  return miNumRaw(miVal(track, ...keys));
}

function miDurationSec(gen: any): number | null {
  const ms = miNum(gen, "Duration");
  if (ms != null) return ms > 1000 ? ms / 1000 : ms;

  const s =
    miStr(
      gen,
      "Duration/String3",
      "Duration_String3",
      "Duration/String2",
      "Duration_String2",
      "Duration/String1",
      "Duration_String1",
      "Duration/String",
      "Duration_String",
    ) || null;

  if (!s) return null;

  const m = s.match(/(\d{1,2}):(\d{2}):(\d{2})(?:[\.:](\d{1,3}))?/);
  if (m) {
    const hh = num(m[1]) ?? 0;
    const mm = num(m[2]) ?? 0;
    const ss = num(m[3]) ?? 0;
    const ms2 = num(m[4]) ?? 0;
    return hh * 3600 + mm * 60 + ss + ms2 / 1000;
  }

  const n = num(s.replace(/[^\d.-]+/g, ""));
  return n;
}

function normDar(raw: any): string | null {
  const s = normStr(raw);
  if (!s) return null;
  const cleaned = String(s).replace(/\s+/g, "");
  if (cleaned.includes(":")) return cleaned;

  const n = num(cleaned);
  if (n != null) {
    if (Math.abs(n - 4 / 3) < 0.05) return "4:3";
    if (Math.abs(n - 16 / 9) < 0.05) return "16:9";
  }
  return cleaned;
}

function deriveDarFromGeometry(width: number | null, height: number | null, pixelAspectRatioRaw: any): string | null {
  if (width == null || height == null || !Number.isFinite(width) || !Number.isFinite(height) || height === 0) return null;

  const parDirect = normDar(pixelAspectRatioRaw);
  let par: number | null = null;
  if (parDirect?.includes(":")) {
    const [a, b] = parDirect.split(":").map((part) => num(part));
    if (a != null && b != null && b !== 0) par = a / b;
  }
  if (par == null) par = fracToNumber(pixelAspectRatioRaw);
  if (par == null || !Number.isFinite(par) || par <= 0) par = 1;

  return normDar((width / height) * par);
}

function detectScanType(video: any): "INTERLACED" | "PROGRESSIVE" | "UNKNOWN" {
  const fo = String(video?.field_order || "").toLowerCase();
  if (fo.includes("progressive")) return "PROGRESSIVE";
  if (fo.includes("tt") || fo.includes("bb") || fo.includes("tb") || fo.includes("bt")) return "INTERLACED";

  if (video?.interlaced_frame === 1 || video?.interlaced_frame === true) return "INTERLACED";
  if (video?.interlaced_frame === 0 || video?.interlaced_frame === false) return "PROGRESSIVE";

  return "UNKNOWN";
}

function chromaFromPixFmt(pixFmt: any): "4:2:0" | "4:2:2" | "4:4:4" | "UNKNOWN" {
  const s = String(pixFmt || "").toLowerCase();
  if (s.includes("420")) return "4:2:0";
  if (s.includes("422")) return "4:2:2";
  if (s.includes("444")) return "4:4:4";
  return "UNKNOWN";
}

function bitDepthFromPixFmt(pixFmt: any): number | null {
  const s = String(pixFmt || "").toLowerCase();
  // common suffix pattern like yuv422p10le
  const m = s.match(/p(8|10|12|14|16)(le|be)?$/);
  if (m) return Number(m[1]);
  return null;
}

function compareNumber(
  actual: number | null,
  expected: number | undefined,
  tolerance: number | undefined,
): { status: QcCheckStatus; message?: string } {
  if (expected === undefined) return { status: actual == null ? "NA" : "PASS" };
  if (actual == null) return { status: "FAIL", message: "Missing value" };
  const tol = typeof tolerance === "number" && Number.isFinite(tolerance) ? tolerance : 0;
  const ok = Math.abs(actual - expected) <= tol;
  return ok ? { status: "PASS" } : { status: "FAIL", message: `Expected ${expected}±${tol}` };
}

function compareString(actual: string | null, expected: string | undefined): { status: QcCheckStatus; message?: string } {
  if (!expected) return { status: actual == null ? "NA" : "PASS" };
  if (actual == null) return { status: "FAIL", message: "Missing value" };
  const ok = actual.trim().toLowerCase() === expected.trim().toLowerCase();
  return ok ? { status: "PASS" } : { status: "FAIL", message: `Expected ${expected}` };
}


function normalizeBitRateMode(v: any): string | null {
  const s = normStr(v);
  if (!s) return null;
  const u = s.replace(/\s+/g, "").toUpperCase();
  if (u === "CBR" || u.includes("CONSTANT")) return "CBR";
  if (u === "VBR" || u.includes("VARIABLE")) return "VBR";
  return s.trim().toUpperCase();
}

function compareBitRateMode(actual: string | null, expected: string | undefined): { status: QcCheckStatus; message?: string } {
  if (!expected) return { status: actual == null ? "NA" : "PASS" };
  const a = normalizeBitRateMode(actual);
  const e = normalizeBitRateMode(expected);
  if (!a) return { status: "FAIL", message: "Missing value" };
  if (!e) return { status: "PASS" };
  return a === e ? { status: "PASS" } : { status: "FAIL", message: `Expected ${e}` };
}

function normalizeLooseString(v: any): string | null {
  const s = normStr(v);
  if (!s) return null;
  return s.replace(/[_\-]+/g, " ").replace(/\s+/g, " ").trim().toLowerCase();
}

function compareLooseString(actual: string | null, expected: string | undefined): { status: QcCheckStatus; message?: string } {
  if (!expected) return { status: actual == null ? "NA" : "PASS" };
  const a = normalizeLooseString(actual);
  const e = normalizeLooseString(expected);
  if (!a) return { status: "FAIL", message: "Missing value" };
  if (!e) return { status: "PASS" };
  return a === e ? { status: "PASS" } : { status: "FAIL", message: `Expected ${expected}` };
}

function compareNumberLikeString(
  actual: string | null,
  expected: string | undefined,
  tolerance = 0.001,
): { status: QcCheckStatus; message?: string } {
  if (!expected) return { status: actual == null ? "NA" : "PASS" };
  const aNum = num(actual);
  const eNum = num(expected);
  if (aNum != null && eNum != null) {
    const ok = Math.abs(aNum - eNum) <= tolerance;
    return ok ? { status: "PASS" } : { status: "FAIL", message: `Expected ${expected}` };
  }
  return compareString(actual, expected);
}

function formatSettingsParts(raw: Array<string | null | undefined>): string | null {
  const parts: string[] = [];
  const seen = new Set<string>();
  for (const entry of raw) {
    const s = normStr(entry);
    if (!s) continue;
    const key = s.replace(/\s+/g, "").toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    parts.push(s.replace(/\s*\/\s*/g, " / "));
  }
  return parts.length ? parts.join(" / ") : null;
}

function buildVideoFormatSettings(miV: any): string | null {
  const direct = miStr(miV, "Format_Settings", "Format_Settings/String");
  if (direct) return direct.replace(/\s*\/\s*/g, " / ");

  const matrix = miStr(miV, "Format_Settings_Matrix", "Format_Settings_Matrix/String");
  const bvop = miStr(miV, "Format_Settings_BVOP", "Format_Settings_BVOP/String");
  const cabac = miStr(miV, "Format_Settings_CABAC", "Format_Settings_CABAC/String");
  const qpel = miStr(miV, "Format_Settings_QPel", "Format_Settings_QPel/String");
  const gmc = miStr(miV, "Format_Settings_GMC", "Format_Settings_GMC/String");

  return formatSettingsParts([
    matrix,
    /yes|true|1/i.test(String(bvop || "")) ? "BVOP" : null,
    /yes|true|1/i.test(String(cabac || "")) ? "CABAC" : null,
    /yes|true|1/i.test(String(qpel || "")) ? "QPel" : null,
    /yes|true|1/i.test(String(gmc || "")) ? "GMC" : null,
  ]);
}

function toLegacyQcStatus(st: QcCheckStatus): "Pass" | "Fail" | "Warn" | "N/A" {
  if (st === "PASS") return "Pass";
  if (st === "FAIL") return "Fail";
  if (st === "WARN") return "Warn";
  return "N/A";
}

function mergeExpected(base?: Partial<QcExpected>): QcExpected {
  const exp: QcExpected = { ...(base || {}) };

  const envInt = (k: string) => {
    const v = process.env[k];
    const n = num(v);
    return n == null ? undefined : Math.trunc(n);
  };
  const envFloat = (k: string) => {
    const v = process.env[k];
    const n = num(v);
    return n == null ? undefined : n;
  };
  const envStr = (k: string) => {
    const v = process.env[k];
    const s = normStr(v);
    return s == null ? undefined : s;
  };

  exp.durationSec = envFloat("QC_EXPECTED_DURATION_SEC") ?? exp.durationSec;
  exp.durationToleranceSec = envFloat("QC_DURATION_TOLERANCE_SEC") ?? exp.durationToleranceSec;
  exp.generalFormat = envStr("QC_EXPECTED_GENERAL_FORMAT") ?? exp.generalFormat;
  exp.overallBitRate = envFloat("QC_EXPECTED_OVERALL_BIT_RATE") ?? exp.overallBitRate;
  exp.overallBitRateTolerance = envFloat("QC_OVERALL_BIT_RATE_TOLERANCE") ?? exp.overallBitRateTolerance;
  exp.overallBitRateMode = envStr("QC_EXPECTED_OVERALL_BIT_RATE_MODE") ?? exp.overallBitRateMode;
  exp.sizeBytes = envFloat("QC_EXPECTED_SIZE_BYTES") ?? exp.sizeBytes;
  exp.sizeToleranceBytes = envFloat("QC_SIZE_TOLERANCE_BYTES") ?? exp.sizeToleranceBytes;

  exp.width = envInt("QC_EXPECTED_WIDTH") ?? exp.width;
  exp.height = envInt("QC_EXPECTED_HEIGHT") ?? exp.height;
  exp.displayAspectRatio = envStr("QC_EXPECTED_DAR") ?? exp.displayAspectRatio;
  exp.frameRate = envFloat("QC_EXPECTED_FRAME_RATE") ?? exp.frameRate;
  exp.frameRateTolerance = envFloat("QC_FRAME_RATE_TOLERANCE") ?? exp.frameRateTolerance;

  const scan = envStr("QC_EXPECTED_SCAN_TYPE");
  if (scan) {
    const u = scan.toUpperCase();
    exp.scanType = (u === "INTERLACED" || u === "PROGRESSIVE") ? (u as any) : exp.scanType;
  }

  const chroma = envStr("QC_EXPECTED_CHROMA");
  if (chroma) {
    const c = chroma.replace(/\s+/g, "");
    exp.chromaSubsampling = (c === "4:2:0" || c === "4:2:2" || c === "4:4:4") ? (c as any) : exp.chromaSubsampling;
  }

  exp.videoProfile = envStr("QC_EXPECTED_VIDEO_PROFILE") ?? exp.videoProfile;
  exp.videoCodecId = envStr("QC_EXPECTED_VIDEO_CODEC_ID") ?? exp.videoCodecId;
  exp.videoFormat = envStr("QC_EXPECTED_VIDEO_FORMAT") ?? exp.videoFormat;
  exp.videoFormatSettings = envStr("QC_EXPECTED_VIDEO_FORMAT_SETTINGS") ?? exp.videoFormatSettings;
  exp.videoBitRate = envFloat("QC_EXPECTED_VIDEO_BIT_RATE") ?? exp.videoBitRate;
  exp.videoBitRateTolerance = envFloat("QC_VIDEO_BIT_RATE_TOLERANCE") ?? exp.videoBitRateTolerance;
  exp.videoBitRateMode = envStr("QC_EXPECTED_VIDEO_BIT_RATE_MODE") ?? exp.videoBitRateMode;
  exp.videoBitDepth = envInt("QC_EXPECTED_VIDEO_BIT_DEPTH") ?? exp.videoBitDepth;
  exp.videoPixelAspectRatio = envStr("QC_EXPECTED_PIXEL_ASPECT_RATIO") ?? exp.videoPixelAspectRatio;
  exp.videoStreamSize = envFloat("QC_EXPECTED_VIDEO_STREAM_SIZE") ?? exp.videoStreamSize;
  exp.videoStreamSizeTolerance = envFloat("QC_VIDEO_STREAM_SIZE_TOLERANCE") ?? exp.videoStreamSizeTolerance;

  exp.audioChannels = envInt("QC_EXPECTED_AUDIO_CHANNELS") ?? exp.audioChannels;
  exp.audioSampleRate = envInt("QC_EXPECTED_AUDIO_SAMPLE_RATE") ?? exp.audioSampleRate;
  exp.integratedLufs = envFloat("QC_EXPECTED_INTEGRATED_LUFS") ?? exp.integratedLufs;
  exp.lufsTolerance = envFloat("QC_LUFS_TOLERANCE") ?? exp.lufsTolerance;
  exp.audioFormat = envStr("QC_EXPECTED_AUDIO_FORMAT") ?? exp.audioFormat;
  exp.audioCodecId = envStr("QC_EXPECTED_AUDIO_CODEC_ID") ?? exp.audioCodecId;
  exp.audioBitRate = envFloat("QC_EXPECTED_AUDIO_BIT_RATE") ?? exp.audioBitRate;
  exp.audioBitRateTolerance = envFloat("QC_AUDIO_BIT_RATE_TOLERANCE") ?? exp.audioBitRateTolerance;
  exp.audioBitRateMode = envStr("QC_EXPECTED_AUDIO_BIT_RATE_MODE") ?? exp.audioBitRateMode;
  exp.audioBitDepth = envInt("QC_EXPECTED_AUDIO_BIT_DEPTH") ?? exp.audioBitDepth;
  exp.audioStreamSize = envFloat("QC_EXPECTED_AUDIO_STREAM_SIZE") ?? exp.audioStreamSize;
  exp.audioStreamSizeTolerance = envFloat("QC_AUDIO_STREAM_SIZE_TOLERANCE") ?? exp.audioStreamSizeTolerance;

  if (exp.frameRate !== undefined && exp.frameRateTolerance === undefined) exp.frameRateTolerance = 0.05;
  if (exp.durationSec !== undefined && exp.durationToleranceSec === undefined) exp.durationToleranceSec = 0.5;
  if (exp.integratedLufs !== undefined && exp.lufsTolerance === undefined) exp.lufsTolerance = 1.0;
  if (exp.overallBitRate !== undefined && exp.overallBitRateTolerance === undefined) exp.overallBitRateTolerance = 0;
  if (exp.videoBitRate !== undefined && exp.videoBitRateTolerance === undefined) exp.videoBitRateTolerance = 0;
  if (exp.audioBitRate !== undefined && exp.audioBitRateTolerance === undefined) exp.audioBitRateTolerance = 0;
  if (exp.sizeBytes !== undefined && exp.sizeToleranceBytes === undefined) exp.sizeToleranceBytes = 0;
  if (exp.videoStreamSize !== undefined && exp.videoStreamSizeTolerance === undefined) exp.videoStreamSizeTolerance = 0;
  if (exp.audioStreamSize !== undefined && exp.audioStreamSizeTolerance === undefined) exp.audioStreamSizeTolerance = 0;

  return exp;
}

export function evalAutoQc(
  ffprobe: any,
  opts?: { expected?: Partial<QcExpected>; sourcePath?: string; qcTools?: any },
): QcEvalResult {
  const reasons: string[] = [];
  const warnings: string[] = [];

  const streams = Array.isArray(ffprobe?.streams) ? ffprobe.streams : [];
  const audioStreams = streams.filter((s: any) => s?.codec_type === "audio");
  const video = streams.find((s: any) => s?.codec_type === "video");
  const audio = audioStreams[0] || null;

  const expected = mergeExpected(opts?.expected);
  const mediainfo = opts?.qcTools?.mediainfo || null;
  const miG = miTrack(mediainfo, "General");
  const miV = miTrack(mediainfo, "Video");
  const miA = miTrack(mediainfo, "Audio");
  const miAudioAll = miTracks(mediainfo, "Audio");

  const hasVideo = Boolean(video || miV || miNum(miG, "VideoCount") || miTracks(mediainfo, "Video").length);
  const hasAudio = Boolean(audioStreams.length || miAudioAll.length || miNum(miG, "AudioCount"));

  // Only enforce channel count when explicitly configured.
  const expectedChannels = typeof expected.audioChannels === "number" ? expected.audioChannels : undefined;
  const enforceChannels = String(process.env.QC_ENFORCE_STEREO || "").toLowerCase() === "true";

  if (!hasVideo) reasons.push("NO_VIDEO_STREAM");

  if (!hasAudio) {
    reasons.push("NO_AUDIO_STREAM");
  } else if (typeof expectedChannels === "number" && Number.isFinite(expectedChannels) && expectedChannels > 0) {
    const hasExpected = audioStreams.some((a: any) => typeof a?.channels === "number" && a.channels === expectedChannels)
      || miAudioAll.some((track: any) => miNum(track, "Channels", "Channel(s)") === expectedChannels);

    const isDualMonoStereoEquivalent =
      expectedChannels === 2 &&
      ((audioStreams.length === 2 && audioStreams.every((a: any) => typeof a?.channels === "number" && a.channels === 1))
        || (miAudioAll.length === 2 && miAudioAll.every((track: any) => miNum(track, "Channels", "Channel(s)") === 1)));

    if (!hasExpected && !isDualMonoStereoEquivalent) {
      if (enforceChannels) reasons.push("AUDIO_CHANNELS_MISMATCH");
      else warnings.push(expectedChannels === 2 ? "AUDIO_NOT_STEREO" : "AUDIO_CHANNELS_MISMATCH");
    } else if (isDualMonoStereoEquivalent) {
      warnings.push("AUDIO_DUAL_MONO_AS_STEREO");
    }
  }

  const checks: QcCheck[] = [];
  const add = (c: QcCheck) => checks.push(c);

  const fmt = ffprobe?.format || {};
  const fmtTags = fmt?.tags || {};
  const v = video || {};
  const a = audio || {};


  const sourcePath = pickFirst(opts?.sourcePath, fmt?.filename) || null;
  const fileName = sourcePath ? sourcePath.split(/[\\/]/).pop() || sourcePath : null;

  // --- General ---
  add({ group: "General", name: "FileName", value: fileName || "—", status: fileName ? "PASS" : "NA" });
  add({ group: "General", name: "Path", value: sourcePath || "—", status: sourcePath ? "PASS" : "NA" });

  const langG = pickFirst(miStr(miG, "Language"), fmtTags?.language);
  add({ group: "General", name: "Language", value: langG ? String(langG) : "—", status: langG ? "PASS" : "NA" });

  // MediaInfo often reports Duration in milliseconds; client expects both ms and seconds (legacy tool behavior).
  const durationMsRaw = miNum(miG, "Duration");
  if (durationMsRaw != null) {
    add({ group: "General", name: "Duration", value: String(Math.trunc(durationMsRaw)), status: "PASS" });
  }

  const containerFmt = pickFirst(miStr(miG, "Format/String"), miStr(miG, "Format"), fmt?.format_long_name, fmt?.format_name);
  {
    const cmp = compareLooseString(containerFmt, expected.generalFormat);
    add({
      group: "General",
      name: "Format",
      value: containerFmt || "—",
      status: cmp.status,
      expected: expected.generalFormat,
      message: cmp.message,
    });
  }

  const encLib = pickFirst(miStr(miG, "Encoded_Library", "Encoded_Library/String"), fmtTags?.encoder, v?.tags?.encoder, a?.tags?.encoder);
  add({ group: "General", name: "EncodedLibrary", value: encLib || "—", status: encLib ? "PASS" : "NA" });

  const encDate = pickFirst(miStr(miG, "Encoded_Date", "Tagged_Date", "File_Modified_Date"), fmtTags?.creation_time, v?.tags?.creation_time, a?.tags?.creation_time);
  add({ group: "General", name: "EncodedDate", value: encDate || "—", status: encDate ? "PASS" : "NA" });

  const fps = miNum(miV, "FrameRate") ?? fracToNumber(v?.avg_frame_rate && v.avg_frame_rate !== "0/0" ? v.avg_frame_rate : v?.r_frame_rate);
  const standard = classifyBroadcastStandard(fps);
  add({
    group: "General",
    name: "BroadcastStandard",
    value: standard ? `${standard.label} (${Number(standard.fps.toFixed(3))} fps)` : (fps == null ? "—" : `${Number(fps.toFixed(3))} fps`),
    status: standard ? "PASS" : (fps == null ? "NA" : "WARN"),
    expected: expected.frameRate !== undefined ? `${expected.frameRate} fps` : undefined,
    message: standard ? undefined : (fps == null ? undefined : "Frame rate is not PAL/NTSC canonical"),
  });

  const durationSec = num(fmt?.duration) ?? miDurationSec(miG);
  {
    const cmp = compareNumber(durationSec, expected.durationSec, expected.durationToleranceSec);
    add({
      group: "General",
      name: "Duration",
      value: durationSec == null ? "—" : String(durationSec),
      status: cmp.status,
      expected: expected.durationSec !== undefined ? `${expected.durationSec}` : undefined,
      message: cmp.message,
    });
  }

  const actualFrameCount = miNum(miV, "FrameCount") ?? (durationSec != null && fps != null ? Math.round(durationSec * fps) : null);
  const expectedTc = parseDurationTimecode(expected.durationTc, fps);
  const actualTc = formatDurationTimecode(durationSec, fps, actualFrameCount);
  if (expected.durationTc) {
    const cmp = expectedTc && actualFrameCount != null
      ? compareNumber(actualFrameCount, expectedTc.totalFrames, 1)
      : { status: (actualTc ? "PASS" : "NA") as QcCheckStatus, message: expectedTc ? undefined : "Could not interpret expected hh:mm:ss:ff against PAL/NTSC frame rate" };
    add({
      group: "General",
      name: "DurationTimecode",
      value: actualTc || "—",
      status: cmp.status,
      expected: expectedTc?.tc ?? expected.durationTc,
      message: cmp.message,
    });
  }

  const sizeBytes = num(fmt?.size) ?? miNum(miG, "FileSize");
  {
    const cmp = compareNumber(sizeBytes, expected.sizeBytes, expected.sizeToleranceBytes);
    add({
      group: "General",
      name: "Size",
      value: sizeBytes == null ? "—" : String(Math.trunc(sizeBytes)),
      status: cmp.status,
      expected: expected.sizeBytes !== undefined ? String(Math.trunc(expected.sizeBytes)) : undefined,
      message: cmp.message,
    });
  }

  const bitRate = num(fmt?.bit_rate) ?? miNum(miG, "OverallBitRate");
  {
    const cmp = compareNumber(bitRate, expected.overallBitRate, expected.overallBitRateTolerance);
    add({
      group: "General",
      name: "BitRate",
      value: bitRate == null ? "—" : String(Math.trunc(bitRate)),
      status: cmp.status,
      expected: expected.overallBitRate !== undefined ? String(Math.trunc(expected.overallBitRate)) : undefined,
      message: cmp.message,
    });
  }

  const brModeG = pickFirst(
    miStr(miG, "OverallBitRate_Mode", "OverallBitRate_Mode/String", "OverallBitRate_Mode_String"),
    miStr(miG, "BitRate_Mode", "BitRate_Mode/String", "BitRate_Mode_String"),
  );
  {
    const cmp = compareBitRateMode(brModeG, expected.overallBitRateMode);
    add({
      group: "General",
      name: "BitRateMode",
      value: normalizeBitRateMode(brModeG) || "—",
      status: cmp.status,
      expected: normalizeBitRateMode(expected.overallBitRateMode) || undefined,
      message: cmp.message,
    });
  }

  // --- Video ---
  const videoCodecId = pickFirst(miStr(miV, "CodecID", "CodecID/String"), v?.codec_tag_string, v?.codec_tag, v?.codec_name);
  {
    const cmp = compareString(videoCodecId, expected.videoCodecId);
    add({
      group: "Video",
      name: "CodecId",
      value: videoCodecId || "—",
      status: cmp.status,
      expected: expected.videoCodecId,
      message: cmp.message,
    });
  }

  const profile = pickFirst(miStr(miV, "Format_Profile", "Format_Profile/String"), normStr(v?.profile));
  {
    const cmp = compareString(profile, expected.videoProfile);
    add({
      group: "Video",
      name: "Format_Profile",
      value: profile || "—",
      status: cmp.status,
      expected: expected.videoProfile,
      message: cmp.message,
    });
  }

  const videoFmt = pickFirst(miStr(miV, "Format", "Format/String"), v?.codec_long_name, v?.codec_name);
  {
    const cmp = compareLooseString(videoFmt, expected.videoFormat);
    add({
      group: "Video",
      name: "Format",
      value: videoFmt || "—",
      status: cmp.status,
      expected: expected.videoFormat,
      message: cmp.message,
    });
  }

  const videoFormatSettings = buildVideoFormatSettings(miV);
  {
    const cmp = compareLooseString(videoFormatSettings, expected.videoFormatSettings);
    add({
      group: "Video",
      name: "Format_Settings",
      value: videoFormatSettings || "—",
      status: cmp.status,
      expected: expected.videoFormatSettings,
      message: cmp.message,
    });
  }

  const vEncLib = pickFirst(miStr(miV, "Encoded_Library", "Encoded_Library/String"), v?.tags?.encoder);
  add({ group: "Video", name: "EncodedLibrary", value: vEncLib || "—", status: vEncLib ? "PASS" : "NA" });

  const langV = pickFirst(miStr(miV, "Language"), v?.tags?.language);
  add({ group: "Video", name: "Language", value: langV ? String(langV) : "—", status: langV ? "PASS" : "NA" });

  const vBitRate = miNum(miV, "BitRate") ?? num(v?.bit_rate);
  {
    const cmp = compareNumber(vBitRate, expected.videoBitRate, expected.videoBitRateTolerance);
    add({
      group: "Video",
      name: "BitRate",
      value: vBitRate == null ? "—" : String(Math.trunc(vBitRate)),
      status: cmp.status,
      expected: expected.videoBitRate !== undefined ? String(Math.trunc(expected.videoBitRate)) : undefined,
      message: cmp.message,
    });
  }

  const vBrMode = pickFirst(miStr(miV, "BitRate_Mode", "BitRate_Mode/String", "BitRate_Mode_String"));
  {
    const cmp = compareBitRateMode(vBrMode, expected.videoBitRateMode);
    add({
      group: "Video",
      name: "BitRateMode",
      value: normalizeBitRateMode(vBrMode) || "—",
      status: cmp.status,
      expected: normalizeBitRateMode(expected.videoBitRateMode) || undefined,
      message: cmp.message,
    });
  }

  const vStreamSize = miNum(miV, "StreamSize");
  {
    const cmp = compareNumber(vStreamSize, expected.videoStreamSize, expected.videoStreamSizeTolerance);
    add({
      group: "Video",
      name: "StreamSize",
      value: vStreamSize == null ? "—" : String(Math.trunc(vStreamSize)),
      status: cmp.status,
      expected: expected.videoStreamSize !== undefined ? String(Math.trunc(expected.videoStreamSize)) : undefined,
      message: cmp.message,
    });
  }

  const width = miNum(miV, "Width") ?? num(v?.width);
  const height = miNum(miV, "Height") ?? num(v?.height);
  {
    const cmpW = compareNumber(width, expected.width, 0);
    add({
      group: "Video",
      name: "Width",
      value: width == null ? "—" : String(width),
      status: cmpW.status,
      expected: expected.width !== undefined ? String(expected.width) : undefined,
      message: cmpW.message,
    });
  }
  {
    const cmpH = compareNumber(height, expected.height, 0);
    add({
      group: "Video",
      name: "Height",
      value: height == null ? "—" : String(height),
      status: cmpH.status,
      expected: expected.height !== undefined ? String(expected.height) : undefined,
      message: cmpH.message,
    });
  }

  const darStr =
    normDar(miVal(
      miV,
      "DisplayAspectRatio/String",
      "DisplayAspectRatio_String",
      "DisplayAspectRatio/String3",
      "DisplayAspectRatio_String3",
      "DisplayAspectRatio_Original/String",
      "DisplayAspectRatio_Original_String",
      "DisplayAspectRatio_Original",
      "DisplayAspectRatio",
    ))
    ?? deriveDarFromGeometry(
      width,
      height,
      miVal(miV, "PixelAspectRatio/String", "PixelAspectRatio_String", "PixelAspectRatio"),
    )
    ?? normDar(v?.display_aspect_ratio);
  {
    const expectedDar = expected.displayAspectRatio;
    const actualDar = darStr;
    const cmp = expectedDar ? compareString(actualDar, expectedDar) : { status: actualDar ? "PASS" : ("NA" as QcCheckStatus) };
    add({
      group: "Video",
      name: "DisplayAspectRatio",
      value: actualDar || "—",
      status: cmp.status,
      expected: expectedDar,
      message: (cmp as any).message,
    });
  }

  const videoFps = fps;
  {
    const cmp = compareNumber(videoFps, expected.frameRate, expected.frameRateTolerance);
    add({
      group: "Video",
      name: "FrameRate",
      value: videoFps == null ? "—" : String(Number(videoFps.toFixed(3))),
      status: cmp.status,
      expected: expected.frameRate !== undefined ? `${expected.frameRate}` : undefined,
      message: cmp.message,
    });
  }

  const frMode = (() => {
    const miMode = miStr(miV, "FrameRate_Mode", "FrameRate_Mode/String");
    if (miMode) {
      const m = String(miMode).toUpperCase();
      if (m.includes("CONSTANT")) return "CFR";
      if (m.includes("VARIABLE")) return "VFR";
      if (m === "CFR" || m === "VFR") return m;
    }

    const r = fracToNumber(v?.r_frame_rate);
    const a2 = fracToNumber(v?.avg_frame_rate);
    if (r == null || a2 == null) return "—";
    if (Math.abs(r - a2) < 0.001) return "CFR";
    return "VFR";
  })();
  add({ group: "Video", name: "FrameRateMode", value: frMode, status: frMode === "—" ? "NA" : "PASS" });

  const scan = (() => {
    const miScan = miStr(miV, "ScanType");
    if (miScan) {
      const s = String(miScan).toUpperCase();
      if (s.includes("INTERLACED")) return "INTERLACED";
      if (s.includes("PROGRESSIVE")) return "PROGRESSIVE";
    }
    return detectScanType(v);
  })();
  {
    const expectedScan = expected.scanType;
    const actualScan = scan === "UNKNOWN" ? null : scan;
    const cmp = expectedScan ? compareString(actualScan, expectedScan) : { status: actualScan ? "PASS" : "NA" as QcCheckStatus };
    add({
      group: "Video",
      name: "ScanType",
      value: actualScan || "—",
      status: cmp.status,
      expected: expectedScan,
      message: (cmp as any).message,
    });
  }

  const par = (() => {
    const miPar = miStr(miV, "PixelAspectRatio");
    if (miPar) return miPar;
    const sar = normStr(v?.sample_aspect_ratio);
    if (!sar) return null;
    const n = fracToNumber(sar);
    return n != null ? String(Number(n.toFixed(3))) : sar;
  })();
  {
    const cmp = compareNumberLikeString(par, expected.videoPixelAspectRatio, 0.001);
    add({
      group: "Video",
      name: "PixelAspectRatio",
      value: par || "—",
      status: cmp.status,
      expected: expected.videoPixelAspectRatio,
      message: cmp.message,
    });
  }

  // MediaInfo legacy field: Bits/(Pixel*Frame) (a.k.a. BitPerFrame in the old QC UI).
  const miBpf = miNum(miV, "Bits/(Pixel*Frame)", "Bits/(Pixel*Frame)/String", "Bits/(Pixel*Frame)_String", "Bits_Pixel_Frame");
  const calcBpf = (() => {
    if (miBpf != null) return miBpf;
    if (vBitRate == null || width == null || height == null) return null;
    const fpsN = fps == null ? null : Number(fps);
    if (!fpsN || !Number.isFinite(fpsN) || fpsN <= 0) return null;
    const denom = width * height * fpsN;
    if (!denom) return null;
    return vBitRate / denom;
  })();
  add({
    group: "Video",
    name: "BitPerFrame",
    value: calcBpf == null ? "—" : String(Number(calcBpf.toFixed(5))),
    status: calcBpf == null ? "NA" : "PASS",
  });

  const pixFmt = normStr(v?.pix_fmt);
  const miChroma = miStr(miV, "ChromaSubsampling");
  const chroma = miChroma ? String(miChroma).replace(/\s+/g, "") : chromaFromPixFmt(pixFmt);
  {
    const expectedChroma = expected.chromaSubsampling;
    const actualChroma = chroma === "UNKNOWN" ? null : chroma;
    const cmp = expectedChroma ? compareString(actualChroma, expectedChroma) : { status: actualChroma ? "PASS" : "NA" as QcCheckStatus };
    add({
      group: "Video",
      name: "ChromaSubsampling",
      value: actualChroma || "—",
      status: cmp.status,
      expected: expectedChroma,
      message: (cmp as any).message,
    });
  }

  const vBitDepth = miNum(miV, "BitDepth") ?? num(v?.bits_per_raw_sample) ?? num(v?.bits_per_sample) ?? bitDepthFromPixFmt(pixFmt);
  {
    const cmp = compareNumber(vBitDepth, expected.videoBitDepth, 0);
    add({
      group: "Video",
      name: "BitDepth",
      value: vBitDepth == null ? "—" : String(vBitDepth),
      status: cmp.status,
      expected: expected.videoBitDepth !== undefined ? String(expected.videoBitDepth) : undefined,
      message: cmp.message,
    });
  }

  // --- Audio ---
  const audioCodecId = pickFirst(miStr(miA, "CodecID", "CodecID/String", "Format"), a?.codec_tag_string, a?.codec_tag, a?.codec_name);
  {
    const cmp = compareString(audioCodecId, expected.audioCodecId);
    add({
      group: "Audio",
      name: "CodecId",
      value: audioCodecId || "—",
      status: cmp.status,
      expected: expected.audioCodecId,
      message: cmp.message,
    });
  }

  const audioFmt = pickFirst(miStr(miA, "Format", "Format/String"), a?.codec_long_name, a?.codec_name);
  {
    const cmp = compareLooseString(audioFmt, expected.audioFormat);
    add({
      group: "Audio",
      name: "Format",
      value: audioFmt || "—",
      status: cmp.status,
      expected: expected.audioFormat,
      message: cmp.message,
    });
  }

  const aEncLib = pickFirst(miStr(miA, "Encoded_Library", "Encoded_Library/String"), a?.tags?.encoder);
  add({ group: "Audio", name: "EncodedLibrary", value: aEncLib || "—", status: aEncLib ? "PASS" : "NA" });

  const aBitRate = miNum(miA, "BitRate") ?? num(a?.bit_rate);
  {
    const cmp = compareNumber(aBitRate, expected.audioBitRate, expected.audioBitRateTolerance);
    add({
      group: "Audio",
      name: "BitRate",
      value: aBitRate == null ? "—" : String(Math.trunc(aBitRate)),
      status: cmp.status,
      expected: expected.audioBitRate !== undefined ? String(Math.trunc(expected.audioBitRate)) : undefined,
      message: cmp.message,
    });
  }

  const aBrMode = pickFirst(miStr(miA, "BitRate_Mode", "BitRate_Mode/String", "BitRate_Mode_String"));
  {
    const cmp = compareBitRateMode(aBrMode, expected.audioBitRateMode);
    add({
      group: "Audio",
      name: "BitRateMode",
      value: normalizeBitRateMode(aBrMode) || "—",
      status: cmp.status,
      expected: normalizeBitRateMode(expected.audioBitRateMode) || undefined,
      message: cmp.message,
    });
  }

  const aStreamSize = miNum(miA, "StreamSize");
  {
    const cmp = compareNumber(aStreamSize, expected.audioStreamSize, expected.audioStreamSizeTolerance);
    add({
      group: "Audio",
      name: "StreamSize",
      value: aStreamSize == null ? "—" : String(Math.trunc(aStreamSize)),
      status: cmp.status,
      expected: expected.audioStreamSize !== undefined ? String(Math.trunc(expected.audioStreamSize)) : undefined,
      message: cmp.message,
    });
  }

  const ch = miNum(miA, "Channels") ?? (typeof a?.channels === "number" ? a.channels : num(a?.channels));
  {
    const cmp = compareNumber(ch == null ? null : Number(ch), expectedChannels, 0);
    const channelStatus: QcCheckStatus =
      enforceChannels || cmp.status !== "FAIL"
        ? cmp.status
        : audioStreams.length
          ? "WARN"
          : "NA";
    add({
      group: "Audio",
      name: "Channels",
      value: ch == null ? "—" : String(ch),
      status: channelStatus,
      expected: expectedChannels ? String(expectedChannels) : undefined,
      message:
        channelStatus === "WARN"
          ? cmp.message || "Client-specific rule: audio channel mismatch is informational only"
          : cmp.message,
    });
  }

  const sr = miNum(miA, "SamplingRate") ?? num(a?.sample_rate);
  {
    const cmp = compareNumber(sr, expected.audioSampleRate, 0);
    add({
      group: "Audio",
      name: "SampleRate",
      value: sr == null ? "—" : String(sr),
      status: cmp.status,
      expected: expected.audioSampleRate !== undefined ? String(expected.audioSampleRate) : undefined,
      message: cmp.message,
    });
  }

  const lang = pickFirst(miStr(miA, "Language"), a?.tags?.language, fmtTags?.language);
  add({ group: "Audio", name: "Language", value: lang ? String(lang) : "—", status: lang ? "PASS" : "NA" });

  const aBitDepth = miNum(miA, "BitDepth") ?? num(a?.bits_per_sample) ?? num(a?.bits_per_raw_sample);
  {
    const cmp = compareNumber(aBitDepth, expected.audioBitDepth, 0);
    add({
      group: "Audio",
      name: "BitDepth",
      value: aBitDepth == null ? "—" : String(aBitDepth),
      status: cmp.status,
      expected: expected.audioBitDepth !== undefined ? String(expected.audioBitDepth) : undefined,
      message: cmp.message,
    });
  }

  const integrated = num(opts?.qcTools?.measures?.loudness?.integrated_lufs);
  if (integrated != null || expected.integratedLufs !== undefined) {
    const cmp = compareNumber(integrated, expected.integratedLufs, expected.lufsTolerance);
    add({
      group: "Audio",
      name: "Loudness",
      value: integrated == null ? "—" : `${Number(integrated).toFixed(1)} LUFS`,
      status: cmp.status,
      expected: expected.integratedLufs !== undefined ? `${expected.integratedLufs}` : undefined,
      message: cmp.message,
    });
  } else {
    add({ group: "Audio", name: "Loudness", value: "—", status: "NA" });
  }

  // New rule: if ANY detailed QC check is FAIL, overall QC must be FAILED.
  // (Client expectation: all checks must pass for overall QC pass.)
  const failedChecks = checks.filter((c) => c.status === "FAIL");
  const checkReasonMap = new Map<string, string>([
    ["General::Duration", "DURATION_MISMATCH"],
    ["General::Format", "GENERAL_FORMAT_MISMATCH"],
    ["General::BitRate", "GENERAL_BIT_RATE_MISMATCH"],
    ["General::BitRateMode", "GENERAL_BIT_RATE_MODE_MISMATCH"],
    ["General::Size", "GENERAL_SIZE_MISMATCH"],
    ["Video::FrameRate", "FPS_MISMATCH"],
    ["Video::Width", "VIDEO_WIDTH_MISMATCH"],
    ["Video::Height", "VIDEO_HEIGHT_MISMATCH"],
    ["Video::DisplayAspectRatio", "VIDEO_DAR_MISMATCH"],
    ["Video::ScanType", "VIDEO_SCAN_TYPE_MISMATCH"],
    ["Video::ChromaSubsampling", "VIDEO_CHROMA_MISMATCH"],
    ["Video::CodecId", "VIDEO_CODEC_MISMATCH"],
    ["Video::Format_Profile", "VIDEO_PROFILE_MISMATCH"],
    ["Video::Format", "VIDEO_FORMAT_MISMATCH"],
    ["Video::Format_Settings", "VIDEO_FORMAT_SETTINGS_MISMATCH"],
    ["Video::BitRate", "VIDEO_BIT_RATE_MISMATCH"],
    ["Video::BitRateMode", "VIDEO_BIT_RATE_MODE_MISMATCH"],
    ["Video::BitDepth", "VIDEO_BIT_DEPTH_MISMATCH"],
    ["Video::PixelAspectRatio", "VIDEO_PAR_MISMATCH"],
    ["Video::StreamSize", "VIDEO_STREAM_SIZE_MISMATCH"],
    ["Audio::CodecId", "AUDIO_CODEC_MISMATCH"],
    ["Audio::Format", "AUDIO_FORMAT_MISMATCH"],
    ["Audio::BitRate", "AUDIO_BIT_RATE_MISMATCH"],
    ["Audio::BitRateMode", "AUDIO_BIT_RATE_MODE_MISMATCH"],
    ["Audio::StreamSize", "AUDIO_STREAM_SIZE_MISMATCH"],
    ["Audio::SampleRate", "AUDIO_SAMPLE_RATE_MISMATCH"],
    ["Audio::BitDepth", "AUDIO_BIT_DEPTH_MISMATCH"],
    ["Audio::Loudness", "AUDIO_LOUDNESS_MISMATCH"],
  ]);
  const detailedFailReasons = failedChecks
    .map((c) => checkReasonMap.get(`${c.group}::${c.name}`))
    .filter((v): v is string => Boolean(v));
  for (const code of detailedFailReasons) {
    if (!reasons.includes(code)) reasons.push(code);
  }
  if (failedChecks.length && !reasons.length) {
    reasons.push("QC_CHECK_FAILED");
  }

  const status = reasons.length || failedChecks.length ? "FAILED" : "PASSED";
  const summary = checks.reduce(
    (acc, c) => {
      acc.total++;
      if (c.status === "PASS") acc.pass++;
      else if (c.status === "FAIL") acc.fail++;
      else if (c.status === "WARN") acc.warn++;
      else acc.na++;
      return acc;
    },
    { total: 0, pass: 0, fail: 0, warn: 0, na: 0 },
  );

  const legacyClientChecks = checks.map((c) => ({
    propertyName: c.name,
    propertyValue: c.value,
    qcStatus: toLegacyQcStatus(c.status),
    group: c.group,
    expected: c.expected ?? null,
    message: c.message ?? null,
  }));

  const clientMetadata = buildClientQcMetadata(mediainfo, sourcePath, integrated);

  return {
    status,
    reasons,
    report: {
      tool: opts?.qcTools?.qcli ? "qcli+mediainfo" : (mediainfo ? "mediainfo" : "unknown"),
      checkedAt: new Date().toISOString(),
      reasons,
      warnings,
      expected,
      expectedAudioChannels: expectedChannels,
      enforceExpectedAudioChannels: enforceChannels,
      enforceDetailedChecks: true,
      checks,
      legacyClientChecks,
      checkSummary: summary,
      clientMetadata,
      ffprobe,
      mediainfo,
    },
  };
}