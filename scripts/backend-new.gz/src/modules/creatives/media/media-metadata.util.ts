export type MediaFileSummary = {
  filename?: string | null;
  sizeBytes?: string | number | bigint | null;
  mimeType?: string | null;
};

export type NormalizedMediaMetadata = {
  format: {
    filename: string | null;
    container: string | null;
    containerLongName: string | null;
    mimeType: string | null;
    durationSeconds: number | string | null;
    sizeBytes: number | string | null;
    bitRate: number | string | null;
    startTimeSeconds: number | string | null;
    streamCount: number | string | null;
    probeScore: number | string | null;
    tags: any;
  };
  videoStreams: Array<Record<string, any>>;
  audioStreams: Array<Record<string, any>>;
  otherStreams: Array<Record<string, any>>;
  toolUsed: string;
};

function valueByKey(obj: any, key: string) {
  if (!obj || typeof obj !== "object") return undefined;
  if (Object.prototype.hasOwnProperty.call(obj, key)) return obj[key];
  const normalized = key.replace(/[\s_/()-]+/g, "").toLowerCase();
  for (const k of Object.keys(obj)) {
    const nk = String(k || "").replace(/[\s_/()-]+/g, "").toLowerCase();
    if (nk === normalized) return obj[k];
  }
  return undefined;
}

function firstValue(obj: any, ...keys: string[]) {
  for (const key of keys) {
    const v = valueByKey(obj, key);
    if (v !== undefined && v !== null && String(v).trim() !== "") return v;
  }
  return undefined;
}

function toNumber(value: any): number | null {
  if (value === null || value === undefined || value === "") return null;
  if (typeof value === "number") return Number.isFinite(value) ? value : null;
  const raw = String(value).trim();
  if (!raw) return null;
  const direct = Number(raw);
  if (Number.isFinite(direct)) return direct;
  const cleaned = raw.replace(/[,\s]/g, "").replace(/[^0-9+\-.]/g, "");
  if (!cleaned) return null;
  const n = Number(cleaned);
  return Number.isFinite(n) ? n : null;
}

function mediaInfoNumber(track: any, ...keys: string[]) {
  for (const key of keys) {
    const n = toNumber(firstValue(track, key));
    if (n !== null) return n;
  }
  return null;
}

function mediaInfoString(track: any, ...keys: string[]) {
  for (const key of keys) {
    const v = firstValue(track, key);
    if (v !== undefined && v !== null) {
      const s = String(v).trim();
      if (s) return s;
    }
  }
  return null;
}


function jsonSafeScalar(value: any): string | number | null {
  if (value === null || value === undefined || value === "") return null;
  if (typeof value === "bigint") {
    const n = Number(value);
    return Number.isSafeInteger(n) ? n : value.toString();
  }
  if (typeof value === "number") return Number.isFinite(value) ? value : null;
  if (typeof value === "string") {
    const s = value.trim();
    return s || null;
  }
  return null;
}

function mediaInfoDurationSeconds(track: any) {
  const raw = firstValue(track, "Duration", "Duration/String3", "Duration/String", "Duration/String4");
  if (raw == null) return null;

  const direct = toNumber(raw);
  if (direct !== null) {
    if (direct > 1000) return direct / 1000;
    return direct;
  }

  const str = String(raw).trim();
  const hms = /(\d{1,2}):(\d{2}):(\d{2})(?:\.(\d+))?/.exec(str);
  if (hms) {
    const hh = Number(hms[1]);
    const mm = Number(hms[2]);
    const ss = Number(hms[3]);
    const frac = hms[4] ? Number(`0.${hms[4]}`) : 0;
    return hh * 3600 + mm * 60 + ss + frac;
  }

  const part = /(?:(\d+)\s*h)?\s*(?:(\d+)\s*mn|min|m)?\s*(?:(\d+(?:\.\d+)?)\s*s)?/i.exec(str);
  if (part && (part[1] || part[2] || part[3])) {
    const hh = Number(part[1] || 0);
    const mm = Number(part[2] || 0);
    const ss = Number(part[3] || 0);
    return hh * 3600 + mm * 60 + ss;
  }

  return null;
}

function simplifyRate(raw: any): string | null {
  if (raw == null || raw === "") return null;
  const value = String(raw).trim();
  if (!value) return null;
  if (!value.includes("/")) return value;
  const [a, b] = value.split("/").map((part) => Number(part));
  if (!Number.isFinite(a) || !Number.isFinite(b) || b === 0) return value;
  const rate = a / b;
  if (!Number.isFinite(rate)) return value;
  if (Math.abs(rate - Math.round(rate)) < 0.0001) return String(Math.round(rate));
  return rate.toFixed(3).replace(/0+$/, "").replace(/\.$/, "");
}

function mediaInfoAspectRatio(raw: any): string | null {
  if (raw == null) return null;
  const compact = String(raw).trim().replace(/\s+/g, "");
  if (!compact) return null;
  if (compact.includes(":")) return compact;
  const n = Number(compact);
  if (!Number.isFinite(n)) return compact;
  if (Math.abs(n - 4 / 3) < 0.02) return "4:3";
  if (Math.abs(n - 16 / 9) < 0.02) return "16:9";
  return compact;
}

function mediaInfoTrack(mediaInfoJson: any, kind: string) {
  const tracks = Array.isArray(mediaInfoJson?.media?.track) ? mediaInfoJson.media.track : [];
  return tracks.find((track: any) => String(track?.["@type"] || track?.["@Type"] || track?.type || "").toLowerCase() === kind.toLowerCase()) || null;
}

function mediaInfoTracks(mediaInfoJson: any, kind: string) {
  const tracks = Array.isArray(mediaInfoJson?.media?.track) ? mediaInfoJson.media.track : [];
  return tracks.filter((track: any) => String(track?.["@type"] || track?.["@Type"] || track?.type || "").toLowerCase() === kind.toLowerCase());
}

export function buildNormalizedMediaMetadata(mediaInfoJson: any, probeJson: any, file?: MediaFileSummary | null): NormalizedMediaMetadata | null {
  if (!mediaInfoJson && !probeJson && !file) return null;

  const format = probeJson?.format ?? {};
  const streams = Array.isArray(probeJson?.streams) ? probeJson.streams : [];

  const miGeneral = mediaInfoTrack(mediaInfoJson, "General");
  const miVideoTracks = mediaInfoTracks(mediaInfoJson, "Video");
  const miAudioTracks = mediaInfoTracks(mediaInfoJson, "Audio");
  const miOtherTracks = (Array.isArray(mediaInfoJson?.media?.track) ? mediaInfoJson.media.track : []).filter((track: any) => {
    const type = String(track?.["@type"] || track?.["@Type"] || track?.type || "").toLowerCase();
    return type && !["general", "video", "audio"].includes(type);
  });

  const ffVideoStreams = streams.filter((stream: any) => String(stream?.codec_type || "") === "video");
  const ffAudioStreams = streams.filter((stream: any) => String(stream?.codec_type || "") === "audio");
  const ffOtherStreams = streams.filter((stream: any) => !["video", "audio"].includes(String(stream?.codec_type || "")));

  const videoCount = Math.max(miVideoTracks.length, ffVideoStreams.length);
  const audioCount = Math.max(miAudioTracks.length, ffAudioStreams.length);
  const otherCount = Math.max(miOtherTracks.length, ffOtherStreams.length);

  const videoStreams = Array.from({ length: videoCount }).map((_, idx) => {
    const mi = miVideoTracks[idx] ?? null;
    const ff = ffVideoStreams[idx] ?? null;
    return {
      index: typeof ff?.index === "number" ? ff.index : idx,
      codec: mediaInfoString(mi, "CodecID", "CodecID/Hint") ?? ff?.codec_name ?? null,
      codecLongName: mediaInfoString(mi, "Format/String", "Format") ?? ff?.codec_long_name ?? ff?.codec_name ?? null,
      profile: mediaInfoString(mi, "Format_Profile", "Format profile") ?? ff?.profile ?? null,
      width: mediaInfoNumber(mi, "Width") ?? toNumber(ff?.width),
      height: mediaInfoNumber(mi, "Height") ?? toNumber(ff?.height),
      displayAspectRatio: mediaInfoAspectRatio(firstValue(mi, "DisplayAspectRatio/String", "DisplayAspectRatio_String", "DisplayAspectRatio_Original/String", "DisplayAspectRatio_Original_String", "DisplayAspectRatio")) ?? ff?.display_aspect_ratio ?? null,
      sampleAspectRatio: mediaInfoAspectRatio(firstValue(mi, "PixelAspectRatio", "PixelAspectRatio/String", "PixelAspectRatio_String")) ?? ff?.sample_aspect_ratio ?? null,
      pixelFormat: mediaInfoString(mi, "PixelFormat", "BitDepth/String", "ChromaSubsampling", "ColorSpace") ?? ff?.pix_fmt ?? null,
      frameRate: mediaInfoString(mi, "FrameRate/String", "FrameRate") ?? simplifyRate(ff?.avg_frame_rate || ff?.r_frame_rate),
      scanType: mediaInfoString(mi, "ScanType", "ScanType/String") ?? ff?.field_order ?? null,
      bitRate: mediaInfoNumber(mi, "BitRate") ?? toNumber(ff?.bit_rate),
      durationSeconds: mediaInfoDurationSeconds(mi) ?? toNumber(ff?.duration) ?? toNumber(format?.duration),
      colorSpace: mediaInfoString(mi, "ColorSpace") ?? ff?.color_space ?? null,
      colorTransfer: mediaInfoString(mi, "Transfer_Characteristics", "colour_transfer", "transfer_characteristics") ?? ff?.color_transfer ?? null,
      colorPrimaries: mediaInfoString(mi, "colour_primaries", "MasteringDisplay_ColorPrimaries", "ColorPrimaries") ?? ff?.color_primaries ?? null,
      language: mediaInfoString(mi, "Language", "Language/String3", "Language_String3") ?? ff?.tags?.language ?? null,
      tags: ff?.tags ?? null,
    };
  });

  const audioStreams = Array.from({ length: audioCount }).map((_, idx) => {
    const mi = miAudioTracks[idx] ?? null;
    const ff = ffAudioStreams[idx] ?? null;
    return {
      index: typeof ff?.index === "number" ? ff.index : idx,
      codec: mediaInfoString(mi, "CodecID", "CodecID/Hint") ?? ff?.codec_name ?? null,
      codecLongName: mediaInfoString(mi, "Format/String", "Format") ?? ff?.codec_long_name ?? ff?.codec_name ?? null,
      profile: mediaInfoString(mi, "Format_Profile", "Format profile") ?? ff?.profile ?? null,
      channels: mediaInfoNumber(mi, "Channel(s)", "Channels") ?? toNumber(ff?.channels),
      channelLayout: mediaInfoString(mi, "ChannelLayout", "ChannelLayout/String") ?? ff?.channel_layout ?? null,
      sampleRate: mediaInfoNumber(mi, "SamplingRate") ?? toNumber(ff?.sample_rate),
      bitRate: mediaInfoNumber(mi, "BitRate") ?? toNumber(ff?.bit_rate),
      durationSeconds: mediaInfoDurationSeconds(mi) ?? toNumber(ff?.duration) ?? toNumber(format?.duration),
      language: mediaInfoString(mi, "Language", "Language/String3", "Language_String3") ?? ff?.tags?.language ?? null,
      tags: ff?.tags ?? null,
    };
  });

  const otherStreams = Array.from({ length: otherCount }).map((_, idx) => {
    const mi = miOtherTracks[idx] ?? null;
    const ff = ffOtherStreams[idx] ?? null;
    return {
      index: typeof ff?.index === "number" ? ff.index : idx,
      type: mediaInfoString(mi, "@type", "@Type", "type") ?? ff?.codec_type ?? null,
      codec: mediaInfoString(mi, "CodecID", "CodecID/Hint") ?? ff?.codec_name ?? null,
      codecLongName: mediaInfoString(mi, "Format/String", "Format") ?? ff?.codec_long_name ?? ff?.codec_name ?? null,
      tags: ff?.tags ?? null,
    };
  });

  const resolvedFilename = mediaInfoString(miGeneral, "CompleteName", "FileNameExtension", "FileName")
    ?? (String(file?.filename || "").trim() || null)
    ?? (format?.filename || null);

  return {
    format: {
      filename: resolvedFilename,
      container: mediaInfoString(miGeneral, "Format", "InternetMediaType") ?? format?.format_name ?? null,
      containerLongName: mediaInfoString(miGeneral, "Format/String", "Format") ?? format?.format_long_name ?? format?.format_name ?? null,
      mimeType: String(file?.mimeType || "").trim() || mediaInfoString(miGeneral, "InternetMediaType") || null,
      durationSeconds: mediaInfoDurationSeconds(miGeneral) ?? toNumber(format?.duration),
      sizeBytes: mediaInfoNumber(miGeneral, "FileSize", "StreamSize") ?? toNumber(format?.size) ?? jsonSafeScalar(file?.sizeBytes),
      bitRate: mediaInfoNumber(miGeneral, "OverallBitRate", "BitRate") ?? toNumber(format?.bit_rate),
      startTimeSeconds: toNumber(format?.start_time),
      streamCount: mediaInfoNumber(miGeneral, "StreamCount") ?? toNumber(format?.nb_streams) ?? streams.length,
      probeScore: toNumber(format?.probe_score),
      tags: format?.tags ?? null,
    },
    videoStreams,
    audioStreams,
    otherStreams,
    toolUsed: mediaInfoJson ? "mediainfo" : (probeJson ? "ffprobe" : "unknown"),
  };
}
