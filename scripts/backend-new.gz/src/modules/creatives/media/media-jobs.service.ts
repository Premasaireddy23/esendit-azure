import { Injectable } from "@nestjs/common";
import { MediaJobStatus, MediaJobType } from "@prisma/client";
import { PrismaService } from "../../../common/prisma/prisma.service";
import { ServiceBusService } from "../../../common/queue/service-bus.service";
import { QUEUES } from "../../../common/queue/queue.constants";

@Injectable()
export class MediaJobsService {
  constructor(private readonly prisma: PrismaService, private readonly bus: ServiceBusService) {}

  async enqueue(accountId: string, projectId: string, creativeId: string, type: MediaJobType, force = false) {
    if (!force) {
      const existing = await this.prisma.mediaJob.findFirst({
        where: {
          creativeId,
          type,
          status: { in: [MediaJobStatus.PENDING, MediaJobStatus.RUNNING] },
        },
        select: { id: true, status: true, type: true, accountId: true, projectId: true, creativeId: true },
      });
      if (existing) {
        await this.bus.sendJson(QUEUES.media(), { jobId: existing.id, accountId: existing.accountId, projectId: existing.projectId, creativeId: existing.creativeId, jobType: existing.type }, { messageId: existing.id }).catch(() => undefined);
        return existing;
      }
    }

    const created = await this.prisma.mediaJob.create({
      data: { accountId, projectId, creativeId, type, status: MediaJobStatus.PENDING },
      select: { id: true, status: true, type: true, accountId: true, projectId: true, creativeId: true },
    });

    // Wake up worker (scale-to-zero)
    await this.bus.sendJson(QUEUES.media(), { jobId: created.id, accountId: created.accountId, projectId: created.projectId, creativeId: created.creativeId, jobType: created.type }, { messageId: created.id }).catch(() => undefined);
    return created;
  }

  async listForCreative(creativeId: string) {
    return this.prisma.mediaJob.findMany({
      where: { creativeId },
      orderBy: { createdAt: "desc" },
      take: 20,
      select: {
        id: true,
        type: true,
        status: true,
        attempts: true,
        error: true,
        createdAt: true,
        startedAt: true,
        endedAt: true,
      },
    });
  }
}
