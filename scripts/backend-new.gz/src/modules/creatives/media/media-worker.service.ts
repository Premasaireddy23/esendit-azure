import { Injectable, Logger, OnModuleInit } from "@nestjs/common";
import {
  CreativeAssetType,
  CreativeAssetUploadStatus,
  MediaJobStatus,
  MediaJobType,
} from "@prisma/client";
import { PrismaService } from "../../../common/prisma/prisma.service";
import { ServiceBusService } from "../../../common/queue/service-bus.service";
import { QUEUES } from "../../../common/queue/queue.constants";
import { AzureBlobService } from "../../../common/storage/azure-blob.service";
import { NotificationsService } from "../../notifications/notifications.service";
import { MediaToolsService } from "./media-tools.service";
import { evalAutoQc } from "./qc-eval";
import { buildNormalizedMediaMetadata } from "./media-metadata.util";

import * as path from "node:path";
import * as fs from "node:fs/promises";

function looksLikeLocalPath(p: string): boolean {
  if (!p) return false;
  return p.startsWith("/") || /^[A-Za-z]:\\/.test(p);
}



function canonicalFrameRate(fps?: number | null): number | undefined {
  if (typeof fps !== "number" || !Number.isFinite(fps) || fps <= 0) return undefined;
  if (Math.abs(fps - 25) <= 0.05) return 25;
  if (Math.abs(fps - 29.97) <= 0.05 || Math.abs(fps - 30000 / 1001) <= 0.05) return 30000 / 1001;
  return fps;
}

function parseDurationSeconds(raw?: string | null, fps?: number | null): number | undefined {
  if (!raw) return undefined;
  const s = String(raw).trim().toLowerCase();

  // hh:mm:ss or hh:mm:ss:ff
  const m1 = /^(\d{1,2}):(\d{2}):(\d{2})(?::(\d{2}))?$/.exec(s);
  if (m1) {
    const hh = parseInt(m1[1], 10);
    const mm = parseInt(m1[2], 10);
    const ss = parseInt(m1[3], 10);
    const ff = m1[4] ? parseInt(m1[4], 10) : 0;
    const rate = canonicalFrameRate(typeof fps === "number" ? fps : undefined);
    const total = hh * 3600 + mm * 60 + ss + ((rate && ff > 0) ? (ff / rate) : 0);
    return Number.isFinite(total) ? total : undefined;
  }

  // 30sec / 30s / 30
  const m2 = /^(\d{1,6})\s*(sec|secs|s)?$/.exec(s);
  if (m2) return parseInt(m2[1], 10);

  return undefined;
}

function envInt(k: string): number | undefined {
  const v = process.env[k];
  if (v === undefined || v === null || String(v).trim() === "") return undefined;
  const n = Number(String(v).trim());
  if (!Number.isFinite(n)) return undefined;
  return Math.trunc(n);
}

function envFloat(k: string): number | undefined {
  const v = process.env[k];
  if (v === undefined || v === null || String(v).trim() === "") return undefined;
  const n = Number(String(v).trim());
  if (!Number.isFinite(n)) return undefined;
  return n;
}

/**
 * Derive default "expected" QC values from Creative fields.
 * (Env overrides still apply inside qc-eval.ts.)
 */
function deriveQcExpectedFromCreative(meta: { format?: string | null; duration?: string | null }, detectedFrameRate?: number | null): any {
  const expected: any = {};

  const fmt = String(meta?.format || "").toUpperCase();
  const resolvedFrameRate = canonicalFrameRate(detectedFrameRate) ?? undefined;
  if (fmt.includes("SD")) {
    expected.width = envInt("QC_EXPECTED_SD_WIDTH") ?? 720;
    expected.height = envInt("QC_EXPECTED_SD_HEIGHT") ?? 576;
    expected.frameRate = resolvedFrameRate ?? (envFloat("QC_EXPECTED_SD_FRAME_RATE") ?? 25);
    expected.displayAspectRatio = String(process.env.QC_EXPECTED_SD_DAR || "4:3");
    if (process.env.QC_EXPECTED_SD_SCAN_TYPE) expected.scanType = String(process.env.QC_EXPECTED_SD_SCAN_TYPE).toUpperCase();
  } else if (fmt.includes("HD")) {
    expected.width = envInt("QC_EXPECTED_HD_WIDTH") ?? 1920;
    expected.height = envInt("QC_EXPECTED_HD_HEIGHT") ?? 1080;
    expected.frameRate = resolvedFrameRate ?? (envFloat("QC_EXPECTED_HD_FRAME_RATE") ?? 25);
    expected.displayAspectRatio = String(process.env.QC_EXPECTED_HD_DAR || "16:9");
    if (process.env.QC_EXPECTED_HD_SCAN_TYPE) expected.scanType = String(process.env.QC_EXPECTED_HD_SCAN_TYPE).toUpperCase();
  } else if (resolvedFrameRate) {
    expected.frameRate = resolvedFrameRate;
  }

  if (process.env.QC_EXPECTED_AUDIO_CHANNELS) expected.audioChannels = envInt("QC_EXPECTED_AUDIO_CHANNELS");
  expected.audioSampleRate = envInt("QC_EXPECTED_AUDIO_SAMPLE_RATE") ?? 48000;

  const lufs = envFloat("QC_EXPECTED_INTEGRATED_LUFS");
  if (typeof lufs === "number" && Number.isFinite(lufs)) {
    expected.integratedLufs = lufs;
    expected.lufsTolerance = envFloat("QC_LUFS_TOLERANCE") ?? 1.0;
  }

  expected.durationTc = meta?.duration ? String(meta.duration).trim() : undefined;
  const dur = parseDurationSeconds(meta?.duration, resolvedFrameRate);
  if (typeof dur === "number" && Number.isFinite(dur) && dur > 0) {
    expected.durationSec = dur;
    expected.durationToleranceSec = envFloat("QC_DURATION_TOLERANCE_SEC") ?? 0.5;
  }

  return expected;
}
@Injectable()
export class MediaWorkerService implements OnModuleInit {
  private readonly log = new Logger(MediaWorkerService.name);
  private running = false;
  private serial: Promise<void> = Promise.resolve();

  constructor(
    private readonly prisma: PrismaService,
    private readonly tools: MediaToolsService,
    private readonly notifications: NotificationsService,
    private readonly blobs: AzureBlobService,
    private readonly bus: ServiceBusService,
  ) {}

  onModuleInit() {
    // Avoid hanging unit tests
    if (process.env.NODE_ENV === "test") return;

    // Allow disabling worker in certain environments
    if ((process.env.MEDIA_WORKER_ENABLED || "true").toLowerCase() === "false") {
      this.log.log("MEDIA_WORKER_ENABLED=false; worker not started");
      return;
    }

    // Prefer Service Bus queue-driven execution when configured (ACA scale-to-zero)
    if (this.bus.isEnabled()) {
      this.bus
        .subscribeJson(QUEUES.media(), async (msg) => {
          const resolvedJobId = await this.resolveJobIdFromMessage(msg);
          if (!resolvedJobId) return;
          const run = this.serial.then(() => this.tick(resolvedJobId));
          // keep the chain alive even if current run fails
          this.serial = run.catch(() => undefined);
          await run;
        })
        .catch((e) => this.log.error(e));
      this.log.log(`Media worker started (service bus: ${QUEUES.media()})`);
      return;
    }

    // Fallback: DB polling (local dev)

    setInterval(() => this.tick().catch((e) => this.log.error(e)), 2000);
    this.log.log("Media worker started (polling every 2s)");
  }


  private async resolveJobIdFromMessage(msg: any): Promise<string | undefined> {
    const jobId = msg?.jobId ? String(msg.jobId) : undefined;
    if (jobId) return jobId;

    const creativeId = msg?.creativeId ? String(msg.creativeId) : undefined;
    const jobType = msg?.jobType || msg?.type;
    const type = jobType ? String(jobType) : undefined;
    if (!creativeId || !type) return undefined;

    const job = await this.prisma.mediaJob.findFirst({
      where: { creativeId, type: type as any, status: MediaJobStatus.PENDING },
      orderBy: { createdAt: "asc" },
      select: { id: true },
    });
    return job?.id ? String(job.id) : undefined;
  }

  private workDir(meta: { accountId: string; projectId: string; id: string }) {
    const root = process.env.TMPDIR || "/tmp";
    return path.join(root, "esendit", "creatives", meta.accountId, meta.projectId, meta.id);
  }

  private async ensureLocalSource(meta: { accountId: string; projectId: string; id: string }, sourcePathOrBlobKey: string) {
    if (looksLikeLocalPath(sourcePathOrBlobKey)) return { localPath: sourcePathOrBlobKey, isBlob: false };

    const wd = this.workDir(meta);
    const fileName = path.basename(sourcePathOrBlobKey);
    const localPath = path.join(wd, "source", fileName);
    await this.blobs.downloadToFile(sourcePathOrBlobKey, localPath);
    return { localPath, isBlob: true, blobKey: sourcePathOrBlobKey, workDir: wd };
  }

  private async uploadDirToBlob(localDir: string, blobPrefix: string) {
    const walk = async (dir: string) => {
      const items = await fs.readdir(dir, { withFileTypes: true }).catch(() => []);
      for (const it of items as any[]) {
        const full = path.join(dir, it.name);
        if (it.isDirectory()) await walk(full);
        else if (it.isFile()) {
          const rel = path.relative(localDir, full).replace(/\\/g, "/");
          const key = `${blobPrefix}${rel}`;
          await this.blobs.uploadFile(key, full);
        }
      }
    };
    await walk(localDir);
  }
  private async tick(jobId?: string) {
    if (this.running) return;
    this.running = true;

    let job: any = null;

    // If triggered from Service Bus, try to process the specific jobId.
    if (jobId) {
      job = await this.prisma.mediaJob.findUnique({ where: { id: jobId } });
      if (!job) return;
      if (job.status !== MediaJobStatus.PENDING) return;
    }


    try {
      if (!job) job = await this.prisma.mediaJob.findFirst({
        where: {
          status: MediaJobStatus.PENDING,
          OR: [{ runAfter: null }, { runAfter: { lte: new Date() } }],
        },
        orderBy: { createdAt: "asc" },
      });

      if (!job) return;

      // claim atomically
      const claimed = await this.prisma.mediaJob.updateMany({
        where: { id: job.id, status: MediaJobStatus.PENDING },
        data: {
          status: MediaJobStatus.RUNNING,
          startedAt: new Date(),
          attempts: { increment: 1 },
        },
      });

      if (claimed.count !== 1) return;

      if (job.type === MediaJobType.AUTO_QC) await this.runAutoQc(job.id, job.creativeId);
      if (job.type === MediaJobType.PROXY_GEN) await this.runProxy(job.id, job.creativeId);

    await this.prisma.mediaJob.update({
        where: { id: job.id },
        data: { status: MediaJobStatus.SUCCEEDED, endedAt: new Date(), error: null },
      });
    } catch (e: any) {
      const msg = String(e?.message || e || "UNKNOWN_ERROR").slice(0, 2000);
      this.log.error(msg);

      if (job?.id) {
        const attemptsNow = Number(job.attempts || 0) + 1; // claimed increments, but job is old snapshot
        const maxAttempts = Number(job.maxAttempts || 3);

        if (attemptsNow < maxAttempts) {
          const backoffMs = Math.min(60_000, 1000 * Math.pow(2, attemptsNow)); // 2s,4s,8s.. capped

    await this.prisma.mediaJob.update({
            where: { id: job.id },
            data: {
              status: MediaJobStatus.PENDING,
              runAfter: new Date(Date.now() + backoffMs),
              endedAt: new Date(),
              error: msg,
            },
          });
        } else {

    await this.prisma.mediaJob.update({
            where: { id: job.id },
            data: {
              status: MediaJobStatus.FAILED,
              endedAt: new Date(),
              error: msg,
            },
          });
        }
      }
    } finally {
      this.running = false;
    }
  }

  private async runAutoQc(jobId: string, creativeId: string) {
    const meta = await this.prisma.creative.findFirst({
      where: { id: creativeId },
      select: { id: true, accountId: true, projectId: true, format: true, duration: true, languages: true },
    });
    if (!meta) throw new Error("CREATIVE_NOT_FOUND");

    // mark IN_PROGRESS
    await this.prisma.creative.update({
      where: { id: creativeId },
      data: {
        qcStatus: "IN_PROGRESS",
        autoQcStartedAt: new Date(),
        qcFailureReasons: [],
        qcReport: null,
      } as any,
    });

    const source = await this.prisma.creativeAsset.findFirst({
      where: {
        creativeId,
        type: CreativeAssetType.SOURCE,
        uploadStatus: CreativeAssetUploadStatus.UPLOADED,
      },
    });

    if (!source) throw new Error("SOURCE_NOT_UPLOADED");

    const local = await this.ensureLocalSource(meta, source.path);
    const localSourcePath = local.localPath;

    let qcDirForUpload = "";
    let qcLogPath = "";
    const safeJson = (v: any, max = 20000) => {
      try {
        const s = JSON.stringify(v, null, 2);
        return s.length > max ? `${s.slice(0, max)}\n...truncated (${s.length} chars)` : s;
      } catch (e: any) {
        return String(e?.message || e);
      }
    };
    const appendQcLog = async (line: string) => {
      if (!qcLogPath) return;
      try {
        await fs.appendFile(qcLogPath, line.endsWith("\n") ? line : line + "\n", { encoding: "utf8" });
      } catch {
        // ignore
      }
    };

    try {
      const ffprobe = null;
      const mediainfoEnabled = (process.env.QC_MEDIAINFO_ENABLED || "true").toLowerCase() !== "false";
      const mediainfoRequired = (process.env.QC_MEDIAINFO_REQUIRED || "true").toLowerCase() === "true";
      const mediainfo = mediainfoEnabled ? await this.tools.runMediainfoQc(localSourcePath) : null;
      if (mediainfoRequired && !mediainfo) throw new Error("MEDIAINFO_NOT_AVAILABLE");
      const detectedFrameRate = (() => {
        const track = Array.isArray(mediainfo?.media?.track)
          ? mediainfo.media.track.find((t: any) => String(t?.['@type'] || t?.type || '').toLowerCase() === 'video')
          : null;
        const raw = track?.FrameRate;
        if (raw === undefined || raw === null || String(raw).trim() === '') return undefined;
        const n = Number(String(raw).trim());
        return Number.isFinite(n) ? n : undefined;
      })();


      // QC artifacts directory (for blob-backed sources we keep artifacts in the per-creative work dir)
      const qcDir = local.isBlob
        ? path.join(this.workDir(meta), "qc")
        : path.join(path.dirname(localSourcePath), "qc");

      qcDirForUpload = qcDir;
      const qcliEnabled = (process.env.QC_QCLI_ENABLED || "true").toLowerCase() !== "false";
      const qcli = qcliEnabled ? await this.tools.runQcliReport(localSourcePath, qcDir) : null;
      try {
        await fs.mkdir(qcDir, { recursive: true });
        qcLogPath = path.join(qcDir, "qc.log");
        await fs.writeFile(
          qcLogPath,
          [
            `QC job log (auto QC)`,
            `createdAt=${new Date().toISOString()}`,
            `creativeId=${creativeId}`,
            `jobId=${jobId}`,
            `accountId=${meta.accountId}`,
            `projectId=${meta.projectId}`,
            `host=${process.env.HOSTNAME || ""}`,
            `revision=${process.env.CONTAINER_APP_REVISION_NAME || process.env.CONTAINER_APP_REVISION || ""}`,
            `sourcePath=${localSourcePath}`,
            `isBlob=${String(local.isBlob)}`,
            "",
          ].join("\n"),
          { encoding: "utf8" },
        );
        await appendQcLog("mediainfo:\n" + safeJson(mediainfo));
        if (qcli?.log) await appendQcLog("\nqcli:\n" + qcli.log);
      } catch {
        // ignore log failures
      }

      // Generate QC artifacts/extra audio stats alongside SOURCE (expand-only; detailed checks now affect overall QC)
      let qcTools: any = { enabled: false, skipped: true, reason: "AUTO_QC_USES_QCLI_AND_MEDIAINFO_ONLY" };
      const artifactsEnabled = (process.env.QC_ARTIFACTS_ENABLED || "false").toLowerCase() === "true";
      if (artifactsEnabled) {
        try {
          qcTools = await this.tools.generateQcToolsReport(localSourcePath, qcDir);
        } catch (e: any) {
          qcTools = { enabled: true, error: String(e?.message || e || "QC_TOOLS_FAILED").slice(0, 2000) };
        }
      }

      // Attach extra probes for qc-eval and UI rendering
      if (qcTools && typeof qcTools === "object") {
        (qcTools as any).mediainfo = mediainfo;
        (qcTools as any).primaryProbeTool = qcli ? "qcli+mediainfo" : (mediainfo ? "mediainfo" : "unknown");
        if (qcli) (qcTools as any).qcli = { reportPath: qcli.reportPath, log: qcli.log };
        (qcTools as any).measures = (qcTools as any).measures || {};
      }

      // Persist support/debug artifacts next to QC outputs (best-effort).
      // These help in containerized environments where stdout logs can be limited.
      const qcArtifacts = qcTools && typeof qcTools === "object"
        ? (((qcTools as any).artifacts = (qcTools as any).artifacts || {}))
        : null;

      const addArtifact = (key: string, type: string, file: string) => {
        try {
          if (!qcArtifacts) return;
          qcArtifacts[key] = { type, path: file };
        } catch {
          // ignore
        }
      };

      const writeJsonFile = async (file: string, value: any, maxChars = 2_000_000) => {
        try {
          const s = safeJson(value, maxChars);
          await fs.writeFile(path.join(qcDir, file), s, { encoding: "utf8" });
        } catch {
          // ignore
        }
      };

      // Always expose qc.log (and the probes) as artifacts for the UI to open.
      addArtifact("qcLog", "text/plain", "qc.log");
      addArtifact("qcliLog", "text/plain", "qcli.log");
      addArtifact("mediainfoJson", "application/json", "mediainfo.json");
      addArtifact("qcToolsJson", "application/json", "qc_tools.json");

      if (qcli?.log) { try { await fs.writeFile(path.join(qcDir, "qcli.log"), qcli.log, { encoding: "utf8" }); } catch {} }
      if (qcli?.reportPath) {
        addArtifact("qctoolsMkv", "video/x-matroska", path.basename(qcli.reportPath));
        try {
          const previewPath = path.join(qcDir, "qctools_preview.jpg");
          await this.tools.extractStillImage(qcli.reportPath, previewPath, 1);
          addArtifact("qctoolsPreview", "image/jpeg", "qctools_preview.jpg");
        } catch {
          // best-effort preview only
        }
      }
      await writeJsonFile("mediainfo.json", mediainfo);
      await writeJsonFile("qc_tools.json", qcTools);

      const expected = deriveQcExpectedFromCreative(meta as any, detectedFrameRate);
      const res = evalAutoQc(ffprobe, { expected, sourcePath: localSourcePath, qcTools });
      const normalizedMetadata = buildNormalizedMediaMetadata(mediainfo, null, {
        filename: source?.filename ?? null,
        sizeBytes: source?.sizeBytes ?? null,
        mimeType: source?.mimeType ?? null,
      });


      addArtifact("qcEvalJson", "application/json", "qc_eval.json");
      await writeJsonFile("qc_eval.json", res);

      try {
        await appendQcLog("\nqcTools:\n" + safeJson(qcTools, 30000));
        await appendQcLog("\nqcEval:\n" + safeJson(res));
      } catch {
        // ignore
      }
      // If source came from blob, upload QC artifacts back to blob (best-effort)
      if (local.isBlob) {
        const qcContainer = process.env.QC_OUTPUT_CONTAINER || process.env.QC_ARTIFACTS_CONTAINER || "";
        const qcBasePrefix = `creatives/${meta.accountId}/${meta.projectId}/${creativeId}/qc/`;
        const qcPrefix = qcContainer ? `${qcContainer}::${qcBasePrefix}` : qcBasePrefix;
        await this.uploadDirToBlob(qcDir, qcPrefix).catch(() => undefined);
      }

      const mergedReport = {
        ...(res.report || {}),
        probeTool: qcli ? "qcli+mediainfo" : (mediainfo ? "mediainfo" : "unknown"),
        qcli: qcli ? { reportPath: qcli.reportPath || null } : null,
        qcTools,
        metadata: normalizedMetadata,
      };

      const updated = await this.prisma.creative.update({
        where: { id: creativeId },
        data: {
          qcStatus: res.status,
          qcFailureReasons: res.reasons,
          qcReport: mergedReport,
          autoQcEndedAt: new Date(),
        } as any,
        select: { id: true, accountId: true, projectId: true, qcStatus: true, qcFailureReasons: true },
      });

      await this.prisma.mediaJob.update({
        where: { id: jobId },
        data: { result: mergedReport },
      });

      // Emit Type 2 (Auto QC result) - do not fail worker if email logic fails
      await this.notifications
        .emitType2AutoQc(
          updated.accountId,
          updated.projectId,
          creativeId,
          jobId,
          String(updated.qcStatus),
          (updated.qcFailureReasons as any) ?? [],
        )
        .catch(() => undefined);
    } catch (e: any) {
      // IMPORTANT: do not leave creative stuck in IN_PROGRESS forever
      const msg = String(e?.message || e || "QC_FAILED").slice(0, 2000);

      await appendQcLog(`\nERROR:\n${msg}\n`);
      if (local.isBlob && qcDirForUpload) {
        const qcContainer = process.env.QC_OUTPUT_CONTAINER || process.env.QC_ARTIFACTS_CONTAINER || "";
        const qcBasePrefix = `creatives/${meta.accountId}/${meta.projectId}/${creativeId}/qc/`;
        const qcPrefix = qcContainer ? `${qcContainer}::${qcBasePrefix}` : qcBasePrefix;
        await this.uploadDirToBlob(qcDirForUpload, qcPrefix).catch(() => undefined);
      }

      await this.prisma.creative.update({
        where: { id: creativeId },
        data: {
          qcStatus: "FAILED",
          qcFailureReasons: ["QC_TOOL_ERROR"],
          qcReport: { error: msg, failedAt: new Date().toISOString() },
          autoQcEndedAt: new Date(),
        } as any,
      }).catch(() => undefined);
      await this.prisma.mediaJob.update({ where: { id: jobId }, data: { result: { error: msg } } }).catch(() => undefined);
      throw e;
    }
  }

  private async runProxy(jobId: string, creativeId: string) {
    const meta = await this.prisma.creative.findFirst({
      where: { id: creativeId },
      select: { id: true, accountId: true, projectId: true },
    });
    if (!meta) throw new Error("CREATIVE_NOT_FOUND");

    const source = await this.prisma.creativeAsset.findFirst({
      where: {
        creativeId,
        type: CreativeAssetType.SOURCE,
        uploadStatus: CreativeAssetUploadStatus.UPLOADED,
      },
    });

    if (!source) throw new Error("SOURCE_NOT_UPLOADED");

    const local = await this.ensureLocalSource(meta, source.path);
    const localSourcePath = local.localPath;

    const wd = this.workDir(meta);
    const base = path.parse(localSourcePath).name;
    const proxyLocalPath = path.join(wd, "proxy", `${base}.proxy.mp4`);
    await fs.mkdir(path.dirname(proxyLocalPath), { recursive: true });

    // Blob key for proxy (Phase-1)
    const proxyBlobKey = `creatives/${meta.accountId}/${meta.projectId}/${creativeId}/proxy/${base}.proxy.mp4`;

    // ensure PROXY row
    const existing = await this.prisma.creativeAsset.findFirst({
      where: { creativeId, type: CreativeAssetType.PROXY },
      select: { id: true },
    });

    const proxyRow = existing
      ? await this.prisma.creativeAsset.update({
          where: { id: existing.id },
          data: {
            filename: `${base}.proxy.mp4`,
            mimeType: "video/mp4",
            path: local.isBlob ? proxyBlobKey : proxyLocalPath,
            uploadStatus: CreativeAssetUploadStatus.UPLOADING,
            uploadStartedAt: new Date(),
            uploadEndedAt: null,
            error: null,
          } as any,
        })
      : await this.prisma.creativeAsset.create({
          data: {
            accountId: meta.accountId,
            creativeId,
            type: CreativeAssetType.PROXY,
            filename: `${base}.proxy.mp4`,
            mimeType: "video/mp4",
            path: local.isBlob ? proxyBlobKey : proxyLocalPath,
            uploadStatus: CreativeAssetUploadStatus.UPLOADING,
            uploadStartedAt: new Date(),
          } as any,
        });

    try {
      await this.tools.makeProxy(localSourcePath, proxyLocalPath);

      const stat = await fs.stat(proxyLocalPath);
      const sizeBytes = BigInt(stat.size);

      if (local.isBlob) {
        await this.blobs.uploadFile(proxyBlobKey, proxyLocalPath, "video/mp4");
      }

      await this.prisma.creativeAsset.update({
        where: { id: proxyRow.id },
        data: {
          path: local.isBlob ? proxyBlobKey : proxyLocalPath,
          uploadStatus: CreativeAssetUploadStatus.UPLOADED,
          sizeBytes: sizeBytes as any,
          bytesTotal: sizeBytes as any,
          bytesReceived: sizeBytes as any,
          uploadEndedAt: new Date(),
          error: null,
        } as any,
      });

      await this.prisma.mediaJob.update({
        where: { id: jobId },
        data: { status: MediaJobStatus.SUCCEEDED, endedAt: new Date() } as any,
      });
    } catch (e: any) {
      const msg = String(e?.message || e || "PROXY_FAILED").slice(0, 2000);
      await this.prisma.creativeAsset
        .update({
          where: { id: proxyRow.id },
          data: { uploadStatus: CreativeAssetUploadStatus.FAILED, error: msg, uploadEndedAt: new Date() } as any,
        })
        .catch(() => undefined);
      await this.prisma.mediaJob
        .update({
          where: { id: jobId },
          data: { status: MediaJobStatus.FAILED, error: msg, endedAt: new Date() } as any,
        })
        .catch(() => undefined);
      throw e;
    }
  }
}
