import { Injectable } from "@nestjs/common";
import { spawn } from "child_process";

import * as path from "node:path";
import * as fs from "node:fs/promises";

@Injectable()
export class MediaToolsService {
  async ffprobeJson(inputPath: string): Promise<any> {
    const args = ["-v", "quiet", "-print_format", "json", "-show_format", "-show_streams", inputPath];
    return this.execJson("ffprobe", args);
  }

  async mediainfoJson(inputPath: string): Promise<any> {
    const args = ["--Output=JSON", inputPath];
    return this.execJson("mediainfo", args);
  }



  async runQcliReport(inputPath: string, qcDir: string): Promise<{ reportPath: string | null; stdout: string; stderr: string; log: string } | null> {
    try {
      await fs.mkdir(qcDir, { recursive: true });
      const cwd = path.dirname(inputPath);
      const expectedReportPath = path.join(cwd, `${path.basename(inputPath)}.qctools.mkv`);
      const { stdout, stderr } = await new Promise<{ stdout: string; stderr: string }>((resolve, reject) => {
        const proc = spawn('qcli', ['-i', inputPath], { stdio: ['ignore', 'pipe', 'pipe'], cwd });
        let out = '';
        let err = '';
        proc.stdout.on('data', (d) => (out += d.toString()));
        proc.stderr.on('data', (d) => (err += d.toString()));
        proc.on('error', reject);
        proc.on('close', (code) => {
          if (code === 0) return resolve({ stdout: out, stderr: err });
          reject(new Error(`qcli failed (code=${code}): ${(err || out).slice(0, 2000)}`));
        });
      });

      let finalReportPath: string | null = null;
      try {
        await fs.access(expectedReportPath);
        const dest = path.join(qcDir, path.basename(expectedReportPath));
        if (dest !== expectedReportPath) {
          await fs.copyFile(expectedReportPath, dest).catch(async () => {
            const buf = await fs.readFile(expectedReportPath);
            await fs.writeFile(dest, buf);
          });
        }
        finalReportPath = dest;
      } catch {
        finalReportPath = null;
      }

      const log = [stdout, stderr].filter(Boolean).join("\n").trim();
      return { reportPath: finalReportPath, stdout, stderr, log };
    } catch {
      return null;
    }
  }
  async extractStillImage(inputPath: string, outputPath: string, atSeconds = 1): Promise<void> {
    await fs.mkdir(path.dirname(outputPath), { recursive: true });
    const args = [
      "-y",
      "-ss", String(Math.max(0, atSeconds)),
      "-i", inputPath,
      "-frames:v", "1",
      "-q:v", "2",
      outputPath,
    ];
    await this.exec("ffmpeg", args);
  }

  /**
   * Accurate frame counting (can be slow). Returns nb_read_frames, or null if not available.
   */
  async ffprobeCountFrames(inputPath: string): Promise<number | null> {
    const args = [
      "-v", "error",
      "-count_frames",
      "-select_streams", "v:0",
      "-show_entries", "stream=nb_read_frames",
      "-of", "json",
      inputPath,
    ];
    try {
      const j = await this.execJson("ffprobe", args);
      const n = j?.streams?.[0]?.nb_read_frames;
      const v = n == null ? null : Number(String(n).trim());
      return v != null && Number.isFinite(v) ? v : null;
    } catch {
      return null;
    }
  }

  /**
   * MediaInfo probe (JSON). If mediainfo isn't installed, returns null (unless required by env).
   */
  async runMediainfoQc(inputPath: string): Promise<any | null> {
    try {
      return await this.mediainfoJson(inputPath);
    } catch {
      return null;
    }
  }


  // QC helper used by Auto-QC worker. Returns ffprobe JSON.
  async runFFprobeQc(inputPath: string): Promise<any> {
    return this.ffprobeJson(inputPath);
  }
  async makeProxy(inputPath: string, outputPath: string): Promise<void> {
    // Browser-safe proxy MP4 (H.264 + AAC), maximum compatibility for HTML5 <video>.
    // - Forces yuv420p (many browsers can't decode 10-bit / 4:2:2)
    // - Moves moov atom to the front for fast start
    // - Makes audio optional (0:a:0?)
    const args = [
      "-y",
      "-i", inputPath,

      "-map", "0:v:0",
      "-map", "0:a:0?",

      "-vf", "scale='min(1280,iw)':-2,format=yuv420p",
      "-c:v", "libx264",
      "-profile:v", "baseline",
      "-level", "3.1",
      "-preset", "veryfast",
      "-crf", "28",
      "-movflags", "+faststart",

      "-c:a", "aac",
      "-ac", "2",
      "-ar", "48000",
      "-b:a", "96k",

      "-shortest",
      outputPath,
    ];
    await this.exec("ffmpeg", args);
  }

  /**
   * Generate QC artifacts (scopes, filmstrip, audio graphs) and audio measurements.
   * This is expand-only: failures here must not break base QC result.
   */
  async generateQcToolsReport(inputPath: string, qcDir: string, opts?: { force?: boolean }): Promise<any> {
    const enabled = opts?.force || (process.env.QC_ARTIFACTS_ENABLED || "true").toLowerCase() !== "false";
    if (!enabled) return { enabled: false, skipped: true, reason: "QC_ARTIFACTS_DISABLED" };

    await fs.mkdir(qcDir, { recursive: true });

    const artifacts: Record<string, any> = {};
    const measures: Record<string, any> = {};

    // --- Audio measurements (safe to run even if we don't have audio; we catch errors) ---
    try { measures.volumeDetect = await this.runVolumeDetect(inputPath); } catch (e: any) { measures.volumeDetectError = String(e?.message || e); }
    try { measures.loudness = await this.runEbur128(inputPath); } catch (e: any) { measures.loudnessError = String(e?.message || e); }
    try { measures.audioStats = await this.runAstats(inputPath); } catch (e: any) { measures.audioStatsError = String(e?.message || e); }

    // --- Broadcast range pixels (signal stats) ---
    try { measures.broadcastRange = await this.runSignalStats(inputPath); } catch (e: any) { measures.broadcastRangeError = String(e?.message || e); }

    // --- Visual scopes (videos) ---
    // keep short to avoid huge CPU/IO. 30s is enough for QC inspection.
    const maxSeconds = Number(process.env.QC_ARTIFACTS_MAX_SECONDS || 30);
    const w = Number(process.env.QC_ARTIFACTS_WIDTH || 640);
    const h = Number(process.env.QC_ARTIFACTS_HEIGHT || 480);

    const scopeJobs: Array<[string, string]> = [
  // Keep filter options minimal for broad FFmpeg compatibility; we scale to desired output size.
  ["waveform.mp4", `waveform,scale=${w}:${h}`],
  ["vectorscope.mp4", `vectorscope,scale=${w}:${h}`],
  ["oscilloscope.mp4", `oscilloscope,scale=${w}:${h}`],
  ["ciescope.mp4", `ciescope,scale=${w}:${h}`],
  ["pixscope.mp4", `pixscope,scale=${w}:${h}`],
];


    for (const [filename, vf] of scopeJobs) {
      const out = path.join(qcDir, filename);
      try {
        await this.makeScopeVideo(inputPath, out, vf, maxSeconds);
        artifacts[filename.replace(/\.mp4$/i, "")] = { type: "video/mp4", path: filename };
      } catch (e: any) {
        artifacts[filename.replace(/\.mp4$/i, "") + "Error"] = String(e?.message || e);
      }
    }

    // --- Audio waveform graph (video) ---
    try {
      const out = path.join(qcDir, "audio_graph.mp4");
      await this.makeAudioGraphVideo(inputPath, out, maxSeconds, w, 200);
      artifacts.audioGraph = { type: "video/mp4", path: "audio_graph.mp4" };
    } catch (e: any) {
      artifacts.audioGraphError = String(e?.message || e);
    }

    // --- Filmstrip (JPEG frames) ---
    try {
      const filmDir = path.join(qcDir, "filmstrip");
      await fs.mkdir(filmDir, { recursive: true });
      const pattern = path.join(filmDir, "frame_%03d.jpg");
      await this.extractFilmstrip(inputPath, pattern);
      // list a few frames
      const files = (await fs.readdir(filmDir)).filter((f) => f.toLowerCase().endsWith(".jpg")).sort();
      artifacts.filmstrip = {
        type: "image/jpeg",
        dir: "filmstrip",
        frames: files.slice(0, 50).map((f) => `filmstrip/${f}`),
      };
    } catch (e: any) {
      artifacts.filmstripError = String(e?.message || e);
    }

    return {
      enabled: true,
      generatedAt: new Date().toISOString(),
      artifacts,
      measures,
    };
  }

  private async makeScopeVideo(inputPath: string, outputPath: string, vf: string, maxSeconds: number) {
    const args = [
      "-y",
      "-i", inputPath,
      "-t", String(maxSeconds),
      "-vf", `${vf},format=yuv420p`,
      "-an",
      "-c:v", "libx264",
      "-preset", "veryfast",
      "-crf", "28",
      "-movflags", "+faststart",
      outputPath,
    ];
    await this.exec("ffmpeg", args);
  }

  private async makeAudioGraphVideo(inputPath: string, outputPath: string, maxSeconds: number, w: number, h: number) {
    const args = [
      "-y",
      "-i", inputPath,
      "-t", String(maxSeconds),
      "-filter_complex", `[0:a]showwaves=s=${w}x${h}:mode=line:rate=25,format=yuv420p[v]`,
      "-map", "[v]",
      "-an",
      "-c:v", "libx264",
      "-preset", "veryfast",
      "-crf", "28",
      "-movflags", "+faststart",
      outputPath,
    ];
    await this.exec("ffmpeg", args);
  }

  private async extractFilmstrip(inputPath: string, outputPattern: string) {
    // 1 frame per 5 seconds, up to 50 frames (approx 250s)
    const args = [
      "-y",
      "-i", inputPath,
      "-vf", "fps=1/5,scale=320:-1",
      "-q:v", "2",
      "-frames:v", "50",
      outputPattern,
    ];
    await this.exec("ffmpeg", args);
  }

  private async runVolumeDetect(inputPath: string) {
    const args = ["-nostats", "-i", inputPath, "-af", "volumedetect", "-vn", "-sn", "-dn", "-f", "null", "-"];
    const { stderr } = await this.execCapture("ffmpeg", args);
    const mean = stderr.match(/mean_volume:\s*([-0-9.]+)\s*dB/i)?.[1];
    const max = stderr.match(/max_volume:\s*([-0-9.]+)\s*dB/i)?.[1];
    return {
      mean_volume_db: mean ? Number(mean) : null,
      max_volume_db: max ? Number(max) : null,
      raw: stderr.slice(-2000),
    };
  }

  private async runEbur128(inputPath: string) {
    const args = ["-nostats", "-i", inputPath, "-filter_complex", "ebur128", "-f", "null", "-"];
    const { stderr } = await this.execCapture("ffmpeg", args);
    // summary lines often include: I:  -23.0 LUFS, LRA:  7.1 LU, TP: -1.0 dBFS
    const parsed = this.parseEbur128Output(stderr);
return parsed;
  }

private parseEbur128Output(stderr: string) {
  const raw = (stderr || "").slice(-4000);

  // Prefer the last "Summary:" block if present.
  const summaryIdx = (stderr || "").lastIndexOf("Summary:");
  const block = summaryIdx >= 0 ? (stderr || "").slice(summaryIdx) : (stderr || "");

  const num = (s?: string | null) => (s == null ? null : Number(s));

  const integrated =
    num(block.match(/Integrated loudness:[\s\S]*?\n\s*I:\s*([-0-9.]+)\s*LUFS/i)?.[1]) ??
    num(Array.from((stderr || "").matchAll(/\bI:\s*([-0-9.]+)\s*LUFS\b/gi)).pop()?.[1]) ??
    null;

  const threshold =
    num(block.match(/Integrated loudness:[\s\S]*?\n\s*Threshold:\s*([-0-9.]+)\s*LUFS/i)?.[1]) ??
    num(block.match(/\bThreshold:\s*([-0-9.]+)\s*LUFS\b/i)?.[1]) ??
    null;

  const lra =
    num(block.match(/Loudness range:[\s\S]*?\n\s*LRA:\s*([-0-9.]+)\s*LU/i)?.[1]) ??
    num(block.match(/\bLRA:\s*([-0-9.]+)\s*LU\b/i)?.[1]) ??
    null;

  const truePeak =
    num(block.match(/\bTrue peak:\s*([-0-9.]+)\s*dBFS\b/i)?.[1]) ??
    num(block.match(/\bTP:\s*([-0-9.]+)\s*dBFS\b/i)?.[1]) ??
    null;

  return {
    raw,
    integrated_lufs: integrated,
    threshold_lufs: threshold,
    lra_lu: lra,
    true_peak_dbfs: truePeak,
  };
}

  private async runAstats(inputPath: string) {
    const args = ["-nostats", "-i", inputPath, "-af", "astats=metadata=1:reset=0", "-f", "null", "-"];
    const { stderr } = await this.execCapture("ffmpeg", args);
    const peak = stderr.match(/Peak level dB:\s*([-0-9.]+)/i)?.[1];
    const rms = stderr.match(/RMS level dB:\s*([-0-9.]+)/i)?.[1];
    const rmsP = stderr.match(/RMS peak dB:\s*([-0-9.]+)/i)?.[1];
    const rmsT = stderr.match(/RMS trough dB:\s*([-0-9.]+)/i)?.[1];
    return {
      peak_level_db: peak ? Number(peak) : null,
      rms_level_db: rms ? Number(rms) : null,
      rms_peak_db: rmsP ? Number(rmsP) : null,
      rms_trough_db: rmsT ? Number(rmsT) : null,
      raw: stderr.slice(-2000),
    };
  }

  private async runSignalStats(inputPath: string) {
    // Capture per-frame metadata and summarize min/max ranges.
    const args = [
      "-nostats",
      "-i", inputPath,
      "-vf", "signalstats,metadata=print:file=-",
      "-f", "null",
      "-",
    ];
    const { stdout, stderr } = await this.execCapture("ffmpeg", args);
    const text = (stdout || "") + "\n" + (stderr || "");

    let ymin: number | null = null;
    let ymax: number | null = null;

    const reYmin = /lavfi\.signalstats\.YMIN=([0-9.]+)/g;
    const reYmax = /lavfi\.signalstats\.YMAX=([0-9.]+)/g;
    let m: RegExpExecArray | null;
    while ((m = reYmin.exec(text))) {
      const v = Number(m[1]);
      ymin = ymin === null ? v : Math.min(ymin, v);
    }
    while ((m = reYmax.exec(text))) {
      const v = Number(m[1]);
      ymax = ymax === null ? v : Math.max(ymax, v);
    }

    return {
      y_min: ymin,
      y_max: ymax,
      raw: text.slice(-2000),
    };
  }

  private exec(cmd: string, args: string[]): Promise<void> {
    return new Promise((resolve, reject) => {
      const p = spawn(cmd, args, { stdio: ["ignore", "pipe", "pipe"] });

      let err = "";
      p.stderr.on("data", (d) => (err += d.toString()));

      p.on("error", reject);
      p.on("close", (code) => {
        if (code === 0) return resolve();
        reject(new Error(`${cmd} failed (code=${code}): ${err.slice(0, 2000)}`));
      });
    });
  }

  private execCapture(cmd: string, args: string[]): Promise<{ stdout: string; stderr: string }> {
    return new Promise((resolve, reject) => {
      const p = spawn(cmd, args, { stdio: ["ignore", "pipe", "pipe"] });

      let out = "";
      let err = "";
      p.stdout.on("data", (d) => (out += d.toString()));
      p.stderr.on("data", (d) => (err += d.toString()));

      p.on("error", reject);
      p.on("close", (code) => {
        if (code === 0) return resolve({ stdout: out, stderr: err });
        reject(new Error(`${cmd} failed (code=${code}): ${err.slice(0, 2000)}`));
      });
    });
  }

  private execJson(cmd: string, args: string[]): Promise<any> {
    return new Promise((resolve, reject) => {
      const p = spawn(cmd, args, { stdio: ["ignore", "pipe", "pipe"] });

      let out = "";
      let err = "";
      p.stdout.on("data", (d) => (out += d.toString()));
      p.stderr.on("data", (d) => (err += d.toString()));

      p.on("error", reject);
      p.on("close", (code) => {
        if (code !== 0) return reject(new Error(`${cmd} failed (code=${code}): ${err.slice(0, 2000)}`));
        try {
          resolve(JSON.parse(out));
        } catch (e) {
          reject(new Error(`Failed to parse ${cmd} json: ${(e as Error).message}`));
        }
      });
    });
  }
}
