import { Module } from "@nestjs/common";
import { StorageModule } from "../../common/storage/storage.module";
import { CreativesService } from "./creatives.service";
import { CreativesController, ProjectsCreativesController } from "./creatives.controller";
import { MediaJobsService } from "./media/media-jobs.service";
import { MediaToolsService } from "./media/media-tools.service";
import { MediaWorkerService } from "./media/media-worker.service";

@Module({
  imports: [StorageModule],
  controllers: [ProjectsCreativesController, CreativesController],
  providers: [CreativesService, MediaJobsService, MediaToolsService, MediaWorkerService],
  exports: [CreativesService, MediaJobsService],
})
export class CreativesModule {}
