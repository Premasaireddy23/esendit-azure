import { Type } from "class-transformer";
import { IsArray, IsOptional, IsString, ValidateNested } from "class-validator";

class CreativeImportRowDto {
  @IsOptional()
  @IsString()
  id?: string;

  @IsOptional()
  @IsString()
  valid?: string;

  @IsOptional()
  @IsString()
  caption?: string;

  @IsOptional()
  @IsString()
  format?: string;

  @IsOptional()
  @IsString()
  languages?: string; // comma/space separated

  @IsOptional()
  @IsString()
  duration?: string;

  @IsOptional()
  @IsString()
  remarks?: string;

  @IsOptional()
  @IsString()
  countryId?: string;
}

export class BulkImportCreativesDto {
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => CreativeImportRowDto)
  rows!: CreativeImportRowDto[];
}
