import { IsArray, IsOptional, IsString, IsUUID, MaxLength } from "class-validator";

/**
 * Section 6B: Save line without file is supported — all fields are optional.
 */
export class CreateCreativeDto {
  @IsOptional()
  @IsString()
  @MaxLength(80)
  valid?: string | null;

  @IsOptional()
  @IsString()
  @MaxLength(200)
  caption?: string | null;

  @IsOptional()
  @IsString()
  @MaxLength(30)
  format?: string | null;

  @IsOptional()
  @IsArray()
  languages?: string[];

  @IsOptional()
  @IsString()
  @MaxLength(30)
  duration?: string | null;

  @IsOptional()
  @IsString()
  @MaxLength(500)
  remarks?: string | null;

  // Section 6A: per-country config selection (optional)
  @IsOptional()
  @IsUUID()
  countryId?: string | null;

  // Section 6B: DAM add-to-line
  @IsOptional()
  @IsUUID()
  primaryDamItemId?: string | null;

  @IsOptional()
  @IsString()
  @MaxLength(120)
  uniqueEditKey?: string | null;

  /**
   * Copy previous line fields (client convenience).
   * If set, server will clone fields from that creative (same project).
   */
  @IsOptional()
  @IsUUID()
  copyFromCreativeId?: string | null;
}
