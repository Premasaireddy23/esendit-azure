import { Type } from "class-transformer";
import { IsArray, IsOptional, IsString, IsUUID, ValidateNested } from "class-validator";

class BulkRow {
  @IsOptional()
  @IsUUID()
  id?: string;

  @IsOptional()
  @IsString()
  valid?: string | null;

  @IsOptional()
  @IsString()
  caption?: string | null;

  @IsOptional()
  @IsString()
  format?: string | null;

  @IsOptional()
  @IsArray()
  languages?: string[];

  @IsOptional()
  @IsString()
  duration?: string | null;

  @IsOptional()
  @IsString()
  remarks?: string | null;

  @IsOptional()
  @IsUUID()
  countryId?: string | null;
}

export class BulkUpsertCreativesDto {
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => BulkRow)
  rows!: BulkRow[];
}
