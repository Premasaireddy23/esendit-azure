import { IsArray, IsOptional, IsString, ValidateNested } from "class-validator";
import { Type } from "class-transformer";

export class CreativeUpsertItemDto {
  @IsOptional()
  @IsString()
  id?: string;

  // keep legacy
  @IsOptional()
  @IsString()
  name?: string;

  // P1.7 grid fields
  @IsOptional()
  @IsString()
  valid?: string;

  @IsOptional()
  @IsString()
  caption?: string;

  @IsOptional()
  @IsString()
  format?: string;

  @IsOptional()
  @IsArray()
  @IsString({ each: true })
  languages?: string[];

  @IsOptional()
  @IsString()
  duration?: string;

  @IsOptional()
  @IsString()
  remarks?: string;
}

export class BulkUpsertCreativesDto {
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => CreativeUpsertItemDto)
  items!: CreativeUpsertItemDto[];
}
