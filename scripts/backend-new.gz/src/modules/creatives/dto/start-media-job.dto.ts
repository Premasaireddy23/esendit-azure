import { IsBoolean, IsOptional } from "class-validator";

export class StartMediaJobDto {
  @IsOptional()
  @IsBoolean()
  force?: boolean;
}
