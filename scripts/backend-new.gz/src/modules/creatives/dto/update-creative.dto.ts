import { IsArray, IsOptional, IsString, IsUUID, MaxLength } from "class-validator";

export class UpdateCreativeDto {
  @IsOptional()
  @IsString()
  @MaxLength(80)
  valid?: string | null;

  @IsOptional()
  @IsString()
  @MaxLength(200)
  caption?: string | null;

  @IsOptional()
  @IsString()
  @MaxLength(30)
  format?: string | null;

  @IsOptional()
  @IsArray()
  languages?: string[];

  @IsOptional()
  @IsString()
  @MaxLength(30)
  duration?: string | null;

  @IsOptional()
  @IsString()
  @MaxLength(500)
  remarks?: string | null;

  @IsOptional()
  @IsUUID()
  countryId?: string | null;

  @IsOptional()
  @IsUUID()
  primaryDamItemId?: string | null;

  @IsOptional()
  @IsString()
  @MaxLength(120)
  uniqueEditKey?: string | null;
}
