import { CreativeAssetType } from "@prisma/client";

export const creativeGridSelect = {
  id: true,
  projectId: true,
  accountId: true,

  // legacy + P1.7
  name: true,
  title: true,

  valid: true,
  caption: true,
  format: true,
  audio: true,
  languages: true,
  duration: true,
  remarks: true,

  qcStatus: true,
  qcNotes: true,
  approvals: true,

  createdAt: true,
  updatedAt: true,

  assets: {
    where: { type: CreativeAssetType.SOURCE },
    select: {
      id: true,
      type: true,
      path: true,

      // P1.7 upload telemetry
      filename: true,
      mimeType: true,
      sizeBytes: true,
      uploadStatus: true,
      bytesTotal: true,
      bytesReceived: true,
      speedBps: true,
      uploadStartedAt: true,
      uploadEndedAt: true,
      error: true,

      createdAt: true,
      updatedAt: true,
    },
    take: 1,
  },
} as const;
