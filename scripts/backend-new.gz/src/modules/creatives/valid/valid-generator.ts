import { CreativeValidConfig } from "./valid-config";

function cleanAlnumUpper(v: string): string {
  return (v || "").toUpperCase().replace(/[^A-Z0-9]/g, "");
}

function padOrTrim(v: string, n: number): string {
  const s = cleanAlnumUpper(v);
  if (s.length === n) return s;
  if (s.length > n) return s.slice(0, n);
  return (s + "X".repeat(n)).slice(0, n);
}

function monthYearPrefix(d: Date) {
  const m = ["JAN","FEB","MAR","APR","MAY","JUN","JUL","AUG","SEP","OCT","NOV","DEC"][d.getUTCMonth()];
  const yy = String(d.getUTCFullYear()).slice(-2);
  return `${m}${yy}`;
}

function parseDurationToSecToken(raw: string | null | undefined): string {
  if (!raw) return "";
  const s = String(raw).trim().toLowerCase();

  // hh:mm:ss or hh:mm:ss:ff
  const m1 = /^(\d{1,2}):(\d{2}):(\d{2})(?::(\d{2}))?$/.exec(s);
  if (m1) {
    const hh = parseInt(m1[1], 10);
    const mm = parseInt(m1[2], 10);
    const ss = parseInt(m1[3], 10);
    const total = hh * 3600 + mm * 60 + ss;
    return total ? String(total) : "";
  }

  // 10sec / 10s / 10
  const m2 = /^(\d{1,4})\s*(sec|s)?$/.exec(s);
  if (m2) return m2[1];

  return cleanAlnumUpper(raw);
}

export function generateValidFromSpec(input: {
  advertiserGroup?: string | null;
  advertiser?: string | null;
  brand?: string | null;
  caption?: string | null;
  format?: string | null;
  languages?: string[] | null;
  duration?: string | null;
  cfg: CreativeValidConfig;
}): string {
  const partLen = input.cfg?.spec?.partLen ?? 4;
  const langLen = input.cfg?.spec?.langLen ?? 3;
  const includeFormat = input.cfg?.spec?.includeFormat ?? true;
  const includeLang = input.cfg?.spec?.includeLang ?? true;
  const includeDuration = input.cfg?.spec?.includeDuration ?? true;
  const durationMode = input.cfg?.spec?.durationMode ?? "SEC";

  const ag = padOrTrim(input.advertiserGroup || "", partLen);
  const adv = padOrTrim(input.advertiser || "", partLen);
  const br = padOrTrim(input.brand || "", partLen);
  const cap = padOrTrim(input.caption || "", partLen);

  const chunks: string[] = [ag, adv, br, cap];

  if (includeDuration) {
    const dur = durationMode === "SEC" ? parseDurationToSecToken(input.duration) : cleanAlnumUpper(input.duration || "");
    if (dur) chunks.push(dur);
  }

  if (includeLang) {
    const lang = (input.languages && input.languages[0]) ? String(input.languages[0]) : "";
    const l = padOrTrim(lang, langLen);
    if (l) chunks.push(l);
  }

  if (includeFormat) {
    const fmt = cleanAlnumUpper(input.format || "");
    if (fmt) chunks.push(fmt);
  }

  return chunks.join("");
}

export function generateValidFromFilename(filename: string, cfg: CreativeValidConfig, now = new Date()): string {
  const fcfg = cfg.filename || {};
  let base = filename || "";
  // strip path
  base = base.split(/[\\/]/).pop() || base;

  if (!fcfg.keepExtension) {
    base = base.replace(/\.[a-z0-9]{1,5}$/i, "");
  }

  let s = base;

  if (fcfg.removeUnderscores ?? true) s = s.replace(/_/g, "");
  if (fcfg.removeSpaces ?? true) s = s.replace(/\s+/g, "");
  s = s.toUpperCase();

  if (fcfg.removeSecToken ?? true) {
    s = s.replace(/\bSEC\b/g, "");
    s = s.replace(/\bSECS\b/g, "");
  }

  s = s.replace(/[^A-Z0-9]/g, "");

  if (fcfg.includeMonthYearPrefix ?? true) {
    const pref = monthYearPrefix(now);
    if (!s.startsWith(pref)) s = pref + s;
  }

  return s;
}
