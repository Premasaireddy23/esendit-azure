export type ValidGenerationStrategy = "FILENAME_DRIVEN" | "SPEC_DRIVEN";

export type ValidSpecConfig = {
  partLen?: number;      // default 4
  langLen?: number;      // default 3
  includeFormat?: boolean;   // default true
  includeLang?: boolean;     // default true
  includeDuration?: boolean; // default true
  durationMode?: "SEC" | "RAW"; // default SEC
};

export type ValidFilenameConfig = {
  includeMonthYearPrefix?: boolean; // default true
  removeUnderscores?: boolean;      // default true
  removeSpaces?: boolean;           // default true
  removeSecToken?: boolean;         // default true (removes 'SEC' word)
  keepExtension?: boolean;          // default false
};

export type CreativeValidConfig = {
  label?: string; // rename VALID column in UI (fallback to creativeCodeLabel)
  strategy?: ValidGenerationStrategy;

  // Per-country defaults
  stereoRequired?: boolean;
  defaultLanguages?: string[];

  // Strategy-specific knobs
  spec?: ValidSpecConfig;
  filename?: ValidFilenameConfig;
};

export type AccountUiConfig = {
  // existing
  creativeCodeLabel?: string;

  // Section 6A
  creativeValid?: CreativeValidConfig;
  creativeValidByCountry?: Record<string, CreativeValidConfig>;
};

export function getValidConfig(uiConfig: any, countryId?: string | null): CreativeValidConfig {
  const root: AccountUiConfig = (uiConfig || {}) as any;
  const base = (root.creativeValid || {}) as CreativeValidConfig;
  const byCountry = (countryId && root.creativeValidByCountry && root.creativeValidByCountry[countryId]) || {};
  return {
    ...base,
    ...byCountry,
    spec: { ...(base.spec || {}), ...((byCountry as any).spec || {}) },
    filename: { ...(base.filename || {}), ...((byCountry as any).filename || {}) },
  };
}

export function getValidLabel(uiConfig: any, countryId?: string | null): string {
  const cfg = getValidConfig(uiConfig, countryId);
  const label = (cfg.label || (uiConfig?.creativeCodeLabel as string) || "VALID").trim();
  return label || "VALID";
}
