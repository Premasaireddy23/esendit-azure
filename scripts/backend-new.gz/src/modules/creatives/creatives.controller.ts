import {
  Body,
  Controller,
  Delete,
  Get,
  Param,
  Patch,
  Post,
  Query,
  Req,
  Res,
  UploadedFile,
  UseGuards,
  UseInterceptors,
  NotFoundException,
} from "@nestjs/common";
import { Request, Response } from "express";
import { FileInterceptor } from "@nestjs/platform-express";
import { JwtAuthGuard } from "../../common/auth/jwt-auth.guard";
import { PermissionsGuard } from "../../common/auth/permissions.guard";
import { CurrentUser, AuthUser } from "../../common/auth/current-user.decorator";
import { RequirePermissions } from "../../common/auth/require-permissions.decorator";
import { RequireAnyPermissions } from "../../common/auth/require-any-permissions.decorator";
import { CreativesService } from "./creatives.service";
import { CreateCreativeDto } from "./dto/create-creative.dto";
import { UpdateCreativeDto } from "./dto/update-creative.dto";
import { BulkImportCreativesDto } from "./dto/bulk-import-creatives.dto";
import { SignedStreamService } from "../../common/stream/signed-stream.service";

function extractWildcardName(
  req: Request,
  id: string,
  base: "qc-artifacts" | "qc",
  suffix: "stream" | "stream-url",
  params: Record<string, any>,
) {
  // Prefer framework-bound param.
  // NOTE: depending on adapter/version, wildcard params can be an array (e.g. ["filmstrip","frame_001.jpg"]).
  // String(array) becomes "filmstrip,frame_001.jpg" which breaks blob keys.
  const raw = (params as any)?.name ?? (params as any)?.["0"] ?? "";
  let name = Array.isArray(raw) ? raw.join("/") : String(raw);

  // Fallback: parse from URL if name looks empty or accidentally includes the suffix.
  if (!name || /stream-url|\/stream\b/i.test(name)) {
    const url = String((req as any)?.originalUrl || req?.url || "");
    const needle = `/${id}/${base}/`;
    const idx = url.indexOf(needle);
    if (idx >= 0) {
      let tail = url.slice(idx + needle.length);
      const end = tail.toLowerCase().lastIndexOf(`/${suffix}`);
      if (end >= 0) tail = tail.slice(0, end);
      name = tail;
    }
  }

  // Normalize
  name = name.replace(/^\/+/, "");
  try {
    name = decodeURIComponent(name);
  } catch {
    // ignore
  }
  name = name.replace(/\/(stream-url|stream)\/?$/i, "");
  return name;
}

@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller("projects/:projectId/creatives")
export class ProjectsCreativesController {
  constructor(private readonly svc: CreativesService, private readonly signed: SignedStreamService) {}

  @Get()
  @RequireAnyPermissions("PROJECT_READ", "page:projects", "action:projects:scoped:read")
  list(@CurrentUser() user: AuthUser, @Param("projectId") projectId: string) {
    return this.svc.listByProject(user, projectId);
  }

  @Get("meta")
  @RequireAnyPermissions("PROJECT_READ", "page:projects", "action:projects:scoped:read")
  meta(
    @CurrentUser() user: AuthUser,
    @Query("countryId") countryId?: string,
  ) {
    return this.svc.getMeta(user.accountId, countryId || null);
  }

  @Post()
  @RequirePermissions("PROJECT_UPDATE")
  create(@CurrentUser() user: AuthUser, @Param("projectId") projectId: string, @Body() dto: CreateCreativeDto) {
    return this.svc.createLine(user, projectId, dto);
  }

  @Post("import")
  @RequirePermissions("PROJECT_UPDATE")
  bulkImport(@CurrentUser() user: AuthUser, @Param("projectId") projectId: string, @Body() dto: BulkImportCreativesDto) {
    return this.svc.bulkImport(user, projectId, dto);
  }
}

@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller("creatives")
export class CreativesController {
  constructor(private readonly svc: CreativesService, private readonly signed: SignedStreamService) {}

  @Patch(":id")
  @RequirePermissions("PROJECT_UPDATE")
  update(@CurrentUser() user: AuthUser, @Param("id") id: string, @Body() dto: UpdateCreativeDto) {
    return this.svc.updateLine(user, id, dto);
  }

  @Delete(":id")
  @RequirePermissions("PROJECT_UPDATE")
  deleteLine(@CurrentUser() user: AuthUser, @Param("id") id: string) {
    return this.svc.deleteLine(user, id);
  }

  
  @Post(":id/upload-source/init")
  @RequireAnyPermissions("PROJECT_UPDATE", "action:projects:creatives:upload:scoped", "page:projects")
  initUploadSource(@CurrentUser() user: AuthUser, @Param("id") id: string, @Body() dto: any) {
    return this.svc.initUploadSource(user, id, dto);
  }

  @Post(":id/upload-source/complete")
  @RequireAnyPermissions("PROJECT_UPDATE", "action:projects:creatives:upload:scoped", "page:projects")
  completeUploadSource(@CurrentUser() user: AuthUser, @Param("id") id: string, @Body() dto: any) {
    return this.svc.completeUploadSource(user, id, dto);
  }

  // Aliases (preferred by frontend): /creatives/:id/source/init + /complete
  @Post(":id/source/init")
  @RequireAnyPermissions("PROJECT_UPDATE", "action:projects:creatives:upload:scoped", "page:projects")
  initSourceAlias(@CurrentUser() user: AuthUser, @Param("id") id: string, @Body() dto: any) {
    return this.svc.initUploadSource(user, id, dto);
  }

  @Post(":id/source/complete")
  @RequireAnyPermissions("PROJECT_UPDATE", "action:projects:creatives:upload:scoped", "page:projects")
  completeSourceAlias(@CurrentUser() user: AuthUser, @Param("id") id: string, @Body() dto: any) {
    return this.svc.completeUploadSource(user, id, dto);
  }

@Post(":id/upload-source")
  @RequireAnyPermissions("PROJECT_UPDATE", "action:projects:creatives:upload:scoped", "page:projects")
  @UseInterceptors(FileInterceptor("file"))
  uploadSource(
    @CurrentUser() user: AuthUser,
    @Param("id") id: string,
    @UploadedFile() file: Express.Multer.File,
  ) {
    return this.svc.uploadSourceAsset(user, id, file);
  }

  // ---- Expand-only aliases used by QC UI (do not remove old endpoints) ----

  @Post(":id/source")
  @RequireAnyPermissions("PROJECT_UPDATE", "action:projects:creatives:upload:scoped", "page:projects")
  @UseInterceptors(FileInterceptor("file"))
  uploadSourceAlias(
    @CurrentUser() user: AuthUser,
    @Param("id") id: string,
    @UploadedFile() file: Express.Multer.File,
  ) {
    return this.svc.uploadSourceAsset(user, id, file);
  }

  @Delete(":id/source")
  @RequireAnyPermissions("PROJECT_UPDATE", "action:projects:creatives:upload:scoped", "page:projects")
  removeSource(@CurrentUser() user: AuthUser, @Param("id") id: string) {
    return this.svc.removeSourceAsset(user, id);
  }

  @Post(":id/auto-qc")
  @RequirePermissions("PROJECT_UPDATE")
  startAutoQc(
    @CurrentUser() user: AuthUser,
    @Param("id") id: string,
    @Body() body: { force?: boolean },
  ) {
    return this.svc.startAutoQc(user, id, Boolean(body?.force));
  }

  @Post(":id/qc-visuals")
  @RequirePermissions("PROJECT_UPDATE")
  generateQcVisuals(
    @CurrentUser() user: AuthUser,
    @Param("id") id: string,
  ) {
    return this.svc.generateQcVisuals(user, id);
  }

  @Post(":id/proxy")
  @RequirePermissions("PROJECT_UPDATE")
  startProxy(
    @CurrentUser() user: AuthUser,
    @Param("id") id: string,
    @Body() body: { force?: boolean },
  ) {
    return this.svc.startProxy(user, id, Boolean(body?.force));
  }

  @Get(":id/jobs")
  @RequireAnyPermissions("PROJECT_READ", "page:projects", "action:projects:scoped:read")
  listJobs(@CurrentUser() user: AuthUser, @Param("id") id: string) {
    return this.svc.listJobs(user, id);
  }

  @Get(":id/qc-report")
  @RequireAnyPermissions("PROJECT_READ", "page:projects", "action:projects:scoped:read")
  getQcReport(@CurrentUser() user: AuthUser, @Param("id") id: string) {
    return this.svc.getQcReport(user, id);
  }

  @Get(":id/assets/:type/stream")
  @RequireAnyPermissions("PROJECT_READ", "action:media:download", "page:projects", "action:projects:scoped:read", "action:library:stream:scoped")
  async streamAsset(
    @CurrentUser() user: AuthUser,
    @Param("id") id: string,
    @Param("type") type: string,
    @Res() res: Response,
  ) {
    const asset: any = await this.svc.getAssetForStream(user, id, type);
    if (asset?.redirectUrl) return res.redirect(302, asset.redirectUrl);
    res.setHeader("Content-Type", asset.mimeType || "application/octet-stream");
    res.setHeader("Content-Disposition", `inline; filename=\"${asset.filename || type.toLowerCase()}\"`);
    return res.sendFile(asset.path);
  }


  @Get(":id/assets/:type/stream-url")
  @RequireAnyPermissions("PROJECT_READ", "page:projects", "action:projects:scoped:read", "action:library:stream:scoped")
  async streamAssetUrl(
    @CurrentUser() user: AuthUser,
    @Param("id") id: string,
    @Param("type") type: string,
  ) {
    const asset: any = await this.svc.getAssetForStream(user, id, type);
    if (asset?.redirectUrl) return { url: asset.redirectUrl };
    const url = this.signed.makeUrl({
      path: asset.path,
      mimeType: asset.mimeType,
      filename: asset.filename || `${type.toLowerCase()}`,
      disposition: "inline",
      ttlSeconds: 600,
    });
    return { url };
  }

  // QC artifacts (single-file names)
  // NOTE: Keep this explicit route because some Nest/Express versions don't
  // reliably bind a named wildcard param into @Param('name').
  @Get(":id/qc-artifacts/:name/stream")
  @RequireAnyPermissions("PROJECT_READ", "page:projects", "action:projects:scoped:read", "action:library:stream:scoped")
  async streamQcArtifactSimple(
    @CurrentUser() user: AuthUser,
    @Param("id") id: string,
    @Param("name") name: string,
    @Res() res: Response,
  ) {
    const f: any = await this.svc.getQcArtifactForStream(user, id, name);
    if (f?.redirectUrl) return res.redirect(302, f.redirectUrl);
    res.setHeader("Content-Type", f.mimeType || "application/octet-stream");
    res.setHeader("Content-Disposition", `inline; filename=\"${f.filename || "qc"}\"`);
    return res.sendFile(f.path);
  }

  // Named wildcard param to allow nested paths like filmstrip/frame_001.jpg
  // path-to-regexp v6+ requires the "*name" syntax (not ":name(*)").
  @Get(":id/qc-artifacts/*name/stream")
  @RequireAnyPermissions("PROJECT_READ", "page:projects", "action:projects:scoped:read", "action:library:stream:scoped")
  async streamQcArtifact(
    @CurrentUser() user: AuthUser,
    @Param("id") id: string,
    // Depending on adapter/version, the wildcard may bind to either `name` or `0`.
    @Param() params: Record<string, string>,
    @Req() req: Request,
    @Res() res: Response,
  ) {
    const name = extractWildcardName(req, id, "qc-artifacts", "stream", params);
    const f: any = await this.svc.getQcArtifactForStream(user, id, name);
    if (f?.redirectUrl) return res.redirect(302, f.redirectUrl);
    res.setHeader("Content-Type", f.mimeType || "application/octet-stream");
    res.setHeader("Content-Disposition", `inline; filename=\"${f.filename || "qc"}\"`);
    return res.sendFile(f.path);
  }


  @Get(":id/qc-artifacts/*name/stream-url")
  @RequireAnyPermissions("PROJECT_READ", "page:projects", "action:projects:scoped:read", "action:library:stream:scoped")
  async qcArtifactUrl(
    @CurrentUser() user: AuthUser,
    @Param("id") id: string,
    @Param() params: Record<string, string>,
    @Req() req: Request,
  ) {
    const name = extractWildcardName(req, id, "qc-artifacts", "stream-url", params);
    const f: any = await this.svc.getQcArtifactForStream(user, id, name);
    if (f?.redirectUrl) return { url: f.redirectUrl };
    const url = this.signed.makeUrl({
      path: f.path,
      mimeType: f.mimeType,
      filename: f.filename || "qc",
      disposition: "inline",
      ttlSeconds: 600,
    });
    return { url };
  }

  // Backward-compatible routes for older frontends that call "/qc/..." instead of "/qc-artifacts/...".
  // These are aliases to the qc-artifacts handlers above.

  // Single-file legacy route (no slashes in name)
  @Get(":id/qc/:name/stream")
  @RequireAnyPermissions("PROJECT_READ", "page:projects", "action:projects:scoped:read", "action:library:stream:scoped")
  async streamQcLegacySimple(
    @CurrentUser() user: AuthUser,
    @Param("id") id: string,
    @Param("name") name: string,
    @Res() res: Response,
  ) {
    const f: any = await this.svc.getQcArtifactForStream(user, id, name);
    if (f?.redirectUrl) return res.redirect(302, f.redirectUrl);
    res.setHeader("Content-Type", f.mimeType || "application/octet-stream");
    res.setHeader("Content-Disposition", `inline; filename=\"${f.filename || "qc"}\"`);
    return res.sendFile(f.path);
  }

  // Named wildcard legacy route to allow nested paths like filmstrip/frame_001.jpg
  @Get(":id/qc/*name/stream")
  @RequireAnyPermissions("PROJECT_READ", "page:projects", "action:projects:scoped:read", "action:library:stream:scoped")
  async streamQcLegacy(
    @CurrentUser() user: AuthUser,
    @Param("id") id: string,
    @Param() params: Record<string, string>,
    @Req() req: Request,
    @Res() res: Response,
  ) {
    const name = extractWildcardName(req, id, "qc", "stream", params);
    const f: any = await this.svc.getQcArtifactForStream(user, id, name);
    if (f?.redirectUrl) return res.redirect(302, f.redirectUrl);
    res.setHeader("Content-Type", f.mimeType || "application/octet-stream");
    res.setHeader("Content-Disposition", `inline; filename=\"${f.filename || "qc"}\"`);
    return res.sendFile(f.path);
  }

  @Get(":id/qc/*name/stream-url")
  @RequireAnyPermissions("PROJECT_READ", "page:projects", "action:projects:scoped:read", "action:library:stream:scoped")
  async qcLegacyUrl(
    @CurrentUser() user: AuthUser,
    @Param("id") id: string,
    @Param() params: Record<string, string>,
    @Req() req: Request,
  ) {
    const name = extractWildcardName(req, id, "qc", "stream-url", params);
    const f: any = await this.svc.getQcArtifactForStream(user, id, name);
    if (f?.redirectUrl) return { url: f.redirectUrl };
    const url = this.signed.makeUrl({
      path: f.path,
      mimeType: f.mimeType,
      filename: f.filename || "qc",
      disposition: "inline",
      ttlSeconds: 600,
    });
    return { url };
  }

  
  // Catch-all fallback for qc-artifacts routes (covers nested paths like filmstrip/frame_001.jpg)
  // Some Nest/Express adapters don't reliably match or bind named wildcards in the middle of the path.
  @Get(":id/qc-artifacts/*")
  @RequireAnyPermissions("PROJECT_READ", "page:projects", "action:projects:scoped:read", "action:library:stream:scoped")
  async qcArtifactsCatchAll(
    @CurrentUser() user: AuthUser,
    @Param("id") id: string,
    @Req() req: Request,
    @Res() res: Response,
  ) {
    const url = String((req as any)?.originalUrl || req?.url || "");
    const lower = url.toLowerCase();
    const suffix: "stream-url" | "stream" | null =
      lower.endsWith("/stream-url") ? "stream-url" : lower.endsWith("/stream") ? "stream" : null;
    if (!suffix) throw new NotFoundException("Unsupported qc-artifacts action");
    const name = extractWildcardName(req, id, "qc-artifacts", suffix, {});
    const f: any = await this.svc.getQcArtifactForStream(user, id, name);
    if (suffix === "stream-url") {
      if (f?.redirectUrl) return res.json({ url: f.redirectUrl });
      const signedUrl = this.signed.makeUrl({
        path: f.path,
        mimeType: f.mimeType,
        filename: f.filename || "qc",
        disposition: "inline",
        ttlSeconds: 600,
      });
      return res.json({ url: signedUrl });
    }
    if (f?.redirectUrl) return res.redirect(302, f.redirectUrl);
    res.setHeader("Content-Type", f.mimeType || "application/octet-stream");
    res.setHeader("Content-Disposition", `inline; filename="${f.filename || "qc"}"`);
    return res.sendFile(f.path);
  }

  // Catch-all fallback for legacy /qc/... routes
  @Get(":id/qc/*")
  @RequireAnyPermissions("PROJECT_READ", "page:projects", "action:projects:scoped:read", "action:library:stream:scoped")
  async qcLegacyCatchAll(
    @CurrentUser() user: AuthUser,
    @Param("id") id: string,
    @Req() req: Request,
    @Res() res: Response,
  ) {
    const url = String((req as any)?.originalUrl || req?.url || "");
    const lower = url.toLowerCase();
    const suffix: "stream-url" | "stream" | null =
      lower.endsWith("/stream-url") ? "stream-url" : lower.endsWith("/stream") ? "stream" : null;
    if (!suffix) throw new NotFoundException("Unsupported qc action");
    const name = extractWildcardName(req, id, "qc", suffix, {});
    const f: any = await this.svc.getQcArtifactForStream(user, id, name);
    if (suffix === "stream-url") {
      if (f?.redirectUrl) return res.json({ url: f.redirectUrl });
      const signedUrl = this.signed.makeUrl({
        path: f.path,
        mimeType: f.mimeType,
        filename: f.filename || "qc",
        disposition: "inline",
        ttlSeconds: 600,
      });
      return res.json({ url: signedUrl });
    }
    if (f?.redirectUrl) return res.redirect(302, f.redirectUrl);
    res.setHeader("Content-Type", f.mimeType || "application/octet-stream");
    res.setHeader("Content-Disposition", `inline; filename="${f.filename || "qc"}"`);
    return res.sendFile(f.path);
  }


  @Get(":id/proxy")
  @RequireAnyPermissions("PROJECT_READ", "action:media:download", "page:projects", "action:projects:scoped:read", "action:library:stream:scoped")
  async downloadProxy(@CurrentUser() user: AuthUser, @Param("id") id: string, @Res() res: Response) {
    const asset: any = await this.svc.downloadProxy(user, id);
    if (asset?.redirectUrl) return res.redirect(302, asset.redirectUrl);
    const filename = asset.filename || "proxy";
    res.setHeader("Content-Type", asset.mimeType || "application/octet-stream");
    res.setHeader("Content-Disposition", `attachment; filename="${filename}"`);
    return res.sendFile(asset.path);
  }

  @Post(":id/apply-dam/:damItemId")
  @RequirePermissions("PROJECT_UPDATE")
  applyDam(@CurrentUser() user: AuthUser, @Param("id") id: string, @Param("damItemId") damItemId: string) {
    return this.svc.applyDamToLine(user, id, damItemId);
  }
}
