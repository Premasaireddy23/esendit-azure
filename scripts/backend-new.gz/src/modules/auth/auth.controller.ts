import { Body, Controller, Get, Param, Post, Put, UseGuards } from "@nestjs/common";
import { AuthService } from "./auth.service";
import { LoginDto } from "./dto/login.dto";
import { ForgotPasswordDto } from "./dto/forgot-password.dto";
import { ResetPasswordDto } from "./dto/reset-password.dto";
import { ChangePasswordDto } from "./dto/change-password.dto";
import { SetPreferenceDto } from "./dto/set-preference.dto";
import { Public } from "../../common/auth/public.decorator";
import { JwtAuthGuard } from "../../common/auth/jwt-auth.guard";
import { CurrentUser, AuthUser } from "../../common/auth/current-user.decorator";

@Controller("auth")
export class AuthController {
  constructor(private readonly auth: AuthService) {}

  @Public()
  @Post("login")
  login(@Body() dto: LoginDto) {
    return this.auth.login(dto);
  }

  @Public()
  @Post("forgot-password")
  forgotPassword(@Body() dto: ForgotPasswordDto) {
    return this.auth.forgotPassword(dto);
  }

  @Public()
  @Post("reset-password")
  resetPassword(@Body() dto: ResetPasswordDto) {
    return this.auth.resetPassword(dto);
  }

  @UseGuards(JwtAuthGuard)
  @Get("me")
  me(@CurrentUser() user: AuthUser) {
    return this.auth.me(user);
  }

  @UseGuards(JwtAuthGuard)
  @Post("change-password")
  changePassword(@CurrentUser() user: AuthUser, @Body() dto: ChangePasswordDto) {
    return this.auth.changePassword(user, dto);
  }

  // --- User preferences (per page) ---
  @UseGuards(JwtAuthGuard)
  @Get("me/preferences/:pageKey")
  getPref(@CurrentUser() user: AuthUser, @Param("pageKey") pageKey: string) {
    return this.auth.getPreference(user, pageKey);
  }

  @UseGuards(JwtAuthGuard)
  @Put("me/preferences/:pageKey")
  setPref(@CurrentUser() user: AuthUser, @Param("pageKey") pageKey: string, @Body() dto: SetPreferenceDto) {
    return this.auth.setPreference(user, pageKey, dto.payload);
  }
}
