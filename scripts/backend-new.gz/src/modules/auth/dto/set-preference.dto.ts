import { IsOptional } from "class-validator";

export class SetPreferenceDto {
  @IsOptional()
  payload?: any;
}
