import { Injectable, UnauthorizedException ,BadRequestException } from "@nestjs/common";
import { JwtService } from "@nestjs/jwt";
import { PrismaService } from "../../common/prisma/prisma.service";
import { LoginDto } from "./dto/login.dto";
import { AuthUser } from "../../common/auth/current-user.decorator";
import { inferStakeholderScopedPermissionKeys } from "../../common/auth/stakeholder-scoped-permissions";
import { canonicalizePermissionKey } from "../../common/auth/permission.normalize";
import { isStakeholderPermissionKey } from "../../common/auth/stakeholder-permission-matrix";
import * as bcrypt from "bcryptjs";
import * as crypto from "crypto";
import { ForgotPasswordDto } from "./dto/forgot-password.dto";
import { ResetPasswordDto } from "./dto/reset-password.dto";
import { ChangePasswordDto } from "./dto/change-password.dto";

function isSupportReadOnlyPermission(key: string) {
  const canonical = canonicalizePermissionKey(key);
  const lower = canonical.toLowerCase();
  if (lower.startsWith("page:")) return true;
  if (lower.includes(":read") || lower.endsWith("_read")) return true;
  if (lower.includes(":view") || lower.includes("view")) return true;
  if (lower.includes(":stream") || lower.includes("stream")) return true;
  if (lower.includes(":scoped:read") || lower.includes("read:scoped")) return true;
  if (["project_read", "action:projects:scoped:read", "action:tracking:read:scoped"].includes(lower)) return true;
  return false;
}

function normalizeEmail(raw: any) {
  return String(raw ?? "").trim().toLowerCase();
}

function emailListHas(emails: any, email: string) {
  if (!email || !Array.isArray(emails)) return false;
  return emails.some((item) => normalizeEmail(item) === email);
}

@Injectable()
export class AuthService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly jwt: JwtService,
  ) {}

  async login(dto: LoginDto) {
    // ✅ default to "default" and make it case-insensitive
    const accountCode = (dto as any).accountCode ?? "default";

    const account = await this.prisma.account.findFirst({
      where: {
        code: { equals: accountCode, mode: "insensitive" },
      },
      select: { id: true, isActive: true },
    });

    if (!account || !account.isActive) {
      throw new UnauthorizedException("Invalid credentials");
    }

    const user = await this.prisma.user.findFirst({
      where: { accountId: account.id, email: dto.email, isActive: true },
      select: { id: true, accountId: true, email: true, passwordHash: true },
    });

    if (!user) throw new UnauthorizedException("Invalid credentials");

    const ok = await bcrypt.compare(dto.password, user.passwordHash);
    if (!ok) throw new UnauthorizedException("Invalid credentials");

    await this.prisma.user.update({
      where: { id: user.id },
      data: { lastLoginAt: new Date() },
    });

    const accessToken = await this.jwt.signAsync({
      sub: user.id,
      accountId: user.accountId,
    });

    return { accessToken };
  }

  // ✅ Return permissions from DB (not from JWT payload)
  async me(user: AuthUser) {
    const dbUser = await this.prisma.user.findFirst({
      where: { id: user.id, accountId: user.accountId, isActive: true },
      select: {
        id: true,
        accountId: true,
        email: true,
        displayName: true,
        userType: true,
        account: { select: { id: true, code: true, uiConfig: true } },
        roles: {
          select: {
            role: {
              select: {
                perms: {
                  select: {
                    permission: { select: { key: true, type: true } },
                  },
                },
              },
            },
          },
        },
      },
    });

    if (!dbUser) throw new UnauthorizedException("User not found");

    const map = new Map<string, { key: string; type: string }>();
    for (const ur of dbUser.roles) {
      for (const rp of ur.role.perms) {
        map.set(rp.permission.key, rp.permission);
      }
    }

    // --- Group-based roles (GroupMember -> GroupRole -> Role) ---
    const groupIds = await this.prisma.groupMember
      .findMany({
        where: { userId: dbUser.id, group: { accountId: dbUser.accountId } },
        select: { groupId: true },
      })
      .then((rows) => rows.map((r) => r.groupId));

    if (groupIds.length) {
      const roleIds = await this.prisma.groupRole
        .findMany({
          where: { groupId: { in: groupIds } },
          select: { roleId: true },
        })
        .then((rows) => Array.from(new Set(rows.map((r) => r.roleId))));

      if (roleIds.length) {
        const roles = await this.prisma.role.findMany({
          where: { id: { in: roleIds }, accountId: dbUser.accountId },
          select: {
            perms: {
              select: {
                permission: { select: { key: true, type: true } },
              },
            },
          },
        });

        for (const r of roles) {
          for (const rp of r.perms) {
            map.set(rp.permission.key, rp.permission as any);
          }
        }
      }
    }

    const hasSpecificStakeholderPerm = Array.from(map.keys()).some((key) =>
      isStakeholderPermissionKey(canonicalizePermissionKey(key)),
    );

    const inferredStakeholderPermKeys = await inferStakeholderScopedPermissionKeys(this.prisma, dbUser);
    const routePermKeys = hasSpecificStakeholderPerm ? ["page:projects", "action:projects:scoped:read"] : [];

    for (const key of [...inferredStakeholderPermKeys, ...routePermKeys]) {
      const canonicalKey = canonicalizePermissionKey(key);
      if (!map.has(canonicalKey)) {
        map.set(canonicalKey, { key, type: key.startsWith("page:") ? "PAGE" : "ACTION" } as any);
      }
    }

    const receiverRows = await this.prisma.partnerAccount.findMany({
      where: { accountId: dbUser.accountId, status: "ACTIVE" as any, accountType: "RECEIVER" as any },
      orderBy: { name: "asc" },
      select: { id: true, name: true, emails: true, receiverCategory: true, accountType: true },
    }).catch(() => []);

    const currentEmail = normalizeEmail(dbUser.email);
    const receiverAccounts = (receiverRows || [])
      .filter((row: any) => emailListHas(row?.emails, currentEmail))
      .map((row: any) => ({
        id: row.id,
        name: row.name,
        receiverCategory: row.receiverCategory ?? null,
        accountType: row.accountType ?? "RECEIVER",
      }));

    const permissionValues = Array.from(map.values()).filter((permission: any) =>
      user?.supportView?.active ? isSupportReadOnlyPermission(permission?.key) : true,
    );

    return {
      user: {
        id: dbUser.id,
        accountId: dbUser.accountId,
        email: dbUser.email,
        displayName: (dbUser as any).displayName ?? null,
        userType: (dbUser as any).userType ?? null,
      },
      account: (dbUser as any).account ?? null,
      permissions: permissionValues, // [{key,type}, ...]
      receiverAccounts,
      supportView: user?.supportView ?? null,
    };
  }

  async changePassword(user: AuthUser, dto: ChangePasswordDto) {
    const dbUser = await this.prisma.user.findFirst({
      where: { id: user.id, accountId: user.accountId, isActive: true },
      select: { id: true, accountId: true, passwordHash: true },
    });

    if (!dbUser) throw new UnauthorizedException("User not found");

    const currentOk = await bcrypt.compare(dto.currentPassword, dbUser.passwordHash);
    if (!currentOk) throw new BadRequestException("Current password is incorrect");

    if (dto.currentPassword === dto.newPassword) {
      throw new BadRequestException("New password must be different from the current password");
    }

    const passwordHash = await bcrypt.hash(dto.newPassword, 10);

    await this.prisma.$transaction(async (tx) => {
      await tx.user.update({
        where: { id: dbUser.id },
        data: { passwordHash },
      });

      await tx.passwordResetToken.deleteMany({
        where: { accountId: dbUser.accountId, userId: dbUser.id },
      });
    });

    return { ok: true };
  }

  private hashResetToken(token: string) {
    const pepper = process.env.RESET_TOKEN_PEPPER || process.env.JWT_SECRET || "dev-pepper";
    return crypto.createHash("sha256").update(`${token}.${pepper}`).digest("hex");
  }

  async forgotPassword(dto: ForgotPasswordDto) {
    const accountCode = (dto as any).accountCode ?? "default";

    const account = await this.prisma.account.findFirst({
      where: { code: { equals: accountCode, mode: "insensitive" } },
      select: { id: true, isActive: true, code: true },
    });

    // Always return OK (avoid account/email enumeration)
    if (!account || !account.isActive) return { ok: true };

    const user = await this.prisma.user.findFirst({
      where: { accountId: account.id, email: dto.email, isActive: true },
      select: { id: true, email: true, accountId: true },
    });

    // Always return OK (avoid email enumeration)
    if (!user) return { ok: true };

    const rawToken = crypto.randomBytes(32).toString("base64url");
    const tokenHash = this.hashResetToken(rawToken);

    const ttlMinutes = Number(process.env.RESET_TOKEN_TTL_MINUTES || "30");
    const expiresAt = new Date(Date.now() + ttlMinutes * 60 * 1000);

    const frontendUrl = process.env.FRONTEND_URL || "http://localhost:5173";
    const resetUrl =
      `${frontendUrl}/reset-password?token=${encodeURIComponent(rawToken)}&accountCode=${encodeURIComponent(accountCode)}`;

    await this.prisma.$transaction(async (tx) => {
      // keep DB clean: delete old unused tokens for this user
      await tx.passwordResetToken.deleteMany({
        where: { accountId: account.id, userId: user.id, usedAt: null },
      });

      await tx.passwordResetToken.create({
        data: {
          accountId: account.id,
          userId: user.id,
          tokenHash,
          expiresAt,
          meta: { accountCode, resetUrl }, // optional
        },
      });

      // You already have EmailOutbox in schema — we queue an email here.
      await tx.emailOutbox.create({
        data: {
          accountId: account.id,
          eventType: "AUTH_PASSWORD_RESET",
          to: [user.email],
          cc: [],
          subject: "Reset your password",
          bodyText: `Use this link to reset your password:\n${resetUrl}\n\nThis link expires in ${ttlMinutes} minutes.`,
          payload: { resetUrl, ttlMinutes },
        },
      });
    });

    return { ok: true };
  }

  async resetPassword(dto: ResetPasswordDto) {
    const accountCode = (dto as any).accountCode ?? "default";
    
    const account = await this.prisma.account.findFirst({
      where: { code: { equals: accountCode, mode: "insensitive" } },
      select: { id: true, isActive: true },
    });
  
    if (!account || !account.isActive) {
      throw new BadRequestException("Invalid or expired token");
    }
  
    const tokenHash = this.hashResetToken(dto.token);
  
    const prt = await this.prisma.passwordResetToken.findFirst({
      where: {
        accountId: account.id,
        tokenHash,
        usedAt: null,
        expiresAt: { gt: new Date() },
      },
      select: { id: true, userId: true },
    });
  
    if (!prt) throw new BadRequestException("Invalid or expired token");
  
    const newHash = await bcrypt.hash(dto.newPassword, 10);
  
    await this.prisma.$transaction(async (tx) => {
      await tx.user.update({
        where: { id: prt.userId },
        data: { passwordHash: newHash },
      });
    
      await tx.passwordResetToken.update({
        where: { id: prt.id },
        data: { usedAt: new Date() },
      });
    });
  
    return { ok: true };
  }


  // --- User preferences (per page) ---
  async getPreference(user: AuthUser, pageKey: string) {
    const row = await this.prisma.userPreference.findFirst({
      where: { userId: user.id, pageKey },
      select: { pageKey: true, payload: true },
    });

    return row ? { pageKey: row.pageKey, payload: row.payload } : { pageKey, payload: null };
  }

  async setPreference(user: AuthUser, pageKey: string, payload: any) {
    const row = await this.prisma.userPreference.upsert({
      where: { userId_pageKey: { userId: user.id, pageKey } },
      update: { payload: payload ?? {} },
      create: { userId: user.id, pageKey, payload: payload ?? {} },
      select: { pageKey: true, payload: true },
    });

    return { ok: true, pageKey: row.pageKey, payload: row.payload };
  }

}
