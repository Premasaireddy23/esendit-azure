import { IsOptional, IsString, MaxLength } from "class-validator";

export class RetriggerNotificationDto {
  @IsOptional()
  @IsString()
  @MaxLength(500)
  reason?: string;
}
