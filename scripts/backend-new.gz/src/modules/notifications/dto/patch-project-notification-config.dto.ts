import { IsArray, IsBoolean, IsInt, IsOptional, Max, Min } from "class-validator";

/**
 * Full config update (base categories + enabled types + third-party flags).
 * Extra emails are updated via a separate endpoint.
 */
export class PatchProjectNotificationConfigDto {
  @IsOptional()
  @IsBoolean()
  notifyAdvertiserGroup?: boolean;

  @IsOptional()
  @IsBoolean()
  notifyAdvertiser?: boolean;

  @IsOptional()
  @IsBoolean()
  notifyBrand?: boolean;

  @IsOptional()
  @IsBoolean()
  notifyMediaAgency?: boolean;

  @IsOptional()
  @IsBoolean()
  notifyCreativeAgency?: boolean;

  @IsOptional()
  @IsBoolean()
  notifyProductionHouse?: boolean;

  @IsOptional()
  @IsBoolean()
  notifyPostHouse?: boolean;

  @IsOptional()
  @IsBoolean()
  notifyAudioAgency?: boolean;

  @IsOptional()
  @IsArray()
  @IsInt({ each: true })
  @Min(1, { each: true })
  @Max(11, { each: true })
  enabledTypes?: number[];

  /**
   * Admin/internal controls for third-party behavior.
   * Defaults were set at create-time in wizard.
   */
  @IsOptional()
  @IsBoolean()
  allowThirdPartyEditBase?: boolean;

  @IsOptional()
  @IsBoolean()
  allowThirdPartyAddExtras?: boolean;
}
