import { ArrayMaxSize, IsArray, IsEmail, IsOptional } from "class-validator";

export class PatchProjectNotificationExtrasDto {
  /**
   * Full list (internal users) OR additional emails (third-party users).
   * Server-side will enforce the rules.
   */
  @IsOptional()
  @IsArray()
  @ArrayMaxSize(250)
  @IsEmail({}, { each: true })
  extraEmails?: string[];
}
