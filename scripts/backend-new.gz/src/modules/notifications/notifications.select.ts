export const notificationAttemptSelect = {
  id: true,
  attemptNo: true,
  status: true,
  error: true,
  reason: true,
  triggeredByUserId: true,
  createdAt: true,
  updatedAt: true,
};

export const notificationEventSelect = {
  id: true,
  type: true,
  dedupeKey: true,
  origin: true,
  title: true,
  payload: true,
  to: true,
  cc: true,
  projectId: true,
  creativeId: true,
  createdAt: true,
  updatedAt: true,
  attempts: { orderBy: { attemptNo: "desc" as const }, take: 5, select: notificationAttemptSelect },
};
