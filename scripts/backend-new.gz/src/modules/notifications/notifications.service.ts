import { BadRequestException, Injectable, NotFoundException } from "@nestjs/common";
import { Prisma, DeliveryTaskStatus, ApprovalRequestStatus } from "@prisma/client";
import { PrismaService } from "../../common/prisma/prisma.service";
import { notificationEventSelect } from "./notifications.select";
import { ESENDIT_LOGO_DATA_URI } from "../../common/email/esendit-logo.data";

function uniq(emails: string[]) {
  const out: string[] = [];
  const seen = new Set<string>();
  for (const e of emails) {
    const v = String(e || "").trim().toLowerCase();
    if (!v) continue;
    if (seen.has(v)) continue;
    seen.add(v);
    out.push(v);
  }
  return out;
}

function normalizeSteps(rawSteps: any[]): any[] {
  const steps = Array.isArray(rawSteps) ? rawSteps : [];
  return steps
    .filter((s: any) => s && typeof s === "object")
    .map((s: any, idx: number) => {
      const order = Number.isFinite(Number(s.order)) ? Number(s.order) : idx + 1;
      return { ...s, order };
    })
    .sort((a: any, b: any) => (Number(a.order) || 0) - (Number(b.order) || 0));
}


function destinationClientEmailsFromConfig(raw: any): string[] {
  const cfg = raw && typeof raw === "object" ? raw : {};
  const candidates = [
    (cfg as any).clientEmails,
    (cfg as any).clientNotificationEmails,
    (cfg as any).notificationEmails,
    (cfg as any).emails,
  ];
  for (const candidate of candidates) {
    if (Array.isArray(candidate)) return uniq(candidate as string[]);
    if (typeof candidate === "string") return uniq(String(candidate).split(/[;,\n]+/g));
  }
  return [];
}
function parseApprovalsEmailsForStep(raw: any, stepOrder: number): { to: string[]; cc: string[]; teamName: string | null } {
  // Accept a few shapes:
  // - { emails: ["a@b.com"] }
  // - { to: ["a"], cc: ["b"] }
  // - { recipients: { to:[], cc:[] } }
  // - { steps: [{ order, teamName/label, approverEmails/to/emails, ccEmails/cc }] }  (Channel approvalsConfig)
  if (!raw || typeof raw !== "object") return { to: [], cc: [], teamName: null };

  const r: any = raw.recipients ?? raw;

  // steps (pick by order; fallback to first)
  if (Array.isArray(r.steps) && r.steps.length) {
    const steps = normalizeSteps(r.steps);
    const wanted = steps.find((s: any) => Number(s.order) === Number(stepOrder));
    if (!wanted) return { to: [], cc: [], teamName: null };
    const step: any = wanted;

    const to0 = Array.isArray(step.approverEmails)
      ? step.approverEmails
      : Array.isArray(step.to)
        ? step.to
        : Array.isArray(step.emails)
          ? step.emails
          : [];

    const cc0 = Array.isArray(step.ccEmails) ? step.ccEmails : Array.isArray(step.cc) ? step.cc : [];
    const teamName = String(step.teamName ?? step.label ?? "").trim() || null;

    return { to: uniq(to0), cc: uniq(cc0), teamName };
  }

  // non-step shape
  const to = Array.isArray(r.to) ? r.to : Array.isArray(r.emails) ? r.emails : [];
  const cc = Array.isArray(r.cc) ? r.cc : [];
  return { to: uniq(to), cc: uniq(cc), teamName: null };
}

type Stakeholders = { to: string[]; cc: string[] };

type ClientQcIssue = {
  code: string;
  label: string;
  expected?: string | null;
  actual?: string | null;
  note?: string | null;
};

function escHtml(v: any): string {
  return String(v ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/\"/g, "&quot;")
    .replace(/'/g, "&#39;");
}

function normUpper(v: any): string {
  return String(v ?? "").trim().toUpperCase();
}

function qcStatusKind(v: any): "PASS" | "FAIL" | "OTHER" {
  const norm = normUpper(v);
  if (!norm) return "OTHER";
  if (norm === "PASS" || norm === "PASSED" || norm === "SUCCESS" || norm === "OK" || norm.startsWith("PASS")) return "PASS";
  if (norm === "FAIL" || norm === "FAILED" || norm === "ERROR" || norm.startsWith("FAIL") || norm.includes("FAIL")) return "FAIL";
  return "OTHER";
}

function prettyValue(v: any): string | null {
  if (v === null || v === undefined) return null;
  const s = String(v).trim();
  if (!s || s === "—") return null;
  if (/^-?\d+(\.\d+)?$/.test(s)) {
    const n = Number(s);
    if (Number.isFinite(n)) {
      if (Math.abs(n - Math.round(n)) < 0.001) return String(Math.round(n));
      return String(Number(n.toFixed(2)));
    }
  }
  return s;
}

function formatQcMetricValue(name: string, value: any): string | null {
  const raw = prettyValue(value);
  if (!raw) return null;
  if (name === "Duration") return `${raw} sec`;
  if (name === "FrameRate") return `${raw} fps`;
  if (name === "SampleRate") return `${raw} Hz`;
  return raw;
}

function reasonLabel(code: string): string {
  const map: Record<string, string> = {
    DURATION_MISMATCH: "Duration does not match",
    FPS_MISMATCH: "Frame rate does not match",
    NO_AUDIO_STREAM: "Audio track is missing",
    VIDEO_WIDTH_MISMATCH: "Video width does not match",
    VIDEO_HEIGHT_MISMATCH: "Video height does not match",
    VIDEO_DAR_MISMATCH: "Aspect ratio does not match",
    VIDEO_SCAN_TYPE_MISMATCH: "Scan type does not match",
    VIDEO_CHROMA_MISMATCH: "Colour format does not match",
    VIDEO_CODEC_MISMATCH: "Video codec does not match",
    VIDEO_PROFILE_MISMATCH: "Video profile does not match",
    VIDEO_FORMAT_MISMATCH: "Video format does not match",
    VIDEO_FORMAT_SETTINGS_MISMATCH: "Video format settings do not match",
    VIDEO_BIT_RATE_MISMATCH: "Video bit rate does not match",
    VIDEO_BIT_RATE_MODE_MISMATCH: "Video bit rate mode does not match",
    VIDEO_BIT_DEPTH_MISMATCH: "Video bit depth does not match",
    VIDEO_PAR_MISMATCH: "Pixel aspect ratio does not match",
    VIDEO_STREAM_SIZE_MISMATCH: "Video stream size does not match",
    GENERAL_FORMAT_MISMATCH: "Container format does not match",
    GENERAL_BIT_RATE_MISMATCH: "Overall bit rate does not match",
    GENERAL_BIT_RATE_MODE_MISMATCH: "Overall bit rate mode does not match",
    GENERAL_SIZE_MISMATCH: "File size does not match",
    AUDIO_CODEC_MISMATCH: "Audio codec does not match",
    AUDIO_FORMAT_MISMATCH: "Audio format does not match",
    AUDIO_BIT_RATE_MISMATCH: "Audio bit rate does not match",
    AUDIO_BIT_RATE_MODE_MISMATCH: "Audio bit rate mode does not match",
    AUDIO_STREAM_SIZE_MISMATCH: "Audio stream size does not match",
    AUDIO_SAMPLE_RATE_MISMATCH: "Audio sample rate does not match",
    AUDIO_BIT_DEPTH_MISMATCH: "Audio bit depth does not match",
    AUDIO_LOUDNESS_MISMATCH: "Audio loudness does not match",
    QC_TOOL_ERROR: "We could not complete the QC review",
  };
  return map[code] ?? code.replace(/_/g, " ").toLowerCase().replace(/(^|\s)\S/g, (m) => m.toUpperCase());
}

function issueNote(code: string): string | null {
  const map: Record<string, string> = {
    DURATION_MISMATCH: "Please update the video length to match the required duration.",
    FPS_MISMATCH: "Please export the file using the required frame rate.",
    NO_AUDIO_STREAM: "Please upload a version that contains the required audio track.",
    VIDEO_FORMAT_SETTINGS_MISMATCH: "Please export the video using the required codec settings.",
    VIDEO_BIT_DEPTH_MISMATCH: "Please export the video using the required bit depth.",
    AUDIO_BIT_DEPTH_MISMATCH: "Please export the audio using the required bit depth.",
    QC_TOOL_ERROR: "Please try the upload again or contact support if the problem continues.",
  };
  return map[code] ?? null;
}

function issueFromCheck(check: any): ClientQcIssue | null {
  const group = String(check?.group ?? "").trim();
  const name = String(check?.name ?? "").trim();
  const status = normUpper(check?.status);
  if (status !== "FAIL") return null;

  const actual = formatQcMetricValue(name, check?.value);
  const expected = formatQcMetricValue(name, check?.expected);
  const message = prettyValue(check?.message);

  const codeMap: Record<string, string> = {
    "General::Duration": "DURATION_MISMATCH",
    "General::Format": "GENERAL_FORMAT_MISMATCH",
    "General::BitRate": "GENERAL_BIT_RATE_MISMATCH",
    "General::BitRateMode": "GENERAL_BIT_RATE_MODE_MISMATCH",
    "General::Size": "GENERAL_SIZE_MISMATCH",
    "Video::FrameRate": "FPS_MISMATCH",
    "Video::Width": "VIDEO_WIDTH_MISMATCH",
    "Video::Height": "VIDEO_HEIGHT_MISMATCH",
    "Video::DisplayAspectRatio": "VIDEO_DAR_MISMATCH",
    "Video::ScanType": "VIDEO_SCAN_TYPE_MISMATCH",
    "Video::ChromaSubsampling": "VIDEO_CHROMA_MISMATCH",
    "Video::CodecId": "VIDEO_CODEC_MISMATCH",
    "Video::Format_Profile": "VIDEO_PROFILE_MISMATCH",
    "Video::Format": "VIDEO_FORMAT_MISMATCH",
    "Video::Format_Settings": "VIDEO_FORMAT_SETTINGS_MISMATCH",
    "Video::BitRate": "VIDEO_BIT_RATE_MISMATCH",
    "Video::BitRateMode": "VIDEO_BIT_RATE_MODE_MISMATCH",
    "Video::BitDepth": "VIDEO_BIT_DEPTH_MISMATCH",
    "Video::PixelAspectRatio": "VIDEO_PAR_MISMATCH",
    "Video::StreamSize": "VIDEO_STREAM_SIZE_MISMATCH",
    "Audio::CodecId": "AUDIO_CODEC_MISMATCH",
    "Audio::Format": "AUDIO_FORMAT_MISMATCH",
    "Audio::BitRate": "AUDIO_BIT_RATE_MISMATCH",
    "Audio::BitRateMode": "AUDIO_BIT_RATE_MODE_MISMATCH",
    "Audio::StreamSize": "AUDIO_STREAM_SIZE_MISMATCH",
    "Audio::SampleRate": "AUDIO_SAMPLE_RATE_MISMATCH",
    "Audio::BitDepth": "AUDIO_BIT_DEPTH_MISMATCH",
    "Audio::Loudness": "AUDIO_LOUDNESS_MISMATCH",
  };

  const code = codeMap[`${group}::${name}`];
  if (!code) return null;

  return {
    code,
    label: reasonLabel(code),
    expected,
    actual,
    note: issueNote(code) ?? message,
  };
}

function deriveClientQcIssues(report: any, reasons: any[]): ClientQcIssue[] {
  const out: ClientQcIssue[] = [];
  const seen = new Set<string>();
  const checks = Array.isArray(report?.checks) ? report.checks : [];

  for (const check of checks) {
    const item = issueFromCheck(check);
    if (!item) continue;
    if (seen.has(item.code)) continue;
    seen.add(item.code);
    out.push(item);
  }

  const reasonList = Array.isArray(reasons) ? reasons : [];
  for (const raw of reasonList) {
    const code = normUpper(raw);
    if (!code || seen.has(code)) continue;
    if (code === "AUDIO_CHANNELS_MISMATCH" || code === "AUDIO_NOT_STEREO" || code === "AUDIO_DUAL_MONO_AS_STEREO") continue;
    seen.add(code);
    out.push({ code, label: reasonLabel(code), note: issueNote(code) });
  }

  
return out;
}

function formatIstDateTime(value: any): string | null {
  if (!value) return null;
  const d = value instanceof Date ? value : new Date(value);
  if (Number.isNaN(d.getTime())) return null;

  const parts = new Intl.DateTimeFormat("en-GB", {
    timeZone: "Asia/Kolkata",
    day: "2-digit",
    month: "short",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  }).formatToParts(d);

  const get = (type: string) => parts.find((p) => p.type === type)?.value ?? "";
  return `${get("day")} ${get("month")} ${get("year")} ${get("hour")}:${get("minute")}:${get("second")}`;
}

function firstNonEmpty(...values: any[]): string | null {
  for (const value of values) {
    const s = String(value ?? "").trim();
    if (s) return s;
  }
  return null;
}

function formatLanguages(value: any): string {
  const arr = Array.isArray(value) ? value.map((x) => String(x ?? "").trim()).filter(Boolean) : [];
  return arr.join(", ");
}

function toCsvCell(value: any): string {
  const s = String(value ?? "");
  if (/[",\n]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
  return s;
}

@Injectable()
export class NotificationsService {
  constructor(private readonly prisma: PrismaService) {}

  // ----------------------------
  // Email helpers
  // ----------------------------
  private formatProjectLabel(p: any): string {
    const name = String(p?.projectName ?? "").trim();
    const code = String(p?.projectCode ?? "").trim();
    if (name) return code ? `${name} (${code})` : name;
    const id = String(p?.projectId ?? "").trim();
    return id || "";
  }

  private formatCreativeLabel(p: any): string {
    const valid = String(p?.creativeValid ?? "").trim();
    if (valid) return valid;
    const id = String(p?.creativeId ?? "").trim();
    return id || "";
  }

  private formatCreativeTitle(p: any): string {
    const t = String(p?.creativeTitle ?? "").trim();
    return t || "";
  }

  private formatChannelsLabel(p: any): string {
    // Prefer payload.channels (array of {name}) then payload.channelName
    const chs = Array.isArray(p?.channels)
      ? p.channels
          .map((c: any) => String(c?.name ?? "").trim())
          .filter(Boolean)
      : [];
    if (chs.length) return chs.length <= 3 ? chs.join(", ") : `${chs.slice(0, 3).join(", ")} (+${chs.length - 3} more)`;
    const one = String(p?.channelName ?? "").trim();
    return one || "";
  }

  private formatSubject(type: number, title: string, p: any) {
    const project = this.formatProjectLabel(p);
    const creative = this.formatCreativeLabel(p);
    const creativeTitle = this.formatCreativeTitle(p);

    if (type === 2) {
      const kind = qcStatusKind(p?.qcStatus);
      const subjectBase =
        kind === "PASS"
          ? "QC passed"
          : kind === "FAIL"
            ? "QC failed – action needed"
            : "QC result";

      const subjectCreative = creativeTitle || creative;

      return project && subjectCreative
        ? `[eSendIT] ${subjectBase} — ${subjectCreative} (${project})`
        : project
          ? `[eSendIT] ${subjectBase} — ${project}`
          : subjectCreative
            ? `[eSendIT] ${subjectBase} — ${subjectCreative}`
            : `[eSendIT] ${subjectBase}`;
    }

    let subject = `[eSendIT] ${title}`;
    if (project) subject += ` — ${project}`;
    if (creative) subject += ` — ${creative}`;
    return subject;
  }

  private formatTeamNamesLabel(p: any): string {
    const teams = Array.isArray(p?.teamNames) ? p.teamNames.map((x: any) => String(x ?? "").trim()).filter(Boolean) : [];
    return teams.length ? teams.join(", ") : "";
  }

  private getEmailTone(type: number, p: any): "success" | "warning" | "danger" | "info" {
    if (type === 2) {
      const kind = qcStatusKind(p?.qcStatus);
      return kind === "PASS" ? "success" : kind === "FAIL" ? "danger" : "info";
    }
    if (type === 9) return "warning";
    if ([3, 5, 6, 7, 8, 10, 11].includes(type)) return "success";
    return "info";
  }

  private getEventCopy(type: number, title: string, p: any) {
    switch (type) {
      case 1:
        return {
          statusText: "Project created",
          intro: "Your project has been created and is ready for setup.",
          nextStep: "Upload the required creatives, select destinations, and continue with planning.",
        };
      case 3:
        return {
          statusText: "Files uploaded",
          intro: "All required files for this project have been uploaded successfully.",
          nextStep: "The project can now continue to QC, approvals, or planning based on your workflow.",
        };
      case 4:
        return {
          statusText: "Destinations selected",
          intro: "Delivery destinations and channels have been selected for this project.",
          nextStep: "Review the selections and commit the project plan when you are ready.",
        };
      case 5:
        return {
          statusText: "Project committed",
          intro: "The project plan has been committed successfully and is ready for the next stage.",
          nextStep: "Proceed with approvals or delivery when the project is ready to move forward.",
        };
      case 6:
        return {
          statusText: "File delivered",
          intro: "A file for this project has been delivered successfully.",
          nextStep: "No action is required unless you would like to review the delivery status.",
        };
      case 7:
        return {
          statusText: "Delivered to multiple destinations",
          intro: "This creative has now been delivered successfully to multiple destinations.",
          nextStep: "No further action is required unless you want to review the delivery results.",
        };
      case 8:
        return {
          statusText: "Project completed",
          intro: "All deliveries for this project have completed successfully.",
          nextStep: "The delivery workflow is complete for this project.",
        };
      case 9:
        return {
          statusText: "Approval needed",
          intro: "A creative is ready for your review and approval.",
          nextStep: "Please review the file and approve or reject it so the workflow can continue.",
        };
      case 10:
        return {
          statusText: "File approved",
          intro: "The creative has been approved successfully.",
          nextStep: "The workflow can now continue to the next stage.",
        };
      case 11:
        return {
          statusText: "File sent",
          intro: "A file for this project has been sent for delivery.",
          nextStep: "Track the delivery progress or wait for the delivery completion update.",
        };
      default:
        return {
          statusText: title,
          intro: "There is an update for your project.",
          nextStep: "Please review this update in eSendIT.",
        };
    }
  }


  private pushDetail(rows: Array<{ label: string; value: string }>, label: string, value: any) {
    const v = Array.isArray(value)
      ? value.map((x) => String(x ?? "").trim()).filter(Boolean).join(", ")
      : String(value ?? "").trim();
    if (!v || v === "-") return;
    rows.push({ label, value: v });
  }

  private displayUserLabel(value: any): string | null {
    if (!value) return null;
    if (typeof value === "string") return firstNonEmpty(value);
    return firstNonEmpty(value?.displayName, value?.name, value?.email);
  }

  private formatUploaderLabel(p: any): string | null {
    const agency = firstNonEmpty(p?.projectUploaderName);
    const team = firstNonEmpty(p?.projectUploaderTeamName);
    if (agency && team) return `${agency} / ${team}`;
    return agency || team || null;
  }

  private qcFailureSummary(p: any): string | null {
    const issues: ClientQcIssue[] = Array.isArray(p?.clientQcIssues) ? p.clientQcIssues : [];
    if (issues.length) return issues.map((item) => item.label).join("; ");
    const reasons = Array.isArray(p?.reasons) ? p.reasons.filter(Boolean).map((x: any) => reasonLabel(String(x))) : [];
    return reasons.length ? reasons.join("; ") : null;
  }

  private buildEventDetailRows(type: number, p: any): Array<{ label: string; value: string }> {
    const rows: Array<{ label: string; value: string }> = [];

    this.pushDetail(rows, "Project Name", p.projectName);
    this.pushDetail(rows, "Project Number", p.projectNumber || p.projectCode);
    this.pushDetail(rows, "Advertiser Group", p.advertiserGroupName);
    this.pushDetail(rows, "Advertiser Name", p.advertiserName);
    this.pushDetail(rows, "Brand", p.brandName);
    this.pushDetail(rows, "Product Category", p.productCategoryName);

    if (type === 1) {
      this.pushDetail(rows, "Media Agency", p.mediaAgencyName);
      this.pushDetail(rows, "Creative Agency", p.creativeAgencyName);
      this.pushDetail(rows, "Production Agency", p.productionHouseName);
      this.pushDetail(rows, "Post House", p.postHouseName);
      this.pushDetail(rows, "Audio Agency", p.audioAgencyName);
      this.pushDetail(rows, "Uploader", this.formatUploaderLabel(p));
      this.pushDetail(rows, "Remarks", p.projectRemarks);
      return rows;
    }

    if ([2, 3, 6, 7, 9, 10, 11].includes(type)) {
      this.pushDetail(rows, "VALID", p.creativeValid);
      this.pushDetail(rows, "Caption", p.creativeCaption || p.creativeTitle);
      this.pushDetail(rows, "Format", p.creativeFormat);
      this.pushDetail(rows, "Language", p.creativeLanguageText || p.creativeLanguage || p.creativeLanguages);
      this.pushDetail(rows, "Duration", p.creativeDuration);
    }

    if (type === 2) {
      const kind = qcStatusKind(p?.qcStatus);
      this.pushDetail(rows, "Status", kind === "PASS" ? "Passed" : kind === "FAIL" ? "Failed" : p?.qcStatus);
      if (kind === "FAIL") this.pushDetail(rows, "Failed Reason", this.qcFailureSummary(p));
    }

    if (type === 3) {
      this.pushDetail(rows, "Upload Time (IST)", p.latestUploadAtIst);
      if (Array.isArray(p?.creativeSummaries) && p.creativeSummaries.length === 1) {
        const one = p.creativeSummaries[0];
        this.pushDetail(rows, "VALID", one.valid);
        this.pushDetail(rows, "Caption", one.caption);
        this.pushDetail(rows, "Format", one.format);
        this.pushDetail(rows, "Language", one.language);
        this.pushDetail(rows, "Duration", one.duration);
      }
    }

    if (type === 4) {
      this.pushDetail(rows, "Selected Destinations", p.destinationNamesLabel);
      this.pushDetail(rows, "Report Rows", p.reportRowCount);
    }

    if (type === 5) {
      this.pushDetail(rows, "Project Committed Time (IST)", p.commitTimeIst);
      this.pushDetail(rows, "User That Committed the Project", p.committedByLabel);
      this.pushDetail(rows, "Plan Version", p.planVersion);
    }

    if ([6, 7, 9, 10, 11].includes(type)) {
      this.pushDetail(rows, "Project Committed Time (IST)", p.commitTimeIst);
      if (type !== 7) this.pushDetail(rows, "User That Committed the Project", p.committedByLabel);
      this.pushDetail(rows, "Destination", p.destinationName || p.destinationNamesLabel);
      this.pushDetail(
        rows,
        "Channels",
        Array.isArray(p?.channels) ? p.channels.map((x: any) => x?.name).filter(Boolean).join(", ") : p.channelName,
      );
    }

    if ([6, 9, 10].includes(type)) {
      this.pushDetail(rows, "Approval Status", p.approvalStatusLabel || p.approvalStatus);
      this.pushDetail(rows, "Approved By", p.approvalApprovedByLabel || p.approvalApprovedByList);
      this.pushDetail(rows, "Pending For", p.approvalPendingForLabel || p.approvalPendingForList);
    }

    if (type === 11) {
      this.pushDetail(rows, "Delivery Status", p.taskStatus);
    }

    if (type === 10) {
      this.pushDetail(rows, "Final Approval Time (IST)", p.approvalCompletedAtIst);
      this.pushDetail(rows, "Time From Project Committed to Final Approval", p.approvalElapsedText);
    }

    if (type === 7) {
      this.pushDetail(rows, "Destinations Delivered", p.destinations);
    }

    if (type === 8) {
      this.pushDetail(rows, "Total Deliveries", p.totalDeliveries);
    }

    return rows;
  }

  private buildDetailTableHtml(rows: Array<{ label: string; value: string }>) {
    if (!rows.length) return "";
    return `
      <table role="presentation" cellspacing="0" cellpadding="0" border="0" style="width:100%;margin-top:20px;border-collapse:collapse;">
        ${rows
          .map(
            (row) => `
              <tr>
                <td style="padding:8px 0;color:#475467;width:220px;vertical-align:top;border-bottom:1px solid #f2f4f7;">${escHtml(row.label)}</td>
                <td style="padding:8px 0;color:#101828;font-weight:600;vertical-align:top;border-bottom:1px solid #f2f4f7;">${escHtml(row.value)}</td>
              </tr>`,
          )
          .join("")}
      </table>`;
  }

  private buildHeaderHtml() {
    return `
      <div style="padding:20px 24px;border-bottom:1px solid #eaecf0;background:#ffffff;">
        <div style="display:flex;align-items:center;gap:14px;">
          <img src="cid:esendit-logo" alt="eSendIT" style="height:44px;width:auto;display:block;border:0;outline:none;text-decoration:none;" />
          <div style="font-size:22px;font-weight:700;color:#101828;">eSendIT</div>
        </div>
      </div>`;
  }

  private buildCreativeSummaryHtml(p: any) {
    const rows = Array.isArray(p?.creativeSummaries) ? p.creativeSummaries : [];
    if (!rows.length) return "";

    return `
      <div style="margin-top:24px;">
        <div style="font-size:16px;font-weight:700;color:#101828;margin-bottom:12px;">Uploaded files</div>
        <table role="presentation" cellspacing="0" cellpadding="0" border="0" style="width:100%;border-collapse:collapse;">
          <thead>
            <tr>
              <th align="left" style="padding:10px 8px;background:#f9fafb;border:1px solid #eaecf0;font-size:12px;color:#475467;">VALID</th>
              <th align="left" style="padding:10px 8px;background:#f9fafb;border:1px solid #eaecf0;font-size:12px;color:#475467;">Caption</th>
              <th align="left" style="padding:10px 8px;background:#f9fafb;border:1px solid #eaecf0;font-size:12px;color:#475467;">Format</th>
              <th align="left" style="padding:10px 8px;background:#f9fafb;border:1px solid #eaecf0;font-size:12px;color:#475467;">Language</th>
              <th align="left" style="padding:10px 8px;background:#f9fafb;border:1px solid #eaecf0;font-size:12px;color:#475467;">Duration</th>
            </tr>
          </thead>
          <tbody>
            ${rows
              .map(
                (row: any) => `
                <tr>
                  <td style="padding:10px 8px;border:1px solid #eaecf0;font-size:13px;color:#101828;">${escHtml(row.valid ?? "")}</td>
                  <td style="padding:10px 8px;border:1px solid #eaecf0;font-size:13px;color:#101828;">${escHtml(row.caption ?? "")}</td>
                  <td style="padding:10px 8px;border:1px solid #eaecf0;font-size:13px;color:#101828;">${escHtml(row.format ?? "")}</td>
                  <td style="padding:10px 8px;border:1px solid #eaecf0;font-size:13px;color:#101828;">${escHtml(row.language ?? "")}</td>
                  <td style="padding:10px 8px;border:1px solid #eaecf0;font-size:13px;color:#101828;">${escHtml(row.duration ?? "")}</td>
                </tr>`,
              )
              .join("")}
          </tbody>
        </table>
      </div>`;
  }

  private buildPlannerReportHtml(p: any) {
    const rows = Array.isArray(p?.reportRows) ? p.reportRows : [];
    if (!rows.length) return "";

    return `
      <div style="margin-top:24px;">
        <div style="font-size:16px;font-weight:700;color:#101828;margin-bottom:8px;">Destination report</div>
        <div style="font-size:13px;color:#475467;line-height:1.6;">The latest planner report is attached with this email.</div>
        <table role="presentation" cellspacing="0" cellpadding="0" border="0" style="width:100%;border-collapse:collapse;margin-top:12px;">
          <thead>
            <tr>
              <th align="left" style="padding:10px 8px;background:#f9fafb;border:1px solid #eaecf0;font-size:12px;color:#475467;">Destination</th>
              <th align="left" style="padding:10px 8px;background:#f9fafb;border:1px solid #eaecf0;font-size:12px;color:#475467;">Channel</th>
              <th align="left" style="padding:10px 8px;background:#f9fafb;border:1px solid #eaecf0;font-size:12px;color:#475467;">VALID</th>
              <th align="left" style="padding:10px 8px;background:#f9fafb;border:1px solid #eaecf0;font-size:12px;color:#475467;">SLA</th>
              <th align="left" style="padding:10px 8px;background:#f9fafb;border:1px solid #eaecf0;font-size:12px;color:#475467;">Logo Position</th>
            </tr>
          </thead>
          <tbody>
            ${rows
              .map(
                (row: any) => `
                <tr>
                  <td style="padding:10px 8px;border:1px solid #eaecf0;font-size:13px;color:#101828;">${escHtml(row.destination ?? "")}</td>
                  <td style="padding:10px 8px;border:1px solid #eaecf0;font-size:13px;color:#101828;">${escHtml(row.channel ?? "")}</td>
                  <td style="padding:10px 8px;border:1px solid #eaecf0;font-size:13px;color:#101828;">${escHtml(row.valid ?? "")}</td>
                  <td style="padding:10px 8px;border:1px solid #eaecf0;font-size:13px;color:#101828;">${escHtml(row.sla ?? "")}</td>
                  <td style="padding:10px 8px;border:1px solid #eaecf0;font-size:13px;color:#101828;">${escHtml(row.logoPosition ?? "")}</td>
                </tr>`,
              )
              .join("")}
          </tbody>
        </table>
      </div>`;
  }

  private buildEventExtraHtml(type: number, p: any) {
    if (type === 3) return this.buildCreativeSummaryHtml(p);
    if (type === 4) return this.buildPlannerReportHtml(p);
    return "";
  }

  private buildFriendlyBody(type: number, title: string, p: any) {
    const copy = this.getEventCopy(type, title, p);
    const detailRows = this.buildEventDetailRows(type, p);
    const lines: string[] = [copy.statusText, "", copy.intro, ""];

    for (const row of detailRows) lines.push(`${row.label}: ${row.value}`);

    if (type === 2) {
      const kind = qcStatusKind(p?.qcStatus);
      const issues: ClientQcIssue[] = Array.isArray(p?.clientQcIssues) ? p.clientQcIssues : [];
      if (kind === "PASS") {
        lines.push("", "Checks completed:", "- Duration", "- Frame rate", "- Audio presence");
      } else if (issues.length) {
        lines.push("", "Issues found:");
        for (const item of issues) {
          lines.push(`- ${item.label}`);
          if (item.expected) lines.push(`  Required: ${item.expected}`);
          if (item.actual) lines.push(`  Received: ${item.actual}`);
          if (item.note) lines.push(`  Note: ${item.note}`);
        }
      } else {
        const reason = this.qcFailureSummary(p);
        if (reason) lines.push("", `Issues found: ${reason}`);
      }
    }

    if (type === 3 && Array.isArray(p?.creativeSummaries) && p.creativeSummaries.length > 1) {
      lines.push("", "Uploaded files:");
      for (const row of p.creativeSummaries) {
        const parts = [row?.valid, row?.caption, row?.format, row?.language, row?.duration].map((x: any) => String(x ?? "").trim()).filter(Boolean);
        if (parts.length) lines.push(`- ${parts.join(" | ")}`);
      }
    }

    if (type === 4 && Array.isArray(p?.reportRows) && p.reportRows.length) {
      lines.push("", "Destination report preview:");
      for (const row of p.reportRows.slice(0, 10)) {
        const parts = [row?.destination, row?.channel, row?.valid, row?.sla, row?.logoPosition].map((x: any) => String(x ?? "").trim()).filter(Boolean);
        if (parts.length) lines.push(`- ${parts.join(" | ")}`);
      }
      lines.push("Planner report attachment included.");
    }

    lines.push("", "Next step:", copy.nextStep);
    return lines.join("\n");
  }

  private buildStandardEmailHtml(type: number, title: string, p: any) {
    const copy = this.getEventCopy(type, title, p);
    const tone = this.getEmailTone(type, p);
    const toneStyles = {
      success: { bannerBg: "#ecfdf3", bannerColor: "#027a48", panelBg: "#f6fef9", panelBorder: "#d1fadf" },
      warning: { bannerBg: "#fffaeb", bannerColor: "#b54708", panelBg: "#fffcf5", panelBorder: "#fedf89" },
      danger: { bannerBg: "#fef2f2", bannerColor: "#b42318", panelBg: "#fef3f2", panelBorder: "#fecdca" },
      info: { bannerBg: "#eff8ff", bannerColor: "#175cd3", panelBg: "#f5faff", panelBorder: "#b2ddff" },
    }[tone];

    const detailRows = this.buildEventDetailRows(type, p);
    const extraHtml = this.buildEventExtraHtml(type, p);

    return `<!doctype html>
<html>
  <body style="margin:0;padding:0;background:#f5f7fa;font-family:Arial,Helvetica,sans-serif;color:#101828;">
    <div style="max-width:760px;margin:0 auto;padding:24px 16px;">
      <div style="background:#ffffff;border:1px solid #eaecf0;border-radius:16px;overflow:hidden;box-shadow:0 1px 2px rgba(16,24,40,0.06);">
        ${this.buildHeaderHtml()}

        <div style="padding:24px;">
          <div style="display:inline-block;padding:10px 14px;border-radius:999px;background:${toneStyles.bannerBg};color:${toneStyles.bannerColor};font-weight:700;font-size:14px;">
            ${escHtml(copy.statusText)}
          </div>

          <div style="font-size:15px;color:#344054;line-height:1.7;margin-top:16px;">
            ${escHtml(copy.intro)}
          </div>

          ${this.buildDetailTableHtml(detailRows)}

          ${extraHtml}

          <div style="margin-top:24px;padding:16px;border-radius:12px;background:${toneStyles.panelBg};border:1px solid ${toneStyles.panelBorder};">
            <div style="font-size:16px;font-weight:700;color:#101828;margin-bottom:8px;">Next step</div>
            <div style="font-size:14px;color:#344054;line-height:1.7;">${escHtml(copy.nextStep)}</div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>`;
  }

  private buildQcEmailHtml(title: string, p: any) {
    const kind = qcStatusKind(p?.qcStatus);
    const isPass = kind === "PASS";
    const statusText = isPass ? "QC Passed" : kind === "FAIL" ? "QC Failed" : title;
    const bannerBg = isPass ? "#ecfdf3" : "#fef2f2";
    const bannerColor = isPass ? "#027a48" : "#b42318";
    const issues: ClientQcIssue[] = Array.isArray(p?.clientQcIssues) ? p.clientQcIssues : [];
    const detailRows = this.buildEventDetailRows(2, p);

    const issuesHtml = issues.length
      ? `<div style="margin-top:24px;">
           <div style="font-size:16px;font-weight:700;color:#101828;margin-bottom:12px;">Issues found</div>
           ${issues
             .map(
               (item) => `
             <div style="border:1px solid #eaecf0;border-radius:12px;padding:14px 16px;margin-bottom:12px;background:#ffffff;">
               <div style="font-size:15px;font-weight:700;color:#101828;margin-bottom:8px;">${escHtml(item.label)}</div>
               ${item.expected ? `<div style="font-size:14px;color:#344054;margin-bottom:4px;"><strong>Required:</strong> ${escHtml(item.expected)}</div>` : ""}
               ${item.actual ? `<div style="font-size:14px;color:#344054;margin-bottom:4px;"><strong>Received:</strong> ${escHtml(item.actual)}</div>` : ""}
               ${item.note ? `<div style="font-size:13px;color:#475467;margin-top:8px;">${escHtml(item.note)}</div>` : ""}
             </div>`,
             )
             .join("")}
         </div>`
      : "";

    const checksHtml = isPass
      ? `<div style="margin-top:24px;">
           <div style="font-size:16px;font-weight:700;color:#101828;margin-bottom:12px;">Checks completed</div>
           <div style="font-size:14px;color:#344054;line-height:1.8;">• Duration<br/>• Frame rate<br/>• Audio presence</div>
         </div>`
      : issuesHtml;

    const intro = isPass
      ? "Your creative has successfully passed quality control."
      : "Your creative could not pass quality control because one or more required checks did not match the delivery specification.";

    const nextStep = isPass
      ? "No action is required. Your creative is ready for the next stage."
      : "Please update the file and upload a corrected version for QC review.";

    return `<!doctype html>
<html>
  <body style="margin:0;padding:0;background:#f5f7fa;font-family:Arial,Helvetica,sans-serif;color:#101828;">
    <div style="max-width:760px;margin:0 auto;padding:24px 16px;">
      <div style="background:#ffffff;border:1px solid #eaecf0;border-radius:16px;overflow:hidden;box-shadow:0 1px 2px rgba(16,24,40,0.06);">
        ${this.buildHeaderHtml()}

        <div style="padding:24px;">
          <div style="display:inline-block;padding:10px 14px;border-radius:999px;background:${bannerBg};color:${bannerColor};font-weight:700;font-size:14px;">
            ${escHtml(statusText)}
          </div>

          <div style="font-size:15px;color:#344054;line-height:1.7;margin-top:16px;">
            ${escHtml(intro)}
          </div>

          ${this.buildDetailTableHtml(detailRows)}

          ${checksHtml}

          <div style="margin-top:24px;padding:16px;border-radius:12px;background:#f9fafb;border:1px solid #eaecf0;">
            <div style="font-size:16px;font-weight:700;color:#101828;margin-bottom:8px;">Next step</div>
            <div style="font-size:14px;color:#344054;line-height:1.7;">${escHtml(nextStep)}</div>
          </div>
        </div>
      </div>
    </div>
  </body>
</html>`;
  }

  private buildAttachmentsForEvent(type: number, p: any) {
    const attachments: Array<{ name: string; contentType: string; contentInBase64: string; contentId?: string }> = [];

    const logoBase64 = String(ESENDIT_LOGO_DATA_URI ?? "")
      .replace(/^data:image\/png;base64,/i, "")
      .trim();

    if (logoBase64) {
      attachments.push({
        name: "esendit-logo.png",
        contentType: "image/png",
        contentInBase64: logoBase64,
        contentId: "esendit-logo",
      });
    }

    if (type === 4) {
      const contentInBase64 = String(p?.reportCsvBase64 ?? "").trim();
      if (contentInBase64) {
        attachments.push({
          name: String(p?.reportAttachmentName ?? "planner-report.csv"),
          contentType: "text/csv",
          contentInBase64,
        });
      }
    }

    return attachments;
  }

  private async loadProjectContext(accountId: string, projectId: string): Promise<any | null> {
    return this.prisma.project.findFirst({
      where: { id: projectId, accountId },
      select: {
        id: true,
        name: true,
        projectNumber: true,
        projectCode: true,
        remarks: true,
        advertiserGroup: { select: { name: true } },
        advertiser: { select: { name: true } },
        brand: { select: { name: true } },
        productCategory: { select: { name: true } },
        mediaAgency: { select: { name: true } },
        creativeAgency: { select: { name: true } },
        productionHouse: { select: { name: true } },
        postHouse: { select: { name: true } },
        audioAgency: { select: { name: true } },
        uploaderAgency: { select: { name: true } },
        uploaderAgencyTeam: { select: { name: true } },
      } as any,
    });
  }

  private async loadCreativeContext(accountId: string, creativeId: string): Promise<any | null> {
    return this.prisma.creative.findFirst({
      where: { id: creativeId, accountId },
      select: {
        id: true,
        valid: true,
        caption: true,
        title: true,
        name: true,
        format: true,
        languages: true,
        duration: true,
        qcReport: true,
      } as any,
    });
  }

  private async loadCommitContext(accountId: string, projectId: string, explicitPlanVersion?: number | null): Promise<any> {
    const priorCommitNotif = await this.prisma.notificationEvent.findFirst({
      where: { accountId, projectId, type: 5 },
      orderBy: { createdAt: "desc" },
      select: { createdAt: true, payload: true } as any,
    });

    if (priorCommitNotif) {
      const np: any = priorCommitNotif.payload ?? {};
      return {
        planVersion: np.planVersion ?? explicitPlanVersion ?? null,
        commitTimeRaw: np.commitTimeRaw ?? priorCommitNotif.createdAt ?? null,
        commitTimeIst: np.commitTimeIst ?? formatIstDateTime(np.commitTimeRaw ?? priorCommitNotif.createdAt),
        committedByLabel: np.committedByLabel ?? null,
      };
    }

    const pv = await this.prisma.planVersion.findFirst({
      where: { accountId, projectId, ...(explicitPlanVersion ? { version: explicitPlanVersion } : {}) },
      orderBy: { version: "desc" },
      select: { version: true, createdAt: true } as any,
    });

    return {
      planVersion: pv?.version ?? explicitPlanVersion ?? null,
      commitTimeRaw: pv?.createdAt ?? null,
      commitTimeIst: formatIstDateTime(pv?.createdAt),
      committedByLabel: null,
    };
  }

  private async loadApprovalContext(accountId: string, projectId: string, creativeId: string): Promise<any | null> {
    const req: any = await this.prisma.approvalRequest.findFirst({
      where: { accountId, projectId, creativeId },
      orderBy: { startedAt: "desc" },
      select: {
        id: true,
        status: true,
        completedAt: true,
        steps: {
          select: {
            order: true,
            label: true,
            required: true,
            status: true,
            approverEmails: true,
            decidedByUser: { select: { displayName: true, email: true } },
          },
          orderBy: { order: "asc" },
        },
      } as any,
    });
    if (!req) return null;

    const steps = Array.isArray(req.steps) ? req.steps : [];
    const approvedBy = uniq(
      steps
        .filter((s: any) => s?.status === "APPROVED")
        .map((s: any) => this.displayUserLabel(s?.decidedByUser))
        .filter(Boolean) as string[],
    );
    const pendingFor = uniq(
      steps
        .filter((s: any) => s?.required && s?.status === "PENDING")
        .flatMap((s: any) => {
          const stepEmails = Array.isArray(s?.approverEmails) ? s.approverEmails : [];
          const label = firstNonEmpty(s?.label);
          return stepEmails.length ? stepEmails : label ? [label] : [];
        })
        .map((x: any) => String(x ?? "").trim())
        .filter(Boolean),
    );

    return {
      approvalStatus: req.status ?? null,
      approvalStatusLabel: req.status ? String(req.status).replace(/_/g, " ") : null,
      approvalApprovedByList: approvedBy.join(", "),
      approvalApprovedByLabel: approvedBy.join(", "),
      approvalPendingForList: pendingFor.join(", "),
      approvalPendingForLabel: pendingFor.join(", "),
      approvalCompletedAtRaw: req.completedAt ?? null,
      approvalCompletedAtIst: formatIstDateTime(req.completedAt),
    };
  }

  private async loadPlannerReportContext(accountId: string, projectId: string): Promise<any> {
    const rows = await this.prisma.planningEntry.findMany({
      where: { accountId, projectId, selected: true },
      include: {
        creative: { select: { valid: true, caption: true, title: true, name: true } as any },
        channel: { select: { name: true, destination: { select: { name: true } }, config: true } as any },
        sla: { select: { name: true } as any },
      },
      orderBy: [{ creativeId: "asc" }, { channelId: "asc" }],
    });

    const mapped = rows.map((r: any) => ({
      valid: firstNonEmpty(r?.creative?.valid) ?? "",
      caption: firstNonEmpty(r?.creative?.caption, r?.creative?.title, r?.creative?.name) ?? "",
      destination: firstNonEmpty(r?.channel?.destination?.name) ?? "",
      channel: firstNonEmpty(r?.channel?.name) ?? "",
      sla: firstNonEmpty(r?.sla?.name) ?? "",
      logoPosition: firstNonEmpty(r?.channel?.config?.alignment) ?? "",
    }));

    const header = ["VALID", "Caption", "Destination", "Channel", "SLA", "Logo Position"];
    const csv = [header, ...mapped.map((row) => [row.valid, row.caption, row.destination, row.channel, row.sla, row.logoPosition])]
      .map((line) => line.map(toCsvCell).join(","))
      .join("\n");

    const destinationNames = uniq(mapped.map((row) => row.destination).filter(Boolean));
    const project = await this.prisma.project.findFirst({
      where: { id: projectId, accountId },
      select: { name: true, projectCode: true } as any,
    });

    const attachmentStem =
      firstNonEmpty(project?.projectCode, project?.name, "planner-report")?.replace(/[^a-zA-Z0-9._-]+/g, "-").replace(/^-+|-+$/g, "") ||
      "planner-report";

    return {
      reportRows: mapped,
      reportRowCount: mapped.length,
      destinationNamesLabel: destinationNames.join(", "),
      reportCsvBase64: Buffer.from(csv, "utf8").toString("base64"),
      reportAttachmentName: `${attachmentStem}-planner-report.csv`,
      reportPreviewLines: mapped.slice(0, 10).map((row) => [row.destination, row.channel, row.valid, row.sla, row.logoPosition].filter(Boolean).join(" | ")),
    };
  }

  private async loadCreativeSummaries(accountId: string, projectId: string): Promise<any> {
    const creatives: any[] = await this.prisma.creative.findMany({
      where: { accountId, projectId },
      orderBy: { createdAt: "asc" },
      select: {
        id: true,
        valid: true,
        caption: true,
        title: true,
        name: true,
        format: true,
        languages: true,
        duration: true,
        updatedAt: true,
        assets: {
          where: { type: "SOURCE" as any },
          orderBy: { createdAt: "desc" },
          take: 1,
          select: { uploadEndedAt: true, createdAt: true } as any,
        },
      } as any,
    });

    const summaries = creatives.map((creative: any) => ({
      valid: firstNonEmpty(creative?.valid) ?? "",
      caption: firstNonEmpty(creative?.caption, creative?.title, creative?.name) ?? "",
      format: firstNonEmpty(creative?.format) ?? "",
      language: formatLanguages(creative?.languages),
      duration: firstNonEmpty(creative?.duration) ?? "",
    }));

    const latestUpload = creatives
      .map((creative: any) => creative?.assets?.[0]?.uploadEndedAt ?? creative?.assets?.[0]?.createdAt ?? creative?.updatedAt ?? null)
      .filter(Boolean)
      .map((x: any) => new Date(x))
      .filter((d: Date) => !Number.isNaN(d.getTime()))
      .sort((a: Date, b: Date) => b.getTime() - a.getTime())[0];

    return {
      creativeSummaries: summaries,
      latestUploadAtRaw: latestUpload ?? null,
      latestUploadAtIst: formatIstDateTime(latestUpload ?? null),
    };
  }

  private async loadRouteContext(accountId: string, projectId: string, creativeId: string | null, p: any, type: number): Promise<any> {
    if ([6, 11].includes(type) && p?.planLineId) {
      const line: any = await this.prisma.planLine.findFirst({
        where: { id: String(p.planLineId), accountId },
        select: {
          channel: {
            select: {
              id: true,
              name: true,
              destination: { select: { name: true } },
            } as any,
          },
        } as any,
      });
      const ch: any = Array.isArray(line?.channel) ? line.channel[0] ?? null : line?.channel ?? null;
      if (!ch) return {};
      return {
        channelName: ch.name ?? null,
        channels: [{ id: ch.id, name: ch.name }],
        destinationName: ch?.destination?.name ?? null,
        destinationNamesLabel: firstNonEmpty(ch?.destination?.name) ?? null,
      };
    }

    const entries: any[] = await this.prisma.planningEntry.findMany({
      where: { accountId, projectId, ...(creativeId ? { creativeId } : {}), selected: true },
      select: {
        channel: {
          select: {
            id: true,
            name: true,
            destination: { select: { name: true } },
          } as any,
        },
      } as any,
    });

    const channels = uniq(
      entries
        .map((entry: any) => entry?.channel?.name)
        .filter(Boolean)
        .map((name: any) => String(name)),
    );
    const destinations = uniq(
      entries
        .map((entry: any) => entry?.channel?.destination?.name)
        .filter(Boolean)
        .map((name: any) => String(name)),
    );

    return {
      channelName: channels.length === 1 ? channels[0] : null,
      channels: entries
        .map((entry: any) => (Array.isArray(entry?.channel) ? entry.channel[0] ?? null : entry?.channel ?? null))
        .filter(Boolean)
        .map((channel: any) => ({ id: channel.id, name: channel.name })),
      destinationName: destinations.length === 1 ? destinations[0] : null,
      destinationNamesLabel: destinations.join(", "),
    };
  }

  private async enrichPayloadForEmail(
    type: number,
    accountId: string,
    projectId: string | null,
    creativeId: string | null,
    payload: any,
  ) {
    const p: any = payload ? { ...payload } : {};
    const pid = String(p.projectId ?? projectId ?? "").trim() || null;
    const cid = String(p.creativeId ?? creativeId ?? "").trim() || null;

    try {
      if (pid) {
        const proj: any = await this.loadProjectContext(accountId, pid);
        if (proj) {
          p.projectName = proj.name ?? p.projectName ?? null;
          p.projectNumber = proj.projectNumber ?? p.projectNumber ?? null;
          p.projectCode = proj.projectCode ?? p.projectCode ?? null;
          p.advertiserGroupName = proj.advertiserGroup?.name ?? p.advertiserGroupName ?? null;
          p.advertiserName = proj.advertiser?.name ?? p.advertiserName ?? null;
          p.brandName = proj.brand?.name ?? p.brandName ?? null;
          p.productCategoryName = proj.productCategory?.name ?? p.productCategoryName ?? null;
          p.mediaAgencyName = proj.mediaAgency?.name ?? p.mediaAgencyName ?? null;
          p.creativeAgencyName = proj.creativeAgency?.name ?? p.creativeAgencyName ?? null;
          p.productionHouseName = proj.productionHouse?.name ?? p.productionHouseName ?? null;
          p.postHouseName = proj.postHouse?.name ?? p.postHouseName ?? null;
          p.audioAgencyName = proj.audioAgency?.name ?? p.audioAgencyName ?? null;
          p.projectUploaderName = proj.uploaderAgency?.name ?? p.projectUploaderName ?? null;
          p.projectUploaderTeamName = proj.uploaderAgencyTeam?.name ?? p.projectUploaderTeamName ?? null;
          p.projectRemarks = proj.remarks ?? p.projectRemarks ?? null;
        }
      }

      if (cid) {
        const cr: any = await this.loadCreativeContext(accountId, cid);
        if (cr) {
          p.creativeValid = cr.valid ?? p.creativeValid ?? null;
          p.creativeCaption = firstNonEmpty(cr.caption, cr.title, cr.name) ?? p.creativeCaption ?? null;
          p.creativeTitle = firstNonEmpty(cr.title, cr.name) ?? p.creativeTitle ?? null;
          p.creativeFormat = cr.format ?? p.creativeFormat ?? null;
          p.creativeLanguages = Array.isArray(cr.languages) ? cr.languages : p.creativeLanguages ?? [];
          p.creativeLanguageText = formatLanguages(cr.languages);
          p.creativeDuration = cr.duration ?? p.creativeDuration ?? null;

          if (type === 2 && !Array.isArray(p.clientQcIssues)) {
            p.clientQcIssues = deriveClientQcIssues((cr as any).qcReport, Array.isArray(p.reasons) ? p.reasons : []);
          }
        }
      }

      if (type === 3 && pid) {
        Object.assign(p, await this.loadCreativeSummaries(accountId, pid));

        const latestPlan: any = await this.prisma.planVersion.findFirst({
          where: { accountId, projectId: pid },
          orderBy: { version: "desc" },
          select: { createdAt: true } as any,
        });
        if (latestPlan?.createdAt && p.latestUploadAtRaw) {
          const commitDt = new Date((latestPlan as any).createdAt as any);
          const uploadDt = new Date(p.latestUploadAtRaw);
          if (!Number.isNaN(commitDt.getTime()) && !Number.isNaN(uploadDt.getTime()) && uploadDt.getTime() > commitDt.getTime()) {
            p.committedProjectNewFileOnly = true;
          }
        }
      }

      if (type === 4 && pid) {
        Object.assign(p, await this.loadPlannerReportContext(accountId, pid));
      }

      if ([5, 6, 7, 9, 10, 11].includes(type) && pid) {
        const commit: any = await this.loadCommitContext(accountId, pid, Number.isFinite(Number(p.planVersion)) ? Number(p.planVersion) : null);
        p.planVersion = p.planVersion ?? commit.planVersion ?? null;
        p.commitTimeRaw = p.commitTimeRaw ?? commit.commitTimeRaw ?? null;
        p.commitTimeIst = p.commitTimeIst ?? commit.commitTimeIst ?? null;
        p.committedByLabel = p.committedByLabel ?? commit.committedByLabel ?? null;
      }

      if ([6, 7, 9, 10, 11].includes(type) && pid) {
        Object.assign(p, await this.loadRouteContext(accountId, pid, cid, p, type));
      }

      if ([6, 9, 10].includes(type) && pid && cid) {
        const approval: any = await this.loadApprovalContext(accountId, pid, cid);
        if (approval) {
          Object.assign(p, approval);
          if (type === 10 && approval.approvalCompletedAtRaw && p.commitTimeRaw) {
            const start = new Date(p.commitTimeRaw);
            const end = new Date((approval as any).approvalCompletedAtRaw as any);
            if (!Number.isNaN(start.getTime()) && !Number.isNaN(end.getTime()) && end.getTime() >= start.getTime()) {
              const totalSeconds = Math.floor((end.getTime() - start.getTime()) / 1000);
              const hours = Math.floor(totalSeconds / 3600);
              const minutes = Math.floor((totalSeconds % 3600) / 60);
              const seconds = totalSeconds % 60;
              p.approvalElapsedText = `${hours}h ${minutes}m ${seconds}s`;
            }
          }
        }
      }

      if ([6, 11].includes(type) && p?.planLineId && !p.creativeId) {
        const line: any = await this.prisma.planLine.findFirst({
          where: { id: String(p.planLineId), accountId },
          select: { creativeId: true } as any,
        });
        if (line?.creativeId) p.creativeId = line.creativeId;
      }
    } catch {
      // best-effort only
    }

    return p;
  }
  async listProjectNotifications(accountId: string, projectId: string) {
    const events = await this.prisma.notificationEvent.findMany({
      where: { accountId, projectId },
      orderBy: { createdAt: "desc" },
      select: notificationEventSelect as any,
    });

    return { events };
  }

  async retrigger(accountId: string, eventId: string, triggeredByUserId?: string | null, reason?: string | null) {
    const event = await this.prisma.notificationEvent.findFirst({
      where: { id: eventId, accountId },
      select: { id: true, accountId: true, type: true, projectId: true, creativeId: true, title: true, payload: true, to: true, cc: true },
    });
    if (!event) throw new NotFoundException("Notification event not found");

    const maxAttempt =
      (await this.prisma.notificationAttempt.aggregate({
        where: { eventId: event.id },
        _max: { attemptNo: true },
      }))._max.attemptNo ?? 0;

    const attemptNo = maxAttempt + 1;

    const attempt = await this.prisma.notificationAttempt.create({
      data: {
        eventId: event.id,
        attemptNo,
        status: "QUEUED",
        triggeredByUserId: triggeredByUserId ?? null,
        reason: reason ?? null,
      } as any,
      select: { id: true, attemptNo: true },
    });

    // Enrich on retrigger too (useful for older events created before human-readable fields existed)
    const enriched = await this.enrichPayloadForEmail(event.type, accountId, event.projectId ?? null, event.creativeId ?? null, event.payload);
    const msg = this.buildEmailForEvent(event.type, event.title, enriched);
    await this.prisma.emailOutbox.create({
      data: {
        accountId,
        projectId: event.projectId ?? null,
        creativeId: event.creativeId ?? null,
        eventType: `NOTIF_${event.type}`,
        to: uniq(event.to ?? []),
        cc: uniq(event.cc ?? []),
        subject: msg.subject,
        bodyText: msg.bodyText,
        bodyHtml: msg.bodyHtml,
        payload: {
          notification: {
            eventId: event.id,
            attemptId: attempt.id,
            attemptNo,
            type: event.type,
            reason: reason ?? null,
          },
          originalPayload: enriched ?? {},
          attachments: msg.attachments ?? [],
        } as any,
      },
    });

    return { ok: true, attemptNo };
  }

  // ----------------------------
  // Emit helpers (Types 1..11)
  // ----------------------------
  async emitType1ProjectCreated(accountId: string, projectId: string) {
    const stakeholders = await this.resolveStakeholders(accountId, projectId);
    const dedupeKey = `P2:NOTIF:1:PROJECT_CREATED:${projectId}`;
    const payload = { projectId };
    return this.emitEvent(accountId, projectId, null, 1, dedupeKey, "Project created", payload, stakeholders.to, stakeholders.cc);
  }

  async emitType2AutoQc(accountId: string, projectId: string, creativeId: string, jobId: string, qcStatus: string, reasons: string[]) {
    const stakeholders = await this.resolveStakeholders(accountId, projectId);
    const dedupeKey = `P2:NOTIF:2:AUTO_QC:${jobId}`;

    let projectName: string | null = null;
    let projectCode: string | null = null;
    let creativeValid: string | null = null;
    let creativeTitle: string | null = null;
    let clientQcIssues: ClientQcIssue[] = [];

    try {
      const [proj, cr] = await Promise.all([
        this.prisma.project.findFirst({
          where: { id: projectId, accountId },
          select: { name: true, projectCode: true } as any,
        }),
        this.prisma.creative.findFirst({
          where: { id: creativeId, accountId },
          select: { valid: true, title: true, name: true, qcReport: true } as any,
        }),
      ]);

      projectName = (proj as any)?.name ?? null;
      projectCode = (proj as any)?.projectCode ?? null;
      creativeValid = (cr as any)?.valid ?? null;
      creativeTitle = (cr as any)?.title ?? (cr as any)?.name ?? null;
      clientQcIssues = deriveClientQcIssues((cr as any)?.qcReport, reasons);
    } catch {
      // best-effort; fall back to IDs
    }

    const payload = {
      projectId,
      projectName,
      projectCode,
      creativeId,
      creativeValid,
      creativeTitle,
      jobId,
      qcStatus,
      reasons,
      clientQcIssues,
    };

    const norm = String(qcStatus ?? "").trim().toUpperCase();
    const isPass =
      norm === "PASS" ||
      norm === "PASSED" ||
      norm === "SUCCESS" ||
      norm === "OK" ||
      norm.startsWith("PASS");
    const isFail = norm === "FAIL" || norm === "FAILED" || norm === "ERROR" || norm.startsWith("FAIL") || norm.includes("FAIL");

    const title = isPass ? "Auto QC passed" : isFail ? "Auto QC failed" : `Auto QC ${norm || "result"}`;
    return this.emitEvent(accountId, projectId, creativeId, 2, dedupeKey, title, payload, stakeholders.to, stakeholders.cc);
  }

  async emitType3AllFilesUploaded(accountId: string, projectId: string) {
    const stakeholders = await this.resolveStakeholders(accountId, projectId);
    const dedupeKey = `P2:NOTIF:3:ALL_FILES_UPLOADED:${projectId}`;
    const payload = { projectId };
    return this.emitEvent(accountId, projectId, null, 3, dedupeKey, "All files uploaded", payload, stakeholders.to, stakeholders.cc);
  }

  async emitType4DestinationsSelected(accountId: string, projectId: string) {
    const stakeholders = await this.resolveStakeholders(accountId, projectId);
    const dedupeKey = `P2:NOTIF:4:DEST_SELECTED:${projectId}`;
    const payload = { projectId };
    return this.emitEvent(accountId, projectId, null, 4, dedupeKey, "Destinations selected", payload, stakeholders.to, stakeholders.cc);
  }

  async emitType5Committed(
    accountId: string,
    projectId: string,
    planVersion: number,
    committedBy?: { userId?: string | null; displayName?: string | null; email?: string | null } | null,
  ) {
    const stakeholders = await this.resolveStakeholders(accountId, projectId);
    const dedupeKey = `P2:NOTIF:5:COMMITTED:${projectId}:v${planVersion}`;
    const payload = {
      projectId,
      planVersion,
      commitTimeRaw: new Date().toISOString(),
      commitTimeIst: formatIstDateTime(new Date()),
      committedByLabel: firstNonEmpty(committedBy?.displayName, committedBy?.email) ?? null,
      committedByUserId: committedBy?.userId ?? null,
    };
    return this.emitEvent(accountId, projectId, null, 5, dedupeKey, "Project committed", payload, stakeholders.to, stakeholders.cc);
  }

  async emitType6Delivered(accountId: string, taskId: string) {
    // NOTE: In this codebase DeliveryTask doesn't expose projectId/creativeId/channelId directly.
    // We resolve projectId via DeliveryOrder (orderId) and creativeId via PlanLine (planLineId).
    const task = await this.prisma.deliveryTask.findFirst({
      where: { id: taskId, accountId },
      select: { id: true, status: true, orderId: true, planLineId: true },
    });
    if (!task) throw new NotFoundException("Delivery task not found");
    if (task.status !== DeliveryTaskStatus.SUCCESS) return { ok: true, skipped: true };

    const order = await this.prisma.deliveryOrder.findFirst({
      where: { id: task.orderId, accountId },
      select: { id: true, projectId: true, accountId: true },
    });
    if (!order?.projectId) return { ok: true, skipped: true };

    const projectId = order.projectId;

    let creativeId: string | null = null;
    if (task.planLineId) {
      const line: any = await this.prisma.planLine.findFirst({
        where: { id: task.planLineId, accountId },
        select: { creativeId: true },
      });
      creativeId = line?.creativeId ?? null;
    }

    const stakeholders = await this.resolveStakeholders(accountId, projectId);
    const to = uniq(stakeholders.to ?? []);
    const cc = uniq(stakeholders.cc ?? []);

    const dedupeKey = `P2:NOTIF:6:DELIVERED:${task.id}`;
    const payload = {
      taskId: task.id,
      taskStatus: task.status,
      projectId,
      creativeId,
      orderId: task.orderId,
      planLineId: task.planLineId ?? null,
    };

    await this.emitEvent(accountId, projectId, creativeId, 6, dedupeKey, "File delivered", payload, to, cc);

    // Consolidations (best-effort)
    if (creativeId) await this.maybeEmitType7CreativeMulti(accountId, projectId, creativeId);
    await this.maybeEmitType8ProjectComplete(accountId, projectId);

    return { ok: true };
  }

  async emitType9ReadyForApproval(accountId: string, approvalRequestId: string) {
    const req: any = await this.prisma.approvalRequest.findFirst({
      where: { id: approvalRequestId, accountId },
      select: {
        id: true,
        projectId: true,
        creativeId: true,
        status: true,
        template: { select: { mode: true } },
        steps: { select: { order: true, required: true, status: true, label: true, key: true }, orderBy: { order: "asc" } },
      },
    });
    if (!req) throw new NotFoundException("Approval request not found");

    // Determine which step(s) are currently actionable
    const required = (req.steps ?? []).filter((s: any) => s.required);
    const pending = required.filter((s: any) => s.status === "PENDING").sort((a: any, b: any) => a.order - b.order);
    if (!pending.length) return { ok: true, skipped: true };

    const mode = (req.template?.mode ?? "SEQUENTIAL") as any;
    const activeOrders = mode === "PARALLEL" ? pending.map((s: any) => s.order) : [pending[0].order];

    for (const stepOrder of activeOrders) {
      const recipients = await this.resolveChannelApprovalRecipients(accountId, req.projectId, req.creativeId, stepOrder);
      if (!recipients.channels.length || (!recipients.to.length && !recipients.cc.length)) continue;
      const teamNames = uniq(recipients.channels.map((c) => c.teamName).filter(Boolean) as any);
      const teamLabel = teamNames.length === 1 ? teamNames[0] : null;

      const title = teamLabel
        ? `File ready for approval - ${teamLabel} (Step ${stepOrder})`
        : `File ready for approval - Step ${stepOrder}`;

      const dedupeKey = `P2:NOTIF:9:READY_APPROVAL:${req.id}:step${stepOrder}`;
      const payload = {
        projectId: req.projectId,
        creativeId: req.creativeId,
        approvalRequestId: req.id,
        stepOrder,
        teamNames,
        channels: recipients.channels,
      };

      await this.emitEvent(accountId, req.projectId, req.creativeId, 9, dedupeKey, title, payload, recipients.to, recipients.cc);
    }

    return { ok: true };
  }

  async emitType10Approved(accountId: string, approvalRequestId: string) {
    const req: any = await this.prisma.approvalRequest.findFirst({
      where: { id: approvalRequestId, accountId },
      select: { id: true, projectId: true, creativeId: true, status: true },
    });
    if (!req) throw new NotFoundException("Approval request not found");
    if (req.status !== ApprovalRequestStatus.APPROVED) return { ok: true, skipped: true };

    const recipients = await this.resolveChannelNotificationRecipientsForCreative(accountId, req.projectId, req.creativeId, {
      approvalRequired: true,
    });
    if (!recipients.channels.length || !recipients.to.length) return { ok: true, skipped: true };

    const dedupeKey = `P2:NOTIF:10:APPROVED:${req.id}`;
    const payload = { projectId: req.projectId, creativeId: req.creativeId, approvalRequestId: req.id, channels: recipients.channels };

    const channelLabel = recipients.channels.length === 1 ? recipients.channels[0]?.name : null;
    const title = channelLabel ? `File approved - ${channelLabel}` : "File approved";

    return this.emitEvent(accountId, req.projectId, req.creativeId, 10, dedupeKey, title, payload, recipients.to, []);
  }

  async emitType11FileSent(accountId: string, taskId: string) {
    const task: any = await this.prisma.deliveryTask.findFirst({
      where: { id: taskId, accountId },
      select: {
        id: true,
        status: true,
        orderId: true,
        planLineId: true,
        order: { select: { projectId: true } },
        planLine: {
          select: {
            creativeId: true,
            channel: {
              select: {
                id: true,
                name: true,
                approvalsConfig: true,
                notificationEmails: true,
                destination: { select: { id: true, name: true, config: true } },
              },
            },
          },
        },
      } as any,
    });
    if (!task?.order?.projectId) return { ok: true, skipped: true };

    const channel = task?.planLine?.channel;
    if (!channel) return { ok: true, skipped: true };
    if (this.destinationApprovalRequired((channel as any)?.destination?.config)) return { ok: true, skipped: true };

    const recipients = await this.resolveReceiverNotificationRecipientsForChannels(accountId, [channel], {
      approvalRequired: false,
      includeApprovalCc: false,
      includeStepOneFallback: true,
    });
    if (!recipients.channels.length || !recipients.to.length) return { ok: true, skipped: true };

    const projectId = task.order.projectId;
    const creativeId = task?.planLine?.creativeId ?? null;
    const dedupeKey = `P2:NOTIF:11:SENT:${task.id}`;
    const payload = {
      taskId: task.id,
      taskStatus: task.status,
      projectId,
      creativeId,
      orderId: task.orderId,
      planLineId: task.planLineId ?? null,
      channels: recipients.channels,
    };

    const channelLabel = recipients.channels.length === 1 ? recipients.channels[0]?.name : null;
    const title = channelLabel ? `File sent - ${channelLabel}` : "File sent";

    return this.emitEvent(accountId, projectId, creativeId, 11, dedupeKey, title, payload, recipients.to, []);
  }

  // ----------------------------
  // Internal core
  // ----------------------------
  private async emitEvent(
    accountId: string,
    projectId: string,
    creativeId: string | null,
    type: number,
    dedupeKey: string,
    title: string,
    payload: any,
    to: string[],
    cc: string[],
  ) {
    const safeTo = uniq(to ?? []);
    const safeCc = uniq(cc ?? []);

    // Respect per-project enabledTypes (if configured)
    const proj = await this.prisma.project.findFirst({
      where: { id: projectId, accountId },
      select: { notificationConfig: { select: { enabledTypes: true } } },
    });
    const enabled = (proj?.notificationConfig?.enabledTypes as any) as number[] | null | undefined;
    if (Array.isArray(enabled)) {
      if (enabled.length === 0 || !enabled.includes(type)) {
        return { ok: true, skipped: true, disabled: true };
      }
    }

    const existing = await this.prisma.notificationEvent.findFirst({
      where: { accountId, dedupeKey },
      select: { id: true },
    });
    if (existing) return { ok: true, skipped: true };

    const enrichedPayload = await this.enrichPayloadForEmail(type, accountId, projectId, creativeId, payload);
    const msg = this.buildEmailForEvent(type, title, enrichedPayload);

    await this.prisma.$transaction(async (tx) => {
      const ev = await tx.notificationEvent.create({
        data: {
          accountId,
          projectId,
          creativeId: creativeId ?? null,
          type,
          dedupeKey,
          origin: payload?.origin ?? null,
          title,
          payload: enrichedPayload ?? {},
          to: safeTo,
          cc: safeCc,
        } as any,
        select: { id: true },
      });

      const attempt = await tx.notificationAttempt.create({
        data: {
          eventId: ev.id,
          attemptNo: 1,
          status: "QUEUED",
          reason: null,
          triggeredByUserId: null,
        } as any,
        select: { id: true },
      });

      await tx.emailOutbox.create({
        data: {
          accountId,
          projectId,
          creativeId: creativeId ?? null,
          eventType: `NOTIF_${type}`,
          to: safeTo,
          cc: safeCc,
          subject: msg.subject,
          bodyText: msg.bodyText,
          bodyHtml: msg.bodyHtml,
          payload: {
            notification: {
              eventId: ev.id,
              attemptId: attempt.id,
              attemptNo: 1,
              type,
            },
            originalPayload: enrichedPayload ?? {},
            attachments: msg.attachments ?? [],
          } as any,
        },
      });
    });

    return { ok: true };
  }

  private buildEmailForEvent(type: number, title: string, payload: any) {
    const p: any = payload ?? {};
    const subject = this.formatSubject(type, title, p);
    const bodyText = this.buildFriendlyBody(type, title, p);
    const bodyHtml = type === 2 ? this.buildQcEmailHtml(title, p) : this.buildStandardEmailHtml(type, title, p);
    const attachments = this.buildAttachmentsForEvent(type, p);
    return { subject, bodyText, bodyHtml, attachments };
  }

  private async resolveStakeholders(accountId: string, projectId: string): Promise<Stakeholders> {
    const project = await this.prisma.project.findFirst({
      where: { id: projectId, accountId },
      select: {
        id: true,
        name: true,
        projectCode: true,
        notificationConfig: {
          select: {
            notifyAdvertiserGroup: true,
            notifyAdvertiser: true,
            notifyBrand: true,
            notifyMediaAgency: true,
            notifyCreativeAgency: true,
            notifyPostHouse: true,
            notifyAudioAgency: true,
            notifyProductionHouse: true,
            extraEmails: true,
            enabledTypes: true,
          },
        },
        brand: { select: { emails: true } },
        mediaAgency: { select: { emails: true } },
        mediaAgencyTeam: { select: { emails: true } },
        creativeAgency: { select: { emails: true } },
        creativeAgencyTeam: { select: { emails: true } },
        productionHouse: { select: { emails: true } },
        productionHouseTeam: { select: { emails: true } },
        postHouse: { select: { emails: true } },
        postHouseTeam: { select: { emails: true } },
        audioAgency: { select: { emails: true } },
        audioAgencyTeam: { select: { emails: true } },
      },
    });
    if (!project) throw new NotFoundException("Project not found");

    const cfg = project.notificationConfig;
    const to: string[] = [];
    const cc: string[] = [];

    // Brand + agencies
    if (cfg?.notifyBrand) to.push(...(project.brand?.emails ?? []));
    if (cfg?.notifyMediaAgency) to.push(...(project.mediaAgency?.emails ?? []), ...(project.mediaAgencyTeam?.emails ?? []));
    if (cfg?.notifyCreativeAgency) to.push(...(project.creativeAgency?.emails ?? []), ...(project.creativeAgencyTeam?.emails ?? []));
    if (cfg?.notifyProductionHouse) to.push(...(project.productionHouse?.emails ?? []), ...(project.productionHouseTeam?.emails ?? []));
    if (cfg?.notifyPostHouse) to.push(...(project.postHouse?.emails ?? []), ...(project.postHouseTeam?.emails ?? []));
    if (cfg?.notifyAudioAgency) to.push(...(project.audioAgency?.emails ?? []), ...(project.audioAgencyTeam?.emails ?? []));

    // Extra emails always included
    to.push(...(cfg?.extraEmails ?? []));

    return { to: uniq(to), cc: uniq(cc) };
  }


  private destinationApprovalRequired(raw: any) {
    const cfg = raw && typeof raw === "object" ? raw : {};
    return (cfg as any).approvalRequired === true;
  }

  private destinationReceiverAccountId(raw: any): string | null {
    const cfg = raw && typeof raw === "object" ? raw : {};
    const id = String((cfg as any).receiverAccountId || "").trim();
    return id || null;
  }

  private async loadReceiverEmailMap(accountId: string, channels: any[]) {
    const receiverIds = Array.from(
      new Set(
        (Array.isArray(channels) ? channels : [])
          .map((ch: any) => this.destinationReceiverAccountId((ch as any)?.destination?.config))
          .filter(Boolean),
      ),
    ) as string[];

    if (!receiverIds.length) return new Map<string, { id: string; name: string | null; emails: string[] }>();

    const receivers: any[] = await this.prisma.partnerAccount.findMany({
      where: { accountId, id: { in: receiverIds } },
      select: { id: true, name: true, emails: true },
    });

    return new Map(
      receivers.map((row: any) => [
        String(row.id),
        {
          id: String(row.id),
          name: firstNonEmpty(row.name) ?? null,
          emails: uniq(row.emails ?? []),
        },
      ]),
    );
  }

  private async resolveReceiverNotificationRecipientsForChannels(
    accountId: string,
    channels: any[],
    opts?: {
      approvalRequired?: boolean | null;
      stepOrder?: number | null;
      includeApprovalCc?: boolean;
      includeStepOneFallback?: boolean;
    },
  ) {
    const scopedChannels = Array.isArray(channels) ? channels : [];
    const receiverById = await this.loadReceiverEmailMap(accountId, scopedChannels);

    const to: string[] = [];
    const cc: string[] = [];
    const metaChannels: Array<{
      id: string;
      name: string;
      teamName: string | null;
      receiverAccountId: string | null;
      receiverAccountName: string | null;
    }> = [];

    for (const ch of scopedChannels) {
      const destinationCfg = (ch as any)?.destination?.config;
      const isApprovalRequired = this.destinationApprovalRequired(destinationCfg);
      if (opts?.approvalRequired === true && !isApprovalRequired) continue;
      if (opts?.approvalRequired === false && isApprovalRequired) continue;

      const receiverAccountId = this.destinationReceiverAccountId(destinationCfg);
      const receiver = receiverAccountId ? receiverById.get(receiverAccountId) : null;
      const receiverEmails = receiver?.emails ?? [];
      const destinationEmails = destinationClientEmailsFromConfig(destinationCfg);
      const parsed = opts?.stepOrder
        ? parseApprovalsEmailsForStep((ch as any)?.approvalsConfig as any, opts.stepOrder)
        : { to: [] as string[], cc: [] as string[], teamName: null as string | null };

      let chosenTo = receiverEmails.length
        ? receiverEmails
        : destinationEmails.length
          ? destinationEmails
          : parsed.to.length
            ? parsed.to
            : (ch.notificationEmails ?? []);

      if (!chosenTo.length && opts?.includeStepOneFallback) {
        const stepOne = parseApprovalsEmailsForStep((ch as any)?.approvalsConfig as any, 1);
        chosenTo = stepOne.to;
        if (opts?.includeApprovalCc && stepOne.cc.length) cc.push(...stepOne.cc);
      }

      if (chosenTo.length) to.push(...chosenTo);
      if (opts?.includeApprovalCc && parsed.cc.length) cc.push(...parsed.cc);

      metaChannels.push({
        id: ch.id,
        name: ch.name,
        teamName: parsed.teamName ?? null,
        receiverAccountId: receiver?.id ?? receiverAccountId ?? null,
        receiverAccountName: receiver?.name ?? null,
      });
    }

    return { to: uniq(to), cc: uniq(cc), channels: metaChannels };
  }

  private async getSelectedChannelsForCreative(accountId: string, projectId: string, creativeId: string) {
    const entries: any[] = await this.prisma.planningEntry.findMany({
      where: { accountId, projectId, creativeId, selected: true },
      select: { channelId: true },
    });
    const channelIds = Array.from(new Set(entries.map((e) => e.channelId)));
    if (!channelIds.length) return [];

    return this.prisma.channel.findMany({
      where: { accountId, id: { in: channelIds } },
      select: {
        id: true,
        name: true,
        approvalsConfig: true,
        notificationEmails: true,
        destination: { select: { id: true, name: true, config: true } },
      },
    });
  }

  private async resolveChannelApprovalRecipients(accountId: string, projectId: string, creativeId: string, stepOrder: number) {
    const channels = await this.getSelectedChannelsForCreative(accountId, projectId, creativeId);
    return this.resolveReceiverNotificationRecipientsForChannels(accountId, channels, {
      approvalRequired: true,
      stepOrder,
      includeApprovalCc: true,
      includeStepOneFallback: false,
    });
  }

  private async resolveChannelNotificationRecipientsForCreative(
    accountId: string,
    projectId: string,
    creativeId: string,
    opts?: { approvalRequired?: boolean | null },
  ) {
    const channels = await this.getSelectedChannelsForCreative(accountId, projectId, creativeId);
    return this.resolveReceiverNotificationRecipientsForChannels(accountId, channels, {
      approvalRequired: opts?.approvalRequired ?? null,
      includeApprovalCc: false,
      includeStepOneFallback: true,
    });
  }

  private async resolveChannelNotificationRecipientsForProject(accountId: string, projectId: string, orderIds: string[]) {
    // Prefer channels actually used by DeliveryTasks (via PlanLineId)
    const taskLineIds = await this.prisma.deliveryTask.findMany({
      where: { accountId, orderId: { in: orderIds }, planLineId: { not: null } },
      select: { planLineId: true },
    });
    const planLineIds = Array.from(new Set(taskLineIds.map((t) => t.planLineId).filter(Boolean))) as string[];

    let channelIds: string[] = [];
    if (planLineIds.length) {
      const lines = await this.prisma.planLine.findMany({
        where: { accountId, id: { in: planLineIds } },
        select: { channelId: true },
      });
      channelIds = Array.from(new Set(lines.map((l) => l.channelId)));
    }

    // fallback: planning entries selected for project
    if (!channelIds.length) {
      const entries: any[] = await this.prisma.planningEntry.findMany({
        where: { accountId, projectId, selected: true },
        select: { channelId: true },
      });
      channelIds = Array.from(new Set(entries.map((e) => e.channelId)));
    }

    if (!channelIds.length) return { to: [], channels: [] as any[] };

    const channels = await this.prisma.channel.findMany({
      where: { accountId, id: { in: channelIds } },
      select: {
        id: true,
        name: true,
        notificationEmails: true,
        destination: { select: { id: true, name: true, config: true } },
      },
    });

    const to: string[] = [];
    for (const ch of channels) {
      const destinationEmails = destinationClientEmailsFromConfig((ch as any)?.destination?.config);
      if (destinationEmails.length) to.push(...destinationEmails);
      else to.push(...(ch.notificationEmails ?? []));
    }

    return { to: uniq(to), channels: channels.map((c) => ({ id: c.id, name: c.name })) };
  }

  private async maybeEmitType7CreativeMulti(accountId: string, projectId: string, creativeId: string) {
    // In this schema, DeliveryTask doesn't have projectId/creativeId.
    // We scope tasks by: DeliveryOrder.projectId -> orderIds, and PlanLine.creativeId -> planLineIds.
    const orders = await this.prisma.deliveryOrder.findMany({
      where: { accountId, projectId },
      select: { id: true },
    });
    const orderIds = orders.map((o) => o.id);
    if (orderIds.length === 0) return;

    const lines = await this.prisma.planLine.findMany({
      where: { accountId, creativeId },
      select: { id: true },
    });
    const lineIds = lines.map((l) => l.id);
    if (lineIds.length === 0) return;

    const total = await this.prisma.deliveryTask.count({
      where: { accountId, orderId: { in: orderIds }, planLineId: { in: lineIds } },
    });
    if (total < 2) return;

    const success = await this.prisma.deliveryTask.count({
      where: { accountId, orderId: { in: orderIds }, planLineId: { in: lineIds }, status: DeliveryTaskStatus.SUCCESS },
    });
    if (success !== total) return;

    const stakeholders = await this.resolveStakeholders(accountId, projectId);

    const dedupeKey = `P2:NOTIF:7:CREATIVE_MULTI_DELIVERED:${creativeId}:${projectId}`;
    const payload = { projectId, creativeId, destinations: total };
    await this.emitEvent(
      accountId,
      projectId,
      creativeId,
      7,
      dedupeKey,
      "File delivered to multiple destinations",
      payload,
      uniq(stakeholders.to ?? []),
      uniq(stakeholders.cc ?? []),
    );
  }

  private async maybeEmitType8ProjectComplete(accountId: string, projectId: string) {
    // Derive tasks for a project via DeliveryOrder ids.
    const orders = await this.prisma.deliveryOrder.findMany({
      where: { accountId, projectId },
      select: { id: true },
    });
    const orderIds = orders.map((o) => o.id);
    if (orderIds.length === 0) return;

    const total = await this.prisma.deliveryTask.count({
      where: { accountId, orderId: { in: orderIds } },
    });
    if (total < 1) return;

    const success = await this.prisma.deliveryTask.count({
      where: { accountId, orderId: { in: orderIds }, status: DeliveryTaskStatus.SUCCESS },
    });
    if (success !== total) return;

    // ✅ Channel-only routing for Type 8
    const recipients = await this.resolveChannelNotificationRecipientsForProject(accountId, projectId, orderIds);
    if (!recipients.to.length) return;

    const dedupeKey = `P2:NOTIF:8:PROJECT_COMPLETE:${projectId}`;
    const payload = { projectId, totalDeliveries: total, channels: recipients.channels };

    const title = "Project completed";
    await this.emitEvent(accountId, projectId, null, 8, dedupeKey, title, payload, recipients.to, []);
  }
}