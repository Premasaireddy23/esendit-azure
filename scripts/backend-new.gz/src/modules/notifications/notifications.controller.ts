import { Body, Controller, Get, Param, Post, UseGuards } from "@nestjs/common";
import { JwtAuthGuard } from "../../common/auth/jwt-auth.guard";
import { PermissionsGuard } from "../../common/auth/permissions.guard";
import { RequirePermissions } from "../../common/auth/require-permissions.decorator";
import { CurrentUser } from "../../common/auth/current-user.decorator";
import { NotificationsService } from "./notifications.service";
import { RetriggerNotificationDto } from "./dto/retrigger-notification.dto";

@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller()
export class NotificationsController {
  constructor(private readonly svc: NotificationsService) {}

  @Get("projects/:projectId/notifications")
  @RequirePermissions("NOTIFICATIONS_READ")
  async listProject(@CurrentUser() user: any, @Param("projectId") projectId: string) {
    return this.svc.listProjectNotifications(user.accountId, projectId);
  }

  @Post("notifications/:eventId/retrigger")
  @RequirePermissions("NOTIFICATIONS_RETRIGGER")
  async retrigger(
    @CurrentUser() user: any,
    @Param("eventId") eventId: string,
    @Body() dto: RetriggerNotificationDto,
  ) {
    return this.svc.retrigger(user.accountId, eventId, user.id, dto?.reason ?? null);
  }
}
