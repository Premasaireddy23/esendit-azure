import { Injectable, NotFoundException, BadRequestException } from "@nestjs/common";
import { PrismaService } from "../../common/prisma/prisma.service";
import { ServiceBusService } from "../../common/queue/service-bus.service";
import { QUEUES } from "../../common/queue/queue.constants";
import { CreatePresetJobDto } from "./dto/create-preset-job.dto";
import { CreativeAssetType, CreativeAssetUploadStatus, MediaJobStatus } from "@prisma/client";
import { DEFAULT_DOWNLOAD_PRESETS } from "../../common/presets/default-download-presets";

type PresetDef = {
  key: string;
  label?: string;
  ext: string;
  mimeType: string;
  // single-step ffmpeg presets (current worker)
  args?: string[];
  // future: multi-step pipelines
  steps?: any[];
};

function parsePresets(downloadPresets: any): PresetDef[] {
  return Array.isArray(downloadPresets) ? (downloadPresets as PresetDef[]) : [];
}

function pickPresetsByKeys(all: PresetDef[], keys: any): PresetDef[] {
  const list = Array.isArray(keys) ? keys.map((k) => String(k).trim()).filter(Boolean) : [];
  if (!list.length) return [];
  const map = new Map(all.map((p) => [p.key, p] as const));
  const seen = new Set<string>();
  const out: PresetDef[] = [];
  for (const k of list) {
    if (seen.has(k)) continue;
    const p = map.get(k);
    if (!p) continue;
    out.push(p);
    seen.add(k);
  }
  return out;
}

type SourceSnapshot = {
  assetId: string;
  filename?: string | null;
  mimeType?: string | null;
  sizeBytes?: string | number | null;
  path?: string | null;
};

// Built-in preset library used when Account.downloadPresets is empty.
// Phase 1 adds the direct single-step client FFmpeg presets here without changing worker behavior.
export const DEFAULT_PRESETS: PresetDef[] = DEFAULT_DOWNLOAD_PRESETS as PresetDef[];

@Injectable()
export class PresetsService {
  constructor(private prisma: PrismaService, private readonly bus: ServiceBusService) {}

  private async resolvePresets(accountId: string, destinationId?: string): Promise<PresetDef[]> {
    // 1) Account global presets (the "library")
    const a = await this.prisma.account.findFirst({
      where: { id: accountId },
      select: { downloadPresets: true } as any,
    });
    const accountPresets = parsePresets((a as any)?.downloadPresets);
    const library = accountPresets.length ? accountPresets : DEFAULT_PRESETS;

    // 2) Destination override
    if (destinationId) {
      const d = await this.prisma.destination.findFirst({
        where: { id: destinationId, accountId },
        select: { downloadPresets: true, config: true },
      });

      // Legacy: if destination.downloadPresets is a full JSON preset array, use it as-is.
      const dp = parsePresets((d as any)?.downloadPresets);
      if (dp.length) return dp;

      // New: destination.config.allowedPresetKeys is an allow-list of preset keys.
      const keys = (d as any)?.config?.allowedPresetKeys;
      const filtered = pickPresetsByKeys(library, keys);
      if (filtered.length) return filtered;
    }

    // 3) Default to global library
    return library;
  }

  async getAccountPresets(accountId: string) {
    const presets = await this.resolvePresets(accountId);
    return { presets };
  }

  async getDestinationPresets(accountId: string, destinationId: string) {
    const presets = await this.resolvePresets(accountId, destinationId);
    return { presets };
  }

  private async getSourceSnapshot(
    accountId: string,
    sourceType: CreatePresetJobDto["sourceType"],
    sourceId: string,
  ): Promise<SourceSnapshot> {
    if (sourceType === "CREATIVE") {
      const a = await this.prisma.creativeAsset.findFirst({
        where: {
          accountId,
          creativeId: sourceId,
          type: CreativeAssetType.SOURCE,
          uploadStatus: CreativeAssetUploadStatus.UPLOADED,
        },
        select: { id: true, filename: true, mimeType: true, sizeBytes: true, path: true },
      });
      if (!a) throw new BadRequestException("Creative SOURCE asset not uploaded");
      return { assetId: a.id, filename: a.filename, mimeType: a.mimeType, sizeBytes: (a as any).sizeBytes, path: a.path };
    }

    if (sourceType === "DAM") {
      const a = await this.prisma.damAsset.findFirst({
        where: {
          accountId,
          damItemId: sourceId,
          type: CreativeAssetType.SOURCE,
          uploadStatus: CreativeAssetUploadStatus.UPLOADED,
        },
        select: { id: true, filename: true, mimeType: true, sizeBytes: true, path: true } as any,
      });
      if (!a) throw new BadRequestException("DAM SOURCE asset not uploaded");
      return { assetId: a.id, filename: (a as any).filename, mimeType: (a as any).mimeType, sizeBytes: (a as any).sizeBytes, path: (a as any).path };
    }

    if (sourceType === "BULK") {
      const a = await this.prisma.bulkUploadAsset.findFirst({
        where: {
          accountId,
          bulkItemId: sourceId,
          type: CreativeAssetType.SOURCE,
          uploadStatus: CreativeAssetUploadStatus.UPLOADED,
        },
        select: { id: true, filename: true, mimeType: true, sizeBytes: true, path: true } as any,
      });
      if (!a) throw new BadRequestException("BULK SOURCE asset not uploaded");
      return { assetId: a.id, filename: (a as any).filename, mimeType: (a as any).mimeType, sizeBytes: (a as any).sizeBytes, path: (a as any).path };
    }

    throw new BadRequestException("Invalid sourceType");
  }

  private async enqueueJob(accountId: string, dto: CreatePresetJobDto, jobId: string) {
    await this.bus
      .sendJson(
        QUEUES.presets(),
        { jobId, accountId, sourceType: dto.sourceType, sourceId: dto.sourceId, presetKey: dto.presetKey },
        { messageId: `${jobId}:${Date.now()}` },
      )
      .catch(() => undefined);
  }

  async createJob(accountId: string, userId: string, dto: CreatePresetJobDto) {
    const presets = await this.resolvePresets(accountId, dto.destinationId);
    const preset = presets.find((p) => p.key === dto.presetKey);
    if (!preset) throw new BadRequestException(`Unknown presetKey: ${dto.presetKey}`);

    const source = await this.getSourceSnapshot(accountId, dto.sourceType, dto.sourceId);

    const payload = {
      ...dto,
      preset: {
        key: preset.key,
        label: preset.label,
        ext: preset.ext,
        mimeType: preset.mimeType,
      },
      source,
      requestedAt: new Date().toISOString(),
    };

    // Create job (unique by accountId+sourceType+sourceId+presetKey)
    try {
      const created = await this.prisma.presetDownloadJob.create({
        data: {
          accountId,
          sourceType: dto.sourceType as any,
          sourceId: dto.sourceId,
          destinationId: dto.destinationId ?? null,
          presetKey: dto.presetKey,
          status: MediaJobStatus.PENDING,
          payload: payload as any,
          createdByUserId: userId,
        },
      });
      await this.enqueueJob(accountId, dto, created.id);
      return created;

    } catch (e: any) {
      // If already exists, return existing job
      if (String(e?.code) === "P2002") {
        const existing = await this.prisma.presetDownloadJob.findFirst({
          where: {
            accountId,
            sourceType: dto.sourceType as any,
            sourceId: dto.sourceId,
            presetKey: dto.presetKey,
          },
        });
        if (existing) {
          const st = String(existing.status || "").toUpperCase();
          const hasError = !!String((existing as any).error || "").trim();
          let job = existing;

          if (
            st === "FAILED" ||
            st === "CANCELLED" ||
            st === "CANCELED" ||
            ((st === "PENDING" || st === "QUEUED" || st === "RUNNING") && hasError)
          ) {
            job = await this.prisma.presetDownloadJob.update({
              where: { id: existing.id },
              data: {
                destinationId: dto.destinationId ?? null,
                status: MediaJobStatus.PENDING,
                payload: payload as any,
                error: null,
                runAfter: null,
                startedAt: null,
                endedAt: null,
                result: null,
                attempts: 0,
              } as any,
            });
            await this.enqueueJob(accountId, dto, job.id);
            return job;
          }

          return existing;
        }
      }
      throw e;
    }
  }
  async listJobs(
    accountId: string,
    opts: { sourceType?: CreatePresetJobDto["sourceType"]; sourceIds: string[] },
  ) {
    const sourceIds = (opts?.sourceIds || []).map((s) => String(s).trim()).filter(Boolean);
    if (!sourceIds.length) return { jobs: [] as any[] };

    const sourceType = (opts?.sourceType || "CREATIVE") as any;

    const jobs = await this.prisma.presetDownloadJob.findMany({
      where: {
        accountId,
        sourceType,
        sourceId: { in: sourceIds },
      },
      orderBy: { createdAt: "desc" },
    });

    return { jobs };
  }



  async getJob(accountId: string, id: string) {
    const j = await this.prisma.presetDownloadJob.findFirst({ where: { id, accountId } });
    if (!j) throw new NotFoundException("Job not found");
    return j;
  }
}
