import { Body, Controller, Get, Inject, NotFoundException, Param, Post, Query, Req, Res, UseGuards } from "@nestjs/common";
import { JwtAuthGuard } from "../../common/auth/jwt-auth.guard";
import { PermissionsGuard } from "../../common/auth/permissions.guard";
import { RequirePermissions } from "../../common/auth/require-permissions.decorator";
import { CurrentUser, type AuthUser } from "../../common/auth/current-user.decorator";
import { PresetsService } from "./presets.service";
import { CreatePresetJobDto } from "./dto/create-preset-job.dto";
import { createReadStream } from "node:fs";
import * as fs from "node:fs/promises";
import * as path from "node:path";
import { STORAGE } from "../../common/storage/storage.token";
import type { StorageService } from "../../common/storage/storage.types";
import { SignedStreamService } from "../../common/stream/signed-stream.service";

const PRESET_OUTPUT_EXPIRED_MESSAGE = "Transcoded file expired as per retention policy. Please re-run transcode.";

function isMissingFileError(e: any) {
  const code = String(e?.code || e?.details?.errorCode || "");
  if (code === "ENOENT" || code === "BlobNotFound" || code === "ResourceNotFound") return true;
  if (e?.statusCode === 404 || e?.status === 404) return true;
  return false;
}

function buildPresetLogFallback(result: any, jobError?: string) {
  const embedded = String(result?.embeddedLogText || "").trim();
  if (embedded) return embedded;

  const failure = result?.failure || {};
  const tail = String(result?.logTail || failure?.stderrTail || failure?.stdoutTail || "").trim();
  const lines = [
    `Status: ${String(failure?.message || jobError ? "FAILED" : "UNKNOWN")}`,
    `Message: ${String(failure?.message || jobError || "No log available yet.")}`,
  ];

  if (failure?.tool) lines.push(`Tool: ${failure.tool}`);
  if (failure?.binary) lines.push(`Binary: ${failure.binary}`);
  if (failure?.stepKey) lines.push(`Step key: ${failure.stepKey}`);
  if (failure?.stepLabel) lines.push(`Step label: ${failure.stepLabel}`);
  if (failure?.exitCode !== undefined && failure?.exitCode !== null) lines.push(`Exit code: ${failure.exitCode}`);
  if (failure?.inputPath) lines.push(`Input: ${failure.inputPath}`);
  if (failure?.outputPath) lines.push(`Output: ${failure.outputPath}`);
  if (failure?.command) lines.push(`Command: ${failure.command}`);
  if (tail) lines.push("", "--- stderr tail ---", tail);

  return lines.join("\n");
}

@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller("presets")
export class PresetsController {
  constructor(private svc: PresetsService, @Inject(STORAGE) private storage: StorageService, private signed: SignedStreamService) {}

  private async ensureOutputAvailable(outPath: string) {
    const p = String(outPath || "").trim();
    if (!p) throw new NotFoundException(PRESET_OUTPUT_EXPIRED_MESSAGE);

    try {
      if (this.storage.isCloud() && !path.isAbsolute(p)) {
        const exists = await this.storage.exists(p);
        if (!exists) throw new NotFoundException(PRESET_OUTPUT_EXPIRED_MESSAGE);
        return;
      }

      await fs.access(p);
    } catch (e: any) {
      if (e instanceof NotFoundException) throw e;
      if (isMissingFileError(e)) throw new NotFoundException(PRESET_OUTPUT_EXPIRED_MESSAGE);
      throw e;
    }
  }

  @Get()
  @RequirePermissions("action:presets:request")
  async getAccountPresets(@CurrentUser() user: AuthUser) {
    return this.svc.getAccountPresets(user.accountId);
  }

  @Get("destinations/:destinationId")
  @RequirePermissions("action:presets:request")
  async getDestinationPresets(@CurrentUser() user: AuthUser, @Param("destinationId") destinationId: string) {
    return this.svc.getDestinationPresets(user.accountId, destinationId);
  }

  @Post("jobs")
  @RequirePermissions("action:presets:request")
  async createJob(@CurrentUser() user: AuthUser, @Body() dto: CreatePresetJobDto) {
    return this.svc.createJob(user.accountId, user.id, dto);
  }

  @Get("jobs")
  @RequirePermissions("action:presets:request")
  async listJobs(
    @CurrentUser() user: AuthUser,
    @Query("sourceType") sourceTypeRaw: string | undefined,
    @Query("sourceIds") sourceIdsRaw: string | undefined,
  ) {
    const sourceType = String(sourceTypeRaw || "CREATIVE").toUpperCase();
    const sourceIds = String(sourceIdsRaw || "")
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);

    return this.svc.listJobs(user.accountId, { sourceType: sourceType as any, sourceIds });
  }

  @Get("jobs/:id")
  @RequirePermissions("action:presets:request")
  async getJob(@CurrentUser() user: AuthUser, @Param("id") id: string) {
    return this.svc.getJob(user.accountId, id);
  }

  @Get("jobs/:id/stream-url")
  @RequirePermissions("action:presets:download", "action:media:download")
  async streamUrl(@CurrentUser() user: AuthUser, @Param("id") id: string) {
    const j = await this.svc.getJob(user.accountId, id);
    const r: any = j.result || {};
    const outPath = r?.outputBlobKey || r?.outputPath;
    const mimeType = (j.result as any)?.mimeType || "application/octet-stream";
    if (!outPath) return { url: null };

    const filename = r?.filename || path.basename(String(outPath));
    await this.ensureOutputAvailable(String(outPath));

    if (this.storage.isCloud() && !path.isAbsolute(String(outPath))) {
      const url = await this.storage.getSignedReadUrl(String(outPath), 30, {
        contentType: mimeType,
        contentDisposition: `attachment; filename="${filename}"`,
      });
      return { url };
    }

    const url = this.signed.makeUrl({
      path: String(outPath),
      mimeType,
      filename,
      disposition: "attachment",
      ttlSeconds: 300,
    });
    return { url };
  }

  @Get("jobs/:id/stream")
  @RequirePermissions("action:presets:download", "action:media:download")
  async stream(@CurrentUser() user: AuthUser, @Param("id") id: string, @Req() req: any, @Res() res: any) {
    const j = await this.svc.getJob(user.accountId, id);
    const r: any = j.result || {};
    const outPath = r?.outputBlobKey || r?.outputPath;
    const mimeType = (j.result as any)?.mimeType || "application/octet-stream";
    if (!outPath) return res.status(404).json({ message: PRESET_OUTPUT_EXPIRED_MESSAGE });

    try {
      await this.ensureOutputAvailable(String(outPath));
    } catch (e: any) {
      if (e instanceof NotFoundException) {
        return res.status(404).json({ message: PRESET_OUTPUT_EXPIRED_MESSAGE });
      }
      throw e;
    }

    if (this.storage.isCloud() && !path.isAbsolute(String(outPath))) {
      const url = await this.storage.getSignedReadUrl(String(outPath), 30, {
        contentType: mimeType,
        contentDisposition: `inline; filename="${r?.filename || path.basename(String(outPath))}"`,
      });
      return res.redirect(302, url);
    }

    const stat = await fs.stat(outPath);
    res.setHeader("Content-Type", mimeType);
    res.setHeader("Content-Length", stat.size);
    createReadStream(outPath).pipe(res);
  }

  @Get("jobs/:id/log-url")
  @RequirePermissions("action:presets:request")
  async logUrl(@CurrentUser() user: AuthUser, @Param("id") id: string) {
    const j: any = await this.svc.getJob(user.accountId, id);
    const r: any = j?.result || {};
    const status = String(j?.status || "").toUpperCase();

    const logPath: string | undefined =
      r?.logBlobKey ||
      r?.logPath ||
      r?.log?.absPath ||
      (r?.log?.root && r?.log?.relPath ? path.join(String(r.log.root), String(r.log.relPath)) : undefined);

    if (status === "FAILED" || String(j?.error || "").trim()) {
      if (!logPath) return { url: null };
      if (this.storage.isCloud() && !path.isAbsolute(String(logPath))) {
        const filename = path.basename(String(logPath));
        const url = await this.storage.getSignedReadUrl(String(logPath), 30, {
          contentType: "text/plain",
          contentDisposition: `inline; filename="${filename}"`,
        });
        return { url };
      }
      return { url: null };
    }

    if (!logPath) return { url: null };

    const filename = path.basename(String(logPath));

    if (this.storage.isCloud() && !path.isAbsolute(String(logPath))) {
      const url = await this.storage.getSignedReadUrl(String(logPath), 30, {
        contentType: "text/plain",
        contentDisposition: `inline; filename="${filename}"`,
      });
      return { url };
    }

    const url = this.signed.makeUrl({
      path: String(logPath),
      mimeType: "text/plain",
      filename,
      disposition: "inline",
      ttlSeconds: 300,
    });
    return { url };
  }

  @Get("jobs/:id/log")
  @RequirePermissions("action:presets:request")
  async log(
    @CurrentUser() user: AuthUser,
    @Param("id") id: string,
    @Query("maxBytes") maxBytesRaw: string | undefined,
    @Res() res: any,
  ) {
    const j: any = await this.svc.getJob(user.accountId, id);
    const r: any = j?.result || {};

    const logPath: string | undefined =
      r?.logBlobKey ||
      r?.logPath ||
      r?.log?.absPath ||
      (r?.log?.root && r?.log?.relPath ? path.join(String(r.log.root), String(r.log.relPath)) : undefined);

    const tail = buildPresetLogFallback(r, j?.error);
    const status = String(j?.status || "").toUpperCase();

    if (status === "FAILED" && tail && String(tail).trim()) {
      res.setHeader("Content-Type", "text/plain; charset=utf-8");
      return res.send(String(tail));
    }

    if (!logPath) {
      if (tail && String(tail).trim()) {
        res.setHeader("Content-Type", "text/plain; charset=utf-8");
        return res.send(String(tail));
      }
      res.setHeader("Content-Type", "text/plain; charset=utf-8");
      return res.send("No log available yet.");
    }

    const maxBytes = Math.max(1_000, Math.min(1_000_000, Number(maxBytesRaw || 200_000)));

    if (this.storage.isCloud() && !path.isAbsolute(String(logPath))) {
      const url = await this.storage.getSignedReadUrl(String(logPath), 30, {
        contentType: "text/plain",
        contentDisposition: `inline; filename="${path.basename(String(logPath))}"`,
      });
      return res.redirect(302, url);
    }

    try {
      const st = await fs.stat(logPath);
      const start = Math.max(0, Number(st.size) - maxBytes);
      const fh = await fs.open(logPath, "r");
      try {
        const len = Number(st.size) - start;
        const buf = Buffer.alloc(len);
        await fh.read(buf, 0, len, start);
        res.setHeader("Content-Type", "text/plain; charset=utf-8");
        res.setHeader("Content-Disposition", `inline; filename="${path.basename(logPath)}"`);
        return res.send(buf.toString("utf8"));
      } finally {
        await fh.close();
      }
    } catch (e: any) {
      if (tail && String(tail).trim()) {
        res.setHeader("Content-Type", "text/plain; charset=utf-8");
        return res.send(String(tail));
      }
      res.setHeader("Content-Type", "text/plain; charset=utf-8");
      return res.send(`Log file not available: ${String(e?.message || e || logPath)}`);
    }
  }
}
