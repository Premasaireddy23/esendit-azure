import { Injectable, Logger, OnModuleInit } from "@nestjs/common";
import {
  CreativeAssetType,
  CreativeAssetUploadStatus,
  MediaJobStatus,
  PresetSourceType,
} from "@prisma/client";
import { PrismaService } from "../../common/prisma/prisma.service";
import { ServiceBusService } from "../../common/queue/service-bus.service";
import { QUEUES } from "../../common/queue/queue.constants";
import { MediaToolsService } from "../creatives/media/media-tools.service";
import * as path from "node:path";
import * as os from "node:os";
import * as fs from "node:fs";
import * as fsp from "node:fs/promises";
import { spawn } from "node:child_process";
import { DEFAULT_PRESETS } from "./presets.service";
import { Inject } from "@nestjs/common";
import { STORAGE } from "../../common/storage/storage.token";
import type { StorageService } from "../../common/storage/storage.types";

function formatCreationTime(d: Date) {
  // ffmpeg metadata commonly accepts "YYYY-MM-DD HH:MM:SS".
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getUTCFullYear()}-${pad(d.getUTCMonth() + 1)}-${pad(d.getUTCDate())} ${pad(
    d.getUTCHours()
  )}:${pad(d.getUTCMinutes())}:${pad(d.getUTCSeconds())}`;
}

function normalizeTimecode(v: any, fallback: string) {
  const s = String(v ?? "").trim();
  if (/^\d{2}:\d{2}:\d{2}:\d{2}$/.test(s)) return s;
  return fallback;
}

function safeRel(rootAbs: string, pAbs: string) {
  const r = path.resolve(rootAbs);
  const p = path.resolve(pAbs);
  if (p === r) return ".";
  if (p.startsWith(r + path.sep)) return path.relative(r, p);
  return p; // not under root
}

function sanitizeName(v: string, maxLen = 80) {
  const s = String(v || "")
    .trim()
    .replace(/\s+/g, " ")
    .replace(/[^\w.-]+/g, "_")
    .replace(/_+/g, "_")
    .replace(/^_+|_+$/g, "");
  return (s || "file").slice(0, maxLen);
}

async function endWriteStream(s: fs.WriteStream): Promise<void> {
  await new Promise<void>((resolve) => {
    try {
      s.end(() => resolve());
    } catch {
      resolve();
    }
  });
}

type PresetDef = {
  key: string;
  label?: string;
  tool?: "ffmpeg" | "ffmbc";
  binary?: string;
  args?: string[];
  steps?: any[];
  ext: string;
  mimeType: string;
};

type PresetPipelineStep = {
  key?: string;
  label?: string;
  tool?: "ffmpeg" | "ffmbc";
  binary?: string;
  input?: string;
  output?: string;
  ext?: string;
  args?: string[];
};

function parsePresets(downloadPresets: any): PresetDef[] {
  return Array.isArray(downloadPresets) ? (downloadPresets as PresetDef[]) : [];
}

function pickPresetsByKeys(all: PresetDef[], keys: any): PresetDef[] {
  const list = Array.isArray(keys) ? keys.map((k) => String(k).trim()).filter(Boolean) : [];
  if (!list.length) return [];
  const map = new Map(all.map((p) => [p.key, p] as const));
  const seen = new Set<string>();
  const out: PresetDef[] = [];
  for (const k of list) {
    if (seen.has(k)) continue;
    const p = map.get(k);
    if (!p) continue;
    out.push(p);
    seen.add(k);
  }
  return out;
}

@Injectable()
export class PresetWorkerService implements OnModuleInit {
  private readonly log = new Logger(PresetWorkerService.name);
  private running = false;
  private serial: Promise<void> = Promise.resolve();

  constructor(
    private prisma: PrismaService,
    private tools: MediaToolsService,
    @Inject(STORAGE) private storage: StorageService,
    private readonly bus: ServiceBusService,
  ) {}

  onModuleInit() {
    if (process.env.NODE_ENV === "test") return;

    if ((process.env.PRESET_WORKER_ENABLED || "true").toLowerCase() === "false") {
      this.log.log("PRESET_WORKER_ENABLED=false; worker not started");
      return;
    }

    if (this.bus.isEnabled()) {
      this.bus
        .subscribeJson(QUEUES.presets(), async (msg) => {
          const resolvedJobId = await this.resolveJobIdFromMessage(msg);
          if (!resolvedJobId) return;
          const run = this.serial.then(() => this.tick(resolvedJobId));
          this.serial = run.catch(() => undefined);
          await run;
        })
        .catch((e) => this.log.error(e));
      this.log.log(`Preset worker started (service bus: ${QUEUES.presets()})`);
      return;
    }


    setInterval(() => this.tick().catch((e) => this.log.error(e)), 2000);
    this.log.log("Preset worker started (polling every 2s)");
  }


  private async resolveJobIdFromMessage(msg: any): Promise<string | undefined> {
    const jobId = msg?.jobId ? String(msg.jobId) : undefined;
    if (jobId) return jobId;

    const accountId = msg?.accountId ? String(msg.accountId) : undefined;
    const sourceType = msg?.sourceType ? String(msg.sourceType) : undefined;
    const sourceId = msg?.sourceId ? String(msg.sourceId) : undefined;
    const presetKey = msg?.presetKey ? String(msg.presetKey) : undefined;
    if (!accountId || !sourceType || !sourceId || !presetKey) return undefined;

    const job = await this.prisma.presetDownloadJob.findFirst({
      where: { accountId, sourceType: sourceType as any, sourceId, presetKey, status: MediaJobStatus.PENDING },
      orderBy: { createdAt: "asc" },
      select: { id: true },
    });
    return job?.id ? String(job.id) : undefined;
  }

  private getOutputRoot(uploadDir: string) {
    // Backward compatible default: uploads/preset-downloads
    return (
      process.env.TRANSCODE_OUTPUT_DIR ||
      process.env.PRESET_OUTPUT_DIR ||
      path.join(uploadDir, "preset-downloads")
    );
  }

  private getCloudOutputKey(job: any, filename: string) {
    // accounts/{accountId}/presets/jobs/{jobId}/{filename}
    return `accounts/${job.accountId}/presets/jobs/${job.id}/${filename}`;
  }

  private getCloudLogKey(job: any, filename: string) {
    return `accounts/${job.accountId}/presets/jobs/${job.id}/logs/${filename}`;
  }

  private getLogRoot(outputRoot: string) {
    return (
      process.env.TRANSCODE_LOG_DIR ||
      process.env.PRESET_LOG_DIR ||
      path.join(outputRoot, "logs")
    );
  }

  private async tick(jobId?: string) {
    if (this.running) return;
    this.running = true;

    let job: any = null;

    try {
      if (jobId) {
        job = await this.prisma.presetDownloadJob.findUnique({ where: { id: jobId } });
      }

      if (!job) job = await this.prisma.presetDownloadJob.findFirst({
        where: {
          status: MediaJobStatus.PENDING,
          OR: [{ runAfter: null }, { runAfter: { lte: new Date() } }],
        },
        orderBy: { createdAt: "asc" },
      });

      if (!job) return;

      // claim atomically
      const claimed = await this.prisma.presetDownloadJob.updateMany({
        where: { id: job.id, status: MediaJobStatus.PENDING },
        data: {
          status: MediaJobStatus.RUNNING,
          startedAt: new Date(),
          attempts: { increment: 1 },
        },
      });
      if (claimed.count !== 1) return;

      // re-fetch snapshot after claim
      job = await this.prisma.presetDownloadJob.findUnique({ where: { id: job.id } });
      if (!job) return;

      const presets = await this.resolvePresetsForJob(job);
      const preset = presets.find((p) => p.key === job.presetKey);
      if (!preset) throw new Error(`Preset not found: ${job.presetKey}`);

      const inputPath = await this.resolveInputPath(job.accountId, job.sourceType, job.sourceId);

      // Cloud mode: DB stores blob keys (relative paths like "creatives/..." or "accounts/..."),
      // not absolute filesystem paths. ffmpeg/ffprobe need a local file, so download to /tmp.
      let inputLocalPath = String(inputPath);
      let inputTmpDir: string | null = null;
      if (this.storage.isCloud() && !path.isAbsolute(inputLocalPath) && !/^https?:\/\//i.test(inputLocalPath)) {
        inputTmpDir = path.join(os.tmpdir(), "esendit", "presets", String(job.id));
        await fsp.mkdir(inputTmpDir, { recursive: true });
        const extGuess = path.extname(inputLocalPath) || ".bin";
        inputLocalPath = path.join(inputTmpDir, `input${extGuess}`);
        await this.storage.downloadToFile(String(inputPath), inputLocalPath);
      }

      await fsp.stat(inputLocalPath); // ensure exists

      const uploadDir = process.env.UPLOAD_DIR || "uploads";
      const uploadRootAbs = path.resolve(uploadDir);
      const outputRoot = this.getOutputRoot(uploadDir);
      const outputRootAbs = path.resolve(outputRoot);
      const logRoot = this.getLogRoot(outputRootAbs);
      const logRootAbs = path.resolve(logRoot);

      // Put outputs under account+source folder so it is easy to browse
      const outDir = path.join(outputRootAbs, job.accountId, String(job.sourceType).toLowerCase(), job.sourceId);
      const logDir = path.join(
        logRootAbs,
        job.accountId,
        String(job.sourceType).toLowerCase(),
        job.sourceId,
      );
      await fsp.mkdir(outDir, { recursive: true });
      await fsp.mkdir(logDir, { recursive: true });

      const safeKey = sanitizeName(String(job.presetKey || "preset").replace(/\.bat$/i, ""), 60);
      const ext = String(preset.ext || "bin").replace(/^\./, "");

      const friendly = await this.resolveFriendlySourceName(job);
      const baseName = sanitizeName(`${friendly}-${safeKey}`, 120);
      const outPath = path.join(outDir, `${baseName}-${String(job.id).slice(0, 8)}.${ext}`);
      const attempt = Number(job.attempts || 1);
      const ts = new Date()
        .toISOString()
        .replace(/[.]/g, "")
        .replace(/[-:]/g, "");
      const logBase = sanitizeName(`${friendly}-${safeKey}`, 120);
      const logPath = path.join(logDir, `${logBase}-${ts}-a${attempt}.log`);
      const logStream = fs.createWriteStream(logPath, { flags: "w" });

      // Ensure the log file is actually opened; createWriteStream emits errors asynchronously.
      await new Promise<void>((resolve, reject) => {
        logStream.once("open", () => resolve());
        logStream.once("error", (err) => reject(err));
      });

      // Surface stream errors in server logs (otherwise they can be silent)
      logStream.on("error", (err) => {
        try {
          this.log.error(`[preset-log] ${String(err?.message || err)}`);
        } catch {
          // ignore
        }
      });

      let pipelineTemps: string[] = [];
      let jobSucceeded = false;
      let finalDurationMs = 0;
      try {
        const initialDurationMs = await this.getDurationMs(inputLocalPath);
        finalDurationMs = initialDurationMs;
        const initialResult: any = {
        host: {
          hostname: os.hostname(),
          pid: process.pid,
        },
        input: {
          // In cloud mode, `absPath` is a blob key. In local mode it's a filesystem path.
          absPath: inputPath,
          localPath: inputLocalPath !== String(inputPath) ? inputLocalPath : undefined,
          root: uploadRootAbs,
          relPath: safeRel(uploadRootAbs, inputLocalPath),
        },
        output: {
          absPath: outPath,
          root: outputRootAbs,
          relPath: safeRel(outputRootAbs, outPath),
        },
        logPath: logPath,
        log: {
          absPath: logPath,
          root: logRootAbs,
          relPath: safeRel(logRootAbs, logPath),
        },
        preset: {
          key: preset.key,
          label: preset.label,
          ext: ext,
          mimeType: preset.mimeType,
        },
        progress: {
          pct: 0,
          outTimeMs: 0,
          durationMs: initialDurationMs,
          updatedAt: new Date().toISOString(),
        },
        pipeline: {
          totalSteps: Array.isArray(preset.steps) && preset.steps.length ? preset.steps.length : 1,
          currentStepIndex: 0,
          currentStepKey: null,
          currentStepLabel: null,
        },
      };

        await this.prisma.presetDownloadJob.update({
          where: { id: job.id },
          data: { result: initialResult as any, error: null },
        });

        // Write header to log
        logStream.write(
          `
[${new Date().toISOString()}] START job=${job.id} preset=${preset.key} source=${job.sourceType}:${job.sourceId}
`
        );
        logStream.write(`[meta] input=${inputPath}
`);
        if (inputLocalPath !== String(inputPath)) logStream.write(`[meta] inputLocal=${inputLocalPath}
`);
        logStream.write(`[meta] output=${outPath}
`);
        logStream.write(`[meta] initialDurationMs=${initialDurationMs}
`);

        if (Array.isArray(preset.steps) && preset.steps.length) {
          pipelineTemps = await this.runPresetPipeline({
            jobId: job.id,
            job,
            preset,
            inputPath: inputLocalPath,
            outPath,
            outDir,
            logStream,
            initialResult,
          });
          finalDurationMs = await this.getDurationMs(outPath);
        } else {
          const expandedArgs = this.expandArgsForJob(preset.args || [], job, preset);
          const presetTool = String(preset.tool || "ffmpeg").trim().toLowerCase();
          logStream.write(
            `[cmd] ${presetTool} ${presetTool === "ffmbc" ? "-y -i" : "-hide_banner -y -i"} "${inputLocalPath}" ${expandedArgs
              .map((a) => JSON.stringify(a))
              .join(" ")} "${outPath}"

`
          );

          if (presetTool === "ffmbc") {
            await this.runCliWithoutProgress({
              tool: presetTool,
              binary: preset.binary,
              inputPath: inputLocalPath,
              outPath,
              expandedArgs,
              logStream,
            });
            await this.prisma.presetDownloadJob.update({
              where: { id: job.id },
              data: {
                result: {
                  ...(initialResult as any),
                  progress: {
                    ...((initialResult as any)?.progress || {}),
                    pct: 100,
                    outTimeMs: initialDurationMs,
                    durationMs: initialDurationMs,
                    updatedAt: new Date().toISOString(),
                  },
                } as any,
              },
            });
          } else {
            await this.runFfmpegWithProgress({
              jobId: job.id,
              inputPath: inputLocalPath,
              outPath,
              expandedArgs,
              durationMs: initialDurationMs,
              logStream,
              initialResult,
              pctBase: 0,
              pctSpan: 100,
            });
          }
          finalDurationMs = initialDurationMs;
        }

        // Ensure log is flushed before we upload it (cloud mode) or before we return.
        logStream.write(`\n[${new Date().toISOString()}] DONE\n`);
        await endWriteStream(logStream);

        const st = await fsp.stat(outPath);

        let outputBlobKey: string | undefined;
        let logBlobKey: string | undefined;
        if (this.storage.isCloud()) {
          // Store outputs under a predictable blob prefix.
          const safeKey = sanitizeName(String(job.presetKey || "preset").replace(/\.bat$/i, ""), 60);
          const friendly = await this.resolveFriendlySourceName(job);
          const baseName = sanitizeName(`${friendly}-${safeKey}`, 120);
          const ext = String(preset.ext || "bin").replace(/^\./, "");


          const outContainer =
            process.env.TRANSCODE_OUTPUT_CONTAINER || process.env.PRESET_OUTPUT_CONTAINER || "";
          const logContainer =
            process.env.TRANSCODE_LOG_CONTAINER || process.env.PRESET_LOG_CONTAINER || outContainer || "";

          const outPrefix = outContainer ? `${outContainer}::` : "";
          const logPrefix = logContainer ? `${logContainer}::` : outPrefix;

          outputBlobKey = `${outPrefix}accounts/${job.accountId}/presets/jobs/${job.id}/${baseName}.${ext}`;
          logBlobKey = `${logPrefix}accounts/${job.accountId}/presets/jobs/${job.id}/${baseName}.log`;

          await this.storage.uploadFile(outputBlobKey, outPath, preset.mimeType || "application/octet-stream");
          await this.storage.uploadFile(logBlobKey, logPath, "text/plain");
        }
        const finalResult: any = {
          ...(initialResult || {}),
          mimeType: preset.mimeType || "application/octet-stream",
          filename: path.basename(outPath),
          bytes: Number(st.size),
          progress: {
            ...(initialResult?.progress || {}),
            pct: 100,
            outTimeMs: finalDurationMs,
            updatedAt: new Date().toISOString(),
          },
        };

        await this.prisma.presetDownloadJob.update({
          where: { id: job.id },
          data: {
            status: MediaJobStatus.SUCCEEDED,
            endedAt: new Date(),
            runAfter: null,
            result: {
              // keep legacy fields for existing frontend
              outputPath: this.storage.isCloud() ? outputBlobKey : outPath,
              filename: this.storage.isCloud() ? path.basename(String(outputBlobKey)) : path.basename(outPath),
              mimeType: preset.mimeType || "application/octet-stream",
              bytes: Number(st.size),
              outputBlobKey,
              logBlobKey,
              // new fields
              ...finalResult,
            } as any,
            error: null,
          },
        });
        jobSucceeded = true;
      } finally {
        // Ensure we don't leak file descriptors on failures.
        try {
          if (!logStream.writableEnded) logStream.end();
        } catch {
          // ignore
        }

        // Clean up ephemeral files in cloud mode (ACA /tmp)
        if (this.storage.isCloud()) {
          // Remove temp files created under /tmp.
          // `inputLocalPath` can differ from `inputPath` (blob key).
          if (inputLocalPath && inputLocalPath !== String(inputPath)) {
            await fsp.rm(inputLocalPath, { force: true }).catch(() => undefined);
          }
          if (inputTmpDir) {
            await fsp.rm(inputTmpDir, { recursive: true, force: true }).catch(() => undefined);
          }
          for (const tempPath of pipelineTemps) {
            await fsp.rm(tempPath, { force: true }).catch(() => undefined);
          }
          await fsp.rm(outPath, { force: true }).catch(() => undefined);
          await fsp.rm(logPath, { force: true }).catch(() => undefined);
        } else if (jobSucceeded) {
          for (const tempPath of pipelineTemps) {
            await fsp.rm(tempPath, { force: true }).catch(() => undefined);
          }
        }
      }
    } catch (e: any) {
      const msg = String(e?.message || e || "UNKNOWN_ERROR").slice(0, 2000);
      this.log.error(msg);

      if (job?.id) {
        const attemptsNow = Number(job.attempts || 0) + 1; // claimed increments, but job is old snapshot
        const maxAttempts = Number(job.maxAttempts || 3);

        if (attemptsNow < maxAttempts) {
          const backoffMs = Math.min(60_000, 1000 * Math.pow(2, attemptsNow)); // 2s,4s,8s.. capped
          await this.prisma.presetDownloadJob.update({
            where: { id: job.id },
            data: {
              status: MediaJobStatus.PENDING,
              runAfter: new Date(Date.now() + backoffMs),
              endedAt: new Date(),
              error: msg,
            },
          });
        } else {
          await this.prisma.presetDownloadJob.update({
            where: { id: job.id },
            data: {
              status: MediaJobStatus.FAILED,
              endedAt: new Date(),
              error: msg,
            },
          });
        }
      }
    } finally {
      this.running = false;
    }
  }


  private resolveToolBinary(tool?: string, explicitBinary?: string): string {
    const normalized = String(tool || "ffmpeg").trim().toLowerCase();
    if (explicitBinary && String(explicitBinary).trim()) return String(explicitBinary).trim();
    if (normalized === "ffmbc") return String(process.env.FFMBC_BIN || "ffmbc").trim();
    return String(process.env.FFMPEG_BIN || "ffmpeg").trim();
  }

  private async runCliWithoutProgress(opts: {
    tool?: string;
    binary?: string;
    inputPath: string;
    outPath: string;
    expandedArgs: string[];
    logStream: fs.WriteStream;
  }) {
    const tool = String(opts.tool || "ffmpeg").trim().toLowerCase();
    const bin = this.resolveToolBinary(tool, opts.binary);
    const cliArgs = [
      ...(tool === "ffmbc" ? [] : ["-hide_banner"]),
      "-y",
      "-i",
      opts.inputPath,
      ...opts.expandedArgs,
      opts.outPath,
    ];

    const proc = spawn(bin, cliArgs, { stdio: ["ignore", "pipe", "pipe"] });
    proc.stdout.setEncoding("utf8");
    proc.stderr.setEncoding("utf8");

    proc.stdout.on("data", (chunk: string) => {
      opts.logStream.write(chunk);
    });
    proc.stderr.on("data", (chunk: string) => {
      opts.logStream.write(chunk);
    });

    const code: number = await new Promise((resolve, reject) => {
      proc.on("error", (err: any) => {
        if (err && err.code === "ENOENT") {
          return reject(new Error(`${tool} binary not found: ${bin}. Set ${tool === "ffmbc" ? "FFMBC_BIN" : "FFMPEG_BIN"} or add ${tool} to the worker image.`));
        }
        reject(err);
      });
      proc.on("close", resolve);
    });

    if (code !== 0) {
      throw new Error(`${tool} failed with exit code ${code}`);
    }
  }

  private async runFfmpegWithProgress(opts: {
    jobId: string;
    inputPath: string;
    outPath: string;
    expandedArgs: string[];
    durationMs: number;
    logStream: fs.WriteStream;
    initialResult: any;
    pctBase?: number;
    pctSpan?: number;
  }) {
    const { jobId, inputPath, outPath, expandedArgs, durationMs, logStream } = opts;

    const ffArgs = [
      "-hide_banner",
      "-y",
      "-i",
      inputPath,
      ...expandedArgs,
      "-progress",
      "pipe:1",
      "-nostats",
      outPath,
    ];

    // Throttle DB updates to avoid write storms
    let lastDbUpdate = 0;
    let lastOutTimeMs = 0;
    let speed = "";
    let fps = "";
    let bitrate = "";

    let stdoutBuf = "";
    let stderrTail = "";

    const updateDb = async (force = false) => {
      const now = Date.now();
      if (!force && now - lastDbUpdate < 2000) return;
      lastDbUpdate = now;

      const pctBase = Number.isFinite(opts.pctBase as number) ? Number(opts.pctBase) : 0;
      const pctSpan = Number.isFinite(opts.pctSpan as number) ? Number(opts.pctSpan) : 100;
      const stepPct = durationMs > 0 ? Math.max(0, Math.min(100, Math.round((lastOutTimeMs / durationMs) * 100))) : 0;
      const pct = Math.max(0, Math.min(100, Math.round(pctBase + (stepPct * pctSpan) / 100)));

      const patch: any = {
        ...(opts.initialResult || {}),
        progress: {
          pct,
          outTimeMs: lastOutTimeMs,
          durationMs,
          speed,
          fps,
          bitrate,
          updatedAt: new Date().toISOString(),
        },
        logTail: stderrTail.slice(-4000),
      };

      await this.prisma.presetDownloadJob.update({
        where: { id: jobId },
        data: { result: patch as any },
      });
    };

    const ffmpegBin = this.resolveToolBinary("ffmpeg");
    const proc = spawn(ffmpegBin, ffArgs, { stdio: ["ignore", "pipe", "pipe"] });

    proc.stdout.setEncoding("utf8");
    proc.stderr.setEncoding("utf8");

    proc.stdout.on("data", async (chunk: string) => {
      logStream.write(chunk);
      stdoutBuf += chunk;
      const lines = stdoutBuf.split(/\r?\n/);
      stdoutBuf = lines.pop() || "";

      for (const line of lines) {
        const idx = line.indexOf("=");
        if (idx <= 0) continue;
        const k = line.slice(0, idx).trim();
        const v = line.slice(idx + 1).trim();

        if (k === "out_time_ms") {
          const ms = Number(v);
          if (Number.isFinite(ms)) lastOutTimeMs = ms;
        } else if (k === "speed") {
          speed = v;
        } else if (k === "fps") {
          fps = v;
        } else if (k === "bitrate") {
          bitrate = v;
        } else if (k === "progress" && v === "end") {
          // push one last update
          await updateDb(true);
        }
      }

      // best-effort update (throttled)
      try {
        await updateDb(false);
      } catch {
        // ignore, next tick will retry
      }
    });

    proc.stderr.on("data", (chunk: string) => {
      logStream.write(chunk);
      stderrTail = (stderrTail + chunk).slice(-8000);
    });

    const code: number = await new Promise((resolve, reject) => {
      proc.on("error", (err: any) => {
        if (err && err.code === "ENOENT") {
          return reject(new Error(`ffmpeg binary not found: ${ffmpegBin}. Set FFMPEG_BIN or add ffmpeg to the worker image.`));
        }
        reject(err);
      });
      proc.on("close", resolve);
    });

    // Final update
    await updateDb(true);

    if (code !== 0) {
      throw new Error(`ffmpeg failed with exit code ${code}`);
    }
  }

  private async runPresetPipeline(opts: {
    jobId: string;
    job: any;
    preset: PresetDef;
    inputPath: string;
    outPath: string;
    outDir: string;
    logStream: fs.WriteStream;
    initialResult: any;
  }): Promise<string[]> {
    const steps = (Array.isArray(opts.preset.steps) ? opts.preset.steps : []) as PresetPipelineStep[];
    if (!steps.length) return [];

    const tempPaths = new Map<string, string>();
    const totalSteps = steps.length;

    const resolveInput = (ref: string | undefined) => {
      const key = String(ref || "source").trim();
      if (!key || key === "source") return opts.inputPath;
      const hit = tempPaths.get(key);
      if (!hit) throw new Error(`Preset step input not found: ${key}`);
      return hit;
    };

    const resolveOutput = (step: PresetPipelineStep, index: number) => {
      const outRef = String(step.output || `step${index + 1}`).trim();
      if (outRef === "final") return { ref: outRef, path: opts.outPath };
      const ext = String(step.ext || opts.preset.ext || "bin").replace(/^\./, "") || "bin";
      const stepKey = sanitizeName(String(step.key || outRef || `step${index + 1}`), 40);
      const tempPath = path.join(
        opts.outDir,
        `${path.parse(opts.outPath).name}-${String(index + 1).padStart(2, "0")}-${stepKey}.${ext}`,
      );
      tempPaths.set(outRef, tempPath);
      return { ref: outRef, path: tempPath };
    };

    for (let i = 0; i < totalSteps; i++) {
      const step = steps[i] || {};
      const stepKey = sanitizeName(String(step.key || `step${i + 1}`), 40);
      const stepLabel = String(step.label || step.key || `Step ${i + 1}`).trim();
      const stepInput = resolveInput(step.input);
      const stepOutput = resolveOutput(step, i);
      const expandedArgs = this.expandArgsForJob(Array.isArray(step.args) ? step.args : [], opts.job, opts.preset);
      const stepDurationMs = await this.getDurationMs(stepInput);
      const pctBase = Math.round((i * 100) / totalSteps);
      const pctSpan = i === totalSteps - 1 ? 100 - pctBase : Math.round(100 / totalSteps);
      const stepResult = {
        ...(opts.initialResult || {}),
        pipeline: {
          totalSteps,
          currentStepIndex: i + 1,
          currentStepKey: stepKey,
          currentStepLabel: stepLabel,
        },
      };

      await this.prisma.presetDownloadJob.update({
        where: { id: opts.jobId },
        data: {
          result: {
            ...(stepResult as any),
            progress: {
              ...((stepResult as any)?.progress || {}),
              pct: pctBase,
              outTimeMs: 0,
              durationMs: stepDurationMs,
              updatedAt: new Date().toISOString(),
            },
          } as any,
        },
      });

      const stepTool = String(step.tool || "ffmpeg").trim().toLowerCase();
      opts.logStream.write(`
[${new Date().toISOString()}] STEP ${i + 1}/${totalSteps} ${stepLabel}
`);
      opts.logStream.write(`[cmd] ${stepTool} ${stepTool === "ffmbc" ? "-y -i" : "-hide_banner -y -i"} "${stepInput}" ${expandedArgs
        .map((a) => JSON.stringify(a))
        .join(" ")} "${stepOutput.path}"

`);

      if (stepTool === "ffmbc") {
        await this.runCliWithoutProgress({
          tool: stepTool,
          binary: step.binary,
          inputPath: stepInput,
          outPath: stepOutput.path,
          expandedArgs,
          logStream: opts.logStream,
        });
        await this.prisma.presetDownloadJob.update({
          where: { id: opts.jobId },
          data: {
            result: {
              ...(stepResult as any),
              progress: {
                ...((stepResult as any)?.progress || {}),
                pct: Math.max(0, Math.min(100, pctBase + pctSpan)),
                outTimeMs: stepDurationMs,
                durationMs: stepDurationMs,
                updatedAt: new Date().toISOString(),
              },
            } as any,
          },
        });
      } else {
        await this.runFfmpegWithProgress({
          jobId: opts.jobId,
          inputPath: stepInput,
          outPath: stepOutput.path,
          expandedArgs,
          durationMs: stepDurationMs,
          logStream: opts.logStream,
          initialResult: stepResult,
          pctBase,
          pctSpan,
        });
      }
    }

    return Array.from(tempPaths.values());
  }

  private expandArgsForJob(args: string[], job: any, preset: PresetDef): string[] {
    const payload = (job?.payload as any) || {};

    // Defaults: allow global override via env, and per-job override via payload.
    const defaultTimecode = preset.key.includes("_zee_") ? "10:00:00:00" : "00:00:00:00";
    const tc = normalizeTimecode(payload.timecode, normalizeTimecode(process.env.DEFAULT_TIMECODE, defaultTimecode));
    const ct = String(payload.creationTime || process.env.DEFAULT_CREATION_TIME || formatCreationTime(new Date()));

    return args.map((a) =>
      String(a)
        .replaceAll("{{TIMECODE}}", tc)
        .replaceAll("{{CREATION_TIME}}", ct)
    );
  }

  private async resolveFriendlySourceName(job: any): Promise<string> {
    // Try to use Creative.valid/caption for nicer filenames.
    if (String(job.sourceType) === "CREATIVE") {
      try {
        const c = await this.prisma.creative.findFirst({
          where: { id: job.sourceId, accountId: job.accountId },
          select: { valid: true, caption: true },
        });
        const v = (c?.valid || c?.caption || "creative") as any;
        return sanitizeName(String(v || "creative"), 80);
      } catch {
        // ignore
      }
    }
    return sanitizeName(`${String(job.sourceType).toLowerCase()}-${String(job.sourceId).slice(0, 8)}`, 80);
  }

  private async getDurationMs(inputPath: string): Promise<number> {
    try {
      const probe: any = await this.tools.ffprobeJson(inputPath);
      const dur = Number(probe?.format?.duration || 0);
      if (!Number.isFinite(dur) || dur <= 0) return 0;
      return Math.round(dur * 1000);
    } catch {
      return 0;
    }
  }

  private async resolvePresetsForJob(job: any): Promise<PresetDef[]> {
    // 1) Account global presets (the "library")
    const a = await this.prisma.account.findFirst({
      where: { id: job.accountId },
      select: { downloadPresets: true } as any,
    });
    const accountPresets = parsePresets((a as any)?.downloadPresets);
    const library = accountPresets.length ? accountPresets : (DEFAULT_PRESETS as any);

    // 2) Destination override (if set)
    if (job.destinationId) {
      const d = await this.prisma.destination.findFirst({
        where: { id: job.destinationId, accountId: job.accountId },
        select: { downloadPresets: true, config: true },
      });

      // Legacy: destination.downloadPresets is a full preset array
      const dp = parsePresets((d as any)?.downloadPresets);
      if (dp.length) return dp;

      // New: destination.config.allowedPresetKeys allow-list
      const keys = (d as any)?.config?.allowedPresetKeys;
      const filtered = pickPresetsByKeys(library, keys);
      if (filtered.length) return filtered;
    }

    // 3) Default to library
    return library;
  }

  private async resolveInputPath(accountId: string, sourceType: PresetSourceType, sourceId: string): Promise<string> {
    if (sourceType === "CREATIVE") {
      const a = await this.prisma.creativeAsset.findFirst({
        where: {
          accountId,
          creativeId: sourceId,
          type: CreativeAssetType.SOURCE,
          uploadStatus: CreativeAssetUploadStatus.UPLOADED,
        },
        select: { path: true },
      });
      if (!a?.path) throw new Error("Creative SOURCE asset not uploaded");
      return this.resolveInputPathMaybeDownload(String(a.path), "creative");
    }

    if (sourceType === "DAM") {
      const a = await this.prisma.damAsset.findFirst({
        where: {
          accountId,
          damItemId: sourceId,
          type: CreativeAssetType.SOURCE,
          uploadStatus: CreativeAssetUploadStatus.UPLOADED,
        },
        select: { path: true },
      });
      if (!a?.path) throw new Error("DAM SOURCE asset not uploaded");
      return this.resolveInputPathMaybeDownload(String(a.path), "dam");
    }

    if (sourceType === "BULK") {
      const a = await this.prisma.bulkUploadAsset.findFirst({
        where: {
          accountId,
          bulkItemId: sourceId,
          type: CreativeAssetType.SOURCE,
          uploadStatus: CreativeAssetUploadStatus.UPLOADED,
        },
        select: { path: true },
      });
      if (!a?.path) throw new Error("BULK SOURCE asset not uploaded");
      return this.resolveInputPathMaybeDownload(String(a.path), "bulk");
    }

    throw new Error(`Unsupported sourceType: ${String(sourceType)}`);
  }

  private async resolveInputPathMaybeDownload(p: string, tag: string): Promise<string> {
    if (!this.storage.isCloud()) return p;
    const ext = path.extname(p).replace(/^\./, "") || "bin";
    const tmp = path.join(os.tmpdir(), `esendit-preset-in-${tag}-${Date.now()}-${Math.random().toString(16).slice(2)}.${ext}`);
    await this.storage.downloadToFile(p, tmp);
    return tmp;
  }
}
