import { Module } from "@nestjs/common";
import { PresetsController } from "./presets.controller";
import { PresetsService } from "./presets.service";
import { PresetWorkerService } from "./preset-worker.service";
import { MediaToolsService } from "../creatives/media/media-tools.service";
import { StorageModule } from "../../common/storage/storage.module";

@Module({
  imports: [StorageModule],
  controllers: [PresetsController],
  providers: [PresetsService, MediaToolsService, PresetWorkerService],
})
export class PresetsModule {}
