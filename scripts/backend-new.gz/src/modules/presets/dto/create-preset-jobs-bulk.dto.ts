import { Type } from "class-transformer";
import { IsArray, ValidateNested } from "class-validator";
import { CreatePresetJobDto } from "./create-preset-job.dto";

export class CreatePresetJobsBulkDto {
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => CreatePresetJobDto)
  items!: CreatePresetJobDto[];
}
