import { IsIn, IsOptional, IsString } from "class-validator";

export class CreatePresetJobDto {
  @IsIn(["CREATIVE", "DAM", "BULK"])
  sourceType!: "CREATIVE" | "DAM" | "BULK";

  @IsString()
  sourceId!: string; // uuid

  @IsOptional() @IsString()
  destinationId?: string;

  @IsString()
  presetKey!: string;

  /**
   * Optional: broadcast timecode override used by presets that contain {{TIMECODE}}.
   * Example: "00:00:00:00".
   */
  @IsOptional()
  @IsString()
  timecode?: string;

  /**
   * Optional: creation_time metadata override used by presets that contain {{CREATION_TIME}}.
   * Example: "2026-02-01 09:00:00".
   */
  @IsOptional()
  @IsString()
  creationTime?: string;
}
