import { Module } from "@nestjs/common";
import { PlannerController } from "./planner.controller";
import { PlannerService } from "./planner.service";
import { PrismaModule } from "../../common/prisma/prisma.module";

@Module({
  imports: [PrismaModule],
  controllers: [PlannerController],
  providers: [PlannerService],
})
export class PlannerModule {}
