import { IsArray, IsBoolean, IsOptional, IsUUID } from "class-validator";

export class PlannerEntryDto {
  @IsUUID() creativeId!: string;
  @IsUUID() channelId!: string;
  @IsBoolean() selected!: boolean;
  @IsOptional() @IsUUID() slaId?: string | null;
}

export class UpsertPlannerDto {
  @IsArray() entries!: PlannerEntryDto[];
}
