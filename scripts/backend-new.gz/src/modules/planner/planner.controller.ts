import { Body, Controller, Get, Param, Post, Put, UseGuards } from "@nestjs/common";
import { PlannerService } from "./planner.service";
import { IsArray, IsBoolean, IsOptional, IsString } from "class-validator";
import { Type } from "class-transformer";
import { ValidateNested } from "class-validator";

import { JwtAuthGuard } from "../../common/auth/jwt-auth.guard";
import { PermissionsGuard } from "../../common/auth/permissions.guard";
import { RequireAnyPermissions } from "../../common/auth/require-any-permissions.decorator";
import { CurrentUser, AuthUser } from "../../common/auth/current-user.decorator";

class PlannerEntryDto {
  @IsString() creativeId!: string;
  @IsString() channelId!: string;

  @IsOptional() @IsString() slaId?: string | null;
  @IsOptional() @IsBoolean() selected?: boolean;
}

class BulkUpsertPlannerDto {
  @IsArray()
  @ValidateNested({ each: true })
  @Type(() => PlannerEntryDto)
  entries!: PlannerEntryDto[];
}

@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller()
export class PlannerController {
  constructor(private readonly svc: PlannerService) {}

  // Matrix data (creatives + channels + slas + existing entries + sentPairs)
  @Get("/projects/:id/planner")
  @RequireAnyPermissions("Page_Planner", "action:projects:planner:edit:scoped", "page:projects")
  getPlanner(@Param("id") projectId: string, @CurrentUser() user: AuthUser) {
    return this.svc.getPlanner(user, projectId);
  }

  // Bulk save (preferred for matrix save)
  @Put("/projects/:id/planner")
  @RequireAnyPermissions("action:planner:edit", "action:projects:planner:edit:scoped", "page:projects")
  bulkUpsert(@Param("id") projectId: string, @Body() dto: BulkUpsertPlannerDto, @CurrentUser() user: AuthUser) {
    return this.svc.upsertEntries(projectId, dto.entries, user);
  }

  // Keep your existing single-cell endpoint (backward compatible)
  @Put("/projects/:id/planner/entries")
  @RequireAnyPermissions("action:planner:edit", "action:projects:planner:edit:scoped", "page:projects")
  upsertOne(@Param("id") projectId: string, @Body() dto: PlannerEntryDto, @CurrentUser() user: AuthUser) {
    return this.svc.upsertEntries(projectId, [dto], user);
  }

  // Excel export data
  @Get("/projects/:id/planner/report")
  @RequireAnyPermissions("Page_Planner", "action:projects:planner:edit:scoped", "page:projects")
  report(@Param("id") projectId: string, @CurrentUser() user: AuthUser) {
    return this.svc.exportRows(user, projectId);
  }

  // Excel import payload (same as bulk upsert)
  @Post("/projects/:id/planner/import")
  @RequireAnyPermissions("action:planner:edit", "action:projects:planner:edit:scoped", "page:projects")
  import(@Param("id") projectId: string, @Body() dto: BulkUpsertPlannerDto, @CurrentUser() user: AuthUser) {
    return this.svc.upsertEntries(projectId, dto.entries, user);
  }
}
