import { BadRequestException, ForbiddenException, Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../../common/prisma/prisma.service";
import { NotificationsService } from "../notifications/notifications.service";
import { decorateSlaRow } from "../masters/sla-duration";
import type { AuthUser } from "../../common/auth/current-user.decorator";
import { ProjectAccessService } from "../../common/project-access/project-access.service";

type EntryInput = {
  creativeId: string;
  channelId: string;
  slaId?: string | null;
  selected?: boolean;
};

type ChannelAlignment = "LHS" | "RHS" | "BLHS" | "BRHS";

@Injectable()
export class PlannerService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly notifications: NotificationsService,
    private readonly projectAccess: ProjectAccessService,
  ) {}

  private async assertCanUsePlanner(user: AuthUser, projectId: string) {
    if (this.projectAccess.hasAnyPerm(user, ["Page_Planner", "action:planner:edit"])) return;
    await this.projectAccess.assertCanPlanner(user, projectId);
  }

  async getPlanner(user: AuthUser, projectId: string) {
    const accountId = user.accountId;
    await this.assertCanUsePlanner(user, projectId);
    const project = await this.prisma.project.findFirst({
      where: { id: projectId, accountId },
      select: { id: true, name: true },
    });
    if (!project) throw new NotFoundException("Project not found");

    const [destinations, rawChannels, slas, creatives, entries, sentPairs] = await Promise.all([
      this.prisma.destination.findMany({
        where: { accountId, status: "ACTIVE" },
        orderBy: { name: "asc" },
        select: { id: true, name: true, category: true, config: true },
      }),
      this.prisma.channel.findMany({
        where: { accountId, status: "ACTIVE" },
        orderBy: { name: "asc" },
        select: { id: true, name: true, destinationId: true, config: true },
      }),
      this.prisma.sla.findMany({
        where: { accountId, status: "ACTIVE" },
        orderBy: { name: "asc" },
        select: { id: true, name: true, hoursTarget: true, description: true },
      }),
      this.prisma.creative.findMany({
        where: { accountId, projectId },
        orderBy: { createdAt: "asc" },
        // Keep this lightweight but include the key columns needed by the Planner matrix
        select: {
          id: true,
          name: true,
          valid: true,
          caption: true,
          duration: true,
          languages: true,
          format: true,
          audio: true,
          qcStatus: true,
        },
      }),
      this.prisma.planningEntry.findMany({
        where: { accountId, projectId },
        select: { creativeId: true, channelId: true, selected: true, slaId: true },
      }),
      this.prisma.planLine.findMany({
        where: {
          accountId,
          planVersion: { projectId },
        },
        select: { creativeId: true, channelId: true },
      }),
    ]);

    const receiverIds = Array.from(
      new Set(
        (destinations || [])
          .map((destination: any) => String((destination?.config as any)?.receiverAccountId || "").trim())
          .filter(Boolean),
      ),
    );
    const receiverAccounts = receiverIds.length
      ? await this.prisma.partnerAccount.findMany({
          where: { accountId, id: { in: receiverIds } },
          select: { id: true, name: true, receiverCategory: true },
        })
      : [];
    const receiverById = new Map((receiverAccounts || []).map((row: any) => [String(row.id), row]));

    const destinationsWithReceiver = (destinations || []).map((destination: any) => {
      const receiverId = String((destination?.config as any)?.receiverAccountId || "").trim();
      const receiver = receiverId ? receiverById.get(receiverId) : null;
      return {
        id: destination.id,
        name: destination.name,
        category: destination.category ?? null,
        receiverAccountId: receiver?.id ?? (receiverId || null),
        receiverAccountName: receiver?.name ?? null,
        receiverCategory: receiver?.receiverCategory ?? destination.category ?? null,
      };
    });

    const channelsWithAlignment = rawChannels.map((channel: any) => ({
      id: channel.id,
      name: channel.name,
      destinationId: channel.destinationId,
      alignment: (channel?.config?.alignment || null) as ChannelAlignment | null,
    }));

    // Mark entries as locked if already included in ANY committed plan version for this project.
    // This keeps previously committed routes greyed out in Planner so they cannot be re-committed accidentally.
    const committedSet = new Set(sentPairs.map((x) => `${x.creativeId}:${x.channelId}`));
    const entriesWithLock = entries.map((e) => ({
      ...e,
      locked: committedSet.has(`${e.creativeId}:${e.channelId}`),
    }));

    return { project, destinations: destinationsWithReceiver, channels: channelsWithAlignment, slas: slas.map((row) => decorateSlaRow(row)), creatives, entries: entriesWithLock, sentPairs };
  }

  /**
   * Bulk upsert planner entries (also used by single-cell endpoint).
   *
   * Rules:
   * - If selected=true => slaId required (dto.slaId OR existing row slaId)
   * - If selected=false => slaId cleared
   * - If a (creativeId, channelId) pair is already SENT => cannot edit anymore
   */
  async upsertEntries(projectId: string, inputs: EntryInput[], user: AuthUser) {
    if (!inputs?.length) return { ok: true, updated: 0 };

    const project = await this.prisma.project.findFirst({
      where: { id: projectId, accountId: user.accountId },
      select: { id: true },
    });
    if (!project) throw new NotFoundException("Project not found");
    await this.assertCanUsePlanner(user, projectId);

    const creativeIds = Array.from(new Set(inputs.map((i) => i.creativeId)));
    const channelIds = Array.from(new Set(inputs.map((i) => i.channelId)));

    // validate creatives belong to this project + account
    const creatives = await this.prisma.creative.findMany({
      where: { accountId: user.accountId, projectId, id: { in: creativeIds } },
      select: { id: true },
    });
    if (creatives.length !== creativeIds.length) {
      throw new BadRequestException("One or more creativeIds invalid for this project");
    }

    // validate channels belong to this account
    const channels = await this.prisma.channel.findMany({
      where: { accountId: user.accountId, id: { in: channelIds } },
      select: { id: true },
    });
    if (channels.length !== channelIds.length) {
      throw new BadRequestException("One or more channelIds invalid for this account");
    }

    // Load existing entries so we can:
    // 1) allow selected=true to reuse previous slaId
    // 2) allow LOCKED/SENT pairs to be present in payload as long as they are not changed
    const existing = await this.prisma.planningEntry.findMany({
      where: {
        accountId: user.accountId,
        projectId,
        creativeId: { in: creativeIds },
        channelId: { in: channelIds },
      },
      select: { creativeId: true, channelId: true, selected: true, slaId: true },
    });

    type ExistingRow = (typeof existing)[number];
    const existingMap = new Map<string, ExistingRow>();
    for (const e of existing) existingMap.set(`${e.creativeId}:${e.channelId}`, e);

    // COMMITTED lock: once a pair has ever been committed for this project, it cannot be modified
    // from Planner anymore. This prevents old committed routes from being selected again in a later commit.
    const sent = await this.prisma.planLine.findMany({
      where: {
        accountId: user.accountId,
        planVersion: { projectId },
      },
      select: { creativeId: true, channelId: true },
    });
    const sentSet = new Set(sent.map((x) => `${x.creativeId}:${x.channelId}`));

    const blockedChanges: any[] = [];
    const actionableInputs: EntryInput[] = [];

    for (const input of inputs) {
      const key = `${input.creativeId}:${input.channelId}`;
      const prev = existingMap.get(key);

      const selected = input.selected ?? prev?.selected ?? true;
      const effectiveSlaId = selected ? (input.slaId ?? prev?.slaId ?? null) : null;

      // If locked and unchanged => ignore it (no-op)
      if (sentSet.has(key)) {
        const prevSelected = prev?.selected ?? false;
        const prevSlaId = prev?.slaId ?? null;
        if (selected === prevSelected && effectiveSlaId === prevSlaId) {
          continue;
        }
        blockedChanges.push({
          creativeId: input.creativeId,
          channelId: input.channelId,
          prev: { selected: prevSelected, slaId: prevSlaId },
          next: { selected, slaId: effectiveSlaId },
        });
        continue;
      }

      actionableInputs.push(input);
    }

    if (blockedChanges.length) {
      throw new ForbiddenException({
        message: "Some selections are already sent and cannot be changed",
        blocked: blockedChanges,
      });
    }

    if (!actionableInputs.length) return { ok: true, updated: 0 };

    // Validate provided SLA IDs (only for actionable inputs)
    const slaIds = Array.from(
      new Set(actionableInputs.map((i) => i.slaId).filter((x): x is string => typeof x === "string" && x.length > 0)),
    );
    if (slaIds.length) {
      const slas = await this.prisma.sla.findMany({
        where: { accountId: user.accountId, id: { in: slaIds } },
        select: { id: true },
      });
      if (slas.length !== slaIds.length) {
        throw new BadRequestException("One or more slaIds invalid for this account");
      }
    }

    const result = await this.prisma.$transaction(async (tx) => {
      let updated = 0;

      for (const input of actionableInputs) {
        const key = `${input.creativeId}:${input.channelId}`;
        const prev = existingMap.get(key);

        const selected = input.selected ?? prev?.selected ?? true;
        const effectiveSlaId = selected ? (input.slaId ?? prev?.slaId ?? null) : null;

        if (selected && !effectiveSlaId) {
          throw new BadRequestException(`slaId is required when selected=true for ${key}`);
        }

        await tx.planningEntry.upsert({
          where: {
            projectId_creativeId_channelId: {
              projectId,
              creativeId: input.creativeId,
              channelId: input.channelId,
            },
          },
          update: {
            selected,
            slaId: effectiveSlaId,
            accountId: user.accountId,
          },
          create: {
            accountId: user.accountId,
            projectId,
            creativeId: input.creativeId,
            channelId: input.channelId,
            selected,
            slaId: effectiveSlaId,
          },
        });

        updated++;
      }

      return { ok: true, updated };
    });

        // If every creative has at least one selected destination, emit Type 4 once
    const creativeCount = await this.prisma.creative.count({ where: { accountId: user.accountId, projectId } });
    if (creativeCount > 0) {
      const creativesWithSelection = await this.prisma.planningEntry.findMany({
        where: { accountId: user.accountId, projectId, selected: true },
        distinct: ["creativeId"] as any,
        select: { creativeId: true },
      });
      if (creativesWithSelection.length === creativeCount) {
        await this.notifications.emitType4DestinationsSelected(user.accountId, projectId);
      }
    }

    return result;
  }

  async exportRows(user: AuthUser, projectId: string) {
    const accountId = user.accountId;
    await this.assertCanUsePlanner(user, projectId);
    const project = await this.prisma.project.findFirst({
      where: { id: projectId, accountId },
      select: { id: true },
    });
    if (!project) throw new NotFoundException("Project not found");

    const rows = await this.prisma.planningEntry.findMany({
      where: { accountId, projectId, selected: true },
      include: {
        creative: { select: { id: true, valid: true, name: true } },
        channel: { select: { id: true, name: true, destination: { select: { name: true } }, config: true } },
        sla: { select: { id: true, name: true } },
      },
      orderBy: [{ creativeId: "asc" }, { channelId: "asc" }],
    });

    return rows.map((r) => ({
      creativeId: r.creativeId,
      valid: r.creative.valid,
      creativeName: r.creative.name,
      destination: r.channel?.destination?.name ?? "",
      channel: r.channel.name,
      logoPosition: (r.channel as any)?.config?.alignment ?? null,
      channelId: r.channelId,
      sla: r.sla?.name ?? "",
      slaId: r.slaId,
      selected: r.selected,
    }));
  }
}
