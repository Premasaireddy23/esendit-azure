export const bulkAssetSelect = {
  id: true,
  type: true,
  path: true,
  filename: true,
  mimeType: true,
  uploadStatus: true,
  sizeBytes: true,
  bytesTotal: true,
  bytesReceived: true,
  uploadStartedAt: true,
  uploadEndedAt: true,
  error: true,
};

export const bulkItemSelect = {
  id: true,
  batchId: true,
  valid: true,
  caption: true,
  format: true,
  languages: true,
  duration: true,
  remarks: true,

  qcStatus: true,
  qcFailureReasons: true,
  qcReport: true,
  autoQcStartedAt: true,
  autoQcEndedAt: true,

  createdAt: true,
  updatedAt: true,

  assets: { select: bulkAssetSelect },
};

export const bulkBatchSelect = {
  id: true,
  name: true,
  billingMode: true,
  createdAt: true,
  updatedAt: true,
};
