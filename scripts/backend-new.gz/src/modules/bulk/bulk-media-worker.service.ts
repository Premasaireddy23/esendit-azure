import { Injectable, Logger, OnModuleInit } from "@nestjs/common";
import { PrismaService } from "../../common/prisma/prisma.service";
import { ServiceBusService } from "../../common/queue/service-bus.service";
import { QUEUES } from "../../common/queue/queue.constants";
import { CreativeAssetType, CreativeAssetUploadStatus, MediaJobStatus, MediaJobType } from "@prisma/client";
import { MediaToolsService } from "../creatives/media/media-tools.service";
import { evalAutoQc } from "../creatives/media/qc-eval";
import { buildNormalizedMediaMetadata } from "../creatives/media/media-metadata.util";
import * as path from "node:path";
import * as fs from "node:fs/promises";
import * as os from "node:os";
import { Inject } from "@nestjs/common";
import { STORAGE } from "../../common/storage/storage.token";
import type { StorageService } from "../../common/storage/storage.types";

function makeTmp(prefix: string, ext: string) {
  const safe = prefix.replace(/[^\w.-]+/g, "_");
  return path.join(os.tmpdir(), `esendit-${safe}-${Date.now()}-${Math.random().toString(16).slice(2)}.${ext}`);
}



function parseDurationSeconds(raw?: string | null): number | undefined {
  if (!raw) return undefined;
  const s = String(raw).trim().toLowerCase();
  const m1 = /^(\d{1,2}):(\d{2}):(\d{2})(?::(\d{2}))?$/.exec(s);
  if (m1) {
    const hh = parseInt(m1[1], 10);
    const mm = parseInt(m1[2], 10);
    const ss = parseInt(m1[3], 10);
    return hh * 3600 + mm * 60 + ss;
  }
  const m2 = /^(\d{1,6})\s*(sec|secs|s)?$/.exec(s);
  if (m2) return parseInt(m2[1], 10);
  return undefined;
}

function envInt(k: string): number | undefined {
  const v = process.env[k];
  if (v === undefined || v === null || String(v).trim() === "") return undefined;
  const n = Number(String(v).trim());
  if (!Number.isFinite(n)) return undefined;
  return Math.trunc(n);
}

function envFloat(k: string): number | undefined {
  const v = process.env[k];
  if (v === undefined || v === null || String(v).trim() === "") return undefined;
  const n = Number(String(v).trim());
  if (!Number.isFinite(n)) return undefined;
  return n;
}

function deriveQcExpectedFromRow(meta: { format?: string | null; duration?: string | null }): any {
  const expected: any = {};
  const fmt = String(meta?.format || "").toUpperCase();

  if (fmt.includes("SD")) {
    expected.width = envInt("QC_EXPECTED_SD_WIDTH") ?? 720;
    expected.height = envInt("QC_EXPECTED_SD_HEIGHT") ?? 576;
    expected.frameRate = envFloat("QC_EXPECTED_SD_FRAME_RATE") ?? 25;
    expected.displayAspectRatio = String(process.env.QC_EXPECTED_SD_DAR || "4:3");
    if (process.env.QC_EXPECTED_SD_SCAN_TYPE) expected.scanType = String(process.env.QC_EXPECTED_SD_SCAN_TYPE).toUpperCase();
  } else if (fmt.includes("HD")) {
    expected.width = envInt("QC_EXPECTED_HD_WIDTH") ?? 1920;
    expected.height = envInt("QC_EXPECTED_HD_HEIGHT") ?? 1080;
    expected.frameRate = envFloat("QC_EXPECTED_HD_FRAME_RATE") ?? 25;
    expected.displayAspectRatio = String(process.env.QC_EXPECTED_HD_DAR || "16:9");
    if (process.env.QC_EXPECTED_HD_SCAN_TYPE) expected.scanType = String(process.env.QC_EXPECTED_HD_SCAN_TYPE).toUpperCase();
  }

  if (process.env.QC_EXPECTED_AUDIO_CHANNELS) expected.audioChannels = envInt("QC_EXPECTED_AUDIO_CHANNELS");
  expected.audioSampleRate = envInt("QC_EXPECTED_AUDIO_SAMPLE_RATE") ?? 48000;

  const dur = parseDurationSeconds(meta?.duration);
  if (typeof dur === "number" && Number.isFinite(dur) && dur > 0) {
    expected.durationSec = dur;
    expected.durationToleranceSec = envFloat("QC_DURATION_TOLERANCE_SEC") ?? 0.5;
  }

  return expected;
}
@Injectable()
export class BulkMediaWorkerService implements OnModuleInit {
  private readonly log = new Logger(BulkMediaWorkerService.name);
  private running = false;
  private serial: Promise<void> = Promise.resolve();

  constructor(
    private prisma: PrismaService,
    private tools: MediaToolsService,
    @Inject(STORAGE) private storage: StorageService,
    private readonly bus: ServiceBusService,
  ) {}

  onModuleInit() {
    if (process.env.NODE_ENV === "test") return;
    if ((process.env.BULK_MEDIA_WORKER_ENABLED || "true").toLowerCase() === "false") {
      this.log.log("BULK_MEDIA_WORKER_ENABLED=false; worker not started");
      return;
    }

    if (this.bus.isEnabled()) {
      this.bus
        .subscribeJson(QUEUES.bulk(), async (msg) => {
          const resolvedJobId = await this.resolveJobIdFromMessage(msg);
          if (!resolvedJobId) return;
          const run = this.serial.then(() => this.tick(resolvedJobId));
          this.serial = run.catch(() => undefined);
          await run;
        })
        .catch((e) => this.log.error(e));
      this.log.log(`Bulk media worker started (service bus: ${QUEUES.bulk()})`);
      return;
    }

    setInterval(() => this.tick().catch((e) => this.log.error(e)), 2000);
    this.log.log("Bulk media worker started (polling every 2s)");
  }


  private async resolveJobIdFromMessage(msg: any): Promise<string | undefined> {
    const jobId = msg?.jobId ? String(msg.jobId) : undefined;
    if (jobId) return jobId;

    const bulkItemId = msg?.bulkItemId ? String(msg.bulkItemId) : undefined;
    const jobType = msg?.jobType || msg?.type;
    const type = jobType ? String(jobType) : undefined;
    if (!bulkItemId || !type) return undefined;

    const job = await this.prisma.bulkMediaJob.findFirst({
      where: { bulkItemId, type: type as any, status: MediaJobStatus.PENDING },
      orderBy: { createdAt: "asc" },
      select: { id: true },
    });
    return job?.id ? String(job.id) : undefined;
  }

  private async tick(jobId?: string) {
    if (this.running) return;
    this.running = true;

    let job: any = null;

    if (jobId) {
      job = await this.prisma.bulkMediaJob.findUnique({ where: { id: jobId } });
      if (!job) return;
      if (job.status !== MediaJobStatus.PENDING) return;
    }


    try {
      if (!job) job = await this.prisma.bulkMediaJob.findFirst({
        where: { status: MediaJobStatus.PENDING, OR: [{ runAfter: null }, { runAfter: { lte: new Date() } }] },
        orderBy: { createdAt: "asc" },
      });
      if (!job) return;

      const claimed = await this.prisma.bulkMediaJob.updateMany({
        where: { id: job.id, status: MediaJobStatus.PENDING },
        data: { status: MediaJobStatus.RUNNING, startedAt: new Date(), attempts: { increment: 1 } },
      });
      if (claimed.count !== 1) return;

      if (job.type === MediaJobType.AUTO_QC) await this.runAutoQc(job.id, job.bulkItemId);
      if (job.type === MediaJobType.PROXY_GEN) await this.runProxy(job.id, job.bulkItemId);

      await this.prisma.bulkMediaJob.update({
        where: { id: job.id },
        data: { status: MediaJobStatus.SUCCEEDED, endedAt: new Date(), error: null },
      });
    } catch (e: any) {
      const msg = String(e?.message || e || "UNKNOWN_ERROR").slice(0, 2000);
      this.log.error(msg);

      if (job?.id) {
        const attemptsNow = Number(job.attempts || 0) + 1;
        const maxAttempts = Number(job.maxAttempts || 3);

        if (attemptsNow < maxAttempts) {
          const backoffMs = Math.min(60_000, 1000 * Math.pow(2, attemptsNow));
          await this.prisma.bulkMediaJob.update({
            where: { id: job.id },
            data: { status: MediaJobStatus.PENDING, runAfter: new Date(Date.now() + backoffMs), endedAt: new Date(), error: msg },
          });
        } else {
          await this.prisma.bulkMediaJob.update({
            where: { id: job.id },
            data: { status: MediaJobStatus.FAILED, endedAt: new Date(), error: msg },
          });
        }
      }
    } finally {
      this.running = false;
    }
  }

  private async runAutoQc(jobId: string, bulkItemId: string) {
    await this.prisma.bulkUploadItem.update({
      where: { id: bulkItemId },
      data: { qcStatus: "IN_PROGRESS", autoQcStartedAt: new Date(), qcFailureReasons: [], qcReport: null } as any,
    });

    const source = await this.prisma.bulkUploadAsset.findFirst({
      where: { bulkItemId, type: CreativeAssetType.SOURCE as any, uploadStatus: CreativeAssetUploadStatus.UPLOADED as any },
    });

    if (!source) {
      await this.prisma.bulkUploadItem.update({
        where: { id: bulkItemId },
        data: { qcStatus: "FAILED", qcFailureReasons: ["SOURCE_NOT_UPLOADED"], qcReport: { error: "SOURCE_NOT_UPLOADED" }, autoQcEndedAt: new Date() } as any,
      });
      throw new Error("SOURCE_NOT_UPLOADED");
    }

    const sourcePath = String(source.path);
    const localInput = this.storage.isCloud() ? makeTmp("bulk-source", "bin") : sourcePath;

    if (this.storage.isCloud()) {
      await this.storage.downloadToFile(sourcePath, localInput);
    }

    const ffprobe = await this.tools.ffprobeJson(localInput).catch(() => null);
    const mediainfoEnabled = (process.env.QC_MEDIAINFO_ENABLED || "true").toLowerCase() !== "false";
    const mediainfoRequired = (process.env.QC_MEDIAINFO_REQUIRED || "false").toLowerCase() === "true";
    const mediainfo = mediainfoEnabled ? await this.tools.runMediainfoQc(localInput) : null;
    if (mediainfoRequired && !mediainfo) throw new Error("MEDIAINFO_NOT_AVAILABLE");

    const framesEnabled = (process.env.QC_FRAME_COUNT_ENABLED || "true").toLowerCase() !== "false";
    const framesRead = framesEnabled ? await this.tools.ffprobeCountFrames(localInput) : null;

    const meta = await this.prisma.bulkUploadItem.findFirst({ where: { id: bulkItemId }, select: { format: true, duration: true, languages: true } });
    const expected = deriveQcExpectedFromRow(meta as any);
    const qcTools: any = { mediainfo, measures: {}, primaryProbeTool: mediainfo ? "qcli+mediainfo" : "ffprobe" };
    if (framesEnabled) qcTools.measures.frames = { nb_read_frames: framesRead };
    const res = evalAutoQc(ffprobe, { expected, sourcePath: localInput, qcTools });
    const normalizedMetadata = buildNormalizedMediaMetadata(mediainfo, ffprobe, {
      filename: source?.filename ?? null,
      sizeBytes: source?.sizeBytes ?? null,
      mimeType: source?.mimeType ?? null,
    });

    if (this.storage.isCloud()) {
      await fs.rm(localInput, { force: true }).catch(() => undefined);
    }

    const mergedReport = { ...(res.report || {}), probeTool: mediainfo ? "qcli+mediainfo" : "ffprobe", qcTools, metadata: normalizedMetadata };

    await this.prisma.bulkUploadItem.update({
      where: { id: bulkItemId },
      data: { qcStatus: res.status, qcFailureReasons: res.reasons, qcReport: mergedReport, autoQcEndedAt: new Date() } as any,
    });

    await this.prisma.bulkMediaJob.update({ where: { id: jobId }, data: { result: mergedReport } });
  }

  private async runProxy(jobId: string, bulkItemId: string) {
    const source = await this.prisma.bulkUploadAsset.findFirst({
      where: { bulkItemId, type: CreativeAssetType.SOURCE as any, uploadStatus: CreativeAssetUploadStatus.UPLOADED as any },
    });
    if (!source) throw new Error("SOURCE_NOT_UPLOADED");

    const sourcePath = String(source.path);

    // Local driver keeps the old behavior (write next to source).
    // Cloud driver uses a predictable blob key next to the source key.
    const proxyKeyOrPath = (() => {
      if (!this.storage.isCloud()) {
        const dir = path.dirname(sourcePath);
        const base = path.parse(sourcePath).name;
        return path.join(dir, `${base}.proxy.mp4`);
      }

      // Expected: accounts/{accountId}/bulk/{batchId}/{itemId}/source/{filename}
      const p = sourcePath.replace(/\\/g, "/");
      const base = path.parse(p).name;
      if (p.includes("/source/")) {
        return p.replace(/\/source\/[^/]+$/, `/proxy/${base}.proxy.mp4`);
      }
      return `${p}.proxy.mp4`;
    })();

    const existing = await this.prisma.bulkUploadAsset.findFirst({
      where: { bulkItemId, type: CreativeAssetType.PROXY as any },
      select: { id: true },
    });

    const proxyRow = existing
      ? await this.prisma.bulkUploadAsset.update({
          where: { id: existing.id },
          data: { path: proxyKeyOrPath, uploadStatus: "UPLOADING", uploadStartedAt: new Date(), uploadEndedAt: null, error: null } as any,
        })
      : await this.prisma.bulkUploadAsset.create({
          data: { accountId: source.accountId, bulkItemId, type: "PROXY" as any, path: proxyKeyOrPath, uploadStatus: "UPLOADING", uploadStartedAt: new Date() } as any,
        });

    try {
      const localInput = this.storage.isCloud() ? makeTmp("bulk-source", "bin") : sourcePath;
      const localOut = this.storage.isCloud() ? makeTmp("bulk-proxy", "mp4") : String(proxyKeyOrPath);

      if (this.storage.isCloud()) {
        await this.storage.downloadToFile(sourcePath, localInput);
      }

      await this.tools.makeProxy(localInput, localOut);
      const stat = await fs.stat(localOut);
      const sizeBytes = BigInt(stat.size);

      if (this.storage.isCloud()) {
        await this.storage.uploadFile(String(proxyKeyOrPath), localOut, "video/mp4");
      }

      await this.prisma.bulkUploadAsset.update({
        where: { id: proxyRow.id },
        data: {
          filename: path.basename(String(proxyKeyOrPath)),
          mimeType: "video/mp4",
          sizeBytes,
          bytesTotal: sizeBytes,
          bytesReceived: sizeBytes,
          uploadStatus: "UPLOADED",
          uploadEndedAt: new Date(),
          error: null,
        } as any,
      });

      await this.prisma.bulkMediaJob.update({ where: { id: jobId }, data: { result: { proxyPath: proxyKeyOrPath, bytes: stat.size } } });

      if (this.storage.isCloud()) {
        await fs.rm(localInput, { force: true }).catch(() => undefined);
        await fs.rm(localOut, { force: true }).catch(() => undefined);
      }
    } catch (e: any) {
      const msg = String(e?.message || e || "PROXY_FAILED").slice(0, 2000);
      await this.prisma.bulkUploadAsset.update({ where: { id: proxyRow.id }, data: { uploadStatus: "FAILED", uploadEndedAt: new Date(), error: msg } as any });
      throw e;
    }
  }
}
