import { BadRequestException, Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../../common/prisma/prisma.service";
import { AzureBlobService } from "../../common/storage/azure-blob.service";
import { SignedStreamService } from "../../common/stream/signed-stream.service";
import { bulkBatchSelect, bulkItemSelect } from "./bulk.select";
import { CreateBulkBatchDto } from "./dto/create-batch.dto";
import { MediaJobType } from "@prisma/client";
import { BulkMediaJobsService } from "./bulk-media-jobs.service";
import * as path from "node:path";
import * as fs from "node:fs/promises";
import { createReadStream } from "node:fs";
import * as ExcelJS from "exceljs"; // ✅ no default export

function looksLikeLocalPath(p: string): boolean {
  if (!p) return false;
  return p.startsWith("/") || /^[A-Za-z]:\\/.test(p);
}

type UploadedFileLike = {
  originalname: string;
  mimetype: string;
  buffer: any; // ✅ keep as any to avoid Buffer generic mismatch
  size?: number;
};

function normHeader(v: any) {
  return String(v ?? "")
    .trim()
    .toLowerCase()
    .replace(/\s+/g, "_");
}

function splitLangs(v: any): string[] {
  if (v === null || v === undefined) return [];
  if (Array.isArray(v)) return v.map(String).map((s) => s.trim()).filter(Boolean);
  const s = String(v).trim();
  if (!s) return [];
  return s
    .split(/[,/|]+/)
    .map((x) => x.trim())
    .filter(Boolean);
}

@Injectable()
export class BulkService {
  constructor(private prisma: PrismaService, private jobs: BulkMediaJobsService, private blobs: AzureBlobService, private signed: SignedStreamService) {}

  async listBatches(accountId: string) {
    return this.prisma.bulkUploadBatch.findMany({
      where: { accountId },
      orderBy: { createdAt: "desc" },
      select: bulkBatchSelect as any,
    });
  }

  async createBatch(accountId: string, userId: string, dto: CreateBulkBatchDto) {
    return this.prisma.bulkUploadBatch.create({
      data: {
        accountId,
        name: dto.name,
        billingMode: (dto.billingMode as any) ?? "UNBILLED",
        createdByUserId: userId,
      } as any,
      select: bulkBatchSelect as any,
    });
  }

  async getBatch(accountId: string, id: string) {
    const b = await this.prisma.bulkUploadBatch.findFirst({
      where: { id, accountId },
      select: {
        ...(bulkBatchSelect as any),
        items: { select: bulkItemSelect as any, orderBy: { createdAt: "asc" } },
      },
    });
    if (!b) throw new NotFoundException("Batch not found");
    return b;
  }

  async createItems(accountId: string, batchId: string, items: any[]) {
    const batch = await this.prisma.bulkUploadBatch.findFirst({
      where: { id: batchId, accountId },
      select: { id: true },
    });
    if (!batch) throw new NotFoundException("Batch not found");

    const out: any[] = [];
    for (const it of items) {
      const row = await this.prisma.bulkUploadItem.create({
        data: {
          accountId,
          batchId,
          valid: it.valid ?? null,
          caption: it.caption ?? null,
          format: it.format ?? null,
          languages: Array.isArray(it.languages) ? it.languages : splitLangs(it.languages),
          duration: it.duration ?? null,
          remarks: it.remarks ?? null,
        } as any,
        select: bulkItemSelect as any,
      });
      out.push(row);
    }
    return out;
  }

  // ✅ Excel import
  async importExcel(accountId: string, batchId: string, file: UploadedFileLike) {
    if (!file?.buffer) throw new BadRequestException("Missing excel file");

    const batch = await this.prisma.bulkUploadBatch.findFirst({
      where: { id: batchId, accountId },
      select: { id: true },
    });
    if (!batch) throw new NotFoundException("Batch not found");

    const wb = new ExcelJS.Workbook();

    // ✅ FIX: cast to any to avoid Buffer<T> type mismatch errors
    await wb.xlsx.load(file.buffer as any);

    const ws = wb.worksheets[0];
    if (!ws) throw new BadRequestException("Excel has no sheets");

    // header row (row 1)
    const headerRow = ws.getRow(1);
    const headers: string[] = [];
    headerRow.eachCell((cell, col) => {
      headers[col] = normHeader(cell.value);
    });

    const rows: any[] = [];
    for (let r = 2; r <= ws.rowCount; r++) {
      const row = ws.getRow(r);
      if (!row || row.cellCount === 0) continue;

      const obj: any = {};
      for (let c = 1; c <= row.cellCount; c++) {
        const key = headers[c] || `col_${c}`;
        const v = row.getCell(c).value as any;

        const value =
          v && typeof v === "object" && "text" in v ? (v as any).text :
          v && typeof v === "object" && "result" in v ? (v as any).result :
          v;

        obj[key] = value;
      }

      const valid = obj.valid ?? obj.valid_id ?? obj.validcode ?? null;
      const caption = obj.caption ?? obj.title ?? null;
      const format = obj.format ?? obj.type ?? null;
      const languages = obj.languages ?? obj.language ?? obj.langs ?? null;
      const duration = obj.duration ?? obj.dur ?? null;
      const remarks = obj.remarks ?? obj.remark ?? obj.notes ?? null;

      const hasAny = [valid, caption, format, languages, duration, remarks].some(
        (x) => String(x ?? "").trim() !== "",
      );
      if (!hasAny) continue;

      rows.push({
        valid: valid ? String(valid).trim() : null,
        caption: caption ? String(caption).trim() : null,
        format: format ? String(format).trim() : null,
        languages: splitLangs(languages),
        duration: duration ? String(duration).trim() : null,
        remarks: remarks ? String(remarks).trim() : null,
      });
    }

    if (!rows.length) throw new BadRequestException("No rows found in excel");

    await this.createItems(accountId, batchId, rows);
    return this.getBatch(accountId, batchId);
  }

  async uploadSource(accountId: string, bulkItemId: string, file: UploadedFileLike) {
    if (!file?.buffer) throw new BadRequestException("Missing file");

    const item = await this.prisma.bulkUploadItem.findFirst({
      where: { id: bulkItemId, accountId },
      select: { id: true, batchId: true },
    });
    if (!item) throw new NotFoundException("Item not found");
    const safeName = file.originalname?.replace(/[^\w.\-()+\[\] ]+/g, "_") || "upload.bin";

    let storedPath: string;
    if (this.blobs.isConfigured()) {
      const blobKey = `accounts/${accountId}/bulk/${item.batchId}/${bulkItemId}/source/${safeName}`;
      await this.blobs.uploadBuffer(blobKey, Buffer.from(file.buffer as any), file.mimetype);
      storedPath = blobKey;
    } else {
      const dir = path.join(process.cwd(), "uploads", "bulk", item.batchId, bulkItemId);
      await fs.mkdir(dir, { recursive: true });
      const target = path.join(dir, safeName);
      await fs.writeFile(target, file.buffer as any);
      storedPath = target;
    }

    await this.prisma.bulkUploadAsset.deleteMany({
      where: { accountId, bulkItemId, type: "SOURCE" as any },
    });

    const stat = this.blobs.isConfigured() ? { size: Number(file.size || (file.buffer?.length || 0)) } as any : await fs.stat(storedPath);
    const sizeBytes = BigInt(stat.size);

    await this.prisma.bulkUploadAsset.create({
      data: {
        accountId,
        bulkItemId,
        type: "SOURCE" as any,
        path: storedPath,
        filename: safeName,
        mimeType: file.mimetype,
        sizeBytes,
        bytesTotal: sizeBytes,
        bytesReceived: sizeBytes,
        uploadStatus: "UPLOADED",
        uploadStartedAt: new Date(),
        uploadEndedAt: new Date(),
      } as any,
    });

    return this.getBatch(accountId, item.batchId);
  }

  startAutoQc(accountId: string, bulkItemId: string, force: boolean) {
    return this.jobs.enqueue(accountId, bulkItemId, MediaJobType.AUTO_QC, force);
  }

  startProxy(accountId: string, bulkItemId: string, force: boolean) {
    return this.jobs.enqueue(accountId, bulkItemId, MediaJobType.PROXY_GEN, force);
  }

  async listJobs(accountId: string, bulkItemId: string) {
    const ok = await this.prisma.bulkUploadItem.findFirst({
      where: { id: bulkItemId, accountId },
      select: { id: true },
    });
    if (!ok) throw new NotFoundException("Item not found");
    return this.jobs.listForItem(bulkItemId);
  }

  async getAssetStreamUrlByType(accountId: string, bulkItemId: string, type: "SOURCE" | "PROXY" | "OUTPUT") {
    const asset: any = await this.prisma.bulkUploadAsset.findFirst({
      where: { accountId, bulkItemId, type: type as any },
      select: { path: true, mimeType: true, filename: true } as any,
    });
    if (!asset) throw new NotFoundException(`${type} asset not found`);

    if (!looksLikeLocalPath(String(asset.path)) && this.blobs.isConfigured()) {
      const url = await this.blobs.createReadSasUrl(String(asset.path), asset.mimeType || undefined, `inline; filename="${asset.filename || type.toLowerCase()}"`, 30);
      return { url };
    }

    const url = this.signed.makeUrl({
      path: String(asset.path),
      mimeType: asset.mimeType || undefined,
      filename: asset.filename || type.toLowerCase(),
      disposition: "inline",
      ttlSeconds: 600,
    });
    return { url };
  }

  async streamAssetByType(
    accountId: string,
    bulkItemId: string,
    type: "SOURCE" | "PROXY" | "OUTPUT",
    req: any,
    res: any,
  ) {
    const asset = await this.prisma.bulkUploadAsset.findFirst({
      where: { accountId, bulkItemId, type: type as any },
      select: { path: true, mimeType: true } as any,
    });
    if (!asset) throw new NotFoundException(`${type} asset not found`);

    // Blob-backed asset -> redirect to SAS URL
    if (!looksLikeLocalPath(String(asset.path)) && this.blobs.isConfigured()) {
      const url = await this.blobs.createReadSasUrl(asset.path, asset.mimeType || undefined, undefined, 30);
      return res.redirect(302, url);
    }

    const stat = await fs.stat(asset.path);
    const mimeType = asset.mimeType || (type === "PROXY" ? "video/mp4" : "application/octet-stream");

    const range = req.headers?.range as string | undefined;
    if (!range) {
      res.setHeader("Content-Type", mimeType);
      res.setHeader("Content-Length", stat.size);
      res.setHeader("Accept-Ranges", "bytes");
      createReadStream(asset.path).pipe(res);
      return;
    }

    const m = /^bytes=(\d+)-(\d*)$/.exec(range);
    if (!m) return res.status(416).end();

    const start = Number(m[1]);
    const end = m[2] ? Number(m[2]) : stat.size - 1;
    if (start >= stat.size || end >= stat.size || start > end) return res.status(416).end();

    res.status(206);
    res.setHeader("Content-Type", mimeType);
    res.setHeader("Accept-Ranges", "bytes");
    res.setHeader("Content-Range", `bytes ${start}-${end}/${stat.size}`);
    res.setHeader("Content-Length", end - start + 1);

    createReadStream(asset.path, { start, end }).pipe(res);
  }
}
