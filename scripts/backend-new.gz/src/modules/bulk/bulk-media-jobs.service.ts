import { Injectable } from "@nestjs/common";
import { PrismaService } from "../../common/prisma/prisma.service";
import { ServiceBusService } from "../../common/queue/service-bus.service";
import { QUEUES } from "../../common/queue/queue.constants";
import { MediaJobStatus, MediaJobType } from "@prisma/client";

@Injectable()
export class BulkMediaJobsService {
  constructor(private prisma: PrismaService, private bus: ServiceBusService) {}

  async enqueue(accountId: string, bulkItemId: string, type: MediaJobType, force: boolean) {
    if (!force) {
      const active = await this.prisma.bulkMediaJob.findFirst({
        where: {
          accountId,
          bulkItemId,
          type,
          status: { in: [MediaJobStatus.PENDING, MediaJobStatus.RUNNING] },
        },
        select: { id: true, accountId: true, bulkItemId: true, type: true },
      });
      if (active) {
        await this.bus.sendJson(QUEUES.bulk(), { jobId: active.id, accountId: active.accountId, bulkItemId: active.bulkItemId, jobType: active.type }, { messageId: active.id }).catch(() => undefined);
        return { ok: true, alreadyQueued: true, id: active.id };
      }
    }

    const created = await this.prisma.bulkMediaJob.create({
      data: { accountId, bulkItemId, type, status: MediaJobStatus.PENDING, payload: {} as any },
      select: { id: true, status: true, type: true, accountId: true, bulkItemId: true } as any,
    });

    await this.bus.sendJson(QUEUES.bulk(), { jobId: created.id, accountId: created.accountId, bulkItemId: created.bulkItemId, jobType: created.type }, { messageId: created.id }).catch(() => undefined);
    return { ok: true, id: created.id };
  }

  listForItem(bulkItemId: string) {
    return this.prisma.bulkMediaJob.findMany({ where: { bulkItemId }, orderBy: { createdAt: "desc" } });
  }
}
