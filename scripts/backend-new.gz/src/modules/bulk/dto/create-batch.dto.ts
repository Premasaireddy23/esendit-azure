import { IsIn, IsOptional, IsString } from "class-validator";

export class CreateBulkBatchDto {
  @IsString()
  name!: string;

  @IsOptional()
  @IsIn(["BILLED", "UNBILLED"])
  billingMode?: "BILLED" | "UNBILLED";
}
