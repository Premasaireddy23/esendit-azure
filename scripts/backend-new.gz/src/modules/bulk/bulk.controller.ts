import {
  Body,
  Controller,
  Get,
  Param,
  Post,
  Query,
  Req,
  Res,
  UploadedFile,
  UseGuards,
  UseInterceptors,
} from "@nestjs/common";
import { FileInterceptor } from "@nestjs/platform-express";
import { JwtAuthGuard } from "../../common/auth/jwt-auth.guard";
import { PermissionsGuard } from "../../common/auth/permissions.guard";
import { RequirePermissions } from "../../common/auth/require-permissions.decorator";
import { CurrentUser } from "../../common/auth/current-user.decorator";
import { BulkService } from "./bulk.service";
import { CreateBulkBatchDto } from "./dto/create-batch.dto";

type UploadedFileLike = {
  originalname: string;
  mimetype: string;
  buffer: Buffer;
  size?: number;
};

@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller("bulk")
export class BulkController {
  constructor(private svc: BulkService) {}

  @Get("batches")
  @RequirePermissions("action_bulk_read")
  list(@CurrentUser() user: any) {
    return this.svc.listBatches(user.accountId);
  }

  @Post("batches")
  @RequirePermissions("action_bulk_create")
  create(@CurrentUser() user: any, @Body() dto: CreateBulkBatchDto) {
    return this.svc.createBatch(user.accountId, user.id, dto);
  }

  @Get("batches/:id")
  @RequirePermissions("action_bulk_read")
  get(@CurrentUser() user: any, @Param("id") id: string) {
    return this.svc.getBatch(user.accountId, id);
  }

  // JSON create items (used by UI)
  @Post("batches/:id/items")
  @RequirePermissions("action_bulk_create")
  createItems(@CurrentUser() user: any, @Param("id") id: string, @Body() body: any) {
    const items = Array.isArray(body?.items) ? body.items : Array.isArray(body) ? body : [];
    return this.svc.createItems(user.accountId, id, items);
  }

  // Excel import -> creates items
  @Post("batches/:id/import-excel")
  @RequirePermissions("action_bulk_import")
  @UseInterceptors(FileInterceptor("file"))
  importExcel(@CurrentUser() user: any, @Param("id") id: string, @UploadedFile() file: UploadedFileLike) {
    return this.svc.importExcel(user.accountId, id, file);
  }

  // Upload SOURCE media for a bulk item
  @Post("items/:id/assets/source")
  @RequirePermissions("action_bulk_upload")
  @UseInterceptors(FileInterceptor("file"))
  uploadSource(@CurrentUser() user: any, @Param("id") id: string, @UploadedFile() file: UploadedFileLike) {
    return this.svc.uploadSource(user.accountId, id, file);
  }

  @Post("items/:id/auto-qc")
  @RequirePermissions("action_bulk_process")
  autoQc(@CurrentUser() user: any, @Param("id") id: string, @Body() body: any) {
    return this.svc.startAutoQc(user.accountId, id, !!body?.force);
  }

  @Post("items/:id/proxy")
  @RequirePermissions("action_bulk_process")
  proxy(@CurrentUser() user: any, @Param("id") id: string, @Body() body: any) {
    return this.svc.startProxy(user.accountId, id, !!body?.force);
  }

  @Get("items/:id/jobs")
  @RequirePermissions("action_bulk_read")
  jobs(@CurrentUser() user: any, @Param("id") id: string) {
    return this.svc.listJobs(user.accountId, id);
  }



  @Get("items/:id/assets/:type/stream-url")
  @RequirePermissions("action_bulk_stream", "action:media:download")
  async streamUrl(
    @CurrentUser() user: any,
    @Param("id") id: string,
    @Param("type") type: "SOURCE" | "PROXY" | "OUTPUT",
  ) {
    return this.svc.getAssetStreamUrlByType(user.accountId, id, type);
  }

  @Get("items/:id/assets/:type/stream")
  @RequirePermissions("action_bulk_stream", "action:media:download")
  stream(
    @CurrentUser() user: any,
    @Param("id") id: string,
    @Param("type") type: "SOURCE" | "PROXY" | "OUTPUT",
    @Req() req: any,
    @Res() res: any,
  ) {
    return this.svc.streamAssetByType(user.accountId, id, type, req, res);
  }
}
