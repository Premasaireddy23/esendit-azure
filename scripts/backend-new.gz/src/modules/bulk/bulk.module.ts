import { Module } from "@nestjs/common";
import { BulkController } from "./bulk.controller";
import { BulkService } from "./bulk.service";
import { BulkMediaJobsService } from "./bulk-media-jobs.service";
import { BulkMediaWorkerService } from "./bulk-media-worker.service";
import { MediaToolsService } from "../creatives/media/media-tools.service";
import { StorageModule } from "../../common/storage/storage.module";

@Module({
  imports: [StorageModule],
  controllers: [BulkController],
  providers: [BulkService, BulkMediaJobsService, MediaToolsService, BulkMediaWorkerService],
})
export class BulkModule {}
