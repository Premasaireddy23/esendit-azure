import { Injectable, OnModuleInit } from "@nestjs/common";
import { EmailOutboxService } from "./email-outbox.service";

@Injectable()
export class EmailOutboxRunner implements OnModuleInit {
  constructor(private readonly svc: EmailOutboxService) {}

  onModuleInit() {
    if ((process.env.EMAIL_OUTBOX_ENABLED || "true").toLowerCase() === "false") {
      return;
    }
    setInterval(async () => {
      try {
        for (let i = 0; i < 5; i++) {
          const did = await this.svc.processOne();
          if (!did) break;
        }
      } catch {
        // keep loop alive
      }
    }, 3000);
  }
}
