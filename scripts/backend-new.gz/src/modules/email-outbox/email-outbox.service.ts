import { Injectable, Logger } from "@nestjs/common";
import { PrismaService } from "../../common/prisma/prisma.service";
import { EmailOutboxStatus } from "@prisma/client";
import { AcsEmailProvider } from "../../common/email/acs-email.provider";

@Injectable()
export class EmailOutboxService {
  private readonly log = new Logger(EmailOutboxService.name);

  constructor(private readonly prisma: PrismaService) {}

  private normalizeEmailList(values: string[] | null | undefined) {
    return Array.from(new Set((values ?? []).map((v) => String(v ?? "").trim().toLowerCase()).filter(Boolean)));
  }

  private async getNotificationEmailSettings(accountId: string): Promise<{ adminEmail: string | null; adminOnlyMode: boolean }> {
    const acc = await this.prisma.account.findUnique({
      where: { id: accountId },
      select: { uiConfig: true },
    });
    const uiConfig = (((acc as any)?.uiConfig as any) ?? {}) as any;
    const rawAdminEmail = String(uiConfig?.notificationAdminEmail ?? "").trim().toLowerCase();
    const adminEmail = rawAdminEmail && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(rawAdminEmail) ? rawAdminEmail : null;
    return { adminEmail, adminOnlyMode: uiConfig?.notificationAdminOnlyMode === true };
  }

  private provider() {
    const cs = process.env.ACS_EMAIL_CONNECTION_STRING || "";
    const from = process.env.ACS_EMAIL_FROM || "";
    if (!cs || !from) throw new Error("Missing ACS_EMAIL_CONNECTION_STRING / ACS_EMAIL_FROM");
    return new AcsEmailProvider(cs, from);
  }

  async processOne(): Promise<boolean> {
    const row = await this.prisma.emailOutbox.findFirst({
      where: { status: EmailOutboxStatus.PENDING },
      orderBy: { createdAt: "asc" },
    });
    if (!row) return false;

    // claim (prevents double send across pods)
    const claimed = await this.prisma.emailOutbox.updateMany({
      where: { id: row.id, status: EmailOutboxStatus.PENDING },
      data: { error: null },
    });
    if (claimed.count !== 1) return false;

    try {
      const attachments = Array.isArray((row.payload as any)?.attachments)
        ? (row.payload as any).attachments
            .filter((item: any) => item && typeof item === "object")
            .map((item: any) => ({
              name: String(item.name ?? "").trim(),
              contentType: String(item.contentType ?? "").trim() || "application/octet-stream",
              contentInBase64: String(item.contentInBase64 ?? "").trim(),
              contentId: String(item.contentId ?? "").trim() || undefined,
            }))
            .filter((item: any) => item.name && item.contentInBase64)
        : [];

      const emailProvider = this.provider();
      const notificationEmailSettings = await this.getNotificationEmailSettings(row.accountId);

      if (notificationEmailSettings.adminOnlyMode) {
        if (!notificationEmailSettings.adminEmail) {
          throw new Error("Notification admin-only test mode is enabled but notificationAdminEmail is not configured");
        }

        await emailProvider.sendEmail({
          to: [notificationEmailSettings.adminEmail],
          cc: [],
          subject: row.subject,
          bodyHtml: row.bodyHtml,
          bodyText: row.bodyText,
          attachments,
        });
      } else {
        await emailProvider.sendEmail({
          to: row.to,
          cc: row.cc,
          subject: row.subject,
          bodyHtml: row.bodyHtml,
          bodyText: row.bodyText,
          attachments,
        });

        try {
          const adminCopyEmail = notificationEmailSettings.adminEmail;
          const existingRecipients = this.normalizeEmailList([...(row.to ?? []), ...(row.cc ?? [])]);
          if (adminCopyEmail && !existingRecipients.includes(adminCopyEmail)) {
            await emailProvider.sendEmail({
              to: [adminCopyEmail],
              subject: row.subject,
              bodyHtml: row.bodyHtml,
              bodyText: row.bodyText,
              attachments,
            });
          }
        } catch (copyErr: any) {
          const msg = String(copyErr?.message ?? copyErr);
          this.log.warn(`Admin copy send skipped id=${row.id} err=${msg}`);
        }
      }

      await this.prisma.emailOutbox.update({
        where: { id: row.id },
        data: { status: EmailOutboxStatus.SENT, sentAt: new Date(), error: null },
      });

      // Optional: keep NotificationAttempt in sync (only if your enum has SENT/FAILED)
      if (row.notificationAttemptId) {
        await this.prisma.notificationAttempt.update({
          where: { id: row.notificationAttemptId },
          data: { status: "SENT", error: null } as any,
        });
      }

      return true;
    } catch (e: any) {
      const msg = String(e?.message ?? e);

      await this.prisma.emailOutbox.update({
        where: { id: row.id },
        data: { status: EmailOutboxStatus.FAILED, error: msg },
      });

      if (row.notificationAttemptId) {
        await this.prisma.notificationAttempt.update({
          where: { id: row.notificationAttemptId },
          data: { status: "FAILED", error: msg } as any,
        });
      }

      this.log.error(`EmailOutbox send failed id=${row.id} err=${msg}`);
      return true;
    }
  }
}
