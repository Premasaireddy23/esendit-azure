import { Module } from "@nestjs/common";
import { EmailOutboxService } from "./email-outbox.service";
import { EmailOutboxRunner } from "./email-outbox.runner";

@Module({
  providers: [EmailOutboxService, EmailOutboxRunner],
})
export class EmailOutboxModule {}
