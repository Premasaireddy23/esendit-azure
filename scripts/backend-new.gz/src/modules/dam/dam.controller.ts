import { Controller, Get, Param, Query, Req, Res, UseGuards, Post } from "@nestjs/common";
import { JwtAuthGuard } from "../../common/auth/jwt-auth.guard";
import { PermissionsGuard } from "../../common/auth/permissions.guard";
import { RequirePermissions } from "../../common/auth/require-permissions.decorator";
import { RequireAnyPermissions } from "../../common/auth/require-any-permissions.decorator";
import { CurrentUser } from "../../common/auth/current-user.decorator";
import { DamService } from "./dam.service";
import { DamIndexerService } from "./dam-indexer.service";
import { ListDamDto } from "./dto/list-dam.dto";

@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller("dam")
export class DamController {
  constructor(
    private readonly svc: DamService,
    private readonly indexer: DamIndexerService,
  ) {}

  @Get("items")
  @RequireAnyPermissions("action:library:read", "action:library:read:scoped", "page:projects", "action:projects:scoped:read")
  list(@CurrentUser() user: any, @Query() dto: ListDamDto) {
    return this.svc.list(user, dto);
  }

  @Get("items/:id")
  @RequireAnyPermissions("action:library:read", "action:library:read:scoped", "page:projects", "action:projects:scoped:read")
  get(@CurrentUser() user: any, @Param("id") id: string) {
    return this.svc.get(user, id);
  }

  @Get("items/:id/thumbnail-url")
  @RequireAnyPermissions("action:library:stream", "action:library:stream:scoped", "page:projects", "action:projects:scoped:read")
  thumbnailUrl(@CurrentUser() user: any, @Param("id") id: string) {
    return this.svc.getThumbnailUrl(user, id);
  }

  @Get("items/:id/assets/:type/stream-url")
  @RequireAnyPermissions("action:library:stream", "action:library:stream:scoped", "page:projects", "action:projects:scoped:read")
  streamUrl(
    @CurrentUser() user: any,
    @Param("id") id: string,
    @Param("type") type: "SOURCE" | "PROXY" | "OUTPUT",
  ) {
    return this.svc.getAssetStreamUrlByType(user, id, type);
  }

  @Get("items/:id/assets/:type/stream")
  @RequireAnyPermissions("action:library:stream", "action:library:stream:scoped", "page:projects", "action:projects:scoped:read")
  stream(
    @CurrentUser() user: any,
    @Param("id") id: string,
    @Param("type") type: "SOURCE" | "PROXY" | "OUTPUT",
    @Req() req: any,
    @Res() res: any,
  ) {
    return this.svc.streamAssetByType(user, id, type, req, res);
  }

  // index a creative into DAM (called from QC page once QC+PROXY done)
  @Post("index/creative/:creativeId")
  @RequirePermissions("action:library:index")
  async indexCreative(@CurrentUser() user: any, @Param("creativeId") creativeId: string) {
    return this.indexer.upsertFromCreative(user.accountId, creativeId);
  }
}
