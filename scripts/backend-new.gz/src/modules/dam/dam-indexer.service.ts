import { Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../../common/prisma/prisma.service";
import { CreativeAssetType, CreativeAssetUploadStatus, DamSourceType } from "@prisma/client";
import * as crypto from "node:crypto";

function norm(v: any) {
  return String(v ?? "").trim().toLowerCase();
}

function buildUniqueEditKey(input: {
  valid?: string | null;
  caption?: string | null;
  format?: string | null;
  duration?: string | null;
  languages?: string[] | null;
}) {
  const raw = [
    norm(input.valid),
    norm(input.caption),
    norm(input.format),
    norm(input.duration),
    (input.languages || []).map(norm).join(","),
  ].join("|");
  return crypto.createHash("sha1").update(raw).digest("hex");
}

function buildSearchText(input: {
  valid?: string | null;
  caption?: string | null;
  format?: string | null;
  duration?: string | null;
  remarks?: string | null;
  languages?: string[] | null;
}) {
  return [
    input.valid,
    input.caption,
    input.format,
    input.duration,
    input.remarks,
    ...(input.languages || []),
  ]
    .filter(Boolean)
    .join(" ")
    .toLowerCase();
}

@Injectable()
export class DamIndexerService {
  constructor(private prisma: PrismaService) {}

  async upsertFromCreative(accountId: string, creativeId: string) {
    const creative = await this.prisma.creative.findFirst({
      where: { id: creativeId, accountId },
      include: { assets: true },
    });
    if (!creative) throw new NotFoundException("Creative not found");

    const key = buildUniqueEditKey(creative);
    const searchText = buildSearchText(creative);

    // Prefer SOURCE, fallback PROXY for playback at least
    const src = creative.assets.find(
      (a) => a.type === CreativeAssetType.SOURCE && a.uploadStatus === CreativeAssetUploadStatus.UPLOADED,
    );
    const proxy = creative.assets.find(
      (a) => a.type === CreativeAssetType.PROXY && a.uploadStatus === CreativeAssetUploadStatus.UPLOADED,
    );
    const output = creative.assets.find(
      (a) => a.type === CreativeAssetType.OUTPUT && a.uploadStatus === CreativeAssetUploadStatus.UPLOADED,
    );

    const dam = await this.prisma.damItem.upsert({
      where: { accountId_uniqueEditKey: { accountId, uniqueEditKey: key } },
      update: {
        sourceType: DamSourceType.CREATIVE,
        sourceCreativeId: creative.id,
        valid: creative.valid,
        caption: creative.caption,
        format: creative.format,
        languages: creative.languages,
        duration: creative.duration,
        remarks: creative.remarks,
        qcStatus: creative.qcStatus as any,
        qcFailureReasons: (creative as any).qcFailureReasons || [],
        qcReport: (creative as any).qcReport,
        autoQcStartedAt: (creative as any).autoQcStartedAt,
        autoQcEndedAt: (creative as any).autoQcEndedAt,
        searchText,
      },
      create: {
        accountId,
        sourceType: DamSourceType.CREATIVE,
        sourceCreativeId: creative.id,
        uniqueEditKey: key,
        valid: creative.valid,
        caption: creative.caption,
        format: creative.format,
        languages: creative.languages,
        duration: creative.duration,
        remarks: creative.remarks,
        qcStatus: creative.qcStatus as any,
        qcFailureReasons: (creative as any).qcFailureReasons || [],
        qcReport: (creative as any).qcReport,
        autoQcStartedAt: (creative as any).autoQcStartedAt,
        autoQcEndedAt: (creative as any).autoQcEndedAt,
        searchText,
      },
    });

    // Replace assets snapshot (simple + safe)
    await this.prisma.damAsset.deleteMany({ where: { accountId, damItemId: dam.id } });

    const toInsert = [src, proxy, output].filter(Boolean).map((a: any) => ({
      accountId,
      damItemId: dam.id,
      type: a.type,
      path: a.path,
      filename: a.filename,
      mimeType: a.mimeType,
      sizeBytes: a.sizeBytes,
      bytesTotal: a.bytesTotal,
      bytesReceived: a.bytesReceived,
      uploadStatus: a.uploadStatus,
      uploadStartedAt: a.uploadStartedAt,
      uploadEndedAt: a.uploadEndedAt,
      error: a.error,
    }));

    if (toInsert.length) {
      await this.prisma.damAsset.createMany({ data: toInsert });
    }

    return dam;
  }
}
