import { IsInt, IsOptional, IsString, Max, Min } from "class-validator";
import { Type } from "class-transformer";

export class ListDamDto {
  @IsOptional() @IsString()
  q?: string;

  @IsOptional() @IsString()
  format?: string;

  @IsOptional() @IsString()
  valid?: string;

  @IsOptional() @IsString()
  qcStatus?: string;

  @IsOptional() @IsString()
  language?: string;

  @IsOptional()
  @Type(() => Number) @IsInt() @Min(0)
  skip?: number = 0;

  @IsOptional()
  @Type(() => Number) @IsInt() @Min(1) @Max(200)
  take?: number = 50;
}
