import { BadRequestException, ForbiddenException, Inject, Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../../common/prisma/prisma.service";
import { damItemSelect } from "./dam.select";
import { ListDamDto } from "./dto/list-dam.dto";
import * as fs from "node:fs/promises";
import { createReadStream } from "node:fs";
import * as path from "node:path";
import { STORAGE } from "../../common/storage/storage.token";
import type { StorageService } from "../../common/storage/storage.types";
import { SignedStreamService } from "../../common/stream/signed-stream.service";
import { AzureBlobService } from "../../common/storage/azure-blob.service";
import { ProjectAccessService } from "../../common/project-access/project-access.service";

function looksLikeLocalPath(p: string): boolean {
  return path.isAbsolute(p) || /^[a-zA-Z]:\\/.test(p) || p.startsWith("./") || p.startsWith("../");
}

function firstFilmstripFrame(qcReport: any): string | null {
  const a = Array.isArray(qcReport?.artifacts?.filmstrip?.frames) ? qcReport.artifacts.filmstrip.frames : null;
  if (a?.length) return String(a[0]);

  const b = Array.isArray(qcReport?.filmstrip?.frames) ? qcReport.filmstrip.frames : null;
  if (b?.length) return String(b[0]);

  return null;
}

function safeArtifactPath(name: string): string {
  let raw = String(name || "");
  try {
    raw = decodeURIComponent(raw);
  } catch {
    // ignore malformed escape sequences
  }

  raw = raw.replace(/^\/+/, "");
  raw = raw.replace(/\/(stream-url|stream)\/?$/i, "");
  if (/^filmstrip,frame_/i.test(raw)) raw = raw.replace(",", "/");
  return raw;
}

type LibraryRef =
  | { kind: "dam"; id: string }
  | { kind: "creative"; id: string };

function parseLibraryRef(id: string): LibraryRef {
  const raw = String(id || "").trim();
  if (raw.startsWith("creative:")) {
    const creativeId = raw.slice("creative:".length).trim();
    if (!creativeId) throw new BadRequestException("Invalid DAM item id");
    return { kind: "creative", id: creativeId };
  }
  if (!raw) throw new BadRequestException("Invalid DAM item id");
  return { kind: "dam", id: raw };
}

function looksLikeVideoAsset(asset: { type?: string | null; mimeType?: string | null; filename?: string | null }): boolean {
  const mime = String(asset?.mimeType || "").toLowerCase();
  const filename = String(asset?.filename || "").toLowerCase();
  const type = String(asset?.type || "").toUpperCase();
  if (mime.startsWith("video/")) return true;
  if (type === "PROXY") return true;
  return /\.(mp4|mov|m4v|webm|avi|mxf|mpeg|mpg|wmv)$/i.test(filename);
}

@Injectable()
export class DamService {
  constructor(
    private prisma: PrismaService,
    @Inject(STORAGE) private storage: StorageService,
    private readonly signed: SignedStreamService,
    private readonly blobs: AzureBlobService,
    private readonly projectAccess: ProjectAccessService,
  ) {}

  private accountIdOf(user: any) {
    return String(user?.accountId || "").trim();
  }

  private hasGlobalLibraryRead(user: any) {
    return this.projectAccess.hasAnyPerm(user, ["action:library:read", "action:dam:read", "page:library", "page:dam"]);
  }

  private hasGlobalLibraryStream(user: any) {
    return this.projectAccess.hasAnyPerm(user, ["action:library:stream", "action:dam:stream", "action:media:download"]);
  }

  private async projectIdForLibraryRef(accountId: string, ref: LibraryRef) {
    if (ref.kind === "creative") return this.projectAccess.projectIdForCreative(accountId, ref.id);

    const dam = await this.prisma.damItem.findFirst({
      where: { id: ref.id, accountId },
      select: { id: true, sourceCreativeId: true },
    });
    if (!dam) throw new NotFoundException("DAM item not found");
    if (!dam.sourceCreativeId) return null;
    return this.projectAccess.projectIdForCreative(accountId, dam.sourceCreativeId);
  }

  private async creativeIdForLibraryRef(accountId: string, ref: LibraryRef) {
    if (ref.kind === "creative") return ref.id;

    const dam = await this.prisma.damItem.findFirst({
      where: { id: ref.id, accountId },
      select: { id: true, sourceCreativeId: true },
    });
    if (!dam) throw new NotFoundException("DAM item not found");
    return dam.sourceCreativeId || null;
  }

  private async assertLibraryRefAccess(user: any, ref: LibraryRef, mode: "read" | "stream" = "read") {
    const accountId = this.accountIdOf(user);
    if (!accountId) throw new ForbiddenException("Unauthorised");

    if (mode === "stream" && this.hasGlobalLibraryStream(user)) return;
    if (mode === "read" && this.hasGlobalLibraryRead(user)) return;

    const projectId = await this.projectIdForLibraryRef(accountId, ref);
    if (!projectId) throw new ForbiddenException("Unauthorised");

    if (mode === "stream") {
      await this.projectAccess.assertCanStreamDam(user, projectId);
    } else {
      await this.projectAccess.assertCanViewDam(user, projectId);
    }

    const creativeId = await this.creativeIdForLibraryRef(accountId, ref);
    if (creativeId && !(await this.projectAccess.canViewCreativeInProject(user, projectId, creativeId))) {
      throw new ForbiddenException("Unauthorised");
    }
  }

  private async canViewDamRow(user: any, row: any) {
    if (this.hasGlobalLibraryRead(user)) return true;
    const creativeId = String(row?.sourceCreativeId || "");
    if (!creativeId) return false;

    try {
      const projectId = await this.projectAccess.projectIdForCreative(this.accountIdOf(user), creativeId);
      const access = await this.projectAccess.getProjectAccess(user, projectId);
      if (!access.canViewDam) return false;
      return this.projectAccess.canViewCreativeInProject(user, projectId, creativeId);
    } catch {
      return false;
    }
  }

  private async canViewCreativeRow(user: any, row: any) {
    if (this.hasGlobalLibraryRead(user)) return true;
    const projectId = String(row?.projectId || "");
    if (!projectId) return false;

    try {
      const access = await this.projectAccess.getProjectAccess(user, projectId);
      if (!access.canViewDam) return false;
      return this.projectAccess.canViewCreativeInProject(user, projectId, String(row?.id || ""));
    } catch {
      return false;
    }
  }

  private buildDamWhere(accountId: string, dto: ListDamDto) {
    const where: any = { accountId };

    if (dto.q?.trim()) where.searchText = { contains: dto.q.trim().toLowerCase() };
    if (dto.format?.trim()) where.format = { equals: dto.format.trim(), mode: "insensitive" };
    if (dto.valid?.trim()) where.valid = { contains: dto.valid.trim(), mode: "insensitive" };
    if (dto.qcStatus?.trim()) where.qcStatus = dto.qcStatus.trim();
    if (dto.language?.trim()) where.languages = { has: dto.language.trim() };

    return where;
  }

  private buildCreativeWhere(accountId: string, dto: ListDamDto) {
    const where: any = {
      accountId,
      assets: {
        some: {
          type: { in: ["SOURCE", "PROXY", "OUTPUT"] as any },
        },
      },
    };

    if (dto.format?.trim()) where.format = { equals: dto.format.trim(), mode: "insensitive" };
    if (dto.valid?.trim()) where.valid = { contains: dto.valid.trim(), mode: "insensitive" };
    if (dto.qcStatus?.trim()) where.qcStatus = dto.qcStatus.trim();
    if (dto.language?.trim()) where.languages = { has: dto.language.trim() };

    const q = dto.q?.trim();
    if (q) {
      const upper = q.toUpperCase();
      where.OR = [
        { valid: { contains: q, mode: "insensitive" } },
        { caption: { contains: q, mode: "insensitive" } },
        { format: { contains: q, mode: "insensitive" } },
        { remarks: { contains: q, mode: "insensitive" } },
        { uniqueEditKey: { contains: q, mode: "insensitive" } },
        { languages: { has: upper } },
      ];
    }

    return where;
  }

  private mapCreativeToLibraryItem(row: any) {
    return {
      id: `creative:${row.id}`,
      uniqueEditKey: row.uniqueEditKey || row.id,
      sourceType: "CREATIVE",
      sourceCreativeId: row.id,
      sourceBulkItemId: null,
      valid: row.valid,
      caption: row.caption,
      format: row.format,
      languages: Array.isArray(row.languages) ? row.languages : [],
      duration: row.duration,
      remarks: row.remarks,
      qcStatus: row.qcStatus || "NOT_STARTED",
      qcFailureReasons: Array.isArray(row.qcFailureReasons) ? row.qcFailureReasons : [],
      qcReport: row.qcReport ?? null,
      autoQcStartedAt: row.autoQcStartedAt ?? null,
      autoQcEndedAt: row.autoQcEndedAt ?? null,
      createdAt: row.createdAt,
      updatedAt: row.updatedAt,
      assets: Array.isArray(row.assets) ? row.assets : [],
    };
  }

  private async listCreativeFallback(user: any, dto: ListDamDto) {
    const accountId = this.accountIdOf(user);
    const where = this.buildCreativeWhere(accountId, dto);

    const rows = await this.prisma.creative.findMany({
      where,
      orderBy: { updatedAt: "desc" },
      skip: dto.skip ?? 0,
      take: dto.take ?? 50,
      select: {
        id: true,
        projectId: true,
        uniqueEditKey: true,
        valid: true,
        caption: true,
        format: true,
        languages: true,
        duration: true,
        remarks: true,
        qcStatus: true,
        qcFailureReasons: true,
        qcReport: true,
        autoQcStartedAt: true,
        autoQcEndedAt: true,
        createdAt: true,
        updatedAt: true,
        assets: {
          select: {
            id: true,
            type: true,
            path: true,
            filename: true,
            mimeType: true,
            uploadStatus: true,
            sizeBytes: true,
            bytesTotal: true,
            bytesReceived: true,
            uploadStartedAt: true,
            uploadEndedAt: true,
            error: true,
          },
        },
      },
    });

    const videoRows = rows.filter((row) => Array.isArray(row.assets) && row.assets.some((asset: any) => looksLikeVideoAsset(asset)));
    const filteredRows: any[] = [];
    for (const row of videoRows as any[]) {
      if (await this.canViewCreativeRow(user, row)) filteredRows.push(row);
    }

    const total = this.hasGlobalLibraryRead(user) ? await this.prisma.creative.count({ where }) : filteredRows.length;
    return { rows: filteredRows.map((row) => this.mapCreativeToLibraryItem(row)), total };
  }

  async list(user: any, dto: ListDamDto) {
    const accountId = this.accountIdOf(user);
    const where = this.buildDamWhere(accountId, dto);

    const [rows, total] = await Promise.all([
      this.prisma.damItem.findMany({
        where,
        orderBy: { updatedAt: "desc" },
        skip: dto.skip ?? 0,
        take: dto.take ?? 50,
        select: damItemSelect as any,
      }),
      this.prisma.damItem.count({ where }),
    ]);

    if (total > 0 || rows.length > 0) {
      if (this.hasGlobalLibraryRead(user)) return { rows, total };

      const filteredRows: any[] = [];
      for (const row of rows as any[]) {
        if (await this.canViewDamRow(user, row)) filteredRows.push(row);
      }
      return { rows: filteredRows, total: filteredRows.length };
    }

    // Fallback for older accounts where creatives exist but DAM indexing has not yet populated rows.
    return this.listCreativeFallback(user, dto);
  }

  async get(user: any, id: string) {
    const accountId = this.accountIdOf(user);
    const ref = parseLibraryRef(id);
    await this.assertLibraryRefAccess(user, ref, "read");

    if (ref.kind === "creative") {
      const row = await this.prisma.creative.findFirst({
        where: { id: ref.id, accountId },
        select: {
          id: true,
          uniqueEditKey: true,
          valid: true,
          caption: true,
          format: true,
          languages: true,
          duration: true,
          remarks: true,
          qcStatus: true,
          qcFailureReasons: true,
          qcReport: true,
          autoQcStartedAt: true,
          autoQcEndedAt: true,
          createdAt: true,
          updatedAt: true,
          assets: {
            select: {
              id: true,
              type: true,
              path: true,
              filename: true,
              mimeType: true,
              uploadStatus: true,
              sizeBytes: true,
              bytesTotal: true,
              bytesReceived: true,
              uploadStartedAt: true,
              uploadEndedAt: true,
              error: true,
            },
          },
        },
      });
      if (!row) throw new NotFoundException("DAM item not found");
      return this.mapCreativeToLibraryItem(row);
    }

    const row = await this.prisma.damItem.findFirst({
      where: { id: ref.id, accountId },
      select: damItemSelect as any,
    });
    if (!row) throw new NotFoundException("DAM item not found");
    return row;
  }

  private async getAssetRecordByRef(accountId: string, ref: LibraryRef, type: "SOURCE" | "PROXY" | "OUTPUT") {
    if (ref.kind === "creative") {
      const asset: any = await this.prisma.creativeAsset.findFirst({
        where: { accountId, creativeId: ref.id, type: type as any },
        select: { path: true, mimeType: true, filename: true },
      });
      if (!asset) throw new NotFoundException(`${type} asset not found`);
      return asset;
    }

    const asset: any = await this.prisma.damAsset.findFirst({
      where: { accountId, damItemId: ref.id, type: type as any },
      select: { path: true, mimeType: true, filename: true },
    });
    if (!asset) throw new NotFoundException(`${type} asset not found`);
    return asset;
  }

  async getAssetStreamUrlByType(user: any, damItemId: string, type: "SOURCE" | "PROXY" | "OUTPUT") {
    const accountId = this.accountIdOf(user);
    const ref = parseLibraryRef(damItemId);
    await this.assertLibraryRefAccess(user, ref, "stream");
    const asset = await this.getAssetRecordByRef(accountId, ref, type);

    const filename = asset.filename || type.toLowerCase();
    if (this.storage.isCloud() && !looksLikeLocalPath(String(asset.path))) {
      const url = await this.storage.getSignedReadUrl(String(asset.path), 30, {
        contentType: asset.mimeType || undefined,
        contentDisposition: `inline; filename=\"${filename}\"`,
      });
      return { url };
    }

    const url = this.signed.makeUrl({
      path: String(asset.path),
      mimeType: asset.mimeType || undefined,
      filename,
      disposition: "inline",
      ttlSeconds: 600,
    });
    return { url };
  }

  private async getCreativeThumbUrl(user: any, creativeId: string): Promise<{ url: string | null; kind: "image" | "video" | null }> {
    const accountId = this.accountIdOf(user);
    const creative: any = await this.prisma.creative.findFirst({
      where: { id: creativeId, accountId },
      select: { id: true, projectId: true, qcReport: true },
    });
    if (!creative) throw new NotFoundException("Creative not found");

    const filmFrame = firstFilmstripFrame(creative.qcReport);
    if (filmFrame) {
      const req = safeArtifactPath(filmFrame);
      const filename = path.basename(req) || "thumbnail.jpg";

      const src: any = await this.prisma.creativeAsset.findFirst({
        where: { accountId, creativeId: creative.id, type: "SOURCE" as any },
        select: { path: true },
      });

      if (src?.path && looksLikeLocalPath(String(src.path))) {
        const qcDir = path.join(path.dirname(String(src.path)), "qc");
        const filePath = path.resolve(path.join(qcDir, req));
        const base = path.resolve(qcDir);
        if (filePath.startsWith(base)) {
          try {
            await fs.access(filePath);
            return {
              url: this.signed.makeUrl({
                path: filePath,
                mimeType: "image/jpeg",
                filename,
                disposition: "inline",
                ttlSeconds: 600,
              }),
              kind: "image",
            };
          } catch {
            // fall through
          }
        }
      }

      if (this.blobs.isConfigured()) {
        const qcContainer = process.env.QC_OUTPUT_CONTAINER || process.env.QC_ARTIFACTS_CONTAINER || "";
        const keyPrefix = qcContainer ? `${qcContainer}::` : "";
        const blobKey = `${keyPrefix}creatives/${accountId}/${creative.projectId}/${creative.id}/qc/${req}`;
        return {
          url: await this.blobs.createReadSasUrl(blobKey, "image/jpeg", `inline; filename=\"${filename}\"`, 30),
          kind: "image",
        };
      }
    }

    try {
      const { url } = await this.getAssetStreamUrlByType(user, `creative:${creative.id}`, "PROXY");
      return { url, kind: "video" };
    } catch {
      // fallback to source
    }

    try {
      const { url } = await this.getAssetStreamUrlByType(user, `creative:${creative.id}`, "SOURCE");
      return { url, kind: "video" };
    } catch {
      return { url: null, kind: null };
    }
  }

  async getThumbnailUrl(user: any, damItemId: string): Promise<{ url: string | null; kind: "image" | "video" | null }> {
    const accountId = this.accountIdOf(user);
    const ref = parseLibraryRef(damItemId);
    await this.assertLibraryRefAccess(user, ref, "stream");
    if (ref.kind === "creative") {
      return this.getCreativeThumbUrl(user, ref.id);
    }

    const dam: any = await this.prisma.damItem.findFirst({
      where: { id: ref.id, accountId },
      select: { id: true, sourceCreativeId: true, qcReport: true },
    });
    if (!dam) throw new NotFoundException("DAM item not found");

    const filmFrame = firstFilmstripFrame(dam.qcReport);
    if (dam.sourceCreativeId && filmFrame) {
      const creative = await this.prisma.creative.findFirst({
        where: { id: dam.sourceCreativeId, accountId },
        select: { id: true, projectId: true },
      });

      if (creative) {
        const req = safeArtifactPath(filmFrame);
        const filename = path.basename(req) || "thumbnail.jpg";

        const src: any = await this.prisma.creativeAsset.findFirst({
          where: { accountId, creativeId: creative.id, type: "SOURCE" as any },
          select: { path: true },
        });

        if (src?.path && looksLikeLocalPath(String(src.path))) {
          const qcDir = path.join(path.dirname(String(src.path)), "qc");
          const filePath = path.resolve(path.join(qcDir, req));
          const base = path.resolve(qcDir);
          if (filePath.startsWith(base)) {
            try {
              await fs.access(filePath);
              return {
                url: this.signed.makeUrl({
                  path: filePath,
                  mimeType: "image/jpeg",
                  filename,
                  disposition: "inline",
                  ttlSeconds: 600,
                }),
                kind: "image",
              };
            } catch {
              // fall through to blob/fallback video
            }
          }
        }

        if (this.blobs.isConfigured()) {
          const qcContainer = process.env.QC_OUTPUT_CONTAINER || process.env.QC_ARTIFACTS_CONTAINER || "";
          const keyPrefix = qcContainer ? `${qcContainer}::` : "";
          const blobKey = `${keyPrefix}creatives/${accountId}/${creative.projectId}/${creative.id}/qc/${req}`;
          return {
            url: await this.blobs.createReadSasUrl(blobKey, "image/jpeg", `inline; filename=\"${filename}\"`, 30),
            kind: "image",
          };
        }
      }
    }

    try {
      const { url } = await this.getAssetStreamUrlByType(user, ref.id, "PROXY");
      return { url, kind: "video" };
    } catch {
      // fallback to source for older records without proxy
    }

    try {
      const { url } = await this.getAssetStreamUrlByType(user, ref.id, "SOURCE");
      return { url, kind: "video" };
    } catch {
      return { url: null, kind: null };
    }
  }

  async streamAssetByType(user: any, damItemId: string, type: "SOURCE" | "PROXY" | "OUTPUT", req: any, res: any) {
    const accountId = this.accountIdOf(user);
    const ref = parseLibraryRef(damItemId);
    await this.assertLibraryRefAccess(user, ref, "stream");
    const asset = await this.getAssetRecordByRef(accountId, ref, type);

    if (this.storage.isCloud() && !looksLikeLocalPath(String(asset.path))) {
      const url = await this.storage.getSignedReadUrl(String(asset.path), 30, {
        contentType: asset.mimeType || undefined,
      });
      return res.redirect(302, url);
    }

    const stat = await fs.stat(asset.path);
    const mimeType = asset.mimeType || (type === "PROXY" ? "video/mp4" : "application/octet-stream");

    const range = req.headers?.range as string | undefined;
    if (!range) {
      res.setHeader("Content-Type", mimeType);
      res.setHeader("Content-Length", stat.size);
      res.setHeader("Accept-Ranges", "bytes");
      createReadStream(asset.path).pipe(res);
      return;
    }

    const m = /^bytes=(\d+)-(\d*)$/.exec(range);
    if (!m) return res.status(416).end();

    const start = Number(m[1]);
    const end = m[2] ? Number(m[2]) : stat.size - 1;

    if (start >= stat.size || end >= stat.size || start > end) return res.status(416).end();

    res.status(206);
    res.setHeader("Content-Type", mimeType);
    res.setHeader("Accept-Ranges", "bytes");
    res.setHeader("Content-Range", `bytes ${start}-${end}/${stat.size}`);
    res.setHeader("Content-Length", end - start + 1);

    createReadStream(asset.path, { start, end }).pipe(res);
  }
}
