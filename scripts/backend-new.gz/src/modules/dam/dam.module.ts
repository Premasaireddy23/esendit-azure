import { Module } from "@nestjs/common";
import { DamController } from "./dam.controller";
import { DamService } from "./dam.service";
import { DamIndexerService } from "./dam-indexer.service";
import { StorageModule } from "../../common/storage/storage.module";

@Module({
  imports: [StorageModule],
  controllers: [DamController],
  providers: [DamService, DamIndexerService],
  exports: [DamIndexerService],
})
export class DamModule {}
