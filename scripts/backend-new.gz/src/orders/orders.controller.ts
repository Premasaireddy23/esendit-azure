import { Controller, Param, Post, UseGuards } from "@nestjs/common";
import { OrdersService } from "./orders.service";
import { JwtAuthGuard } from "../common/auth/jwt-auth.guard";
import { PermissionsGuard } from "../common/auth/permissions.guard";
import { CurrentUser, AuthUser } from "../common/auth/current-user.decorator";
import { RequirePermissions } from "../common/auth/require-permissions.decorator";

@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller()
export class OrdersController {
  constructor(private readonly orders: OrdersService) {}

  @RequirePermissions("ORDER_SEND")
  @Post("/projects/:id/orders")
  createOrder(@Param("id") projectId: string, @CurrentUser() user: AuthUser) {
    return this.orders.createOrderForProject(projectId, user);
  }

  @RequirePermissions("ORDER_SEND")
  @Post("/orders/:id/send")
  send(@Param("id") orderId: string, @CurrentUser() user: AuthUser) {
    return this.orders.send(orderId, user);
  }
}
