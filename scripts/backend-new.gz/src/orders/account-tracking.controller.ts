import { Controller, Get, Query, UseGuards } from "@nestjs/common";
import { JwtAuthGuard } from "../common/auth/jwt-auth.guard";
import { PermissionsGuard } from "../common/auth/permissions.guard";
import { RequireAnyPermissions } from "../common/auth/require-any-permissions.decorator";
import { CurrentUser } from "../common/auth/current-user.decorator";
import { TrackingService } from "./tracking.service";

@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller("tracking")
export class AccountTrackingController {
  constructor(private readonly svc: TrackingService) {}

  @Get()
  @RequireAnyPermissions("action:tracking:read", "action:tracking:read:scoped", "page:projects", "action:projects:scoped:read")
  async getAccountTracking(
    @CurrentUser() user: any,
    @Query("take") take?: string,
    @Query("skip") skip?: string,
  ) {
    const t = Math.min(1000, Math.max(1, parseInt(take || "500", 10) || 500));
    const s = Math.max(0, parseInt(skip || "0", 10) || 0);
    return this.svc.getAccountTracking(user, t, s);
  }
}
