import { Module } from "@nestjs/common";
import { PrismaModule } from "src/common/prisma/prisma.module";
import { StorageModule } from "src/common/storage/storage.module";
import { OrdersController } from "./orders.controller";
import { OrdersService } from "./orders.service";
import { TrackingController } from "./tracking.controller";
import { AccountTrackingController } from "./account-tracking.controller";
import { TrackingService } from "./tracking.service";

import { SendQueueController } from "./send-queue.controller";
import { SendQueueService } from "./send-queue.service";

import { DeliveryTasksController } from "./delivery-tasks.controller";
import { DeliveryTasksService } from "./delivery-tasks.service";


@Module({
  imports: [PrismaModule, StorageModule],
  controllers: [OrdersController, TrackingController, AccountTrackingController, SendQueueController, DeliveryTasksController],
  providers: [OrdersService, TrackingService, SendQueueService, DeliveryTasksService],
})
export class OrdersModule {}
