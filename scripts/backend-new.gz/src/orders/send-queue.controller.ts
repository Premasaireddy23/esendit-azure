import { Controller, Get, Param, UseGuards } from "@nestjs/common";
import { JwtAuthGuard } from "../common/auth/jwt-auth.guard";
import { PermissionsGuard } from "../common/auth/permissions.guard";
import { RequirePermissions } from "../common/auth/require-permissions.decorator";
import { CurrentUser } from "../common/auth/current-user.decorator";
import { SendQueueService } from "./send-queue.service";

@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller("projects/:projectId/send-queue")
export class SendQueueController {
  constructor(private readonly svc: SendQueueService) {}

  @Get()
  @RequirePermissions("ORDER_SEND")
  async getSendQueue(@CurrentUser() user: any, @Param("projectId") projectId: string) {
    return this.svc.getSendQueue(user.accountId, projectId);
  }
}
