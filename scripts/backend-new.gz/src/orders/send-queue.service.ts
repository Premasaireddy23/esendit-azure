import { Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../common/prisma/prisma.service";
import { extractPresetJobOutput, getLatestCreativePresetJob, resolveChannelDefaultPreset } from "../common/presets/channel-default-preset";

export type SendQueueRow = {
  planLineId: string;
  projectId: string;
  planVersionId: string;
  planVersion: number;

  creativeId: string;
  valid: string;
  creativeName: string;
  caption?: string | null;
  duration?: string | null;
  languages?: string[];
  format?: string | null;
  audio?: string | null;

  advertiserGroup?: string | null;
  advertiser?: string | null;
  brand?: string | null;
  productCategory?: string | null;

  mediaAgency?: string | null;
  mediaAgencyTeam?: string | null;
  creativeAgency?: string | null;
  creativeAgencyTeam?: string | null;
  productionHouse?: string | null;
  productionHouseTeam?: string | null;
  postHouse?: string | null;
  postHouseTeam?: string | null;
  audioAgency?: string | null;
  audioAgencyTeam?: string | null;

  billableParty?: string | null;

  destinationId: string | null;
  destinationName: string;
  channelId: string;
  channelName: string;
  channelServerStatus?: string | null;
  channelServerMessage?: string | null;

  slaId: string | null;
  slaName: string | null;
  autoSendAt?: string | null;

  // best-effort file info for “what will be sent”
  uploaderEmail?: string | null;
  uploadedAt?: string | null;
  filename?: string | null;
  mimeType?: string | null;
  fileSizeBytes?: string | null;

  qcStatus?: string | null;
  qcFailureReasons?: string[];

  approvalStatus?: string | null;
  lastApprovalAt?: string | null;
  presetKey?: string | null;
  presetLabel?: string | null;
  presetStatus?: string | null;
  approvalStep1Label?: string | null;
  approvalStep1Status?: string | null;
  approvalStep1DecidedBy?: string | null;
  approvalStep2Label?: string | null;
  approvalStep2Status?: string | null;
  approvalStep2DecidedBy?: string | null;
};

@Injectable()
export class SendQueueService {
  constructor(private prisma: PrismaService) {}

  async getSendQueue(
    accountId: string,
    projectId: string,
  ): Promise<{ activePlan: { id: string; version: number } | null; unsentLines: number; rows: SendQueueRow[] }> {
    const project = await this.prisma.project.findFirst({
      where: { id: projectId, accountId },
      select: {
        id: true,
        projectNumber: true,
        name: true,
        advertiserGroup: { select: { name: true } },
        advertiser: { select: { name: true } },
        brand: { select: { name: true } },
        productCategory: { select: { name: true } },
        mediaAgency: { select: { name: true } },
        mediaAgencyTeam: { select: { name: true } },
        creativeAgency: { select: { name: true } },
        creativeAgencyTeam: { select: { name: true } },
        productionHouse: { select: { name: true } },
        productionHouseTeam: { select: { name: true } },
        postHouse: { select: { name: true } },
        postHouseTeam: { select: { name: true } },
        audioAgency: { select: { name: true } },
        audioAgencyTeam: { select: { name: true } },
        billableParty: { select: { name: true } },
      },
    });
    if (!project) throw new NotFoundException("Project not found");

    const active = await this.prisma.planVersion.findFirst({
      where: { accountId, projectId, isActive: true },
      select: { id: true, version: true },
    });

    if (!active) {
      return { activePlan: null, unsentLines: 0, rows: [] };
    }

    const lines = await this.prisma.planLine.findMany({
      where: { accountId, planVersionId: active.id, sentAt: null },
      orderBy: [{ createdAt: "asc" }],
      select: {
        id: true,
        creativeId: true,
        channelId: true,
        slaId: true,
        autoSendAt: true,
        creative: {
          select: {
            id: true,
            name: true,
            valid: true,
            caption: true,
            duration: true,
            languages: true,
            format: true,
            audio: true,
            qcStatus: true,
            qcFailureReasons: true,
            approvalRequest: {
              select: {
                id: true,
                status: true,
                completedAt: true,
                steps: {
                  select: {
                    order: true,
                    label: true,
                    status: true,
                    decidedByUser: { select: { email: true } },
                  },
                  orderBy: { order: "asc" },
                },
              },
            },
            assets: {
              select: {
                type: true,
                uploadStatus: true,
                filename: true,
                mimeType: true,
                sizeBytes: true,
                uploadEndedAt: true,
                uploadedByUser: { select: { email: true } },
              },
              orderBy: { createdAt: "desc" },
            },
          },
        },
        channel: {
          select: {
            id: true,
            name: true,
            destinationId: true,
            config: true,
            destination: { select: { id: true, name: true } },
            serverStatus: true,
            serverMessage: true,
          },
        },
        sla: { select: { id: true, name: true } },
      },
    });

    const rows: SendQueueRow[] = await Promise.all(
      lines.map(async (pl: any) => {
        const creative = pl?.creative;
        const channel = pl?.channel;

        const destinationId = channel?.destinationId ?? channel?.destination?.id ?? null;
        const destinationName = channel?.destination?.name ?? "";

        const valid = creative?.valid ?? "";
        const creativeName = valid || creative?.name || "";

        const assets: any[] = Array.isArray(creative?.assets) ? creative.assets : [];
        let best =
          assets.find((a) => a?.type === "OUTPUT" && a?.uploadStatus === "UPLOADED") ??
          assets.find((a) => a?.type === "SOURCE" && a?.uploadStatus === "UPLOADED") ??
          assets[0] ??
          null;

        let presetKey: string | null = null;
        let presetLabel: string | null = null;
        let presetStatus: string | null = null;

        const selectedPreset = await resolveChannelDefaultPreset(this.prisma, accountId, channel);
        if (selectedPreset) {
          presetKey = selectedPreset.key;
          presetLabel = selectedPreset.label ?? selectedPreset.key;
          const presetJob = await getLatestCreativePresetJob(this.prisma, accountId, pl.creativeId, selectedPreset.key);
          const req = creative?.approvalRequest ?? null;
          const approvalPending = !!req && req.status !== "APPROVED";
          presetStatus = presetJob?.status ? String(presetJob.status) : approvalPending ? "WAITING_APPROVAL" : "NOT_REQUESTED";
          const output = presetJob ? extractPresetJobOutput(presetJob) : null;
          if (output?.path) {
            best = {
              type: "OUTPUT",
              uploadStatus: presetStatus === "SUCCEEDED" ? "UPLOADED" : "PENDING",
              filename: output.filename,
              mimeType: output.mimeType,
              sizeBytes: output.bytes,
              uploadEndedAt: output.endedAt,
              uploadedByUser: null,
            };
          }
        }

        const uploadedAt = best?.uploadEndedAt ? new Date(best.uploadEndedAt).toISOString() : null;
        const uploaderEmail = best?.uploadedByUser?.email ?? null;
        const fileSizeBytes = best?.sizeBytes != null ? String(best.sizeBytes) : null;
        const mimeType = best?.mimeType ?? null;
        const filename = best?.filename ?? null;

        const req = creative?.approvalRequest ?? null;
        const steps: any[] = Array.isArray(req?.steps) ? req.steps : [];
        const s1 = steps[0] ?? null;
        const s2 = steps[1] ?? null;

        return {
          planLineId: pl.id,
          projectId,
          planVersionId: active.id,
          planVersion: active.version,

          creativeId: pl.creativeId,
          valid,
          creativeName,
          caption: creative?.caption ?? null,
          duration: creative?.duration ?? null,
          languages: creative?.languages ?? [],
          format: creative?.format ?? null,
          audio: creative?.audio ?? null,

          advertiserGroup: project.advertiserGroup?.name ?? null,
          advertiser: project.advertiser?.name ?? null,
          brand: project.brand?.name ?? null,
          productCategory: project.productCategory?.name ?? null,

          mediaAgency: project.mediaAgency?.name ?? null,
          mediaAgencyTeam: project.mediaAgencyTeam?.name ?? null,
          creativeAgency: project.creativeAgency?.name ?? null,
          creativeAgencyTeam: project.creativeAgencyTeam?.name ?? null,
          productionHouse: project.productionHouse?.name ?? null,
          productionHouseTeam: project.productionHouseTeam?.name ?? null,
          postHouse: project.postHouse?.name ?? null,
          postHouseTeam: project.postHouseTeam?.name ?? null,
          audioAgency: project.audioAgency?.name ?? null,
          audioAgencyTeam: project.audioAgencyTeam?.name ?? null,

          billableParty: project.billableParty?.name ?? null,

          destinationId,
          destinationName,
          channelId: pl.channelId,
          channelName: channel?.name ?? "",
          channelServerStatus: channel?.serverStatus ?? null,
          channelServerMessage: channel?.serverMessage ?? null,

          slaId: pl.slaId ?? null,
          slaName: pl?.sla?.name ?? null,
          autoSendAt: pl?.autoSendAt ? new Date(pl.autoSendAt).toISOString() : null,

          uploaderEmail,
          uploadedAt,
          filename,
          mimeType,
          fileSizeBytes,

          qcStatus: creative?.qcStatus ?? null,
          qcFailureReasons: creative?.qcFailureReasons ?? [],

          approvalStatus: req?.status ?? null,
          lastApprovalAt: req?.completedAt ? new Date(req.completedAt).toISOString() : null,
          presetKey,
          presetLabel,
          presetStatus,
          approvalStep1Label: s1?.label ?? null,
          approvalStep1Status: s1?.status ?? null,
          approvalStep1DecidedBy: s1?.decidedByUser?.email ?? null,
          approvalStep2Label: s2?.label ?? null,
          approvalStep2Status: s2?.status ?? null,
          approvalStep2DecidedBy: s2?.decidedByUser?.email ?? null,
        };
      })
    );

    return {
      activePlan: { id: active.id, version: active.version },
      unsentLines: rows.length,
      rows,
    };
  }
}
