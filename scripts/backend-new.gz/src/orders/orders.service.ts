import { BadRequestException, Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../common/prisma/prisma.service";
import { ServiceBusService } from "../common/queue/service-bus.service";
import { AuthUser } from "../common/auth/current-user.decorator";
import { NotificationsService } from "../modules/notifications/notifications.service";
import { DeliveryOrderStatus, DeliveryTaskStatus, PlanLineStatus } from "@prisma/client";
import { ensureCreativePresetJob, resolveChannelDefaultPreset } from "../common/presets/channel-default-preset";
import {
  getDeliveryQueueForRoute,
  getDeliveryRouteConflictMessage,
  resolveDeliveryRoutingFromProfiles,
  withDeliveryRoutingTranscript,
} from "../common/queue/delivery-routing";

function resolveDeliveryProfiles(channel: any) {
  const cfg = channel?.destination?.config && typeof channel.destination.config === "object" ? channel.destination.config : {};
  const defaults = cfg.deliveryProfileDefaults && typeof cfg.deliveryProfileDefaults === "object" ? cfg.deliveryProfileDefaults : {};

  return {
    mainDeliveryProfileId:
      channel?.mainDeliveryProfileId ?? defaults.mainProfileId ?? defaults.defaultProfileId ?? cfg.mainDeliveryProfileId ?? cfg.defaultDeliveryProfileId ?? null,
    backupDeliveryProfileId:
      channel?.backupDeliveryProfileId ?? defaults.backupProfileId ?? cfg.backupDeliveryProfileId ?? null,
  };
}

@Injectable()
export class OrdersService {
  constructor(
    private prisma: PrismaService,
    private readonly bus: ServiceBusService,
    private readonly notifications: NotificationsService,
  ) {}

  async createOrderForProject(projectId: string, user: AuthUser) {
    const project = await this.prisma.project.findFirst({
      where: { id: projectId, accountId: user.accountId },
      select: { id: true },
    });
    if (!project) throw new NotFoundException("Project not found");

    const latest = await this.prisma.planVersion.findFirst({
      where: { accountId: user.accountId, projectId },
      orderBy: [{ version: "desc" }],
      select: { id: true, version: true },
    });
    if (!latest) throw new BadRequestException("No plan version to create an order. Commit first.");

    const order = await this.prisma.deliveryOrder.create({
      data: {
        status: DeliveryOrderStatus.DRAFT,
      
        // ✅ required relations
        account: { connect: { id: user.accountId } },
        project: { connect: { id: projectId } },      // ✅ REQUIRED by your schema
        planVersion: { connect: { id: latest.id } },  // ✅ for tracking which commit/version it belongs to
      },
      select: { id: true, status: true, planVersionId: true, projectId: true },
    });

    return order;
  }


  async send(orderId: string, user: AuthUser) {
    const order = await this.prisma.deliveryOrder.findFirst({
      where: { id: orderId, accountId: user.accountId },
      select: { id: true, accountId: true, status: true, planVersionId: true, projectId: true },
    });
    if (!order) throw new NotFoundException("Order not found");
    if (order.status === DeliveryOrderStatus.SENT) throw new BadRequestException("Order already sent");

    const now = new Date();

    const result = await this.prisma.$transaction(async (tx) => {
      const lines = await tx.planLine.findMany({
        where: {
          accountId: user.accountId,
          planVersionId: order.planVersionId,
          sentAt: null,
        },
        select: {
          id: true,
          creativeId: true,
          status: true,
          creative: { select: { approvals: true, name: true } },
          channel: {
            select: {
              id: true,
              destinationId: true,
              config: true,
              mainDeliveryProfileId: true,
              backupDeliveryProfileId: true,
              destination: { select: { config: true } },
            },
          },
        },
      });

      if (lines.length === 0) throw new BadRequestException("No unsent plan lines.");

      const project = await tx.project.findFirst({
        where: { id: order.projectId, accountId: user.accountId },
        select: { approvalsEnabled: true, approvalsPhase: true },
      });
      if (project?.approvalsEnabled && project?.approvalsPhase !== "POST") {
        const waiting = lines.filter((line: any) => line?.creative?.approvals !== "APPROVED");
        if (waiting.length) {
          throw new BadRequestException(`Waiting for approvals: ${waiting.map((line: any) => line?.creative?.name || line.creativeId).join(", ")}.`);
        }
      }

      // prevent duplicates without relying on unique constraint (safe)
      const existing = await tx.deliveryTask.findMany({
        where: { accountId: user.accountId, orderId: order.id, planLineId: { in: lines.map((l) => l.id) } },
        select: { planLineId: true },
      });
      const existingSet = new Set(existing.map((e) => e.planLineId));

      const pendingLines = lines.filter((line) => !existingSet.has(line.id));
      const resolvedByPlanLineId = new Map<string, ReturnType<typeof resolveDeliveryProfiles>>(
        pendingLines.map((line) => [line.id, resolveDeliveryProfiles(line.channel)]),
      );
      const deliveryProfileIds = Array.from(
        new Set(
          pendingLines.flatMap((line) => {
            const resolved = resolvedByPlanLineId.get(line.id);
            return [resolved?.mainDeliveryProfileId, resolved?.backupDeliveryProfileId].filter(Boolean);
          }),
        ),
      ) as string[];
      const deliveryProfiles = deliveryProfileIds.length
        ? await tx.deliveryProfile.findMany({
            where: { accountId: user.accountId, id: { in: deliveryProfileIds } },
            select: { id: true, config: true },
          } as any)
        : [];
      const deliveryProfileById = new Map<string, any>(deliveryProfiles.map((profile: any) => [profile.id, profile]));

      const createdTasks: Array<{ taskId: string; route: string }> = [];
      const presetRequests: Array<{ creativeId: string; destinationId: string | null; presetKey: string; requestedByUserId: string | null }> = [];

      for (const l of pendingLines) {
        const resolved = resolvedByPlanLineId.get(l.id)!;
        const routing = resolveDeliveryRoutingFromProfiles(
          resolved.mainDeliveryProfileId ? deliveryProfileById.get(resolved.mainDeliveryProfileId) ?? null : null,
          resolved.backupDeliveryProfileId ? deliveryProfileById.get(resolved.backupDeliveryProfileId) ?? null : null,
        );
        if (routing.routeConflict) {
          throw new BadRequestException(
            `${getDeliveryRouteConflictMessage(routing.mainRoute, routing.backupRoute)} Channel=${l.channel?.id ?? "unknown"}.`,
          );
        }

        const selectedPreset = await resolveChannelDefaultPreset(this.prisma, user.accountId, l.channel);
        const transcript = withDeliveryRoutingTranscript(
          selectedPreset
            ? {
                mode: "CHANNEL_DEFAULT_PRESET",
                selectedPreset: {
                  key: selectedPreset.key,
                  label: selectedPreset.label ?? selectedPreset.key,
                  ext: selectedPreset.ext ?? null,
                  mimeType: selectedPreset.mimeType ?? null,
                  destinationId: selectedPreset.destinationId ?? null,
                },
                requestedByUserId: (user as any).userId ?? (user as any).id ?? null,
              }
            : null,
          routing,
        );

        const created = await tx.deliveryTask.create({
          data: {
            accountId: user.accountId,
            orderId: order.id,
            planLineId: l.id,
            status: DeliveryTaskStatus.QUEUED,
            mainDeliveryProfileId: resolved.mainDeliveryProfileId,
            backupDeliveryProfileId: resolved.backupDeliveryProfileId,
            ...(selectedPreset ? { maxAttempts: 3 } : {}),
            transcript: transcript as any,
          } as any,
          select: { id: true },
        });
        if (selectedPreset) {
          presetRequests.push({
            creativeId: l.creativeId,
            destinationId: selectedPreset.destinationId ?? null,
            presetKey: selectedPreset.key,
            requestedByUserId: (user as any).userId ?? (user as any).id ?? null,
          });
        }
        createdTasks.push({ taskId: created.id, route: routing.preferredRoute });
      }

      await tx.planLine.updateMany({
        where: { id: { in: lines.map((l) => l.id) }, accountId: user.accountId },
        data: { sentAt: now, status: PlanLineStatus.SENT },
      });

      const updatedOrder = await tx.deliveryOrder.update({
        where: { id: order.id },
        data: { status: DeliveryOrderStatus.SENT },
        select: { id: true, status: true },
      });

      return { updatedOrder, createdTasks, presetRequests };
    });

    for (const req of result.presetRequests || []) {
      await ensureCreativePresetJob(this.prisma, this.bus, {
        accountId: user.accountId,
        creativeId: req.creativeId,
        destinationId: req.destinationId,
        presetKey: req.presetKey,
        userId: req.requestedByUserId,
      }).catch(() => undefined);
    }

    // Wake up delivery worker (scale-to-zero). No-op if Service Bus not configured.
    for (const item of result.createdTasks || []) {
      await this.bus
        .sendJson(getDeliveryQueueForRoute(item.route), { taskId: item.taskId }, { messageId: item.taskId })
        .catch(() => undefined);
      await this.notifications.emitType11FileSent(user.accountId, item.taskId).catch(() => undefined);
    }

    return result.updatedOrder;
  }
}
