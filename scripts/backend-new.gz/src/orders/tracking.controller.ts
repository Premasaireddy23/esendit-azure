import { Controller, Get, Param, Query, UseGuards } from "@nestjs/common";
import { JwtAuthGuard } from "../common/auth/jwt-auth.guard";
import { PermissionsGuard } from "../common/auth/permissions.guard";
import { RequireAnyPermissions } from "../common/auth/require-any-permissions.decorator";
import { CurrentUser } from "../common/auth/current-user.decorator";
import { TrackingService } from "./tracking.service";

@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller("projects/:projectId/tracking")
export class TrackingController {
  constructor(private readonly svc: TrackingService) {}

  @Get()
  @RequireAnyPermissions("PROJECT_READ", "page:projects", "action:projects:scoped:read", "action:tracking:read:scoped")
  async getProjectTracking(@CurrentUser() user: any, @Param("projectId") projectId: string) {
    return this.svc.getProjectTracking(user, projectId);
  }

  @Get(":taskId")
  @RequireAnyPermissions("PROJECT_READ", "page:projects", "action:projects:scoped:read", "action:tracking:read:scoped")
  async getTrackingTaskDetails(
    @CurrentUser() user: any,
    @Param("projectId") projectId: string,
    @Param("taskId") taskId: string,
    @Query("includeDeliveredMedia") includeDeliveredMedia?: string,
  ) {
    const includeMedia = ["1", "true", "yes", "y"].includes(String(includeDeliveredMedia || "").trim().toLowerCase());
    return this.svc.getTrackingTaskDetails(user, projectId, taskId, { includeDeliveredMedia: includeMedia });
  }
}
