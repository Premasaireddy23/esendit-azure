import { ForbiddenException, Inject, Injectable, NotFoundException } from "@nestjs/common";
import * as fs from "node:fs";
import * as fsp from "node:fs/promises";
import * as os from "node:os";
import * as path from "node:path";
import { execFile } from "node:child_process";
import { SignedStreamService } from "../common/stream/signed-stream.service";
import { PrismaService } from "../common/prisma/prisma.service";
import { STORAGE } from "../common/storage/storage.token";
import type { StorageService } from "../common/storage/storage.types";
import { buildNormalizedMediaMetadata } from "../modules/creatives/media/media-metadata.util";
import { ProjectAccessService } from "../common/project-access/project-access.service";

export type TrackingRow = {
  taskId: string;
  orderId: string;

  projectId: string;
  planLineId: string;

  creativeId: string;
  creativeName: string;

  destinationId: string | null;
  destinationName: string;
  receiverAccountId?: string | null;
  receiverAccountName?: string | null;
  receiverCategory?: string | null;

  channelId: string;
  channelName: string;

  slaId: string | null;
  slaName: string | null;

  status: string;

  attempts: number;
  maxAttempts: number;

  forceBackup: boolean;
  failoverUsed: boolean;

  runAfter: string | null;
  startedAt: string | null;
  endedAt: string | null;

  remotePath: string | null;
  bytesSent: string | null;

  lastError: string | null;

  createdAt: string;
  updatedAt: string;

  // ---- Enriched fields for Delivery Viewer (Tracking) ----
  projectNumber?: string;
  projectName?: string;

  advertiserGroup?: string | null;
  advertiser?: string | null;
  brand?: string | null;
  productCategory?: string | null;

  mediaAgency?: string | null;
  mediaAgencyTeam?: string | null;
  creativeAgency?: string | null;
  creativeAgencyTeam?: string | null;
  productionHouse?: string | null;
  productionHouseTeam?: string | null;
  postHouse?: string | null;
  postHouseTeam?: string | null;
  audioAgency?: string | null;
  audioAgencyTeam?: string | null;

  billableParty?: string | null;

  uploaderEmail?: string | null;
  uploadedAt?: string | null;

  caption?: string | null;
  duration?: string | null;
  languages?: string[];
  format?: string | null;
  audio?: string | null;
  filename?: string | null;
  mimeType?: string | null;
  fileSizeBytes?: string | null;
  sourceAssetType?: string | null;
  sourceAssetFilename?: string | null;

  qcStatus?: string | null;
  qcFailureReasons?: string[];

  approvalStatus?: string | null;
  approvalStep1Label?: string | null;
  approvalStep1Status?: string | null;
  approvalStep1DecidedBy?: string | null;
  approvalStep2Label?: string | null;
  approvalStep2Status?: string | null;
  approvalStep2DecidedBy?: string | null;

  deliveryApprovalRequired?: boolean;
  deliveryApprovalStatus?: string | null;
  deliveryHouseId?: string | null;
  deliveryStagingRemotePath?: string | null;
  deliveryFinalRemotePath?: string | null;

  channelServerStatus?: string | null;
  channelServerMessage?: string | null;
};

@Injectable()
export class TrackingService {
  constructor(
    private prisma: PrismaService,
    private signed: SignedStreamService,
    @Inject(STORAGE) private storage: StorageService,
    private readonly projectAccess: ProjectAccessService,
  ) {}

  private accountIdOf(user: any) {
    return String(user?.accountId || "").trim();
  }

  private hasLegacyProjectTrackingAccess(user: any) {
    return this.projectAccess.hasAnyPerm(user, ["PROJECT_READ", "action:projects:read"]);
  }

  private hasGlobalAccountTrackingAccess(user: any) {
    return this.projectAccess.hasAnyPerm(user, ["action:tracking:read", "TRACKING_READ"]);
  }

  private async assertCanViewProjectTracking(user: any, projectId: string) {
    if (this.hasLegacyProjectTrackingAccess(user)) return;
    const access = await this.projectAccess.getProjectAccess(user, projectId);
    if (!access.canViewTracking) throw new ForbiddenException("Unauthorised");
  }

  private async canViewTrackingRow(user: any, projectId: string, receiverAccountId?: string | null) {
    if (this.hasGlobalAccountTrackingAccess(user)) return true;
    if (!projectId) return false;
    try {
      const access = await this.projectAccess.getProjectAccess(user, projectId);
      if (!access.canViewTracking) return false;
      return this.projectAccess.canViewReceiverRoute(access, receiverAccountId);
    } catch {
      return false;
    }
  }

  private normalizeAssetType(v: any): string {
    return String(v || "").trim().toUpperCase();
  }

  private toIso(v: any): string | null {
    if (!v) return null;
    try {
      return new Date(v).toISOString();
    } catch {
      return null;
    }
  }

  private safeTempExt(name?: string | null, fallback = ".bin") {
    const ext = name ? path.extname(String(name)) : "";
    return ext || fallback;
  }

  private async execResult(cmd: string, args: string[]) {
    return await new Promise<{ stdout: string; stderr: string; code: number | null }>((resolve, reject) => {
      execFile(cmd, args, { maxBuffer: 12 * 1024 * 1024 }, (error: any, stdout = "", stderr = "") => {
        if (error && error.code === "ENOENT") {
          reject(new Error(`${cmd} is not installed on the backend server`));
          return;
        }
        resolve({ stdout: String(stdout || ""), stderr: String(stderr || ""), code: typeof error?.code === "number" ? error.code : null });
      });
    });
  }

  private pickDetailsAsset(task: any) {
    const transcriptDelivered = task?.transcript?.deliveredAsset ?? null;
    const sourceAsset = task?.sourceAsset ?? null;
    const assets = Array.isArray(task?.planLine?.creative?.assets) ? task.planLine.creative.assets : [];
    const uploaded = assets.filter((a: any) => String(a?.uploadStatus || "").toUpperCase() === "UPLOADED");

    const transcriptPresetOutput =
      transcriptDelivered &&
      (!!transcriptDelivered?.presetJobId || String(transcriptDelivered?.kind || "").trim().toUpperCase() === "PRESET_OUTPUT")
        ? transcriptDelivered
        : null;

    const transcriptCreativeAsset = transcriptDelivered?.sourceAssetId
      ? uploaded.find((a: any) => String(a?.id || "") === String(transcriptDelivered.sourceAssetId)) ?? null
      : null;

    const sameAsSourceAsset = sourceAsset?.id
      ? uploaded.find((a: any) => String(a?.id || "") === String(sourceAsset.id)) ?? null
      : null;

    return (
      (transcriptPresetOutput?.path ? transcriptPresetOutput : null) ??
      (transcriptCreativeAsset?.path ? transcriptCreativeAsset : null) ??
      (transcriptDelivered?.path ? transcriptDelivered : null) ??
      (sameAsSourceAsset?.path ? sameAsSourceAsset : null) ??
      (sourceAsset?.path ? sourceAsset : null) ??
      uploaded.find((a: any) => this.normalizeAssetType(a?.type) === "OUTPUT" && a?.path) ??
      uploaded.find((a: any) => this.normalizeAssetType(a?.type) === "PROXY" && a?.path) ??
      uploaded.find((a: any) => this.normalizeAssetType(a?.type) === "SOURCE" && a?.path) ??
      uploaded.find((a: any) => !!a?.path) ??
      transcriptPresetOutput ??
      transcriptCreativeAsset ??
      transcriptDelivered ??
      sameAsSourceAsset ??
      sourceAsset ??
      uploaded[0] ??
      null
    );
  }

  private simplifyRate(v: any): string | null {
    const raw = String(v || "").trim();
    if (!raw) return null;
    if (!raw.includes("/")) return raw;
    const [a, b] = raw.split("/");
    const num = Number(a);
    const den = Number(b);
    if (!Number.isFinite(num) || !Number.isFinite(den) || den === 0) return raw;
    const rate = num / den;
    return Number.isFinite(rate)
      ? rate.toFixed(rate >= 100 ? 0 : rate >= 10 ? 2 : 3).replace(/\.0+$/, "").replace(/(\.\d*?)0+$/, "$1")
      : raw;
  }


  private mediaInfoTrack(mediaInfo: any, type: string) {
    const tracks = mediaInfo?.media?.track;
    if (!Array.isArray(tracks)) return null;
    const want = String(type || "").toLowerCase();
    return tracks.find((t: any) => String(t?.["@type"] || t?.["@Type"] || t?.type || "").toLowerCase() === want) ?? null;
  }

  private mediaInfoValue(track: any, ...keys: string[]) {
    if (!track) return null;
    for (const key of keys) {
      if (track[key] !== undefined && track[key] !== null) return track[key];
    }
    return null;
  }

  private mediaInfoString(track: any, ...keys: string[]): string | null {
    const value = this.mediaInfoValue(track, ...keys);
    if (value === undefined || value === null) return null;
    const s = String(value).trim();
    return s || null;
  }


  private async buildReceiverAccountMap(accountId: string, tasks: any[]) {
    const receiverIds = Array.from(
      new Set(
        (tasks || [])
          .map((task: any) => String((task?.planLine?.channel?.destination?.config as any)?.receiverAccountId || "").trim())
          .filter(Boolean),
      ),
    );

    if (!receiverIds.length) return new Map<string, any>();

    const rows = await this.prisma.partnerAccount.findMany({
      where: { accountId, id: { in: receiverIds } },
      select: { id: true, name: true, receiverCategory: true },
    });
    return new Map((rows || []).map((row: any) => [String(row.id), row]));
  }

  private mediaInfoNumberRaw(value: any): number | null {
    if (value === undefined || value === null) return null;
    if (typeof value === "number") return Number.isFinite(value) ? value : null;

    const raw = String(value).trim();
    if (!raw) return null;
    const compact = raw.replace(/,/g, "").replace(/\s+/g, "");

    const khz = compact.match(/^([-0-9.]+)kHz$/i);
    if (khz) {
      const n = Number(khz[1]);
      return Number.isFinite(n) ? n * 1000 : null;
    }

    const hz = compact.match(/^([-0-9.]+)Hz$/i);
    if (hz) {
      const n = Number(hz[1]);
      return Number.isFinite(n) ? n : null;
    }

    const mbps = compact.match(/^([-0-9.]+)Mbps$/i);
    if (mbps) {
      const n = Number(mbps[1]);
      return Number.isFinite(n) ? n * 1000000 : null;
    }

    const kbps = compact.match(/^([-0-9.]+)kbps$/i);
    if (kbps) {
      const n = Number(kbps[1]);
      return Number.isFinite(n) ? n * 1000 : null;
    }

    const bps = compact.match(/^([-0-9.]+)bps$/i);
    if (bps) {
      const n = Number(bps[1]);
      return Number.isFinite(n) ? n : null;
    }

    const n = Number(compact);
    return Number.isFinite(n) ? n : null;
  }

  private mediaInfoNumber(track: any, ...keys: string[]): number | null {
    return this.mediaInfoNumberRaw(this.mediaInfoValue(track, ...keys));
  }

  private mediaInfoDurationSeconds(track: any): number | null {
    const ms = this.mediaInfoNumber(track, "Duration");
    if (ms != null) return ms > 1000 ? ms / 1000 : ms;

    const display =
      this.mediaInfoString(
        track,
        "Duration/String3",
        "Duration_String3",
        "Duration/String2",
        "Duration_String2",
        "Duration/String1",
        "Duration_String1",
        "Duration/String",
        "Duration_String",
      ) || null;

    if (!display) return null;

    const hhmmss = display.match(/(\d{1,2}):(\d{2}):(\d{2})(?:[\.:](\d{1,3}))?/);
    if (hhmmss) {
      const hh = Number(hhmmss[1] || 0);
      const mm = Number(hhmmss[2] || 0);
      const ss = Number(hhmmss[3] || 0);
      const frac = Number(hhmmss[4] || 0);
      return (Number.isFinite(hh) ? hh : 0) * 3600 + (Number.isFinite(mm) ? mm : 0) * 60 + (Number.isFinite(ss) ? ss : 0) + (Number.isFinite(frac) ? frac / 1000 : 0);
    }

    const n = Number(display.replace(/[^\d.-]+/g, ""));
    return Number.isFinite(n) ? n : null;
  }

  private mediaInfoAspectRatio(value: any): string | null {
    if (value === undefined || value === null) return null;
    const raw = String(value).trim();
    if (!raw) return null;
    const compact = raw.replace(/\s+/g, "");
    if (compact.includes(":")) return compact;
    const n = Number(compact);
    if (Number.isFinite(n)) {
      if (Math.abs(n - 4 / 3) < 0.02) return "4:3";
      if (Math.abs(n - 16 / 9) < 0.02) return "16:9";
    }
    return compact;
  }

  private buildDeliveredAssetInfo(asset: any) {
    if (!asset) return null;
    return {
      id: asset.id,
      type: asset.type ?? null,
      filename: asset.filename ?? null,
      mimeType: asset.mimeType ?? null,
      sizeBytes: asset.sizeBytes != null ? String(asset.sizeBytes) : null,
      uploadEndedAt: this.toIso(asset.uploadEndedAt),
    };
  }

  private async inspectDeliveredAsset(asset: any) {
    if (!asset) return { deliveredAsset: null, deliveredMedia: null };

    const deliveredAsset = this.buildDeliveredAssetInfo(asset);

    const rawPath = asset?.path ? String(asset.path).replace(/^file:\/\//, "") : "";
    if (!rawPath) {
      return {
        deliveredAsset,
        deliveredMedia: {
          file: deliveredAsset,
          error: "No stored delivered asset path was found for this task.",
        },
      };
    }

    const ext = this.safeTempExt(asset?.filename || rawPath, ".bin");
    const useExistingLocal = path.isAbsolute(rawPath) && fs.existsSync(rawPath);
    const localPath = useExistingLocal ? rawPath : path.join(os.tmpdir(), `tracking-details-${asset.id || Date.now()}-${Math.random().toString(36).slice(2)}${ext}`);
    const cleanupPath = useExistingLocal ? null : localPath;

    try {
      if (!useExistingLocal) {
        await this.storage.downloadToFile(rawPath, localPath);
      }

      let mediaInfoJson: any = null;
      let rawMediaInfoText: string | null = null;
      try {
        const mediaInfo = await this.execResult("mediainfo", ["--Output=JSON", localPath]);
        mediaInfoJson = JSON.parse(mediaInfo.stdout || "{}");
      } catch {
        mediaInfoJson = null;
      }
      try {
        const mediaInfoText = await this.execResult("mediainfo", [localPath]);
        rawMediaInfoText = (mediaInfoText.stdout || mediaInfoText.stderr || "").trim() || null;
      } catch {
        rawMediaInfoText = null;
      }

      let probeJson: any = null;
      try {
        const ffprobe = await this.execResult("ffprobe", ["-v", "quiet", "-print_format", "json", "-show_format", "-show_streams", localPath]);
        probeJson = JSON.parse(ffprobe.stdout || "{}");
      } catch {
        probeJson = null;
      }

      const ffmpegInfo = await this.execResult("ffmpeg", ["-hide_banner", "-i", localPath]).catch(() => ({ stdout: "", stderr: "", code: null as number | null }));

      const metadata = buildNormalizedMediaMetadata(mediaInfoJson, probeJson, {
        filename: deliveredAsset.filename,
        sizeBytes: deliveredAsset.sizeBytes,
        mimeType: deliveredAsset.mimeType,
      });

      if (!mediaInfoJson && !probeJson) {
        return {
          deliveredAsset,
          deliveredMedia: {
            file: deliveredAsset,
            error: "Neither MediaInfo nor ffprobe returned readable media details for this asset.",
          },
        };
      }

      return {
        deliveredAsset,
        deliveredMedia: {
          file: deliveredAsset,
          format: metadata?.format || null,
          videoStreams: metadata?.videoStreams || [],
          audioStreams: metadata?.audioStreams || [],
          otherStreams: metadata?.otherStreams || [],
          metadata,
          mediaInfoJson: mediaInfoJson || null,
          rawMediaInfoText,
          rawFfmpegText: (ffmpegInfo.stderr || ffmpegInfo.stdout || "").trim() || null,
          toolUsed: metadata?.toolUsed || (mediaInfoJson ? "mediainfo+ffprobe" : "ffprobe"),
        },
      };
    } catch (e: any) {
      return {
        deliveredAsset,
        deliveredMedia: {
          file: deliveredAsset,
          error: e?.message ? String(e.message) : String(e),
        },
      };
    } finally {
      if (cleanupPath) {
        await fsp.unlink(cleanupPath).catch(() => undefined);
      }
    }
  }


  /**
   * Detailed view for a single delivery task (used by the Tracking UI “View details” modal).
   * Kept intentionally broad: transcript/receipt are JSON and may evolve.
   */
  async getTrackingTaskDetails(user: any, projectId: string, taskId: string, options?: { includeDeliveredMedia?: boolean }) {
    const accountId = this.accountIdOf(user);
    await this.assertCanViewProjectTracking(user, projectId);
    const task = await this.prisma.deliveryTask.findFirst({
      where: {
        id: taskId,
        accountId,
        order: { projectId },
      },
      include: {
        order: { select: { id: true, status: true, createdAt: true, updatedAt: true } },
        planLine: {
          select: {
            id: true,
            createdAt: true,
            updatedAt: true,
            channel: {
              select: {
                id: true,
                name: true,
                serverStatus: true,
                serverMessage: true,
                destination: { select: { id: true, name: true, category: true, config: true } },
              },
            },
            sla: { select: { id: true, name: true } },
            creative: {
              select: {
                id: true,
                name: true,
                valid: true,
                caption: true,
                duration: true,
                assets: {
                  select: {
                    id: true,
                    type: true,
                    filename: true,
                    mimeType: true,
                    path: true,
                    sizeBytes: true,
                    uploadEndedAt: true,
                    uploadStatus: true,
                  },
                  orderBy: { createdAt: "desc" },
                },
              },
            },
          },
        },
        mainDeliveryProfile: { select: { id: true, name: true, protocol: true, finalPath: true, stagingPath: true } },
        backupDeliveryProfile: { select: { id: true, name: true, protocol: true, finalPath: true, stagingPath: true } },
        sourceAsset: { select: { id: true, type: true, filename: true, mimeType: true, path: true, sizeBytes: true, uploadEndedAt: true } },
      },
    });

    if (!task) {
      return { notFound: true };
    }

    if (!this.hasLegacyProjectTrackingAccess(user) && !this.hasGlobalAccountTrackingAccess(user)) {
      const access = await this.projectAccess.getProjectAccess(user, projectId);
      const receiverAccountId = String((task as any)?.planLine?.channel?.destination?.config?.receiverAccountId || "").trim() || null;
      if (!this.projectAccess.canViewReceiverRoute(access, receiverAccountId)) {
        throw new ForbiddenException("Unauthorised");
      }
    }

    const rawReceipt: any = (task as any).receipt ?? null;
    let receipt = rawReceipt;
    try {
      const xml = rawReceipt?.xml ?? null;
      const auditKey = xml?.auditKey || rawReceipt?.xmlAuditKey || rawReceipt?.xmlAuditKey;
      const fileName = xml?.fileName || rawReceipt?.xmlFileName || "metadata.xml";
      if (auditKey) {
        const viewUrl = this.signed.makeUrl({
          path: String(auditKey),
          mimeType: "application/xml",
          filename: String(fileName || "metadata.xml"),
          disposition: "inline",
          ttlSeconds: 900,
        });
        const downloadUrl = this.signed.makeUrl({
          path: String(auditKey),
          mimeType: "application/xml",
          filename: String(fileName || "metadata.xml"),
          disposition: "attachment",
          ttlSeconds: 900,
        });
        receipt = {
          ...(rawReceipt || {}),
          xmlViewUrl: viewUrl,
          xmlDownloadUrl: downloadUrl,
          xml: { ...(xml || {}), auditKey, fileName, viewUrl, downloadUrl },
        };
      }
    } catch {
      // ignore enrichment errors; receipt stays raw
    }

    const includeDeliveredMedia = !!options?.includeDeliveredMedia;
    const deliveryAsset = this.pickDetailsAsset(task as any);
    const deliveredAsset = this.buildDeliveredAssetInfo(deliveryAsset);
    const deliveryMedia = includeDeliveredMedia
      ? await this.inspectDeliveredAsset(deliveryAsset)
      : { deliveredAsset, deliveredMedia: null };

    return {
      task: {
        id: task.id,
        status: task.status,
        attempts: task.attempts ?? 0,
        maxAttempts: task.maxAttempts ?? 3,
        runAfter: task.runAfter ? task.runAfter.toISOString() : null,
        startedAt: task.startedAt ? task.startedAt.toISOString() : null,
        endedAt: task.endedAt ? task.endedAt.toISOString() : null,
        createdAt: task.createdAt.toISOString(),
        updatedAt: task.updatedAt.toISOString(),
        lastError: task.lastError ?? null,
        remotePath: task.remotePath ?? null,
        bytesSent: task.bytesSent != null ? String(task.bytesSent) : null,
        forceBackup: !!task.forceBackup,
        failoverUsed: !!task.failoverUsed,
        usedDeliveryProfileId: task.usedDeliveryProfileId ?? null,
        sourceAsset: (task as any)?.sourceAsset
          ? {
              id: (task as any).sourceAsset.id,
              type: (task as any).sourceAsset.type,
              filename: (task as any).sourceAsset.filename ?? null,
              mimeType: (task as any).sourceAsset.mimeType ?? null,
              path: (task as any).sourceAsset.path ?? null,
              sizeBytes: (task as any).sourceAsset.sizeBytes != null ? String((task as any).sourceAsset.sizeBytes) : null,
              uploadEndedAt: this.toIso((task as any).sourceAsset.uploadEndedAt),
            }
          : null,
        transcript: (task as any).transcript ?? null,
        receipt: receipt ?? null,
      },
      order: task.order,
      planLine: task.planLine,
      profiles: {
        main: task.mainDeliveryProfile,
        backup: task.backupDeliveryProfile,
      },
      deliveredAsset: deliveryMedia.deliveredAsset,
      deliveredMedia: deliveryMedia.deliveredMedia,
    };
  }

  async getAccountTracking(user: any, take = 500, skip = 0): Promise<{ rows: TrackingRow[] }> {
    const accountId = this.accountIdOf(user);
    const safeTake = Math.min(1000, Math.max(1, take || 500));
    const safeSkip = Math.max(0, skip || 0);

    const tasks = await this.prisma.deliveryTask.findMany({
      where: { accountId },
      take: safeTake,
      skip: safeSkip,
      orderBy: [{ createdAt: "desc" }],
      include: {
        order: {
          select: {
            id: true,
            status: true,
            createdAt: true,
            project: {
              select: {
                id: true,
                projectNumber: true,
                name: true,
                approvalsEnabled: true,

                advertiserGroup: { select: { name: true } },
                advertiser: { select: { name: true } },
                brand: { select: { name: true } },
                productCategory: { select: { name: true } },

                mediaAgency: { select: { name: true } },
                mediaAgencyTeam: { select: { name: true } },
                creativeAgency: { select: { name: true } },
                creativeAgencyTeam: { select: { name: true } },
                productionHouse: { select: { name: true } },
                productionHouseTeam: { select: { name: true } },
                postHouse: { select: { name: true } },
                postHouseTeam: { select: { name: true } },
                audioAgency: { select: { name: true } },
                audioAgencyTeam: { select: { name: true } },

                billableParty: { select: { name: true } },
              },
            },
          },
        },
        planLine: {
          select: {
            id: true,
            creativeId: true,
            channelId: true,
            slaId: true,
            creative: {
              select: {
                id: true,
                name: true,
                valid: true,
                caption: true,
                duration: true,
                languages: true,
                format: true,
                audio: true,

                qcStatus: true,
                qcFailureReasons: true,

                approvalRequest: {
                  select: {
                    id: true,
                    status: true,
                    steps: {
                      select: {
                        order: true,
                        label: true,
                        status: true,
                        decidedByUser: { select: { email: true } },
                      },
                      orderBy: { order: "asc" },
                    },
                  },
                },

                assets: {
                  select: {
                    id: true,
                    type: true,
                    uploadStatus: true,
                    filename: true,
                    mimeType: true,
                    sizeBytes: true,
                    uploadEndedAt: true,
                    uploadedByUser: { select: { email: true } },
                  },
                  orderBy: { createdAt: "desc" },
                },
              },
            },
            channel: {
              select: {
                id: true,
                name: true,
                destinationId: true,
                destination: { select: { id: true, name: true, category: true, config: true } },
                serverStatus: true,
                serverMessage: true,
              },
            },
            sla: { select: { id: true, name: true } },
          },
        },
        sourceAsset: {
          select: {
            id: true,
            type: true,
            filename: true,
            mimeType: true,
            sizeBytes: true,
            uploadEndedAt: true,
            uploadedByUser: { select: { email: true } },
          },
        },
      },
    });

    const receiverById = await this.buildReceiverAccountMap(accountId, tasks as any[]);

    const rows: TrackingRow[] = tasks.map((t) => {
      const tt = t as any;
      const pl = t.planLine as any;

      const creative = pl?.creative;
      const channel = pl?.channel;

      const destinationId = channel?.destinationId ?? channel?.destination?.id ?? null;
      const destinationName = channel?.destination?.name ?? "";
      const receiverAccountId = String((channel?.destination?.config as any)?.receiverAccountId || "").trim() || null;
      const receiver = receiverAccountId ? receiverById.get(receiverAccountId) : null;
      const receiverAccountName = receiver?.name ?? null;
      const receiverCategory = receiver?.receiverCategory ?? channel?.destination?.category ?? null;

      const creativeName =
        (creative?.valid && typeof creative.valid === "string" ? creative.valid : null) ??
        creative?.name ??
        "";

      // Prefer the exact asset used by delivery once known; fall back to the previous best-asset heuristic
      // for older / in-flight tasks that do not have sourceAssetId set yet.
      const assets: any[] = Array.isArray(creative?.assets) ? creative.assets : [];
      const transcriptDelivered = (t as any)?.transcript?.deliveredAsset ?? null;
      const sourceAsset = (t as any)?.sourceAsset ?? null;
      const transcriptAssetById = transcriptDelivered?.sourceAssetId
        ? assets.find((a) => String(a?.id || "") === String(transcriptDelivered.sourceAssetId)) ?? null
        : null;
      const deliveredAsset = transcriptDelivered ?? sourceAsset ?? null;
      const best =
        transcriptAssetById ??
        sourceAsset ??
        assets.find((a) => a?.type === "OUTPUT" && a?.uploadStatus === "UPLOADED") ??
        assets.find((a) => a?.type === "SOURCE" && a?.uploadStatus === "UPLOADED") ??
        assets[0] ??
        null;

      const uploadedAt = best?.uploadEndedAt ? new Date(best.uploadEndedAt).toISOString() : null;
      const uploaderEmail = best?.uploadedByUser?.email ?? null;
      const fileSizeBytes = deliveredAsset?.sizeBytes != null
        ? String(deliveredAsset.sizeBytes)
        : deliveredAsset?.bytes != null
          ? String(deliveredAsset.bytes)
          : best?.sizeBytes != null
            ? String(best.sizeBytes)
            : null;
      const mimeType = deliveredAsset?.mimeType ?? best?.mimeType ?? null;
      const filename = deliveredAsset?.filename ?? best?.filename ?? null;
      const sourceAssetType =
        deliveredAsset?.type ??
        (deliveredAsset?.presetJobId || String(deliveredAsset?.kind || "").trim().toUpperCase() === "PRESET_OUTPUT" ? "OUTPUT" : null) ??
        deliveredAsset?.kind ??
        best?.type ??
        null;
      const sourceAssetFilename = deliveredAsset?.filename ?? best?.filename ?? null;

      const deliveryApprovalGate = (t as any)?.transcript?.approvalGate && typeof (t as any).transcript.approvalGate === "object"
        ? (t as any).transcript.approvalGate
        : null;
      const deliveryApprovalRequired = deliveryApprovalGate?.required === true;
      const deliveryApprovalStatus = deliveryApprovalGate?.status ? String(deliveryApprovalGate.status) : null;
      const deliveryHouseId = deliveryApprovalGate?.houseId ? String(deliveryApprovalGate.houseId) : null;
      const deliveryStagingRemotePath = deliveryApprovalGate?.stagedRemotePath ? String(deliveryApprovalGate.stagedRemotePath) : null;
      const deliveryFinalRemotePath = deliveryApprovalGate?.finalRemotePath ? String(deliveryApprovalGate.finalRemotePath) : null;

      // approval steps (first two)
      const req = creative?.approvalRequest ?? null;
      const steps: any[] = Array.isArray(req?.steps) ? req.steps : [];
      const s1 = steps[0] ?? null;
      const s2 = steps[1] ?? null;

      const prj = (t as any)?.order?.project ?? null;
      const projectId = prj?.id ?? (t as any)?.order?.projectId ?? "";

      return {
        taskId: t.id,
        orderId: t.orderId,

        projectId,
        planLineId: t.planLineId,

        creativeId: pl?.creativeId ?? "",
        creativeName,

        destinationId,
        destinationName,
        receiverAccountId,
        receiverAccountName,
        receiverCategory,

        channelId: pl?.channelId ?? "",
        channelName: channel?.name ?? "",

        slaId: pl?.slaId ?? null,
        slaName: pl?.sla?.name ?? null,

        status: t.status,

        attempts: typeof tt.attempts === "number" ? tt.attempts : 0,
        maxAttempts: typeof tt.maxAttempts === "number" ? tt.maxAttempts : 3,

        forceBackup: !!tt.forceBackup,
        failoverUsed: !!tt.failoverUsed,

        runAfter: tt.runAfter ? new Date(tt.runAfter).toISOString() : null,
        startedAt: tt.startedAt ? new Date(tt.startedAt).toISOString() : null,
        endedAt: tt.endedAt ? new Date(tt.endedAt).toISOString() : null,

        remotePath: tt.remotePath ?? null,
        bytesSent: tt.bytesSent != null ? String(tt.bytesSent) : null,

        lastError: tt.lastError ?? null,

        createdAt: t.createdAt.toISOString(),
        updatedAt: t.updatedAt.toISOString(),

        projectNumber: prj?.projectNumber ?? undefined,
        projectName: prj?.name ?? undefined,

        advertiserGroup: prj?.advertiserGroup?.name ?? null,
        advertiser: prj?.advertiser?.name ?? null,
        brand: prj?.brand?.name ?? null,
        productCategory: prj?.productCategory?.name ?? null,

        mediaAgency: prj?.mediaAgency?.name ?? null,
        mediaAgencyTeam: prj?.mediaAgencyTeam?.name ?? null,
        creativeAgency: prj?.creativeAgency?.name ?? null,
        creativeAgencyTeam: prj?.creativeAgencyTeam?.name ?? null,
        productionHouse: prj?.productionHouse?.name ?? null,
        productionHouseTeam: prj?.productionHouseTeam?.name ?? null,
        postHouse: prj?.postHouse?.name ?? null,
        postHouseTeam: prj?.postHouseTeam?.name ?? null,
        audioAgency: prj?.audioAgency?.name ?? null,
        audioAgencyTeam: prj?.audioAgencyTeam?.name ?? null,

        billableParty: prj?.billableParty?.name ?? null,

        uploaderEmail,
        uploadedAt,

        caption: creative?.caption ?? null,
        duration: creative?.duration ?? null,
        languages: Array.isArray(creative?.languages) ? creative.languages : [],
        format: creative?.format ?? null,
        audio: creative?.audio ?? null,
        filename,
        mimeType,
        fileSizeBytes,
        sourceAssetType,
        sourceAssetFilename,

        qcStatus: creative?.qcStatus ?? null,
        qcFailureReasons: Array.isArray(creative?.qcFailureReasons) ? creative.qcFailureReasons : [],

        approvalStatus: req?.status ?? null,
        approvalStep1Label: s1?.label ?? null,
        approvalStep1Status: s1?.status ?? null,
        approvalStep1DecidedBy: s1?.decidedByUser?.email ?? null,
        approvalStep2Label: s2?.label ?? null,
        approvalStep2Status: s2?.status ?? null,
        approvalStep2DecidedBy: s2?.decidedByUser?.email ?? null,

        deliveryApprovalRequired,
        deliveryApprovalStatus,
        deliveryHouseId,
        deliveryStagingRemotePath,
        deliveryFinalRemotePath,

        channelServerStatus: channel?.serverStatus ?? null,
        channelServerMessage: channel?.serverMessage ?? null,
      };
    });

    if (this.hasGlobalAccountTrackingAccess(user)) return { rows };

    const filteredRows: TrackingRow[] = [];
    for (const row of rows) {
      if (await this.canViewTrackingRow(user, row.projectId, row.receiverAccountId)) filteredRows.push(row);
    }
    return { rows: filteredRows };
  }

  async getProjectTracking(user: any, projectId: string): Promise<{ rows: TrackingRow[] }> {
    const accountId = this.accountIdOf(user);
    await this.assertCanViewProjectTracking(user, projectId);
    const project = await this.prisma.project.findFirst({
      where: { id: projectId, accountId },
      select: { id: true },
    });
    if (!project) throw new NotFoundException("Project not found");

    const tasks = await this.prisma.deliveryTask.findMany({
      where: {
        accountId,
        order: { projectId },
      },
      orderBy: [{ createdAt: "desc" }],
      include: {
        order: {
          select: {
            id: true,
            status: true,
            createdAt: true,
            project: {
              select: {
                id: true,
                projectNumber: true,
                name: true,
                approvalsEnabled: true,

                advertiserGroup: { select: { name: true } },
                advertiser: { select: { name: true } },
                brand: { select: { name: true } },
                productCategory: { select: { name: true } },

                mediaAgency: { select: { name: true } },
                mediaAgencyTeam: { select: { name: true } },
                creativeAgency: { select: { name: true } },
                creativeAgencyTeam: { select: { name: true } },
                productionHouse: { select: { name: true } },
                productionHouseTeam: { select: { name: true } },
                postHouse: { select: { name: true } },
                postHouseTeam: { select: { name: true } },
                audioAgency: { select: { name: true } },
                audioAgencyTeam: { select: { name: true } },

                billableParty: { select: { name: true } },
              },
            },
          },
        },
        planLine: {
          select: {
            id: true,
            creativeId: true,
            channelId: true,
            slaId: true,
            creative: {
              select: {
                id: true,
                name: true,
                valid: true,
                caption: true,
                duration: true,
                languages: true,
                format: true,
                audio: true,

                qcStatus: true,
                qcFailureReasons: true,

                approvalRequest: {
                  select: {
                    id: true,
                    status: true,
                    steps: {
                      select: {
                        order: true,
                        label: true,
                        status: true,
                        decidedByUser: { select: { email: true } },
                      },
                      orderBy: { order: "asc" },
                    },
                  },
                },

                assets: {
                  select: {
                    id: true,
                    type: true,
                    uploadStatus: true,
                    filename: true,
                    mimeType: true,
                    sizeBytes: true,
                    uploadEndedAt: true,
                    uploadedByUser: { select: { email: true } },
                  },
                  orderBy: { createdAt: "desc" },
                },
              },
            },
            channel: {
              select: {
                id: true,
                name: true,
                destinationId: true,
                destination: { select: { id: true, name: true, category: true, config: true } },
                serverStatus: true,
                serverMessage: true,
              },
            },
            sla: { select: { id: true, name: true } },
          },
        },
        sourceAsset: {
          select: {
            id: true,
            type: true,
            filename: true,
            mimeType: true,
            sizeBytes: true,
            uploadEndedAt: true,
            uploadedByUser: { select: { email: true } },
          },
        },
      },
    });

    const receiverById = await this.buildReceiverAccountMap(accountId, tasks as any[]);

    const rows: TrackingRow[] = tasks.map((t) => {
      const tt = t as any;
      const pl = t.planLine as any;

      const creative = pl?.creative;
      const channel = pl?.channel;

      const destinationId = channel?.destinationId ?? channel?.destination?.id ?? null;
      const destinationName = channel?.destination?.name ?? "";
      const receiverAccountId = String((channel?.destination?.config as any)?.receiverAccountId || "").trim() || null;
      const receiver = receiverAccountId ? receiverById.get(receiverAccountId) : null;
      const receiverAccountName = receiver?.name ?? null;
      const receiverCategory = receiver?.receiverCategory ?? channel?.destination?.category ?? null;

      const creativeName =
        (creative?.valid && typeof creative.valid === "string" ? creative.valid : null) ??
        creative?.name ??
        "";

      // Prefer the exact asset used by delivery once known; fall back to the previous best-asset heuristic
      // for older / in-flight tasks that do not have sourceAssetId set yet.
      const assets: any[] = Array.isArray(creative?.assets) ? creative.assets : [];
      const transcriptDelivered = (t as any)?.transcript?.deliveredAsset ?? null;
      const sourceAsset = (t as any)?.sourceAsset ?? null;
      const transcriptAssetById = transcriptDelivered?.sourceAssetId
        ? assets.find((a) => String(a?.id || "") === String(transcriptDelivered.sourceAssetId)) ?? null
        : null;
      const deliveredAsset = transcriptDelivered ?? sourceAsset ?? null;
      const best =
        transcriptAssetById ??
        sourceAsset ??
        assets.find((a) => a?.type === "OUTPUT" && a?.uploadStatus === "UPLOADED") ??
        assets.find((a) => a?.type === "SOURCE" && a?.uploadStatus === "UPLOADED") ??
        assets[0] ??
        null;

      const uploadedAt = best?.uploadEndedAt ? new Date(best.uploadEndedAt).toISOString() : null;
      const uploaderEmail = best?.uploadedByUser?.email ?? null;
      const fileSizeBytes = deliveredAsset?.sizeBytes != null
        ? String(deliveredAsset.sizeBytes)
        : deliveredAsset?.bytes != null
          ? String(deliveredAsset.bytes)
          : best?.sizeBytes != null
            ? String(best.sizeBytes)
            : null;
      const mimeType = deliveredAsset?.mimeType ?? best?.mimeType ?? null;
      const filename = deliveredAsset?.filename ?? best?.filename ?? null;
      const sourceAssetType =
        deliveredAsset?.type ??
        (deliveredAsset?.presetJobId || String(deliveredAsset?.kind || "").trim().toUpperCase() === "PRESET_OUTPUT" ? "OUTPUT" : null) ??
        deliveredAsset?.kind ??
        best?.type ??
        null;
      const sourceAssetFilename = deliveredAsset?.filename ?? best?.filename ?? null;

      const deliveryApprovalGate = (t as any)?.transcript?.approvalGate && typeof (t as any).transcript.approvalGate === "object"
        ? (t as any).transcript.approvalGate
        : null;
      const deliveryApprovalRequired = deliveryApprovalGate?.required === true;
      const deliveryApprovalStatus = deliveryApprovalGate?.status ? String(deliveryApprovalGate.status) : null;
      const deliveryHouseId = deliveryApprovalGate?.houseId ? String(deliveryApprovalGate.houseId) : null;
      const deliveryStagingRemotePath = deliveryApprovalGate?.stagedRemotePath ? String(deliveryApprovalGate.stagedRemotePath) : null;
      const deliveryFinalRemotePath = deliveryApprovalGate?.finalRemotePath ? String(deliveryApprovalGate.finalRemotePath) : null;

      // approval steps (first two)
      const req = creative?.approvalRequest ?? null;
      const steps: any[] = Array.isArray(req?.steps) ? req.steps : [];
      const s1 = steps[0] ?? null;
      const s2 = steps[1] ?? null;

      const prj = (t as any)?.order?.project ?? null;
      const projectId = prj?.id ?? (t as any)?.order?.projectId ?? "";

      return {
        taskId: t.id,
        orderId: t.orderId,

        projectId,
        planLineId: t.planLineId,

        creativeId: pl?.creativeId ?? "",
        creativeName,

        destinationId,
        destinationName,
        receiverAccountId,
        receiverAccountName,
        receiverCategory,

        channelId: pl?.channelId ?? "",
        channelName: channel?.name ?? "",

        slaId: pl?.slaId ?? null,
        slaName: pl?.sla?.name ?? null,

        status: t.status,

        attempts: typeof tt.attempts === "number" ? tt.attempts : 0,
        maxAttempts: typeof tt.maxAttempts === "number" ? tt.maxAttempts : 3,

        forceBackup: !!tt.forceBackup,
        failoverUsed: !!tt.failoverUsed,

        runAfter: tt.runAfter ? new Date(tt.runAfter).toISOString() : null,
        startedAt: tt.startedAt ? new Date(tt.startedAt).toISOString() : null,
        endedAt: tt.endedAt ? new Date(tt.endedAt).toISOString() : null,

        remotePath: tt.remotePath ?? null,
        bytesSent: tt.bytesSent != null ? String(tt.bytesSent) : null,

        lastError: tt.lastError ?? null,

        createdAt: t.createdAt.toISOString(),
        updatedAt: t.updatedAt.toISOString(),

        projectNumber: prj?.projectNumber ?? undefined,
        projectName: prj?.name ?? undefined,

        advertiserGroup: prj?.advertiserGroup?.name ?? null,
        advertiser: prj?.advertiser?.name ?? null,
        brand: prj?.brand?.name ?? null,
        productCategory: prj?.productCategory?.name ?? null,

        mediaAgency: prj?.mediaAgency?.name ?? null,
        mediaAgencyTeam: prj?.mediaAgencyTeam?.name ?? null,
        creativeAgency: prj?.creativeAgency?.name ?? null,
        creativeAgencyTeam: prj?.creativeAgencyTeam?.name ?? null,
        productionHouse: prj?.productionHouse?.name ?? null,
        productionHouseTeam: prj?.productionHouseTeam?.name ?? null,
        postHouse: prj?.postHouse?.name ?? null,
        postHouseTeam: prj?.postHouseTeam?.name ?? null,
        audioAgency: prj?.audioAgency?.name ?? null,
        audioAgencyTeam: prj?.audioAgencyTeam?.name ?? null,

        billableParty: prj?.billableParty?.name ?? null,

        uploaderEmail,
        uploadedAt,

        caption: creative?.caption ?? null,
        duration: creative?.duration ?? null,
        languages: Array.isArray(creative?.languages) ? creative.languages : [],
        format: creative?.format ?? null,
        audio: creative?.audio ?? null,
        filename,
        mimeType,
        fileSizeBytes,
        sourceAssetType,
        sourceAssetFilename,

        qcStatus: creative?.qcStatus ?? null,
        qcFailureReasons: Array.isArray(creative?.qcFailureReasons) ? creative.qcFailureReasons : [],

        approvalStatus: req?.status ?? null,
        approvalStep1Label: s1?.label ?? null,
        approvalStep1Status: s1?.status ?? null,
        approvalStep1DecidedBy: s1?.decidedByUser?.email ?? null,
        approvalStep2Label: s2?.label ?? null,
        approvalStep2Status: s2?.status ?? null,
        approvalStep2DecidedBy: s2?.decidedByUser?.email ?? null,

        deliveryApprovalRequired,
        deliveryApprovalStatus,
        deliveryHouseId,
        deliveryStagingRemotePath,
        deliveryFinalRemotePath,

        channelServerStatus: channel?.serverStatus ?? null,
        channelServerMessage: channel?.serverMessage ?? null,
      };
    });

    if (this.hasLegacyProjectTrackingAccess(user) || this.hasGlobalAccountTrackingAccess(user)) return { rows };

    const filteredRows: TrackingRow[] = [];
    for (const row of rows) {
      if (await this.canViewTrackingRow(user, row.projectId, row.receiverAccountId)) filteredRows.push(row);
    }
    return { rows: filteredRows };
  }
}
