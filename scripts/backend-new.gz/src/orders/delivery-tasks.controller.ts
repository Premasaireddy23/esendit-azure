import { Body, Controller, Param, Post, UseGuards } from "@nestjs/common";
import { JwtAuthGuard } from "../common/auth/jwt-auth.guard";
import { PermissionsGuard } from "../common/auth/permissions.guard";
import { RequirePermissions } from "../common/auth/require-permissions.decorator";
import { CurrentUser } from "../common/auth/current-user.decorator";
import { DeliveryTasksService } from "./delivery-tasks.service";

@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller("delivery/tasks")
export class DeliveryTasksController {
  constructor(private readonly svc: DeliveryTasksService) {}

  @Post(":taskId/retry")
  @RequirePermissions("ORDER_SEND")
  retry(@CurrentUser() user: any, @Param("taskId") taskId: string) {
    return this.svc.retry(user.accountId, user.userId ?? user.id, taskId);
  }

  @Post(":taskId/send-again")
  @RequirePermissions("ORDER_SEND")
  sendAgain(@CurrentUser() user: any, @Param("taskId") taskId: string) {
    return this.svc.sendAgain(user.accountId, user.userId ?? user.id, taskId);
  }

  @Post(":taskId/failover")
  @RequirePermissions("ORDER_SEND")
  failover(@CurrentUser() user: any, @Param("taskId") taskId: string) {
    return this.svc.failover(user.accountId, user.userId ?? user.id, taskId);
  }

  // --- Delivery Viewer actions (Pause/Resume/Stop/Restart) ---
  @Post(":taskId/pause")
  @RequirePermissions("ORDER_SEND")
  pause(@CurrentUser() user: any, @Param("taskId") taskId: string) {
    return this.svc.pause(user.accountId, user.userId ?? user.id, taskId);
  }

  @Post(":taskId/resume")
  @RequirePermissions("ORDER_SEND")
  resume(@CurrentUser() user: any, @Param("taskId") taskId: string) {
    return this.svc.resume(user.accountId, user.userId ?? user.id, taskId);
  }

  @Post(":taskId/release")
  @RequirePermissions("ORDER_SEND")
  release(@CurrentUser() user: any, @Param("taskId") taskId: string, @Body() body: any) {
    return this.svc.release(user.accountId, user.userId ?? user.id, taskId, String(body?.houseId || ""));
  }

  @Post(":taskId/cancel")
  @RequirePermissions("ORDER_SEND")
  cancel(@CurrentUser() user: any, @Param("taskId") taskId: string) {
    return this.svc.cancel(user.accountId, user.userId ?? user.id, taskId);
  }
}
