import { BadRequestException, Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../common/prisma/prisma.service";
import { ServiceBusService } from "../common/queue/service-bus.service";
import {
  getDeliveryQueueForRoute,
  getDeliveryRouteConflictMessage,
  resolveDeliveryTaskRouting,
  withDeliveryRoutingTranscript,
} from "../common/queue/delivery-routing";

@Injectable()
export class DeliveryTasksService {
  constructor(private prisma: PrismaService, private readonly bus: ServiceBusService) {}

  private async getTaskForRouting(accountId: string, taskId: string) {
    const task = await this.prisma.deliveryTask.findFirst({
      where: { id: taskId, accountId },
      select: {
        id: true,
        transcript: true,
        forceBackup: true,
        mainDeliveryProfile: { select: { id: true, config: true } },
        backupDeliveryProfile: { select: { id: true, config: true } },
      },
    } as any);
    if (!task) throw new NotFoundException("Task not found");
    return task;
  }

  private ensureRoutingAllowed(task: any) {
    const routing = resolveDeliveryTaskRouting(task);
    if (routing.routeConflict) {
      throw new BadRequestException(getDeliveryRouteConflictMessage(routing.mainRoute, routing.backupRoute));
    }
    return routing;
  }

  private getApprovalGate(task: any) {
    const transcript = task?.transcript && typeof task.transcript === "object" ? task.transcript : {};
    const gate = transcript?.approvalGate && typeof transcript.approvalGate === "object" ? transcript.approvalGate : {};
    const required = gate?.required === true;
    const status = String(gate?.status || "").trim().toUpperCase();
    const stagedRemotePath = String(gate?.stagedRemotePath || "").trim();
    const houseId = String(gate?.houseId || "").trim();
    return { transcript, gate, required, status, stagedRemotePath, houseId };
  }

  private ensureNotWaitingForApproval(task: any) {
    const gate = this.getApprovalGate(task);
    if (gate.required && gate.status === "WAITING") {
      throw new BadRequestException("Task is waiting for destination approval. Use Approve & Release instead.");
    }
    return gate;
  }

  private resetApprovalGateForFreshRun(task: any) {
    const { transcript, gate, required } = this.getApprovalGate(task);
    if (!required) return transcript;
    return {
      ...transcript,
      approvalGate: {
        ...gate,
        required: true,
        status: "PENDING",
        houseId: null,
        approvedByUserId: null,
        approvedAt: null,
        releasedAt: null,
        stagedRemotePath: null,
        finalRemotePath: null,
        finalFileName: null,
      },
    };
  }

  private async republishTask(taskId: string, route: string, messageId: string = taskId, scheduleAtUtc?: Date) {
    await this.bus
      .sendJson(getDeliveryQueueForRoute(route), { taskId }, scheduleAtUtc ? { messageId, scheduleAtUtc } : { messageId })
      .catch(() => undefined);
  }

  async retry(accountId: string, userId: string, taskId: string) {
    void userId;
    const t = await this.prisma.deliveryTask.findFirst({
      where: { id: taskId, accountId },
      select: {
        id: true,
        status: true,
        attempts: true,
        maxAttempts: true,
      },
    });
    if (!t) throw new NotFoundException("Task not found");

    if (t.status === "SUCCESS") {
      throw new BadRequestException("Cannot retry a SUCCESS task");
    }

    const taskForRouting = await this.getTaskForRouting(accountId, taskId);
    const gate = this.ensureNotWaitingForApproval(taskForRouting);
    const routing = this.ensureRoutingAllowed(taskForRouting);

    const updated = await this.prisma.deliveryTask.update({
      where: { id: taskId },
      data: {
        status: "QUEUED",
        runAfter: null,

        // reset run metadata
        startedAt: null,
        endedAt: null,
        lastHeartbeatAt: null,

        // keep maxAttempts, reset attempts so worker restarts cleanly
        attempts: 0,

        // clear errors & outputs
        lastError: null,
        remotePath: null,
        bytesSent: null,

        // clear forced failover (retry starts with normal preference again)
        forceBackup: false,
        failoverUsed: false,
        transcript: withDeliveryRoutingTranscript(
          gate.required && gate.status === "APPROVED" && gate.stagedRemotePath
            ? taskForRouting.transcript
            : this.resetApprovalGateForFreshRun(taskForRouting),
          {
            preferredRoute: routing.mainRoute,
            mainRoute: routing.mainRoute,
            backupRoute: routing.backupRoute,
          },
        ) as any,
      } as any,
      select: { id: true, status: true, attempts: true, maxAttempts: true, updatedAt: true },
    });

    await this.republishTask(updated.id, routing.mainRoute);
    return { ok: true, task: updated };
  }

  /**
   * "Send again" for a completed task.
   *
   * IMPORTANT: In this app we often enforce uniqueness around (orderId, planLineId) to avoid duplicates.
   * Creating a brand-new task for the same plan line can therefore crash with a Prisma unique constraint error.
   *
   * To keep it reliable, we re-queue the SAME task (similar to retry) but we allow it even if the task was SUCCESS.
   */
  async sendAgain(accountId: string, userId: string, taskId: string) {
    void userId;
    const t = await this.prisma.deliveryTask.findFirst({
      where: { id: taskId, accountId },
      select: {
        id: true,
        status: true,
      } as any,
    });
    if (!t) throw new NotFoundException("Task not found");

    // Only allow "send again" for SUCCESS tasks (otherwise use Retry).
    if (String((t as any).status || "").toUpperCase() !== "SUCCESS") {
      throw new BadRequestException('Send again is allowed only after SUCCESS. Use "Retry" for failed/cancelled tasks.');
    }

    const taskForRouting = await this.getTaskForRouting(accountId, taskId);
    const routing = this.ensureRoutingAllowed(taskForRouting);

    const updated = await this.prisma.deliveryTask.update({
      where: { id: taskId },
      data: {
        status: "QUEUED",
        runAfter: null,

        // reset run metadata
        startedAt: null,
        endedAt: null,
        lastHeartbeatAt: null,

        // restart clean
        attempts: 0,

        // clear errors & outputs
        lastError: null,
        remotePath: null,
        bytesSent: null,

        // clear forced failover
        forceBackup: false,
        failoverUsed: false,
        transcript: withDeliveryRoutingTranscript(this.resetApprovalGateForFreshRun(taskForRouting), {
          preferredRoute: routing.mainRoute,
          mainRoute: routing.mainRoute,
          backupRoute: routing.backupRoute,
        }) as any,
      } as any,
      select: { id: true, status: true, attempts: true, updatedAt: true },
    });

    await this.republishTask(updated.id, routing.mainRoute);

    return { ok: true, task: updated };
  }

  async failover(accountId: string, userId: string, taskId: string) {
    void userId;
    const t = await this.prisma.deliveryTask.findFirst({
      where: { id: taskId, accountId },
      select: { id: true, status: true },
    });
    if (!t) throw new NotFoundException("Task not found");

    if (t.status === "SUCCESS") {
      throw new BadRequestException("Cannot failover a SUCCESS task");
    }

    const taskForRouting = await this.getTaskForRouting(accountId, taskId);
    const gate = this.ensureNotWaitingForApproval(taskForRouting);
    const routing = this.ensureRoutingAllowed({ ...taskForRouting, forceBackup: true });

    const updated = await this.prisma.deliveryTask.update({
      where: { id: taskId },
      data: {
        status: "QUEUED",
        runAfter: null,

        startedAt: null,
        endedAt: null,
        lastHeartbeatAt: null,

        attempts: 0,

        lastError: null,

        // key: force backup on next run
        forceBackup: true,
        transcript: withDeliveryRoutingTranscript(
          gate.required && gate.status === "APPROVED" && gate.stagedRemotePath
            ? taskForRouting.transcript
            : this.resetApprovalGateForFreshRun(taskForRouting),
          {
            preferredRoute: routing.preferredRoute,
            mainRoute: routing.mainRoute,
            backupRoute: routing.backupRoute,
          },
        ) as any,
      } as any,
      select: { id: true, status: true, attempts: true, updatedAt: true, forceBackup: true },
    });

    await this.republishTask(updated.id, routing.preferredRoute, `${updated.id}:failover:${Date.now()}`);
    return { ok: true, task: updated };
  }

  // --- Delivery Viewer actions ---
  async pause(accountId: string, userId: string, taskId: string) {
    void userId;
    const t = await this.prisma.deliveryTask.findFirst({
      where: { id: taskId, accountId },
      select: { id: true, status: true },
    });
    if (!t) throw new NotFoundException("Task not found");

    if (t.status === "SUCCESS") {
      throw new BadRequestException("Cannot pause a SUCCESS task");
    }
    if (t.status === "RUNNING") {
      // our simple worker cannot interrupt an in-flight transfer
      throw new BadRequestException("Cannot pause a RUNNING task (try Stop instead)");
    }

    const updated = await this.prisma.deliveryTask.update({
      where: { id: taskId },
      data: {
        status: "PAUSED" as any,
      } as any,
      select: { id: true, status: true, updatedAt: true },
    });
    return { ok: true, task: updated };
  }

  async resume(accountId: string, userId: string, taskId: string) {
    void userId;
    const t = await this.prisma.deliveryTask.findFirst({
      where: { id: taskId, accountId },
      select: { id: true, status: true },
    });
    if (!t) throw new NotFoundException("Task not found");

    if (t.status !== "PAUSED") {
      throw new BadRequestException("Task is not PAUSED");
    }

    const taskForRouting = await this.getTaskForRouting(accountId, taskId);
    const gate = this.getApprovalGate(taskForRouting);
    if (gate.required && gate.status === "WAITING") {
      throw new BadRequestException("Task is waiting for destination approval. Use Approve & Release instead.");
    }
    const routing = this.ensureRoutingAllowed(taskForRouting);

    const updated = await this.prisma.deliveryTask.update({
      where: { id: taskId },
      data: {
        status: "QUEUED" as any,
        runAfter: null,
        transcript: withDeliveryRoutingTranscript(taskForRouting.transcript, {
          preferredRoute: routing.preferredRoute,
          mainRoute: routing.mainRoute,
          backupRoute: routing.backupRoute,
        }) as any,
      } as any,
      select: { id: true, status: true, updatedAt: true },
    });
    await this.republishTask(updated.id, routing.preferredRoute, `${updated.id}:resume:${Date.now()}`);
    return { ok: true, task: updated };
  }

  async release(accountId: string, userId: string, taskId: string, houseIdRaw: string) {
    const houseId = String(houseIdRaw || "").trim();
    if (!houseId) throw new BadRequestException("House ID is required");

    const taskForRouting = await this.getTaskForRouting(accountId, taskId);
    const gate = this.getApprovalGate(taskForRouting);
    if (!gate.required || gate.status !== "WAITING" || !gate.stagedRemotePath) {
      throw new BadRequestException("Task is not waiting for destination approval");
    }

    const routing = this.ensureRoutingAllowed(taskForRouting);
    const updated = await this.prisma.deliveryTask.update({
      where: { id: taskId },
      data: {
        status: "QUEUED" as any,
        runAfter: null,
        endedAt: null,
        lastError: null,
        transcript: withDeliveryRoutingTranscript(
          {
            ...gate.transcript,
            approvalGate: {
              ...gate.gate,
              required: true,
              status: "APPROVED",
              houseId,
              approvedByUserId: userId,
              approvedAt: new Date().toISOString(),
            },
          },
          {
            preferredRoute: routing.preferredRoute,
            mainRoute: routing.mainRoute,
            backupRoute: routing.backupRoute,
          },
        ) as any,
      } as any,
      select: { id: true, status: true, updatedAt: true },
    });

    await this.republishTask(updated.id, routing.preferredRoute, `${updated.id}:approval-release:${Date.now()}`);
    return { ok: true, task: updated };
  }

  async cancel(accountId: string, userId: string, taskId: string) {
    void userId;
    const t = await this.prisma.deliveryTask.findFirst({
      where: { id: taskId, accountId },
      select: { id: true, status: true },
    });
    if (!t) throw new NotFoundException("Task not found");

    if (t.status === "SUCCESS") {
      throw new BadRequestException("Cannot stop a SUCCESS task");
    }
    if (t.status === "CANCELLED") {
      return { ok: true, task: t };
    }

    // Note: if RUNNING, we only mark it; the worker may still finish the current attempt.
    const updated = await this.prisma.deliveryTask.update({
      where: { id: taskId },
      data: {
        status: "CANCELLED" as any,
        runAfter: null,
      } as any,
      select: { id: true, status: true, updatedAt: true },
    });
    return { ok: true, task: updated };
  }
}
