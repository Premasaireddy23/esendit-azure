export const destinationSelect = {
  id: true,
  accountId: true,
  name: true,
  uri: true,
  category: true,
  destinationAccount: true,
  countryId: true,
  cityId: true,
  status: true,
  config: true,
  fileNameTemplate: true,
  downloadPresets: true,
  createdAt: true,
  updatedAt: true,
};

export const deliveryProfileSelect = {
  id: true,
  accountId: true,
  name: true,
  protocol: true,
  status: true,
  config: true,
  stagingPath: true,
  finalPath: true,
  lastStatus: true,
  lastCheckedAt: true,
  lastError: true,
  createdAt: true,
  updatedAt: true,
};

export const channelSelect = {
  id: true,
  accountId: true,
  name: true,

  destinationId: true,
  status: true,
  sortOrder: true,

  notificationEmails: true,
  approvalsConfig: true,
  config: true,

  mainDeliveryProfileId: true,
  backupDeliveryProfileId: true,

  serverStatus: true,
  serverCheckedAt: true,

  destination: { select: { id: true, name: true } },
  mainDeliveryProfile: { select: { id: true, name: true, protocol: true, lastStatus: true, lastCheckedAt: true, lastError: true, config: true } },
  backupDeliveryProfile: { select: { id: true, name: true, protocol: true, lastStatus: true, lastCheckedAt: true, lastError: true, config: true } },


  createdAt: true,
  updatedAt: true,
};

export const channelForServerCheckSelect = {
  ...channelSelect,
  destination: { select: { id: true, name: true, uri: true } },
};
