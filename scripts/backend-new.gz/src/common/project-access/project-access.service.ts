import { ForbiddenException, Injectable, NotFoundException } from "@nestjs/common";
import { PrismaService } from "../prisma/prisma.service";
import type { AuthUser } from "../auth/current-user.decorator";
import { canonicalizePermissionKey } from "../auth/permission.normalize";
import {
  PROJECT_STAKEHOLDER_ACTIONS,
  isStakeholderPermissionKey,
  stakeholderPermissionKey,
  type ProjectStakeholderAction,
  type ProjectStakeholderType,
} from "../auth/stakeholder-permission-matrix";

export type ProjectAccessSummary = {
  scope: "GLOBAL" | "PROJECT" | "NONE";
  roleLabels: string[];
  /**
   * Receiver-only access is granted when a user's email belongs only to a receiver
   * account linked through the project's selected/committed destination channels.
   * Keep this view-only so receiver logins cannot accidentally upload, plan, approve,
   * send, or edit unless they also match another explicit project stakeholder.
   */
  receiverOnly?: boolean;
  receiverAccountIds?: string[];
  activeReceiverAccountId?: string | null;
  stakeholderTypes?: ProjectStakeholderType[];
  stakeholderActions?: Record<string, ProjectStakeholderAction[]>;
  usesSpecificStakeholderPermissions?: boolean;
  canUpdateHouseId?: boolean;
  canViewProject: boolean;
  canViewCreatives: boolean;
  canViewDam: boolean;
  canStreamDam: boolean;
  canViewTracking: boolean;
  canUploadCreatives: boolean;
  canEditProject: boolean;
  canPlanner: boolean;
  canCommit: boolean;
  canApprove: boolean;
  canSend: boolean;
  canCloseProject: boolean;
  canReopenProject: boolean;
  canDeleteProject: boolean;
};

const PROJECT_SCOPED_READ = [
  "page:projects",
  "action:projects:scoped:read",
  "action:tracking:read:scoped",
  "action:library:read:scoped",
  "action:library:stream:scoped",
  "action:projects:creatives:upload:scoped",
  "action:projects:planner:edit:scoped",
  "approvals.decide.scoped",
];

function normalizeEmail(raw?: string | null) {
  return String(raw ?? "").trim().toLowerCase();
}

function emailListHas(emails: any, email: string) {
  if (!email || !Array.isArray(emails)) return false;
  return emails.some((item) => normalizeEmail(item) === email);
}

function uniq(list: string[]) {
  return Array.from(new Set(list.filter(Boolean)));
}

function readReceiverAccountId(config: any) {
  if (!config || typeof config !== "object") return "";
  return String(config.receiverAccountId || config.receiver_account_id || "").trim();
}

function getActiveReceiverAccountId(user: AuthUser | any) {
  const id = String(user?.activeReceiverAccountId || "").trim();
  return id || null;
}

@Injectable()
export class ProjectAccessService {
  constructor(private readonly prisma: PrismaService) {}

  hasPerm(user: AuthUser | any, key: string) {
    const want = canonicalizePermissionKey(key);
    const perms = Array.isArray(user?.permissions) ? user.permissions : [];
    return perms.some((p: string) => canonicalizePermissionKey(p) === want);
  }

  hasAnyPerm(user: AuthUser | any, keys: readonly string[]) {
    return keys.some((key) => this.hasPerm(user, key));
  }

  hasAnySpecificStakeholderPerm(user: AuthUser | any) {
    const perms = Array.isArray(user?.permissions) ? user.permissions : [];
    return perms.some((p: string) => isStakeholderPermissionKey(canonicalizePermissionKey(p)));
  }

  hasStakeholderPerm(user: AuthUser | any, type: ProjectStakeholderType, action: ProjectStakeholderAction) {
    return this.hasPerm(user, stakeholderPermissionKey(type, action));
  }

  private stakeholderActionsForUser(user: AuthUser | any, types: ProjectStakeholderType[]) {
    const out: Record<string, ProjectStakeholderAction[]> = {};
    for (const type of types) {
      const actions = PROJECT_STAKEHOLDER_ACTIONS
        .map((item) => item.action)
        .filter((action) => this.hasStakeholderPerm(user, type, action));
      if (actions.length) out[type] = actions;
    }
    return out;
  }

  private canBySpecificStakeholderAction(
    user: AuthUser | any,
    types: ProjectStakeholderType[],
    actions: ProjectStakeholderAction[],
  ) {
    return types.some((type) => actions.some((action) => this.hasStakeholderPerm(user, type, action)));
  }

  private hasAnySpecificActionForMatchedStakeholder(user: AuthUser | any, types: ProjectStakeholderType[]) {
    return types.some((type) =>
      PROJECT_STAKEHOLDER_ACTIONS.some((item) => this.hasStakeholderPerm(user, type, item.action)),
    );
  }

  hasGlobalProjectRead(user: AuthUser | any) {
    return this.hasAnyPerm(user, ["PROJECT_READ", "action:projects:read"]);
  }

  canUseScopedProjectAccess(user: AuthUser | any) {
    return (
      this.hasAnyPerm(user, PROJECT_SCOPED_READ) ||
      this.hasAnySpecificStakeholderPerm(user) ||
      String(user?.userType || "").toUpperCase() === "THIRD_PARTY"
    );
  }

  canOpenProjectsArea(user: AuthUser | any) {
    return this.hasGlobalProjectRead(user) || this.canUseScopedProjectAccess(user);
  }

  private baseGlobalAccess(user: AuthUser | any): ProjectAccessSummary {
    const canEditProject = this.hasAnyPerm(user, ["PROJECT_UPDATE", "action:projects:update"]);
    const canCloseProject = this.hasAnyPerm(user, ["PROJECT_CLOSE", "action:projects:close"]);
    const canReopenProject = this.hasAnyPerm(user, ["PROJECT_REOPEN", "action:projects:reopen"]);
    return {
      scope: "GLOBAL",
      roleLabels: ["Global project access"],
      receiverOnly: false,
      receiverAccountIds: [],
      activeReceiverAccountId: null,
      stakeholderTypes: [],
      stakeholderActions: {},
      usesSpecificStakeholderPermissions: false,
      canUpdateHouseId: this.hasAnyPerm(user, ["PROJECT_UPDATE", "action:projects:update"]),
      canViewProject: true,
      canViewCreatives: true,
      canViewDam: this.hasAnyPerm(user, ["page:library", "page:dam", "action:library:read", "action:dam:read"]),
      canStreamDam: this.hasAnyPerm(user, ["action:library:stream", "action:dam:stream", "action:media:download"]),
      canViewTracking: this.hasAnyPerm(user, ["PROJECT_READ", "action:projects:read", "action:tracking:read", "TRACKING_READ"]),
      canUploadCreatives: canEditProject,
      canEditProject,
      canPlanner: this.hasAnyPerm(user, ["Page_Planner", "action:planner:edit"]),
      canCommit: this.hasAnyPerm(user, ["COMMIT_RUN"]),
      canApprove: this.hasAnyPerm(user, ["approvals.decide", "APPROVALS_DECIDE"]),
      canSend: this.hasAnyPerm(user, ["ORDER_SEND", "action:orders:send"]),
      canCloseProject,
      canReopenProject,
      canDeleteProject: canEditProject,
    };
  }

  private emptyAccess(): ProjectAccessSummary {
    return {
      scope: "NONE",
      roleLabels: [],
      receiverOnly: false,
      receiverAccountIds: [],
      activeReceiverAccountId: null,
      stakeholderTypes: [],
      stakeholderActions: {},
      usesSpecificStakeholderPermissions: false,
      canUpdateHouseId: false,
      canViewProject: false,
      canViewCreatives: false,
      canViewDam: false,
      canStreamDam: false,
      canViewTracking: false,
      canUploadCreatives: false,
      canEditProject: false,
      canPlanner: false,
      canCommit: false,
      canApprove: false,
      canSend: false,
      canCloseProject: false,
      canReopenProject: false,
      canDeleteProject: false,
    };
  }

  private async getReceiverRoutesForProject(accountId: string, projectId: string) {
    const [planningEntries, planLines] = await Promise.all([
      this.prisma.planningEntry.findMany({
        where: { accountId, projectId, selected: true },
        select: { creativeId: true, channelId: true },
      }).catch(() => []),
      this.prisma.planLine.findMany({
        where: { accountId, planVersion: { projectId } },
        select: { creativeId: true, channelId: true },
      }).catch(() => []),
    ]);

    const routeRows = [
      ...(planningEntries || []).map((row: any) => ({
        creativeId: String(row?.creativeId || "").trim(),
        channelId: String(row?.channelId || "").trim(),
      })),
      ...(planLines || []).map((row: any) => ({
        creativeId: String(row?.creativeId || "").trim(),
        channelId: String(row?.channelId || "").trim(),
      })),
    ].filter((row) => row.channelId);

    const channelIds = uniq(routeRows.map((row) => row.channelId));
    if (!channelIds.length) return [];

    const channels = await this.prisma.channel.findMany({
      where: { accountId, id: { in: channelIds } },
      select: {
        id: true,
        destinationId: true,
        destination: { select: { id: true, name: true, config: true } },
      },
    }).catch(() => []);

    const channelById = new Map((channels || []).map((channel: any) => [String(channel.id), channel]));
    const receiverIds = uniq(
      (channels || [])
        .map((channel: any) => readReceiverAccountId(channel?.destination?.config))
        .filter(Boolean),
    );
    if (!receiverIds.length) return [];

    const receivers = await this.prisma.partnerAccount.findMany({
      where: { accountId, id: { in: receiverIds } },
      select: { id: true, name: true, emails: true, receiverCategory: true },
    }).catch(() => []);

    const receiverById = new Map((receivers || []).map((receiver: any) => [String(receiver.id), receiver]));
    const routesByReceiver = new Map<string, any>();

    for (const route of routeRows) {
      const channel: any = channelById.get(route.channelId);
      const receiverId = readReceiverAccountId(channel?.destination?.config);
      if (!receiverId || !receiverById.has(receiverId)) continue;

      const receiverRow: any = receiverById.get(receiverId) || {};
      const existing = routesByReceiver.get(receiverId) || {
        ...receiverRow,
        destinationIds: new Set<string>(),
        channelIds: new Set<string>(),
        creativeIds: new Set<string>(),
      };

      if (channel?.destinationId || channel?.destination?.id) {
        existing.destinationIds.add(String(channel.destinationId || channel.destination.id));
      }
      if (route.channelId) existing.channelIds.add(route.channelId);
      if (route.creativeId) existing.creativeIds.add(route.creativeId);
      routesByReceiver.set(receiverId, existing);
    }

    return Array.from(routesByReceiver.values()).map((row: any) => ({
      id: row.id,
      name: row.name,
      emails: row.emails,
      receiverCategory: row.receiverCategory,
      destinationIds: Array.from(row.destinationIds || []),
      channelIds: Array.from(row.channelIds || []),
      creativeIds: Array.from(row.creativeIds || []),
    }));
  }

  private async getReceiverAccountsForProject(accountId: string, projectId: string) {
    return this.getReceiverRoutesForProject(accountId, projectId);
  }

  private async getBrandEmails(accountId: string, brandId?: string | null) {
    if (!brandId) return [];
    try {
      const row = await (this.prisma as any).brand.findFirst({
        where: { accountId, id: brandId },
        select: { emails: true },
      });
      return Array.isArray(row?.emails) ? row.emails : [];
    } catch {
      return [];
    }
  }

  async getProjectAccess(user: AuthUser | any, projectId: string): Promise<ProjectAccessSummary> {
    const accountId = String(user?.accountId || "").trim();
    if (!accountId || !projectId) return this.emptyAccess();

    if (this.hasGlobalProjectRead(user)) {
      return this.baseGlobalAccess(user);
    }

    if (!this.canUseScopedProjectAccess(user)) {
      return this.emptyAccess();
    }

    const project: any = await this.prisma.project.findFirst({
      where: { id: projectId, accountId },
      select: {
        id: true,
        brandId: true,
        approvalsEnabled: true,
        advertiserGroup: { select: { id: true, name: true, emails: true } },
        advertiser: { select: { id: true, name: true, emails: true } },
        brand: { select: { id: true, name: true } },
        billableParty: { select: { id: true, name: true, emails: true } },
        senderAccount: { select: { id: true, name: true, emails: true } },
        mediaAgency: { select: { id: true, name: true, emails: true } },
        mediaAgencyTeam: { select: { id: true, name: true, emails: true } },
        creativeAgency: { select: { id: true, name: true, emails: true } },
        creativeAgencyTeam: { select: { id: true, name: true, emails: true } },
        productionHouse: { select: { id: true, name: true, emails: true } },
        productionHouseTeam: { select: { id: true, name: true, emails: true } },
        postHouse: { select: { id: true, name: true, emails: true } },
        postHouseTeam: { select: { id: true, name: true, emails: true } },
        audioAgency: { select: { id: true, name: true, emails: true } },
        audioAgencyTeam: { select: { id: true, name: true, emails: true } },
        uploaderAgency: { select: { id: true, name: true, emails: true } },
        uploaderAgencyTeam: { select: { id: true, name: true, emails: true } },
      } as any,
    });

    if (!project) throw new NotFoundException("Project not found");

    const email = normalizeEmail(user?.email);
    const activeReceiverAccountId = getActiveReceiverAccountId(user);
    const roleLabels: string[] = [];
    let stakeholderMatch = false;
    let nonReceiverStakeholderMatch = false;
    let uploaderMatch = false;
    let mediaMatch = false;
    let receiverMatch = false;
    const matchedReceiverAccountIds: string[] = [];
    const matchedStakeholderTypes = new Set<ProjectStakeholderType>();

    const addMatch = (
      label: string,
      entity: any,
      type: ProjectStakeholderType,
      opts?: { uploader?: boolean; media?: boolean },
    ) => {
      if (!emailListHas(entity?.emails, email)) return;
      stakeholderMatch = true;
      nonReceiverStakeholderMatch = true;
      matchedStakeholderTypes.add(type);
      if (opts?.uploader) uploaderMatch = true;
      if (opts?.media) mediaMatch = true;
      roleLabels.push(label);
    };

    addMatch("Advertiser Group", project.advertiserGroup, "advertiserGroup");
    addMatch("Advertiser", project.advertiser, "advertiser");
    const brandEmails = await this.getBrandEmails(accountId, project.brandId);
    if (emailListHas(brandEmails, email)) {
      stakeholderMatch = true;
      nonReceiverStakeholderMatch = true;
      matchedStakeholderTypes.add("brand");
      roleLabels.push("Brand");
    }
    addMatch("Billable Party", project.billableParty, "billableParty");
    addMatch("Sender Account", project.senderAccount, "senderAccount");
    addMatch("Media Agency", project.mediaAgency, "mediaAgency", { media: true });
    addMatch("Media Agency Team", project.mediaAgencyTeam, "mediaAgencyTeam", { media: true });
    addMatch("Creative Agency", project.creativeAgency, "creativeAgency");
    addMatch("Creative Agency Team", project.creativeAgencyTeam, "creativeAgencyTeam");
    addMatch("Production", project.productionHouse, "production");
    addMatch("Production Team", project.productionHouseTeam, "productionTeam");
    addMatch("Post House", project.postHouse, "postHouse");
    addMatch("Post House Team", project.postHouseTeam, "postHouseTeam");
    addMatch("Audio Agency", project.audioAgency, "audioAgency");
    addMatch("Audio Agency Team", project.audioAgencyTeam, "audioAgencyTeam");
    addMatch("Uploader Agency", project.uploaderAgency, "uploaderAgency", { uploader: true });
    addMatch("Uploader Agency Team", project.uploaderAgencyTeam, "uploaderAgencyTeam", { uploader: true });

    const receivers = await this.getReceiverAccountsForProject(accountId, projectId);
    for (const receiver of receivers as any[]) {
      const receiverId = String(receiver?.id || "").trim();
      if (!emailListHas(receiver?.emails, email)) continue;
      if (activeReceiverAccountId && receiverId !== activeReceiverAccountId) continue;

      stakeholderMatch = true;
      receiverMatch = true;
      matchedStakeholderTypes.add("receiverAccount");
      matchedReceiverAccountIds.push(receiverId);
      roleLabels.push(`Receiver Account${receiver?.name ? `: ${receiver.name}` : ""}`);
    }

    if (!stakeholderMatch && !uploaderMatch && !mediaMatch && !receiverMatch) {
      return this.emptyAccess();
    }

    const receiverOnly = receiverMatch && !nonReceiverStakeholderMatch;
    const stakeholderTypes = Array.from(matchedStakeholderTypes);
    const usesSpecificStakeholderPermissions = this.hasAnySpecificStakeholderPerm(user);
    const stakeholderActions = this.stakeholderActionsForUser(user, stakeholderTypes);

    const canSpecific = (actions: ProjectStakeholderAction[]) =>
      this.canBySpecificStakeholderAction(user, stakeholderTypes, actions);

    const canViewProject = usesSpecificStakeholderPermissions
      ? canSpecific(["view"]) || this.hasAnySpecificActionForMatchedStakeholder(user, stakeholderTypes)
      : true;

    const canViewDam = usesSpecificStakeholderPermissions
      ? canSpecific(["dam:view", "view"])
      : this.hasAnyPerm(user, ["action:library:read:scoped", "action:dam:read:scoped", "action:projects:scoped:read", "page:projects"]);

    const canStreamDam = usesSpecificStakeholderPermissions
      ? canSpecific(["dam:stream", "dam:view", "view"])
      : this.hasAnyPerm(user, ["action:library:stream:scoped", "action:dam:stream:scoped", "action:projects:scoped:read", "page:projects"]);

    const canViewTracking = usesSpecificStakeholderPermissions
      ? canSpecific(["tracking:view", "view"])
      : this.hasAnyPerm(user, ["action:tracking:read:scoped", "action:projects:scoped:read", "page:projects"]);

    const canUploadCreatives = usesSpecificStakeholderPermissions
      ? canSpecific(["upload"])
      : uploaderMatch && this.hasAnyPerm(user, ["action:projects:creatives:upload:scoped", "page:projects"]);

    const canPlanner = usesSpecificStakeholderPermissions
      ? canSpecific(["planner"])
      : mediaMatch && this.hasAnyPerm(user, ["action:projects:planner:edit:scoped", "page:projects"]);

    const canApprove = usesSpecificStakeholderPermissions
      ? canSpecific(["approve"])
      : !receiverOnly && receiverMatch && this.hasAnyPerm(user, ["approvals.decide.scoped", "page:projects"]);

    const canEditProject = usesSpecificStakeholderPermissions ? canSpecific(["update"]) : false;
    const canCommit = usesSpecificStakeholderPermissions ? canSpecific(["commit"]) : false;
    const canSend = usesSpecificStakeholderPermissions ? canSpecific(["send"]) : false;
    const canUpdateHouseId = usesSpecificStakeholderPermissions ? canSpecific(["house-id:update"]) : false;

    return {
      scope: "PROJECT",
      roleLabels: uniq(roleLabels),
      receiverOnly,
      receiverAccountIds: uniq(matchedReceiverAccountIds),
      activeReceiverAccountId,
      stakeholderTypes,
      stakeholderActions,
      usesSpecificStakeholderPermissions,
      canUpdateHouseId,
      canViewProject,
      canViewCreatives: canViewProject,
      canViewDam,
      canStreamDam,
      canViewTracking,
      canUploadCreatives,
      canEditProject,
      canPlanner,
      canCommit,
      canApprove,
      canSend,
      canCloseProject: false,
      canReopenProject: false,
      canDeleteProject: false,
    };
  }

  async assertCanViewProject(user: AuthUser | any, projectId: string) {
    const access = await this.getProjectAccess(user, projectId);
    if (!access.canViewProject) throw new ForbiddenException("Unauthorised");
    return access;
  }

  async assertCanViewDam(user: AuthUser | any, projectId: string) {
    const access = await this.getProjectAccess(user, projectId);
    if (!access.canViewDam) throw new ForbiddenException("Unauthorised");
    return access;
  }

  async assertCanStreamDam(user: AuthUser | any, projectId: string) {
    const access = await this.getProjectAccess(user, projectId);
    if (!access.canStreamDam) throw new ForbiddenException("Unauthorised");
    return access;
  }

  async assertCanViewTracking(user: AuthUser | any, projectId: string) {
    const access = await this.getProjectAccess(user, projectId);
    if (!access.canViewTracking) throw new ForbiddenException("Unauthorised");
    return access;
  }

  async assertCanUploadCreatives(user: AuthUser | any, projectId: string) {
    const access = await this.getProjectAccess(user, projectId);
    if (!access.canUploadCreatives) throw new ForbiddenException("Unauthorised");
    return access;
  }

  async assertCanPlanner(user: AuthUser | any, projectId: string) {
    const access = await this.getProjectAccess(user, projectId);
    if (!access.canPlanner) throw new ForbiddenException("Unauthorised");
    return access;
  }

  async assertCanApprove(user: AuthUser | any, projectId: string) {
    const access = await this.getProjectAccess(user, projectId);
    if (!access.canApprove) throw new ForbiddenException("Unauthorised");
    return access;
  }

  async visibleCreativeIdsForProject(user: AuthUser | any, projectId: string): Promise<Set<string> | null> {
    const access = await this.getProjectAccess(user, projectId);
    if (!access.canViewProject) return new Set<string>();

    // null means unrestricted within the project. Receiver-only users are restricted
    // to creatives attached to the selected/committed channels whose destination is
    // linked to their receiver account.
    if (!access.receiverOnly || !access.receiverAccountIds?.length) return null;

    const accountId = String(user?.accountId || "").trim();
    if (!accountId) return new Set<string>();

    const allowedReceiverIds = new Set(access.receiverAccountIds.map((id) => String(id)));
    const routes = await this.getReceiverRoutesForProject(accountId, projectId);
    const creativeIds = new Set<string>();
    for (const route of routes as any[]) {
      if (!allowedReceiverIds.has(String(route?.id || ""))) continue;
      for (const creativeId of route?.creativeIds || []) {
        const id = String(creativeId || "").trim();
        if (id) creativeIds.add(id);
      }
    }
    return creativeIds;
  }

  async canViewCreativeInProject(user: AuthUser | any, projectId: string, creativeId: string): Promise<boolean> {
    const visibleCreativeIds = await this.visibleCreativeIdsForProject(user, projectId);
    if (visibleCreativeIds === null) return true;
    return visibleCreativeIds.has(String(creativeId || "").trim());
  }

  canViewReceiverRoute(access: ProjectAccessSummary, receiverAccountId?: string | null) {
    if (!access.canViewProject) return false;
    if (!access.receiverOnly) return true;
    const allowed = new Set((access.receiverAccountIds || []).map((id) => String(id)));
    return !!receiverAccountId && allowed.has(String(receiverAccountId));
  }

  async filterProjectsForUser<T extends { id?: string | null }>(user: AuthUser | any, projects: T[]): Promise<T[]> {
    if (this.hasGlobalProjectRead(user)) return projects;
    if (!this.canUseScopedProjectAccess(user)) return [];

    const out: T[] = [];
    for (const project of projects || []) {
      const id = String(project?.id || "");
      if (!id) continue;
      const access = await this.getProjectAccess(user, id).catch(() => this.emptyAccess());
      if (access.canViewProject) out.push({ ...(project as any), access } as T);
    }
    return out;
  }

  async projectIdForCreative(accountId: string, creativeId: string) {
    const creative = await this.prisma.creative.findFirst({
      where: { id: creativeId, accountId },
      select: { id: true, projectId: true },
    });
    if (!creative) throw new NotFoundException("Creative not found");
    return creative.projectId;
  }
}
