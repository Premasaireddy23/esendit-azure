import * as path from "path";
import { MediaJobStatus } from "@prisma/client";
import { PrismaService } from "../prisma/prisma.service";
import { ServiceBusService } from "../queue/service-bus.service";
import { QUEUES } from "../queue/queue.constants";

type PresetDef = {
  key: string;
  label?: string;
  ext?: string;
  mimeType?: string;
  args?: string[];
  steps?: any[];
};

export type ResolvedChannelPreset = {
  key: string;
  label?: string;
  ext?: string;
  mimeType?: string;
  destinationId: string | null;
};

export type PresetJobOutput = {
  jobId: string;
  status: string;
  path: string;
  filename: string | null;
  mimeType: string | null;
  bytes: string | null;
  endedAt: string | null;
};

function parsePresets(downloadPresets: any): PresetDef[] {
  return Array.isArray(downloadPresets) ? (downloadPresets as PresetDef[]) : [];
}

function pickPresetsByKeys(all: PresetDef[], keys: any): PresetDef[] {
  const list = Array.isArray(keys) ? keys.map((k) => String(k).trim()).filter(Boolean) : [];
  if (!list.length) return [];
  const map = new Map(all.map((p) => [p.key, p] as const));
  const seen = new Set<string>();
  const out: PresetDef[] = [];
  for (const k of list) {
    if (seen.has(k)) continue;
    const p = map.get(k);
    if (!p) continue;
    seen.add(k);
    out.push(p);
  }
  return out;
}

function normalizePresetKey(v: any): string | null {
  const raw = String(v ?? "").trim();
  return raw || null;
}

function readBooleanFlag(v: any): boolean | null {
  if (v === undefined || v === null || v === "") return null;
  if (v === false || v === "false" || v === 0 || v === "0") return false;
  return true;
}

async function resolvePresetLibrary(prisma: PrismaService, accountId: string, destinationId?: string | null): Promise<PresetDef[]> {
  const account = await prisma.account.findFirst({
    where: { id: accountId },
    select: { downloadPresets: true } as any,
  });
  const accountPresets = parsePresets((account as any)?.downloadPresets);
  const library = accountPresets;
  if (!destinationId) return library;

  const destination = await prisma.destination.findFirst({
    where: { id: destinationId, accountId },
    select: { downloadPresets: true, config: true },
  });

  const destinationPresets = parsePresets((destination as any)?.downloadPresets);
  if (destinationPresets.length) return destinationPresets;

  const filtered = pickPresetsByKeys(library, (destination as any)?.config?.allowedPresetKeys);
  return filtered.length ? filtered : library;
}

export async function resolveChannelDefaultPreset(
  prisma: PrismaService,
  accountId: string,
  channel: { destinationId?: string | null; config?: any } | null | undefined,
): Promise<ResolvedChannelPreset | null> {
  const destinationId = (channel as any)?.destinationId ?? null;

  let presetKey = normalizePresetKey((channel as any)?.config?.defaultPresetKey);
  if (!presetKey && destinationId) {
    const destination = await prisma.destination.findFirst({
      where: { id: destinationId, accountId },
      select: { config: true },
    });
    presetKey = normalizePresetKey((destination as any)?.config?.defaultPresetKey);
  }

  if (!presetKey) return null;

  const presets = await resolvePresetLibrary(prisma, accountId, destinationId);
  const preset = presets.find((p) => p.key === presetKey);
  if (!preset) {
    return { key: presetKey, label: presetKey, destinationId, ext: undefined, mimeType: undefined };
  }
  return {
    key: preset.key,
    label: preset.label,
    ext: preset.ext,
    mimeType: preset.mimeType,
    destinationId,
  };
}


export function isChannelTranscodeOnCommit(channel: { config?: any } | null | undefined): boolean {
  const raw = (channel as any)?.config?.transcodeOnCommit;
  if (raw === false || raw === "false" || raw === 0 || raw === "0") return false;
  return true;
}

export async function resolveChannelCommitPreset(
  prisma: PrismaService,
  accountId: string,
  channel: { destinationId?: string | null; config?: any } | null | undefined,
): Promise<ResolvedChannelPreset | null> {
  const channelFlag = readBooleanFlag((channel as any)?.config?.transcodeOnCommit);
  if (channelFlag === false) return null;

  const destinationId = (channel as any)?.destinationId ?? null;
  if (channelFlag === null && destinationId) {
    const destination = await prisma.destination.findFirst({
      where: { id: destinationId, accountId },
      select: { config: true },
    });
    const fallbackFlag = readBooleanFlag((destination as any)?.config?.transcodeOnCommit);
    if (fallbackFlag === false) return null;
  }

  return resolveChannelDefaultPreset(prisma, accountId, channel);
}
export async function getLatestCreativePresetJob(
  prisma: PrismaService,
  accountId: string,
  creativeId: string,
  presetKey: string,
) {
  return prisma.presetDownloadJob.findFirst({
    where: {
      accountId,
      sourceType: "CREATIVE" as any,
      sourceId: creativeId,
      presetKey,
    },
    orderBy: [{ endedAt: "desc" }, { createdAt: "desc" }],
  });
}

export function extractPresetJobOutput(job: any): PresetJobOutput | null {
  const r = (job?.result ?? {}) as any;
  const outputPath = r?.outputBlobKey || r?.outputPath || r?.output?.absPath || null;
  if (!outputPath) return null;
  return {
    jobId: String(job.id),
    status: String(job.status || ""),
    path: String(outputPath),
    filename: r?.filename ? String(r.filename) : path.basename(String(outputPath)),
    mimeType: r?.mimeType ? String(r.mimeType) : (r?.preset?.mimeType ? String(r.preset.mimeType) : null),
    bytes: r?.bytes != null ? String(r.bytes) : null,
    endedAt: job?.endedAt ? new Date(job.endedAt).toISOString() : null,
  };
}

export async function ensureCreativePresetJob(
  prisma: PrismaService,
  bus: ServiceBusService,
  input: {
    accountId: string;
    creativeId: string;
    presetKey: string;
    destinationId?: string | null;
    userId?: string | null;
  },
) {
  const accountId = String(input.accountId);
  const creativeId = String(input.creativeId);
  const presetKey = String(input.presetKey);
  const destinationId = input.destinationId ?? null;
  const userId = input.userId ?? null;

  let job = await getLatestCreativePresetJob(prisma, accountId, creativeId, presetKey);

  if (job?.status === MediaJobStatus.SUCCEEDED || job?.status === MediaJobStatus.RUNNING || job?.status === MediaJobStatus.PENDING) {
    if (job.status !== MediaJobStatus.SUCCEEDED) {
      await bus.sendJson(
        QUEUES.presets(),
        { jobId: job.id, accountId, sourceType: "CREATIVE", sourceId: creativeId, presetKey },
        { messageId: String(job.id) },
      ).catch(() => undefined);
    }
    return job;
  }

  if (String(job?.status || "") === "FAILED" || String(job?.status || "") === "CANCELLED") {
    const reset = await prisma.presetDownloadJob.update({
      where: { id: job.id },
      data: {
        status: MediaJobStatus.PENDING,
        error: null,
        runAfter: null,
        startedAt: null,
        endedAt: null,
        result: null,
      } as any,
    });
    await bus.sendJson(
      QUEUES.presets(),
      { jobId: reset.id, accountId, sourceType: "CREATIVE", sourceId: creativeId, presetKey },
      { messageId: String(reset.id) },
    ).catch(() => undefined);
    return reset;
  }

  const payload = {
    sourceType: "CREATIVE",
    sourceId: creativeId,
    destinationId,
    presetKey,
    requestedAt: new Date().toISOString(),
    requestedByUserId: userId,
  };

  try {
    job = await prisma.presetDownloadJob.create({
      data: {
        accountId,
        sourceType: "CREATIVE" as any,
        sourceId: creativeId,
        destinationId,
        presetKey,
        status: MediaJobStatus.PENDING,
        payload: payload as any,
        ...(userId ? { createdByUserId: userId } : {}),
      } as any,
    });
  } catch (e: any) {
    if (String(e?.code) !== "P2002") throw e;
    job = await getLatestCreativePresetJob(prisma, accountId, creativeId, presetKey);
    if (!job) throw e;
    if (String(job.status || "") === "FAILED" || String(job.status || "") === "CANCELLED") {
      job = await prisma.presetDownloadJob.update({
        where: { id: job.id },
        data: {
          status: MediaJobStatus.PENDING,
          error: null,
          runAfter: null,
          startedAt: null,
          endedAt: null,
          result: null,
        } as any,
      });
    }
  }

  await bus.sendJson(
    QUEUES.presets(),
    { jobId: job.id, accountId, sourceType: "CREATIVE", sourceId: creativeId, presetKey },
    { messageId: String(job.id) },
  ).catch(() => undefined);

  return job;
}
