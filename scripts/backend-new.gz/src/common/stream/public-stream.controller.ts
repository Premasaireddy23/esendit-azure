import { Controller, Get, Inject, Query, Req, Res } from "@nestjs/common";
import type { Response } from "express";
import { createReadStream } from "node:fs";
import * as fs from "node:fs/promises";
import * as path from "node:path";
import { SignedStreamService } from "./signed-stream.service";
import { STORAGE } from "../storage/storage.token";
import type { StorageService } from "../storage/storage.types";

function looksLikeLocalPath(p: string): boolean {
  return path.isAbsolute(p) || /^[a-zA-Z]:\\/.test(p) || p.startsWith("./") || p.startsWith("../");
}

@Controller("public")
export class PublicStreamController {
  constructor(
    private readonly signed: SignedStreamService,
    @Inject(STORAGE) private storage: StorageService,
  ) {}

  @Get("stream")
  async stream(@Query("token") token: string, @Req() req: any, @Res() res: Response) {
    const p = this.signed.verify(String(token || ""));

    // Cloud storage shortcut: if this token points to a blob key, redirect to a SAS URL.
    // This ensures the API never proxies bytes in Azure.
    if (this.storage.isCloud() && !looksLikeLocalPath(String(p.path))) {
      const url = await this.storage.getSignedReadUrl(String(p.path), 30, {
        contentType: p.mimeType || undefined,
        contentDisposition: p.filename ? `${p.disposition || "inline"}; filename="${p.filename}"` : undefined,
      });
      return res.redirect(302, url);
    }

    const stat = await fs.stat(p.path);

    const mime = p.mimeType || "application/octet-stream";
    res.setHeader("Content-Type", mime);
    res.setHeader("Accept-Ranges", "bytes");
    if (p.filename) {
      const disp = p.disposition || "inline";
      res.setHeader("Content-Disposition", `${disp}; filename=\"${p.filename}\"`);
    }

    const range = req.headers?.range as string | undefined;
    if (!range) {
      res.setHeader("Content-Length", stat.size);
      return createReadStream(p.path).pipe(res);
    }

    const m = /^bytes=(\d+)-(\d*)$/.exec(range);
    if (!m) return res.status(416).end();
    const start = Number(m[1]);
    const end = m[2] ? Number(m[2]) : stat.size - 1;
    if (start >= stat.size || end >= stat.size || start > end) return res.status(416).end();

    res.status(206);
    res.setHeader("Content-Range", `bytes ${start}-${end}/${stat.size}`);
    res.setHeader("Content-Length", end - start + 1);
    return createReadStream(p.path, { start, end }).pipe(res);
  }
}
