import { Injectable } from "@nestjs/common";
import * as crypto from "crypto";import { createHmac, timingSafeEqual } from "node:crypto";

type Payload = {
  path: string;
  mimeType?: string;
  filename?: string;
  disposition?: "inline" | "attachment";
  exp: number;
};

function b64u(input: Buffer | string): string {
  const b = Buffer.isBuffer(input) ? input : Buffer.from(input);
  return b.toString("base64").replace(/=/g, "").replace(/\+/g, "-").replace(/\//g, "_");
}

function b64uDec(s: string): Buffer {
  const pad = s.length % 4 === 0 ? "" : "=".repeat(4 - (s.length % 4));
  const b64 = s.replace(/-/g, "+").replace(/_/g, "/") + pad;
  return Buffer.from(b64, "base64");
}

@Injectable()
export class SignedStreamService {
  private secret(): Buffer {
    const s = process.env.STREAM_TOKEN_SECRET || process.env.JWT_SECRET || "dev-stream-secret";
    return Buffer.from(String(s));
  }

  sign(payload: Omit<Payload, "exp"> & { ttlSeconds?: number }): string {
    const exp = Date.now() + 1000 * Math.max(10, Math.min(3600, payload.ttlSeconds ?? 300));
    const data: Payload = {
      path: payload.path,
      mimeType: payload.mimeType,
      filename: payload.filename,
      disposition: payload.disposition,
      exp,
    };
    const json = JSON.stringify(data);
    const head = b64u(json);
    const sig = b64u(crypto.createHmac("sha256", this.secret()).update(head).digest());
    return `${head}.${sig}`;
  }

  verify(token: string): Payload {
    const [head, sig] = token.split(".");
    if (!head || !sig) throw new Error("BAD_TOKEN");
    const expected = b64u(crypto.createHmac("sha256", this.secret()).update(head).digest());
    if (!crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(sig))) throw new Error("BAD_SIGNATURE");
    const payload = JSON.parse(b64uDec(head).toString("utf8")) as Payload;
    if (!payload?.path) throw new Error("BAD_PAYLOAD");
    if (Date.now() > payload.exp) throw new Error("TOKEN_EXPIRED");
    return payload;
  }

  makeUrl(payload: { path: string; mimeType?: string; filename?: string; disposition?: "inline" | "attachment"; ttlSeconds?: number }) {
    const token = this.sign(payload);
    return `/public/stream?token=${encodeURIComponent(token)}`;
  }
}
