import { Global, Module } from "@nestjs/common";
import { StorageModule } from "../storage/storage.module";
import { SignedStreamService } from "./signed-stream.service";
import { PublicStreamController } from "./public-stream.controller";

@Global()
@Module({
  imports: [StorageModule],
  providers: [SignedStreamService],
  controllers: [PublicStreamController],
  exports: [SignedStreamService],
})
export class StreamModule {}
