import {
  CanActivate,
  ExecutionContext,
  ForbiddenException,
  Injectable,
  UnauthorizedException,
} from "@nestjs/common";
import { Reflector } from "@nestjs/core";
import { PERMISSIONS_KEY } from "./require-permissions.decorator";
import { PERMISSIONS_ANY_KEY } from "./require-any-permissions.decorator";
import { canonicalizePermissionKey } from "./permission.normalize";

@Injectable()
export class PermissionsGuard implements CanActivate {
  constructor(private reflector: Reflector) {}

  canActivate(context: ExecutionContext): boolean {
    const required =
      this.reflector.getAllAndOverride<string[]>(PERMISSIONS_KEY, [
        context.getHandler(),
        context.getClass(),
      ]) ?? [];
    const requiredAny =
      this.reflector.getAllAndOverride<string[]>(PERMISSIONS_ANY_KEY, [
        context.getHandler(),
        context.getClass(),
      ]) ?? [];

    // No permissions required → allow
    if (!required.length && !requiredAny.length) return true;

    const req = context.switchToHttp().getRequest();
    const user = req.user;

    if (!user) throw new UnauthorizedException("Missing auth user context");

    const perms: string[] = Array.isArray(user.permissions) ? user.permissions : [];

    // Canonicalize both required and user permissions so legacy keys
    // (e.g., ADMIN_GROUPS_READ) work with canonical keys (e.g., action:admin:groups:read).
    const userCanon = new Set(perms.map((p) => canonicalizePermissionKey(p)));
    const missing = required.filter((p) => !userCanon.has(canonicalizePermissionKey(p)));
    if (missing.length) {
      throw new ForbiddenException("Unauthorised");
    }

    if (requiredAny.length) {
      const hasAny = requiredAny.some((p) => userCanon.has(canonicalizePermissionKey(p)));
      if (!hasAny) {
        throw new ForbiddenException("Unauthorised");
      }
    }

    return true;
  }
}
