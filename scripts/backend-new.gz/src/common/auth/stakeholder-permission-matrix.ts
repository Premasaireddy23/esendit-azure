export const PROJECT_STAKEHOLDER_TYPES = [
  { type: "advertiserGroup", slug: "advertiser-group", label: "Advertiser Group" },
  { type: "advertiser", slug: "advertiser", label: "Advertiser" },
  { type: "brand", slug: "brand", label: "Brand" },
  { type: "billableParty", slug: "billable-party", label: "Billable Party" },
  { type: "senderAccount", slug: "sender-account", label: "Sender Account" },
  { type: "receiverAccount", slug: "receiver-account", label: "Receiver Account" },
  { type: "mediaAgency", slug: "media-agency", label: "Media Agency" },
  { type: "mediaAgencyTeam", slug: "media-agency-team", label: "Media Agency Team" },
  { type: "creativeAgency", slug: "creative-agency", label: "Creative Agency" },
  { type: "creativeAgencyTeam", slug: "creative-agency-team", label: "Creative Agency Team" },
  { type: "production", slug: "production", label: "Production" },
  { type: "productionTeam", slug: "production-team", label: "Production Team" },
  { type: "postHouse", slug: "post-house", label: "Post House" },
  { type: "postHouseTeam", slug: "post-house-team", label: "Post House Team" },
  { type: "audioAgency", slug: "audio-agency", label: "Audio Agency" },
  { type: "audioAgencyTeam", slug: "audio-agency-team", label: "Audio Agency Team" },
  { type: "uploaderAgency", slug: "uploader-agency", label: "Uploader Agency" },
  { type: "uploaderAgencyTeam", slug: "uploader-agency-team", label: "Uploader Agency Team" },
] as const;

export type ProjectStakeholderType = (typeof PROJECT_STAKEHOLDER_TYPES)[number]["type"];

export const PROJECT_STAKEHOLDER_ACTIONS = [
  { action: "view", label: "View Project & Videos" },
  { action: "update", label: "Update Project" },
  { action: "upload", label: "Upload Creatives" },
  { action: "planner", label: "Planner Edit" },
  { action: "commit", label: "Commit Plan" },
  { action: "approve", label: "Approve / Reject" },
  { action: "send", label: "Send Delivery" },
  { action: "dam:view", label: "DAM View" },
  { action: "dam:stream", label: "DAM Stream / Preview" },
  { action: "tracking:view", label: "Tracking View" },
  { action: "house-id:update", label: "House ID Update" },
] as const;

export type ProjectStakeholderAction = (typeof PROJECT_STAKEHOLDER_ACTIONS)[number]["action"];

const TYPE_SLUG_BY_TYPE = new Map<string, string>(
  PROJECT_STAKEHOLDER_TYPES.map((item) => [item.type, item.slug]),
);

export function stakeholderTypeSlug(type: string) {
  return TYPE_SLUG_BY_TYPE.get(type) || String(type || "").trim().replace(/([a-z])([A-Z])/g, "$1-$2").toLowerCase();
}

export function stakeholderPermissionKey(type: string, action: string) {
  return `action:stakeholder:${stakeholderTypeSlug(type)}:${String(action || "").trim().toLowerCase()}`;
}

export function isStakeholderPermissionKey(key: string) {
  return String(key || "").trim().toLowerCase().startsWith("action:stakeholder:");
}
