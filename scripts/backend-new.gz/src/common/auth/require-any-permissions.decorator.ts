import { SetMetadata } from "@nestjs/common";

/**
 * Require the user to have AT LEAST ONE of the given permission keys.
 *
 * Used by PermissionsGuard (PERMISSIONS_ANY_KEY).
 */
export const PERMISSIONS_ANY_KEY = "permissions_any";

export const RequireAnyPermissions = (...permissions: string[]) =>
  SetMetadata(PERMISSIONS_ANY_KEY, permissions);
