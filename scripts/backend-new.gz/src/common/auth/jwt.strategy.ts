import { Injectable, UnauthorizedException } from "@nestjs/common";
import { PassportStrategy } from "@nestjs/passport";
import { ExtractJwt, Strategy } from "passport-jwt";
import { PrismaService } from "../prisma/prisma.service";
import { inferStakeholderScopedPermissionKeys } from "./stakeholder-scoped-permissions";
import { canonicalizePermissionKey } from "./permission.normalize";
import { isStakeholderPermissionKey } from "./stakeholder-permission-matrix";

type JwtPayload = {
  sub: string; // userId
  accountId?: string; // tenant
  supportMode?: boolean;
  impersonatedByUserId?: string;
  impersonatedByEmail?: string;
  supportReason?: string;
  supportTicket?: string;
  supportStartedAt?: string;
};

function isSupportReadOnlyPermission(key: string) {
  const canonical = canonicalizePermissionKey(key);
  const lower = canonical.toLowerCase();
  if (lower.startsWith("page:")) return true;
  if (lower.includes(":read") || lower.endsWith("_read")) return true;
  if (lower.includes(":view") || lower.includes("view")) return true;
  if (lower.includes(":stream") || lower.includes("stream")) return true;
  if (lower.includes(":scoped:read") || lower.includes("read:scoped")) return true;
  if (["project_read", "action:projects:scoped:read", "action:tracking:read:scoped"].includes(lower)) return true;
  return false;
}

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor(private prisma: PrismaService) {
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      ignoreExpiration: false,
      secretOrKey: process.env.JWT_SECRET,
    });
  }

  async validate(payload: JwtPayload) {
    const userId = payload?.sub;
    if (!userId) throw new UnauthorizedException("Invalid token payload");

    const user = await this.prisma.user.findFirst({
      where: {
        id: userId,
        ...(payload.accountId ? { accountId: payload.accountId } : {}),
        isActive: true,
      },
      select: {
        id: true,
        accountId: true,
        email: true,
        displayName: true,
        userType: true,
        isActive: true,
        roles: {
          select: {
            role: {
              select: {
                id: true,
                name: true,
                perms: {
                  select: {
                    permission: { select: { key: true } },
                  },
                },
              },
            },
          },
        },
      },
    });

    if (!user) throw new UnauthorizedException("User not found / inactive");

    // --- Direct user roles ---
    const directPermKeys = user.roles.flatMap((ur) => ur.role.perms.map((rp) => rp.permission.key));
    const directRoleNames = user.roles.map((ur) => ur.role.name);

    // --- Group-based roles (GroupMember -> GroupRole -> Role) ---
    const groupIds = await this.prisma.groupMember
      .findMany({
        where: { userId: user.id, group: { accountId: user.accountId } },
        select: { groupId: true },
      })
      .then((rows) => rows.map((r) => r.groupId));

    let groupRoleNames: string[] = [];
    let groupPermKeys: string[] = [];

    if (groupIds.length) {
      const roleIds = await this.prisma.groupRole
        .findMany({
          where: { groupId: { in: groupIds } },
          select: { roleId: true },
        })
        .then((rows) => Array.from(new Set(rows.map((r) => r.roleId))));

      if (roleIds.length) {
        const roles = await this.prisma.role.findMany({
          where: { id: { in: roleIds }, accountId: user.accountId },
          select: {
            name: true,
            perms: {
              select: {
                permission: { select: { key: true } },
              },
            },
          },
        });

        groupRoleNames = roles.map((r) => r.name);
        groupPermKeys = roles.flatMap((r) => r.perms.map((p) => p.permission.key));
      }
    }

    const explicitPermKeys = [...directPermKeys, ...groupPermKeys];
    const hasSpecificStakeholderPerm = explicitPermKeys.some((key) =>
      isStakeholderPermissionKey(canonicalizePermissionKey(key)),
    );
    const inferredStakeholderPermKeys = await inferStakeholderScopedPermissionKeys(this.prisma, user);
    const routePermKeys = hasSpecificStakeholderPerm ? ["page:projects", "action:projects:scoped:read"] : [];
    const fullPermissionKeys = Array.from(new Set([...explicitPermKeys, ...inferredStakeholderPermKeys, ...routePermKeys]));
    const permissions = payload?.supportMode
      ? fullPermissionKeys.filter((key) => isSupportReadOnlyPermission(key))
      : fullPermissionKeys;
    const roleNames = Array.from(new Set([...directRoleNames, ...groupRoleNames]));

    // ✅ Backward-safe return shape:
    // some modules might use req.user.id, some might use req.user.userId
    return {
      id: user.id,
      userId: user.id,
      accountId: user.accountId,
      email: user.email,
      displayName: user.displayName,
      userType: user.userType,
      roleNames,
      permissions,
      supportView: payload?.supportMode
        ? {
            active: true,
            impersonatedByUserId: payload.impersonatedByUserId || null,
            impersonatedByEmail: payload.impersonatedByEmail || null,
            reason: payload.supportReason || null,
            ticket: payload.supportTicket || null,
            startedAt: payload.supportStartedAt || null,
          }
        : null,
    };
  }
}
