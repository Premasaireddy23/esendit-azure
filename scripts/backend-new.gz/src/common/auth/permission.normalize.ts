// Canonicalize permission keys so legacy keys and newer "action:..." / "page:..." keys
// remain compatible. This enables a gradual migration to a single convention without
// breaking existing roles.

const ALIAS: Record<string, string> = {
  // Canonical + legacy aliases for Admin / Teams / Groups.
  // Some accounts still carry Team-based admin permission keys while newer
  // controllers use Groups-based keys. Keep both forms compatible.
  "action:admin:groups:read": "action:admin:groups:read",
  "action:admin:group:read": "action:admin:groups:read",
  "action:admin:teams:read": "action:admin:groups:read",
  "action:groups:read": "action:admin:groups:read",
  "action:group:read": "action:admin:groups:read",
  "action:teams:read": "action:admin:groups:read",

  "action:admin:groups:write": "action:admin:groups:write",
  "action:admin:group:write": "action:admin:groups:write",
  "action:admin:teams:write": "action:admin:groups:write",
  "action:groups:write": "action:admin:groups:write",
  "action:group:write": "action:admin:groups:write",
  "action:teams:write": "action:admin:groups:write",

  // Admin
  ADMIN_USERS_READ: "action:admin:users:read",
  ADMIN_USERS_WRITE: "action:admin:users:write",
  ADMIN_ROLES_READ: "action:admin:roles:read",
  ADMIN_ROLES_WRITE: "action:admin:roles:write",
  ADMIN_GROUPS_READ: "action:admin:groups:read",
  ADMIN_GROUPS_WRITE: "action:admin:groups:write",
  ADMIN_GROUP_READ: "action:admin:groups:read",
  ADMIN_GROUP_WRITE: "action:admin:groups:write",
  ADMIN_TEAMS_READ: "action:admin:groups:read",
  ADMIN_TEAMS_WRITE: "action:admin:groups:write",
  GROUPS_READ: "action:admin:groups:read",
  GROUPS_WRITE: "action:admin:groups:write",
  GROUP_READ: "action:admin:groups:read",
  GROUP_WRITE: "action:admin:groups:write",
  TEAMS_READ: "action:admin:groups:read",
  TEAMS_WRITE: "action:admin:groups:write",


  // Project-scoped stakeholder permissions
  PROJECT_SCOPED_READ: "action:projects:scoped:read",
  PAGE_PROJECTS: "page:projects",
  "page:projects": "page:projects",
  ACTION_PROJECTS_SCOPED_READ: "action:projects:scoped:read",
  "action:projects:scoped:read": "action:projects:scoped:read",
  ACTION_PROJECTS_CREATIVES_UPLOAD_SCOPED: "action:projects:creatives:upload:scoped",
  "action:projects:creatives:upload:scoped": "action:projects:creatives:upload:scoped",
  ACTION_PROJECTS_PLANNER_EDIT_SCOPED: "action:projects:planner:edit:scoped",
  "action:projects:planner:edit:scoped": "action:projects:planner:edit:scoped",
  ACTION_TRACKING_READ_SCOPED: "action:tracking:read:scoped",
  "action:tracking:read:scoped": "action:tracking:read:scoped",
  ACTION_LIBRARY_READ_SCOPED: "action:library:read:scoped",
  "action:library:read:scoped": "action:library:read:scoped",
  ACTION_LIBRARY_STREAM_SCOPED: "action:library:stream:scoped",
  "action:library:stream:scoped": "action:library:stream:scoped",
  APPROVALS_DECIDE_SCOPED: "action:approvals:decide:scoped",
  "approvals.decide.scoped": "action:approvals:decide:scoped",

  // Account / server
  ACCOUNT_SETTINGS_READ: "action:account-settings:read",
  ACCOUNT_SETTINGS_WRITE: "action:account-settings:write",
  SERVER_STATUS_READ: "action:server-status:read",
  SERVER_STATUS_RUN: "action:server-status:run",

  // Masters
  MASTERS_CREATE: "action:masters:create",
  MASTERS_READ: "action:masters:read",
  MASTERS_UPDATE: "action:masters:update",
  MASTERS_DELETE: "action:masters:delete",

  // Projects
  PROJECT_CREATE: "action:projects:create",
  PROJECT_READ: "action:projects:read",
  PROJECT_UPDATE: "action:projects:update",
  PROJECT_CLOSE: "action:projects:close",
  PROJECT_REOPEN: "action:projects:reopen",
  PROJECT_WIZARD_CREATE: "action:projects:wizard:create",

  // Approvals
  APPROVAL_TRACKER_READ: "action:approvals:tracker:read",

  // Billing
  BILLING_CREATE: "action:billing:create",
  BILLING_READ: "action:billing:read",
  BILLING_UPDATE: "action:billing:update",
  BILLING_DELETE: "action:billing:delete",

  // Notifications
  NOTIFICATIONS_READ: "action:notifications:read",
  NOTIFICATIONS_RETRIGGER: "action:notifications:retrigger",

  // Orders / send / tracking / media
  ORDER_SEND: "action:orders:send",
  TRACKING_READ: "action:tracking:read",
  MEDIA_DOWNLOAD: "action:media:download",

  // Library / DAM (new library names + legacy dam names)
  PAGE_LIBRARY: "page:library",
  "page:library": "page:library",
  PAGE_DAM: "page:library",
  "page:dam": "page:library",

  ACTION_LIBRARY_READ: "action:library:read",
  "action:library:read": "action:library:read",
  ACTION_DAM_READ: "action:library:read",
  "action:dam:read": "action:library:read",

  ACTION_LIBRARY_INDEX: "action:library:index",
  "action:library:index": "action:library:index",
  ACTION_DAM_INDEX: "action:library:index",
  "action:dam:index": "action:library:index",

  ACTION_LIBRARY_STREAM: "action:library:stream",
  "action:library:stream": "action:library:stream",
  ACTION_DAM_STREAM: "action:library:stream",
  "action:dam:stream": "action:library:stream",
};

export function canonicalizePermissionKey(key: string): string {
  const raw = String(key ?? "").trim();
  if (!raw) return "";

  const lowered = raw.toLowerCase();

  // Exact alias mapping
  if (ALIAS[raw]) return ALIAS[raw];
  if (ALIAS[lowered]) return ALIAS[lowered];

  // Already canonical
  if (raw.startsWith("action:") || raw.startsWith("page:")) {
    return lowered;
  }

  // snake_case legacy style: action_bulk_create → action:bulk:create
  if (raw.startsWith("action_") && raw.length > 7) {
    const rest = raw.slice("action_".length);
    const parts = rest.split("_").filter(Boolean).map((p) => p.toLowerCase());
    if (parts.length >= 2) return `action:${parts.join(":")}`;
  }

  // legacy dot style: approvals.decide → action:approvals:decide
  if (raw.includes(".") && !raw.includes(":")) {
    return `action:${raw.replace(/\./g, ":").toLowerCase()}`;
  }

  // legacy page style: Page_Planner → page:planner
  if (raw.startsWith("Page_")) {
    const rest = raw.slice("Page_".length);
    const parts = rest.split("_").filter(Boolean).map((p) => p.toLowerCase());
    if (parts.length) return `page:${parts.join(":")}`;
  }

  // Generic UPPER_CASE ops: FOO_BAR_READ → action:foo-bar:read
  const m = raw.match(/^(.*)_(READ|WRITE|CREATE|UPDATE|DELETE|RUN)$/);
  if (m && /^[A-Z0-9_]+$/.test(raw)) {
    const base = m[1].toLowerCase().replace(/_/g, "-");
    const verb = m[2].toLowerCase();
    return `action:${base}:${verb}`;
  }

  return raw;
}
