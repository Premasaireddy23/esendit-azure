import { createParamDecorator, ExecutionContext } from "@nestjs/common";

function headerValue(raw: any) {
  const value = Array.isArray(raw) ? raw[0] : raw;
  return String(value ?? "").trim();
}

export type AuthUser = {
  id: string;
  userId?: string;
  accountId: string;
  email: string;
  displayName?: string;
  userType?: string;
  roleNames?: string[];
  permissions: string[];
  /**
   * Optional receiver account context selected from the UI. Empty means the
   * existing behaviour: show all receiver accounts this login can access.
   */
  activeReceiverAccountId?: string | null;
  supportView?: {
    active: boolean;
    impersonatedByUserId?: string | null;
    impersonatedByEmail?: string | null;
    reason?: string | null;
    ticket?: string | null;
    startedAt?: string | null;
  } | null;
};

export const CurrentUser = createParamDecorator((_data, ctx: ExecutionContext) => {
  const req = ctx.switchToHttp().getRequest();
  const activeReceiverAccountId = headerValue(
    req.headers?.["x-active-receiver-account-id"] ?? req.headers?.["X-Active-Receiver-Account-Id"],
  );
  return {
    ...(req.user || {}),
    activeReceiverAccountId: activeReceiverAccountId || null,
  } as AuthUser;
});
