import { PROJECT_STAKEHOLDER_ACTIONS, PROJECT_STAKEHOLDER_TYPES, stakeholderPermissionKey } from "./stakeholder-permission-matrix";

// IMPORTANT: Keep Permission.key EXACTLY as in @RequirePermissions("...")

export const PERM = {
  // Masters (generic)
  MASTERS_READ: "MASTERS_READ",
  MASTERS_CREATE: "MASTERS_CREATE",
  MASTERS_UPDATE: "MASTERS_UPDATE",
  MASTERS_DELETE: "MASTERS_DELETE",

  // Masters (accounts granular)
  PAGE_MASTERS_ACCOUNTS: "page:masters:accounts",
  ACTION_MASTERS_ACCOUNTS_CREATE: "action:masters:accounts:create",
  ACTION_MASTERS_ACCOUNTS_UPDATE: "action:masters:accounts:update",
  ACTION_MASTERS_ACCOUNTS_DELETE: "action:masters:accounts:delete",

  // Masters (destinations granular)
  PAGE_MASTERS_DESTINATIONS: "page:masters:destinations",
  ACTION_MASTERS_DESTINATIONS_CREATE: "action:masters:destinations:create",
  ACTION_MASTERS_DESTINATIONS_UPDATE: "action:masters:destinations:update",
  ACTION_MASTERS_DESTINATIONS_DELETE: "action:masters:destinations:delete",

  // Masters / Billing section pages
  PAGE_MASTERS: "page:masters",
  PAGE_AGENCIES: "page:agencies",
  PAGE_DELIVERY: "page:delivery",
  PAGE_BILLING: "page:billing",

  // Masters (granular pages + actions)
  PAGE_MASTERS_ADVERTISER_GROUPS: "page:masters:advertiser-groups",
  ACTION_MASTERS_ADVERTISER_GROUPS_CREATE: "action:masters:advertiser-groups:create",
  ACTION_MASTERS_ADVERTISER_GROUPS_UPDATE: "action:masters:advertiser-groups:update",
  ACTION_MASTERS_ADVERTISER_GROUPS_DELETE: "action:masters:advertiser-groups:delete",

  PAGE_MASTERS_ADVERTISERS: "page:masters:advertisers",
  ACTION_MASTERS_ADVERTISERS_CREATE: "action:masters:advertisers:create",
  ACTION_MASTERS_ADVERTISERS_UPDATE: "action:masters:advertisers:update",
  ACTION_MASTERS_ADVERTISERS_DELETE: "action:masters:advertisers:delete",

  PAGE_MASTERS_BRANDS: "page:masters:brands",
  ACTION_MASTERS_BRANDS_CREATE: "action:masters:brands:create",
  ACTION_MASTERS_BRANDS_UPDATE: "action:masters:brands:update",
  ACTION_MASTERS_BRANDS_DELETE: "action:masters:brands:delete",

  PAGE_MASTERS_PRODUCT_CATEGORIES: "page:masters:product-categories",
  ACTION_MASTERS_PRODUCT_CATEGORIES_CREATE: "action:masters:product-categories:create",
  ACTION_MASTERS_PRODUCT_CATEGORIES_UPDATE: "action:masters:product-categories:update",
  ACTION_MASTERS_PRODUCT_CATEGORIES_DELETE: "action:masters:product-categories:delete",

  PAGE_MASTERS_AGENCIES: "page:masters:agencies",
  ACTION_MASTERS_AGENCIES_CREATE: "action:masters:agencies:create",
  ACTION_MASTERS_AGENCIES_UPDATE: "action:masters:agencies:update",
  ACTION_MASTERS_AGENCIES_DELETE: "action:masters:agencies:delete",

  PAGE_MASTERS_AGENCY_TEAMS: "page:masters:agency-teams",
  ACTION_MASTERS_AGENCY_TEAMS_CREATE: "action:masters:agency-teams:create",
  ACTION_MASTERS_AGENCY_TEAMS_UPDATE: "action:masters:agency-teams:update",
  ACTION_MASTERS_AGENCY_TEAMS_DELETE: "action:masters:agency-teams:delete",

  PAGE_MASTERS_SLAS: "page:masters:slas",
  ACTION_MASTERS_SLAS_CREATE: "action:masters:slas:create",
  ACTION_MASTERS_SLAS_UPDATE: "action:masters:slas:update",
  ACTION_MASTERS_SLAS_DELETE: "action:masters:slas:delete",

  PAGE_MASTERS_HOT_FOLDERS: "page:masters:hot-folders",
  ACTION_MASTERS_HOT_FOLDERS_CREATE: "action:masters:hot-folders:create",
  ACTION_MASTERS_HOT_FOLDERS_UPDATE: "action:masters:hot-folders:update",
  ACTION_MASTERS_HOT_FOLDERS_DELETE: "action:masters:hot-folders:delete",

  PAGE_MASTERS_DELIVERY_SETUP: "page:masters:delivery-setup",
  PAGE_MASTERS_DELIVERY_PROFILES: "page:masters:delivery-profiles",
  ACTION_MASTERS_DELIVERY_PROFILES_CREATE: "action:masters:delivery-profiles:create",
  ACTION_MASTERS_DELIVERY_PROFILES_UPDATE: "action:masters:delivery-profiles:update",
  ACTION_MASTERS_DELIVERY_PROFILES_DELETE: "action:masters:delivery-profiles:delete",

  PAGE_MASTERS_CHANNELS: "page:masters:channels",
  ACTION_MASTERS_CHANNELS_CREATE: "action:masters:channels:create",
  ACTION_MASTERS_CHANNELS_UPDATE: "action:masters:channels:update",
  ACTION_MASTERS_CHANNELS_DELETE: "action:masters:channels:delete",

  // Billing (granular pages + actions)
  PAGE_BILLING_BILLABLE_PARTIES: "page:billing:billable-parties",
  ACTION_BILLING_BILLABLE_PARTIES_CREATE: "action:billing:billable-parties:create",
  ACTION_BILLING_BILLABLE_PARTIES_UPDATE: "action:billing:billable-parties:update",
  ACTION_BILLING_BILLABLE_PARTIES_DELETE: "action:billing:billable-parties:delete",

  PAGE_BILLING_RATE_CARDS: "page:billing:rate-cards",
  ACTION_BILLING_RATE_CARDS_CREATE: "action:billing:rate-cards:create",
  ACTION_BILLING_RATE_CARDS_UPDATE: "action:billing:rate-cards:update",
  ACTION_BILLING_RATE_CARDS_DELETE: "action:billing:rate-cards:delete",

  PAGE_BILLING_CHARGES: "page:billing:charges",
  PAGE_BILLING_INVOICES: "page:billing:invoices",

  // Billing
  BILLING_READ: "BILLING_READ",
  BILLING_CREATE: "BILLING_CREATE",
  BILLING_UPDATE: "BILLING_UPDATE",
  BILLING_DELETE: "BILLING_DELETE",

  // Projects
  PROJECT_WIZARD_CREATE: "PROJECT_WIZARD_CREATE",
  PROJECT_CREATE: "PROJECT_CREATE",
  PROJECT_READ: "PROJECT_READ",
  PAGE_PROJECTS: "page:projects",
  ACTION_PROJECTS_SCOPED_READ: "action:projects:scoped:read",
  ACTION_PROJECTS_CREATIVES_UPLOAD_SCOPED: "action:projects:creatives:upload:scoped",
  ACTION_PROJECTS_PLANNER_EDIT_SCOPED: "action:projects:planner:edit:scoped",

  // Inline master creation from Project wizard
  PROJECT_MASTER_ADD_ADVERTISER_GROUP: "PROJECT_MASTER_ADD_ADVERTISER_GROUP",
  PROJECT_MASTER_ADD_ADVERTISER: "PROJECT_MASTER_ADD_ADVERTISER",
  PROJECT_MASTER_ADD_BRAND: "PROJECT_MASTER_ADD_BRAND",
  PROJECT_MASTER_ADD_PRODUCT_CATEGORY: "PROJECT_MASTER_ADD_PRODUCT_CATEGORY",
  PROJECT_MASTER_ADD_AGENCY: "PROJECT_MASTER_ADD_AGENCY",
  PROJECT_MASTER_ADD_AGENCY_TEAM: "PROJECT_MASTER_ADD_AGENCY_TEAM",
  COMMIT_RUN: "COMMIT_RUN",
  PROJECT_CLOSE: "PROJECT_CLOSE",
  PROJECT_REOPEN: "PROJECT_REOPEN",

  // Orders
  ORDER_SEND: "ORDER_SEND",

  // Account tracking (sidebar Tracking page)
  ACTION_TRACKING_READ: "action:tracking:read",
  ACTION_TRACKING_READ_SCOPED: "action:tracking:read:scoped",

  // Media download
  ACTION_MEDIA_DOWNLOAD: "action:media:download",

  // Planner
  PAGE_PLANNER: "Page_Planner",
  ACTION_PLANNER_EDIT: "action:planner:edit",

  // Approvals
  APPROVALS_TEMPLATES_MANAGE: "APPROVALS_TEMPLATES_MANAGE",
  APPROVALS_CONFIG_WRITE: "APPROVALS_CONFIG_WRITE",
  APPROVALS_DECIDE: "approvals.decide",
  APPROVALS_DECIDE_SCOPED: "approvals.decide.scoped",
  APPROVALS_RESET: "approvals.reset",
  APPROVAL_TRACKER_READ: "APPROVAL_TRACKER_READ",

  // Admin
  ADMIN_USERS_READ: "ADMIN_USERS_READ",
  ADMIN_USERS_WRITE: "ADMIN_USERS_WRITE",
  ADMIN_ROLES_READ: "ADMIN_ROLES_READ",
  ADMIN_ROLES_WRITE: "ADMIN_ROLES_WRITE",
  ADMIN_GROUPS_READ: "ADMIN_GROUPS_READ",
  ADMIN_GROUPS_WRITE: "ADMIN_GROUPS_WRITE",
  ADMIN_SUPPORT_VIEW: "action:admin:support-view",

  // Account settings
  ACCOUNT_SETTINGS_READ: "ACCOUNT_SETTINGS_READ",
  ACCOUNT_SETTINGS_WRITE: "ACCOUNT_SETTINGS_WRITE",

  
  // -------------------------
  // P2: Notifications
  ACTION_NOTIFICATIONS_READ: "NOTIFICATIONS_READ",
  ACTION_NOTIFICATIONS_RETRIGGER: "NOTIFICATIONS_RETRIGGER",


  // -------------------------
  // P2: DAM / Presets / Bulk
  // -------------------------

  // Library / DAM
  PAGE_LIBRARY: "page:library",
  ACTION_LIBRARY_READ: "action:library:read",
  ACTION_LIBRARY_READ_SCOPED: "action:library:read:scoped",
  ACTION_LIBRARY_INDEX: "action:library:index",
  ACTION_LIBRARY_STREAM: "action:library:stream",
  ACTION_LIBRARY_STREAM_SCOPED: "action:library:stream:scoped",

  // Legacy aliases kept in registry for backward compatibility
  PAGE_DAM: "page:dam",
  ACTION_DAM_READ: "action:dam:read",
  ACTION_DAM_INDEX: "action:dam:index",
  ACTION_DAM_STREAM: "action:dam:stream",

  // Presets
  ACTION_PRESETS_REQUEST: "action:presets:request",
  ACTION_PRESETS_DOWNLOAD: "action:presets:download",

  // Bulk
  PAGE_BULK: "page:bulk",
  ACTION_BULK_READ: "action:bulk:read",
  ACTION_BULK_CREATE: "action:bulk:create",
  ACTION_BULK_IMPORT: "action:bulk:import",
  ACTION_BULK_UPLOAD: "action:bulk:upload",
  ACTION_BULK_PROCESS: "action:bulk:process",
  ACTION_BULK_STREAM: "action:bulk:stream",


  // server status
  SERVER_STATUS_READ: "SERVER_STATUS_READ",
  SERVER_STATUS_RUN: "SERVER_STATUS_RUN",

} as const;


const STAKEHOLDER_PERMISSION_ROWS = PROJECT_STAKEHOLDER_TYPES.flatMap((stakeholder) =>
  PROJECT_STAKEHOLDER_ACTIONS.map((item) => ({
    key: stakeholderPermissionKey(stakeholder.type, item.action),
    name: `Stakeholder - ${stakeholder.label} - ${item.label}`,
    type: "PROJECTS",
  })),
);

/**
 * NOTE: Permission.type must match YOUR Prisma enum PermissionType values.
 * If your enum doesn't have these categories, either:
 *  - change the type strings below to valid enum values, OR
 *  - temporarily set all to ONE valid enum value.
 */
export const PERMISSIONS = [
  { key: PERM.MASTERS_READ, name: "Masters - Read", type: "MASTERS" },
  { key: PERM.MASTERS_CREATE, name: "Masters - Create", type: "MASTERS" },
  { key: PERM.MASTERS_UPDATE, name: "Masters - Update", type: "MASTERS" },
  { key: PERM.MASTERS_DELETE, name: "Masters - Delete", type: "MASTERS" },

  { key: PERM.PAGE_MASTERS_ACCOUNTS, name: "Masters - Accounts Page", type: "MASTERS" },
  { key: PERM.ACTION_MASTERS_ACCOUNTS_CREATE, name: "Masters - Accounts Create", type: "MASTERS" },
  { key: PERM.ACTION_MASTERS_ACCOUNTS_UPDATE, name: "Masters - Accounts Update", type: "MASTERS" },
  { key: PERM.ACTION_MASTERS_ACCOUNTS_DELETE, name: "Masters - Accounts Delete", type: "MASTERS" },

  { key: PERM.PAGE_MASTERS_DESTINATIONS, name: "Masters - Destinations Page", type: "MASTERS" },
  { key: PERM.ACTION_MASTERS_DESTINATIONS_CREATE, name: "Masters - Destinations Create", type: "MASTERS" },
  { key: PERM.ACTION_MASTERS_DESTINATIONS_UPDATE, name: "Masters - Destinations Update", type: "MASTERS" },
  { key: PERM.ACTION_MASTERS_DESTINATIONS_DELETE, name: "Masters - Destinations Delete", type: "MASTERS" },

  { key: PERM.PAGE_MASTERS, name: "Masters - Section", type: "MASTERS" },
  { key: PERM.PAGE_AGENCIES, name: "Agencies - Section", type: "MASTERS" },
  { key: PERM.PAGE_DELIVERY, name: "Delivery - Section", type: "MASTERS" },
  { key: PERM.PAGE_BILLING, name: "Billing - Section", type: "BILLING" },

  { key: PERM.PAGE_MASTERS_ADVERTISER_GROUPS, name: "Masters - Advertiser Groups Page", type: "MASTERS" },
  { key: PERM.ACTION_MASTERS_ADVERTISER_GROUPS_CREATE, name: "Masters - Advertiser Groups Create", type: "MASTERS" },
  { key: PERM.ACTION_MASTERS_ADVERTISER_GROUPS_UPDATE, name: "Masters - Advertiser Groups Update", type: "MASTERS" },
  { key: PERM.ACTION_MASTERS_ADVERTISER_GROUPS_DELETE, name: "Masters - Advertiser Groups Delete", type: "MASTERS" },

  { key: PERM.PAGE_MASTERS_ADVERTISERS, name: "Masters - Advertisers Page", type: "MASTERS" },
  { key: PERM.ACTION_MASTERS_ADVERTISERS_CREATE, name: "Masters - Advertisers Create", type: "MASTERS" },
  { key: PERM.ACTION_MASTERS_ADVERTISERS_UPDATE, name: "Masters - Advertisers Update", type: "MASTERS" },
  { key: PERM.ACTION_MASTERS_ADVERTISERS_DELETE, name: "Masters - Advertisers Delete", type: "MASTERS" },

  { key: PERM.PAGE_MASTERS_BRANDS, name: "Masters - Brands Page", type: "MASTERS" },
  { key: PERM.ACTION_MASTERS_BRANDS_CREATE, name: "Masters - Brands Create", type: "MASTERS" },
  { key: PERM.ACTION_MASTERS_BRANDS_UPDATE, name: "Masters - Brands Update", type: "MASTERS" },
  { key: PERM.ACTION_MASTERS_BRANDS_DELETE, name: "Masters - Brands Delete", type: "MASTERS" },

  { key: PERM.PAGE_MASTERS_PRODUCT_CATEGORIES, name: "Masters - Product Categories Page", type: "MASTERS" },
  { key: PERM.ACTION_MASTERS_PRODUCT_CATEGORIES_CREATE, name: "Masters - Product Categories Create", type: "MASTERS" },
  { key: PERM.ACTION_MASTERS_PRODUCT_CATEGORIES_UPDATE, name: "Masters - Product Categories Update", type: "MASTERS" },
  { key: PERM.ACTION_MASTERS_PRODUCT_CATEGORIES_DELETE, name: "Masters - Product Categories Delete", type: "MASTERS" },

  { key: PERM.PAGE_MASTERS_AGENCIES, name: "Masters - Agencies Page", type: "MASTERS" },
  { key: PERM.ACTION_MASTERS_AGENCIES_CREATE, name: "Masters - Agencies Create", type: "MASTERS" },
  { key: PERM.ACTION_MASTERS_AGENCIES_UPDATE, name: "Masters - Agencies Update", type: "MASTERS" },
  { key: PERM.ACTION_MASTERS_AGENCIES_DELETE, name: "Masters - Agencies Delete", type: "MASTERS" },

  { key: PERM.PAGE_MASTERS_AGENCY_TEAMS, name: "Masters - Agency Teams Page", type: "MASTERS" },
  { key: PERM.ACTION_MASTERS_AGENCY_TEAMS_CREATE, name: "Masters - Agency Teams Create", type: "MASTERS" },
  { key: PERM.ACTION_MASTERS_AGENCY_TEAMS_UPDATE, name: "Masters - Agency Teams Update", type: "MASTERS" },
  { key: PERM.ACTION_MASTERS_AGENCY_TEAMS_DELETE, name: "Masters - Agency Teams Delete", type: "MASTERS" },

  { key: PERM.PAGE_MASTERS_SLAS, name: "Masters - SLAs Page", type: "MASTERS" },
  { key: PERM.ACTION_MASTERS_SLAS_CREATE, name: "Masters - SLAs Create", type: "MASTERS" },
  { key: PERM.ACTION_MASTERS_SLAS_UPDATE, name: "Masters - SLAs Update", type: "MASTERS" },
  { key: PERM.ACTION_MASTERS_SLAS_DELETE, name: "Masters - SLAs Delete", type: "MASTERS" },

  { key: PERM.PAGE_MASTERS_HOT_FOLDERS, name: "Masters - Hot Folders Page", type: "MASTERS" },
  { key: PERM.ACTION_MASTERS_HOT_FOLDERS_CREATE, name: "Masters - Hot Folders Create", type: "MASTERS" },
  { key: PERM.ACTION_MASTERS_HOT_FOLDERS_UPDATE, name: "Masters - Hot Folders Update", type: "MASTERS" },
  { key: PERM.ACTION_MASTERS_HOT_FOLDERS_DELETE, name: "Masters - Hot Folders Delete", type: "MASTERS" },

  { key: PERM.PAGE_MASTERS_DELIVERY_SETUP, name: "Masters - Delivery Setup Page", type: "MASTERS" },
  { key: PERM.PAGE_MASTERS_DELIVERY_PROFILES, name: "Masters - Delivery Profiles Page", type: "MASTERS" },
  { key: PERM.ACTION_MASTERS_DELIVERY_PROFILES_CREATE, name: "Masters - Delivery Profiles Create", type: "MASTERS" },
  { key: PERM.ACTION_MASTERS_DELIVERY_PROFILES_UPDATE, name: "Masters - Delivery Profiles Update", type: "MASTERS" },
  { key: PERM.ACTION_MASTERS_DELIVERY_PROFILES_DELETE, name: "Masters - Delivery Profiles Delete", type: "MASTERS" },

  { key: PERM.PAGE_MASTERS_CHANNELS, name: "Masters - Channels Page", type: "MASTERS" },
  { key: PERM.ACTION_MASTERS_CHANNELS_CREATE, name: "Masters - Channels Create", type: "MASTERS" },
  { key: PERM.ACTION_MASTERS_CHANNELS_UPDATE, name: "Masters - Channels Update", type: "MASTERS" },
  { key: PERM.ACTION_MASTERS_CHANNELS_DELETE, name: "Masters - Channels Delete", type: "MASTERS" },

  { key: PERM.PAGE_BILLING_BILLABLE_PARTIES, name: "Billing - Billable Parties Page", type: "BILLING" },
  { key: PERM.ACTION_BILLING_BILLABLE_PARTIES_CREATE, name: "Billing - Billable Parties Create", type: "BILLING" },
  { key: PERM.ACTION_BILLING_BILLABLE_PARTIES_UPDATE, name: "Billing - Billable Parties Update", type: "BILLING" },
  { key: PERM.ACTION_BILLING_BILLABLE_PARTIES_DELETE, name: "Billing - Billable Parties Delete", type: "BILLING" },

  { key: PERM.PAGE_BILLING_RATE_CARDS, name: "Billing - Rate Cards Page", type: "BILLING" },
  { key: PERM.ACTION_BILLING_RATE_CARDS_CREATE, name: "Billing - Rate Cards Create", type: "BILLING" },
  { key: PERM.ACTION_BILLING_RATE_CARDS_UPDATE, name: "Billing - Rate Cards Update", type: "BILLING" },
  { key: PERM.ACTION_BILLING_RATE_CARDS_DELETE, name: "Billing - Rate Cards Delete", type: "BILLING" },

  { key: PERM.PAGE_BILLING_CHARGES, name: "Billing - Charges Page", type: "BILLING" },
  { key: PERM.PAGE_BILLING_INVOICES, name: "Billing - Invoices Page", type: "BILLING" },

  { key: PERM.BILLING_READ, name: "Billing - Read", type: "BILLING" },
  { key: PERM.BILLING_CREATE, name: "Billing - Create", type: "BILLING" },
  { key: PERM.BILLING_UPDATE, name: "Billing - Update", type: "BILLING" },
  { key: PERM.BILLING_DELETE, name: "Billing - Delete", type: "BILLING" },

  { key: PERM.PROJECT_WIZARD_CREATE, name: "Project Wizard - Create", type: "PROJECTS" },
  { key: PERM.PROJECT_CREATE, name: "Projects - Create", type: "PROJECTS" },
  { key: PERM.PROJECT_READ, name: "Projects - Read", type: "PROJECTS" },
  { key: PERM.PAGE_PROJECTS, name: "Projects - Scoped Stakeholder Page", type: "PROJECTS" },
  { key: PERM.ACTION_PROJECTS_SCOPED_READ, name: "Projects - Scoped Stakeholder Read", type: "PROJECTS" },
  { key: PERM.ACTION_PROJECTS_CREATIVES_UPLOAD_SCOPED, name: "Projects - Scoped Creative Upload", type: "PROJECTS" },
  { key: PERM.ACTION_PROJECTS_PLANNER_EDIT_SCOPED, name: "Projects - Scoped Planner Edit", type: "PROJECTS" },
  ...STAKEHOLDER_PERMISSION_ROWS,

  { key: PERM.PROJECT_MASTER_ADD_ADVERTISER_GROUP, name: "Projects - Inline Add Advertiser Group", type: "PROJECTS" },
  { key: PERM.PROJECT_MASTER_ADD_ADVERTISER, name: "Projects - Inline Add Advertiser", type: "PROJECTS" },
  { key: PERM.PROJECT_MASTER_ADD_BRAND, name: "Projects - Inline Add Brand", type: "PROJECTS" },
  { key: PERM.PROJECT_MASTER_ADD_PRODUCT_CATEGORY, name: "Projects - Inline Add Product Category", type: "PROJECTS" },
  { key: PERM.PROJECT_MASTER_ADD_AGENCY, name: "Projects - Inline Add Agency", type: "PROJECTS" },
  { key: PERM.PROJECT_MASTER_ADD_AGENCY_TEAM, name: "Projects - Inline Add Agency Team", type: "PROJECTS" },

  { key: PERM.COMMIT_RUN, name: "Projects - Commit Run", type: "PROJECTS" },
  { key: PERM.PROJECT_CLOSE, name: "Projects - Close", type: "PROJECTS" },
  { key: PERM.PROJECT_REOPEN, name: "Projects - Reopen", type: "PROJECTS" },

  { key: PERM.ORDER_SEND, name: "Orders - Send", type: "ORDERS" },
  { key: PERM.ACTION_TRACKING_READ, name: "Tracking - Read", type: "ORDERS" },
  { key: PERM.ACTION_TRACKING_READ_SCOPED, name: "Tracking - Scoped Stakeholder Read", type: "ORDERS" },
  { key: PERM.ACTION_MEDIA_DOWNLOAD, name: "Media - Download", type: "ORDERS" },

  { key: PERM.PAGE_PLANNER, name: "Planner - Page", type: "PLANNER" },
  { key: PERM.ACTION_PLANNER_EDIT, name: "Planner - Edit", type: "PLANNER" },

  { key: PERM.APPROVALS_TEMPLATES_MANAGE, name: "Approvals - Templates Manage", type: "APPROVALS" },
  { key: PERM.APPROVALS_CONFIG_WRITE, name: "Approvals - Config Write", type: "APPROVALS" },
  { key: PERM.APPROVALS_DECIDE, name: "Approvals - Decide", type: "APPROVALS" },
  { key: PERM.APPROVALS_DECIDE_SCOPED, name: "Approvals - Scoped Decide", type: "APPROVALS" },
  { key: PERM.APPROVALS_RESET, name: "Approvals - Reset", type: "APPROVALS" },
  { key: PERM.APPROVAL_TRACKER_READ, name: "Approvals - Tracker Read", type: "APPROVALS" },

  { key: PERM.ADMIN_USERS_READ, name: "Admin - Users Read", type: "ADMIN" },
  { key: PERM.ADMIN_USERS_WRITE, name: "Admin - Users Write", type: "ADMIN" },
  { key: PERM.ADMIN_ROLES_READ, name: "Admin - Roles Read", type: "ADMIN" },
  { key: PERM.ADMIN_ROLES_WRITE, name: "Admin - Roles Write", type: "ADMIN" },
  { key: PERM.ADMIN_GROUPS_READ, name: "Admin - Groups Read", type: "ADMIN" },
  { key: PERM.ADMIN_GROUPS_WRITE, name: "Admin - Groups Write", type: "ADMIN" },
  { key: PERM.ADMIN_SUPPORT_VIEW, name: "Admin - Support View Client Account", type: "ADMIN" },

  { key: PERM.ACCOUNT_SETTINGS_READ, name: "Account Settings - Read", type: "ADMIN" },
  { key: PERM.ACCOUNT_SETTINGS_WRITE, name: "Account Settings - Write", type: "ADMIN" },

// -------------------------
  // P2: Notifications

  { key: PERM.ACTION_NOTIFICATIONS_READ, name: "Notifications - Roles Read", type: "NOTIFICATIONS" },
  { key: PERM.ACTION_NOTIFICATIONS_RETRIGGER, name: "Notifications - Roles Retriggger", type: "NOTIFICATIONS" },


  // -------------------------
  // P2: DAM / legacy Library keys
  // -------------------------
  { key: PERM.PAGE_LIBRARY, name: "DAM - Page", type: "DAM" },
  { key: PERM.ACTION_LIBRARY_READ, name: "DAM - Read/Search", type: "DAM" },
  { key: PERM.ACTION_LIBRARY_INDEX, name: "DAM - Index", type: "DAM" },
  { key: PERM.ACTION_LIBRARY_STREAM, name: "DAM - Stream", type: "DAM" },

  // -------------------------
  // P2: Presets
  // -------------------------
  { key: PERM.ACTION_PRESETS_REQUEST, name: "Presets - Request", type: "PRESETS" },
  { key: PERM.ACTION_PRESETS_DOWNLOAD, name: "Presets - Download", type: "PRESETS" },

  // -------------------------
  // P2: Bulk Upload
  // -------------------------
  { key: PERM.PAGE_BULK, name: "Bulk - Page", type: "BULK" },
  { key: PERM.ACTION_BULK_READ, name: "Bulk - Read", type: "BULK" },
  { key: PERM.ACTION_BULK_CREATE, name: "Bulk - Create", type: "BULK" },
  { key: PERM.ACTION_BULK_IMPORT, name: "Bulk - Import", type: "BULK" },
  { key: PERM.ACTION_BULK_UPLOAD, name: "Bulk - Upload", type: "BULK" },
  { key: PERM.ACTION_BULK_PROCESS, name: "Bulk - Process (QC/Proxy)", type: "BULK" },
  { key: PERM.ACTION_BULK_STREAM, name: "Bulk - Stream", type: "BULK" },

  { key: PERM.SERVER_STATUS_READ, name: "Server Status - Read", type: "ADMIN" },
  { key: PERM.SERVER_STATUS_RUN, name: "Server Status - Run", type: "ADMIN" },

] as const;
