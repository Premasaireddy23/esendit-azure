import { PrismaService } from "../prisma/prisma.service";

export const STAKEHOLDER_SCOPED_PERMISSION_KEYS = [
  "page:projects",
  "action:projects:scoped:read",
  "action:tracking:read:scoped",
  "action:library:read:scoped",
  "action:library:stream:scoped",
  "action:projects:creatives:upload:scoped",
  "action:projects:planner:edit:scoped",
  "approvals.decide.scoped",
];

function normalizeEmail(raw?: string | null) {
  return String(raw ?? "").trim().toLowerCase();
}

function hasEmail(emails: any, email: string) {
  if (!email || !Array.isArray(emails)) return false;
  return emails.some((item) => normalizeEmail(item) === email);
}

async function safeFindMany(prisma: PrismaService, modelName: string, args: any) {
  try {
    const model = (prisma as any)[modelName];
    if (!model?.findMany) return [];
    return await model.findMany(args);
  } catch {
    return [];
  }
}

export async function inferStakeholderScopedPermissionKeys(prisma: PrismaService, user: any): Promise<string[]> {
  const email = normalizeEmail(user?.email);
  const accountId = String(user?.accountId || "").trim();
  const userType = String(user?.userType || "").toUpperCase();
  if (!accountId || !email) return [];

  if (userType === "THIRD_PARTY") return [...STAKEHOLDER_SCOPED_PERMISSION_KEYS];

  const checks = await Promise.all([
    safeFindMany(prisma, "partnerAccount", { where: { accountId }, select: { emails: true } }),
    safeFindMany(prisma, "agency", { where: { accountId }, select: { emails: true } }),
    safeFindMany(prisma, "agencyTeam", { where: { accountId }, select: { emails: true } }),
    safeFindMany(prisma, "advertiserGroup", { where: { accountId }, select: { emails: true } }),
    safeFindMany(prisma, "advertiser", { where: { accountId }, select: { emails: true } }),
    safeFindMany(prisma, "brand", { where: { accountId }, select: { emails: true } }),
    safeFindMany(prisma, "billableParty", { where: { accountId }, select: { emails: true } }),
  ]);

  const matched = checks.some((rows) => (rows || []).some((row: any) => hasEmail(row?.emails, email)));
  return matched ? [...STAKEHOLDER_SCOPED_PERMISSION_KEYS] : [];
}
