import * as bcrypt from "bcryptjs";
import { MasterStatus, UserType } from "@prisma/client";

// NOTE:
// Keep this helper additive and conservative.
// - only ACTIVE partner accounts are eligible
// - only first valid email is used
// - existing users for accountId + email are left unchanged
// - no roles are auto-assigned

function pick(...vals: Array<string | undefined | null>) {
  for (const v of vals) {
    if (v !== undefined && v !== null && String(v).trim() !== "") return String(v);
  }
  return undefined;
}

export function normalizeAutoUserEmail(raw?: string | null) {
  const email = String(raw ?? "").trim().toLowerCase();
  return email.includes("@") ? email : "";
}

export function firstValidPartnerAccountEmail(emails?: string[] | null) {
  if (!Array.isArray(emails)) return "";
  for (const raw of emails) {
    const email = normalizeAutoUserEmail(raw);
    if (email) return email;
  }
  return "";
}

export function partnerAccountAutoUserPassword() {
  return (
    pick(
      process.env.PARTNER_ACCOUNT_DEFAULT_PASSWORD,
      process.env.AUTO_USER_DEFAULT_PASSWORD,
      "ChangeMe@123",
    ) || "ChangeMe@123"
  );
}

export async function ensurePartnerAccountPeopleUser(
  prisma: any,
  partnerAccount: {
    id: string;
    accountId: string;
    name?: string | null;
    emails?: string[] | null;
    status?: MasterStatus | string | null;
  },
) {
  if (!partnerAccount || String(partnerAccount.status || "") !== String(MasterStatus.ACTIVE)) {
    return { ok: true, created: false, skippedReason: "inactive" as const };
  }

  const email = firstValidPartnerAccountEmail(partnerAccount.emails);
  if (!email) {
    return { ok: true, created: false, skippedReason: "missing_email" as const };
  }

  const existing = await prisma.user.findFirst({
    where: { accountId: partnerAccount.accountId, email },
    select: { id: true, email: true },
  });

  if (existing) {
    return { ok: true, created: false, existingUserId: existing.id, email, skippedReason: "exists" as const };
  }

  const passwordHash = await bcrypt.hash(partnerAccountAutoUserPassword(), 10);
  const displayName = email.split("@")[0] || partnerAccount.name || email;

  const created = await prisma.user.create({
    data: {
      account: { connect: { id: partnerAccount.accountId } },
      email,
      displayName,
      passwordHash,
      isActive: true,
      userType: UserType.THIRD_PARTY,
    },
    select: { id: true, email: true, displayName: true, isActive: true },
  });

  return { ok: true, created: true, user: created, email };
}

export async function syncMissingPeopleFromPartnerAccounts(prisma: any, accountId: string) {
  const partnerAccounts = await prisma.partnerAccount.findMany({
    where: { accountId, status: MasterStatus.ACTIVE },
    select: { id: true, accountId: true, name: true, emails: true, status: true },
    orderBy: { name: "asc" },
  });

  let createdCount = 0;
  let existingCount = 0;
  let skippedCount = 0;

  for (const row of partnerAccounts) {
    const result = await ensurePartnerAccountPeopleUser(prisma, row);
    if (result.created) createdCount += 1;
    else if ((result as any).skippedReason === "exists") existingCount += 1;
    else skippedCount += 1;
  }

  return {
    ok: true,
    scannedCount: partnerAccounts.length,
    createdCount,
    existingCount,
    skippedCount,
  };
}
