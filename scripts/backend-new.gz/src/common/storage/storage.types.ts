import { Readable } from "node:stream";

export type WriteSasResult = { url: string; headers: Record<string, string> };

export type StoragePutInput = Buffer | Uint8Array | Readable;

export interface StorageService {
  /** True if the backing store is a remote object store (Azure Blob). */
  isCloud(): boolean;

  /**
   * Upload a buffer/stream to an object key.
   * - For cloud storage, `key` is a blob key.
   * - For local storage, `key` is a filesystem path.
   */
  putObject(key: string, data: StoragePutInput, contentType?: string): Promise<void>;

  /** Upload a local file to an object key. */
  uploadFile(key: string, localPath: string, contentType?: string): Promise<void>;

  /** Download an object key to a local file path. */
  downloadToFile(key: string, localPath: string): Promise<void>;

  /** Whether an object exists. */
  exists(key: string): Promise<boolean>;

  /** Delete all objects under a prefix. */
  deletePrefix(prefix: string): Promise<{ deleted: number }>;

  /** Cloud-only: Create a read URL (SAS) for a key. */
  getSignedReadUrl(
    key: string,
    ttlMinutes: number,
    opts?: { contentType?: string; contentDisposition?: string },
  ): Promise<string>;

  /** Cloud-only: Create a write URL (SAS) for a key. */
  getSignedWriteUrl(key: string, ttlMinutes: number, opts?: { contentType?: string }): Promise<WriteSasResult>;
}
