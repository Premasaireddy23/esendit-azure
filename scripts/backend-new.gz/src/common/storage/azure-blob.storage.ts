import { Injectable } from "@nestjs/common";
import { Readable } from "node:stream";
import { AzureBlobService } from "./azure-blob.service";
import { StorageService, type StoragePutInput, type WriteSasResult } from "./storage.types";

@Injectable()
export class AzureBlobStorageService implements StorageService {
  constructor(private blobs: AzureBlobService) {}

  isCloud(): boolean {
    return this.blobs.isConfigured();
  }

  async putObject(key: string, data: StoragePutInput, contentType?: string): Promise<void> {
    if (data instanceof Readable) {
      // For now we buffer streams (most uploads are buffers); keep simple.
      const bufs: Buffer[] = [];
      for await (const c of data) bufs.push(Buffer.from(c as any));
      await this.blobs.uploadBuffer(key, Buffer.concat(bufs), contentType);
      return;
    }

    const buf = Buffer.isBuffer(data) ? data : Buffer.from(data as any);
    await this.blobs.uploadBuffer(key, buf, contentType);
  }

  async uploadFile(key: string, localPath: string, contentType?: string): Promise<void> {
    await this.blobs.uploadFile(key, localPath, contentType);
  }

  async downloadToFile(key: string, localPath: string): Promise<void> {
    await this.blobs.downloadToFile(key, localPath);
  }

  async exists(key: string): Promise<boolean> {
    return this.blobs.exists(key);
  }

  async deletePrefix(prefix: string): Promise<{ deleted: number }> {
    return this.blobs.deletePrefix(prefix);
  }

  async getSignedReadUrl(key: string, ttlMinutes: number, opts?: { contentType?: string; contentDisposition?: string }): Promise<string> {
    return this.blobs.createReadSasUrl(key, opts?.contentType, opts?.contentDisposition, ttlMinutes);
  }

  async getSignedWriteUrl(key: string, ttlMinutes: number, opts?: { contentType?: string }): Promise<WriteSasResult> {
    const r = await this.blobs.createWriteSasUrl(key, opts?.contentType, ttlMinutes);
    return { url: r.url, headers: r.headers };
  }
}
