import { Injectable } from "@nestjs/common";
import { Readable } from "node:stream";
import * as fs from "node:fs/promises";
import * as fssync from "node:fs";
import * as path from "node:path";
import { StorageService, type StoragePutInput, type WriteSasResult } from "./storage.types";

@Injectable()
export class LocalFsStorageService implements StorageService {
  isCloud(): boolean {
    return false;
  }

  async putObject(key: string, data: StoragePutInput, _contentType?: string): Promise<void> {
    await fs.mkdir(path.dirname(key), { recursive: true });

    if (data instanceof Readable) {
      await new Promise<void>((resolve, reject) => {
        const w = fssync.createWriteStream(key);
        w.on("error", reject);
        w.on("finish", () => resolve());
        data.on("error", reject);
        data.pipe(w);
      });
      return;
    }

    const buf = Buffer.isBuffer(data) ? data : Buffer.from(data as any);
    await fs.writeFile(key, buf);
  }

  async uploadFile(key: string, localPath: string): Promise<void> {
    await fs.mkdir(path.dirname(key), { recursive: true });
    await fs.copyFile(localPath, key);
  }

  async downloadToFile(key: string, localPath: string): Promise<void> {
    await fs.mkdir(path.dirname(localPath), { recursive: true });
    await fs.copyFile(key, localPath);
  }

  async exists(key: string): Promise<boolean> {
    try {
      await fs.stat(key);
      return true;
    } catch {
      return false;
    }
  }

  async deletePrefix(prefix: string): Promise<{ deleted: number }> {
    // Simple recursive delete.
    try {
      const st = await fs.stat(prefix);
      if (st.isFile()) {
        await fs.unlink(prefix);
        return { deleted: 1 };
      }
    } catch {
      return { deleted: 0 };
    }

    let deleted = 0;
    const walk = async (dir: string) => {
      const entries = await fs.readdir(dir, { withFileTypes: true });
      for (const e of entries) {
        const p = path.join(dir, e.name);
        if (e.isDirectory()) await walk(p);
        else {
          await fs.unlink(p).catch(() => undefined);
          deleted++;
        }
      }
    };

    await walk(prefix);
    await fs.rm(prefix, { recursive: true, force: true }).catch(() => undefined);
    return { deleted };
  }

  async getSignedReadUrl(): Promise<string> {
    throw new Error("getSignedReadUrl is not supported for local storage");
  }

  async getSignedWriteUrl(): Promise<WriteSasResult> {
    throw new Error("getSignedWriteUrl is not supported for local storage");
  }
}
