import { Module } from "@nestjs/common";
import { AzureBlobService } from "./azure-blob.service";
import { AzureBlobStorageService } from "./azure-blob.storage";
import { LocalFsStorageService } from "./local-fs.storage";
import { STORAGE } from "./storage.token";
import type { StorageService } from "./storage.types";

@Module({
  providers: [
    AzureBlobService,
    AzureBlobStorageService,
    LocalFsStorageService,
    {
      provide: STORAGE,
      inject: [AzureBlobStorageService, LocalFsStorageService],
      useFactory: (azure: AzureBlobStorageService, local: LocalFsStorageService): StorageService => {
        const driver = String(process.env.STORAGE_DRIVER || "").toLowerCase();

        // Explicit driver wins.
        if (driver === "azure") return azure;
        if (driver === "local") return local;

        // Auto: use Azure when configured, else local.
        return azure.isCloud() ? azure : local;
      },
    },
  ],
  exports: [AzureBlobService, STORAGE],
})
export class StorageModule {}
