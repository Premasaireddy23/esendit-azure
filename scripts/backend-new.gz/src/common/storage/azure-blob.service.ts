import { Injectable } from "@nestjs/common";
import {
  BlobServiceClient,
  BlobSASPermissions,
  SASProtocol,
  StorageSharedKeyCredential,
  generateBlobSASQueryParameters,
} from "@azure/storage-blob";
import { DefaultAzureCredential } from "@azure/identity";
import * as fs from "node:fs/promises";
import * as path from "node:path";

type SasOptions = {
  contentType?: string;
  contentDisposition?: string;
};

@Injectable()
export class AzureBlobService {
  readonly account: string;
  readonly containerName: string;

  private readonly client: BlobServiceClient;
  private readonly sharedKey?: StorageSharedKeyCredential;
  private _udkCache: { key: any; exp: number } | null = null;

  constructor() {
    const account = process.env.AZURE_STORAGE_ACCOUNT || "";
    if (!account) {
      // We allow construction even if not configured; callers can throw more helpful errors.
      // This is useful for local dev.
    }

    this.account = account;
    this.containerName = process.env.AZURE_STORAGE_CONTAINER || "esendit-media";

    const url = account ? `https://${account}.blob.core.windows.net` : "";
    const accountKey = process.env.AZURE_STORAGE_ACCOUNT_KEY || "";

    if (account && accountKey) {
      this.sharedKey = new StorageSharedKeyCredential(account, accountKey);
      this.client = new BlobServiceClient(url, this.sharedKey);
    } else if (account) {
      const cred = new DefaultAzureCredential();
      this.client = new BlobServiceClient(url, cred);
    } else {
      // dummy client; any call will fail with a clearer error
      this.client = new BlobServiceClient("https://invalid.blob.core.windows.net");
    }
  }

  /** True when the service has enough configuration to operate. */
  isConfigured(): boolean {
    return Boolean(this.account);
  }

  private ensureConfigured() {
    if (!this.account) {
      throw new Error("AZURE_STORAGE_ACCOUNT is not set");
    }
  }

  
  private splitKey(blobKey: string): { container: string; key: string } {
    const idx = String(blobKey || "").indexOf("::");
    if (idx > 0) {
      const container = String(blobKey).slice(0, idx).trim();
      const key = String(blobKey).slice(idx + 2);
      if (container && key) return { container, key };
    }
    return { container: this.containerName, key: String(blobKey || "") };
  }

  private containerClientFor(containerName: string) {
    this.ensureConfigured();
    const name = String(containerName || this.containerName || "").trim();
    if (!name) throw new Error("AZURE_STORAGE_CONTAINER is not set");
    return this.client.getContainerClient(name);
  }

  private containerClient() {
    return this.containerClientFor(this.containerName);
  }

  private blobClient(blobKey: string) {
    const { container, key } = this.splitKey(blobKey);
    return this.containerClientFor(container).getBlobClient(key);
  }


  async exists(blobKey: string): Promise<boolean> {
    try {
      await this.blobClient(blobKey).getProperties();
      return true;
    } catch (e: any) {
      const code = String(e?.details?.errorCode || e?.code || "");
      if (code === "BlobNotFound") return false;
      // Some SDK versions throw 404 status without errorCode
      if (e?.statusCode === 404) return false;
      throw e;
    }
  }

  async getSize(blobKey: string): Promise<number | null> {
    try {
      const p = await this.blobClient(blobKey).getProperties();
      return typeof p?.contentLength === "number" ? p.contentLength : null;
    } catch (e: any) {
      const code = String(e?.details?.errorCode || e?.code || "");
      if (code === "BlobNotFound" || e?.statusCode === 404) return null;
      throw e;
    }
  }

  async delete(blobKey: string): Promise<void> {
    try {
      await this.blobClient(blobKey).deleteIfExists();
    } catch {
      // ignore
    }
  }

  /**
   * Deletes all blobs under the given prefix.
   *
   * Notes:
   * - This is used for hard-delete semantics (DB delete should not happen if blob delete fails).
   * - If the prefix has no blobs, this is a no-op.
   */
  async deletePrefix(prefix: string): Promise<{ deleted: number }> {
    this.ensureConfigured();
    const { container, key: prefixKey } = this.splitKey(prefix);
    const cc = this.containerClientFor(container);
    let deleted = 0;
    const errors: Array<{ name: string; err: any }> = [];

    for await (const b of cc.listBlobsFlat({ prefix: prefixKey })) {
      const name = String(b?.name || "");
      if (!name) continue;
      try {
        await cc.getBlobClient(name).deleteIfExists();
        deleted++;
      } catch (err) {
        errors.push({ name, err });
      }
    }

    if (errors.length) {
      const ex = errors[0];
      const msg = String(ex?.err?.message || ex?.err || "unknown error");
      throw new Error(`Failed to delete blob(s) under prefix '${prefix}'. Example: ${ex.name}: ${msg}`);
    }

    return { deleted };
  }

  async downloadToFile(blobKey: string, localPath: string): Promise<void> {
    await fs.mkdir(path.dirname(localPath), { recursive: true });
    const bc = this.blobClient(blobKey);
    await bc.downloadToFile(localPath);
  }

  async uploadFile(blobKey: string, localPath: string, contentType?: string): Promise<void> {
    const { container, key } = this.splitKey(blobKey);
    const cc = this.containerClientFor(container);
    // Ensure container exists (no-op if it already exists)
    await cc.createIfNotExists();
    const bc = cc.getBlockBlobClient(key);
    await bc.uploadFile(localPath, {
      blobHTTPHeaders: contentType ? { blobContentType: contentType } : undefined,
    });
  }

  async uploadBuffer(blobKey: string, buffer: Buffer, contentType?: string): Promise<void> {
    const { container, key } = this.splitKey(blobKey);
    const cc = this.containerClientFor(container);
    await cc.createIfNotExists();
    const bc = cc.getBlockBlobClient(key);
    await bc.uploadData(buffer, {
      blobHTTPHeaders: contentType ? { blobContentType: contentType } : undefined,
    });
  }

  async listKeys(prefix: string): Promise<string[]> {
    const { container, key: prefixKey } = this.splitKey(prefix);
    const cc = this.containerClientFor(container);
    const out: string[] = [];
    for await (const b of cc.listBlobsFlat({ prefix: prefixKey })) {
      if (b?.name) out.push(b.name);
    }
    out.sort((a, b) => a.localeCompare(b, undefined, { numeric: true, sensitivity: "base" }));
    return out;
  }

  private async getUserDelegationKey() {
    // Cache for ~25 minutes to reduce calls.
    const now = Date.now();
    if (this._udkCache && this._udkCache.exp > now + 60_000) return this._udkCache.key;

    const start = new Date(now - 5 * 60_000);
    const end = new Date(now + 30 * 60_000);

    const key = await this.client.getUserDelegationKey(start, end);
    this._udkCache = { key, exp: end.getTime() };
    return key;
  }

  async createSasUrl(
    blobKey: string,
    permissions: string,
    expiresInMinutes: number,
    opts: SasOptions = {},
  ): Promise<string> {
    this.ensureConfigured();

    const { container, key } = this.splitKey(blobKey);
    const cc = this.containerClientFor(container);
    const bc = cc.getBlobClient(key);

    const expiresOn = new Date(Date.now() + expiresInMinutes * 60_000);

    const common = {
      containerName: container,
      blobName: key,
      permissions: BlobSASPermissions.parse(permissions),
      protocol: SASProtocol.Https,
      expiresOn,
      contentType: opts.contentType,
      contentDisposition: opts.contentDisposition,
    };

    const sas = this.sharedKey
      ? generateBlobSASQueryParameters(common as any, this.sharedKey).toString()
      : generateBlobSASQueryParameters(common as any, await this.getUserDelegationKey(), this.account).toString();

    return `${bc.url}?${sas}`;
  }

  async createWriteSasUrl(blobKey: string, contentType?: string, expiresInMinutes = 15): Promise<{ url: string; headers: Record<string, string> }> {
    const url = await this.createSasUrl(blobKey, "cw", expiresInMinutes, { contentType });
    return {
      url,
      headers: {
        "x-ms-blob-type": "BlockBlob",
        ...(contentType ? { "content-type": contentType } : {}),
      },
    };
  }

  async createReadSasUrl(blobKey: string, contentType?: string, disposition?: string, expiresInMinutes = 30): Promise<string> {
    return this.createSasUrl(blobKey, "r", expiresInMinutes, {
      contentType,
      contentDisposition: disposition,
    });
  }
}
