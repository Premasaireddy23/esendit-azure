import { EmailClient } from "@azure/communication-email";

export class AcsEmailProvider {
  private readonly client: EmailClient;

  constructor(
    private readonly connectionString: string,
    private readonly from: string,
  ) {
    this.client = new EmailClient(connectionString);
  }

  async sendEmail(input: {
    to: string[];
    cc?: string[];
    subject: string;
    bodyHtml?: string | null;
    bodyText?: string | null;
    attachments?: Array<{ name: string; contentType: string; contentInBase64: string; contentId?: string }>;
  }) {
    if (!input.to?.length) throw new Error("No recipients (to[])");

    const message: any = {
      senderAddress: this.from,
      recipients: {
        to: input.to.map((address) => ({ address })),
        cc: (input.cc ?? []).map((address) => ({ address })),
      },
      content: {
        subject: input.subject,
        html: input.bodyHtml ?? undefined,
        plainText: input.bodyText ?? undefined,
      },
      attachments: (input.attachments ?? []).map((attachment) => ({
        name: attachment.name,
        contentType: attachment.contentType,
        contentInBase64: attachment.contentInBase64,
        contentId: attachment.contentId || undefined,
      })),
    };

    const poller = await this.client.beginSend(message);
    return await poller.pollUntilDone();
  }
}
