export const DEFAULT_QUEUE_PREFIX = "esendit";

function env(name: string): string | undefined {
  const v = process.env[name];
  return v && String(v).trim() ? String(v).trim() : undefined;
}

export function queuePrefix(): string {
  return (
    env("ESENDIT_QUEUE_PREFIX") ||
    env("SERVICE_BUS_QUEUE_PREFIX") ||
    env("QUEUE_PREFIX") ||
    DEFAULT_QUEUE_PREFIX
  );
}

export function q(name: string): string {
  const p = queuePrefix();
  const base = name.replace(/[^a-z0-9-]/gi, "-").toLowerCase();
  return `${p}-${base}`;
}

export const QUEUES = {
  media: () => q("media-jobs"),
  bulk: () => q("bulk-jobs"),
  presets: () => q("preset-jobs"),
  delivery: () => q("delivery-jobs"),
  deliveryStaticVm: () => q("delivery-jobs-static-vm"),
};
