import { QUEUES } from "./queue.constants";

export const DELIVERY_WORKER_ROUTES = {
  ACA: "ACA",
  STATIC_VM: "STATIC_VM",
} as const;

export type DeliveryWorkerRoute = (typeof DELIVERY_WORKER_ROUTES)[keyof typeof DELIVERY_WORKER_ROUTES];

const DEFAULT_DELIVERY_WORKER_ROUTE: DeliveryWorkerRoute = DELIVERY_WORKER_ROUTES.ACA;

function asObject(value: any): Record<string, any> {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}

export function normalizeDeliveryWorkerRoute(value: any): DeliveryWorkerRoute {
  const raw = String(value ?? "").trim().toUpperCase().replace(/[\s-]+/g, "_");
  if (raw === DELIVERY_WORKER_ROUTES.STATIC_VM || raw === "STATICVM" || raw === "VM") {
    return DELIVERY_WORKER_ROUTES.STATIC_VM;
  }
  return DEFAULT_DELIVERY_WORKER_ROUTE;
}

export function getDeliveryProfileWorkerRoute(profile: any): DeliveryWorkerRoute {
  return normalizeDeliveryWorkerRoute(asObject(profile?.config).workerRoute);
}

export function getCurrentDeliveryWorkerRoute(): DeliveryWorkerRoute {
  return normalizeDeliveryWorkerRoute(process.env.DELIVERY_WORKER_ROUTE);
}

export function getDeliveryQueueForRoute(route: any): string {
  return normalizeDeliveryWorkerRoute(route) === DELIVERY_WORKER_ROUTES.STATIC_VM
    ? QUEUES.deliveryStaticVm()
    : QUEUES.delivery();
}

export function getTaskTranscript(taskOrTranscript: any): Record<string, any> {
  if (taskOrTranscript?.transcript && typeof taskOrTranscript.transcript === "object" && !Array.isArray(taskOrTranscript.transcript)) {
    return taskOrTranscript.transcript;
  }
  return asObject(taskOrTranscript);
}

export function resolveDeliveryRoutingFromProfiles(
  mainProfile: any,
  backupProfile: any,
  opts: { forceBackup?: boolean } = {},
): {
  preferredRoute: DeliveryWorkerRoute;
  mainRoute: DeliveryWorkerRoute;
  backupRoute: DeliveryWorkerRoute | null;
  routeConflict: boolean;
} {
  const mainRoute = getDeliveryProfileWorkerRoute(mainProfile);
  const backupRoute = backupProfile ? getDeliveryProfileWorkerRoute(backupProfile) : null;
  const routeConflict = Boolean(backupRoute && backupRoute !== mainRoute);
  const preferredRoute = opts.forceBackup && backupRoute ? backupRoute : mainRoute;

  return {
    preferredRoute,
    mainRoute,
    backupRoute,
    routeConflict,
  };
}

export function readPersistedDeliveryRouting(taskOrTranscript: any): {
  preferredRoute: DeliveryWorkerRoute;
  mainRoute: DeliveryWorkerRoute;
  backupRoute: DeliveryWorkerRoute | null;
} | null {
  const transcript = getTaskTranscript(taskOrTranscript);
  const routing = asObject(transcript.deliveryRouting);
  if (!Object.keys(routing).length) return null;

  const mainRoute = normalizeDeliveryWorkerRoute(routing.mainRoute);
  const backupRoute = routing.backupRoute == null ? null : normalizeDeliveryWorkerRoute(routing.backupRoute);
  const preferredRoute = normalizeDeliveryWorkerRoute(
    routing.preferredRoute ?? (routing.forceBackup && backupRoute ? backupRoute : mainRoute),
  );

  return {
    preferredRoute,
    mainRoute,
    backupRoute,
  };
}

export function resolveDeliveryTaskRouting(task: any): {
  preferredRoute: DeliveryWorkerRoute;
  mainRoute: DeliveryWorkerRoute;
  backupRoute: DeliveryWorkerRoute | null;
  routeConflict: boolean;
} {
  const persisted = readPersistedDeliveryRouting(task);
  const derived = resolveDeliveryRoutingFromProfiles(task?.mainDeliveryProfile ?? null, task?.backupDeliveryProfile ?? null, {
    forceBackup: Boolean(task?.forceBackup),
  });

  const mainRoute = persisted?.mainRoute ?? derived.mainRoute;
  const backupRoute = persisted?.backupRoute ?? derived.backupRoute;
  const preferredRoute = normalizeDeliveryWorkerRoute(
    persisted?.preferredRoute ?? (task?.forceBackup && backupRoute ? backupRoute : mainRoute),
  );

  return {
    preferredRoute,
    mainRoute,
    backupRoute,
    routeConflict: Boolean(backupRoute && backupRoute !== mainRoute),
  };
}

export function withDeliveryRoutingTranscript(taskOrTranscript: any, routing: {
  preferredRoute: DeliveryWorkerRoute;
  mainRoute: DeliveryWorkerRoute;
  backupRoute: DeliveryWorkerRoute | null;
}) {
  const transcript = getTaskTranscript(taskOrTranscript);
  return {
    ...transcript,
    deliveryRouting: {
      preferredRoute: normalizeDeliveryWorkerRoute(routing.preferredRoute),
      mainRoute: normalizeDeliveryWorkerRoute(routing.mainRoute),
      backupRoute: routing.backupRoute == null ? null : normalizeDeliveryWorkerRoute(routing.backupRoute),
    },
  };
}

export function getDeliveryRouteConflictMessage(mainRoute: any, backupRoute: any): string {
  return `Phase 1 split delivery requires main and backup delivery profiles to use the same workerRoute. Found main=${normalizeDeliveryWorkerRoute(
    mainRoute,
  )}, backup=${normalizeDeliveryWorkerRoute(backupRoute)}.`;
}
