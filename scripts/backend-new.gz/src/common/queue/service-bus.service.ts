import { Injectable, Logger, OnModuleDestroy } from "@nestjs/common";
import { ServiceBusClient, ServiceBusReceiver } from "@azure/service-bus";

type SendOpts = {
  messageId?: string;
  scheduleAtUtc?: Date;
};

@Injectable()
export class ServiceBusService implements OnModuleDestroy {
  private readonly log = new Logger(ServiceBusService.name);
  private client: ServiceBusClient | null = null;
  private receivers: ServiceBusReceiver[] = [];

  isEnabled(): boolean {
    const flag = (process.env.SERVICE_BUS_ENABLED || "true").toLowerCase();
    if (flag === "false") return false;
    return Boolean(process.env.SERVICE_BUS_CONNECTION_STRING);
  }

  private getClient(): ServiceBusClient {
    if (!this.isEnabled()) throw new Error("SERVICE_BUS_NOT_CONFIGURED");
    if (!this.client) {
      this.client = new ServiceBusClient(String(process.env.SERVICE_BUS_CONNECTION_STRING));
    }
    return this.client;
  }

  async sendJson(queueName: string, body: any, opts: SendOpts = {}) {
    const client = this.getClient();
    const sender = client.createSender(queueName);
    try {
      const msg: any = {
        body,
        contentType: "application/json",
        messageId: opts.messageId,
      };
      if (opts.scheduleAtUtc) {
        await sender.scheduleMessages([msg], opts.scheduleAtUtc);
      } else {
        await sender.sendMessages(msg);
      }
    } finally {
      await sender.close().catch(() => undefined);
    }
  }

  async subscribeJson(queueName: string, handler: (body: any) => Promise<void>) {
    const client = this.getClient();
    const receiver = client.createReceiver(queueName, { receiveMode: "peekLock" });
    this.receivers.push(receiver);

    // NOTE: Some @azure/service-bus versions don't support `prefetchCount` in ServiceBusReceiverOptions.
    // Setting it directly on the receiver is compatible across versions.
    const prefetchCount = Number(process.env.SERVICE_BUS_PREFETCH || "1");
    if (Number.isFinite(prefetchCount) && prefetchCount > 0) {
      try {
        (receiver as any).prefetchCount = prefetchCount;
      } catch {
        // ignore
      }
    }

    const maxConcurrentCalls = Number(process.env.SERVICE_BUS_MAX_CONCURRENT_CALLS || "1");
    receiver.subscribe(
      {
        processMessage: async (msg) => {
          try {
            await handler(msg.body);
            await receiver.completeMessage(msg);
          } catch (e) {
            await receiver.abandonMessage(msg).catch(() => undefined);
            // Do not throw — avoid noisy processError loops.
            this.log.warn(`Message handling failed for ${queueName}: ${(e as any)?.message || e}`);
          }
        },
        processError: async (args) => {
          this.log.error(`Receiver error for ${queueName}: ${args.error?.message || args.error}`);
        },
      },
      {
        autoCompleteMessages: false,
        maxConcurrentCalls:
          Number.isFinite(maxConcurrentCalls) && maxConcurrentCalls > 0 ? maxConcurrentCalls : 1,
      },
    );
  }

  async onModuleDestroy() {
    for (const r of this.receivers) await r.close().catch(() => undefined);
    this.receivers = [];
    if (this.client) await this.client.close().catch(() => undefined);
    this.client = null;
  }
}
