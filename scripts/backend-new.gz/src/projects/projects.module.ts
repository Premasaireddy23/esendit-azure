import { Module } from "@nestjs/common";
import { ProjectsController } from "./projects.controller";
import { ProjectsService } from "./projects.service";
import { ProjectWizardController } from "./project-wizard.controller";
import { ProjectWizardService } from "./project-wizard.service";
import { NotificationsModule } from "../modules/notifications/notifications.module";
import { ApprovalsModule } from "../modules/approvals/approvals.module";

import { MastersProjectsController } from "./masters-projects.controller";
import { MastersProjectsService } from "./masters-projects.service";

@Module({
  imports: [NotificationsModule, ApprovalsModule],
  controllers: [ProjectsController, ProjectWizardController, MastersProjectsController],
  providers: [ProjectsService, ProjectWizardService, MastersProjectsService],
})
export class ProjectsModule {}
