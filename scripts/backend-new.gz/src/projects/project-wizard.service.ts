import {
  BadRequestException,
  ConflictException,
  ForbiddenException,
  Injectable,
} from "@nestjs/common";
import { AccountType, AgencyType, UserType } from "@prisma/client";
import { PrismaService } from "../common/prisma/prisma.service";
import { NotificationsService } from "../modules/notifications/notifications.service";
import { CreateProjectWizardDto } from "./dto/project-wizard.dto";

const DEFAULT_TYPES = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11];

function uniqEmails(emails: string[] | undefined) {
  const list = (emails ?? [])
    .map((e) => e.trim().toLowerCase())
    .filter(Boolean);
  return Array.from(new Set(list));
}

function sanitizeEnabledTypes(types: number[] | undefined) {
  const list = (types ?? []).filter((n) => Number.isInteger(n) && n >= 1 && n <= 11);
  const unique = Array.from(new Set(list));
  return unique.length ? unique : DEFAULT_TYPES;
}

@Injectable()
export class ProjectWizardService {
  constructor(private readonly prisma: PrismaService, private readonly notifications: NotificationsService,) {}

  private has(user: any, perm: string) {
    return Array.isArray(user.permissions) && user.permissions.includes(perm);
  }


  private async assertAgencyType(accountId: string, id: string, expected: AgencyType) {
    const a = await this.prisma.agency.findFirst({
      where: { id, accountId },
      select: { id: true, type: true },
    });
    if (!a) throw new BadRequestException("Invalid agency for this account.");
    if (a.type !== expected) throw new BadRequestException(`Agency type mismatch: expected ${expected}.`);
  }

  private async assertTeamBelongs(accountId: string, teamId: string, agencyId: string) {
    const t = await this.prisma.agencyTeam.findFirst({
      where: { id: teamId, accountId },
      select: { id: true, agencyId: true },
    });
    if (!t) throw new BadRequestException("Invalid agency team for this account.");
    if (t.agencyId !== agencyId) throw new BadRequestException("Agency team does not belong to selected agency.");
  }

  private async assertSenderAccount(accountId: string, senderAccountId: string) {
    const sender = await this.prisma.partnerAccount.findFirst({
      where: { id: senderAccountId, accountId },
      select: { id: true, accountType: true, status: true },
    });
    if (!sender) throw new BadRequestException("Invalid sender account for this account.");
    if (sender.accountType !== AccountType.SENDER) throw new BadRequestException("Selected account is not a sender account.");
    if (sender.status !== "ACTIVE") throw new BadRequestException("Sender account must be active.");
  }

  async getMeta(accountId: string) {
    const [advertiserGroups, advertisers, brands, productCategories, agencies, agencyTeams, senderAccounts, billableParties] =
      await Promise.all([
        this.prisma.advertiserGroup.findMany({
          where: { accountId, status: "ACTIVE" },
          orderBy: { name: "asc" },
        }),
        this.prisma.advertiser.findMany({
          where: { accountId, status: "ACTIVE" },
          orderBy: { name: "asc" },
        }),
        this.prisma.brand.findMany({
          where: { accountId, status: "ACTIVE" },
          orderBy: { name: "asc" },
        }),
        this.prisma.productCategory.findMany({
          where: { accountId, status: "ACTIVE" },
          orderBy: { name: "asc" },
        }),
        this.prisma.agency.findMany({
          where: { accountId, status: "ACTIVE" },
          orderBy: { name: "asc" },
          select: { id: true, type: true, name: true, emails: true, status: true },
        }),
        this.prisma.agencyTeam.findMany({
          where: { accountId, status: "ACTIVE" },
          orderBy: { name: "asc" },
          select: { id: true, agencyId: true, name: true, emails: true, status: true },
        }),
        this.prisma.partnerAccount.findMany({
          where: { accountId, status: "ACTIVE", accountType: AccountType.SENDER },
          orderBy: { name: "asc" },
          select: { id: true, name: true, accountType: true, emails: true, receiverCategory: true },
        }),
        this.prisma.billableParty.findMany({
          where: { accountId, status: "ACTIVE" as any },
          orderBy: { name: "asc" },
          select: { id: true, name: true, code: true },
        }).catch(() => []),
      ]);

    return {
      advertiserGroups,
      advertisers,
      brands,
      productCategories,
      agencies,
      agencyTeams,
      senderAccounts,
      billableParties,
    };
  }

  private formatProjectCode(seq: number) {
    const prefix = process.env.PROJECT_NUMBER_PREFIX ?? "PRJ";
    return `${prefix}-${String(seq).padStart(6, "0")}`;
  }

  private async peekNextProjectCode(db: any, accountId: string) {
    const current = await db.accountSequence.upsert({
      where: { accountId_key: { accountId, key: "PROJECT_NUMBER" } },
      update: {},
      create: { accountId, key: "PROJECT_NUMBER", nextValue: 1 },
      select: { nextValue: true },
    });

    return this.formatProjectCode(current.nextValue);
  }

  private async nextProjectCode(tx: any, accountId: string) {
    await tx.accountSequence.upsert({
      where: { accountId_key: { accountId, key: "PROJECT_NUMBER" } },
      update: {},
      create: { accountId, key: "PROJECT_NUMBER", nextValue: 1 },
    });

    const updated = await tx.accountSequence.update({
      where: { accountId_key: { accountId, key: "PROJECT_NUMBER" } },
      data: { nextValue: { increment: 1 } },
      select: { nextValue: true },
    });

    const seq = updated.nextValue - 1;
    return this.formatProjectCode(seq);
  }

  async previewNextProjectCode(user: any) {
    const accountId = user.accountId as string;
    if (!this.has(user, "PROJECT_NUMBER_AUTO")) {
      throw new ForbiddenException("Missing PROJECT_NUMBER_AUTO permission.");
    }
    return { projectCode: await this.peekNextProjectCode(this.prisma, accountId) };
  }

  async validateProjectName(user: any, name: string) {
    const accountId = user.accountId as string;
    const normalizedName = String(name ?? "").trim();
    if (!normalizedName) throw new BadRequestException("Project name is required");

    const existing = await this.prisma.project.findFirst({
      where: {
        accountId,
        name: { equals: normalizedName, mode: "insensitive" },
      },
      select: { id: true, name: true, projectCode: true },
    });

    if (existing) {
      return {
        available: false,
        message: "Project name already exists in this account.",
        existing,
      };
    }

    return {
      available: true,
      message: "Project name is available.",
    };
  }

  async createWizardProject(user: any, dto: CreateProjectWizardDto) {
    const accountId = user.accountId as string;

    // Validate masters belong to tenant
    const [ag, adv, br, pc] = await Promise.all([
      this.prisma.advertiserGroup.findFirst({
        where: { id: dto.advertiserGroupId, accountId },
        select: { id: true },
      }),
      this.prisma.advertiser.findFirst({
        where: { id: dto.advertiserId, accountId },
        select: { id: true },
      }),
      this.prisma.brand.findFirst({
        where: { id: dto.brandId, accountId },
        select: { id: true },
      }),
      this.prisma.productCategory.findFirst({
        where: { id: dto.productCategoryId, accountId },
        select: { id: true },
      }),
    ]);
    if (!ag || !adv || !br || !pc) {
      throw new BadRequestException("Invalid master selection for this account.");
    }

    if (dto.senderAccountId) {
      await this.assertSenderAccount(accountId, dto.senderAccountId);
    }

    if (dto.billablePartyId) {
      const billableParty = await this.prisma.billableParty.findFirst({
        where: { id: dto.billablePartyId, accountId, status: "ACTIVE" as any },
        select: { id: true },
      }).catch(() => null);
      if (!billableParty) throw new BadRequestException("Invalid billable party for this account.");
    }

    const wantsManual = !!dto.projectCode?.trim();
    if (wantsManual && !this.has(user, "PROJECT_NUMBER_MANUAL")) {
      throw new ForbiddenException("Missing PROJECT_NUMBER_MANUAL permission.");
    }
    if (!wantsManual && !this.has(user, "PROJECT_NUMBER_AUTO")) {
      throw new ForbiddenException("Missing PROJECT_NUMBER_AUTO permission.");
    }


    // Validate optional agency/team pairs (not required; only validates if provided)
    const pairs = [
      { agencyId: dto.mediaAgencyId, teamId: dto.mediaAgencyTeamId, type: AgencyType.MEDIA },
      { agencyId: dto.creativeAgencyId, teamId: dto.creativeAgencyTeamId, type: AgencyType.CREATIVE },
      { agencyId: dto.productionHouseId, teamId: dto.productionHouseTeamId, type: AgencyType.PRODUCTION_HOUSE },
      { agencyId: dto.postHouseId, teamId: dto.postHouseTeamId, type: AgencyType.POST_HOUSE },
      { agencyId: dto.audioAgencyId, teamId: dto.audioAgencyTeamId, type: AgencyType.AUDIO },
    ];

    for (const p of pairs) {
      if (p.teamId && !p.agencyId) {
        throw new BadRequestException("Select an agency before selecting its team.");
      }
      if (p.agencyId) {
        await this.assertAgencyType(accountId, p.agencyId, p.type);
      }
      if (p.teamId && p.agencyId) {
        await this.assertTeamBelongs(accountId, p.teamId, p.agencyId);
      }
    }

    // Uploader = Agency + Team (no type restriction)
    if (dto.uploaderAgencyTeamId && !dto.uploaderAgencyId) {
      throw new BadRequestException("Select an uploader agency before selecting its team.");
    }
    if (dto.uploaderAgencyId) {
      const a = await this.prisma.agency.findFirst({ where: { id: dto.uploaderAgencyId, accountId }, select: { id: true } });
      if (!a) throw new BadRequestException("Invalid uploader agency for this account.");
    }
    if (dto.uploaderAgencyTeamId && dto.uploaderAgencyId) {
      await this.assertTeamBelongs(accountId, dto.uploaderAgencyTeamId, dto.uploaderAgencyId);
    }

    const notif = dto.notification ?? {};
    const enabledTypes = sanitizeEnabledTypes(notif.enabledTypes);
    const extraEmails = uniqEmails(notif.extraEmails);

    const isThirdParty = (user.userType ?? UserType.INTERNAL) === UserType.THIRD_PARTY;

    // Defaults for base booleans = true (notifications-first)
    const base = {
      notifyAdvertiserGroup: notif.notifyAdvertiserGroup ?? true,
      notifyAdvertiser: notif.notifyAdvertiser ?? true,
      notifyBrand: notif.notifyBrand ?? true,
      notifyMediaAgency: notif.notifyMediaAgency ?? true,
      notifyCreativeAgency: notif.notifyCreativeAgency ?? true,
      notifyPostHouse: notif.notifyPostHouse ?? true,
      notifyAudioAgency: notif.notifyAudioAgency ?? true,
      notifyProductionHouse: notif.notifyProductionHouse ?? true,
    };

    // Third-party constraints: cannot change base; extras allowed (if allowed) later
    const notifCreate = isThirdParty
      ? {
          notifyAdvertiserGroup: true,
          notifyAdvertiser: true,
          notifyBrand: true,
          notifyMediaAgency: true,
          notifyCreativeAgency: true,
          notifyPostHouse: true,
          notifyAudioAgency: true,
          notifyProductionHouse: true,
          extraEmails,
          enabledTypes,
          allowThirdPartyEditBase: false,
          allowThirdPartyAddExtras: true,
        }
      : {
          ...base,
          extraEmails,
          enabledTypes,
          allowThirdPartyEditBase: notif.allowThirdPartyEditBase ?? false,
          allowThirdPartyAddExtras: notif.allowThirdPartyAddExtras ?? true,
        };

    try {
      const createdProject = await this.prisma.$transaction(
        async (tx) => {
          const projectCode = wantsManual
            ? dto.projectCode!.trim()
            : await this.nextProjectCode(tx, accountId);

          const project = await tx.project.create({
            data: {
              accountId,
              name: dto.name.trim(),
              projectCode,
              approvalsEnabled: dto.approvalsEnabled ?? false,

              advertiserGroupId: dto.advertiserGroupId,
              advertiserId: dto.advertiserId,
              brandId: dto.brandId,
              productCategoryId: dto.productCategoryId,
              senderAccountId: dto.senderAccountId ?? null,
              ...(dto.billablePartyId !== undefined ? ({ billablePartyId: dto.billablePartyId ?? null } as any) : {}),

              mediaAgencyId: dto.mediaAgencyId,
              mediaAgencyTeamId: dto.mediaAgencyTeamId,
              creativeAgencyId: dto.creativeAgencyId,
              creativeAgencyTeamId: dto.creativeAgencyTeamId,
              productionHouseId: dto.productionHouseId,
              productionHouseTeamId: dto.productionHouseTeamId,
              postHouseId: dto.postHouseId,
              postHouseTeamId: dto.postHouseTeamId,
              audioAgencyId: dto.audioAgencyId,
              audioAgencyTeamId: dto.audioAgencyTeamId,

              uploaderAgencyId: dto.uploaderAgencyId,
              uploaderAgencyTeamId: dto.uploaderAgencyTeamId,
              remarks: dto.remarks?.trim() || null,

              notificationConfig: { create: notifCreate },
            },
            include: { notificationConfig: true },
          });

          return project;
        },
        { isolationLevel: "Serializable" as any },
      );
      // Emit notification (Type 1)
      await this.notifications.emitType1ProjectCreated(accountId, createdProject.id);

      return createdProject;
    } catch (e: any) {
      // Prisma unique constraint violation
      if (e?.code === "P2002") {
        throw new ConflictException("Project number or name already exists in this account.");
      }
      throw e;
    }
  }


  // ----------------------------
  // Inline master creation (from Project wizard)
  // Minimal payloads; full details can still be edited in Masters.
  // ----------------------------

  async createInlineAdvertiserGroup(accountId: string, name: string) {
    const n = (name || "").trim();
    if (!n) throw new BadRequestException("Name is required");
    try {
      return await this.prisma.advertiserGroup.create({ data: { accountId, name: n }, select: { id: true, name: true } });
    } catch (e: any) {
      if (e?.code === "P2002") throw new BadRequestException("Advertiser Group already exists");
      throw e;
    }
  }

  async createInlineAdvertiser(accountId: string, input: { name: string; advertiserGroupId?: string }) {
    const n = (input.name || "").trim();
    if (!n) throw new BadRequestException("Name is required");
    if (input.advertiserGroupId) {
      const ag = await this.prisma.advertiserGroup.findFirst({ where: { id: input.advertiserGroupId, accountId }, select: { id: true } });
      if (!ag) throw new BadRequestException("Invalid advertiserGroupId");
    }
    try {
      return await this.prisma.advertiser.create({
        data: { accountId, name: n, advertiserGroupId: input.advertiserGroupId ?? null },
        select: { id: true, name: true, advertiserGroupId: true },
      });
    } catch (e: any) {
      if (e?.code === "P2002") throw new BadRequestException("Advertiser already exists");
      throw e;
    }
  }

  async createInlineBrand(accountId: string, input: { name: string; advertiserId: string }) {
    const n = (input.name || "").trim();
    if (!n) throw new BadRequestException("Name is required");
    const adv = await this.prisma.advertiser.findFirst({ where: { id: input.advertiserId, accountId }, select: { id: true } });
    if (!adv) throw new BadRequestException("Invalid advertiserId");
    try {
      return await this.prisma.brand.create({
        data: { accountId, name: n, advertiserId: input.advertiserId },
        select: { id: true, name: true, advertiserId: true },
      });
    } catch (e: any) {
      if (e?.code === "P2002") throw new BadRequestException("Brand already exists for this advertiser");
      throw e;
    }
  }

  async createInlineProductCategory(accountId: string, name: string) {
    const n = (name || "").trim();
    if (!n) throw new BadRequestException("Name is required");
    try {
      return await this.prisma.productCategory.create({ data: { accountId, name: n }, select: { id: true, name: true } });
    } catch (e: any) {
      if (e?.code === "P2002") throw new BadRequestException("Product Category already exists");
      throw e;
    }
  }

  async createInlineAgency(accountId: string, input: { type: AgencyType; name: string }) {
    const n = (input.name || "").trim();
    if (!n) throw new BadRequestException("Name is required");
    try {
      return await this.prisma.agency.create({
        data: { accountId, type: input.type, name: n },
        select: { id: true, name: true, type: true },
      });
    } catch (e: any) {
      if (e?.code === "P2002") throw new BadRequestException("Agency already exists");
      throw e;
    }
  }

  async createInlineAgencyTeam(accountId: string, input: { agencyId: string; name: string }) {
    const n = (input.name || "").trim();
    if (!n) throw new BadRequestException("Name is required");
    const a = await this.prisma.agency.findFirst({ where: { id: input.agencyId, accountId }, select: { id: true } });
    if (!a) throw new BadRequestException("Invalid agencyId");
    try {
      return await this.prisma.agencyTeam.create({
        data: { accountId, agencyId: input.agencyId, name: n },
        select: { id: true, name: true, agencyId: true },
      });
    } catch (e: any) {
      if (e?.code === "P2002") throw new BadRequestException("Agency Team already exists");
      throw e;
    }
  }

}
