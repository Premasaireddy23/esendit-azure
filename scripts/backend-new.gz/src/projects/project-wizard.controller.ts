import { Body, Controller, Get, Post, Query } from '@nestjs/common';
import { JwtAuthGuard } from '../common/auth/jwt-auth.guard';
import { PermissionsGuard } from '../common/auth/permissions.guard';
import { RequirePermissions } from '../common/auth/require-permissions.decorator';
import { UseGuards } from '@nestjs/common';
import { CreateProjectWizardDto } from './dto/project-wizard.dto';
import { InlineCreateAdvertiserDto, InlineCreateAgencyDto, InlineCreateAgencyTeamDto, InlineCreateBrandDto, InlineCreateNamedDto } from "./dto/inline-master.dto";
import { PERM } from "../common/auth/permission.registry";
import { ProjectWizardService } from './project-wizard.service';
import { CurrentUser } from '../common/auth/current-user.decorator';

@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller('projects/wizard')
export class ProjectWizardController {
  constructor(private readonly svc: ProjectWizardService) {}

  @Get('meta')
  @RequirePermissions('PROJECT_WIZARD_CREATE')
  async meta(@CurrentUser() user: any) {
    return this.svc.getMeta(user.accountId);
  }

  @Post()
  @RequirePermissions('PROJECT_WIZARD_CREATE')
  async create(@CurrentUser() user: any, @Body() dto: CreateProjectWizardDto) {
    return this.svc.createWizardProject(user, dto);
  }

  @Get('next-code')
  @RequirePermissions('PROJECT_WIZARD_CREATE')
  async previewNextCode(@CurrentUser() user: any) {
    return this.svc.previewNextProjectCode(user);
  }

  @Get('validate-name')
  @RequirePermissions('PROJECT_WIZARD_CREATE')
  async validateName(@CurrentUser() user: any, @Query('name') name: string) {
    return this.svc.validateProjectName(user, name);
  }


  @Post("inline/advertiser-groups")
  @RequirePermissions(PERM.PROJECT_MASTER_ADD_ADVERTISER_GROUP)
  async createAdvertiserGroup(@CurrentUser() user: any, @Body() dto: InlineCreateNamedDto) {
    return this.svc.createInlineAdvertiserGroup(user.accountId, dto.name);
  }

  @Post("inline/advertisers")
  @RequirePermissions(PERM.PROJECT_MASTER_ADD_ADVERTISER)
  async createAdvertiser(@CurrentUser() user: any, @Body() dto: InlineCreateAdvertiserDto) {
    return this.svc.createInlineAdvertiser(user.accountId, dto);
  }

  @Post("inline/brands")
  @RequirePermissions(PERM.PROJECT_MASTER_ADD_BRAND)
  async createBrand(@CurrentUser() user: any, @Body() dto: InlineCreateBrandDto) {
    return this.svc.createInlineBrand(user.accountId, dto);
  }

  @Post("inline/product-categories")
  @RequirePermissions(PERM.PROJECT_MASTER_ADD_PRODUCT_CATEGORY)
  async createProductCategory(@CurrentUser() user: any, @Body() dto: InlineCreateNamedDto) {
    return this.svc.createInlineProductCategory(user.accountId, dto.name);
  }

  @Post("inline/agencies")
  @RequirePermissions(PERM.PROJECT_MASTER_ADD_AGENCY)
  async createAgency(@CurrentUser() user: any, @Body() dto: InlineCreateAgencyDto) {
    return this.svc.createInlineAgency(user.accountId, dto);
  }

  @Post("inline/agency-teams")
  @RequirePermissions(PERM.PROJECT_MASTER_ADD_AGENCY_TEAM)
  async createAgencyTeam(@CurrentUser() user: any, @Body() dto: InlineCreateAgencyTeamDto) {
    return this.svc.createInlineAgencyTeam(user.accountId, dto);
  }
}
