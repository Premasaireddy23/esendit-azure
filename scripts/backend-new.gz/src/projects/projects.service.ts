import { BadRequestException, ConflictException, Injectable, NotFoundException } from "@nestjs/common";
import { approvals, AccountType, AgencyType, CreativeQcStatus, PlanLineStatus, Prisma } from "@prisma/client";
import { PrismaService } from "../common/prisma/prisma.service";
import { ServiceBusService } from "../common/queue/service-bus.service";
import { NotificationsService } from "../modules/notifications/notifications.service";
import type { AuthUser } from "../common/auth/current-user.decorator";
import { ensureCreativePresetJob, resolveChannelCommitPreset } from "../common/presets/channel-default-preset";
import { parseSlaTargetMinutes } from "../modules/masters/sla-duration";
import { ApprovalsService } from "../modules/approvals/approvals.service";

import { UpdateProjectDto } from "./dto/update-project.dto";

type GateFail = { code: string; message: string };

function uniqEmails(emails: string[] | undefined) {
  const list = (emails ?? [])
    .map((e) => String(e ?? "").trim().toLowerCase())
    .filter(Boolean);
  return Array.from(new Set(list));
}

function sanitizeExplicitEnabledTypes(types: number[] | undefined) {
  const list = (types ?? []).filter((n) => Number.isInteger(n) && n >= 1 && n <= 11);
  return Array.from(new Set(list)).sort((a, b) => a - b);
}

function normalizeLookupText(value: any) {
  return String(value ?? "")
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "");
}

function deriveSenderAccountMatches(
  senderAccounts: Array<{ id: string; name: string }>,
  sources: Array<{ source: string; value?: string | null }>,
) {
  const activeSources = sources
    .map((item) => ({
      source: item.source,
      value: String(item.value ?? "").trim(),
      normalized: normalizeLookupText(item.value),
    }))
    .filter((item) => item.normalized);

  if (!activeSources.length || !Array.isArray(senderAccounts) || !senderAccounts.length) return [];

  const matches: Array<{ id: string; name: string; matchSources: string[]; matchScore: number }> = [];

  for (const account of senderAccounts) {
    const accountName = String(account?.name ?? "").trim();
    const normalizedName = normalizeLookupText(accountName);
    if (!normalizedName) continue;

    let score = 0;
    const matchedBy: string[] = [];
    for (const src of activeSources) {
      if (!src.normalized) continue;
      if (normalizedName === src.normalized) {
        score += 300;
        matchedBy.push(src.source);
        continue;
      }
      if (src.normalized.length >= 4 && (normalizedName.includes(src.normalized) || src.normalized.includes(normalizedName))) {
        score += 120;
        matchedBy.push(src.source);
      }
    }

    if (score > 0) {
      matches.push({
        id: account.id,
        name: accountName,
        matchSources: Array.from(new Set(matchedBy)),
        matchScore: score,
      });
    }
  }

  return matches
    .sort((a, b) => b.matchScore - a.matchScore || a.name.localeCompare(b.name))
    .slice(0, 5);
}

type QcGateBlocker = {
  creativeId: string;
  valid: string | null;
  caption: string | null;
  missingSource: boolean;
  qcStatus: string | null;
  qcNotes: string | null;
};

type QcGateResult = {
  ok: boolean;
  blockers: QcGateBlocker[];
};

@Injectable()
export class ProjectsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly notifications: NotificationsService,
    private readonly bus: ServiceBusService,
    private readonly approvalsService: ApprovalsService,
  ) {}

  async createProject(input: { accountId: string; name: string; approvalsEnabled?: boolean; senderAccountId?: string; billablePartyId?: string }) {
    const account = await this.prisma.account.findUnique({
      where: { id: input.accountId },
      select: { id: true },
    });
    if (!account) throw new BadRequestException("Invalid accountId");

    if (input.senderAccountId) {
      await this.assertSenderAccount(input.accountId, input.senderAccountId);
    }
    if (input.billablePartyId) {
      const billableParty = await this.prisma.billableParty.findFirst({
        where: { id: input.billablePartyId, accountId: input.accountId, status: "ACTIVE" as any },
        select: { id: true },
      }).catch(() => null);
      if (!billableParty) throw new BadRequestException("Invalid billable party for this account.");
    }

    return this.prisma.project.create({
      data: {
        accountId: input.accountId,
        name: input.name,
        approvalsEnabled: input.approvalsEnabled ?? false,
        senderAccountId: input.senderAccountId ?? null,
        ...(input.billablePartyId !== undefined ? ({ billablePartyId: input.billablePartyId ?? null } as any) : {}),
      },
    });
  }

  async getProjectEditMeta(accountId: string) {
    const [advertiserGroups, advertisers, brands, productCategories, agencies, agencyTeams, senderAccounts, billableParties] = await Promise.all([
      this.prisma.advertiserGroup.findMany({
        where: { accountId, status: "ACTIVE" },
        orderBy: { name: "asc" },
        select: { id: true, name: true },
      }),
      this.prisma.advertiser.findMany({
        where: { accountId, status: "ACTIVE" },
        orderBy: { name: "asc" },
        select: { id: true, name: true },
      }),
      this.prisma.brand.findMany({
        where: { accountId, status: "ACTIVE" },
        orderBy: { name: "asc" },
        select: { id: true, name: true },
      }),
      this.prisma.productCategory.findMany({
        where: { accountId, status: "ACTIVE" },
        orderBy: { name: "asc" },
        select: { id: true, name: true },
      }),
      this.prisma.agency.findMany({
        where: { accountId, status: "ACTIVE" },
        orderBy: { name: "asc" },
        select: { id: true, type: true, name: true },
      }),
      this.prisma.agencyTeam.findMany({
        where: { accountId, status: "ACTIVE" },
        orderBy: { name: "asc" },
        select: { id: true, agencyId: true, name: true },
      }),
      this.prisma.partnerAccount.findMany({
        where: { accountId, status: "ACTIVE", accountType: AccountType.SENDER },
        orderBy: { name: "asc" },
        select: { id: true, name: true, accountType: true, emails: true, receiverCategory: true },
      }),
      this.prisma.billableParty.findMany({
        where: { accountId, status: "ACTIVE" as any },
        orderBy: { name: "asc" },
        select: { id: true, name: true, code: true },
      }).catch(() => []),
    ]);

    return {
      advertiserGroups,
      advertisers,
      brands,
      productCategories,
      agencies,
      agencyTeams,
      senderAccounts,
      billableParties,
    };
  }

  /**
   * Project details for FE "View" drawer and "Edit Project" page.
   */
  async getProjectDetails(accountId: string, projectId: string, user?: AuthUser | any) {
    const project = await this.prisma.project.findFirst({
      where: { id: projectId, accountId },
      select: {
        id: true,
        name: true,
        projectNumber: true,
        projectCode: true,
        status: true,
        approvalsEnabled: true,
        remarks: true,
        uploaderAgency: { select: { id: true, name: true, type: true } },
        uploaderAgencyTeam: { select: { id: true, name: true, agencyId: true } },
        createdAt: true,
        updatedAt: true,
        closedAt: true,

        advertiserGroup: { select: { id: true, name: true } },
        advertiser: { select: { id: true, name: true } },
        brand: { select: { id: true, name: true } },
        productCategory: { select: { id: true, name: true } },
        senderAccount: { select: { id: true, name: true } },
        ...( {
          billableParty: { select: { id: true, name: true, code: true } },
        } as any),

        mediaAgency: { select: { id: true, name: true, type: true } },
        mediaAgencyTeam: { select: { id: true, name: true, agencyId: true } },

        creativeAgency: { select: { id: true, name: true, type: true } },
        creativeAgencyTeam: { select: { id: true, name: true, agencyId: true } },

        productionHouse: { select: { id: true, name: true, type: true } },
        productionHouseTeam: { select: { id: true, name: true, agencyId: true } },

        postHouse: { select: { id: true, name: true, type: true } },
        postHouseTeam: { select: { id: true, name: true, agencyId: true } },

        audioAgency: { select: { id: true, name: true, type: true } },
        audioAgencyTeam: { select: { id: true, name: true, agencyId: true } },

        notificationConfig: {
          select: {
            notifyAdvertiserGroup: true,
            notifyAdvertiser: true,
            notifyBrand: true,
            notifyMediaAgency: true,
            notifyCreativeAgency: true,
            notifyProductionHouse: true,
            notifyPostHouse: true,
            notifyAudioAgency: true,
            extraEmails: true,
            enabledTypes: true,
            allowThirdPartyEditBase: true,
            allowThirdPartyAddExtras: true,
          },
        },

        // User model uses displayName (not name)
        closedByUser: { select: { id: true, email: true, displayName: true } },
      },
    });

    if (!project) throw new NotFoundException("Project not found");

    const [senderAccounts, planningEntries] = await Promise.all([
      this.prisma.partnerAccount.findMany({
        where: { accountId, status: "ACTIVE", accountType: AccountType.SENDER },
        orderBy: { name: "asc" },
        select: { id: true, name: true },
      }),
      this.prisma.planningEntry.findMany({
        where: { accountId, projectId, selected: true },
        select: { channelId: true },
      }),
    ]);

    const senderAccountMatches = deriveSenderAccountMatches(senderAccounts, [
      { source: "Advertiser Group", value: (project as any)?.advertiserGroup?.name },
      { source: "Advertiser", value: (project as any)?.advertiser?.name },
      { source: "Brand", value: (project as any)?.brand?.name },
    ]);

    const channelIds = Array.from(
      new Set((planningEntries || []).map((row: any) => String(row?.channelId || "").trim()).filter(Boolean)),
    );

    let receiverAccountsUsed: Array<{ id: string; name: string; receiverCategory?: string | null }> = [];
    if (channelIds.length) {
      const channels = await this.prisma.channel.findMany({
        where: { accountId, id: { in: channelIds } },
        select: { id: true, destinationId: true },
      });

      const destinationIds = Array.from(
        new Set((channels || []).map((row: any) => String(row?.destinationId || "").trim()).filter(Boolean)),
      );

      if (destinationIds.length) {
        const destinations = await this.prisma.destination.findMany({
          where: { accountId, id: { in: destinationIds } },
          select: { id: true, name: true, config: true, category: true },
        });

        const receiverIds = Array.from(
          new Set(
            (destinations || [])
              .map((row: any) => String((row?.config as any)?.receiverAccountId || "").trim())
              .filter(Boolean),
          ),
        );

        if (receiverIds.length) {
          const receivers = await this.prisma.partnerAccount.findMany({
            where: { accountId, id: { in: receiverIds } },
            select: { id: true, name: true, receiverCategory: true },
          });
          const receiverById = new Map((receivers || []).map((row: any) => [String(row.id), row]));
          receiverAccountsUsed = Array.from(
            new Map(
              (destinations || [])
                .map((row: any) => receiverById.get(String((row?.config as any)?.receiverAccountId || "").trim()))
                .filter(Boolean)
                .map((row: any) => [String(row.id), { id: row.id, name: row.name, receiverCategory: row.receiverCategory ?? null }]),
            ).values(),
          ).sort((a, b) => String(a.name || "").localeCompare(String(b.name || "")));

          const activeReceiverAccountId = String((user as any)?.activeReceiverAccountId || "").trim();
          if (activeReceiverAccountId) {
            receiverAccountsUsed = receiverAccountsUsed.filter((row) => String(row.id || "") === activeReceiverAccountId);
          }
        }
      }
    }

    return {
      ...project,
      senderAccountMatches,
      receiverAccountsUsed,
    };
  }

  private hasPerm(user: AuthUser, perm: string) {
    return Array.isArray(user.permissions) && user.permissions.includes(perm);
  }

  private async assertMasterId(
    accountId: string,
    model: "advertiserGroup" | "advertiser" | "brand" | "productCategory",
    id: string,
  ) {
    const exists = await (this.prisma as any)[model].findFirst({ where: { id, accountId }, select: { id: true } });
    if (!exists) throw new BadRequestException(`Invalid ${model} for this account.`);
  }

  private async assertSenderAccount(accountId: string, senderAccountId: string) {
    const sender = await this.prisma.partnerAccount.findFirst({
      where: { id: senderAccountId, accountId },
      select: { id: true, accountType: true, status: true },
    });
    if (!sender) throw new BadRequestException("Invalid sender account for this account.");
    if (sender.accountType !== AccountType.SENDER) throw new BadRequestException("Selected account is not a sender account.");
    if (sender.status !== "ACTIVE") throw new BadRequestException("Sender account must be active.");
  }

  private async assertAgency(accountId: string, id: string, expectedType: AgencyType) {
    const a = await this.prisma.agency.findFirst({ where: { id, accountId }, select: { id: true, type: true } });
    if (!a) throw new BadRequestException("Invalid agency for this account.");
    if (a.type !== expectedType) throw new BadRequestException(`Agency type mismatch: expected ${expectedType}.`);
  }

  private async assertTeam(accountId: string, teamId: string, agencyId: string) {
    const t = await this.prisma.agencyTeam.findFirst({
      where: { id: teamId, accountId },
      select: { id: true, agencyId: true },
    });
    if (!t) throw new BadRequestException("Invalid agency team for this account.");
    if (t.agencyId !== agencyId) throw new BadRequestException("Agency team does not belong to the selected agency.");
  }

  /**
   * Update project details (Edit Project).
   * Only provided fields are updated.
   */
  async updateProject(user: AuthUser, projectId: string, dto: UpdateProjectDto) {
    const accountId = user.accountId;

    const existing = await this.prisma.project.findFirst({
      where: { id: projectId, accountId },
      select: {
        id: true,
        mediaAgencyId: true,
        mediaAgencyTeamId: true,
        creativeAgencyId: true,
        creativeAgencyTeamId: true,
        productionHouseId: true,
        productionHouseTeamId: true,
        postHouseId: true,
        postHouseTeamId: true,
        audioAgencyId: true,
        audioAgencyTeamId: true,
        uploaderAgencyId: true,
        uploaderAgencyTeamId: true,
        senderAccountId: true,
        ...( { billablePartyId: true } as any),
        remarks: true,
      },
    });
    if (!existing) throw new NotFoundException("Project not found");

    const data: Prisma.ProjectUpdateInput = {};

    if (dto.name !== undefined) {
      const n = (dto.name ?? "").trim();
      if (!n) throw new BadRequestException("Project name is required");
      data.name = n;
    }

    if (dto.approvalsEnabled !== undefined) {
      data.approvalsEnabled = !!dto.approvalsEnabled;
    }

    if ((dto as any).remarks !== undefined) {
      const r = ((dto as any).remarks ?? "") as string;
      data.remarks = r ? r.trim() : null;
    }

    // Project code: treat blank as null; require PROJECT_NUMBER_MANUAL to set non-empty.
    if (dto.projectCode !== undefined) {
      const pc = dto.projectCode == null ? null : String(dto.projectCode).trim();
      if (pc && !this.hasPerm(user, "PROJECT_NUMBER_MANUAL")) {
        throw new BadRequestException("Missing PROJECT_NUMBER_MANUAL permission.");
      }
      (data as any).projectCode = pc ? pc : null;
    }

    // Masters (validate in-tenant)
    if (dto.advertiserGroupId !== undefined) {
      if (dto.advertiserGroupId) await this.assertMasterId(accountId, "advertiserGroup", dto.advertiserGroupId);
      (data as any).advertiserGroupId = dto.advertiserGroupId;
    }
    if (dto.advertiserId !== undefined) {
      if (dto.advertiserId) await this.assertMasterId(accountId, "advertiser", dto.advertiserId);
      (data as any).advertiserId = dto.advertiserId;
    }
    if (dto.brandId !== undefined) {
      if (dto.brandId) await this.assertMasterId(accountId, "brand", dto.brandId);
      (data as any).brandId = dto.brandId;
    }
    if (dto.productCategoryId !== undefined) {
      if (dto.productCategoryId) await this.assertMasterId(accountId, "productCategory", dto.productCategoryId);
      (data as any).productCategoryId = dto.productCategoryId;
    }

    if (dto.senderAccountId !== undefined) {
      const nextSenderAccountId = dto.senderAccountId;
      const currentSenderAccountId = (existing as any).senderAccountId ? String((existing as any).senderAccountId) : null;
      if (nextSenderAccountId && nextSenderAccountId !== currentSenderAccountId) {
        await this.assertSenderAccount(accountId, nextSenderAccountId);
      }
      (data as any).senderAccountId = nextSenderAccountId;
    }

    if ((dto as any).billablePartyId !== undefined) {
      const nextBillablePartyId = (dto as any).billablePartyId;
      if (nextBillablePartyId) {
        const billableParty = await this.prisma.billableParty.findFirst({
          where: { id: nextBillablePartyId, accountId, status: "ACTIVE" as any },
          select: { id: true },
        }).catch(() => null);
        if (!billableParty) throw new BadRequestException("Invalid billable party for this account.");
      }
      (data as any).billablePartyId = nextBillablePartyId;
    }

    // Agencies/teams (validate types + team belongs to agency)
    const pair = async (
      agencyKey: "mediaAgencyId" | "creativeAgencyId" | "productionHouseId" | "postHouseId" | "audioAgencyId",
      teamKey: "mediaAgencyTeamId" | "creativeAgencyTeamId" | "productionHouseTeamId" | "postHouseTeamId" | "audioAgencyTeamId",
      expectedType: AgencyType,
    ) => {
      const agencyProvided = (dto as any)[agencyKey] !== undefined;
      const teamProvided = (dto as any)[teamKey] !== undefined;

      const newAgency = agencyProvided ? (dto as any)[agencyKey] : (existing as any)[agencyKey];
      const oldAgency = (existing as any)[agencyKey];
      const newTeam = teamProvided ? (dto as any)[teamKey] : (existing as any)[teamKey];

      // if caller tries to set a team without any agency context
      if (!newAgency && newTeam) {
        throw new BadRequestException(`Cannot set ${teamKey} without ${agencyKey}`);
      }

      if (agencyProvided) {
        (data as any)[agencyKey] = (dto as any)[agencyKey];
      }

      // clearing agency => clear team
      if (agencyProvided && !(dto as any)[agencyKey]) {
        (data as any)[teamKey] = null;
        return;
      }

      // validate agency type when explicitly set
      if (agencyProvided && (dto as any)[agencyKey]) {
        await this.assertAgency(accountId, (dto as any)[agencyKey], expectedType);
      }

      if (teamProvided) {
        (data as any)[teamKey] = (dto as any)[teamKey];
      } else if (agencyProvided && newAgency !== oldAgency) {
        // agency changed but team not provided => clear to avoid mismatch
        (data as any)[teamKey] = null;
      }

      // validate team belongs to the effective agency
      const effectiveTeam = teamProvided ? (dto as any)[teamKey] : newTeam;
      if (effectiveTeam && newAgency) {
        await this.assertTeam(accountId, effectiveTeam, newAgency);
      }
    };

    await pair("mediaAgencyId", "mediaAgencyTeamId", AgencyType.MEDIA);
    await pair("creativeAgencyId", "creativeAgencyTeamId", AgencyType.CREATIVE);
    await pair("productionHouseId", "productionHouseTeamId", AgencyType.PRODUCTION_HOUSE);
    await pair("postHouseId", "postHouseTeamId", AgencyType.POST_HOUSE);
    await pair("audioAgencyId", "audioAgencyTeamId", AgencyType.AUDIO);

    // Uploader: any AgencyType allowed
    const uploaderAgencyProvided = (dto as any).uploaderAgencyId !== undefined;
    const uploaderTeamProvided = (dto as any).uploaderAgencyTeamId !== undefined;

    const oldUploaderAgency = (existing as any).uploaderAgencyId;
    const oldUploaderTeam = (existing as any).uploaderAgencyTeamId;

    const newUploaderAgency = uploaderAgencyProvided ? (dto as any).uploaderAgencyId : oldUploaderAgency;
    const newUploaderTeam = uploaderTeamProvided ? (dto as any).uploaderAgencyTeamId : oldUploaderTeam;

    if (!newUploaderAgency && newUploaderTeam) {
      throw new BadRequestException("Cannot set uploaderAgencyTeamId without uploaderAgencyId");
    }

    if (uploaderAgencyProvided) {
      (data as any).uploaderAgencyId = (dto as any).uploaderAgencyId;
    }

    if (uploaderAgencyProvided && !(dto as any).uploaderAgencyId) {
      (data as any).uploaderAgencyTeamId = null;
    } else if (uploaderTeamProvided) {
      (data as any).uploaderAgencyTeamId = (dto as any).uploaderAgencyTeamId;
    } else if (uploaderAgencyProvided && newUploaderAgency !== oldUploaderAgency) {
      (data as any).uploaderAgencyTeamId = null;
    }

    if (uploaderAgencyProvided && (dto as any).uploaderAgencyId) {
      const a = await this.prisma.agency.findFirst({ where: { id: (dto as any).uploaderAgencyId, accountId }, select: { id: true } });
      if (!a) throw new BadRequestException("Invalid uploader agency for this account.");
    }

    const effectiveUploaderTeam = uploaderTeamProvided ? (dto as any).uploaderAgencyTeamId : newUploaderTeam;
    if (effectiveUploaderTeam && newUploaderAgency) {
      await this.assertTeam(accountId, effectiveUploaderTeam, newUploaderAgency);
    }

    if (dto.notification !== undefined) {
      const notif = dto.notification ?? {};
      const notifData = {
        notifyAdvertiserGroup: notif.notifyAdvertiserGroup ?? true,
        notifyAdvertiser: notif.notifyAdvertiser ?? true,
        notifyBrand: notif.notifyBrand ?? true,
        notifyMediaAgency: notif.notifyMediaAgency ?? true,
        notifyCreativeAgency: notif.notifyCreativeAgency ?? true,
        notifyProductionHouse: notif.notifyProductionHouse ?? true,
        notifyPostHouse: notif.notifyPostHouse ?? true,
        notifyAudioAgency: notif.notifyAudioAgency ?? true,
        extraEmails: uniqEmails(notif.extraEmails),
        enabledTypes: sanitizeExplicitEnabledTypes(notif.enabledTypes),
      };

      (data as any).notificationConfig = {
        upsert: {
          create: {
            ...notifData,
            allowThirdPartyEditBase: false,
            allowThirdPartyAddExtras: true,
          },
          update: notifData,
        },
      };
    }

    try {
      await this.prisma.project.update({ where: { id: projectId }, data });
      return this.getProjectDetails(accountId, projectId);
    } catch (e: any) {
      if (e?.code === "P2002") {
        throw new ConflictException("Project name or code already exists in this account.");
      }
      throw e;
    }
  }

  /**
   * Commit gating (used by commit + workflow)
   * NOTE: we enforce SOURCE must be UPLOADED (not just exists).
   */
  private async computeCommitGates(projectId: string, onlyUnsent: boolean, accountId: string) {
    const project = await this.prisma.project.findFirst({
      where: { id: projectId, accountId },
      select: { id: true, status: true, approvalsEnabled: true, approvalsPhase: true, approvalTemplateId: true },
    });
    if (!project) throw new NotFoundException("Project not found");

    const plannerWhere: Prisma.PlanningEntryWhereInput = {
      projectId,
      accountId,
      selected: true,
    };

    const entries = await this.prisma.planningEntry.findMany({
      where: plannerWhere,
      select: { id: true, creativeId: true, channelId: true, slaId: true },
    });

    let entriesToCommit = entries;

    if (onlyUnsent) {
      const sent = await this.prisma.planLine.findMany({
        where: {
          accountId,
          planVersion: { projectId },
        },
        select: { creativeId: true, channelId: true },
      });
      const committedSet = new Set(sent.map((x) => `${x.creativeId}:${x.channelId}`));
      entriesToCommit = entries.filter((e) => !committedSet.has(`${e.creativeId}:${e.channelId}`));
    }

    if (entriesToCommit.length === 0) {
      const msg = entries.length === 0 ? "No planner selections to commit." : "No new planner selections to commit.";
      return {
        project,
        entries: entriesToCommit,
        ok: false,
        reasons: [{ code: "NO_PLANNER", message: msg }] as GateFail[],
      };
    }


    const creativeIds = Array.from(new Set(entriesToCommit.map((e) => e.creativeId)));

    const creatives = await this.prisma.creative.findMany({
      where: { accountId, id: { in: creativeIds } },
      select: {
        id: true,
        name: true,
        approvals: true,
        qcStatus: true,
        assets: {
          where: { type: "SOURCE" },
          select: { uploadStatus: true },
        },
      },
    });

    const reasons: GateFail[] = [];

    for (const c of creatives) {
      const src = c.assets?.[0];
      const srcOk = src?.uploadStatus === "UPLOADED";
      if (!srcOk) reasons.push({ code: "UPLOAD_MISSING", message: `Creative ${c.name} SOURCE not uploaded.` });
    }

    for (const c of creatives) {
      if (c.qcStatus !== CreativeQcStatus.PASSED) {
        reasons.push({ code: "QC_NOT_PASSED", message: `Creative ${c.name} QC is ${c.qcStatus}.` });
      }
    }

    if (project.approvalsEnabled && project.approvalsPhase !== "POST") {
      const template =
        ((project as any).approvalTemplateId
          ? await this.prisma.approvalTemplate.findFirst({
              where: { id: (project as any).approvalTemplateId, accountId },
              select: { id: true },
            })
          : null) ??
        (await this.prisma.approvalTemplate.findFirst({
          where: { accountId, isActive: true },
          select: { id: true },
        }));
      if (!template) {
        reasons.push({ code: "APPROVAL_TEMPLATE_MISSING", message: "Approvals are enabled but no active approval template is configured." });
      }
    }

    return { project, entries: entriesToCommit, ok: reasons.length === 0, reasons };
  }

  /**
   * Main commit action
   */
  async commitProject(projectId: string, opts: { onlyUnsent: boolean }, user: AuthUser) {
    const { project, entries, ok, reasons } = await this.computeCommitGates(projectId, opts.onlyUnsent, user.accountId);
    if (!ok) throw new BadRequestException({ message: "Commit blocked", reasons });

    const approvalGateAfterCommit = !!project?.approvalsEnabled && project?.approvalsPhase !== "POST";

    // Use a single commit-time reference so SLA-based autoSendAt is stable and UTC-based.
    const commitTime = new Date();

    const nextVersion =
      (await this.prisma.planVersion.aggregate({
        where: { projectId, accountId: user.accountId },
        _max: { version: true },
      }))._max.version ?? 0;

    const versionToCreate = nextVersion + 1;

    const commitPresetRequests: Array<{ creativeId: string; destinationId: string | null; presetKey: string }> = [];

    const created = await this.prisma.$transaction(async (tx) => {
      await tx.planVersion.updateMany({
        where: { projectId, accountId: user.accountId, isActive: true },
        data: { isActive: false },
      });

      const pv = await tx.planVersion.create({
        data: {
          accountId: user.accountId,
          projectId,
          version: versionToCreate,
          isActive: true,
        },
      });

      // Preload SLAs used by the committed entries so we can compute per-line autoSendAt.
      const slaIds = Array.from(new Set(entries.map((e) => e.slaId).filter((x): x is string => typeof x === "string" && x.length > 0)));
      const slas = slaIds.length
        ? await tx.sla.findMany({
            where: { accountId: user.accountId, id: { in: slaIds } },
            select: { id: true, hoursTarget: true, description: true },
          })
        : [];
      const slaTargetMinutes = new Map<string, number>(slas.map((s) => [s.id, parseSlaTargetMinutes(s)]));

      const addMinutesUtc = (d: Date, minutes: number) => new Date(d.getTime() + minutes * 60 * 1000);

      await tx.planLine.createMany({
        data: entries.map((e) => ({
          accountId: user.accountId,
          planVersionId: pv.id,
          creativeId: e.creativeId,
          channelId: e.channelId,
          slaId: e.slaId ?? null,
          // SLA-based auto-send schedule. If slaId is missing or invalid, leave null (no auto-send).
          autoSendAt: approvalGateAfterCommit
            ? null
            : e.slaId && slaTargetMinutes.has(e.slaId)
              ? addMinutesUtc(commitTime, slaTargetMinutes.get(e.slaId) as number)
              : null,
        })),
      });

      if (!approvalGateAfterCommit) {
        const channelIds = Array.from(new Set(entries.map((e) => e.channelId).filter((x): x is string => typeof x === "string" && x.length > 0)));
        const channels = channelIds.length
          ? await tx.channel.findMany({
              where: { accountId: user.accountId, id: { in: channelIds } },
              select: { id: true, destinationId: true, config: true },
            })
          : [];
        const channelById = new Map(channels.map((c: any) => [String(c.id), c] as const));
        const commitPresetSeen = new Set<string>();
        for (const entry of entries) {
          const channel = channelById.get(String(entry.channelId));
          if (!channel) continue;
          const selectedPreset = await resolveChannelCommitPreset(this.prisma, user.accountId, channel);
          if (!selectedPreset?.key) continue;
          const dedupe = `${entry.creativeId}::${selectedPreset.key}`;
          if (commitPresetSeen.has(dedupe)) continue;
          commitPresetSeen.add(dedupe);
          commitPresetRequests.push({
            creativeId: String(entry.creativeId),
            destinationId: selectedPreset.destinationId ?? null,
            presetKey: selectedPreset.key,
          });
        }
      }

      return pv;
    });

    if (approvalGateAfterCommit) {
      const creativeIds = Array.from(new Set(entries.map((e) => String(e.creativeId)).filter(Boolean)));
      await this.approvalsService.ensureRequestsForCommittedCreatives(user.accountId, projectId, creativeIds, project.approvalsPhase ?? "PRE").catch((e) => { throw e; });
    } else {
      for (const req of commitPresetRequests) {
        await ensureCreativePresetJob(this.prisma, this.bus, {
          accountId: user.accountId,
          creativeId: req.creativeId,
          destinationId: req.destinationId ?? null,
          presetKey: req.presetKey,
          userId: user.userId ?? user.id ?? null,
        }).catch(() => undefined);
      }
    }

    await this.notifications
      .emitType5Committed(user.accountId, projectId, created.version, {
        userId: (user as any).userId ?? (user as any).id ?? null,
        displayName: (user as any).displayName ?? null,
        email: (user as any).email ?? null,
      })
      .catch(() => undefined);

    return {
      planVersionId: created.id,
      version: created.version,
      committedLines: entries.length,
      transcodeQueued: approvalGateAfterCommit ? 0 : commitPresetRequests.length,
      approvalsPending: approvalGateAfterCommit,
    };
  }

  /**
   * Used by FE stepper to show OK/Pending states.
   */
  async getWorkflow(projectId: string, user: AuthUser) {
    const project = await this.prisma.project.findFirst({
      where: { id: projectId, accountId: user.accountId },
      select: { id: true, approvalsEnabled: true, approvalsPhase: true, status: true },
    });
    if (!project) throw new NotFoundException("Project not found");

    const activePlan = await this.prisma.planVersion.findFirst({
      where: { projectId, accountId: user.accountId, isActive: true },
      include: { lines: true },
    });

    const commit = await this.computeCommitGates(projectId, true, user.accountId);

    const sendReasons: GateFail[] = [];
    if (!activePlan) sendReasons.push({ code: "NO_COMMIT", message: "No committed plan exists. Commit first." });

    const unsentLines = activePlan ? activePlan.lines.filter((l) => l.sentAt == null) : [];
    if (activePlan && unsentLines.length === 0) {
      sendReasons.push({ code: "NOTHING_TO_SEND", message: "All plan lines are already sent." });
    }

    return {
      steps: {
        creatives: { ok: true },
        qc: { ok: !commit.reasons.some((r) => r.code === "QC_NOT_PASSED") },
        approvals: { ok: !project.approvalsEnabled || project.approvalsPhase === "POST" || !commit.reasons.some((r) => r.code === "APPROVAL_NOT_DONE") },
        planner: { ok: !commit.reasons.some((r) => r.code === "NO_PLANNER") },
        commit: { ok: !!activePlan },
        send: { ok: sendReasons.length === 0 },
      },
      actions: {
        canCommit: commit.ok,
        commitReasons: commit.reasons,
        canSend: sendReasons.length === 0,
        sendReasons,
      },
      activePlan: activePlan ? { id: activePlan.id, version: activePlan.version, unsentLines: unsentLines.length } : null,
    };
  }

  async setStatus(accountId: string, projectId: string, status: "OPEN" | "CLOSED", actorUserId?: string) {
    const project = await this.prisma.project.findFirst({
      where: { id: projectId, accountId },
      select: { id: true, status: true },
    });
    if (!project) throw new NotFoundException("Project not found");

    const isClosing = status === "CLOSED";

    return this.prisma.project.update({
      where: { id: projectId },
      data: {
        status,
        closedAt: isClosing ? new Date() : null,
        closedByUserId: isClosing ? actorUserId ?? null : null,
      } as any,
      select: { id: true, status: true, closedAt: true, closedByUserId: true, updatedAt: true },
    });
  }


  async deleteProject(accountId: string, projectId: string) {
    const project = await this.prisma.project.findFirst({
      where: { id: projectId, accountId },
      select: { id: true, name: true, status: true },
    });
    if (!project) throw new NotFoundException("Project not found");

    try {
      await this.prisma.project.delete({ where: { id: projectId } });
      return { ok: true, id: projectId };
    } catch (e: any) {
      if (e?.code === "P2003" || e?.code === "P2014") {
        throw new BadRequestException(
          "This project cannot be deleted because it already has related data. Close the project instead, or remove dependent records first.",
        );
      }
      throw e;
    }
  }

  /**
   * ---- QC Gate API for FE + for enforcing Send later ----
   * Commit scope: planner selected entries
   * Send scope: active plan unsent lines
   */
  private async qcGateForCreativeIds(accountId: string, creativeIds: string[]): Promise<QcGateResult> {
    if (!creativeIds.length) return { ok: true, blockers: [] };

    const creatives = await this.prisma.creative.findMany({
      where: { accountId, id: { in: creativeIds } },
      select: {
        id: true,
        valid: true,
        caption: true,
        qcStatus: true,
        qcNotes: true,
        assets: {
          where: { type: "SOURCE" },
          select: { uploadStatus: true },
        },
      },
    });

    const blockers: QcGateBlocker[] = creatives
      .map((c) => {
        const src = c.assets?.[0];
        const srcOk = src?.uploadStatus === "UPLOADED";
        const qcOk = c.qcStatus === CreativeQcStatus.PASSED;

        return {
          creativeId: c.id,
          valid: c.valid ?? null,
          caption: c.caption ?? null,
          missingSource: !srcOk,
          qcStatus: (c.qcStatus as any) ?? null,
          qcNotes: c.qcNotes ?? null,
        };
      })
      .filter((b) => b.missingSource || b.qcStatus !== "PASSED");

    return { ok: blockers.length === 0, blockers };
  }

  async getQcGateForCommit(accountId: string, projectId: string): Promise<QcGateResult> {
    const entries = await this.prisma.planningEntry.findMany({
      where: { accountId, projectId, selected: true },
      select: { creativeId: true },
    });
    const creativeIds = Array.from(new Set(entries.map((e) => e.creativeId)));
    return this.qcGateForCreativeIds(accountId, creativeIds);
  }

  async getQcGateForSend(accountId: string, projectId: string): Promise<QcGateResult> {
    const active = await this.prisma.planVersion.findFirst({
      where: { accountId, projectId, isActive: true },
      select: { id: true },
    });
    if (!active) return { ok: true, blockers: [] };

    const lines = await this.prisma.planLine.findMany({
      where: { accountId, planVersionId: active.id, sentAt: null },
      select: { creativeId: true },
    });

    const creativeIds = Array.from(new Set(lines.map((l) => l.creativeId)));
    return this.qcGateForCreativeIds(accountId, creativeIds);
  }

  /**
   * Optional: use these later in Orders/Send flow
   */
  async assertQcGateForSend(accountId: string, projectId: string) {
    const gate = await this.getQcGateForSend(accountId, projectId);
    if (!gate.ok) {
      throw new ConflictException({
        code: "QC_GATE_SEND",
        message: "Send blocked: uploads/QC not complete for some creatives.",
        ...gate,
      });
    }
  }

}
