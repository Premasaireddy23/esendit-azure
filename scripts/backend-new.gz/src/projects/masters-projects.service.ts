import { Injectable } from "@nestjs/common";
import { PrismaService } from "../common/prisma/prisma.service";
import { ProjectAccessService } from "../common/project-access/project-access.service";
import type { AuthUser } from "../common/auth/current-user.decorator";
import { AccountType, Prisma } from "@prisma/client"; // ✅ add

@Injectable()
export class MastersProjectsService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly projectAccess: ProjectAccessService,
  ) {}

  private parseAccountType(v?: string): AccountType | undefined {
    if (!v) return undefined;
    const key = v.trim().toUpperCase();
    // Prisma enum values are the values of AccountType
    return (Object.values(AccountType) as string[]).includes(key) ? (key as AccountType) : undefined;
  }

  async listProjects(
    user: AuthUser | any,
    opts: {
      q?: string;
      accountType?: string;
      status?: "OPEN" | "CLOSED";
      sort?: "createdAt" | "name" | "status" | "projectNumber";
      order?: "asc" | "desc";
      take?: number;
      skip?: number;
    } = {},
  ) {
    const accountId = String(user?.accountId || "").trim();
    const take = Math.min(Math.max(opts.take ?? 50, 1), 200);
    const skip = Math.max(opts.skip ?? 0, 0);

    const sort = (opts.sort ?? "createdAt") as "createdAt" | "name" | "status" | "projectNumber";
    const order = (opts.order ?? "desc") as "asc" | "desc";

    const acctType = this.parseAccountType(opts.accountType); // ✅

    const where: Prisma.ProjectWhereInput = {
      accountId,
      ...(opts.status ? { status: opts.status } : {}),
      ...(opts.q ? { name: { contains: opts.q, mode: "insensitive" } } : {}),
      ...(acctType ? { account: { type: acctType } } : {}), // ✅ only if valid
    };

    const [total, items] = await this.prisma.$transaction([
      this.prisma.project.count({ where }),
      this.prisma.project.findMany({
        where,
        orderBy: { [sort]: order },
        take,
        skip,
        select: {
          id: true,
          name: true,
          projectCode: true,
          projectNumber: true,
          status: true,
          createdAt: true,
          updatedAt: true,
          account: { select: { name: true, type: true } },

          advertiserGroup: { select: { id: true, name: true, emails: true } },
          advertiser: { select: { id: true, name: true, emails: true, contactNo: true, address: true, gstNumber: true, panNumber: true } },
          brand: { select: { id: true, name: true, address: true, gstNumber: true, panNumber: true } },
          productCategory: { select: { id: true, name: true } },
          ...( {
            billableParty: { select: { id: true, name: true, code: true, emails: true, address: true, gstNumber: true, panNumber: true, paymentTerms: true } },
            billablePartyId: true,
            mediaAgency: { select: { id: true, name: true, type: true, emails: true, contactNo: true, address: true, gstNumber: true, panNumber: true } },
            mediaAgencyTeam: { select: { id: true, name: true, agencyId: true, emails: true, contactNo: true, address: true, gstNumber: true, panNumber: true } },
            creativeAgency: { select: { id: true, name: true, type: true, emails: true, contactNo: true, address: true, gstNumber: true, panNumber: true } },
            creativeAgencyTeam: { select: { id: true, name: true, agencyId: true, emails: true, contactNo: true, address: true, gstNumber: true, panNumber: true } },
            productionHouse: { select: { id: true, name: true, type: true, emails: true, contactNo: true, address: true, gstNumber: true, panNumber: true } },
            productionHouseTeam: { select: { id: true, name: true, agencyId: true, emails: true, contactNo: true, address: true, gstNumber: true, panNumber: true } },
            postHouse: { select: { id: true, name: true, type: true, emails: true, contactNo: true, address: true, gstNumber: true, panNumber: true } },
            postHouseTeam: { select: { id: true, name: true, agencyId: true, emails: true, contactNo: true, address: true, gstNumber: true, panNumber: true } },
            audioAgency: { select: { id: true, name: true, type: true, emails: true, contactNo: true, address: true, gstNumber: true, panNumber: true } },
            audioAgencyTeam: { select: { id: true, name: true, agencyId: true, emails: true, contactNo: true, address: true, gstNumber: true, panNumber: true } },
            uploaderAgency: { select: { id: true, name: true, type: true, emails: true, contactNo: true, address: true, gstNumber: true, panNumber: true } },
            uploaderAgencyTeam: { select: { id: true, name: true, agencyId: true, emails: true, contactNo: true, address: true, gstNumber: true, panNumber: true } },
          } as any),
        },
      }),
    ]);

    if (this.projectAccess.hasGlobalProjectRead(user)) return { total, items };

    const scopedItems = await this.projectAccess.filterProjectsForUser(user, items as any[]);
    return { total: scopedItems.length, items: scopedItems };
  }
}
