import { Type } from "class-transformer";
import { IsArray, IsBoolean, IsEmail, IsInt, IsOptional, IsString, IsUUID, Max, MaxLength, Min, MinLength, ValidateNested } from "class-validator";

/**
 * Used by "Edit Project" page.
 * All fields are optional: only provided fields will be updated.
 * NOTE: passing `null` for *_Id clears the value.
 */

export class UpdateProjectNotificationDto {
  @IsOptional() @IsBoolean() notifyAdvertiserGroup?: boolean;
  @IsOptional() @IsBoolean() notifyAdvertiser?: boolean;
  @IsOptional() @IsBoolean() notifyBrand?: boolean;
  @IsOptional() @IsBoolean() notifyMediaAgency?: boolean;
  @IsOptional() @IsBoolean() notifyCreativeAgency?: boolean;
  @IsOptional() @IsBoolean() notifyProductionHouse?: boolean;
  @IsOptional() @IsBoolean() notifyPostHouse?: boolean;
  @IsOptional() @IsBoolean() notifyAudioAgency?: boolean;

  @IsOptional()
  @IsArray()
  @IsEmail({}, { each: true })
  extraEmails?: string[];

  @IsOptional()
  @IsArray()
  @IsInt({ each: true })
  @Min(1, { each: true })
  @Max(11, { each: true })
  enabledTypes?: number[];
}

export class UpdateProjectDto {
  @IsOptional()
  @IsString()
  @MinLength(1)
  @MaxLength(200)
  name?: string;

  @IsOptional()
  @IsString()
  @MaxLength(50)
  projectCode?: string | null;

  // Masters
  @IsOptional() @IsUUID() advertiserGroupId?: string | null;
  @IsOptional() @IsUUID() advertiserId?: string | null;
  @IsOptional() @IsUUID() brandId?: string | null;
  @IsOptional() @IsUUID() productCategoryId?: string | null;

  @IsOptional() @IsUUID() senderAccountId?: string | null;
  @IsOptional() @IsUUID() billablePartyId?: string | null;

  // Agencies/teams
  @IsOptional() @IsUUID() mediaAgencyId?: string | null;
  @IsOptional() @IsUUID() mediaAgencyTeamId?: string | null;
  @IsOptional() @IsUUID() creativeAgencyId?: string | null;
  @IsOptional() @IsUUID() creativeAgencyTeamId?: string | null;
  @IsOptional() @IsUUID() productionHouseId?: string | null;
  @IsOptional() @IsUUID() productionHouseTeamId?: string | null;
  @IsOptional() @IsUUID() postHouseId?: string | null;
  @IsOptional() @IsUUID() postHouseTeamId?: string | null;
  @IsOptional() @IsUUID() audioAgencyId?: string | null;
  @IsOptional() @IsUUID() audioAgencyTeamId?: string | null;

  // Uploader + remarks
  @IsOptional() @IsUUID() uploaderAgencyId?: string | null;
  @IsOptional() @IsUUID() uploaderAgencyTeamId?: string | null;

  @IsOptional()
  @IsString()
  @MaxLength(2000)
  remarks?: string | null;

  @IsOptional()
  @IsBoolean()
  approvalsEnabled?: boolean;

  @IsOptional()
  @ValidateNested()
  @Type(() => UpdateProjectNotificationDto)
  notification?: UpdateProjectNotificationDto;
}
