import { IsBoolean, IsOptional, IsString, IsUUID, MinLength } from "class-validator";

export class CreateProjectDto {
  @IsString()
  @MinLength(1)
  name!: string;

  @IsOptional()
  @IsBoolean()
  approvalsEnabled?: boolean;

  @IsOptional()
  @IsUUID()
  senderAccountId?: string;

  @IsOptional()
  @IsUUID()
  billablePartyId?: string;
}
