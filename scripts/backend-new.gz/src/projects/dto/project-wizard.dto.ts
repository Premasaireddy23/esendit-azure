import {
  IsArray,
  IsBoolean,
  IsEmail,
  IsInt,
  IsOptional,
  IsString,
  IsUUID,
  Max,
  MaxLength,
  Min,
  ValidateNested,
} from "class-validator";
import { Type } from "class-transformer";

export class ProjectWizardNotificationDto {
  @IsOptional() @IsBoolean() notifyAdvertiserGroup?: boolean;
  @IsOptional() @IsBoolean() notifyAdvertiser?: boolean;
  @IsOptional() @IsBoolean() notifyBrand?: boolean;
  @IsOptional() @IsBoolean() notifyMediaAgency?: boolean;
  @IsOptional() @IsBoolean() notifyCreativeAgency?: boolean;
  @IsOptional() @IsBoolean() notifyPostHouse?: boolean;
  @IsOptional() @IsBoolean() notifyAudioAgency?: boolean;
  @IsOptional() @IsBoolean() notifyProductionHouse?: boolean;

  // Extra recipients (emails)
  @IsOptional()
  @IsArray()
  @IsEmail({}, { each: true })
  extraEmails?: string[];

  // Notification types 1..11
  @IsOptional()
  @IsArray()
  @IsInt({ each: true })
  @Min(1, { each: true })
  @Max(11, { each: true })
  enabledTypes?: number[];

  // Internal-only toggles (wizard can expose later)
  @IsOptional() @IsBoolean() allowThirdPartyEditBase?: boolean;
  @IsOptional() @IsBoolean() allowThirdPartyAddExtras?: boolean;
}

export class CreateProjectWizardDto {
  // Manual project code if user has PROJECT_NUMBER_MANUAL. If omitted, auto-generate (PROJECT_NUMBER_AUTO).
  @IsOptional()
  @IsString()
  @MaxLength(50)
  projectCode?: string;

  @IsString()
  @MaxLength(200)
  name!: string;

  // Required masters (spec)
  @IsUUID() advertiserGroupId!: string;
  @IsUUID() advertiserId!: string;
  @IsUUID() brandId!: string;
  @IsUUID() productCategoryId!: string;

  @IsOptional() @IsUUID() senderAccountId?: string;
  @IsOptional() @IsUUID() billablePartyId?: string;

  // Agencies/teams (optional)
  @IsOptional() @IsUUID() mediaAgencyId?: string;
  @IsOptional() @IsUUID() mediaAgencyTeamId?: string;
  @IsOptional() @IsUUID() creativeAgencyId?: string;
  @IsOptional() @IsUUID() creativeAgencyTeamId?: string;
  @IsOptional() @IsUUID() productionHouseId?: string;
  @IsOptional() @IsUUID() productionHouseTeamId?: string;
  @IsOptional() @IsUUID() postHouseId?: string;
  @IsOptional() @IsUUID() postHouseTeamId?: string;
  @IsOptional() @IsUUID() audioAgencyId?: string;
  @IsOptional() @IsUUID() audioAgencyTeamId?: string;

  // NEW: uploader (Agency + Team) + remarks
  @IsOptional() @IsUUID() uploaderAgencyId?: string;
  @IsOptional() @IsUUID() uploaderAgencyTeamId?: string;

  @IsOptional()
  @IsString()
  @MaxLength(2000)
  remarks?: string;

  @IsOptional()
  @ValidateNested()
  @Type(() => ProjectWizardNotificationDto)
  notification?: ProjectWizardNotificationDto;

  @IsOptional()
  @IsBoolean()
  approvalsEnabled?: boolean;
}
