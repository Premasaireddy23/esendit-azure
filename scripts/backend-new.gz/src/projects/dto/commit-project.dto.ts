import { IsBoolean, IsOptional } from "class-validator";

export class CommitProjectDto {
  // default true: recommit includes only unsent planner entries
  @IsOptional()
  @IsBoolean()
  onlyUnsent?: boolean;
}
