import { IsEnum, IsOptional, IsString, IsUUID, MaxLength } from "class-validator";
import { AgencyType } from "@prisma/client";

export class InlineCreateNamedDto {
  @IsString()
  @MaxLength(200)
  name!: string;
}

export class InlineCreateAdvertiserDto {
  @IsString()
  @MaxLength(200)
  name!: string;

  @IsOptional()
  @IsUUID()
  advertiserGroupId?: string;
}

export class InlineCreateBrandDto {
  @IsString()
  @MaxLength(200)
  name!: string;

  @IsUUID()
  advertiserId!: string;
}

export class InlineCreateAgencyDto {
  @IsEnum(AgencyType)
  type!: AgencyType;

  @IsString()
  @MaxLength(200)
  name!: string;
}

export class InlineCreateAgencyTeamDto {
  @IsUUID()
  agencyId!: string;

  @IsString()
  @MaxLength(200)
  name!: string;
}
