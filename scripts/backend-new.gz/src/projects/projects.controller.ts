import { Body, Controller, Delete, ForbiddenException, Get, Param, Patch, Post, Query, UseGuards } from "@nestjs/common";
import { CreateProjectDto } from "./dto/create-project.dto";
import { CommitProjectDto } from "./dto/commit-project.dto";
import { UpdateProjectDto } from "./dto/update-project.dto";
import { ProjectsService } from "./projects.service";

import { JwtAuthGuard } from "../common/auth/jwt-auth.guard";
import { PermissionsGuard } from "../common/auth/permissions.guard";
import { CurrentUser, AuthUser } from "../common/auth/current-user.decorator";
import { RequirePermissions } from "../common/auth/require-permissions.decorator";
import { RequireAnyPermissions } from "../common/auth/require-any-permissions.decorator";
import { ProjectAccessService } from "../common/project-access/project-access.service";


@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller("projects")
export class ProjectsController {
  constructor(
    private readonly projects: ProjectsService,
    private readonly projectAccess: ProjectAccessService,
  ) {}

  @Get("meta")
  @RequireAnyPermissions("PROJECT_READ", "page:projects", "action:projects:scoped:read")
  getEditMeta(@CurrentUser() user: AuthUser) {
    return this.projects.getProjectEditMeta(user.accountId);
  }

  /**
   * Project details for "View" drawer + "Edit Project" page.
   */
  @Get(":id")
  @RequireAnyPermissions("PROJECT_READ", "page:projects", "action:projects:scoped:read")
  async getOne(@CurrentUser() user: AuthUser, @Param("id") id: string) {
    await this.projectAccess.assertCanViewProject(user, id);
    return this.projects.getProjectDetails(user.accountId, id, user);
  }

  /**
   * Update project details (Edit Project page).
   */
  @Patch(":id")
  @RequireAnyPermissions("PROJECT_UPDATE", "page:projects", "action:projects:scoped:read")
  async update(@CurrentUser() user: AuthUser, @Param("id") id: string, @Body() dto: UpdateProjectDto) {
    if (!this.projectAccess.hasAnyPerm(user, ["PROJECT_UPDATE", "action:projects:update"])) {
      const access = await this.projectAccess.getProjectAccess(user, id);
      if (!access.canEditProject) throw new ForbiddenException("Unauthorised");
    }
    return this.projects.updateProject(user, id, dto);
  }

  @Post()
  @RequirePermissions("PROJECT_CREATE")
  create(@CurrentUser() user: AuthUser, @Body() dto: CreateProjectDto) {
    return this.projects.createProject({
      accountId: user.accountId,
      name: dto.name,
      approvalsEnabled: (dto as any).approvalsEnabled ?? false,
      senderAccountId: (dto as any).senderAccountId ?? undefined,
      billablePartyId: (dto as any).billablePartyId ?? undefined,
    });
  }

  @Get(":id/workflow")
  @RequireAnyPermissions("PROJECT_READ", "page:projects", "action:projects:scoped:read") // ✅ was PROJECT_VIEW
  async workflow(@CurrentUser() user: AuthUser, @Param("id") id: string) {
    await this.projectAccess.assertCanViewProject(user, id);
    return this.projects.getWorkflow(id, user);
  }

  @Get(":id/qc-gate")
  @RequireAnyPermissions("PROJECT_READ", "page:projects", "action:projects:scoped:read") // ✅ was PROJECT_VIEW
  async qcGate(
    @CurrentUser() user: AuthUser,
    @Param("id") projectId: string,
    @Query("scope") scope: "commit" | "send" = "commit",
  ) {
    await this.projectAccess.assertCanViewProject(user, projectId);
    if (scope === "send") return this.projects.getQcGateForSend(user.accountId, projectId);
    return this.projects.getQcGateForCommit(user.accountId, projectId);
  }

  @Get(":id/access")
  @RequireAnyPermissions("PROJECT_READ", "page:projects", "action:projects:scoped:read")
  access(@CurrentUser() user: AuthUser, @Param("id") id: string) {
    return this.projectAccess.getProjectAccess(user, id);
  }

  @Post(":id/commit")
  @RequirePermissions("COMMIT_RUN") // ✅ was PROJECT_COMMIT
  commit(@CurrentUser() user: AuthUser, @Param("id") id: string, @Body() dto: CommitProjectDto) {
    return this.projects.commitProject(id, { onlyUnsent: (dto as any).onlyUnsent ?? true }, user);
  }

  @Post(":id/close")
  @RequirePermissions("PROJECT_CLOSE")
  close(@CurrentUser() user: AuthUser, @Param("id") id: string) {
    return this.projects.setStatus(user.accountId, id, "CLOSED", user.id);
  }

  @Post(":id/reopen")
  @RequirePermissions("PROJECT_REOPEN")
  reopen(@CurrentUser() user: AuthUser, @Param("id") id: string) {
    return this.projects.setStatus(user.accountId, id, "OPEN", user.id);
  }

  @Delete(":id")
  @RequirePermissions("PROJECT_UPDATE")
  remove(@CurrentUser() user: AuthUser, @Param("id") id: string) {
    return this.projects.deleteProject(user.accountId, id);
  }
}
