import { Controller, Get, Query, UseGuards } from "@nestjs/common";
import { JwtAuthGuard } from "../common/auth/jwt-auth.guard";
import { PermissionsGuard } from "../common/auth/permissions.guard";
import { CurrentUser, AuthUser } from "../common/auth/current-user.decorator";
import { RequireAnyPermissions } from "../common/auth/require-any-permissions.decorator";
import { MastersProjectsService } from "./masters-projects.service";

@UseGuards(JwtAuthGuard, PermissionsGuard)
@Controller("masters")
export class MastersProjectsController {
  constructor(private readonly svc: MastersProjectsService) {}

  @Get("projects")
  @RequireAnyPermissions("PROJECT_READ", "page:projects", "action:projects:scoped:read")
  list(
    @CurrentUser() user: AuthUser,
    @Query("q") q?: string,
    @Query("accountType") accountType?: string,
    @Query("status") status?: "OPEN" | "CLOSED",
    @Query("sort") sort?: "createdAt" | "name" | "status" | "projectNumber",
    @Query("order") order?: "asc" | "desc",
    @Query("take") take?: string,
    @Query("skip") skip?: string
  ) {
    return this.svc.listProjects(user, {
      q,
      accountType,
      status,
      sort,
      order,
      take: take ? Number(take) : undefined,
      skip: skip ? Number(skip) : undefined,
    });
  }
}
