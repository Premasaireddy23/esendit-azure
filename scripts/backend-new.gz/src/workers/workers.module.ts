import { Module } from "@nestjs/common";
import { DeliveryWorker } from "./delivery/delivery.worker";
import { HotFolderWorker } from "./hot-folders/hot-folder.worker";
import { AutoSendWorker } from "./auto-send/auto-send.worker";
import { StorageModule } from "../common/storage/storage.module";

@Module({
  imports: [StorageModule],
  providers: [DeliveryWorker, HotFolderWorker, AutoSendWorker],
})
export class WorkersModule {}