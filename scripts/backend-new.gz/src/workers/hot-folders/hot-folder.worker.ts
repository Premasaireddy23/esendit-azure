import { Cron } from "@nestjs/schedule";
import { Injectable, Logger } from "@nestjs/common";
import {
  CreativeAssetType,
  CreativeAssetUploadStatus,
  HotFolderIngestStatus,
  HotFolderSourceType,
  MasterStatus,
  MediaJobStatus,
  MediaJobType,
} from "@prisma/client";
import { PrismaService } from "../../common/prisma/prisma.service";

import * as fs from "node:fs/promises";
import * as path from "node:path";

type MappingSnapshot = {
  creativeId?: string;
  projectId?: string;
  validIdFromFilename?: boolean;
  stripUnderscores?: boolean;
  stripNonAlnum?: boolean;
  // If you want to build VALID = <MMMYY><CAPTION> (caption derived from filename)
  // you can optionally override the month+year part.
  // Example: {"monthYearPrefix":"JAN26"}
  monthYearPrefix?: string;
  // If true (default), we attempt to read the MMMYY prefix from the start of the filename.
  monthYearFromFilename?: boolean;
  // Optional caption transforms before sanitizing (uppercased):
  // - Replace tokens: {"PETROL":"PETRO"}
  // - Strip tokens: ["SEC"]
  captionReplaceTokens?: Record<string, string>;
  captionStripTokens?: string[];
  autoCreateCreative?: boolean;
  enforceMonthYearPrefix?: boolean;
  queueAutoQc?: boolean;
  queueProxy?: boolean;
};

const MONTHS = ["JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"];

function sanitizeToAlnumUpper(s: string): string {
  return String(s || "")
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, "");
}

function extractMonthYearPrefix(raw: string): string | null {
  const s = String(raw || "").toUpperCase();
  const m = s.match(/^([A-Z]{3})(\d{2})/);
  if (!m) return null;
  const mon = m[1];
  if (!MONTHS.includes(mon)) return null;
  return `${mon}${m[2]}`;
}

function applyCaptionTransforms(rawCaption: string, mapping: MappingSnapshot): string {
  let c = String(rawCaption || "").toUpperCase();

  const repl = mapping?.captionReplaceTokens && typeof mapping.captionReplaceTokens === "object" ? mapping.captionReplaceTokens : null;
  if (repl) {
    for (const [from, to] of Object.entries(repl)) {
      const f = String(from || "").toUpperCase();
      if (!f) continue;
      const t = String(to ?? "").toUpperCase();
      c = c.split(f).join(t);
    }
  }

  const strips = Array.isArray(mapping?.captionStripTokens) ? mapping.captionStripTokens : null;
  if (strips) {
    for (const tok of strips) {
      const t = String(tok || "").toUpperCase();
      if (!t) continue;
      c = c.split(t).join("");
    }
  }

  return c;
}

// Derive a VALID from filename.
// Supports:
//  - direct: JAN26JIOBPPETROLMSD10SECTELHD.mov  -> JAN26JIOBPPETROLMSD10SECTELHD
//  - caption-style: JAN26_Jio_BP_Petrol_MSD_10Sec_TEL_HD.mov
//      -> (strip separators + upper) JAN26JIOBPPETROLMSD10SECTELHD
//  - caption-style without prefix in filename:
//      mappingRules.monthYearPrefix = "JAN26" and filename = Jio_BP_Petrol_MSD_10Sec_TEL_HD.mov
//      -> JAN26JIOBPPETROLMSD10SECTELHD
function normalizeValidIdFromFilename(raw: string, mapping: MappingSnapshot): string {
  let v = String(raw || "").trim();
  if (!v) return v;
  v = v.split("/").pop() || v;
  v = v.split("\\").pop() || v;
  v = v.replace(/\.[a-z0-9]{1,8}$/i, "");
  v = v.replace(/\s+/g, "");

  const stripUnderscores = mapping?.stripUnderscores ?? true;
  const stripNonAlnum = mapping?.stripNonAlnum ?? true;
  const monthYearPrefixOverride = mapping?.monthYearPrefix ? sanitizeToAlnumUpper(mapping.monthYearPrefix) : "";
  const monthYearFromFilename = mapping?.monthYearFromFilename ?? true;

  let upper = String(v).toUpperCase();
  if (stripUnderscores) upper = upper.replace(/_/g, "");

  // If caller wants a MMMYY prefix, detect it or use override.
  let prefix = "";
  let captionPart = upper;

  if (monthYearPrefixOverride) {
    prefix = monthYearPrefixOverride;
    if (captionPart.startsWith(prefix)) captionPart = captionPart.slice(prefix.length);
  } else if (monthYearFromFilename) {
    const p = extractMonthYearPrefix(upper);
    if (p) {
      prefix = p;
      captionPart = upper.slice(p.length);
    }
  }

  captionPart = applyCaptionTransforms(captionPart, mapping);

  // Final sanitize
  if (stripNonAlnum) {
    captionPart = captionPart.replace(/[^A-Z0-9]/g, "");
    prefix = prefix.replace(/[^A-Z0-9]/g, "");
  }
  const out = `${prefix}${captionPart}`.toUpperCase();
  return out;
}

function looksLikeMonthYearPrefix(validId: string): boolean {
  // Accept both JAN26|... and JAN26...
  const m = String(validId || "").toUpperCase().match(/^([A-Z]{3})(\d{2})/);
  if (!m) return false;
  return MONTHS.includes(m[1]);
}

function asObj(v: any): any {
  try {
    if (v == null) return {};
    if (typeof v === "string") return JSON.parse(v);
    return v;
  } catch {
    return {};
  }
}

function guessMime(filename: string): string | null {
  const ext = path.extname(filename || "").toLowerCase();
  if (ext === ".mp4") return "video/mp4";
  if (ext === ".mov") return "video/quicktime";
  if (ext === ".mxf") return "application/mxf";
  if (ext === ".wav") return "audio/wav";
  if (ext === ".mp3") return "audio/mpeg";
  return null;
}

@Injectable()
export class HotFolderWorker {
  private readonly log = new Logger(HotFolderWorker.name);
  private running = false;

  constructor(private readonly prisma: PrismaService) {}

  @Cron("*/5 * * * * *")
  async tick() {
    if ((process.env.HOT_FOLDER_WORKER_ENABLED || "true").toLowerCase() === "false") return;
    if (this.running) return;
    this.running = true;
    try {
      await this.scanDue();
      await this.processQueue();
    } catch (e: any) {
      this.log.error(String(e?.message || e || "HOT_FOLDER_TICK_FAILED"));
    } finally {
      this.running = false;
    }
  }

  private stableSec(): number {
    const sec = Number(process.env.HOT_FOLDER_STABLE_SEC || 10);
    return Number.isFinite(sec) ? Math.max(1, sec) : 10;
  }

  private processMax(): number {
    const n = Number(process.env.HOT_FOLDER_PROCESS_MAX || 5);
    return Number.isFinite(n) ? Math.max(1, n) : 5;
  }

  private scanMaxFiles(): number {
    const n = Number(process.env.HOT_FOLDER_SCAN_MAX_FILES || 200);
    return Number.isFinite(n) ? Math.max(10, n) : 200;
  }

  private async scanDue() {
    const now = new Date();
    const cfgs = await this.prisma.hotFolderConfig.findMany({
      where: {
        enabled: true,
        status: MasterStatus.ACTIVE,
        sourceType: HotFolderSourceType.LOCAL_PATH,
      },
      orderBy: { updatedAt: "asc" },
      take: 50,
    });

    for (const cfg of cfgs) {
      const poll = Number((cfg as any).pollIntervalSec || 60);
      const last = (cfg as any).lastScannedAt as Date | null;
      if (last && now.getTime() - new Date(last).getTime() < poll * 1000) continue;

      try {
        await this.scanLocalFolder(cfg, now);
      } catch (e: any) {
        this.log.warn(`scan failed for ${cfg.id}: ${String(e?.message || e || "SCAN_FAILED")}`);
      } finally {
        await this.prisma.hotFolderConfig.update({
          where: { id: cfg.id },
          data: { lastScannedAt: now },
        }).catch(() => undefined);
      }
    }
  }

  private async scanLocalFolder(cfg: any, now: Date) {
    const basePath = String(cfg.basePath || "").trim();
    if (!basePath) return;

    const conn = asObj(cfg.connectionConfig);
    const recursive = !!conn.recursive;
    const allowExts = Array.isArray(conn.allowExts)
      ? conn.allowExts.map((s: any) => String(s).toLowerCase())
      : null;
    const stableSec = Number.isFinite(Number(conn.stableSec)) ? Math.max(1, Number(conn.stableSec)) : this.stableSec();

    await fs.access(basePath);

    const files = await this.listFiles(basePath, recursive, this.scanMaxFiles());

    const rules = asObj(cfg.mappingRules) as MappingSnapshot;
    const mappingBase: MappingSnapshot = {
      creativeId: rules.creativeId,
      projectId: rules.projectId,
      validIdFromFilename: rules.validIdFromFilename,
      stripUnderscores: rules.stripUnderscores,
      stripNonAlnum: rules.stripNonAlnum,
      monthYearPrefix: rules.monthYearPrefix,
      monthYearFromFilename: rules.monthYearFromFilename,
      captionReplaceTokens: rules.captionReplaceTokens,
      captionStripTokens: rules.captionStripTokens,
      autoCreateCreative: rules.autoCreateCreative,
      enforceMonthYearPrefix: rules.enforceMonthYearPrefix,
      queueAutoQc: rules.queueAutoQc,
      queueProxy: rules.queueProxy,
    };

    const createData: any[] = [];

    for (const absPath of files) {
      const rel = path.relative(basePath, absPath).split(path.sep).join("/");
      if (!rel || rel.startsWith("..")) continue;

      if (allowExts && allowExts.length) {
        const ext = path.extname(absPath).toLowerCase();
        if (!allowExts.includes(ext)) continue;
      }

      const st = await fs.stat(absPath);
      if (!st.isFile()) continue;
      if (st.size <= 0) continue;
      if (now.getTime() - st.mtime.getTime() < stableSec * 1000) continue;

      createData.push({
        accountId: cfg.accountId,
        hotFolderId: cfg.id,
        fileKey: rel,
        absPath,
        fileSize: BigInt(st.size),
        mtime: st.mtime,
        status: HotFolderIngestStatus.DISCOVERED,
        mapping: mappingBase as any,
      });

      if (createData.length >= 200) break;
    }

    if (!createData.length) return;

    await this.prisma.hotFolderIngestItem.createMany({
      data: createData,
      skipDuplicates: true,
    });
  }

  private async listFiles(basePath: string, recursive: boolean, max: number): Promise<string[]> {
    const out: string[] = [];

    const walk = async (dir: string, depth: number) => {
      if (out.length >= max) return;
      const ents = await fs.readdir(dir, { withFileTypes: true });
      for (const e of ents) {
        if (out.length >= max) return;
        if (e.name.startsWith(".")) continue;
        const full = path.join(dir, e.name);
        if (e.isDirectory()) {
          if (recursive && depth < 8) await walk(full, depth + 1);
          continue;
        }
        if (e.isFile()) out.push(full);
      }
    };

    await walk(basePath, 0);
    return out;
  }

  private async processQueue() {
    const now = new Date();
    const candidates = await this.prisma.hotFolderIngestItem.findMany({
      where: {
        status: HotFolderIngestStatus.DISCOVERED,
        OR: [{ runAfter: null }, { runAfter: { lte: now } }],
      },
      take: this.processMax(),
      orderBy: [{ createdAt: "asc" }],
    });

    for (const it of candidates) {
      // claim
      const claimed = await this.prisma.hotFolderIngestItem.updateMany({
        where: { id: it.id, status: HotFolderIngestStatus.DISCOVERED },
        data: {
          status: HotFolderIngestStatus.CLAIMED,
          claimedAt: new Date(),
          attempts: { increment: 1 },
        } as any,
      });
      if (claimed.count !== 1) continue;
      await this.processOne(it.id).catch(() => undefined);
    }
  }

  private async ensureMediaJob(accountId: string, projectId: string | null, creativeId: string, type: MediaJobType) {
    const existing = await this.prisma.mediaJob.findFirst({
      where: {
        creativeId,
        type,
        status: { in: [MediaJobStatus.PENDING, MediaJobStatus.RUNNING] },
      },
      select: { id: true },
    });
    if (existing) return existing.id;

    const created = await this.prisma.mediaJob.create({
      data: { accountId, projectId, creativeId, type, status: MediaJobStatus.PENDING },
      select: { id: true },
    });
    return created.id;
  }

  private async processOne(itemId: string) {
    const item = await this.prisma.hotFolderIngestItem.findFirst({
      where: { id: itemId },
      include: { hotFolder: true },
    });
    if (!item) return;

    const now = new Date();
    const mapping = asObj(item.mapping) as MappingSnapshot;
    const creativeId = mapping?.creativeId;

    // Option A (original HF-2): mapping provides creativeId
    // Option A+ (this patch): mapping provides projectId + validIdFromFilename
    const wantValidFromFilename = !!mapping?.validIdFromFilename;
    const enforcePrefix = !!mapping?.enforceMonthYearPrefix;
    const autoCreateCreative = !!mapping?.autoCreateCreative;

    let derivedValid: string | null = null;
    if (!creativeId && wantValidFromFilename) {
      derivedValid = normalizeValidIdFromFilename(path.basename(item.absPath), mapping);
      if (!derivedValid) {
        await this.prisma.hotFolderIngestItem.update({
          where: { id: item.id },
          data: { status: HotFolderIngestStatus.SKIPPED, error: "DERIVED_VALID_EMPTY", ingestedAt: now },
        });
        return;
      }
      if (enforcePrefix && !looksLikeMonthYearPrefix(derivedValid)) {
        await this.prisma.hotFolderIngestItem.update({
          where: { id: item.id },
          data: {
            status: HotFolderIngestStatus.SKIPPED,
            error: "DERIVED_VALID_INVALID_PREFIX",
            ingestedAt: now,
            result: { derivedValid } as any,
          },
        });
        return;
      }
    }

    if (!creativeId && !(mapping?.projectId && derivedValid)) {
      await this.prisma.hotFolderIngestItem.update({
        where: { id: item.id },
        data: {
          status: HotFolderIngestStatus.SKIPPED,
          error: "MAPPING_RULES_MISSING_CREATIVE_OR_PROJECT_VALID",
          ingestedAt: now,
        },
      });
      return;
    }

    // file must exist + stable (avoid half-copied files)
    let st: any;
    try {
      st = await fs.stat(item.absPath);
    } catch {
      await this.finishFailure(item, "FILE_NOT_FOUND");
      return;
    }

    const stableSec = Number.isFinite(Number((asObj(item.hotFolder?.connectionConfig) as any)?.stableSec))
      ? Math.max(1, Number((asObj(item.hotFolder?.connectionConfig) as any)?.stableSec))
      : this.stableSec();
    if (now.getTime() - new Date(st.mtime).getTime() < stableSec * 1000) {
      // re-queue shortly
      await this.prisma.hotFolderIngestItem.update({
        where: { id: item.id },
        data: { status: HotFolderIngestStatus.DISCOVERED, runAfter: new Date(Date.now() + stableSec * 1000) },
      });
      return;
    }

    let creative: { id: string; accountId: string; projectId: string } | null = null;

    if (creativeId) {
      creative = await this.prisma.creative.findFirst({
        where: { id: creativeId, accountId: item.accountId },
        select: { id: true, accountId: true, projectId: true },
      });
      if (!creative) {
        await this.finishFailure(item, "CREATIVE_NOT_FOUND");
        return;
      }
    } else {
      // Find a Creative by (projectId + valid)
      const projectId = String(mapping.projectId || "");
      const valid = String(derivedValid || "");

      const project = await this.prisma.project.findFirst({
        where: { id: projectId, accountId: item.accountId },
        select: { id: true },
      });
      if (!project) {
        await this.finishFailure(item, "PROJECT_NOT_FOUND");
        return;
      }

      creative = await this.prisma.creative.findFirst({
        where: { accountId: item.accountId, projectId, valid },
        select: { id: true, accountId: true, projectId: true },
      });

      if (!creative && autoCreateCreative) {
        // Minimal create: keep it non-breaking; user can fill caption/format/audio later.
        const suffix = valid.includes("|") ? valid.split("|").slice(1).join("|") : valid;
        const fmt = /HD$/i.test(suffix) ? "HD" : /SD$/i.test(suffix) ? "SD" : null;

        creative = await this.prisma.creative.create({
          data: {
            accountId: item.accountId,
            projectId,
            name: valid,
            valid,
            caption: suffix || null,
            format: fmt,
          } as any,
          select: { id: true, accountId: true, projectId: true },
        });
      }

      if (!creative) {
        await this.finishFailure(item, "CREATIVE_NOT_FOUND_FOR_VALID");
        return;
      }
    }

    const filename = path.basename(item.absPath);
    const sizeBytes = BigInt(Number(st.size || 0));

    const existing = await this.prisma.creativeAsset.findFirst({
      where: { accountId: item.accountId, creativeId: creative.id, type: CreativeAssetType.SOURCE },
      select: { id: true },
    });

    const assetData: any = {
      accountId: item.accountId,
      creativeId: creative.id,
      type: CreativeAssetType.SOURCE,
      path: item.absPath,
      filename,
      mimeType: guessMime(filename),
      sizeBytes,
      bytesTotal: sizeBytes,
      bytesReceived: sizeBytes,
      uploadStatus: CreativeAssetUploadStatus.UPLOADED,
      uploadStartedAt: now,
      uploadEndedAt: now,
      error: null,
    };

    const asset = existing
      ? await this.prisma.creativeAsset.update({ where: { id: existing.id }, data: assetData, select: { id: true } })
      : await this.prisma.creativeAsset.create({ data: assetData, select: { id: true } });

    const hfRules = asObj(item.hotFolder?.mappingRules) as MappingSnapshot;
    const qcCfg = asObj(item.hotFolder?.qcConfig);

    const queueAutoQc = mapping.queueAutoQc ?? hfRules.queueAutoQc ?? !!item.hotFolder?.qcEnabled;
    const queueProxy = mapping.queueProxy ?? hfRules.queueProxy ?? !!qcCfg.queueProxy;

    const jobIds: string[] = [];
    if (queueAutoQc) jobIds.push(await this.ensureMediaJob(item.accountId, creative.projectId, creative.id, MediaJobType.AUTO_QC));
    if (queueProxy) jobIds.push(await this.ensureMediaJob(item.accountId, creative.projectId, creative.id, MediaJobType.PROXY_GEN));

    await this.prisma.hotFolderIngestItem.update({
      where: { id: item.id },
      data: {
        status: HotFolderIngestStatus.INGESTED,
        ingestedAt: now,
        runAfter: null,
        error: null,
        result: { creativeId: creative.id, assetId: asset.id, mediaJobIds: jobIds, derivedValid: derivedValid ?? undefined } as any,
      },
    });
  }

  private async finishFailure(item: any, message: string) {
    const attemptsNow = Number(item.attempts || 0);
    const maxAttempts = Number(item.maxAttempts || 3);
    const msg = String(message || "FAILED").slice(0, 2000);

    if (attemptsNow < maxAttempts) {
      const backoffMs = Math.min(60_000, 1000 * Math.pow(2, attemptsNow));
      await this.prisma.hotFolderIngestItem.update({
        where: { id: item.id },
        data: {
          status: HotFolderIngestStatus.DISCOVERED,
          runAfter: new Date(Date.now() + backoffMs),
          error: msg,
        },
      });
      return;
    }

    await this.prisma.hotFolderIngestItem.update({
      where: { id: item.id },
      data: {
        status: HotFolderIngestStatus.FAILED,
        ingestedAt: new Date(),
        runAfter: null,
        error: msg,
      },
    });
  }
}
