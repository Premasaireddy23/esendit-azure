import { Cron } from "@nestjs/schedule";
import { Injectable, Inject, Logger, OnModuleInit } from "@nestjs/common";
import { PrismaService } from "../../common/prisma/prisma.service";
import { NotificationsService } from "../../modules/notifications/notifications.service";
import { ServiceBusService } from "../../common/queue/service-bus.service";
import {
  getCurrentDeliveryWorkerRoute,
  getDeliveryQueueForRoute,
  getDeliveryRouteConflictMessage,
  resolveDeliveryTaskRouting,
  withDeliveryRoutingTranscript,
} from "../../common/queue/delivery-routing";
import * as SftpClientModule from "ssh2-sftp-client";
import { Client as FtpClient } from "basic-ftp";
import * as path from "path";
import * as fs from "fs";
import * as os from "os";
import { spawn } from "node:child_process";
import { STORAGE } from "../../common/storage/storage.token";
import type { StorageService } from "../../common/storage/storage.types";
import { ensureCreativePresetJob, extractPresetJobOutput, getLatestCreativePresetJob } from "../../common/presets/channel-default-preset";

type FtpProgressInfo = {
  name?: string;
  type?: string;
  bytes?: number;
  bytesOverall?: number;
};

@Injectable()
export class DeliveryWorker implements OnModuleInit {
  private log = new Logger(DeliveryWorker.name);
  private serial: Promise<void> = Promise.resolve();
  private readonly workerRoute = getCurrentDeliveryWorkerRoute();

  constructor(
    private prisma: PrismaService,
    private readonly notifications: NotificationsService,
    @Inject(STORAGE) private storage: StorageService,
    private readonly bus: ServiceBusService,
  ) {}

  onModuleInit() {
    if (process.env.NODE_ENV === "test") return;
    if ((process.env.DELIVERY_WORKER_ENABLED || "true").toLowerCase() === "false") {
      this.log.log("DELIVERY_WORKER_ENABLED=false; worker not started");
      return;
    }

    if (this.bus.isEnabled()) {
      const queueName = getDeliveryQueueForRoute(this.workerRoute);
      this.bus
        .subscribeJson(queueName, async (msg) => {
          const taskId = msg?.taskId ? String(msg.taskId) : undefined;
          if (!taskId) return;
          const run = this.serial.then(() => this.processOne(taskId));
          this.serial = run.catch(() => undefined);
          await run;
        })
        .catch((e) => this.log.error(e));
      this.log.log(`Delivery worker started (route=${this.workerRoute}, service bus: ${queueName})`);
    }
  }

  private async republishTask(taskId: string, route: string, messageId: string, scheduleAtUtc?: Date) {
    await this.bus
      .sendJson(
        getDeliveryQueueForRoute(route),
        { taskId },
        scheduleAtUtc ? { messageId, scheduleAtUtc } : { messageId },
      )
      .catch(() => undefined);
  }

  private getApprovalGate(task: any) {
    const transcript = task?.transcript && typeof task.transcript === "object" ? task.transcript : {};
    const gate = transcript?.approvalGate && typeof transcript.approvalGate === "object" ? transcript.approvalGate : {};
    const destinationCfg = task?.planLine?.channel?.destination?.config && typeof task.planLine.channel.destination.config === "object"
      ? task.planLine.channel.destination.config
      : {};
    const required = gate?.required === true || (destinationCfg as any)?.approvalRequired === true;
    const status = String(gate?.status || (required ? "PENDING" : "")).trim().toUpperCase();
    const stagedRemotePath = String(gate?.stagedRemotePath || "").trim() || null;
    const houseId = String(gate?.houseId || "").trim() || null;
    return { transcript, gate, required, status, stagedRemotePath, houseId };
  }

  private buildDeliveredAssetTranscript(asset: any) {
    return {
      kind: asset?.kind || (asset?.id ? "CREATIVE_ASSET" : "PRESET_OUTPUT"),
      path: asset?.path ?? null,
      filename: asset?.filename ?? null,
      mimeType: asset?.mimeType ?? null,
      sourceAssetId: asset?.id ?? null,
      presetJobId: asset?.presetJobId ?? null,
    };
  }

  private async guardTaskRoute(taskId: string): Promise<boolean> {
    const task = await this.prisma.deliveryTask.findUnique({
      where: { id: taskId },
      select: {
        id: true,
        status: true,
        transcript: true,
        forceBackup: true,
        mainDeliveryProfile: { select: { id: true, config: true } },
        backupDeliveryProfile: { select: { id: true, config: true } },
      },
    } as any);
    if (!task) return false;
    if (task.status !== "QUEUED") return false;

    const routing = resolveDeliveryTaskRouting(task);
    if (routing.routeConflict) {
      const routeError = getDeliveryRouteConflictMessage(routing.mainRoute, routing.backupRoute);
      await this.prisma.deliveryTask.updateMany({
        where: { id: taskId, status: "QUEUED" },
        data: {
          status: "FAILED",
          endedAt: new Date(),
          lastError: routeError,
          transcript: withDeliveryRoutingTranscript(
            {
              ...(task.transcript && typeof task.transcript === "object" ? task.transcript : {}),
              lastError: routeError,
            },
            routing,
          ) as any,
        } as any,
      });
      this.log.error(`Task ${taskId} rejected: ${routeError}`);
      return false;
    }

    if (routing.preferredRoute !== this.workerRoute) {
      this.log.warn(`Task ${taskId} belongs to route=${routing.preferredRoute} but worker route=${this.workerRoute}`);
      if (this.bus.isEnabled()) {
        await this.republishTask(taskId, routing.preferredRoute, `${taskId}:reroute:${Date.now()}`);
      }
      return false;
    }

    return true;
  }

  @Cron("*/10 * * * * *")
  async tick() {
    if ((process.env.DELIVERY_WORKER_ENABLED || "true").toLowerCase() === "false") return;
    if (this.bus.isEnabled()) return;
    const now = new Date();
    const candidates = await this.prisma.deliveryTask.findMany({
      where: {
        status: "QUEUED",
        OR: [{ runAfter: null }, { runAfter: { lte: now } }],
      },
      take: 5,
      orderBy: { updatedAt: "asc" },
      include: {
        planLine: { include: { creative: { include: { assets: true } }, channel: { include: { destination: true } } } },
        mainDeliveryProfile: true,
        backupDeliveryProfile: true,
      },
    });

    for (const task of candidates) {
      await this.processOne(task.id);
    }
  }

  private async processOne(taskId: string) {
    const routeOk = await this.guardTaskRoute(taskId);
    if (!routeOk) return;

    // claim (avoid double workers)
    const claimed = await this.prisma.deliveryTask.updateMany({
      where: { id: taskId, status: "QUEUED" },
      data: {
        status: "RUNNING",
        startedAt: new Date(),
        lastHeartbeatAt: new Date(),
        attempts: { increment: 1 },
      },
    });
    if (claimed.count !== 1) return;

    const task = await this.prisma.deliveryTask.findUnique({
      where: { id: taskId },
      include: {
        planLine: { include: { creative: { include: { assets: true } }, channel: { include: { destination: true } } } },
        mainDeliveryProfile: true,
        backupDeliveryProfile: true,
      },
    });
    if (!task) return;

    // Business rule: if there's already SUCCESS for the same creative+channel, auto-cancel this task.
    const creativeId = task.planLine?.creative?.id ?? task.planLine?.creativeId;
    const channelId = task.planLine?.channel?.id ?? task.planLine?.channelId;
    if (creativeId && channelId) {
      const winner = await this.prisma.deliveryTask.findFirst({
        where: {
          accountId: task.accountId,
          status: "SUCCESS",
          id: { not: task.id },
          planLine: { creativeId, channelId },
        },
        select: { id: true, endedAt: true },
        orderBy: { endedAt: "desc" },
      });

      if (winner?.id) {
        await this.prisma.deliveryTask.updateMany({
          where: { id: task.id, status: "RUNNING" },
          data: {
            status: "CANCELLED",
            endedAt: new Date(),
            lastError: `Superseded by successful delivery (${winner.id})`,
            transcript: { lastError: `Superseded by successful delivery (${winner.id})` },
          } as any,
        });
        return;
      }
    }

    const creative = task.planLine.creative;
    const assetResolution = await this.resolveDeliveryAsset(task);
    if (!assetResolution?.asset) {
      return this.failOrRetry(task, assetResolution?.message || "No uploaded SOURCE/OUTPUT asset available");
    }
    const pickAsset = assetResolution.asset;

    const main = task.mainDeliveryProfile ?? null;
    const backup = task.backupDeliveryProfile ?? null;

    const first = task.forceBackup ? backup : main;
    const second = task.forceBackup ? main : backup;

    try {
      if (!first) throw new Error("No delivery profile configured on channel");
      await this.executeProfile(task, pickAsset.path, pickAsset.filename ?? null, creative.valid ?? creative.name, first);

      const latestTaskAfterMain = await this.prisma.deliveryTask.findUnique({ where: { id: task.id }, select: { transcript: true } } as any);

      // If user STOPPED/CANCELLED during transfer, don't flip it to SUCCESS.
      const ok1 = await this.prisma.deliveryTask.updateMany({
        where: { id: task.id, status: "RUNNING" },
        data: {
          status: "SUCCESS",
          endedAt: new Date(),
          usedDeliveryProfileId: first.id,
          failoverUsed: false,
          ...(pickAsset.id ? { sourceAssetId: pickAsset.id } : {}),
          transcript: {
            ...((latestTaskAfterMain as any)?.transcript && typeof (latestTaskAfterMain as any).transcript === "object" ? (latestTaskAfterMain as any).transcript : ((task as any)?.transcript && typeof (task as any).transcript === "object" ? (task as any).transcript : {})),
            deliveredAsset: this.buildDeliveredAssetTranscript(pickAsset),
          } as any,
        } as any,
      });

      if (ok1?.count) {
        // Auto-cancel older QUEUED/PAUSED duplicates for the same creative+channel
        if (creativeId && channelId) {
          await this.prisma.deliveryTask.updateMany({
            where: {
              accountId: task.accountId,
              id: { not: task.id },
              status: { in: ["QUEUED", "PAUSED"] },
              planLine: { creativeId, channelId },
            },
            data: {
              status: "CANCELLED",
              endedAt: new Date(),
              lastError: `Superseded by successful delivery (${task.id})`,
            } as any,
          });
        }

        await this.notifications.emitType6Delivered(task.accountId, task.id).catch(() => undefined);
      }
      return;
    } catch (e1: any) {
      this.log.warn(`Task ${task.id} main attempt failed: ${e1?.message}`);
      if (second) {
        try {
          await this.executeProfile(task, pickAsset.path, pickAsset.filename ?? null, creative.valid ?? creative.name, second);
          const latestTaskAfterFailover = await this.prisma.deliveryTask.findUnique({ where: { id: task.id }, select: { transcript: true } } as any);
          const ok2 = await this.prisma.deliveryTask.updateMany({
            where: { id: task.id, status: "RUNNING" },
            data: {
              status: "SUCCESS",
              endedAt: new Date(),
              usedDeliveryProfileId: second.id,
              failoverUsed: true,
              ...(pickAsset.id ? { sourceAssetId: pickAsset.id } : {}),
              transcript: {
                ...((latestTaskAfterFailover as any)?.transcript && typeof (latestTaskAfterFailover as any).transcript === "object" ? (latestTaskAfterFailover as any).transcript : ((task as any)?.transcript && typeof (task as any).transcript === "object" ? (task as any).transcript : {})),
                deliveredAsset: this.buildDeliveredAssetTranscript(pickAsset),
              } as any,
            } as any,
          });

          if (ok2?.count) {
            // Auto-cancel older QUEUED/PAUSED duplicates for the same creative+channel
            if (creativeId && channelId) {
              await this.prisma.deliveryTask.updateMany({
                where: {
                  accountId: task.accountId,
                  id: { not: task.id },
                  status: { in: ["QUEUED", "PAUSED"] },
                  planLine: { creativeId, channelId },
                },
                data: {
                  status: "CANCELLED",
                  endedAt: new Date(),
                  lastError: `Superseded by successful delivery (${task.id})`,
                } as any,
              });
            }

            await this.notifications.emitType6Delivered(task.accountId, task.id).catch(() => undefined);
          }
          return;
        } catch (e2: any) {
          return this.failOrRetry(task, `Failover failed: ${e2?.message}`);
        }
      }
      return this.failOrRetry(task, e1?.message ?? "Delivery failed");
    }
  }

  private resolveDestinationDeliveryDefinition(task: any): "SD" | "HD" | null {
    const destinationCfg = task?.planLine?.channel?.destination?.config && typeof task.planLine.channel.destination.config === "object"
      ? task.planLine.channel.destination.config
      : {};
    const configured = String(
      (destinationCfg as any).deliveryDefinition ??
      (destinationCfg as any).clientDeliveryType ??
      (destinationCfg as any).format ??
      "",
    )
      .trim()
      .toUpperCase();
    if (configured === "SD" || configured === "HD") return configured as "SD" | "HD";

    const creativeFormat = String(task?.planLine?.creative?.format ?? "")
      .trim()
      .toUpperCase();
    if (creativeFormat.includes("SD")) return "SD";
    if (creativeFormat.includes("HD")) return "HD";
    return null;
  }

  private resolveProfilePaths(task: any, profile: any) {
    const cfg = profile?.config && typeof profile.config === "object" ? profile.config : {};
    const definition = this.resolveDestinationDeliveryDefinition(task);

    const variantFinalPath =
      definition === "SD"
        ? (cfg as any).sdFinalPath
        : definition === "HD"
          ? (cfg as any).hdFinalPath
          : null;
    const variantStagingPath =
      definition === "SD"
        ? (cfg as any).sdStagingPath
        : definition === "HD"
          ? (cfg as any).hdStagingPath
          : null;

    const finalDir = String(variantFinalPath ?? profile?.finalPath ?? (cfg as any).finalPath ?? "/").trim() || "/";
    const stagingValue = variantStagingPath ?? profile?.stagingPath ?? (cfg as any).stagingPath ?? null;
    const stagingDir = String(stagingValue ?? "").trim() || null;

    return { definition, finalDir, stagingDir };
  }

  private async executeProfile(task: any, assetPath: string, filename: string | null, fallbackName: string, profile: any) {
    const proto = String(profile?.protocol || "").toUpperCase();

    const cfg = (profile.config ?? {}) as any;
    const resolvedPaths = this.resolveProfilePaths(task, profile);
    const approvalGate = this.getApprovalGate(task);
    const approvalRequired = approvalGate.required;
    const finalizeApprovedRelease = approvalRequired && approvalGate.status === "APPROVED" && !!approvalGate.stagedRemotePath;

    // Serialize sends per delivery profile across all worker replicas.
    // This prevents multiple parallel transfers to the same FTP/SFTP endpoint, which some servers reject.
    const serializePerProfile = (process.env.DELIVERY_SERIALIZE_PER_PROFILE || "true").toLowerCase() !== "false";
    if (serializePerProfile && profile?.id && (proto === "FTP" || proto === "FTPS" || proto === "SFTP" || proto === "ASPERA" || proto === "FILECATALYST")) {
      await this.awaitProfileTurn(task.id, String(profile.id));
    }

    // Common: compute local path (download blob key to /tmp if needed)
    const raw = assetPath.startsWith("file://") ? assetPath.replace("file://", "") : assetPath;

    let localPath = raw;
    let tmpDownloaded = false;

    if (this.storage.isCloud() && !path.isAbsolute(raw)) {
      const ext = (filename ? path.extname(filename) : path.extname(raw)) || ".bin";
      localPath = path.join(os.tmpdir(), `esendit-delivery-${task.id}-${Date.now()}${ext}`);
      await this.storage.downloadToFile(raw, localPath);
      tmpDownloaded = true;
    }

    if (!fs.existsSync(localPath)) throw new Error(`Local file not found: ${localPath}`);

    const extWithDot = filename ? path.extname(filename) : "";
    const baseName = await this.resolveRemoteBaseName(task, fallbackName, extWithDot);
    const outName = this.ensureExtension(baseName, extWithDot || ".mov");

    // Paths (support staging -> final, with optional destination-driven SD/HD overrides)
    const finalDir = resolvedPaths.finalDir;
    const stagingDir = resolvedPaths.stagingDir;

    if (approvalRequired && !finalizeApprovedRelease && (!stagingDir || String(stagingDir).trim() === String(finalDir).trim())) {
      throw new Error("Approval-required destinations need a dedicated staging path that differs from the final path");
    }

    const finalPath = path.posix.join(finalDir, outName);
    const tempPath = finalizeApprovedRelease
      ? String(approvalGate.stagedRemotePath || "").trim()
      : stagingDir && String(stagingDir).trim() && String(stagingDir).trim() !== String(finalDir).trim()
        ? path.posix.join(String(stagingDir).trim(), outName)
        : finalPath;

    const stat = fs.statSync(localPath);
    const totalBytes = stat?.size ?? 0;

    try {
      if (proto === "SFTP") {
        if (finalizeApprovedRelease) {
          await this.moveViaSftp(tempPath, finalPath, {
            host: cfg.host,
            port: cfg.port ?? 22,
            username: cfg.username,
            password: cfg.password,
          });
        } else {
          await this.uploadViaSftp(task, localPath, tempPath, approvalRequired ? tempPath : finalPath, totalBytes, {
            host: cfg.host,
            port: cfg.port ?? 22,
            username: cfg.username,
            password: cfg.password,
          });
        }
      } else if (proto === "FTP" || proto === "FTPS") {
        if (finalizeApprovedRelease) {
          await this.moveViaFtp(tempPath, finalPath, {
            host: cfg.host,
            port: cfg.port ?? 21,
            username: cfg.username,
            password: cfg.password,
            secure: proto === "FTPS" || Boolean(cfg.secure),
            secureOptions: cfg.secureOptions,
          });
        } else {
          await this.uploadViaFtp(task, localPath, tempPath, approvalRequired ? tempPath : finalPath, totalBytes, {
            host: cfg.host,
            port: cfg.port ?? 21,
            username: cfg.username,
            password: cfg.password,
            secure: proto === "FTPS" || Boolean(cfg.secure),
            secureOptions: cfg.secureOptions,
          });
        }
      } else if (proto === "ASPERA") {
        if (!finalizeApprovedRelease) {
          this.ensureCliProtocolSinglePath("ASPERA", tempPath, approvalRequired ? tempPath : finalPath);
        }
        await this.uploadViaAspera(task, localPath, finalizeApprovedRelease ? finalPath : (approvalRequired ? tempPath : finalPath), totalBytes, {
          host: cfg.host,
          port: cfg.port ?? 33001,
          username: cfg.username,
          password: cfg.password,
          rateMbps: cfg.rateMbps,
          resumePolicy: cfg.resumePolicy,
        });
      } else if (proto === "FILECATALYST") {
        if (!finalizeApprovedRelease) {
          this.ensureCliProtocolSinglePath("FILECATALYST", tempPath, approvalRequired ? tempPath : finalPath);
        }
        await this.uploadViaFileCatalyst(task, localPath, finalizeApprovedRelease ? finalPath : (approvalRequired ? tempPath : finalPath), totalBytes, {
          host: cfg.host,
          port: cfg.port ?? 21,
          username: cfg.username,
          password: cfg.password,
          secure: Boolean(cfg.secure),
          rateKbps: cfg.rateKbps,
          numThreads: cfg.numThreads,
          autoResume: cfg.autoResume,
        });
      } else {
        throw new Error(`Unsupported protocol: ${profile.protocol}`);
      }

      if (tmpDownloaded) {
        try {
          fs.unlinkSync(localPath);
        } catch {
          // ignore
        }
      }

      await this.prisma.deliveryTask.updateMany({
        where: { id: task.id, status: "RUNNING" },
        data: { bytesSent: BigInt(totalBytes) } as any,
      });

      if (approvalRequired && !finalizeApprovedRelease) {
        const waitingTranscript = {
          ...approvalGate.transcript,
          approvalGate: {
            ...approvalGate.gate,
            required: true,
            status: "WAITING",
            houseId: null,
            approvedByUserId: null,
            approvedAt: null,
            releasedAt: null,
            stagedRemotePath: tempPath,
            finalRemotePath: null,
            finalFileName: null,
            profileId: profile?.id ?? null,
          },
        };

        const waitingReceipt: any = {
          protocol: proto,
          remotePath: tempPath,
          stagingRemotePath: tempPath,
          approvalRequired: true,
          approvalStatus: "WAITING",
          profileId: profile.id,
        };

        await this.prisma.deliveryTask.updateMany({
          where: { id: task.id, status: "RUNNING" },
          data: {
            status: "PAUSED",
            endedAt: new Date(),
            remotePath: tempPath,
            receipt: waitingReceipt,
            transcript: waitingTranscript as any,
          } as any,
        });
        return;
      }

      const receipt: any = { protocol: proto, remotePath: finalPath, profileId: profile.id };
      if (approvalRequired) {
        receipt.approvalRequired = true;
        receipt.approvalStatus = "RELEASED";
        receipt.houseId = approvalGate.houseId ?? null;
        receipt.stagingRemotePath = approvalGate.stagedRemotePath || tempPath;
        if (finalizeApprovedRelease && (proto === "ASPERA" || proto === "FILECATALYST")) {
          receipt.releaseMethod = "REUPLOAD_TO_FINAL";
          receipt.stagingCleanupPending = true;
        }
      }

      const xmlCfg = this.resolveXmlConfig(task, profile);
      if (xmlCfg?.enabled) {
        const values = this.buildXmlTemplateValues(task, profile, outName, finalPath, totalBytes);
        const xmlFileName = this.computeXmlFileName(xmlCfg, values);

        const xmlFinalPath = path.posix.join(finalDir, xmlFileName);
        const xmlTempPath =
          finalizeApprovedRelease && (proto === "ASPERA" || proto === "FILECATALYST")
            ? xmlFinalPath
            : stagingDir && String(stagingDir).trim() && String(stagingDir).trim() !== String(finalDir).trim()
              ? path.posix.join(String(stagingDir).trim(), xmlFileName)
              : xmlFinalPath;

        const xmlContent = this.buildXml(xmlCfg, values);
        const xmlBytes = Buffer.byteLength(xmlContent || "", "utf8");

        const xmlAuditKey = path.posix.join(
          "accounts",
          String(task.accountId),
          "deliveries",
          String(task.id),
          "xml",
          xmlFileName,
        );

        try {
          await this.storage.putObject(xmlAuditKey, Buffer.from(xmlContent, "utf8"), "application/xml");
        } catch (e: any) {
          this.log.warn(`Task ${task.id} failed to store XML audit copy: ${e?.message}`);
        }

        const xmlReceipt: any = {
          enabled: true,
          required: Boolean(xmlCfg.required),
          fileName: xmlFileName,
          remotePath: xmlFinalPath,
          auditKey: xmlAuditKey,
          status: "PENDING",
        };

        const tmpXmlPath = path.join(os.tmpdir(), `esendit-xml-${task.id}-${Date.now()}-${xmlFileName}`);
        fs.writeFileSync(tmpXmlPath, xmlContent, "utf8");

        try {
          if (proto === "SFTP") {
            await this.uploadViaSftp(
              task,
              tmpXmlPath,
              xmlTempPath,
              xmlFinalPath,
              xmlBytes,
              {
                host: cfg.host,
                port: cfg.port ?? 22,
                username: cfg.username,
                password: cfg.password,
              },
              false,
            );
          } else if (proto === "FTP" || proto === "FTPS") {
            await this.uploadViaFtp(
              task,
              tmpXmlPath,
              xmlTempPath,
              xmlFinalPath,
              xmlBytes,
              {
                host: cfg.host,
                port: cfg.port ?? 21,
                username: cfg.username,
                password: cfg.password,
                secure: proto === "FTPS" || Boolean(cfg.secure),
                secureOptions: cfg.secureOptions,
              },
              false,
            );
          } else if (proto === "ASPERA") {
            this.ensureCliProtocolSinglePath("ASPERA", xmlTempPath, xmlFinalPath);
            await this.uploadViaAspera(
              task,
              tmpXmlPath,
              xmlFinalPath,
              xmlBytes,
              {
                host: cfg.host,
                port: cfg.port ?? 33001,
                username: cfg.username,
                password: cfg.password,
                rateMbps: cfg.rateMbps,
                resumePolicy: cfg.resumePolicy,
              },
              false,
            );
          } else if (proto === "FILECATALYST") {
            this.ensureCliProtocolSinglePath("FILECATALYST", xmlTempPath, xmlFinalPath);
            await this.uploadViaFileCatalyst(
              task,
              tmpXmlPath,
              xmlFinalPath,
              xmlBytes,
              {
                host: cfg.host,
                port: cfg.port ?? 21,
                username: cfg.username,
                password: cfg.password,
                secure: Boolean(cfg.secure),
                rateKbps: cfg.rateKbps,
                numThreads: cfg.numThreads,
                autoResume: cfg.autoResume,
              },
              false,
            );
          } else {
            throw new Error(`XML upload unsupported for protocol: ${profile.protocol}`);
          }

          xmlReceipt.status = "SUCCESS";
        } catch (e: any) {
          xmlReceipt.status = "FAILED";
          xmlReceipt.error = e?.message ? String(e.message) : String(e);

          if (xmlCfg.required) throw e;
        } finally {
          try {
            if (fs.existsSync(tmpXmlPath)) fs.unlinkSync(tmpXmlPath);
          } catch {
            // ignore
          }
        }

        receipt.xml = xmlReceipt;
        receipt.xmlAuditKey = xmlAuditKey;
        receipt.xmlFileName = xmlFileName;
        receipt.xmlRemotePath = xmlFinalPath;
      }

      const nextTranscript = approvalRequired
        ? {
            ...approvalGate.transcript,
            approvalGate: {
              ...approvalGate.gate,
              required: true,
              status: "RELEASED",
              houseId: approvalGate.houseId ?? null,
              stagedRemotePath: approvalGate.stagedRemotePath || tempPath,
              finalRemotePath: finalPath,
              finalFileName: outName,
              profileId: profile?.id ?? null,
              releasedAt: new Date().toISOString(),
              releaseMethod: finalizeApprovedRelease && (proto === "ASPERA" || proto === "FILECATALYST") ? "REUPLOAD_TO_FINAL" : "MOVE_TO_FINAL",
              stagingCleanupPending: finalizeApprovedRelease && (proto === "ASPERA" || proto === "FILECATALYST") ? true : false,
            },
          }
        : approvalGate.transcript;

      await this.prisma.deliveryTask.updateMany({
        where: { id: task.id, status: "RUNNING" },
        data: {
          remotePath: finalPath,
          receipt,
          transcript: nextTranscript as any,
        } as any,
      });
    } finally {
      if (tmpDownloaded) {
        try {
          if (fs.existsSync(localPath)) fs.unlinkSync(localPath);
        } catch {
          // ignore
        }
      }
    }
  }

  private createSftpClient() {
    const SftpClientCtor: any =
      (SftpClientModule as any)?.default && typeof (SftpClientModule as any).default === "function"
        ? (SftpClientModule as any).default
        : (SftpClientModule as any);
    if (typeof SftpClientCtor !== "function") {
      throw new Error("ssh2-sftp-client module could not be initialized");
    }
    return new SftpClientCtor();
  }

  private async uploadViaSftp(
    task: any,
    localPath: string,
    tempRemotePath: string,
    finalRemotePath: string,
    totalBytes: number,
    conn: { host: string; port: number; username: string; password: string },
    trackProgress = true,
  ) {
    const { host, port, username, password } = conn;
    if (!host || !username || !password) throw new Error("SFTP config missing host/username/password");

    const sftp = this.createSftpClient();
    await sftp.connect({ host, port, username, password });

    // Best-effort progress updates (throttled)
    let last = 0;
    const opts: any = trackProgress
      ? {
          step: async (transferred: number) => {
            const now = Date.now();
            if (now - last < 2000) return;
            last = now;
            try {
              await this.prisma.deliveryTask.updateMany({
                where: { id: task.id, status: "RUNNING" },
                data: { bytesSent: BigInt(transferred) } as any,
              });
            } catch {
              // ignore
            }
          },
        }
      : {};


    // Ensure dirs exist (best-effort)
    try {
      const dir = path.posix.dirname(tempRemotePath);
      await (sftp as any).mkdir(dir, true);
    } catch {
      // ignore
    }

    await (sftp as any).fastPut(localPath, tempRemotePath, opts);

    // If staging path is used, rename to final path
    if (tempRemotePath !== finalRemotePath) {
      try {
        const fdir = path.posix.dirname(finalRemotePath);
        await (sftp as any).mkdir(fdir, true);
      } catch {
        // ignore
      }
      await (sftp as any).rename(tempRemotePath, finalRemotePath);
    }

    await sftp.end();

    // ensure final bytes sent (helps if server doesn't report steps)
    if (trackProgress) {
      await this.prisma.deliveryTask.updateMany({
        where: { id: task.id, status: "RUNNING" },
        data: { bytesSent: BigInt(totalBytes) } as any,
      });
    }
  }

  private ensureCliProtocolSinglePath(protocol: "ASPERA" | "FILECATALYST", tempRemotePath: string, finalRemotePath: string) {
    if (tempRemotePath !== finalRemotePath) {
      throw new Error(`${protocol} delivery currently supports direct final-path upload only. Leave staging path empty or same as final path.`);
    }
  }

  private async uploadViaAspera(
    task: any,
    localPath: string,
    finalRemotePath: string,
    totalBytes: number,
    conn: { host: string; port: number; username: string; password: string; rateMbps?: number; resumePolicy?: number },
    trackProgress = true,
  ) {
    const { host, port, username, password, rateMbps, resumePolicy } = conn;
    if (!host || !username || !password) throw new Error("Aspera config missing host/username/password");

    const destination = `${username}@${host}:${finalRemotePath}`;
    const args = ["-P", String(port || 33001), "-O", String(port || 33001), "-k", String(resumePolicy ?? 1)];
    const rate = Number(rateMbps ?? 0);
    if (Number.isFinite(rate) && rate > 0) args.push("-l", `${rate}m`);
    args.push(localPath, destination);

    await this.runExternalTransfer(task, {
      command: "ascp",
      args,
      env: { ASPERA_SCP_PASS: password },
      missingMessage: "Aspera runtime not installed in the worker image. Install the Aspera transfer engine (ascp) before using ASPERA delivery profiles.",
      trackProgress,
      totalBytes,
      progressFile: localPath,
    });
  }

  private async uploadViaFileCatalyst(
    task: any,
    localPath: string,
    finalRemotePath: string,
    totalBytes: number,
    conn: { host: string; port: number; username: string; password: string; secure?: boolean; rateKbps?: number; numThreads?: number; autoResume?: boolean },
    trackProgress = true,
  ) {
    const { host, port, username, password, secure, rateKbps, numThreads, autoResume } = conn;
    if (!host || !username || !password) throw new Error("FileCatalyst config missing host/username/password");

    const remoteDir = path.posix.dirname(finalRemotePath || "/");
    const remoteName = path.posix.basename(finalRemotePath || path.basename(localPath));
    const prepared = this.prepareCliUploadSource(localPath, remoteName);

    try {
      const args = [
        "-host", host,
        "-port", String(port || 21),
        "-user", username,
        "-pass", password,
        "-localdir", path.dirname(prepared.uploadPath),
        "-remotedir", remoteDir || "/",
        "-upload", path.basename(prepared.uploadPath),
      ];
      if (secure) args.push("-secure");
      const rate = Number(rateKbps ?? 0);
      if (Number.isFinite(rate) && rate > 0) args.push("-rate", String(rate));
      const threads = Number(numThreads ?? 0);
      if (Number.isFinite(threads) && threads > 0) args.push("-numthreads", String(threads));
      if (autoResume !== undefined) args.push("-autoresume", String(Boolean(autoResume)));

      await this.runExternalTransfer(task, {
        command: process.env.FILECATALYST_CLI_BIN || "fc_cliclient.sh",
        args,
        missingMessage: "FileCatalyst runtime not installed in the worker image. Install fc_cliclient before using FILECATALYST delivery profiles.",
        trackProgress,
        totalBytes,
        progressFile: prepared.uploadPath,
      });
    } finally {
      prepared.cleanup();
    }
  }

  private prepareCliUploadSource(localPath: string, desiredName: string) {
    const currentName = path.basename(localPath);
    if (!desiredName || desiredName === currentName) {
      return { uploadPath: localPath, cleanup: () => undefined };
    }

    const target = path.join(os.tmpdir(), `esendit-cli-${Date.now()}-${desiredName}`);
    try {
      fs.linkSync(localPath, target);
    } catch {
      fs.copyFileSync(localPath, target);
    }

    return {
      uploadPath: target,
      cleanup: () => {
        try {
          if (fs.existsSync(target)) fs.unlinkSync(target);
        } catch {
          // ignore
        }
      },
    };
  }

  private async runExternalTransfer(
    task: any,
    opts: {
      command: string;
      args: string[];
      env?: Record<string, string>;
      missingMessage: string;
      trackProgress?: boolean;
      totalBytes: number;
      progressFile?: string;
    },
  ) {
    const { command, args, env, missingMessage, trackProgress = true, totalBytes, progressFile } = opts;

    await new Promise<void>((resolve, reject) => {
      const child = spawn(command, args, {
        env: { ...process.env, ...(env ?? {}) },
        stdio: ["ignore", "pipe", "pipe"],
      });

      let stdout = "";
      let stderr = "";
      let settled = false;
      let timer: NodeJS.Timeout | undefined;
      let progressTimer: NodeJS.Timeout | undefined;

      const fail = (message: string) => {
        if (settled) return;
        settled = true;
        try { if (timer) clearTimeout(timer); } catch {}
        try { if (progressTimer) clearInterval(progressTimer); } catch {}
        reject(new Error(message));
      };

      child.once("error", (err: any) => {
        if (err?.code === "ENOENT") return fail(missingMessage);
        return fail(err?.message || `${command} failed to start`);
      });

      if (trackProgress) {
        progressTimer = setInterval(async () => {
          try {
            const fileForProgress = progressFile;
            if (!fileForProgress || !fs.existsSync(fileForProgress)) return;
            const size = fs.statSync(fileForProgress).size;
            await this.prisma.deliveryTask.updateMany({
              where: { id: task.id, status: "RUNNING" },
              data: { bytesSent: BigInt(Math.min(size, totalBytes)) } as any,
            });
          } catch {
            // ignore
          }
        }, 2000);
      }

      timer = setTimeout(() => {
        try { child.kill("SIGKILL"); } catch {}
        fail(`${command} timed out while transferring file`);
      }, Math.max(300000, Number(process.env.DELIVERY_EXTERNAL_TIMEOUT_MS || "7200000")));

      child.stdout?.on("data", (chunk) => { stdout += chunk.toString(); });
      child.stderr?.on("data", (chunk) => { stderr += chunk.toString(); });

      child.once("close", async (code) => {
        if (settled) return;
        settled = true;
        try { if (timer) clearTimeout(timer); } catch {}
        try { if (progressTimer) clearInterval(progressTimer); } catch {}

        if (code !== 0) {
          const detail = (stderr || stdout || `${command} exited with code ${code}`).trim();
          return reject(new Error(detail));
        }

        if (trackProgress) {
          try {
            await this.prisma.deliveryTask.updateMany({
              where: { id: task.id, status: "RUNNING" },
              data: { bytesSent: BigInt(totalBytes) } as any,
            });
          } catch {
            // ignore
          }
        }
        resolve();
      });
    });
  }

  private async uploadViaFtp(
    task: any,
    localPath: string,
    tempRemotePath: string,
    finalRemotePath: string,
    totalBytes: number,
    conn: { host: string; port: number; username: string; password: string; secure?: boolean; secureOptions?: any },
    trackProgress = true,
  ) {
    const { host, port, username, password, secure, secureOptions } = conn;
    if (!host || !username || !password) throw new Error("FTP config missing host/username/password");

    const client = new FtpClient();
    // Keep logs quiet; enable for debugging if needed
    client.ftp.verbose = false;

    // Best-effort progress updates (throttled)
    let last = 0;
    if (trackProgress) {
      client.trackProgress(async (info: FtpProgressInfo) => {
      const now = Date.now();
      if (now - last < 2000) return;
      last = now;
      const transferred = Number(info?.bytesOverall ?? 0);
      try {
        await this.prisma.deliveryTask.updateMany({
          where: { id: task.id, status: "RUNNING" },
          data: { bytesSent: BigInt(transferred) } as any,
        });
      } catch {
        // ignore
      }
      });
    }

    try {
      await client.access({
        host,
        port,
        user: username,
        password,
        secure: Boolean(secure),
        secureOptions,
      } as any);

      // Ensure staging dir exists; ensureDir() changes current working dir.
      const tempDir = path.posix.dirname(tempRemotePath);
      await client.ensureDir(tempDir);

      // Upload using basename relative to ensured directory
      await client.uploadFrom(localPath, path.posix.basename(tempRemotePath));

      // If staging path is used, rename to final path
      if (tempRemotePath !== finalRemotePath) {
        const finalDir = path.posix.dirname(finalRemotePath);
        await client.ensureDir(finalDir);

        // Rename using full paths (works even if cwd changed)
        await client.rename(tempRemotePath, finalRemotePath);
      }

      await this.prisma.deliveryTask.updateMany({
        where: { id: task.id, status: "RUNNING" },
        data: { bytesSent: BigInt(totalBytes) } as any,
      });
    } finally {
      if (trackProgress) {
        try {
          client.trackProgress(); // stop tracking
        } catch {
          // ignore
        }
      }
      client.close();
    }
  }

  private async moveViaSftp(
    tempRemotePath: string,
    finalRemotePath: string,
    conn: { host: string; port: number; username: string; password: string },
  ) {
    const { host, port, username, password } = conn;
    if (!host || !username || !password) throw new Error("SFTP config missing host/username/password");

    const sftp = this.createSftpClient();
    await sftp.connect({ host, port, username, password });
    try {
      try {
        const fdir = path.posix.dirname(finalRemotePath);
        await (sftp as any).mkdir(fdir, true);
      } catch {
        // ignore
      }
      await (sftp as any).rename(tempRemotePath, finalRemotePath);
    } finally {
      await sftp.end();
    }
  }

  private async moveViaFtp(
    tempRemotePath: string,
    finalRemotePath: string,
    conn: { host: string; port: number; username: string; password: string; secure?: boolean; secureOptions?: any },
  ) {
    const { host, port, username, password, secure, secureOptions } = conn;
    if (!host || !username || !password) throw new Error("FTP config missing host/username/password");

    const client = new FtpClient();
    client.ftp.verbose = false;
    try {
      await client.access({
        host,
        port,
        user: username,
        password,
        secure: Boolean(secure),
        secureOptions,
      } as any);

      const finalDir = path.posix.dirname(finalRemotePath);
      await client.ensureDir(finalDir);
      await client.rename(tempRemotePath, finalRemotePath);
    } finally {
      client.close();
    }
  }

  private ensureExtension(name: string, extWithDot: string) {
    const safe = String(name || "").trim();
    if (!safe) return `file${extWithDot}`;
    // If the template already contains an extension, don't append another one.
    return path.posix.extname(safe) ? safe : `${safe}${extWithDot}`;
  }

  private sanitizeFileNamePart(v: string) {
    // Keep it receiver-friendly: no spaces, no path separators, no weird characters.
    return String(v || "")
      .trim()
      .replace(/\s+/g, "_")
      .replace(/[\\/]/g, "_")
      .replace(/[^a-zA-Z0-9._-]/g, "_")
      .replace(/_+/g, "_")
      .replace(/^[_\.\-]+|[_\.\-]+$/g, "");
  }

  private renderTemplate(tpl: string, values: Record<string, string>) {
    const template = String(tpl || "").trim();
    if (!template) return "";
    return template.replace(/\{([A-Za-z0-9_]+)\}/g, (_m, keyRaw) => {
      const key = String(keyRaw || "").trim();
      // Support case-insensitive keys.
      const v = values[key] ?? values[key.toUpperCase()] ?? values[key.toLowerCase()] ?? "";
      return v;
    });
  }



private xmlEscape(v: any) {
  return String(v ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

private resolveXmlConfig(task: any, profile: any) {
  // XML config can be enabled at destination or channel level:
  // - destination.config.xml
  // - channel.config.xml
  // - optionally overridden by deliveryProfile.config.xml
  const channel = task?.planLine?.channel ?? null;
  const destination = channel?.destination ?? null;

  const destXml = (destination?.config as any)?.xml ?? null;
  const chanXml = (channel?.config as any)?.xml ?? null;
  const profXml = (profile?.config as any)?.xml ?? null;

  // Merge with increasing precedence: destination -> channel -> profile
  const merged = { ...(destXml && typeof destXml === "object" ? destXml : {}), ...(chanXml && typeof chanXml === "object" ? chanXml : {}), ...(profXml && typeof profXml === "object" ? profXml : {}) } as any;

  const enabled = merged?.enabled === true;
  if (!enabled) return { enabled: false };

  return {
    enabled: true,
    required: merged?.required === true,
    rootTag: merged?.rootTag || merged?.root || "DeliveryMetadata",
    namespace: merged?.namespace || merged?.xmlns || null,
    fileName: merged?.fileName || null,
    fileNameTemplate: merged?.fileNameTemplate || null,
    template: merged?.template || null,
    fields: Array.isArray(merged?.fields) ? merged.fields : null,
  };
}

private buildXmlTemplateValues(task: any, profile: any, outName: string, remotePath: string, totalBytes: number) {
  const creative = task?.planLine?.creative ?? null;
  const channel = task?.planLine?.channel ?? null;
  const destination = channel?.destination ?? null;

  const baseName = path.posix.basename(outName, path.posix.extname(outName));

  return {
    ACCOUNT_ID: String(task?.accountId ?? ""),
    TASK_ID: String(task?.id ?? ""),
    ORDER_ID: String(task?.orderId ?? ""),
    PROJECT_ID: String(creative?.projectId ?? ""),
    CREATIVE_ID: String(creative?.id ?? ""),
    CREATIVE_NAME: String(creative?.name ?? ""),
    VALID: String(creative?.valid ?? creative?.name ?? ""),
    HOUSE_ID: String(this.getApprovalGate(task).houseId ?? ""),
    CHANNEL_ID: String(channel?.id ?? ""),
    CHANNEL_NAME: String(channel?.name ?? ""),
    DESTINATION_ID: String(destination?.id ?? ""),
    DESTINATION_NAME: String(destination?.name ?? ""),
    PROFILE_ID: String(profile?.id ?? ""),
    PROFILE_NAME: String(profile?.name ?? ""),
    PROTOCOL: String(profile?.protocol ?? ""),
    FILE_NAME: String(outName ?? ""),
    BASENAME: String(baseName ?? ""),
    REMOTE_PATH: String(remotePath ?? ""),
    BYTES: String(totalBytes ?? 0),
    GENERATED_AT_UTC: new Date().toISOString(),
  } as Record<string, string>;
}

private buildDefaultXml(xmlCfg: any, values: Record<string, string>) {
  const rootTag = String(xmlCfg?.rootTag || "DeliveryMetadata");
  const xmlns = xmlCfg?.namespace ? ` xmlns="${this.xmlEscape(xmlCfg.namespace)}"` : "";

  const defaultKeys = [
    "ACCOUNT_ID",
    "TASK_ID",
    "ORDER_ID",
    "PROJECT_ID",
    "CREATIVE_ID",
    "CREATIVE_NAME",
    "VALID",
    "CHANNEL_ID",
    "CHANNEL_NAME",
    "DESTINATION_ID",
    "DESTINATION_NAME",
    "PROFILE_ID",
    "PROFILE_NAME",
    "PROTOCOL",
    "FILE_NAME",
    "REMOTE_PATH",
    "BYTES",
    "GENERATED_AT_UTC",
  ];

  const fields = Array.isArray(xmlCfg?.fields) && xmlCfg.fields.length ? xmlCfg.fields : defaultKeys;
  const lines: string[] = [];

  for (const f of fields) {
    if (typeof f === "string") {
      const key = String(f).trim();
      if (!key) continue;
      const val = values[key] ?? values[key.toUpperCase()] ?? "";
      lines.push(`  <${key}>${this.xmlEscape(val)}</${key}>`);
      continue;
    }
    if (f && typeof f === "object") {
      const tag = String((f as any).tag || (f as any).name || "").trim();
      if (!tag) continue;
      const key = (f as any).key ? String((f as any).key) : null;
      const rawValue = (f as any).value != null ? String((f as any).value) : key ? (values[key] ?? "") : "";
      const value = this.renderTemplate(rawValue, values);
      lines.push(`  <${tag}>${this.xmlEscape(value)}</${tag}>`);
    }
  }

  const inner = lines.join("\n");
  return `<?xml version="1.0" encoding="UTF-8"?>\n<${rootTag}${xmlns}>\n${inner}\n</${rootTag}>\n`;
}

private buildXml(xmlCfg: any, values: Record<string, string>) {
  if (xmlCfg?.template && String(xmlCfg.template).trim()) {
    // Allow placeholders in the template: {TASK_ID}, {FILE_NAME}, etc.
    return this.renderTemplate(String(xmlCfg.template), values);
  }
  return this.buildDefaultXml(xmlCfg, values);
}

private computeXmlFileName(xmlCfg: any, values: Record<string, string>) {
  const base = values.BASENAME || "metadata";
  const fallback = `${this.sanitizeFileNamePart(base)}.xml`;

  if (xmlCfg?.fileName && String(xmlCfg.fileName).trim()) {
    const n = this.sanitizeFileNamePart(this.renderTemplate(String(xmlCfg.fileName), values));
    return n.endsWith(".xml") ? n : `${n}.xml`;
  }
  if (xmlCfg?.fileNameTemplate && String(xmlCfg.fileNameTemplate).trim()) {
    const n = this.sanitizeFileNamePart(this.renderTemplate(String(xmlCfg.fileNameTemplate), values));
    if (!n) return fallback;
    return n.endsWith(".xml") ? n : `${n}.xml`;
  }
  return fallback;
}

  
  private async awaitProfileTurn(taskId: string, deliveryProfileId: string) {
    const pollMs = Math.max(250, Number(process.env.DELIVERY_SERIALIZE_POLL_MS || "2000"));
    const maxWaitSec = Number(process.env.DELIVERY_SERIALIZE_MAX_WAIT_SEC || "0"); // 0 = no timeout
    const started = Date.now();

    // Basic FIFO ordering by startedAt then id.
    while (true) {
      const cur = await this.prisma.deliveryTask.findFirst({
        where: { id: taskId },
        select: { status: true },
      });
      if (!cur || cur.status !== "RUNNING") return;

      const head = await this.prisma.deliveryTask.findFirst({
        where: {
          status: "RUNNING",
          OR: [{ mainDeliveryProfileId: deliveryProfileId }, { backupDeliveryProfileId: deliveryProfileId }],
        } as any,
        orderBy: [{ startedAt: "asc" }, { id: "asc" }] as any,
        select: { id: true },
      });

      if (head?.id === taskId) return;

      // heartbeat while waiting
      await this.prisma.deliveryTask.updateMany({
        where: { id: taskId, status: "RUNNING" },
        data: { lastHeartbeatAt: new Date() },
      });

      if (maxWaitSec > 0 && Date.now() - started > maxWaitSec * 1000) {
        throw new Error(`Destination busy (profile ${deliveryProfileId}); timed out waiting for turn`);
      }

      await new Promise((r) => setTimeout(r, pollMs));
    }
  }

private async resolveRemoteBaseName(task: any, fallbackName: string, assetExtWithDot: string) {
    const creative = task?.planLine?.creative ?? null;
    const channel = task?.planLine?.channel ?? null;
    const destinationId: string | null = channel?.destinationId ?? null;

    // Load destination (template lives here)
    let destination: any = channel?.destination ?? null;
    if (!destination && destinationId) {
      destination = await this.prisma.destination.findFirst({
        where: { accountId: task.accountId, id: destinationId },
        select: { id: true, name: true, fileNameTemplate: true, config: true },
      });
    }

    // Load project name (optional but useful)
    let project: any = null;
    const projectId: string | null = creative?.projectId ?? null;
    if (projectId) {
      project = await this.prisma.project.findFirst({
        where: { accountId: task.accountId, id: projectId },
        select: { id: true, name: true },
      });
    }

    const now = new Date();
    const yyyy = now.getUTCFullYear();
    const mm = String(now.getUTCMonth() + 1).padStart(2, "0");
    const dd = String(now.getUTCDate()).padStart(2, "0");
    const HH = String(now.getUTCHours()).padStart(2, "0");
    const Min = String(now.getUTCMinutes()).padStart(2, "0");

    const ext = (assetExtWithDot || "").startsWith(".") ? assetExtWithDot.slice(1) : assetExtWithDot || "";

    const durationRaw = creative?.duration ?? "";
    const durationStr = typeof durationRaw === "number" ? String(durationRaw) : String(durationRaw || "");
    const durationSec = (() => {
      if (typeof durationRaw === "number") return String(Math.max(0, Math.floor(durationRaw)));
      // Support HH:MM:SS or HH:MM:SS:FF (ignore frames)
      const m = /^(\d+):(\d+):(\d+)(?::(\d+))?$/.exec(durationStr.trim());
      if (!m) return "";
      const h = Number(m[1] || 0);
      const mi = Number(m[2] || 0);
      const s = Number(m[3] || 0);
      if ([h, mi, s].some((x) => !Number.isFinite(x))) return "";
      return String(h * 3600 + mi * 60 + s);
    })();

    const values: Record<string, string> = {
      // Destination / Channel
      DESTINATION: this.sanitizeFileNamePart(destination?.name ?? ""),
      DESTINATIONNAME: this.sanitizeFileNamePart(destination?.name ?? ""),
      DEST: this.sanitizeFileNamePart(destination?.name ?? ""),
      CHANNEL: this.sanitizeFileNamePart(channel?.name ?? ""),
      CHANNELNAME: this.sanitizeFileNamePart(channel?.name ?? ""),

      // Project
      PROJECT: this.sanitizeFileNamePart(project?.name ?? ""),
      PROJECTNAME: this.sanitizeFileNamePart(project?.name ?? ""),

      // Creative
      VALID: this.sanitizeFileNamePart(creative?.valid ?? creative?.name ?? fallbackName),
      CREATIVE: this.sanitizeFileNamePart(creative?.name ?? fallbackName),
      CREATIVENAME: this.sanitizeFileNamePart(creative?.name ?? fallbackName),
      CREATIVEID: this.sanitizeFileNamePart(creative?.id ?? ""),
      CAPTION: this.sanitizeFileNamePart(creative?.caption ?? ""),
      HOUSE_ID: this.sanitizeFileNamePart(this.getApprovalGate(task).houseId ?? ""),
      DUR: this.sanitizeFileNamePart(durationStr),
      DURATION: this.sanitizeFileNamePart(durationStr),
      DURSEC: this.sanitizeFileNamePart(durationSec),

      // Time
      DATE: `${yyyy}${mm}${dd}`,
      YYYYMMDD: `${yyyy}${mm}${dd}`,
      TIME: `${HH}${Min}`,
      HHMM: `${HH}${Min}`,

      // Uniqueness
      UUID8: this.sanitizeFileNamePart(String(task?.id ?? "").slice(0, 8)),

      // Extension (without dot)
      EXT: this.sanitizeFileNamePart(ext),
    };

    const tpl = String(destination?.fileNameTemplate ?? "").trim();

    // No template configured => old behavior (creative valid/name)
    if (!tpl) return this.sanitizeFileNamePart(fallbackName);

    const rendered = this.sanitizeFileNamePart(this.renderTemplate(tpl, values));

    // If template renders to empty (e.g. only unknown tokens), fallback.
    return rendered || this.sanitizeFileNamePart(fallbackName);
  }


  private async resolveDeliveryAsset(task: any): Promise<{ asset: any | null; message?: string }> {
    const creative = task?.planLine?.creative ?? null;
    const assets: any[] = Array.isArray(creative?.assets) ? creative.assets : [];
    const transcript = (task as any)?.transcript && typeof (task as any).transcript === "object" ? (task as any).transcript : {};
    const selectedPreset = transcript?.selectedPreset && typeof transcript.selectedPreset === "object" ? transcript.selectedPreset : null;
    const presetKey = selectedPreset?.key ? String(selectedPreset.key) : "";
    const creativeId = task?.planLine?.creativeId ?? creative?.id ?? null;
    const channelDestinationId = task?.planLine?.channel?.destinationId ?? task?.planLine?.channel?.destination?.id ?? selectedPreset?.destinationId ?? null;

    if (presetKey && creativeId) {
      const job = await getLatestCreativePresetJob(this.prisma, task.accountId, creativeId, presetKey);
      if (job?.status === "SUCCEEDED") {
        const output = extractPresetJobOutput(job);
        if (output?.path) {
          return {
            asset: {
              id: null,
              type: "OUTPUT",
              kind: "PRESET_OUTPUT",
              presetJobId: output.jobId,
              path: output.path,
              filename: output.filename ?? null,
              mimeType: output.mimeType ?? null,
              sizeBytes: output.bytes ?? null,
            },
          };
        }
      }

      await ensureCreativePresetJob(this.prisma, this.bus, {
        accountId: task.accountId,
        creativeId,
        destinationId: channelDestinationId,
        presetKey,
        userId: transcript?.requestedByUserId ? String(transcript.requestedByUserId) : null,
      }).catch(() => undefined);

      const status = job?.status ? String(job.status) : "QUEUED";
      return {
        asset: null,
        message: `Waiting for preset output ${presetKey} (${status}). Delivery will retry automatically once the transcode finishes.`,
      };
    }

    const fallback =
      assets.find((a) => a.type === "OUTPUT" && a.uploadStatus === "UPLOADED") ??
      assets.find((a) => a.type === "SOURCE" && a.uploadStatus === "UPLOADED") ??
      null;

    if (!fallback) return { asset: null, message: "No uploaded SOURCE/OUTPUT asset available" };
    return {
      asset: {
        ...fallback,
        kind: "CREATIVE_ASSET",
      },
    };
  }

  private async failOrRetry(task: any, message: string) {
    // Re-check current status because the user may have cancelled/paused while we were running.
    const cur = await this.prisma.deliveryTask.findFirst({
      where: { id: task.id },
      select: { status: true, attempts: true, maxAttempts: true },
    });
    if (!cur || cur.status === "CANCELLED") return;

    const routing = resolveDeliveryTaskRouting(task);
    const attempts = cur.attempts; // attempts already incremented at claim()
    const max = cur.maxAttempts ?? 3;
    const routeError = routing.routeConflict ? getDeliveryRouteConflictMessage(routing.mainRoute, routing.backupRoute) : null;
    const finalMessage = routeError || message;

    if (!routeError && attempts < max) {
      const backoffSec = Math.min(300, 10 * attempts * attempts);
      const nextRunAt = new Date(Date.now() + backoffSec * 1000);
      await this.prisma.deliveryTask.update({
        where: { id: task.id },
        data: {
          status: "QUEUED",
          runAfter: nextRunAt,
          lastError: finalMessage,
          transcript: withDeliveryRoutingTranscript(
            {
              ...((task as any)?.transcript && typeof (task as any).transcript === "object" ? (task as any).transcript : {}),
              lastError: finalMessage,
              attempts,
            },
            routing,
          ) as any,
        },
      });

      if (this.bus.isEnabled()) {
        await this.republishTask(task.id, routing.preferredRoute, `${task.id}:retry:${attempts}:${nextRunAt.getTime()}`, nextRunAt);
      }

      await this.notifications.emitType6Delivered(task.accountId, task.id).catch(() => undefined);
      return;
    }

    await this.prisma.deliveryTask.update({
      where: { id: task.id },
      data: {
        status: "FAILED",
        endedAt: new Date(),
        lastError: finalMessage,
        transcript: withDeliveryRoutingTranscript(
          {
            ...((task as any)?.transcript && typeof (task as any).transcript === "object" ? (task as any).transcript : {}),
            lastError: finalMessage,
            attempts,
          },
          routing,
        ) as any,
      },
    });
  }
}
