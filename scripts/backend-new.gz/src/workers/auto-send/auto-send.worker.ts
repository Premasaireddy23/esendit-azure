import { Cron } from "@nestjs/schedule";
import { Injectable, Logger } from "@nestjs/common";
import { PrismaService } from "../../common/prisma/prisma.service";
import { ServiceBusService } from "../../common/queue/service-bus.service";
import { DeliveryOrderStatus, DeliveryTaskStatus, PlanLineStatus } from "@prisma/client";
import { NotificationsService } from "../../modules/notifications/notifications.service";
import { ensureCreativePresetJob, resolveChannelDefaultPreset } from "../../common/presets/channel-default-preset";
import {
  getDeliveryQueueForRoute,
  getDeliveryRouteConflictMessage,
  resolveDeliveryRoutingFromProfiles,
  withDeliveryRoutingTranscript,
} from "../../common/queue/delivery-routing";

/**
 * SLA-based auto send
 *
 * Behavior:
 * - PlanLine.autoSendAt is computed at commit time from SLA.hoursTarget.
 * - When autoSendAt <= now, this worker creates DeliveryTasks (queued) and
 *   marks the plan line as SENT (same as manual send).
 *
 * Safe defaults:
 * - Disabled unless AUTO_SEND_WORKER_ENABLED=true
 */


function resolveDeliveryProfiles(channel: any) {
  const cfg = channel?.destination?.config && typeof channel.destination.config === "object" ? channel.destination.config : {};
  const defaults = cfg.deliveryProfileDefaults && typeof cfg.deliveryProfileDefaults === "object" ? cfg.deliveryProfileDefaults : {};

  return {
    mainDeliveryProfileId:
      channel?.mainDeliveryProfileId ?? defaults.mainProfileId ?? defaults.defaultProfileId ?? cfg.mainDeliveryProfileId ?? cfg.defaultDeliveryProfileId ?? null,
    backupDeliveryProfileId:
      channel?.backupDeliveryProfileId ?? defaults.backupProfileId ?? cfg.backupDeliveryProfileId ?? null,
  };
}

@Injectable()
export class AutoSendWorker {
  private log = new Logger(AutoSendWorker.name);

  constructor(
    private prisma: PrismaService,
    private readonly bus: ServiceBusService,
    private readonly notifications: NotificationsService,
  ) {}

  @Cron("0 * * * * *") // every minute (at second 0)
  async tick() {
    if ((process.env.AUTO_SEND_WORKER_ENABLED || "false").toLowerCase() !== "true") return;

    const now = new Date();
    const batch = Math.max(1, Number(process.env.AUTO_SEND_BATCH || "50"));

    // Pull a small batch of due plan lines.
    // NOTE: We only auto-send from the active plan version.
    const due = await this.prisma.planLine.findMany({
      where: {
        sentAt: null,
        status: PlanLineStatus.COMMITTED,
        autoSendAt: { not: null, lte: now },
        planVersion: { isActive: true, project: { status: "OPEN" } },
      },
      take: batch,
      orderBy: [{ autoSendAt: "asc" }],
      select: {
        id: true,
        accountId: true,
        creativeId: true,
        planVersionId: true,
        planVersion: { select: { projectId: true } },
        channel: {
          select: {
            id: true,
            destinationId: true,
            config: true,
            mainDeliveryProfileId: true,
            backupDeliveryProfileId: true,
            destination: { select: { config: true } },
          },
        },
      },
    });

    if (!due.length) return;

    // Group by (accountId, projectId, planVersionId) so we create 1 order per batch.
    const groups = new Map<string, typeof due>();
    for (const pl of due) {
      const projectId = pl.planVersion.projectId;
      const key = `${pl.accountId}::${projectId}::${pl.planVersionId}`;
      const arr = groups.get(key) ?? [];
      arr.push(pl);
      groups.set(key, arr);
    }

    for (const [key, lines] of groups.entries()) {
      const [accountId, projectId, planVersionId] = key.split("::");
      try {
        const result = await this.prisma.$transaction(async (tx) => {
          // Claim the plan lines first (avoid duplicates if multiple workers exist).
          const claimedIds: string[] = [];
          for (const l of lines) {
            // If a previous send created tasks but crashed before marking sentAt,
            // avoid creating duplicates.
            const alreadyHasTask = await tx.deliveryTask.findFirst({
              where: { accountId, planLineId: l.id },
              select: { id: true },
            });
            if (alreadyHasTask?.id) continue;

            const claimed = await tx.planLine.updateMany({
              where: { id: l.id, accountId, sentAt: null, status: PlanLineStatus.COMMITTED },
              data: { status: PlanLineStatus.SENT, sentAt: now },
            });
            if (claimed.count === 1) claimedIds.push(l.id);
          }

          if (!claimedIds.length) return { createdTasks: [] as Array<{ taskId: string; route: string }> };

          const order = await tx.deliveryOrder.create({
            data: {
              status: DeliveryOrderStatus.SENT,
              account: { connect: { id: accountId } },
              project: { connect: { id: projectId } },
              planVersion: { connect: { id: planVersionId } },
            },
            select: { id: true },
          });

          const claimedLines = lines.filter((line) => claimedIds.includes(line.id));
          const resolvedByPlanLineId = new Map<string, ReturnType<typeof resolveDeliveryProfiles>>(
            claimedLines.map((line) => [line.id, resolveDeliveryProfiles(line.channel)]),
          );
          const deliveryProfileIds = Array.from(
            new Set(
              claimedLines.flatMap((line) => {
                const resolved = resolvedByPlanLineId.get(line.id);
                return [resolved?.mainDeliveryProfileId, resolved?.backupDeliveryProfileId].filter(Boolean);
              }),
            ),
          ) as string[];
          const deliveryProfiles = deliveryProfileIds.length
            ? await tx.deliveryProfile.findMany({
                where: { accountId, id: { in: deliveryProfileIds } },
                select: { id: true, config: true },
              } as any)
            : [];
          const deliveryProfileById = new Map<string, any>(deliveryProfiles.map((profile: any) => [profile.id, profile]));

          const createdTasks: Array<{ taskId: string; route: string }> = [];
          const presetRequests: Array<{ creativeId: string; destinationId: string | null; presetKey: string }> = [];
          for (const l of claimedLines) {
            const resolved = resolvedByPlanLineId.get(l.id)!;
            const routing = resolveDeliveryRoutingFromProfiles(
              resolved.mainDeliveryProfileId ? deliveryProfileById.get(resolved.mainDeliveryProfileId) ?? null : null,
              resolved.backupDeliveryProfileId ? deliveryProfileById.get(resolved.backupDeliveryProfileId) ?? null : null,
            );
            if (routing.routeConflict) {
              throw new Error(`${getDeliveryRouteConflictMessage(routing.mainRoute, routing.backupRoute)} Channel=${l.channel?.id ?? "unknown"}.`);
            }

            const selectedPreset = await resolveChannelDefaultPreset(this.prisma, accountId, l.channel);
            const transcript = withDeliveryRoutingTranscript(
              selectedPreset
                ? {
                    mode: "CHANNEL_DEFAULT_PRESET",
                    selectedPreset: {
                      key: selectedPreset.key,
                      label: selectedPreset.label ?? selectedPreset.key,
                      ext: selectedPreset.ext ?? null,
                      mimeType: selectedPreset.mimeType ?? null,
                      destinationId: selectedPreset.destinationId ?? null,
                    },
                    requestedByUserId: null,
                  }
                : null,
              routing,
            );

            const created = await tx.deliveryTask.create({
              data: {
                accountId,
                orderId: order.id,
                planLineId: l.id,
                status: DeliveryTaskStatus.QUEUED,
                mainDeliveryProfileId: resolved.mainDeliveryProfileId,
                backupDeliveryProfileId: resolved.backupDeliveryProfileId,
                ...(selectedPreset ? { maxAttempts: 3 } : {}),
                transcript: transcript as any,
              } as any,
              select: { id: true },
            });
            if (selectedPreset) {
              presetRequests.push({ creativeId: l.creativeId, destinationId: selectedPreset.destinationId ?? null, presetKey: selectedPreset.key });
            }
            createdTasks.push({ taskId: created.id, route: routing.preferredRoute });
          }

          return { createdTasks, presetRequests };
        });

        for (const req of (result as any).presetRequests || []) {
          await ensureCreativePresetJob(this.prisma, this.bus, {
            accountId,
            creativeId: req.creativeId,
            destinationId: req.destinationId,
            presetKey: req.presetKey,
            userId: null,
          }).catch(() => undefined);
        }

        const createdTasks = result.createdTasks || [];

        // Wake delivery worker (scale-to-zero). No-op if Service Bus not configured.
        for (const item of createdTasks) {
          await this.bus
            .sendJson(getDeliveryQueueForRoute(item.route), { taskId: item.taskId }, { messageId: item.taskId })
            .catch(() => undefined);
          await this.notifications.emitType11FileSent(accountId, item.taskId).catch(() => undefined);
        }

        if (createdTasks.length) {
          this.log.log(
            `Auto-sent ${createdTasks.length} plan lines for project=${projectId} planVersion=${planVersionId} (account=${accountId})`,
          );
        }
      } catch (e: any) {
        this.log.error(`Auto-send failed for project=${projectId}: ${e?.message ?? e}`);
      }
    }
  }
}
