export type ApiError = Error & { status?: number; data?: any };

const TOKEN_KEY = "esendit_token";
const ACTIVE_RECEIVER_ACCOUNT_KEY = "esendit.activeReceiverAccountId";
const SUPPORT_ORIGINAL_TOKEN_KEY = "esendit.support.originalToken";

/**
 * Base URL for API calls.
 *
 * - Local dev (vite proxy): VITE_API_BASE=/api (default)
 * - ACA backend: VITE_API_BASE=https://backend.<env>.azurecontainerapps.io
 *
 * IMPORTANT: do NOT add /api suffix for ACA because backend is served at root.
 */
export const API_BASE: string = (import.meta as any).env?.VITE_API_BASE ?? "/api";

function isAbsoluteUrl(v: string) {
  return /^https?:\/\//i.test(v);
}

function joinUrl(base: string, path: string) {
  if (!path) return base;
  if (isAbsoluteUrl(path)) return path;

  const b = (base || "").replace(/\/+$/g, "");
  const p = path.startsWith("/") ? path : `/${path}`;

  if (!b) return p;
  return isAbsoluteUrl(b) ? `${b}${p}` : `${b}${p}`;
}

export function apiUrl(path: string) {
  // Preserve query strings if provided
  const [p, q] = path.split("?");
  const u = joinUrl(API_BASE, p);
  return q ? `${u}?${q}` : u;
}

export function getToken() {
  // Prefer session token if present; fall back to persisted token.
  return sessionStorage.getItem(TOKEN_KEY) || localStorage.getItem(TOKEN_KEY) || "";
}

/**
 * @param persist If true, store in localStorage (survives browser restart). If false, store in sessionStorage.
 */
export function setToken(token: string, persist: boolean = true) {
  if (persist) {
    localStorage.setItem(TOKEN_KEY, token);
    sessionStorage.removeItem(TOKEN_KEY);
  } else {
    sessionStorage.setItem(TOKEN_KEY, token);
    localStorage.removeItem(TOKEN_KEY);
  }
}

export function clearToken() {
  localStorage.removeItem(TOKEN_KEY);
  sessionStorage.removeItem(TOKEN_KEY);
  sessionStorage.removeItem(SUPPORT_ORIGINAL_TOKEN_KEY);
}

export function getActiveReceiverAccountId() {
  try {
    return localStorage.getItem(ACTIVE_RECEIVER_ACCOUNT_KEY) || "";
  } catch {
    return "";
  }
}

export function setActiveReceiverAccountId(id: string) {
  try {
    const value = String(id || "").trim();
    if (value) localStorage.setItem(ACTIVE_RECEIVER_ACCOUNT_KEY, value);
    else localStorage.removeItem(ACTIVE_RECEIVER_ACCOUNT_KEY);
  } catch {
    // ignore storage errors
  }
}

export function startSupportSessionToken(accessToken: string) {
  const current = getToken();
  if (current) sessionStorage.setItem(SUPPORT_ORIGINAL_TOKEN_KEY, current);
  setToken(accessToken, false);
}

export function hasSupportOriginalToken() {
  return !!sessionStorage.getItem(SUPPORT_ORIGINAL_TOKEN_KEY);
}

export function exitSupportSessionToken() {
  const original = sessionStorage.getItem(SUPPORT_ORIGINAL_TOKEN_KEY) || "";
  sessionStorage.removeItem(SUPPORT_ORIGINAL_TOKEN_KEY);
  if (original) {
    localStorage.setItem(TOKEN_KEY, original);
    sessionStorage.removeItem(TOKEN_KEY);
    return true;
  }
  clearToken();
  return false;
}

async function safeParseJson(text: string) {
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}

export async function api<T>(path: string, opts: RequestInit = {}): Promise<T> {
  const token = getToken();
  const isForm = typeof FormData !== "undefined" && opts.body instanceof FormData;

  const headers: Record<string, string> = {
    ...(opts.headers as any),
  };

  // Only set JSON content-type when body is NOT FormData
  if (!isForm && !headers["Content-Type"] && !headers["content-type"]) {
    headers["Content-Type"] = "application/json";
  }

  // attach JWT automatically (unless caller explicitly sets authorization)
  const lower = Object.keys(headers).reduce((a, k) => ({ ...a, [k.toLowerCase()]: true }), {} as any);
  if (token && !lower["authorization"]) headers["Authorization"] = `Bearer ${token}`;
  const activeReceiverAccountId = getActiveReceiverAccountId();
  if (activeReceiverAccountId && !lower["x-active-receiver-account-id"]) {
    headers["X-Active-Receiver-Account-Id"] = activeReceiverAccountId;
  }

  const res = await fetch(apiUrl(path), { ...opts, headers });

  const text = await res.text();
  const data = text ? await safeParseJson(text) : null;

  if (!res.ok) {
    const errMsg = res.status === 403
      ? "Unauthorised"
      : (data && (data.message || data.error)) || `${res.status} ${res.statusText}`;
    const err: ApiError = Object.assign(new Error(errMsg), { status: res.status, data });

    if (res.status === 401) clearToken();
    throw err;
  }

  return data as T;
}

function parseFilenameFromDisposition(v: string | null): string | null {
  if (!v) return null;
  // content-disposition: attachment; filename="x.csv"
  const m = /filename\*=UTF-8''([^;]+)|filename=\"([^\"]+)\"|filename=([^;]+)/i.exec(v);
  const raw = (m?.[1] ?? m?.[2] ?? m?.[3])?.trim();
  if (!raw) return null;
  try {
    return decodeURIComponent(raw.replace(/^"|"$/g, ""));
  } catch {
    return raw.replace(/^"|"$/g, "");
  }
}

/**
 * Download binary file from backend (CSV/Excel).
 * Uses the same auth header logic as api().
 */
export async function apiDownload(path: string, opts: RequestInit = {}, fallbackFilename = "download") {
  const token = getToken();
  const headers: Record<string, string> = {
    ...(opts.headers as any),
  };

  const lower = Object.keys(headers).reduce((a, k) => ({ ...a, [k.toLowerCase()]: true }), {} as any);
  if (token && !lower["authorization"]) headers["Authorization"] = `Bearer ${token}`;
  const activeReceiverAccountId = getActiveReceiverAccountId();
  if (activeReceiverAccountId && !lower["x-active-receiver-account-id"]) {
    headers["X-Active-Receiver-Account-Id"] = activeReceiverAccountId;
  }

  const res = await fetch(apiUrl(path), { ...opts, headers });

  if (!res.ok) {
    // Try parse error JSON
    let data: any = null;
    try {
      data = await res.json();
    } catch {
      // ignore
    }
    const errMsg = res.status === 403
      ? "Unauthorised"
      : (data && (data.message || data.error)) || `${res.status} ${res.statusText}`;
    const err: ApiError = Object.assign(new Error(errMsg), { status: res.status, data });
    if (res.status === 401) clearToken();
    throw err;
  }

  const blob = await res.blob();
  const filename = parseFilenameFromDisposition(res.headers.get("content-disposition")) || fallbackFilename;

  const url = URL.createObjectURL(blob);
  try {
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
  } finally {
    URL.revokeObjectURL(url);
  }
}
