import { api } from "./api";
import { canonicalizePermissionKey } from "./permissions";

export type Permission = { key: string; type: "ACTION" | "PAGE" | string };

export type ValidGenerationStrategy = "FILENAME_DRIVEN" | "SPEC_DRIVEN";

export type CreativeValidConfig = {
  label?: string;
  strategy?: ValidGenerationStrategy;

  // per-country defaults
  stereoRequired?: boolean;
  defaultLanguages?: string[];

  // optional knobs (kept loose on purpose to avoid FE/BE drift)
  spec?: {
    partLen?: number;
    langLen?: number;
    includeFormat?: boolean;
    includeLang?: boolean;
    includeDuration?: boolean;
    durationMode?: "SEC" | "RAW";
  };
  filename?: {
    includeMonthYearPrefix?: boolean;
    removeUnderscores?: boolean;
    removeSpaces?: boolean;
    removeSecToken?: boolean;
    keepExtension?: boolean;
  };
};

export type UiConfig = {
  /**
   * Backwards compatible label (Phase 3 Option 1).
   * If creativeValid.label is present, it wins.
   */
  creativeCodeLabel?: string;
  notificationAdminEmail?: string;
  notificationAdminOnlyMode?: boolean;

  /**
   * Section 6A: VALID generation config (default).
   */
  creativeValid?: CreativeValidConfig;

  /**
   * Section 6A: per-country overrides.
   * Key is Country.id (UUID).
   */
  creativeValidByCountry?: Record<string, CreativeValidConfig>;
};

export type ReceiverAccountContext = {
  id: string;
  name: string;
  receiverCategory?: string | null;
  accountType?: string | null;
};

export type SupportViewContext = {
  active: boolean;
  impersonatedByUserId?: string | null;
  impersonatedByEmail?: string | null;
  reason?: string | null;
  ticket?: string | null;
  startedAt?: string | null;
} | null;

export type MeResponse = {
  user: {
    id: string;
    accountId: string;
    email: string;
    displayName?: string | null;
    userType?: string | null;
  };
  account?: {
    id: string;
    code?: string;
    uiConfig?: UiConfig | null;
  } | null;
  permissions: Permission[];
  receiverAccounts?: ReceiverAccountContext[];
  supportView?: SupportViewContext;
};

export const ME_UPDATED_EVENT = "me:updated";

let cached: MeResponse | null = null;

export async function getMe(force = false): Promise<MeResponse> {
  if (!force && cached) return cached;
  cached = await api<MeResponse>("/auth/me");
  return cached;
}

export function clearMeCache() {
  cached = null;
}

/**
 * Call this after changing roles / permissions so nav + layouts re-fetch /auth/me.
 */
export function emitMeUpdated() {
  clearMeCache();
  // guard for SSR/tests
  if (typeof window !== "undefined") {
    window.dispatchEvent(new Event(ME_UPDATED_EVENT));
  }
}

export function hasPerm(me: MeResponse | null | undefined, key: string) {
  if (!me) return false;
  const want = canonicalizePermissionKey(key);
  return me.permissions.some((p) => canonicalizePermissionKey(p.key) === want);
}


// convenience: check if user has ANY of the permissions in the list
export function hasAnyPerm(me: MeResponse | null, perms: string[]) {
  if (!Array.isArray(perms) || perms.length === 0) return false;
  return perms.some((p) => hasPerm(me, p));
}

function mergeCreativeValid(ui: UiConfig | null | undefined, countryId?: string | null): CreativeValidConfig {
  const base = (ui?.creativeValid || {}) as CreativeValidConfig;
  const byCountry = (countryId && ui?.creativeValidByCountry && ui.creativeValidByCountry[countryId]) || {};
  return {
    ...base,
    ...byCountry,
    spec: { ...(base.spec || {}), ...((byCountry as any).spec || {}) },
    filename: { ...(base.filename || {}), ...((byCountry as any).filename || {}) },
  };
}

/**
 * Dynamic label for Creative Code (default: VALID).
 * - First prefers uiConfig.creativeValid.label
 * - Falls back to uiConfig.creativeCodeLabel (legacy)
 */
export function getCreativeCodeLabel(me: MeResponse | null | undefined, countryId?: string | null): string {
  const ui = (me as any)?.account?.uiConfig as UiConfig | undefined;
  const cfg = mergeCreativeValid(ui, countryId);
  const raw = (cfg.label || ui?.creativeCodeLabel || "VALID") as string;
  return typeof raw === "string" && raw.trim() ? raw.trim() : "VALID";
}

/**
 * Section 6A: Convenience getter used by Creatives UI.
 */
export function getCreativeValidConfig(me: MeResponse | null | undefined, countryId?: string | null): CreativeValidConfig {
  const ui = (me as any)?.account?.uiConfig as UiConfig | undefined;
  return mergeCreativeValid(ui, countryId);
}
