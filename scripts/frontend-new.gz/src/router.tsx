import { createBrowserRouter, Navigate } from "react-router-dom";
import { LoginPage } from "./ui/LoginPage";
import { RequireAuth } from "./ui/RequireAuth";
import { ForgotPasswordPage } from "./ui/ForgotPasswordPage";
import { SignupPage } from "./ui/SignupPage";
import { ResetPasswordPage } from "./ui/ResetPasswordPage";
import { HomePage } from "./ui/HomePage";
import { AppShell } from "./ui/AppShell";
import { RequireAnyPermission } from "./ui/RequireAnyPermission";
import { ACCOUNTS_PAGE_PERMISSIONS } from "./features/masters/accountsPermissions";
import {
  AGENCY_HUB_PAGE_PERMISSIONS,
  AGENCY_TEAMS_PAGE_PERMISSIONS,
  AGENCIES_PAGE_PERMISSIONS,
  ADVERTISER_GROUPS_PAGE_PERMISSIONS,
  ADVERTISERS_PAGE_PERMISSIONS,
  BILLABLE_PARTIES_PAGE_PERMISSIONS,
  BILLING_CHARGES_PAGE_PERMISSIONS,
  BILLING_INVOICES_PAGE_PERMISSIONS,
  BRANDS_PAGE_PERMISSIONS,
  CHANNELS_PAGE_PERMISSIONS,
  DELIVERY_PROFILES_PAGE_PERMISSIONS,
  DELIVERY_SETUP_PAGE_PERMISSIONS,
  DESTINATIONS_PAGE_PERMISSIONS,
  HOT_FOLDERS_PAGE_PERMISSIONS,
  MASTERS_OVERVIEW_PAGE_PERMISSIONS,
  PRODUCT_CATEGORIES_PAGE_PERMISSIONS,
  RATE_CARDS_PAGE_PERMISSIONS,
  SLAS_PAGE_PERMISSIONS,
} from "./features/masters/mastersPermissions";

import { ProjectLayout } from "./features/projects/ProjectLayout";
import { CreativesPage } from "./features/projects/pages/CreativesPage";
import { QcPage } from "./features/projects/pages/QcPage";
import { TranscodePage } from "./features/projects/pages/TranscodePage";
import { ApprovalsPage } from "./features/projects/pages/ApprovalsPage";
import { PlannerPage } from "./features/projects/pages/PlannerPage";
import TrackingPage from "./features/projects/pages/TrackingPage";
import { SendPage } from "./features/projects/pages/SendPage";
import ProjectCreateWizardPage from "./features/projects/wizard/ProjectCreateWizardPage";

import { TasksPage } from "./features/operations/TasksPage";

import { AdminLayout } from "./features/admin/AdminLayout";
import { AdminUsersPage } from "./features/admin/pages/AdminUserPage";
import { AdminRolesPage } from "./features/admin/pages/AdminRolesPage";
import { AdminGroupsPage } from "./features/admin/pages/AdminGroupsPage";
import { AdminPermissionsPage } from "./features/admin/pages/AdminPermissionsPage";
import { AdminServerStatusPage } from "./features/admin/pages/AdminServerStatusPage";
import { AdminAccountSettingsPage } from "./features/admin/pages/AdminAccountSettingsPage";
import { AdminPresetLibraryPage } from "./features/admin/pages/AdminPresetLibraryPage";

import { MastersLayout } from "./features/masters/MastersLayout";
import { AdvertiserGroupsPage } from "./features/masters/pages/AdvertiserGroupsPage";
import { AdvertisersPage } from "./features/masters/pages/AdvertisersPage";
import { BrandsPage } from "./features/masters/pages/BrandsPage";
import { CountriesPage } from "./features/masters/pages/CountriesPage";
import { CitiesPage } from "./features/masters/pages/CitiesPage";
import { ProductCategoriesPage } from "./features/masters/pages/ProductCategoriesPage";
import { AgenciesPage } from "./features/masters/pages/AgenciesPage";
import { AgencyTeamsPage } from "./features/masters/pages/AgencyTeamsPage";
import { SlasPage } from "./features/masters/pages/SlasPage";
import { BillablePartiesPage } from "./features/masters/pages/BillablePartiesPage";
import { RateCardsPage } from "./features/masters/pages/RateCardsPage";
import { DestinationsPage } from "./features/masters/pages/DestinationsPage";
import { ChannelsPage } from "./features/masters/pages/ChannelsPage";
import { DeliveryProfilesPage } from "./features/masters/pages/DeliveryProfilesPage";
import { DeliverySetupPage } from "./features/masters/pages/DeliverySetupPage";
import { HotFoldersPage } from "./features/masters/pages/HotFoldersPage";
import { AccountsPage } from "./features/masters/pages/AccountsPage";
import { PartnerAccountsCreatePage } from "./features/masters/pages/PartnerAccountsCreatePage";
import { MastersHomePage } from "./features/masters/pages/MastersHomePage";

import { DamPage } from "./features/dam/DamPage";
import { BulkBatchesPage } from "./features/bulk/BulkBatchesPage";
import { BulkBatchDetailPage } from "./features/bulk/BulkBatchDetailPage";
import { BillingChargesPage } from "./features/billing/BillingChargesPage";
import { BillingInvoicesPage } from "./features/billing/BillingInvoicesPage";

import { AgencyHubPage } from "./features/masters/pages/AgencyHubPage";

import { AdvertiserGroupsCreatePage } from "./features/masters/pages/AdvertiserGroupsCreatePage";
import { AdvertisersCreatePage } from "./features/masters/pages/AdvertisersCreatePage";
import { BrandsCreatePage } from "./features/masters/pages/BrandsCreatePage";
import { AgenciesCreatePage } from "./features/masters/pages/AgenciesCreatePage";
import { AgencyTeamsCreatePage } from "./features/masters/pages/AgencyTeamsCreatePage";

import { ProductCategoriesCreatePage } from "./features/masters/pages/ProductCategoriesCreatePage";

import { ProjectsPage } from "./features/projects/pages/ProjectsPage";
import { ProjectEditPage } from "./features/projects/pages/ProjectEditPage";




export const router = createBrowserRouter([
  { path: "/login", element: <LoginPage /> },
  { path: "/forgot-password", element: <ForgotPasswordPage /> },
  { path: "/reset-password", element: <ResetPasswordPage /> },
  { path: "/signup", element: <SignupPage /> },

  // ✅ After login: show left sidebar for all pages
  {
    path: "/",
    element: (
      <RequireAuth>
        <AppShell />
      </RequireAuth>
    ),
    children: [
      { index: true, element: <HomePage /> },

      {
        path: "admin",
        element: <AdminLayout />,
        children: [
          { path: "users", element: <RequireAnyPermission permissions={["ADMIN_USERS_READ"]} title="People access denied"><AdminUsersPage /></RequireAnyPermission> },
          { path: "roles", element: <RequireAnyPermission permissions={["ADMIN_ROLES_READ"]} title="Access Profiles access denied"><AdminRolesPage /></RequireAnyPermission> },
          { path: "groups", element: <RequireAnyPermission permissions={["ADMIN_GROUPS_READ"]} title="Teams access denied"><AdminGroupsPage /></RequireAnyPermission> },
          { path: "permissions", element: <RequireAnyPermission permissions={["ADMIN_ROLES_READ"]} title="Permission Library access denied"><AdminPermissionsPage /></RequireAnyPermission> },
          { path: "server-status", element: <RequireAnyPermission permissions={["SERVER_STATUS_READ"]} title="Server Status access denied"><AdminServerStatusPage /></RequireAnyPermission> },
          { path: "account-settings", element: <RequireAnyPermission permissions={["ACCOUNT_SETTINGS_READ", "ACCOUNT_SETTINGS_WRITE"]} title="Account Settings access denied"><AdminAccountSettingsPage /></RequireAnyPermission> },
          { path: "presets", element: <RequireAnyPermission permissions={["ACCOUNT_SETTINGS_READ", "ACCOUNT_SETTINGS_WRITE"]} title="Transcode Presets access denied"><AdminPresetLibraryPage /></RequireAnyPermission> },
        ],
      },

      {
        path: "masters",
        element: <MastersLayout />,
        children: [
          { index: true, element: <RequireAnyPermission permissions={MASTERS_OVERVIEW_PAGE_PERMISSIONS} title="Masters access denied"><MastersHomePage /></RequireAnyPermission> },

            { path: "advertiser-groups/new", element: <RequireAnyPermission permissions={ADVERTISER_GROUPS_PAGE_PERMISSIONS} title="Advertiser Groups access denied"><AdvertiserGroupsCreatePage /></RequireAnyPermission> },
            { path: "advertisers/new", element: <RequireAnyPermission permissions={ADVERTISERS_PAGE_PERMISSIONS} title="Advertisers access denied"><AdvertisersCreatePage /></RequireAnyPermission> },
            { path: "brands/new", element: <RequireAnyPermission permissions={BRANDS_PAGE_PERMISSIONS} title="Brands access denied"><BrandsCreatePage /></RequireAnyPermission> },
            { path: "agencies/new", element: <RequireAnyPermission permissions={AGENCIES_PAGE_PERMISSIONS} title="Agencies access denied"><AgenciesCreatePage /></RequireAnyPermission> },
            { path: "agency-teams/new", element: <RequireAnyPermission permissions={AGENCY_TEAMS_PAGE_PERMISSIONS} title="Agency Teams access denied"><AgencyTeamsCreatePage /></RequireAnyPermission> },
            { path: "product-categories/new", element: <RequireAnyPermission permissions={PRODUCT_CATEGORIES_PAGE_PERMISSIONS} title="Product Categories access denied"><ProductCategoriesCreatePage /></RequireAnyPermission> },
            { path: "accounts/new", element: <RequireAnyPermission permissions={ACCOUNTS_PAGE_PERMISSIONS} title="Accounts access denied" message={<>Need <code>page:masters:accounts</code> or temporary legacy <code>MASTERS_READ</code>.</>}><PartnerAccountsCreatePage /></RequireAnyPermission> },

          { path: "advertiser-groups", element: <RequireAnyPermission permissions={ADVERTISER_GROUPS_PAGE_PERMISSIONS} title="Advertiser Groups access denied"><AdvertiserGroupsPage /></RequireAnyPermission> },
          { path: "advertisers", element: <RequireAnyPermission permissions={ADVERTISERS_PAGE_PERMISSIONS} title="Advertisers access denied"><AdvertisersPage /></RequireAnyPermission> },
          { path: "brands", element: <RequireAnyPermission permissions={BRANDS_PAGE_PERMISSIONS} title="Brands access denied"><BrandsPage /></RequireAnyPermission> },
          { path: "countries", element: <CountriesPage /> },
          { path: "cities", element: <CitiesPage /> },
          { path: "product-categories", element: <RequireAnyPermission permissions={PRODUCT_CATEGORIES_PAGE_PERMISSIONS} title="Product Categories access denied"><ProductCategoriesPage /></RequireAnyPermission> },
          { path: "agencies", element: <RequireAnyPermission permissions={AGENCIES_PAGE_PERMISSIONS} title="Agencies access denied"><AgenciesPage /></RequireAnyPermission> },
          { path: "agency-teams", element: <RequireAnyPermission permissions={AGENCY_TEAMS_PAGE_PERMISSIONS} title="Agency Teams access denied"><AgencyTeamsPage /></RequireAnyPermission> },
          { path: "slas", element: <RequireAnyPermission permissions={SLAS_PAGE_PERMISSIONS} title="SLAs access denied"><SlasPage /></RequireAnyPermission> },
          { path: "destinations", element: <RequireAnyPermission permissions={DESTINATIONS_PAGE_PERMISSIONS} title="Destinations access denied"><DestinationsPage /></RequireAnyPermission> },
          { path: "delivery-setup", element: <RequireAnyPermission permissions={DELIVERY_SETUP_PAGE_PERMISSIONS} title="Delivery Setup access denied"><DeliverySetupPage /></RequireAnyPermission> },
          { path: "delivery-profiles", element: <RequireAnyPermission permissions={DELIVERY_PROFILES_PAGE_PERMISSIONS} title="Delivery Profiles access denied"><DeliveryProfilesPage /></RequireAnyPermission> },
          { path: "channels", element: <RequireAnyPermission permissions={CHANNELS_PAGE_PERMISSIONS} title="Channels access denied"><ChannelsPage /></RequireAnyPermission> },
          { path: "billable-parties", element: <RequireAnyPermission permissions={BILLABLE_PARTIES_PAGE_PERMISSIONS} title="Billable Parties access denied"><BillablePartiesPage /></RequireAnyPermission> },
          { path: "rate-cards", element: <RequireAnyPermission permissions={RATE_CARDS_PAGE_PERMISSIONS} title="Rate Cards access denied"><RateCardsPage /></RequireAnyPermission> },
          { path: "hot-folders", element: <RequireAnyPermission permissions={HOT_FOLDERS_PAGE_PERMISSIONS} title="Hot Folders access denied"><HotFoldersPage /></RequireAnyPermission> },
          { path: "accounts", element: <RequireAnyPermission permissions={ACCOUNTS_PAGE_PERMISSIONS} title="Accounts access denied" message={<>Need <code>page:masters:accounts</code> or temporary legacy <code>MASTERS_READ</code>.</>}><AccountsPage /></RequireAnyPermission> },
          { path: "agency-hub", element: <RequireAnyPermission permissions={AGENCY_HUB_PAGE_PERMISSIONS} title="Agencies access denied"><AgencyHubPage /></RequireAnyPermission> },
        ],
      },

      { path: "dam", element: <RequireAnyPermission permissions={["page:library", "action:library:read", "action:library:read:scoped", "action:library:index", "action:library:stream", "action:library:stream:scoped", "page:dam", "action:dam:read", "action:dam:index", "action:dam:stream", "page:projects", "action:projects:scoped:read"]} title="Library access denied"><DamPage /></RequireAnyPermission> },

      { path: "bulk", element: <RequireAnyPermission permissions={["page:bulk", "action:bulk:read", "action:bulk:create", "action:bulk:import", "action:bulk:upload", "action:bulk:process", "action:bulk:stream"]} title="Bulk access denied"><BulkBatchesPage /></RequireAnyPermission> },
      { path: "bulk/batches/:id", element: <RequireAnyPermission permissions={["page:bulk", "action:bulk:read", "action:bulk:create", "action:bulk:import", "action:bulk:upload", "action:bulk:process", "action:bulk:stream"]} title="Bulk access denied"><BulkBatchDetailPage /></RequireAnyPermission> },

      { path: "billing/charges", element: <RequireAnyPermission permissions={BILLING_CHARGES_PAGE_PERMISSIONS} title="Billing access denied"><BillingChargesPage /></RequireAnyPermission> },
      { path: "billing/invoices", element: <RequireAnyPermission permissions={BILLING_INVOICES_PAGE_PERMISSIONS} title="Billing access denied"><BillingInvoicesPage /></RequireAnyPermission> },

      { path: "tracking", element: <RequireAnyPermission permissions={["action:tracking:read", "action:tracking:read:scoped", "page:projects", "action:projects:scoped:read"]} title="Tracking access denied"><TrackingPage /></RequireAnyPermission> },

      { path: "operations/tasks", element: <TasksPage /> },

      { path: "projects", element: <RequireAnyPermission permissions={["PROJECT_READ", "page:projects", "action:projects:scoped:read"]} title="Projects access denied"><ProjectsPage /></RequireAnyPermission> },
      { path: "projects/:id/edit", element: <RequireAnyPermission permissions={["PROJECT_UPDATE", "page:projects", "action:projects:scoped:read"]} title="Project edit access denied"><ProjectEditPage /></RequireAnyPermission> },
      { path: "projects/new", element: <RequireAnyPermission permissions={["PROJECT_CREATE", "PROJECT_WIZARD_CREATE", "action:projects:create", "action:projects:wizard:create"]} title="Create Project access denied"><ProjectCreateWizardPage /></RequireAnyPermission> },

      {
        path: "projects/:id",
        element: <RequireAnyPermission permissions={["PROJECT_READ", "page:projects", "action:projects:scoped:read"]} title="Project access denied"><ProjectLayout /></RequireAnyPermission>,
        children: [
          { path: "creatives", element: <CreativesPage /> },
          { path: "qc", element: <QcPage /> },
          { path: "planner", element: <PlannerPage /> },
          { path: "approvals", element: <ApprovalsPage /> },
          { path: "transcode", element: <TranscodePage /> },
          { path: "send", element: <SendPage /> },
          { path: "tracking", element: <RequireAnyPermission permissions={["action:tracking:read", "action:tracking:read:scoped", "page:projects", "action:projects:scoped:read"]} title="Tracking access denied"><TrackingPage /></RequireAnyPermission> },
        ],
      },

      { path: "*", element: <Navigate to="/" replace /> },
    ],
  },
]);
