// Frontend build-safe placeholder.
// The real NestJS TrackingService belongs in the backend codebase, not the frontend Vite app.
// Keeping this file minimal avoids TypeScript frontend build errors when the frontend tsconfig
// scans src/orders.
export {};
