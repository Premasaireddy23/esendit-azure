import React from "react";
import leftImg from "../assets/auth-left.png";

export function AuthLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="auth-page">
      <div className="auth-frame">
        <div className="auth-split">
          <div className="auth-left">
            <img src={leftImg} alt="eSENDIT" />
          </div>
          <div className="auth-right">{children}</div>
        </div>
      </div>
    </div>
  );
}
