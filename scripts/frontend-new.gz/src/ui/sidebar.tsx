import { createContext, useContext, type ReactNode } from "react";

export type SidebarCtx = {
  open: boolean;
  setOpen: (open: boolean) => void;
  toggle: () => void;
};

// HomeRefreshBar is also used on auth pages (outside AppShell),
// so the hook must be safe and return null when not provided.
const SidebarContext = createContext<SidebarCtx | null>(null);

export function SidebarProvider(props: { value: SidebarCtx; children: ReactNode }) {
  return <SidebarContext.Provider value={props.value}>{props.children}</SidebarContext.Provider>;
}

export function useSidebar(): SidebarCtx | null {
  return useContext(SidebarContext);
}
