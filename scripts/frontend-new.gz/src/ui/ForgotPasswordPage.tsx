import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../lib/api";
import { AuthLayout } from "./AuthLayout";

export function ForgotPasswordPage() {
  const nav = useNavigate();

  const [email, setEmail] = useState("");
  const [loading, setLoading] = useState(false);
  const [done, setDone] = useState(false);
  const [err, setErr] = useState("");

  const canSubmit = useMemo(() => email.trim().length > 3, [email]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setErr("");
    setLoading(true);
    try {
      await api<{ ok: boolean }>("/auth/forgot-password", {
        method: "POST",
        body: JSON.stringify({ email: email.trim() }),
      });
      setDone(true);
    } catch (e: any) {
      setErr(e?.message || "Failed to send reset email");
    } finally {
      setLoading(false);
    }
  }

  return (
    <AuthLayout>
      <div className="auth-form">
        <div style={{ display: "grid", gap: 6 }}>
          <h1 className="auth-title">Forgot password?</h1>
          <div className="auth-caption">No worries, we&apos;ll Send you reset instructions.</div>
        </div>

        {done ? (
          <div className="card" style={{ display: "grid", gap: 10 }}>
            <div style={{ fontWeight: 800 }}>Check your email</div>
            <div style={{ color: "#555", fontSize: 13 }}>
              If an account exists for <b>{email}</b>, you&apos;ll receive a password reset link.
            </div>
            <button className="auth-primary" type="button" onClick={() => nav("/login")}>
              Back to Log in
            </button>
          </div>
        ) : (
          <form onSubmit={onSubmit} style={{ display: "grid", gap: 14 }}>
            <label className="auth-field">
              <div className="auth-label">Email Address</div>
              <input
                className="auth-input"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="name@domainname.com"
                autoComplete="email"
              />
            </label>

            {err ? <div style={{ color: "crimson", fontSize: 13 }}>{err}</div> : null}

            <button className="auth-primary" type="submit" disabled={!canSubmit || loading}>
              {loading ? "Sending…" : "Reset Password"}
            </button>

            <button type="button" className="auth-link" onClick={() => nav("/login")}>
              Back to Log in
            </button>
          </form>
        )}
      </div>
    </AuthLayout>
  );
}
