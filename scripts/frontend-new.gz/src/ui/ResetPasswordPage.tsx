import { useMemo, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { api, clearToken } from "../lib/api";

export function ResetPasswordPage() {
  const nav = useNavigate();
  const [params] = useSearchParams();

  const token = useMemo(() => params.get("token") || "", [params]);
  const accountCode = useMemo(() => params.get("accountCode") || "", [params]);

  const [newPassword, setNewPassword] = useState("");
  const [confirm, setConfirm] = useState("");
  const [loading, setLoading] = useState(false);
  const [ok, setOk] = useState(false);
  const [err, setErr] = useState("");

  const mismatch = confirm.length > 0 && newPassword !== confirm;

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setErr("");

    if (!token) {
      setErr("Missing token. Please use the link from your email.");
      return;
    }
    if (newPassword.length < 6) {
      setErr("Password must be at least 6 characters.");
      return;
    }
    if (newPassword !== confirm) {
      setErr("Passwords do not match.");
      return;
    }

    setLoading(true);
    try {
      await api<{ ok: boolean }>("/auth/reset-password", {
        method: "POST",
        headers: { Authorization: "" },
        body: JSON.stringify({
          token,
          newPassword,
          ...(accountCode?.trim() ? { accountCode: accountCode.trim() } : {}),
        }),
      });

      // Clear any old session token in browser
      clearToken();
      setOk(true);
    } catch (e: any) {
      setErr(e?.message || "Reset failed");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div style={{ padding: 16, maxWidth: 420, margin: "0 auto" }}>
      <h2>Reset password</h2>

      {!token ? (
        <div className="card" style={{ display: "grid", gap: 10 }}>
          <div style={{ color: "crimson" }}>
            Missing token. Please open the reset link from your email.
          </div>
          <button onClick={() => nav("/forgot-password")}>Request a new link</button>
        </div>
      ) : ok ? (
        <div className="card" style={{ display: "grid", gap: 10 }}>
          <div>Password updated successfully.</div>
          <button onClick={() => nav("/login")}>Go to login</button>
        </div>
      ) : (
        <form onSubmit={onSubmit} className="card" style={{ display: "grid", gap: 10 }}>
          <label style={{ display: "grid", gap: 6 }}>
            <div>New password</div>
            <input
              type="password"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              placeholder="Min 6 characters"
              required
            />
          </label>

          <label style={{ display: "grid", gap: 6 }}>
            <div>Confirm password</div>
            <input
              type="password"
              value={confirm}
              onChange={(e) => setConfirm(e.target.value)}
              required
            />
          </label>

          {mismatch ? (
            <div style={{ color: "crimson", fontSize: 13 }}>Passwords do not match.</div>
          ) : null}

          {err ? <div style={{ color: "crimson", fontSize: 13 }}>{err}</div> : null}

          <div className="row" style={{ justifyContent: "space-between" }}>
            <button type="button" onClick={() => nav("/login")} disabled={loading}>
              Cancel
            </button>
            <button type="submit" disabled={loading || !newPassword || !confirm || mismatch}>
              {loading ? "Updating…" : "Update password"}
            </button>
          </div>
        </form>
      )}
    </div>
  );
}
