import { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../lib/api";
import { getMe, hasPerm, type MeResponse } from "../lib/me";

type Range = "today" | "weekly" | "monthly" | "yearly";
type Metric = "activeDeliveries" | "deliveriesCompleted" | "deliveriesPending" | "approvalsPending";

type Overview = {
  range: Range;
  totals: {
    projectsTotal: number;
    projectsOpen: number;
    activeDeliveries: number;
    deliveriesCompleted: number;
    deliveriesPending: number;
    approvalsPending: number;
  };
  series: {
    buckets: string[];
    activeDeliveries: number[];
    deliveriesCompleted: number[];
    deliveriesPending: number[];
    approvalsPending: number[];
  };
};

type DashboardQuickCount = {
  total: number;
  active: number | null;
};

type DashboardQuickCountsResponse = {
  destinations: DashboardQuickCount | null;
  channels: DashboardQuickCount | null;
  deliveryProfiles: DashboardQuickCount | null;
  accounts: DashboardQuickCount | null;
  people: DashboardQuickCount | null;
};

const QUICK_COUNTS_CACHE_KEY = "dashboard:quick-counts:v1";

type CountCard = {
  key: "destinations" | "channels" | "deliveryProfiles" | "accounts" | "people";
  label: string;
  href: string;
  total: number;
  active?: number | null;
};

function fmtBucket(iso: string, range: Range) {
  const d = new Date(iso);
  if (range === "yearly") return d.toLocaleString(undefined, { month: "short" });
  if (range === "today") return d.toLocaleTimeString(undefined, { hour: "2-digit" });
  return d.toLocaleDateString(undefined, { day: "2-digit", month: "short" });
}

function readCachedCountCards() {
  if (typeof window === "undefined") return [] as CountCard[];
  try {
    const raw = window.sessionStorage.getItem(QUICK_COUNTS_CACHE_KEY);
    if (!raw) return [] as CountCard[];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as CountCard[]) : ([] as CountCard[]);
  } catch {
    return [] as CountCard[];
  }
}

function writeCachedCountCards(cards: CountCard[]) {
  if (typeof window === "undefined") return;
  try {
    window.sessionStorage.setItem(QUICK_COUNTS_CACHE_KEY, JSON.stringify(cards));
  } catch {}
}

function toCountCards(data: DashboardQuickCountsResponse): CountCard[] {
  const next: CountCard[] = [];

  if (data.destinations) {
    next.push({
      key: "destinations",
      label: "Destinations",
      href: "/masters/destinations",
      total: data.destinations.total,
      active: data.destinations.active,
    });
  }

  if (data.channels) {
    next.push({
      key: "channels",
      label: "Channels",
      href: "/masters/channels",
      total: data.channels.total,
      active: data.channels.active,
    });
  }

  if (data.deliveryProfiles) {
    next.push({
      key: "deliveryProfiles",
      label: "Delivery Profiles",
      href: "/masters/delivery-profiles",
      total: data.deliveryProfiles.total,
      active: data.deliveryProfiles.active,
    });
  }

  if (data.accounts) {
    next.push({
      key: "accounts",
      label: "Accounts",
      href: "/masters/accounts",
      total: data.accounts.total,
      active: data.accounts.active,
    });
  }

  if (data.people) {
    next.push({
      key: "people",
      label: "People",
      href: "/admin/users",
      total: data.people.total,
      active: data.people.active,
    });
  }

  return next;
}

function Kpi({
  label,
  value,
  active = false,
  onClick,
}: {
  label: string;
  value: number;
  active?: boolean;
  onClick?: () => void;
}) {
  return (
    <button
      type="button"
      className={active ? "kpi kpi--button kpi--active" : "kpi kpi--button"}
      onClick={onClick}
      aria-pressed={active}
      title={`Show ${label} chart`}
    >
      <div className="kpi__value">{value}</div>
      <div className="kpi__label">{label}</div>
    </button>
  );
}

export function HomePage() {
  const nav = useNavigate();
  const [me, setMe] = useState<MeResponse | null>(null);

  const [range, setRange] = useState<Range>("weekly");
  const [metric, setMetric] = useState<Metric>("activeDeliveries");

  const [data, setData] = useState<Overview | null>(null);
  const [err, setErr] = useState<string>("");
  const [countCards, setCountCards] = useState<CountCard[]>(() => readCachedCountCards());
  const [countsLoading, setCountsLoading] = useState(false);

  useEffect(() => {
    getMe().then(setMe).catch(() => setMe(null));
  }, []);

  useEffect(() => {
    setErr("");
    api<Overview>(`/dashboard/overview?range=${range}`)
      .then(setData)
      .catch((e) => setErr(e.message || "Failed to load dashboard"));
  }, [range]);

  useEffect(() => {
    let cancelled = false;

    async function loadCounts() {
      if (!me) {
        if (!cancelled) setCountCards([]);
        return;
      }

      if (!cancelled) setCountsLoading(true);

      try {
        const response = await api<DashboardQuickCountsResponse>("/dashboard/quick-counts");
        if (cancelled) return;
        const next = toCountCards(response);
        setCountCards(next);
        writeCachedCountCards(next);
      } catch {
        if (!cancelled) {
          const cached = readCachedCountCards();
          setCountCards(cached);
        }
      } finally {
        if (!cancelled) setCountsLoading(false);
      }
    }

    loadCounts();

    return () => {
      cancelled = true;
    };
  }, [me]);

  const visibleCountCards = useMemo(() => {
    return countCards.filter((card) => {
      switch (card.key) {
        case "destinations":
          return hasPerm(me, "page:masters:destinations");
        case "channels":
          return hasPerm(me, "page:masters:channels");
        case "deliveryProfiles":
          return hasPerm(me, "page:masters:delivery-profiles");
        case "accounts":
          return hasPerm(me, "page:masters:accounts");
        case "people":
          return hasPerm(me, "ADMIN_USERS_READ");
        default:
          return true;
      }
    });
  }, [countCards, me]);

  const buckets = data?.series.buckets ?? [];
  const values = (data?.series?.[metric] ?? []) as number[];

  const max = useMemo(() => Math.max(1, ...values), [values]);
  const chartMaxBarHeight = 156;

  return (
    <div className="dash">
      <div className="dash__hero">
        <div>
          <div className="dash__welcome">Welcome, {me?.user.email ?? "User"}</div>
          <div className="dash__title">Sender Overview</div>
        </div>

        <div className="dash__heroRight">
          <button onClick={() => nav("/projects/new")}>New Project</button>
        </div>
      </div>

      {err && <div className="dash__error">{err}</div>}

      {visibleCountCards.length ? (
        <div className="dashSummary card">
          <div className="dashSummary__head">
            <div>
              <div className="dashSummary__title">Quick master visibility</div>
              <div className="dashSummary__sub">Live totals for the setup entities clients ask about most.</div>
            </div>
            {countsLoading ? <div className="dashSummary__loading">Refreshing…</div> : null}
          </div>

          <div className="dashSummary__grid">
            {visibleCountCards.map((card) => (
              <button key={card.key} type="button" className="summaryStat" onClick={() => nav(card.href)}>
                <div className="summaryStat__value">{card.total}</div>
                <div className="summaryStat__label">{card.label}</div>
                <div className="summaryStat__meta">{typeof card.active === "number" ? `${card.active} active` : "Total records"}</div>
              </button>
            ))}
          </div>
        </div>
      ) : null}

      <div className="kpiRow">
        <Kpi
          label="No. of Active Deliveries"
          value={data?.totals.activeDeliveries ?? 0}
          active={metric === "activeDeliveries"}
          onClick={() => setMetric("activeDeliveries")}
        />
        <Kpi
          label="No. of Deliveries Completed"
          value={data?.totals.deliveriesCompleted ?? 0}
          active={metric === "deliveriesCompleted"}
          onClick={() => setMetric("deliveriesCompleted")}
        />
        <Kpi
          label="No. of Deliveries Pending"
          value={data?.totals.deliveriesPending ?? 0}
          active={metric === "deliveriesPending"}
          onClick={() => setMetric("deliveriesPending")}
        />
        <Kpi
          label="Approval pending"
          value={data?.totals.approvalsPending ?? 0}
          active={metric === "approvalsPending"}
          onClick={() => setMetric("approvalsPending")}
        />
      </div>

      <div className="dashCard">
        <div className="dashCard__head">
          <div className="pillRow pillRow--metrics">
            <button
              className={metric === "activeDeliveries" ? "pill pill--on" : "pill"}
              onClick={() => setMetric("activeDeliveries")}
            >
              Active Deliveries
            </button>
            <button
              className={metric === "deliveriesCompleted" ? "pill pill--on" : "pill"}
              onClick={() => setMetric("deliveriesCompleted")}
            >
              Deliveries Completed
            </button>
            <button
              className={metric === "deliveriesPending" ? "pill pill--on" : "pill"}
              onClick={() => setMetric("deliveriesPending")}
            >
              Deliveries Pending
            </button>
            <button
              className={metric === "approvalsPending" ? "pill pill--on" : "pill"}
              onClick={() => setMetric("approvalsPending")}
            >
              Approval Pending
            </button>
          </div>

          <div className="pillRow pillRow--ranges">
            <button className={range === "today" ? "pill pill--on" : "pill"} onClick={() => setRange("today")}>
              Today
            </button>
            <button className={range === "weekly" ? "pill pill--on" : "pill"} onClick={() => setRange("weekly")}>
              Weekly
            </button>
            <button className={range === "monthly" ? "pill pill--on" : "pill"} onClick={() => setRange("monthly")}>
              Monthly
            </button>
            <button className={range === "yearly" ? "pill pill--on" : "pill"} onClick={() => setRange("yearly")}>
              Yearly
            </button>
          </div>
        </div>

        <div className="chart">
          <div className="chart__track">
            {values.map((v, i) => (
              <div className="chartCol" key={buckets[i] || i}>
                <div
                  className="chartBarWrap"
                  title={`${v}`}
                  aria-label={`${buckets[i] ? fmtBucket(buckets[i], range) : "Value"}: ${v}`}
                >
                  <span className="chartBarTooltip">{v}</span>
                  <div className="chartBar" style={{ height: `${Math.round((v / max) * chartMaxBarHeight)}px` }} />
                </div>
                <div className="chartLabel">{buckets[i] ? fmtBucket(buckets[i], range) : ""}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
