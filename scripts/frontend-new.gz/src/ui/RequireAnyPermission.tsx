import { useEffect, useState, type ReactNode } from "react";
import { getMe, hasAnyPerm, type MeResponse } from "../lib/me";

type Props = {
  permissions: readonly string[];
  children: ReactNode;
  title?: string;
  message?: ReactNode;
};

export function RequireAnyPermission({ permissions, children, title = "You don’t have permission.", message }: Props) {
  const [me, setMe] = useState<MeResponse | null | undefined>(undefined);

  useEffect(() => {
    getMe().then(setMe).catch(() => setMe(null));
  }, []);

  if (me === undefined) {
    return <div style={{ padding: 16 }}>Checking permissions…</div>;
  }

  if (!hasAnyPerm(me ?? null, [...permissions])) {
    return (
      <div style={{ padding: 16 }}>
        <div className="card" style={{ padding: 12 }}>
          <div style={{ fontWeight: 800, marginBottom: 6 }}>{title}</div>
          {message ? <div>{message}</div> : null}
        </div>
      </div>
    );
  }

  return <>{children}</>;
}
