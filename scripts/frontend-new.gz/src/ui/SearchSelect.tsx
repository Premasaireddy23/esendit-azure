import { useEffect, useMemo, useRef, useState, type KeyboardEvent } from "react";

export type SearchSelectOption = {
  id: string;
  name?: string;
  label?: string;
  code?: string | null;
  [k: string]: any;
};

export type SearchSelectProps = {
  label: string;
  value: string;
  onChange: (id: string) => void;
  options: SearchSelectOption[];
  placeholder?: string;
  disabled?: boolean;
  allowClear?: boolean;
  // Optional element rendered to the right of the input (e.g., + button)
  rightElement?: any;
  // Optional inline creation for missing values.
  onCreateOption?: (query: string) => void | Promise<void>;
  createOptionLabel?: string;
  createOptionDisabled?: boolean;
};

function getLabel(o: SearchSelectOption): string {
  return (o.name ?? o.label ?? o.code ?? o.id ?? "").toString();
}

export function SearchSelect({
  label,
  value,
  onChange,
  options,
  placeholder,
  disabled,
  allowClear = true,
  rightElement,
  onCreateOption,
  createOptionLabel,
  createOptionDisabled = false,
}: SearchSelectProps) {
  const wrapRef = useRef<HTMLDivElement | null>(null);

  const selected = useMemo(() => options.find((o) => o.id === value) || null, [options, value]);
  const [query, setQuery] = useState<string>(selected ? getLabel(selected) : "");
  const [open, setOpen] = useState(false);
  const [creating, setCreating] = useState(false);
  const [highlightedIndex, setHighlightedIndex] = useState(0);
  const optionRefs = useRef<Array<HTMLDivElement | null>>([]);

  useEffect(() => {
    // keep input text aligned with selected value
    setQuery(selected ? getLabel(selected) : "");
  }, [selected?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    function onDocDown(e: MouseEvent) {
      if (!wrapRef.current) return;
      if (!wrapRef.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", onDocDown);
    return () => document.removeEventListener("mousedown", onDocDown);
  }, []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return options.slice(0, 50);
    return options
      .filter((o) => getLabel(o).toLowerCase().includes(q))
      .slice(0, 50);
  }, [options, query]);

  const normalizedQuery = query.trim();
  const hasExactMatch = useMemo(() => {
    const q = normalizedQuery.toLowerCase();
    if (!q) return false;
    return options.some((o) => getLabel(o).trim().toLowerCase() === q);
  }, [options, normalizedQuery]);

  const canCreateOption = Boolean(onCreateOption && normalizedQuery && !hasExactMatch);

  useEffect(() => {
    if (!open) return;
    if (!filtered.length) {
      setHighlightedIndex(0);
      return;
    }
    const selectedIndex = filtered.findIndex((o) => o.id === value);
    setHighlightedIndex(selectedIndex >= 0 ? selectedIndex : 0);
  }, [filtered, open, value]);

  useEffect(() => {
    if (!open) return;
    optionRefs.current[highlightedIndex]?.scrollIntoView({ block: "nearest" });
  }, [highlightedIndex, open]);

  function selectOption(option: SearchSelectOption) {
    const text = getLabel(option);
    onChange(option.id);
    setQuery(text);
    setOpen(false);
  }

  function handleInputKeyDown(e: KeyboardEvent<HTMLInputElement>) {
    if (disabled) return;
    if (e.key === "ArrowDown") {
      e.preventDefault();
      setOpen(true);
      setHighlightedIndex((current) => {
        if (!filtered.length) return 0;
        return Math.min(current + 1, filtered.length - 1);
      });
      return;
    }
    if (e.key === "ArrowUp") {
      e.preventDefault();
      setOpen(true);
      setHighlightedIndex((current) => {
        if (!filtered.length) return 0;
        return Math.max(current - 1, 0);
      });
      return;
    }
    if (e.key === "Enter") {
      if (!open || !filtered.length) return;
      e.preventDefault();
      const selectedOption = filtered[Math.min(highlightedIndex, filtered.length - 1)];
      if (selectedOption) selectOption(selectedOption);
      return;
    }
    if (e.key === "Escape") {
      setOpen(false);
    }
  }

  return (
    <div ref={wrapRef} style={{ position: "relative" }}>
      <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>{label}</div>

      <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
        <input
          style={{ width: "100%" }}
          value={query}
          disabled={disabled}
          placeholder={placeholder}
          onFocus={() => setOpen(true)}
          onChange={(e) => {
            setQuery(e.target.value);
            setOpen(true);
          }}
          onKeyDown={handleInputKeyDown}
        />

        {allowClear && !disabled && value && (
          <button
            type="button"
            onClick={() => {
              onChange("");
              setQuery("");
              setOpen(false);
            }}
            style={{ padding: "6px 10px" }}
            title="Clear"
          >
            ✕
          </button>
        )}

        {rightElement ? <span style={{ display: "inline-flex" }}>{rightElement}</span> : null}
      </div>

      {open && !disabled && (
        <div
          role="listbox"
          style={{
            position: "absolute",
            zIndex: 20,
            top: "100%",
            left: 0,
            right: 0,
            marginTop: 6,
            border: "1px solid rgba(0,0,0,0.12)",
            borderRadius: 8,
            background: "white",
            maxHeight: 260,
            overflow: "auto",
            boxShadow: "0 10px 30px rgba(0,0,0,0.10)",
          }}
        >
          {filtered.length === 0 && !canCreateOption ? (
            <div style={{ padding: 10, fontSize: 13, opacity: 0.75 }}>No matches</div>
          ) : null}

          {canCreateOption ? (
            <button
              type="button"
              onMouseDown={(e) => e.preventDefault()}
              disabled={creating || createOptionDisabled}
              onClick={async () => {
                if (!onCreateOption || !normalizedQuery || creating || createOptionDisabled) return;
                try {
                  setCreating(true);
                  await onCreateOption(normalizedQuery);
                  setOpen(false);
                } finally {
                  setCreating(false);
                }
              }}
              style={{
                width: "100%",
                textAlign: "left",
                padding: "10px 12px",
                cursor: creating || createOptionDisabled ? "not-allowed" : "pointer",
                fontSize: 13,
                background: "rgba(14,165,233,0.08)",
                border: 0,
                borderBottom: "1px solid rgba(0,0,0,0.06)",
              }}
            >
              {creating ? "Adding..." : `${createOptionLabel || "Add"} "${normalizedQuery}"`}
            </button>
          ) : null}

          {filtered.map((o, index) => {
            const text = getLabel(o);
            const active = o.id === value;
            const highlighted = index === highlightedIndex;
            return (
              <div
                key={o.id}
                ref={(el) => {
                  optionRefs.current[index] = el;
                }}
                role="option"
                aria-selected={active || highlighted}
                tabIndex={0}
                onMouseDown={(e) => e.preventDefault()} // keep focus
                onMouseEnter={() => setHighlightedIndex(index)}
                onClick={() => selectOption(o)}
                style={{
                  padding: "10px 12px",
                  cursor: "pointer",
                  fontSize: 13,
                  background: active ? "rgba(37,99,235,0.10)" : highlighted ? "rgba(0,0,0,0.04)" : "transparent",
                  borderBottom: "1px solid rgba(0,0,0,0.06)",
                }}
              >
                {text}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
