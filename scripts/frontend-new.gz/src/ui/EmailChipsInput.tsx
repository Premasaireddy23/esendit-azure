import { useEffect, useMemo, useRef, useState } from "react";
import type { KeyboardEvent } from "react";

type Props = {
  value: string[];
  onChange: (next: string[]) => void;
  placeholder?: string;
  disabled?: boolean;
  /** optional callback when user tries to add an invalid email */
  onInvalidEmail?: (value: string) => void;
};

function norm(s: string) {
  return String(s || "").trim();
}

function isLikelyEmail(s: string) {
  const v = norm(s);
  if (!v) return false;
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
}

function splitTokens(raw: string) {
  return raw
    .split(/[,\s]+/g)
    .map((s) => s.trim())
    .filter(Boolean);
}

export function EmailChipsInput({ value, onChange, placeholder, disabled, onInvalidEmail }: Props) {
  const [input, setInput] = useState("");
  const inputRef = useRef<HTMLInputElement | null>(null);

  const chips = useMemo(() => (Array.isArray(value) ? value : []), [value]);

  function addMany(raw: string) {
    const parts = splitTokens(raw);
    if (!parts.length) return;
    let changed = false;
    const set = new Set(chips.map((c) => norm(c).toLowerCase()).filter(Boolean));

    for (const p of parts) {
      if (!isLikelyEmail(p)) {
        onInvalidEmail?.(p);
        continue;
      }
      const key = p.toLowerCase();
      if (!set.has(key)) {
        set.add(key);
        changed = true;
      }
    }

    if (changed) onChange(Array.from(set));
  }

  function remove(v: string) {
    const key = norm(v).toLowerCase();
    onChange(chips.filter((c) => norm(c).toLowerCase() !== key));
  }

  function commit() {
    if (!input.trim()) return;
    addMany(input);
    setInput("");
  }

  function onKeyDown(e: KeyboardEvent<HTMLInputElement>) {
    if (disabled) return;
    if (e.key === "Enter" || e.key === ",") {
      e.preventDefault();
      commit();
      return;
    }
    if (e.key === "Backspace" && !input) {
      if (chips.length) remove(chips[chips.length - 1]);
    }
  }

  useEffect(() => {
    if (!input) return;
    if (!/[\s,]/.test(input)) return;
    // if user pasted many, auto-commit when it looks like a list
    const parts = splitTokens(input);
    if (parts.length <= 1) return;
    addMany(input);
    setInput("");
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [input]);

  return (
    <div
      style={{
        border: "1px solid rgba(0,0,0,0.15)",
        borderRadius: 10,
        padding: 8,
        display: "flex",
        flexWrap: "wrap",
        gap: 8,
        alignItems: "center",
        background: disabled ? "rgba(0,0,0,0.03)" : "white",
        minHeight: 42,
      }}
      onClick={() => inputRef.current?.focus()}
    >
      {chips.map((c) => (
        <span
          key={c}
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: 6,
            padding: "4px 10px",
            borderRadius: 999,
            background: "rgba(0,0,0,0.06)",
            fontSize: 13,
          }}
          title={c}
        >
          <span style={{ maxWidth: 380, overflow: "hidden", textOverflow: "ellipsis" }}>{c}</span>
          <button
            type="button"
            disabled={disabled}
            onClick={(e) => {
              e.stopPropagation();
              remove(c);
            }}
            style={{
              border: "none",
              background: "transparent",
              cursor: disabled ? "not-allowed" : "pointer",
              opacity: 0.7,
              fontWeight: 900,
              lineHeight: 1,
            }}
          >
            ×
          </button>
        </span>
      ))}

      <input
        ref={inputRef}
        value={input}
        onChange={(e) => setInput(e.target.value)}
        onKeyDown={onKeyDown}
        onBlur={commit}
        disabled={disabled}
        placeholder={placeholder || "Type email(s) and press Enter"}
        style={{
          minWidth: 240,
          flex: 1,
          border: "none",
          outline: "none",
          background: "transparent",
        }}
      />
    </div>
  );
}
