import { useEffect, type CSSProperties, type ReactNode } from "react";
import { createPortal } from "react-dom";

type ModalWidth = "sm" | "md" | "lg" | "xl" | "xxl";

function modalWidthValue(width?: number | ModalWidth) {
  if (typeof width === "number") return `min(${width}px, calc(100vw - 32px))`;
  switch (width) {
    case "sm":
      return "min(460px, calc(100vw - 32px))";
    case "md":
      return "min(620px, calc(100vw - 32px))";
    case "xl":
      return "min(1120px, calc(100vw - 32px))";
    case "xxl":
      return "min(1280px, calc(100vw - 32px))";
    case "lg":
    default:
      return "min(840px, calc(100vw - 32px))";
  }
}

export function AppModal(props: {
  open: boolean;
  title: string;
  subtitle?: string;
  onClose: () => void;
  children: ReactNode;
  width?: number | ModalWidth;
  headerActions?: ReactNode;
  footer?: ReactNode;
  panelStyle?: CSSProperties;
  bodyStyle?: CSSProperties;
  bodyClassName?: string;
  closeLabel?: string;
}) {
  const {
    open,
    title,
    subtitle,
    onClose,
    children,
    width,
    headerActions,
    footer,
    panelStyle,
    bodyStyle,
    bodyClassName,
    closeLabel = "Close",
  } = props;

  useEffect(() => {
    if (!open || typeof document === "undefined") return;
    const prevOverflow = document.body.style.overflow;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
    };
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", onKeyDown);
    return () => {
      document.body.style.overflow = prevOverflow;
      window.removeEventListener("keydown", onKeyDown);
    };
  }, [open, onClose]);

  if (!open || typeof document === "undefined") return null;

  return createPortal(
    <div
      className="app-modal-backdrop"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <div
        role="dialog"
        aria-modal="true"
        className="app-modal"
        style={{ width: modalWidthValue(width), ...panelStyle }}
        onMouseDown={(event) => event.stopPropagation()}
      >
        <div className="app-modal__header">
          <div className="app-modal__title-wrap">
            <div className="app-modal__title">{title}</div>
            {subtitle ? <div className="app-modal__subtitle">{subtitle}</div> : null}
          </div>
          <div className="app-modal__header-actions">
            {headerActions}
            <button type="button" className="app-modal__close" onClick={onClose} aria-label={closeLabel}>
              ×
            </button>
          </div>
        </div>
        <div className={bodyClassName ? `app-modal__body ${bodyClassName}` : "app-modal__body"} style={bodyStyle}>
          {children}
        </div>
        {footer ? <div className="app-modal__footer">{footer}</div> : null}
      </div>
    </div>,
    document.body,
  );
}
