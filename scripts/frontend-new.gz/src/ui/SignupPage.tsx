import { useNavigate } from "react-router-dom";
import { AuthLayout } from "./AuthLayout";

export function SignupPage() {
  const nav = useNavigate();

  return (
    <AuthLayout>
      <div className="auth-form">
        <div style={{ display: "grid", gap: 6 }}>
          <h1 className="auth-title">Signup</h1>
          <div className="auth-caption">Signup is not enabled yet in this environment.</div>
        </div>

        <div className="card" style={{ display: "grid", gap: 10 }}>
          <div style={{ fontWeight: 800 }}>How to get access</div>
          <div style={{ color: "#555", fontSize: 13 }}>
            Please contact your account administrator to create a user for you.
          </div>
        </div>

        <button className="auth-primary" type="button" onClick={() => nav("/login")}>
          Back to Log in
        </button>
      </div>
    </AuthLayout>
  );
}
