import { useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";

export type KebabItem = {
  label: string;
  onClick?: () => void | Promise<void>;
  disabled?: boolean;
  danger?: boolean;
};

type Pos = { left: number; top: number };

export function KebabMenu({ items }: { items: KebabItem[] }) {
  const [open, setOpen] = useState(false);
  const btnRef = useRef<HTMLButtonElement | null>(null);
  const menuRef = useRef<HTMLDivElement | null>(null);
  const [pos, setPos] = useState<Pos>({ left: 0, top: 0 });

  const safeItems = useMemo(() => (items || []).filter(Boolean), [items]);

  // Approximate height so we can place the menu within the viewport even
  // before we know the exact rendered height.
  const estimatedHeight = useMemo(() => {
    const per = 44; // row height
    const pad = 12;
    return Math.min(420, safeItems.length * per + pad);
  }, [safeItems.length]);

  function computePos() {
    const btn = btnRef.current;
    if (!btn) return;
    const r = btn.getBoundingClientRect();

    const menuW = 220;
    const margin = 8;

    // align menu's right edge with button's right edge (like a typical kebab)
    let left = r.right - menuW;
    left = Math.max(margin, Math.min(left, window.innerWidth - margin - menuW));

    // open below by default, but flip upwards if it would go off-screen
    let top = r.bottom + 6;
    const wouldOverflow = top + estimatedHeight > window.innerHeight - margin;
    if (wouldOverflow) {
      top = Math.max(margin, r.top - 6 - estimatedHeight);
    }

    setPos({ left, top });
  }

  useLayoutEffect(() => {
    if (!open) return;
    computePos();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, estimatedHeight]);

  useEffect(() => {
    if (!open) return;

    const onDocPointerDown = (e: MouseEvent | TouchEvent) => {
      const target = e.target as Node | null;
      const btn = btnRef.current;
      const menu = menuRef.current;

      if (target && btn && btn.contains(target)) return;
      if (target && menu && menu.contains(target)) return;

      setOpen(false);
    };

    const onDocKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };

    const onScrollOrResize = () => computePos();

    document.addEventListener("mousedown", onDocPointerDown);
    document.addEventListener("touchstart", onDocPointerDown);
    document.addEventListener("keydown", onDocKeyDown);
    window.addEventListener("scroll", onScrollOrResize, true);
    window.addEventListener("resize", onScrollOrResize);

    return () => {
      document.removeEventListener("mousedown", onDocPointerDown);
      document.removeEventListener("touchstart", onDocPointerDown);
      document.removeEventListener("keydown", onDocKeyDown);
      window.removeEventListener("scroll", onScrollOrResize, true);
      window.removeEventListener("resize", onScrollOrResize);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  return (
    <>
      <button
        ref={btnRef}
        type="button"
        style={{ padding: "6px 10px", minWidth: 34, textAlign: "center" }}
        aria-haspopup="menu"
        aria-expanded={open}
        onClick={(e) => {
          e.stopPropagation();
          setOpen((v) => !v);
        }}
      >
        ⋯
      </button>

      {open
        ? createPortal(
            <div
              ref={menuRef}
              role="menu"
              style={{
                position: "fixed",
                left: pos.left,
                top: pos.top,
                zIndex: 2000,
                background: "white",
                border: "1px solid rgba(0,0,0,0.10)",
                borderRadius: 12,
                boxShadow: "0 10px 24px rgba(0,0,0,0.14)",
                padding: 6,
                width: 220,
                maxHeight: 420,
                overflow: "auto",
                display: "flex",
                flexDirection: "column",
                alignItems: "stretch",
              }}
              onClick={(e) => e.stopPropagation()}
            >
              {safeItems.map((it, idx) => (
                <button
                  key={idx}
                  type="button"
                  role="menuitem"
                  disabled={!!it.disabled}
                  onClick={async (e) => {
                    e.stopPropagation();
                    if (it.disabled) return;
                    setOpen(false);
                    try {
                      await it.onClick?.();
                    } catch (err) {
                      console.error(err);
                    }
                  }}
                  style={{
                    display: "block",
                    width: "100%",
                    textAlign: "left",
                    padding: "10px 10px",
                    borderRadius: 10,
                    border: "none",
                    background: "transparent",
                    cursor: it.disabled ? "not-allowed" : "pointer",
                    opacity: it.disabled ? 0.45 : 1,
                    color: it.danger ? "#a10000" : undefined,
                    fontWeight: 800,
                    whiteSpace: "nowrap",
                  }}
                >
                  {it.label}
                </button>
              ))}
            </div>,
            document.body,
          )
        : null}
    </>
  );
}
