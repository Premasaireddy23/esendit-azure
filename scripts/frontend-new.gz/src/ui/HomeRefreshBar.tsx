import type { ReactNode } from "react";
import "./homebar.css";

export function HomeRefreshBar(props: {
  title?: string;
  onRefresh?: () => void;
  right?: ReactNode;
  flat?: boolean;
}) {
  return (
    <div className={`homebar${props.flat ? " homebar--flat" : ""}`}>
      <div className="homebar__inner">
        {props.title ? <span className="homebar__crumb">{props.title}</span> : null}
        {props.right ? <div className="homebar__right">{props.right}</div> : null}
      </div>
    </div>
  );
}
