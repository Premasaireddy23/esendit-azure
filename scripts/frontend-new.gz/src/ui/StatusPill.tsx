export function StatusPill({ status, title }: { status: string; title?: string }) {
  const s = (status || "UNKNOWN").toUpperCase();

  const palette: Record<string, { bg: string; dot: string; border: string }> = {
    // infra
    ONLINE: { bg: "#ecfdf5", dot: "#10b981", border: "#bbf7d0" },
    OFFLINE: { bg: "#fff1f2", dot: "#ef4444", border: "#fecdd3" },

    // delivery / workflow
    SUCCESS: { bg: "#ecfdf5", dot: "#10b981", border: "#bbf7d0" },
    PASSED: { bg: "#ecfdf5", dot: "#10b981", border: "#bbf7d0" },
    APPROVED: { bg: "#ecfdf5", dot: "#10b981", border: "#bbf7d0" },

    FAILED: { bg: "#fff1f2", dot: "#ef4444", border: "#fecdd3" },
    REJECTED: { bg: "#fff1f2", dot: "#ef4444", border: "#fecdd3" },

    RUNNING: { bg: "#fffbeb", dot: "#f59e0b", border: "#fde68a" },
    QUEUED: { bg: "#eff6ff", dot: "#3b82f6", border: "#bfdbfe" },
    PENDING: { bg: "#eff6ff", dot: "#3b82f6", border: "#bfdbfe" },

    PAUSED: { bg: "#f5f3ff", dot: "#8b5cf6", border: "#ddd6fe" },
    WAITING_APPROVAL: { bg: "#fff7ed", dot: "#f97316", border: "#fdba74" },
    CANCELLED: { bg: "#f8fafc", dot: "#64748b", border: "#e2e8f0" },

    PARTIAL: { bg: "#f8fafc", dot: "#64748b", border: "#e2e8f0" },
    MIXED: { bg: "#f8fafc", dot: "#64748b", border: "#e2e8f0" },
  };

  const p = palette[s] || { bg: "#f8fafc", dot: "#64748b", border: "#e2e8f0" };

  const style: React.CSSProperties = {
    display: "inline-flex",
    alignItems: "center",
    gap: 6,
    padding: "2px 8px",
    borderRadius: 999,
    fontSize: 12,
    whiteSpace: "nowrap",
    flexWrap: "nowrap",
    border: `1px solid ${p.border}`,
    background: p.bg,
  };

  return (
    <span style={style} title={title || ""}>
      <span style={{
        width: 8,
        height: 8,
        borderRadius: 999,
        background: p.dot,
      }} />
      {s}
    </span>
  );
}
