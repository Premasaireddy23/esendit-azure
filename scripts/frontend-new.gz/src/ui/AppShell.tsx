import { Link, NavLink, Outlet, useLocation, useNavigate } from "react-router-dom";
import { useEffect, useLayoutEffect, useMemo, useRef, useState, type WheelEvent } from "react";
import { api, clearToken, exitSupportSessionToken, getActiveReceiverAccountId, setActiveReceiverAccountId } from "../lib/api";
import { getMe, hasAnyPerm, hasPerm, ME_UPDATED_EVENT, type MeResponse } from "../lib/me";
import { SidebarProvider } from "./sidebar";
import { AppModal } from "./AppModal";
import esenditLogo from "../assets/esendit-logo.png";

type GroupKey = "masters" | "agencies" | "delivery" | "admin" | "billing";

function cls(active: boolean) {
  return "nav-item" + (active ? " nav-item--active" : "");
}

function topCls(active: boolean) {
  return cls(active) + " nav-item--top";
}

function isDeliveryPath(pathname: string) {
  return [
    "/masters/delivery-setup",
    "/masters/destinations",
    "/masters/delivery-profiles",
    "/masters/channels",
    "/masters/slas",
  ].some((prefix) => pathname === prefix || pathname.startsWith(prefix + "/"));
}

function isAgencyPath(pathname: string) {
  return [
    "/masters/agency-hub",
    "/masters/agencies",
    "/masters/agency-teams",
    "/masters/agencies/new",
    "/masters/agency-teams/new",
  ].some((prefix) => pathname === prefix || pathname.startsWith(prefix + "/") || pathname.startsWith(prefix + "?"));
}

function isMastersPath(pathname: string) {
  return pathname.startsWith("/masters") && !isDeliveryPath(pathname) && !isAgencyPath(pathname);
}

function isAdminPath(pathname: string) {
  return pathname.startsWith("/admin") || pathname.startsWith("/bulk");
}

function prettyNameFromEmail(email: string) {
  const raw = (email || "").split("@")[0] || "User";
  return raw
    .replace(/[._-]+/g, " ")
    .split(/\s+/)
    .filter(Boolean)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");
}

export function AppShell() {
  const nav = useNavigate();
  const loc = useLocation();
  const [me, setMe] = useState<MeResponse | null>(null);
  const [activeReceiverAccountId, setActiveReceiverAccountIdState] = useState(() => getActiveReceiverAccountId());
  const [profileOpen, setProfileOpen] = useState(false);
  const profileWrapRef = useRef<HTMLDivElement | null>(null);
  const [changePasswordOpen, setChangePasswordOpen] = useState(false);
  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [changePasswordError, setChangePasswordError] = useState("");
  const [changePasswordSuccess, setChangePasswordSuccess] = useState("");
  const [changePasswordSaving, setChangePasswordSaving] = useState(false);


  function agencyLinkClass(type: string, view = "group") {
    const sp = new URLSearchParams(loc.search);
    const active =
      loc.pathname === "/masters/agency-hub" &&
      (sp.get("type") || "").toUpperCase() === type.toUpperCase() &&
      (sp.get("view") || "group").toLowerCase() === view.toLowerCase();
    return cls(active);
  }

  const [compactUi, setCompactUi] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem("esendit.ui.compact");
      if (saved === "1") return true;
      if (saved === "0") return false;
    } catch {
      // ignore
    }
    return true;
  });

  const [viewport, setViewport] = useState(() => ({
    width: typeof window !== "undefined" ? window.innerWidth : 1440,
    height: typeof window !== "undefined" ? window.innerHeight : 900,
  }));

  const [sidebarOpen, setSidebarOpen] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem("esendit.sidebar.open");
      if (saved === "1") return true;
      if (saved === "0") return false;
    } catch {
      // ignore
    }

    try {
      return !window.matchMedia("(max-width: 900px)").matches;
    } catch {
      return true;
    }
  });

  const [open, setOpen] = useState<Record<GroupKey, boolean>>(() => ({
    masters: true,
    agencies: true,
    delivery: true,
    admin: false,
    billing: false,
  }));
  const sidebarNavRef = useRef<HTMLElement | null>(null);

  useEffect(() => {
    try {
      localStorage.setItem("esendit.sidebar.open", sidebarOpen ? "1" : "0");
    } catch {
      // ignore
    }
  }, [sidebarOpen]);

  useEffect(() => {
    const onResize = () => setViewport({ width: window.innerWidth, height: window.innerHeight });
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);

  const isMobile = viewport.width <= 900;

  const desktopSidebarWidth = useMemo(() => {
    if (viewport.width <= 900) return 0;
    if (viewport.width <= 1366) return 228;
    if (viewport.width <= 1536) return 248;
    return 272;
  }, [viewport.width]);

  const effectiveContentWidth = useMemo(() => {
    if (viewport.width <= 900) return viewport.width;
    const reserved = desktopSidebarWidth;
    return Math.max(320, viewport.width - reserved - 24);
  }, [desktopSidebarWidth, viewport.width]);

  const resolvedDensity = useMemo(() => {
    if (viewport.width <= 900) return "tight";
    if (effectiveContentWidth <= 860 || viewport.height <= 700) return "ultra-tight";
    if (effectiveContentWidth <= 1080 || viewport.height <= 768) return "tight";
    if (effectiveContentWidth <= 1380 || viewport.height <= 864) return "compact";
    return compactUi ? "compact" : "comfortable";
  }, [compactUi, effectiveContentWidth, viewport.height, viewport.width]);

  useLayoutEffect(() => {
    const el = document.documentElement;
    el.setAttribute("data-density", resolvedDensity);
    el.style.setProperty("--effective-content-width", `${effectiveContentWidth}px`);
  }, [effectiveContentWidth, resolvedDensity]);

  useEffect(() => {
    try {
      localStorage.setItem("esendit.ui.compact", compactUi ? "1" : "0");
    } catch {
      // ignore
    }
  }, [compactUi]);

  useEffect(() => {
    getMe().then(setMe).catch(() => setMe(null));
  }, []);

  useEffect(() => {
    const handler = () => {
      getMe(true).then(setMe).catch(() => setMe(null));
    };
    window.addEventListener(ME_UPDATED_EVENT, handler);
    return () => window.removeEventListener(ME_UPDATED_EVENT, handler);
  }, []);

  const canSeeProjects = hasAnyPerm(me, ["PROJECT_READ", "page:projects", "action:projects:scoped:read"]);
  const canSeeTracking = hasAnyPerm(me, ["action:tracking:read", "action:tracking:read:scoped", "page:projects", "action:projects:scoped:read"]);
  const canSeeLibrary = hasAnyPerm(me, ["page:library", "action:library:read", "action:library:read:scoped", "action:library:index", "action:library:stream", "action:library:stream:scoped", "page:dam", "action:dam:read", "action:dam:index", "action:dam:stream", "page:projects", "action:projects:scoped:read"]);
  const canSeeBulk = hasAnyPerm(me, [
    "page:bulk",
    "action:bulk:read",
    "action:bulk:create",
    "action:bulk:import",
    "action:bulk:upload",
    "action:bulk:process",
    "action:bulk:stream",
  ]);

  const canSeeDestinations = hasPerm(me, "page:masters:destinations");
  const canSeeDeliverySetup = hasPerm(me, "page:masters:delivery-setup");
  const canSeeChannels = hasPerm(me, "page:masters:channels");
  const canSeeDeliveryProfiles = hasPerm(me, "page:masters:delivery-profiles");
  const canSeeSlas = hasPerm(me, "page:masters:slas");
  const canSeeHotFolders = hasPerm(me, "page:masters:hot-folders");
  const canSeeAccounts = hasPerm(me, "page:masters:accounts");
  const canSeeMastersOverview = hasPerm(me, "page:masters");
  const canSeeAdvertiserGroups = hasPerm(me, "page:masters:advertiser-groups");
  const canSeeAdvertisers = hasPerm(me, "page:masters:advertisers");
  const canSeeBrands = hasPerm(me, "page:masters:brands");
  const canSeeProductCategories = hasPerm(me, "page:masters:product-categories");
  const hasMastersSection = hasPerm(me, "page:masters");
  const hasAgenciesSection = hasPerm(me, "page:agencies");
  const hasDeliverySection = hasPerm(me, "page:delivery");
  const hasBillingSection = hasPerm(me, "page:billing");

  const showMasters = hasMastersSection || [
    canSeeMastersOverview,
    canSeeAdvertiserGroups,
    canSeeAdvertisers,
    canSeeBrands,
    canSeeProductCategories,
    canSeeHotFolders,
    canSeeAccounts,
  ].some(Boolean);
  const canSeeAgenciesPage = hasPerm(me, "page:masters:agencies");
  const canSeeAgencyTeamsPage = hasPerm(me, "page:masters:agency-teams");
  const showAgencies = hasAgenciesSection || [canSeeAgenciesPage, canSeeAgencyTeamsPage].some(Boolean);
  const showDelivery = hasDeliverySection || [canSeeDeliverySetup, canSeeDestinations, canSeeDeliveryProfiles, canSeeChannels, canSeeSlas].some(Boolean);

  const canSeeBillableParties = hasPerm(me, "page:billing:billable-parties");
  const canSeeRateCards = hasPerm(me, "page:billing:rate-cards");
  const canSeeChargesExport = hasPerm(me, "page:billing:charges");
  const canSeeInvoices = hasPerm(me, "page:billing:invoices");
  const showBilling = hasBillingSection || [canSeeBillableParties, canSeeRateCards, canSeeChargesExport, canSeeInvoices].some(Boolean);

  const canSeeAdminUsers = hasPerm(me, "ADMIN_USERS_READ");
  const canSeeAdminRoles = hasPerm(me, "ADMIN_ROLES_READ");
  const canSeeAdminGroups = hasPerm(me, "ADMIN_GROUPS_READ");
  const canSeeAdminPermissions = hasPerm(me, "ADMIN_ROLES_READ");
  const canSeeAdminPresets = hasAnyPerm(me, ["ACCOUNT_SETTINGS_READ", "ACCOUNT_SETTINGS_WRITE"]);
  const canSeeAdminAccountSettings = hasAnyPerm(me, ["ACCOUNT_SETTINGS_READ", "ACCOUNT_SETTINGS_WRITE"]);
  const canSeeAdminServerStatus = hasPerm(me, "SERVER_STATUS_READ");
  const showAdmin = [
    canSeeAdminUsers,
    canSeeAdminRoles,
    canSeeAdminGroups,
    canSeeAdminPermissions,
    canSeeAdminPresets,
    canSeeAdminAccountSettings,
    canSeeAdminServerStatus,
    canSeeBulk,
  ].some(Boolean);

  const userEmail = useMemo(() => {
    return (me as any)?.user?.email || "";
  }, [me]);

  const userName = useMemo(() => {
    const displayName = (me as any)?.user?.displayName?.trim();
    if (displayName) return displayName;
    if (userEmail) return prettyNameFromEmail(userEmail);
    return "Signed in";
  }, [me, userEmail]);

  const userLabel = useMemo(() => {
    return userEmail || "Signed in";
  }, [userEmail]);

  const userSubLabel = useMemo(() => {
    return userEmail || "Profile";
  }, [userEmail]);

  const userInitials = useMemo(() => {
    const raw = userName || userLabel;
    const parts = raw
      .replace(/[^a-zA-Z0-9]+/g, " ")
      .trim()
      .split(/\s+/)
      .filter(Boolean);

    if (!parts.length) return "U";
    if (parts.length === 1) return parts[0].slice(0, 2).toUpperCase();
    return (parts[0][0] + parts[1][0]).toUpperCase();
  }, [userLabel, userName]);

  const receiverAccounts = useMemo(() => {
    return Array.isArray((me as any)?.receiverAccounts) ? ((me as any).receiverAccounts as any[]) : [];
  }, [me]);

  const supportView = (me as any)?.supportView || null;
  const isSupportView = !!supportView?.active;

  useEffect(() => {
    if (!activeReceiverAccountId) return;
    if (!receiverAccounts.length) {
      setActiveReceiverAccountId("");
      setActiveReceiverAccountIdState("");
      return;
    }
    if (!receiverAccounts.some((item) => String(item?.id || "") === activeReceiverAccountId)) {
      setActiveReceiverAccountId("");
      setActiveReceiverAccountIdState("");
    }
  }, [activeReceiverAccountId, receiverAccounts]);

  function changeReceiverAccountContext(nextId: string) {
    const value = String(nextId || "").trim();
    setActiveReceiverAccountId(value);
    setActiveReceiverAccountIdState(value);
    window.location.reload();
  }

  function exitSupportView() {
    const restored = exitSupportSessionToken();
    if (restored) window.location.href = "/";
    else nav("/login");
  }

  const mastersActive = isMastersPath(loc.pathname);
  const agenciesActive = isAgencyPath(loc.pathname);
  const deliveryActive = isDeliveryPath(loc.pathname);
  const adminActive = isAdminPath(loc.pathname);
  const billingActive =
    loc.pathname.startsWith("/billing") ||
    loc.pathname.startsWith("/masters/billable-parties") ||
    loc.pathname.startsWith("/masters/rate-cards");

  useEffect(() => {
    setProfileOpen(false);
  }, [loc.pathname, loc.search]);

  useEffect(() => {
    setOpen((prev) => ({
      masters: mastersActive ? true : prev.masters,
      agencies: agenciesActive ? true : prev.agencies,
      delivery: deliveryActive ? true : prev.delivery,
      admin: adminActive ? true : prev.admin,
      billing: billingActive ? true : prev.billing,
    }));
  }, [adminActive, agenciesActive, billingActive, deliveryActive, mastersActive]);

  useEffect(() => {
    if (!profileOpen) return;

    const handlePointerDown = (event: MouseEvent) => {
      const target = event.target as Node | null;
      if (profileWrapRef.current && target && !profileWrapRef.current.contains(target)) {
        setProfileOpen(false);
      }
    };

    const handleEscape = (event: KeyboardEvent) => {
      if (event.key === "Escape") setProfileOpen(false);
    };

    document.addEventListener("mousedown", handlePointerDown);
    document.addEventListener("keydown", handleEscape);
    return () => {
      document.removeEventListener("mousedown", handlePointerDown);
      document.removeEventListener("keydown", handleEscape);
    };
  }, [profileOpen]);

  function logout() {
    clearToken();
    nav("/login");
  }

  function openChangePassword() {
    setProfileOpen(false);
    setChangePasswordError("");
    setChangePasswordSuccess("");
    setCurrentPassword("");
    setNewPassword("");
    setConfirmPassword("");
    setChangePasswordOpen(true);
  }

  function closeChangePassword() {
    if (changePasswordSaving) return;
    setChangePasswordOpen(false);
    setChangePasswordError("");
    setChangePasswordSuccess("");
    setCurrentPassword("");
    setNewPassword("");
    setConfirmPassword("");
  }

  async function saveChangePassword() {
    const current = currentPassword;
    const next = newPassword;
    const confirm = confirmPassword;

    if (!current || !next || !confirm) {
      setChangePasswordError("Enter current password, new password, and confirmation.");
      setChangePasswordSuccess("");
      return;
    }
    if (next.length < 8) {
      setChangePasswordError("New password must be at least 8 characters.");
      setChangePasswordSuccess("");
      return;
    }
    if (next !== confirm) {
      setChangePasswordError("New password and confirmation do not match.");
      setChangePasswordSuccess("");
      return;
    }
    if (current === next) {
      setChangePasswordError("New password must be different from the current password.");
      setChangePasswordSuccess("");
      return;
    }

    setChangePasswordSaving(true);
    setChangePasswordError("");
    setChangePasswordSuccess("");
    try {
      await api<{ ok: boolean }>("/auth/change-password", {
        method: "POST",
        body: JSON.stringify({ currentPassword: current, newPassword: next }),
      });
      setChangePasswordSuccess("Password updated successfully.");
      setCurrentPassword("");
      setNewPassword("");
      setConfirmPassword("");
    } catch (e: any) {
      setChangePasswordError(e?.message || "Failed to update password.");
    } finally {
      setChangePasswordSaving(false);
    }
  }

  function toggleGroup(key: GroupKey) {
    setOpen((o) => ({ ...o, [key]: !o[key] }));
  }


  const sidebarCtx = useMemo(
    () => ({
      open: sidebarOpen,
      setOpen: setSidebarOpen,
      toggle: () => setSidebarOpen((s) => !s),
    }),
    [sidebarOpen]
  );

  function handleSidebarWheel(event: WheelEvent<HTMLElement>) {
    const navEl = sidebarNavRef.current;
    if (!navEl) return;
    const canScroll = navEl.scrollHeight > navEl.clientHeight + 1;
    if (!canScroll) return;
    const target = event.target as Node | null;
    const isInsideNav = !!target && navEl.contains(target);
    if (isInsideNav) return;
    navEl.scrollTop += event.deltaY;
    event.preventDefault();
  }

  const receiverAccountNode = receiverAccounts.length > 1 ? (
    <label
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 8,
        padding: "7px 10px",
        borderRadius: 999,
        border: "1px solid rgba(15,23,42,0.10)",
        background: "#ffffff",
        boxShadow: "0 8px 18px rgba(15,23,42,0.06)",
        fontSize: 12,
        fontWeight: 800,
        color: "#334155",
      }}
      title="Select receiver account context"
    >
      <span style={{ whiteSpace: "nowrap" }}>Viewing as</span>
      <select
        value={activeReceiverAccountId}
        onChange={(event) => changeReceiverAccountContext(event.target.value)}
        style={{ border: 0, outline: 0, background: "transparent", fontWeight: 800, color: "#1e293b", maxWidth: 220 }}
        aria-label="Receiver account context"
      >
        <option value="">All receiver accounts</option>
        {receiverAccounts.map((item) => (
          <option key={item.id} value={item.id}>
            {item.name || "Receiver account"}
          </option>
        ))}
      </select>
    </label>
  ) : null;

  const headerProfileNode = (
    <div className="app-header__profileWrap" ref={profileWrapRef}>
      <button
        type="button"
        className={"app-header__profile" + (profileOpen ? " app-header__profile--open" : "")}
        title={userSubLabel}
        aria-label={userSubLabel}
        aria-expanded={profileOpen}
        aria-haspopup="menu"
        onClick={() => setProfileOpen((s) => !s)}
      >
        <span className="app-header__profileAvatar" aria-hidden="true">
          {userInitials}
        </span>
        <span className="app-header__profileMeta">
          <span className="app-header__profileName">{userName}</span>
          <span className="app-header__profileSub">{userEmail || "Profile"}</span>
        </span>
      </button>

      {profileOpen ? (
        <div className="app-header__profileMenu" role="menu">
          <div className="app-header__profileMenuMeta">
            <div className="app-header__profileMenuName">{userName}</div>
            <div className="app-header__profileMenuSub">{userSubLabel}</div>
          </div>

          {!isSupportView ? (
            <button
              type="button"
              className="app-header__profileMenuItem"
              onClick={openChangePassword}
              role="menuitem"
            >
              Change password
            </button>
          ) : null}

          <button
            type="button"
            className="app-header__profileMenuItem"
            onClick={() => setCompactUi((s) => !s)}
            role="menuitem"
          >
            {compactUi ? "Compact UI: ON" : "Compact UI: OFF"}
          </button>

          <button type="button" className="app-header__profileMenuItem" onClick={logout} role="menuitem">
            Logout
          </button>
        </div>
      ) : null}
    </div>
  );

  return (
    <SidebarProvider value={sidebarCtx}>
      <div
        className={
          "app-shell " +
          (sidebarOpen ? "app-shell--sidebar-open" : "app-shell--sidebar-closed") +
          (isMobile ? " app-shell--mobile" : " app-shell--desktop")
        }
      >
        {isMobile && sidebarOpen ? <div className="sidebar-backdrop" onClick={() => setSidebarOpen(false)} /> : null}

        <aside
          className="sidebar"
          aria-hidden={isMobile && !sidebarOpen ? true : undefined}
          onWheel={handleSidebarWheel}
        >
          <div className="sidebar__top">
            <div className="brand">
              <button
                className="brand__logo brand__logoBtn"
                type="button"
                onClick={() => nav("/")}
                aria-label="Home"
                title="Home"
              >
                <img src={esenditLogo} alt="eSendIt" className="brand__logoImage" />
              </button>

              <button
                className="sidebar__close"
                type="button"
                onClick={() => setSidebarOpen(false)}
                aria-label="Close menu"
                title="Close"
              >
                ✕
              </button>
            </div>

          </div>

          <nav className="nav" ref={sidebarNavRef}>
            <NavLink to="/" className={({ isActive }) => topCls(isActive)} title="Home">
              <span className="nav-item__glyph" aria-hidden="true">HM</span>
              <span className="nav-item__label">Home</span>
            </NavLink>

            {canSeeProjects ? (
              <NavLink to="/projects" className={({ isActive }) => topCls(isActive)} title="Projects">
                <span className="nav-item__glyph" aria-hidden="true">PR</span>
                <span className="nav-item__label">Projects</span>
              </NavLink>
            ) : null}

            {showMasters && (
              <div className="nav-group">
                <button
                  type="button"
                  className={topCls(mastersActive) + " nav-group__trigger"}
                  onClick={() => toggleGroup("masters")}
                  aria-expanded={open.masters}
                  title="Masters"
                >
                  <span className="nav-item__glyph" aria-hidden="true">MS</span>
                  <span className="nav-item__label">Masters</span>
                </button>

                {open.masters && (
                  <div className="nav-group__children">
                    {canSeeMastersOverview ? (
                      <NavLink to="/masters" end className={({ isActive }) => cls(isActive)}>
                        Overview
                      </NavLink>
                    ) : null}
                    {canSeeAdvertiserGroups ? (
                      <NavLink to="/masters/advertiser-groups" className={({ isActive }) => cls(isActive)}>
                        Advertiser Groups
                      </NavLink>
                    ) : null}
                    {canSeeAdvertisers ? (
                      <NavLink to="/masters/advertisers" className={({ isActive }) => cls(isActive)}>
                        Advertisers
                      </NavLink>
                    ) : null}
                    {canSeeBrands ? (
                      <NavLink to="/masters/brands" className={({ isActive }) => cls(isActive)}>
                        Brands
                      </NavLink>
                    ) : null}
                    {canSeeProductCategories ? (
                      <NavLink to="/masters/product-categories" className={({ isActive }) => cls(isActive)}>
                        Product Categories
                      </NavLink>
                    ) : null}
                    {canSeeHotFolders ? (
                      <NavLink to="/masters/hot-folders" className={({ isActive }) => cls(isActive)}>
                        Hot Folders
                      </NavLink>
                    ) : null}
                    {canSeeAccounts ? (
                      <NavLink to="/masters/accounts" className={({ isActive }) => cls(isActive)}>
                        Accounts
                      </NavLink>
                    ) : null}
                  </div>
                )}
              </div>
            )}

            {showAgencies && (
              <div className="nav-group">
                <button
                  type="button"
                  className={topCls(agenciesActive) + " nav-group__trigger"}
                  onClick={() => toggleGroup("agencies")}
                  aria-expanded={open.agencies}
                  title="Agencies"
                >
                  <span className="nav-item__glyph" aria-hidden="true">AG</span>
                  <span className="nav-item__label">Agencies</span>
                </button>

                {open.agencies && (
                  <div className="nav-group__children">
                    <NavLink to="/masters/agency-hub?type=MEDIA&view=group" className={() => agencyLinkClass("MEDIA")}>
                      Media Agencies
                    </NavLink>
                    <NavLink to="/masters/agency-hub?type=CREATIVE&view=group" className={() => agencyLinkClass("CREATIVE")}>
                      Creative Agencies
                    </NavLink>
                    <NavLink to="/masters/agency-hub?type=POST_HOUSE&view=group" className={() => agencyLinkClass("POST_HOUSE")}>
                      Post Houses
                    </NavLink>
                    <NavLink
                      to="/masters/agency-hub?type=PRODUCTION_HOUSE&view=group"
                      className={() => agencyLinkClass("PRODUCTION_HOUSE")}
                    >
                      Production Houses
                    </NavLink>
                    <NavLink to="/masters/agency-hub?type=AUDIO&view=group" className={() => agencyLinkClass("AUDIO")}>
                      Audio Agencies
                    </NavLink>
                    <NavLink to="/masters/agency-hub?type=UPLOADER&view=group" className={() => agencyLinkClass("UPLOADER")}>
                      Uploader Agencies
                    </NavLink>
                  </div>
                )}
              </div>
            )}

            {showDelivery && (
              <div className="nav-group">
                <button
                  type="button"
                  className={topCls(deliveryActive) + " nav-group__trigger"}
                  onClick={() => toggleGroup("delivery")}
                  aria-expanded={open.delivery}
                  title="Delivery"
                >
                  <span className="nav-item__glyph" aria-hidden="true">DL</span>
                  <span className="nav-item__label">Delivery</span>
                </button>

                {open.delivery && (
                  <div className="nav-group__children">
                    {canSeeDeliverySetup ? (
                      <NavLink to="/masters/delivery-setup" className={({ isActive }) => cls(isActive)}>
                        Delivery Setup
                      </NavLink>
                    ) : null}
                    {canSeeDestinations ? (
                      <NavLink to="/masters/destinations" className={({ isActive }) => cls(isActive)}>
                        Destinations
                      </NavLink>
                    ) : null}
                    {canSeeDeliveryProfiles ? (
                      <NavLink to="/masters/delivery-profiles" className={({ isActive }) => cls(isActive)}>
                        Delivery Profiles
                      </NavLink>
                    ) : null}
                    {canSeeChannels ? (
                      <NavLink to="/masters/channels" className={({ isActive }) => cls(isActive)}>
                        Channels
                      </NavLink>
                    ) : null}
                    {canSeeSlas ? (
                      <NavLink to="/masters/slas" className={({ isActive }) => cls(isActive)}>
                        SLAs
                      </NavLink>
                    ) : null}
                  </div>
                )}
              </div>
            )}

            {showAdmin && (
              <div className="nav-group">
                <button
                  type="button"
                  className={topCls(adminActive) + " nav-group__trigger"}
                  onClick={() => toggleGroup("admin")}
                  aria-expanded={open.admin}
                  title="Admin"
                >
                  <span className="nav-item__glyph" aria-hidden="true">AD</span>
                  <span className="nav-item__label">Admin</span>
                </button>

                {open.admin && (
                  <div className="nav-group__children">
                    {canSeeAdminUsers ? (
                      <NavLink to="/admin/users" className={({ isActive }) => cls(isActive)}>
                        People
                      </NavLink>
                    ) : null}
                    {canSeeAdminRoles ? (
                      <NavLink to="/admin/roles" className={({ isActive }) => cls(isActive)}>
                        Access Profiles
                      </NavLink>
                    ) : null}
                    {canSeeAdminGroups ? (
                      <NavLink to="/admin/groups" className={({ isActive }) => cls(isActive)}>
                        Teams
                      </NavLink>
                    ) : null}
                    {canSeeAdminPermissions ? (
                      <NavLink to="/admin/permissions" className={({ isActive }) => cls(isActive)}>
                        Permission Library
                      </NavLink>
                    ) : null}
                    {canSeeAdminPresets ? (
                      <NavLink to="/admin/presets" className={({ isActive }) => cls(isActive)}>
                        Transcode Presets
                      </NavLink>
                    ) : null}
                    {canSeeAdminAccountSettings ? (
                      <NavLink to="/admin/account-settings" className={({ isActive }) => cls(isActive)}>
                        Account Settings
                      </NavLink>
                    ) : null}
                    {canSeeAdminServerStatus ? (
                      <NavLink to="/admin/server-status" className={({ isActive }) => cls(isActive)}>
                        Server Status
                      </NavLink>
                    ) : null}
                    {canSeeBulk ? (
                      <NavLink to="/bulk" className={({ isActive }) => cls(isActive)}>
                        Bulk Upload
                      </NavLink>
                    ) : null}
                  </div>
                )}
              </div>
            )}

            {canSeeTracking ? (
              <NavLink to="/tracking" className={({ isActive }) => topCls(isActive)} title="Tracking">
                <span className="nav-item__glyph" aria-hidden="true">TR</span>
                <span className="nav-item__label">Tracking</span>
              </NavLink>
            ) : null}

            {canSeeLibrary ? (
              <NavLink to="/dam" className={({ isActive }) => topCls(isActive)} title="DAM">
                <span className="nav-item__glyph" aria-hidden="true">DM</span>
                <span className="nav-item__label">DAM</span>
              </NavLink>
            ) : null}

            {showBilling && (
              <div className="nav-group">
                <button
                  type="button"
                  className={topCls(billingActive) + " nav-group__trigger"}
                  onClick={() => toggleGroup("billing")}
                  aria-expanded={open.billing}
                  title="Billing"
                >
                  <span className="nav-item__glyph" aria-hidden="true">BL</span>
                  <span className="nav-item__label">Billing</span>
                </button>

                {open.billing && (
                  <div className="nav-group__children">
                    {canSeeBillableParties ? (
                      <NavLink to="/masters/billable-parties" className={({ isActive }) => cls(isActive)}>
                        Billable Parties
                      </NavLink>
                    ) : null}
                    {canSeeRateCards ? (
                      <NavLink to="/masters/rate-cards" className={({ isActive }) => cls(isActive)}>
                        Rate Cards
                      </NavLink>
                    ) : null}
                    {canSeeChargesExport ? (
                      <NavLink to="/billing/charges" className={({ isActive }) => cls(isActive)}>
                        Charges Export
                      </NavLink>
                    ) : null}
                    {canSeeInvoices ? (
                      <NavLink to="/billing/invoices" className={({ isActive }) => cls(isActive)}>
                        Invoices
                      </NavLink>
                    ) : null}
                  </div>
                )}
              </div>
            )}
          </nav>
        </aside>

        <div className="shell-main">
          <header className="app-header">
            <div className="app-header__left">
              <button
                type="button"
                className="app-header__iconBtn"
                onClick={() => setSidebarOpen((s) => !s)}
                aria-label={sidebarOpen ? "Collapse menu" : "Expand menu"}
                title={sidebarOpen ? "Collapse menu" : "Expand menu"}
              >
                <span className="app-header__hamburger" aria-hidden="true">
                  <span />
                  <span />
                  <span />
                </span>
              </button>

              <Link className="app-header__homeBtn" to="/" aria-label="Home" title="Home">
                <span className="app-header__homeLabel">Home</span>
              </Link>

              <button
                type="button"
                className="app-header__refreshBtn"
                onClick={() => window.location.reload()}
                aria-label="Refresh page"
                title="Refresh"
              >
                <span className="app-header__refreshIcon" aria-hidden="true">↻</span>
                <span className="app-header__refreshLabel">Refresh</span>
              </button>
            </div>

            <div className="app-header__right" style={{ gap: 10 }}>
              {receiverAccountNode}
              {headerProfileNode}
            </div>
          </header>

          {isSupportView ? (
            <div
              style={{
                margin: "10px 14px 0",
                padding: "10px 14px",
                borderRadius: 14,
                border: "1px solid rgba(217,119,6,0.25)",
                background: "#fffbeb",
                color: "#92400e",
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                gap: 12,
                flexWrap: "wrap",
                fontSize: 13,
                fontWeight: 800,
              }}
            >
              <span>
                Support View: viewing as {userEmail || "client user"}. This session is read-only for safe troubleshooting.
                {supportView?.ticket ? ` Ticket: ${supportView.ticket}.` : ""}
              </span>
              <button type="button" onClick={exitSupportView} style={{ background: "#ffffff" }}>
                Exit Support View
              </button>
            </div>
          ) : null}

          <main className="content">
            <div className="content__body">
              <Outlet />
            </div>
          </main>
        </div>
      </div>

      <AppModal
        open={changePasswordOpen}
        title="Change password"
        subtitle="Update your sign-in password without changing any other account settings."
        onClose={closeChangePassword}
        width="sm"
        footer={
          <div style={{ display: "flex", justifyContent: "flex-end", gap: 10 }}>
            <button type="button" onClick={closeChangePassword} disabled={changePasswordSaving}>
              Cancel
            </button>
            <button type="button" className="btnPrimary" onClick={saveChangePassword} disabled={changePasswordSaving}>
              {changePasswordSaving ? "Updating..." : "Update password"}
            </button>
          </div>
        }
      >
        <div style={{ display: "grid", gap: 14 }}>
          <label className="auth-field">
            <span className="auth-label">Current password</span>
            <input
              className="auth-input"
              type="password"
              value={currentPassword}
              onChange={(event) => setCurrentPassword(event.target.value)}
              autoComplete="current-password"
              placeholder="Enter current password"
              disabled={changePasswordSaving}
            />
          </label>

          <label className="auth-field">
            <span className="auth-label">New password</span>
            <input
              className="auth-input"
              type="password"
              value={newPassword}
              onChange={(event) => setNewPassword(event.target.value)}
              autoComplete="new-password"
              placeholder="Enter new password"
              disabled={changePasswordSaving}
            />
          </label>

          <label className="auth-field">
            <span className="auth-label">Confirm new password</span>
            <input
              className="auth-input"
              type="password"
              value={confirmPassword}
              onChange={(event) => setConfirmPassword(event.target.value)}
              autoComplete="new-password"
              placeholder="Re-enter new password"
              disabled={changePasswordSaving}
            />
          </label>

          {changePasswordError ? <div style={{ fontSize: 13, color: "#b42318", fontWeight: 600 }}>{changePasswordError}</div> : null}
          {changePasswordSuccess ? <div style={{ fontSize: 13, color: "#067647", fontWeight: 600 }}>{changePasswordSuccess}</div> : null}
        </div>
      </AppModal>
    </SidebarProvider>
  );
}
