import { useMemo, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { api, setToken } from "../lib/api";
import { AuthLayout } from "./AuthLayout";

const SHOW_ICON_SRC = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAACXBIWXMAAAnXAAAJ1wGxbhe3AAAAGXRFWHRTb2Z0d2FyZQB3d3cuaW5rc2NhcGUub3Jnm+48GgAAASZJREFUOI3N0ksrhGEUB/CfGYWFhVnIpYmyp1hYiNRsZKN8DhY+h4UoSbmUD8DKhnLZWQnLKbfUlHKJXBdTFnOmXmNQVv51Ou9zzv/8n3PO+/Df0R32LWorzhncJc7j4U8SsSbcVxPL4BrDqMco9rGHEdRF7jpEqiKHR9ziNewt/G3kct8VN2MXp2F9idwALnGOneB+QmckZ3CDNrRjDlPB6YrcLM7QQWmJDdjCNIrYRAEH6MdVtL8WHR4ij230pJBFI1ZiOYW4sSd8FvPxfYGW4DYim0qorVfMvpgYcSl8b4hsRNf5MiGNVRzFssYiPhgLFLErHGM5ar5gEg94xkIUD0U3T0q/caJaYRJt0U35DbzjJeZurSTX/CCUDjFKiy3+dvOf8AGyDkZkzWjbSgAAAABJRU5ErkJggg==";
const CLOSE_EYE_ICON_SRC = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAACXBIWXMAAAB2AAAAdgFOeyYIAAAAGXRFWHRTb2Z0d2FyZQB3d3cuaW5rc2NhcGUub3Jnm+48GgAAAMFJREFUOI3t0LFKgmEUxvGfiZZToLi55NzULbi2JM5Cd+CFRINrV5CLk+AgOHcDBl+BuAoWDoGgZIMH+bAPaWiK/tPhPc/zPucc/vk1TnCP2g+0ZXSQSz/mMMEYxSPmAoaYReieChJs0cNZhrmEx9C8oppu3mGKG8zxjDYuUMdtBLyhhRd0DyeoRN0L4UekbaNeoB+ac7tbfOMSn2jiFAOMYqXr6F2lDfmDDwp4xwM2aGAVUyVY4wnLrPQsyqnV/ipf9qQltmU4I0EAAAAASUVORK5CYII=";

function EyeIcon({ open }: { open: boolean }) {
  return (
    <img
      src={open ? SHOW_ICON_SRC : CLOSE_EYE_ICON_SRC}
      alt=""
      aria-hidden="true"
      style={{ width: 18, height: 18, display: "block", objectFit: "contain" }}
    />
  );
}

export function LoginPage() {
  const nav = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [remember, setRemember] = useState(true);
  const [showPw, setShowPw] = useState(false);
  const [err, setErr] = useState("");

  const canSubmit = useMemo(() => email.trim() && password.trim(), [email, password]);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setErr("");
    try {
      const res = await api<{ accessToken: string }>("/auth/login", {
        method: "POST",
        body: JSON.stringify({ email: email.trim(), password }),
      });

      setToken(res.accessToken, remember);
      nav("/", { replace: true });
    } catch (e: any) {
      setErr(e?.message || "Login failed");
    }
  }

  return (
    <AuthLayout>
      <form onSubmit={onSubmit} className="auth-form">
        <div style={{ display: "grid", gap: 6 }}>
          <h1 className="auth-title">Sign In to eSENDIT</h1>
          <div className="auth-subtitle">Plug, Play, Collaborate</div>
        </div>

        <label className="auth-field">
          <div className="auth-label">Email Address</div>
          <input
            className="auth-input"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="name@domainname.com"
            autoComplete="email"
          />
        </label>

        <label className="auth-field">
          <div className="auth-label">Password</div>
          <div className="auth-password-wrap">
            <input
              className="auth-input"
              type={showPw ? "text" : "password"}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              autoComplete="current-password"
              style={{ paddingRight: 44 }}
            />
            <button
              type="button"
              className="auth-eye"
              aria-label={showPw ? "Hide password" : "Show password"}
              onClick={() => setShowPw((v) => !v)}
            >
              <EyeIcon open={showPw} />
            </button>
          </div>
        </label>

        <div className="auth-actions-row">
          <label className="auth-checkbox">
            <input
              type="checkbox"
              checked={remember}
              onChange={(e) => setRemember(e.target.checked)}
            />
            Remember Me
          </label>

          <button type="button" className="auth-link" onClick={() => nav("/forgot-password")}>
            Forgot Password?
          </button>
        </div>

        {err ? <div style={{ color: "crimson", fontSize: 13 }}>{err}</div> : null}

        <button className="auth-primary" type="submit" disabled={!canSubmit}>
          Sign In
        </button>

        <div className="auth-footer">
          Don&apos;t have an Account? <Link to="/signup">Signup</Link>
        </div>
      </form>
    </AuthLayout>
  );
}
