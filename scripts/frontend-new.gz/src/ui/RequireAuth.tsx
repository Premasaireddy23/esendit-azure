import { useEffect, useState } from "react";
import { Navigate, useLocation } from "react-router-dom";
import { api, getToken } from "../lib/api";

export function RequireAuth({ children }: { children: React.ReactNode }) {
  const loc = useLocation();
  const [ok, setOk] = useState<boolean | null>(null);

  useEffect(() => {
    const t = getToken();
    if (!t) {
      setOk(false);
      return;
    }
    // Validate token quickly
    api("/auth/me")
      .then(() => setOk(true))
      .catch(() => setOk(false));
  }, [loc.pathname]);

  if (ok === null) return <div style={{ padding: 16 }}>Checking session…</div>;
  if (!ok) return <Navigate to="/login" replace state={{ from: loc.pathname }} />;

  return <>{children}</>;
}
