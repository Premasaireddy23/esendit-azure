export type ClientRateProfile = {
  key: string;
  advertiser: string;
  billingName: string;
  address: string;
  pan: string;
  gst: string;
  currency: string;
  invoiceMode: "INDIA";
  defaultGstPercent: string;
  pairedRates: Record<string, { sd: number; hd: number }>;
  singleRates: Record<string, number>;
};

type ClientRateSeed = {
  code: string;
  label: string;
  action: "UPLOAD" | "ENCODE" | "DELIVERY" | "OTHER";
  unit: string;
  sortOrder: number;
  sourceHeaders: string[];
  paired?: boolean;
};

const PAIRED_SEEDS: ClientRateSeed[] = [
  { code: "ENCODING_UPLOADING", label: "Encoding / Uploading", action: "ENCODE", unit: "per_file", sortOrder: 10, sourceHeaders: ["SD Encoding/Uploading", "HD Encoding/Uploading"], paired: true },
  { code: "REGULAR_DELIVERY", label: "Regular Delivery", action: "DELIVERY", unit: "per_file", sortOrder: 20, sourceHeaders: ["SD Regular", "HD Regular"], paired: true },
  { code: "EXPRESS_DELIVERY", label: "Express Delivery", action: "DELIVERY", unit: "per_file", sortOrder: 30, sourceHeaders: ["SD Express", "HD Express"], paired: true },
  { code: "IMMEDIATE_DELIVERY", label: "Immediate Delivery", action: "DELIVERY", unit: "per_file", sortOrder: 40, sourceHeaders: ["SD Immediate", "HD Immediate"], paired: true },
];

const SINGLE_SEEDS: ClientRateSeed[] = [
  { code: "MP4", label: "MP4", action: "OTHER", unit: "per_file", sortOrder: 50, sourceHeaders: ["MP4"] },
  { code: "SUBTITILING", label: "Subtitiling", action: "OTHER", unit: "per_file", sortOrder: 60, sourceHeaders: ["Subtitiling"] },
  { code: "LOGO_SLAPPING", label: "Logo Slapping", action: "OTHER", unit: "per_file", sortOrder: 70, sourceHeaders: ["Logo Slapping"] },
  { code: "J2K", label: "J2K", action: "OTHER", unit: "per_file", sortOrder: 80, sourceHeaders: ["J2K"] },
  { code: "CBFC", label: "CBFC", action: "OTHER", unit: "per_file", sortOrder: 90, sourceHeaders: ["CBFC"] },
  { code: "HD_SD", label: "HD-SD", action: "OTHER", unit: "per_file", sortOrder: 100, sourceHeaders: ["HD-SD"] },
  { code: "ASPECT_9_16", label: "9:16", action: "OTHER", unit: "per_file", sortOrder: 110, sourceHeaders: ["9:16"] },
  { code: "4K", label: "4K", action: "OTHER", unit: "per_file", sortOrder: 120, sourceHeaders: ["4K"] },
  { code: "MASKING", label: "Masking", action: "OTHER", unit: "per_file", sortOrder: 130, sourceHeaders: ["Masking"] },
  { code: "AUDIO_SLAP", label: "Audio Slap", action: "OTHER", unit: "per_file", sortOrder: 140, sourceHeaders: ["Audio Slap"] },
  { code: "LUFS", label: "LUFS", action: "OTHER", unit: "per_file", sortOrder: 150, sourceHeaders: ["LUFS"] },
  { code: "VIDEO_LOOP", label: "Video Loop", action: "OTHER", unit: "per_file", sortOrder: 160, sourceHeaders: ["Video Loop"] },
  { code: "MUTES", label: "Mutes", action: "OTHER", unit: "per_file", sortOrder: 170, sourceHeaders: ["Mutes"] },
  { code: "MASTERING", label: "Mastering", action: "OTHER", unit: "per_file", sortOrder: 180, sourceHeaders: ["Mastering"] },
  { code: "TEXT", label: "Text", action: "OTHER", unit: "per_file", sortOrder: 190, sourceHeaders: ["Text"] },
];

const formatMoneyString = (value: number) => Number(value || 0).toFixed(2);

export const CLIENT_RATE_PROFILES: ClientRateProfile[] = [
  {
    key: "tata-digital-private-limited",
    advertiser: "Tata Digital Private Limited",
    billingName: "Tata Digital Private Limited",
    address: "Army & Navy Building, 148 MG Road, Opposite Kala Ghoda Fort, Mumbai 400001",
    pan: "AAHCT2205N",
    gst: "27AAHCT2205N1Z6",
    currency: "INR",
    invoiceMode: "INDIA",
    defaultGstPercent: "18",
    pairedRates: {
      "SD Encoding/Uploading": { sd: 350, hd: 500 },
      "SD Regular": { sd: 600, hd: 900 },
      "SD Express": { sd: 0, hd: 0 },
      "SD Immediate": { sd: 0, hd: 0 },
    },
    singleRates: {
      "MP4": 750,
      "Subtitiling": 600,
      "Logo Slapping": 600,
      "J2K": 0,
      "CBFC": 0,
      "HD-SD": 800,
      "9:16": 8000,
      "4K": 2000,
      "Masking": 1250,
      "Audio Slap": 400,
      "LUFS": 1100,
      "Video Loop": 0,
      "Mutes": 4500,
      "Mastering": 0,
      "Text": 0,
    },
  },
  {
    key: "reliance-retail-limited",
    advertiser: "Reliance Retail Limited",
    billingName: "Reliance Retail Limited",
    address: "0,5 TTC INDUSTRIAL AREA, RELIANCE CORPORATE PARK, GHANSOLI, NAVI MUMBAI, Thane, Maharashtra, 400701",
    pan: "AABCR1718E",
    gst: "27AABCR1718E2ZO",
    currency: "INR",
    invoiceMode: "INDIA",
    defaultGstPercent: "18",
    pairedRates: {
      "SD Encoding/Uploading": { sd: 0, hd: 0 },
      "SD Regular": { sd: 250, hd: 250 },
      "SD Express": { sd: 0, hd: 0 },
      "SD Immediate": { sd: 0, hd: 0 },
    },
    singleRates: {
      "MP4": 1000,
      "Subtitiling": 0,
      "Logo Slapping": 2500,
      "J2K": 0,
      "CBFC": 0,
      "HD-SD": 1250,
      "9:16": 7500,
      "4K": 0,
      "Masking": 0,
      "Audio Slap": 0,
      "LUFS": 0,
      "Video Loop": 0,
      "Mutes": 0,
      "Mastering": 6500,
      "Text": 400,
    },
  },
  {
    key: "vibrant-advertising-pvt-ltd",
    advertiser: "Reliance Retail Limited",
    billingName: "Vibrant Advertising Pvt Ltd.",
    address: "3rd Floor, Court House, Lokmanaya Tilak Marg, Dhobi Talao, Mumbai 400002, Maharashtra",
    pan: "AACV7737Q1",
    gst: "27AAACV7737Q1ZI",
    currency: "INR",
    invoiceMode: "INDIA",
    defaultGstPercent: "18",
    pairedRates: {
      "SD Encoding/Uploading": { sd: 0, hd: 0 },
      "SD Regular": { sd: 250, hd: 250 },
      "SD Express": { sd: 0, hd: 0 },
      "SD Immediate": { sd: 0, hd: 0 },
    },
    singleRates: {
      "MP4": 1000,
      "Subtitiling": 0,
      "Logo Slapping": 2500,
      "J2K": 0,
      "CBFC": 0,
      "HD-SD": 1250,
      "9:16": 7500,
      "4K": 0,
      "Masking": 0,
      "Audio Slap": 0,
      "LUFS": 0,
      "Video Loop": 0,
      "Mutes": 0,
      "Mastering": 6500,
      "Text": 400,
    },
  },
];

export function normalizeClientRateText(value?: string | null) {
  return String(value || "")
    .trim()
    .toLowerCase()
    .replace(/\s+/g, " ");
}

export function findClientRateProfileByKey(key?: string | null) {
  const normalized = normalizeClientRateText(key);
  return CLIENT_RATE_PROFILES.find((profile) => normalizeClientRateText(profile.key) === normalized) || null;
}

export function findClientRateProfileByName(name?: string | null) {
  const normalized = normalizeClientRateText(name);
  return CLIENT_RATE_PROFILES.find((profile) => normalizeClientRateText(profile.billingName) === normalized) || null;
}

export function buildClientRateCardItems(profile: ClientRateProfile) {
  const snapshot = {
    advertiser: profile.advertiser,
    billingName: profile.billingName,
    address: profile.address,
    panNumber: profile.pan,
    gstNumber: profile.gst,
    currency: profile.currency,
    invoiceMode: profile.invoiceMode,
    defaultGstPercent: profile.defaultGstPercent,
  };

  const paired = PAIRED_SEEDS.map((seed) => {
    const pair = profile.pairedRates[seed.sourceHeaders[0]] || { sd: 0, hd: 0 };
    return {
      action: seed.action,
      code: seed.code,
      label: seed.label,
      sortOrder: seed.sortOrder,
      sourceHeaders: [...seed.sourceHeaders],
      billingMode: "INDIA" as const,
      hsnSacCode: "",
      gstPercent: profile.defaultGstPercent,
      taxSlabPercent: "",
      notes: "",
      sdAmount: formatMoneyString(pair.sd),
      hdAmount: formatMoneyString(pair.hd),
      amount: formatMoneyString(pair.sd),
      currency: profile.currency,
      unit: seed.unit,
      meta: {
        clientRateSheet: true,
        clientRateProfileKey: profile.key,
        sourceHeaders: [...seed.sourceHeaders],
        billingMode: "INDIA",
        gstPercent: profile.defaultGstPercent,
        billablePartySnapshot: snapshot,
        advertiser: profile.advertiser,
        rateKind: "PAIRED",
      },
    };
  });

  const singles = SINGLE_SEEDS.map((seed) => {
    const amount = profile.singleRates[seed.sourceHeaders[0]] ?? 0;
    return {
      action: seed.action,
      code: seed.code,
      label: seed.label,
      sortOrder: seed.sortOrder,
      sourceHeaders: [...seed.sourceHeaders],
      billingMode: "INDIA" as const,
      hsnSacCode: "",
      gstPercent: profile.defaultGstPercent,
      taxSlabPercent: "",
      notes: "",
      sdAmount: formatMoneyString(amount),
      hdAmount: formatMoneyString(amount),
      amount: formatMoneyString(amount),
      currency: profile.currency,
      unit: seed.unit,
      meta: {
        clientRateSheet: true,
        clientRateProfileKey: profile.key,
        sourceHeaders: [...seed.sourceHeaders],
        billingMode: "INDIA",
        gstPercent: profile.defaultGstPercent,
        billablePartySnapshot: snapshot,
        advertiser: profile.advertiser,
        rateKind: "SINGLE",
        singleRate: true,
      },
    };
  });

  return [...paired, ...singles].sort((a, b) => a.sortOrder - b.sortOrder);
}
