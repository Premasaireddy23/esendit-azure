import { useEffect, useMemo, useState } from "react";
import { HomeRefreshBar } from "../../ui/HomeRefreshBar";
import { api, apiDownload } from "../../lib/api";

type MasterRow = { id: string; name: string; code?: string | null };

type ChargeRow = {
  id: string;
  originKey: string;
  action: string;
  quantity: number;
  unit?: string | null;
  amount: any;
  currency: string;
  occurredAt: string;
  projectId?: string | null;
  missingReason?: string | null;
  billableParty?: { id: string; name: string } | null;
  project?: { id: string; projectNumber?: string | null; projectCode?: string | null; name: string } | null;
  creative?: { id: string; name: string; valid?: string | null; title?: string | null } | null;
  destination?: { id: string; name: string } | null;
  channel?: { id: string; name: string } | null;
  sla?: { id: string; name: string } | null;
};

function qs(obj: Record<string, any>) {
  const p = new URLSearchParams();
  for (const [k, v] of Object.entries(obj)) {
    if (v === undefined || v === null || v === "") continue;
    p.set(k, String(v));
  }
  const s = p.toString();
  return s ? `?${s}` : "";
}

export function BillingChargesPage() {
  const [loading, setLoading] = useState(false);
  const [rows, setRows] = useState<ChargeRow[]>([]);
  const [err, setErr] = useState<string>("");

  // filters
  const [from, setFrom] = useState<string>("");
  const [to, setTo] = useState<string>("");
  const [action, setAction] = useState<string>("");
  const [projectId, setProjectId] = useState<string>("");
  const [billablePartyId, setBillablePartyId] = useState<string>("");
  const [destinationId, setDestinationId] = useState<string>("");
  const [channelId, setChannelId] = useState<string>("");
  const [slaId, setSlaId] = useState<string>("");

  const [billableParties, setBillableParties] = useState<MasterRow[]>([]);
  const [destinations, setDestinations] = useState<MasterRow[]>([]);
  const [channels, setChannels] = useState<MasterRow[]>([]);
  const [slas, setSlas] = useState<MasterRow[]>([]);

  useEffect(() => {
    // load masters (best-effort; page still works without)
    api<MasterRow[]>(`/masters/billable-parties`).then(setBillableParties).catch(() => setBillableParties([]));
    api<MasterRow[]>(`/masters/destinations`).then(setDestinations).catch(() => setDestinations([]));
    api<MasterRow[]>(`/masters/channels`).then(setChannels).catch(() => setChannels([]));
    api<MasterRow[]>(`/masters/slas`).then(setSlas).catch(() => setSlas([]));
  }, []);

  const query = useMemo(() => {
    return {
      from: from ? new Date(from).toISOString() : "",
      to: to ? new Date(to).toISOString() : "",
      action,
      projectId,
      billablePartyId,
      destinationId,
      channelId,
      slaId,
      take: 200,
      skip: 0,
    };
  }, [from, to, action, projectId, billablePartyId, destinationId, channelId, slaId]);

  async function runSearch() {
    setErr("");
    setLoading(true);
    try {
      const data = await api<ChargeRow[]>(`/billing/charges${qs(query)}`);
      setRows(data);
    } catch (e: any) {
      setErr(e?.message || "Failed to load charges");
      setRows([]);
    } finally {
      setLoading(false);
    }
  }

  async function download(kind: "csv" | "xlsx") {
    setErr("");
    try {
      await apiDownload(`/billing/charges/export.${kind}${qs(query)}`, {}, `charges.${kind}`);
    } catch (e: any) {
      setErr(e?.message || `Failed to download ${kind}`);
    }
  }

  return (
    <div style={{ padding: 16, display: "grid", gap: 12, maxWidth: 1200 }}>
      <HomeRefreshBar
        title="Billing — Charges Export"
        onRefresh={runSearch}
        right={
          <div style={{ display: "flex", gap: 8 }}>
            <button onClick={() => download("csv")} disabled={loading}>
              Download CSV
            </button>
            <button onClick={() => download("xlsx")} disabled={loading}>
              Download Excel
            </button>
          </div>
        }
      />

      <div className="card" style={{ display: "grid", gap: 10 }}>
        <div style={{ fontWeight: 700 }}>Filters</div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(4, minmax(0, 1fr))", gap: 10 }}>
          <label style={{ display: "grid", gap: 4 }}>
            <span style={{ fontSize: 12, opacity: 0.7 }}>From</span>
            <input type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
          </label>

          <label style={{ display: "grid", gap: 4 }}>
            <span style={{ fontSize: 12, opacity: 0.7 }}>To</span>
            <input type="date" value={to} onChange={(e) => setTo(e.target.value)} />
          </label>

          <label style={{ display: "grid", gap: 4 }}>
            <span style={{ fontSize: 12, opacity: 0.7 }}>Action</span>
            <select value={action} onChange={(e) => setAction(e.target.value)}>
              <option value="">All</option>
              <option value="UPLOAD">UPLOAD</option>
              <option value="ENCODE">ENCODE</option>
              <option value="DELIVERY">DELIVERY</option>
              <option value="OTHER">OTHER</option>
            </select>
          </label>

          <label style={{ display: "grid", gap: 4 }}>
            <span style={{ fontSize: 12, opacity: 0.7 }}>Project ID</span>
            <input placeholder="UUID" value={projectId} onChange={(e) => setProjectId(e.target.value)} />
          </label>

          <label style={{ display: "grid", gap: 4 }}>
            <span style={{ fontSize: 12, opacity: 0.7 }}>Billable Party</span>
            <select value={billablePartyId} onChange={(e) => setBillablePartyId(e.target.value)}>
              <option value="">All</option>
              {billableParties.map((b) => (
                <option key={b.id} value={b.id}>
                  {b.name}
                </option>
              ))}
            </select>
          </label>

          <label style={{ display: "grid", gap: 4 }}>
            <span style={{ fontSize: 12, opacity: 0.7 }}>Destination</span>
            <select value={destinationId} onChange={(e) => setDestinationId(e.target.value)}>
              <option value="">All</option>
              {destinations.map((d) => (
                <option key={d.id} value={d.id}>
                  {d.name}
                </option>
              ))}
            </select>
          </label>

          <label style={{ display: "grid", gap: 4 }}>
            <span style={{ fontSize: 12, opacity: 0.7 }}>Channel</span>
            <select value={channelId} onChange={(e) => setChannelId(e.target.value)}>
              <option value="">All</option>
              {channels.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </label>

          <label style={{ display: "grid", gap: 4 }}>
            <span style={{ fontSize: 12, opacity: 0.7 }}>SLA</span>
            <select value={slaId} onChange={(e) => setSlaId(e.target.value)}>
              <option value="">All</option>
              {slas.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          </label>
        </div>

        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <button onClick={runSearch} disabled={loading}>
            Search
          </button>
          {loading && <span style={{ fontSize: 12, opacity: 0.7 }}>Loading...</span>}
          <span style={{ fontSize: 12, opacity: 0.7 }}>Rows shown: {rows.length}</span>
        </div>

        {err && <div style={{ color: "crimson" }}>{err}</div>}
      </div>

      <div className="card" style={{ overflowX: "auto" }}>
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr>
              {[
                "Occurred At",
                "Action",
                "Qty",
                "Amount",
                "Currency",
                "Project",
                "Creative",
                "Destination",
                "Channel",
                "SLA",
                "Billable Party",
              ].map((h) => (
                <th key={h} style={{ textAlign: "left", padding: 8, borderBottom: "1px solid #eee" }}>
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id}>
                <td style={{ padding: 8, borderBottom: "1px solid #f2f2f2", whiteSpace: "nowrap" }}>
                  {new Date(r.occurredAt).toLocaleString()}
                </td>
                <td style={{ padding: 8, borderBottom: "1px solid #f2f2f2" }}>{r.action}</td>
                <td style={{ padding: 8, borderBottom: "1px solid #f2f2f2" }}>{r.quantity}</td>
                <td style={{ padding: 8, borderBottom: "1px solid #f2f2f2" }}>{String(r.amount)}</td>
                <td style={{ padding: 8, borderBottom: "1px solid #f2f2f2" }}>{r.currency}</td>
                <td style={{ padding: 8, borderBottom: "1px solid #f2f2f2" }}>
                  {r.project ? (r.project.projectCode || r.project.projectNumber || r.project.id) : r.projectId}
                </td>
                <td style={{ padding: 8, borderBottom: "1px solid #f2f2f2" }}>
                  {r.creative ? r.creative.name || r.creative.valid : ""}
                </td>
                <td style={{ padding: 8, borderBottom: "1px solid #f2f2f2" }}>{r.destination?.name || ""}</td>
                <td style={{ padding: 8, borderBottom: "1px solid #f2f2f2" }}>{r.channel?.name || ""}</td>
                <td style={{ padding: 8, borderBottom: "1px solid #f2f2f2" }}>{r.sla?.name || ""}</td>
                <td style={{ padding: 8, borderBottom: "1px solid #f2f2f2" }}>{r.billableParty?.name || ""}</td>
              </tr>
            ))}

            {!rows.length && (
              <tr>
                <td colSpan={11} style={{ padding: 16, opacity: 0.7 }}>
                  No charges found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div style={{ fontSize: 12, opacity: 0.7 }}>
        Export includes a <b>Currency</b> column for each row (multi-currency supported).
      </div>
    </div>
  );
}
