import { useEffect, useMemo, useState } from "react";
import { api, apiDownload, type ApiError } from "../../lib/api";
import { HomeRefreshBar } from "../../ui/HomeRefreshBar";
import { findClientRateProfileByName } from "./clientRateProfiles";

type MasterRow = { id: string; name: string; code?: string | null };
type PartyRef = {
  id: string;
  name: string;
  code?: string | null;
  type?: string | null;
  emails?: string[] | null;
  contactNo?: string | null;
  address?: string | null;
  gstNumber?: string | null;
  panNumber?: string | null;
  paymentTerms?: string | null;
};
type AgencyRef = PartyRef & { agencyId?: string | null };
type BillingAgencyKey = "MEDIA" | "MEDIA_TEAM" | "CREATIVE" | "CREATIVE_TEAM" | "PRODUCTION_HOUSE" | "PRODUCTION_HOUSE_TEAM" | "POST_HOUSE" | "POST_HOUSE_TEAM" | "AUDIO" | "AUDIO_TEAM" | "UPLOADER" | "UPLOADER_TEAM";
type BillingAgencyOption = { key: BillingAgencyKey; label: string; agency: AgencyRef };
type BillingSourceKey = "ADVERTISER_GROUP" | "ADVERTISER" | "BRAND" | BillingAgencyKey;
type SelectedBillingSourceKey = BillingSourceKey | "";
type BillingSourceOption = { key: BillingSourceKey; label: string; party: PartyRef };

const PROJECT_BILLING_AGENCY_STORAGE_PREFIX = "projects.billingApplicableAgencies.";
const PROJECT_BILLING_SOURCE_STORAGE_PREFIX = "projects.billingSource.";
const PROJECT_RATE_CARD_STORAGE_PREFIX = "projects.rateCard.";
const BILLING_AGENCY_KEY_SET = new Set<BillingAgencyKey>(["MEDIA", "MEDIA_TEAM", "CREATIVE", "CREATIVE_TEAM", "PRODUCTION_HOUSE", "PRODUCTION_HOUSE_TEAM", "POST_HOUSE", "POST_HOUSE_TEAM", "AUDIO", "AUDIO_TEAM", "UPLOADER", "UPLOADER_TEAM"]);
const BILLING_SOURCE_KEY_SET = new Set<BillingSourceKey>(["ADVERTISER_GROUP", "ADVERTISER", "BRAND", "MEDIA", "MEDIA_TEAM", "CREATIVE", "CREATIVE_TEAM", "PRODUCTION_HOUSE", "PRODUCTION_HOUSE_TEAM", "POST_HOUSE", "POST_HOUSE_TEAM", "AUDIO", "AUDIO_TEAM", "UPLOADER", "UPLOADER_TEAM"]);
type ProjectOption = {
  id: string;
  name: string;
  projectCode?: string | null;
  projectNumber?: string | null;
  billablePartyId?: string | null;
  billableParty?: PartyRef | null;
  advertiserGroup?: PartyRef | null;
  advertiser?: PartyRef | null;
  brand?: PartyRef | null;
  mediaAgency?: AgencyRef | null;
  mediaAgencyTeam?: AgencyRef | null;
  creativeAgency?: AgencyRef | null;
  creativeAgencyTeam?: AgencyRef | null;
  productionHouse?: AgencyRef | null;
  productionHouseTeam?: AgencyRef | null;
  postHouse?: AgencyRef | null;
  postHouseTeam?: AgencyRef | null;
  audioAgency?: AgencyRef | null;
  audioAgencyTeam?: AgencyRef | null;
  uploaderAgency?: AgencyRef | null;
  uploaderAgencyTeam?: AgencyRef | null;
};

type RateCardSummary = {
  id: string;
  name: string;
  billablePartyId?: string | null;
  effectiveFrom?: string;
  effectiveTo?: string | null;
  status?: string;
};

type InvoiceRow = {
  id: string;
  date: string;
  description: string;
  project: string;
  creative: string;
  destination: string;
  channel: string;
  sla: string;
  action: string;
  itemCode?: string | null;
  hsnSacCode?: string | null;
  quantity: number;
  unit: string;
  unitRate: number;
  lineTotal: number;
  currency: string;
  gstPercent: number;
  taxSlabPercent: number;
  cgstAmount: number;
  sgstAmount: number;
  igstAmount: number;
  taxAmount: number;
  totalWithTax: number;
};

type InvoiceTotal = {
  currency: string;
  subTotal: number;
  taxTotal: number;
  cgstTotal: number;
  sgstTotal: number;
  igstTotal: number;
  grandTotal: number;
};

type InvoicePreview = {
  invoiceNumber: string;
  invoiceDate: string;
  dueDate: string;
  invoiceMode: "INDIA" | "GLOBAL";
  indiaTaxType: "INTRA" | "INTER";
  notes?: string;
  rowCount: number;
  warnings?: string[];
  invoiceFrom?: {
    name?: string | null;
    address?: string | null;
    email?: string | null;
    phone?: string | null;
    gstNumber?: string | null;
    panNumber?: string | null;
  } | null;
  bankDetails?: {
    beneficiaryName?: string | null;
    bankName?: string | null;
    bankBranch?: string | null;
    accountNumber?: string | null;
    ifscCode?: string | null;
    accountType?: string | null;
  } | null;
  billableParty?: {
    id?: string;
    name: string;
    contactName?: string | null;
    advertiser?: string | null;
    address?: string | null;
    email?: string | null;
    phone?: string | null;
    projectNo?: string | null;
    brand?: string | null;
    poNumber?: string | null;
    gstNumber?: string | null;
    panNumber?: string | null;
    paymentTerms?: string | null;
  } | null;
  rows: InvoiceRow[];
  totals: InvoiceTotal[];
};

type ManualInvoiceRow = {
  id: string;
  date: string;
  description: string;
  project: string;
  creative: string;
  destination: string;
  channel: string;
  sla: string;
  action: string;
  itemCode: string;
  hsnSacCode: string;
  quantity: string;
  unit: string;
  unitRate: string;
  currency: string;
  gstPercent: string;
  taxSlabPercent: string;
};


type ManualBillTo = {
  name: string;
  contactName: string;
  advertiser: string;
  address: string;
  email: string;
  phone: string;
  projectNo: string;
  brand: string;
  poNumber: string;
  paymentTerms: string;
  gstNumber: string;
  panNumber: string;
};

function qs(obj: Record<string, any>) {
  const p = new URLSearchParams();
  for (const [k, v] of Object.entries(obj)) {
    if (v === undefined || v === null || v === "") continue;
    p.set(k, String(v));
  }
  const s = p.toString();
  return s ? `?${s}` : "";
}

function parseDateValue(value?: string | null) {
  if (!value) return 0;
  const ts = new Date(value).getTime();
  return Number.isFinite(ts) ? ts : 0;
}

function pickLatestRateCard(rateCards: RateCardSummary[], billablePartyId?: string | null) {
  const linkedId = String(billablePartyId || "").trim();
  if (!linkedId) return null;
  const matches = rateCards.filter((card) => String(card.billablePartyId || "").trim() === linkedId);
  if (!matches.length) return null;
  return [...matches].sort((a, b) => {
    const statusA = String(a.status || "").toUpperCase() === "ACTIVE" ? 1 : 0;
    const statusB = String(b.status || "").toUpperCase() === "ACTIVE" ? 1 : 0;
    if (statusA !== statusB) return statusB - statusA;
    return parseDateValue(b.effectiveFrom) - parseDateValue(a.effectiveFrom);
  })[0] || null;
}

function normalizeBillingAgencyKeys(value: unknown): BillingAgencyKey[] {
  if (!Array.isArray(value)) return [];
  const out: BillingAgencyKey[] = [];
  for (const item of value) {
    const key = String(item || "").trim().toUpperCase() as BillingAgencyKey;
    if (BILLING_AGENCY_KEY_SET.has(key) && !out.includes(key)) out.push(key);
  }
  return out;
}

function loadProjectBillingAgencyKeys(projectId?: string | null): BillingAgencyKey[] | null {
  const id = String(projectId || "").trim();
  if (!id) return null;
  try {
    const raw = safeLocalStorageGet(`${PROJECT_BILLING_AGENCY_STORAGE_PREFIX}${id}`);
    if (!raw) return null;
    return normalizeBillingAgencyKeys(JSON.parse(raw));
  } catch {
    return null;
  }
}

function saveProjectBillingAgencyKeys(projectId: string, keys: BillingAgencyKey[]) {
  const id = String(projectId || "").trim();
  if (!id) return;
  safeLocalStorageSet(`${PROJECT_BILLING_AGENCY_STORAGE_PREFIX}${id}`, JSON.stringify(normalizeBillingAgencyKeys(keys)));
}

function normalizeBillingSourceKey(value: unknown): SelectedBillingSourceKey {
  const key = String(value || "").trim().toUpperCase() as BillingSourceKey;
  return BILLING_SOURCE_KEY_SET.has(key) ? key : "";
}

function loadProjectBillingSourceKey(projectId?: string | null): SelectedBillingSourceKey {
  const id = String(projectId || "").trim();
  if (!id) return "";
  return normalizeBillingSourceKey(safeLocalStorageGet(`${PROJECT_BILLING_SOURCE_STORAGE_PREFIX}${id}`));
}

function saveProjectBillingSourceKey(projectId: string, key: SelectedBillingSourceKey) {
  const id = String(projectId || "").trim();
  if (!id) return;
  safeLocalStorageSet(`${PROJECT_BILLING_SOURCE_STORAGE_PREFIX}${id}`, normalizeBillingSourceKey(key));
}

function loadProjectRateCardId(projectId?: string | null): string {
  const id = String(projectId || "").trim();
  if (!id) return "";
  return String(safeLocalStorageGet(`${PROJECT_RATE_CARD_STORAGE_PREFIX}${id}`) || "").trim();
}

function projectBillingAgencies(project: ProjectOption | null) {
  if (!project) return [] as BillingAgencyOption[];
  return [
    { key: "MEDIA", label: "Media", agency: project.mediaAgency },
    { key: "MEDIA_TEAM", label: "Media Team", agency: project.mediaAgencyTeam },
    { key: "CREATIVE", label: "Creative", agency: project.creativeAgency },
    { key: "CREATIVE_TEAM", label: "Creative Team", agency: project.creativeAgencyTeam },
    { key: "PRODUCTION_HOUSE", label: "Production", agency: project.productionHouse },
    { key: "PRODUCTION_HOUSE_TEAM", label: "Production Team", agency: project.productionHouseTeam },
    { key: "POST_HOUSE", label: "Post House", agency: project.postHouse },
    { key: "POST_HOUSE_TEAM", label: "Post House Team", agency: project.postHouseTeam },
    { key: "AUDIO", label: "Audio", agency: project.audioAgency },
    { key: "AUDIO_TEAM", label: "Audio Team", agency: project.audioAgencyTeam },
    { key: "UPLOADER", label: "Uploader", agency: project.uploaderAgency },
    { key: "UPLOADER_TEAM", label: "Uploader Team", agency: project.uploaderAgencyTeam },
  ].filter((item): item is BillingAgencyOption => !!item.agency?.id && !!item.agency?.name);
}

function projectBillingSourceOptions(project: ProjectOption | null, linkedAgencies: BillingAgencyOption[]) {
  if (!project) return [] as BillingSourceOption[];
  return [
    project.advertiserGroup?.id ? { key: "ADVERTISER_GROUP" as BillingSourceKey, label: "Advertiser Group", party: project.advertiserGroup } : null,
    project.advertiser?.id ? { key: "ADVERTISER" as BillingSourceKey, label: "Advertiser", party: project.advertiser } : null,
    project.brand?.id ? { key: "BRAND" as BillingSourceKey, label: "Brand", party: project.brand } : null,
    ...linkedAgencies.map((item) => ({ key: item.key as BillingSourceKey, label: item.label, party: item.agency })),
  ].filter((item): item is BillingSourceOption => !!item?.party?.id && !!item.party.name);
}

function firstEmail(value?: string[] | null) {
  return Array.isArray(value) ? String(value.find((item) => String(item || "").trim()) || "") : "";
}

function deriveAutoBillTo(
  selectedProject: ProjectOption | null,
  selectedSource: BillingSourceOption | null,
  linkedBillableParty: PartyRef | null,
) {
  if (!selectedProject) return null;
  const baseParty = linkedBillableParty || selectedSource?.party || null;
  if (!baseParty) return null;
  return {
    billToName: baseParty.name || "",
    billToContactName: "",
    billToAdvertiser: selectedProject.advertiser?.name || "",
    billToAddress: baseParty.address || "",
    billToEmail: firstEmail(baseParty.emails),
    billToPhone: baseParty.contactNo || "",
    billToProjectNo: selectedProject.projectNumber || selectedProject.projectCode || "",
    billToBrand: selectedProject.brand?.name || "",
    billToGstNumber: baseParty.gstNumber || "",
    billToPanNumber: baseParty.panNumber || "",
    billToPaymentTerms: baseParty.paymentTerms || "",
  };
}

function fmtMoney(v: number) {
  return Number(v || 0).toFixed(2);
}

function num(v: any) {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

function normalizeDateForApi(value: string) {
  if (!value) return "";
  const trimmed = String(value).trim();
  if (!trimmed) return "";

  const direct = new Date(trimmed);
  if (!Number.isNaN(direct.getTime())) return direct.toISOString();

  const dmy = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(trimmed);
  if (dmy) {
    const day = dmy[1].padStart(2, "0");
    const month = dmy[2].padStart(2, "0");
    const year = dmy[3];
    return new Date(`${year}-${month}-${day}T00:00:00.000Z`).toISOString();
  }

  return trimmed;
}

function safeLocalStorageGet(key: string) {
  try {
    if (typeof window === "undefined") return "";
    return window.localStorage.getItem(key) || "";
  } catch {
    return "";
  }
}

function safeLocalStorageSet(key: string, value: string) {
  try {
    if (typeof window === "undefined") return;
    if (value) window.localStorage.setItem(key, value);
    else window.localStorage.removeItem(key);
  } catch {
    // ignore local storage failures
  }
}

function safeLocalStorageGetJson<T>(key: string, fallback: T): T {
  try {
    const raw = safeLocalStorageGet(key);
    if (!raw) return fallback;
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function safeLocalStorageSetJson(key: string, value: unknown) {
  try {
    if (typeof window === "undefined") return;
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // ignore local storage failures
  }
}

function makeManualRow(seedDate?: string): ManualInvoiceRow {
  return {
    id: `manual-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    date: seedDate || new Date().toISOString().slice(0, 10),
    description: "",
    project: "",
    creative: "",
    destination: "",
    channel: "",
    sla: "",
    action: "",
    itemCode: "",
    hsnSacCode: "",
    quantity: "1",
    unit: "each",
    unitRate: "0",
    currency: "EUR",
    gstPercent: "",
    taxSlabPercent: "",
  };
}

function normalizeManualRows(raw: any): ManualInvoiceRow[] {
  if (!Array.isArray(raw) || !raw.length) return [makeManualRow()];
  return raw.map((row: any, index: number) => ({
    id: String(row?.id || `manual-${index + 1}`),
    date: String(row?.date || new Date().toISOString().slice(0, 10)),
    description: String(row?.description || ""),
    project: String(row?.project || ""),
    creative: String(row?.creative || ""),
    destination: String(row?.destination || ""),
    channel: String(row?.channel || ""),
    sla: String(row?.sla || ""),
    action: String(row?.action || ""),
    itemCode: String(row?.itemCode || ""),
    hsnSacCode: String(row?.hsnSacCode || ""),
    quantity: String(row?.quantity ?? "1"),
    unit: String(row?.unit || "each"),
    unitRate: String(row?.unitRate ?? "0"),
    currency: String(row?.currency || "EUR"),
    gstPercent: String(row?.gstPercent ?? ""),
    taxSlabPercent: String(row?.taxSlabPercent ?? ""),
  }));
}

function normalizeManualBillTo(raw: any): ManualBillTo {
  return {
    name: String(raw?.name || ""),
    contactName: String(raw?.contactName || ""),
    advertiser: String(raw?.advertiser || ""),
    address: String(raw?.address || ""),
    email: String(raw?.email || ""),
    phone: String(raw?.phone || ""),
    projectNo: String(raw?.projectNo || ""),
    brand: String(raw?.brand || ""),
    poNumber: String(raw?.poNumber || ""),
    paymentTerms: String(raw?.paymentTerms || ""),
    gstNumber: String(raw?.gstNumber || ""),
    panNumber: String(raw?.panNumber || ""),
  };
}

function rowHasContent(row: ManualInvoiceRow) {
  return !![
    row.description,
    row.project,
    row.creative,
    row.destination,
    row.channel,
    row.sla,
    row.action,
    row.itemCode,
    row.hsnSacCode,
  ].find((v) => String(v || "").trim());
}

export function BillingInvoicesPage() {
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string>("");
  const [preview, setPreview] = useState<InvoicePreview | null>(null);

  const [from, setFrom] = useState<string>("");
  const [to, setTo] = useState<string>("");
  const [action, setAction] = useState<string>("");
  const [projectId, setProjectId] = useState<string>("");
  const [destinationId, setDestinationId] = useState<string>("");
  const [channelId, setChannelId] = useState<string>("");
  const [slaId, setSlaId] = useState<string>("");
  const [billablePartyId, setBillablePartyId] = useState<string>("");

  const [invoiceNumber, setInvoiceNumber] = useState<string>(`INV-${new Date().toISOString().slice(0, 10)}`);
  const [invoiceDate, setInvoiceDate] = useState<string>(new Date().toISOString().slice(0, 10));
  const [dueDate, setDueDate] = useState<string>(new Date().toISOString().slice(0, 10));
  const [notes, setNotes] = useState<string>("");
  const [invoiceMode, setInvoiceMode] = useState<"INDIA" | "GLOBAL">("GLOBAL");
  const [invoiceSource, setInvoiceSource] = useState<"AUTO" | "MANUAL">(() => {
    const raw = safeLocalStorageGet("billing.invoiceSource");
    return raw === "MANUAL" ? "MANUAL" : "AUTO";
  });
  const [indiaTaxType, setIndiaTaxType] = useState<"INTRA" | "INTER">("INTRA");
  const [defaultGstPercent, setDefaultGstPercent] = useState<string>("18");
  const [defaultTaxSlabPercent, setDefaultTaxSlabPercent] = useState<string>("0");

  const [invoiceFromName, setInvoiceFromName] = useState<string>(() => safeLocalStorageGet("billing.invoiceFromName"));
  const [invoiceFromAddress, setInvoiceFromAddress] = useState<string>(() => safeLocalStorageGet("billing.invoiceFromAddress"));
  const [invoiceFromEmail, setInvoiceFromEmail] = useState<string>(() => safeLocalStorageGet("billing.invoiceFromEmail"));
  const [invoiceFromPhone, setInvoiceFromPhone] = useState<string>(() => safeLocalStorageGet("billing.invoiceFromPhone"));
  const [invoiceFromGstNumber, setInvoiceFromGstNumber] = useState<string>(() => safeLocalStorageGet("billing.invoiceFromGstNumber"));
  const [invoiceFromPanNumber, setInvoiceFromPanNumber] = useState<string>(() => safeLocalStorageGet("billing.invoiceFromPanNumber"));
  const [bankBeneficiaryName, setBankBeneficiaryName] = useState<string>(() => safeLocalStorageGet("billing.bankBeneficiaryName"));
  const [bankName, setBankName] = useState<string>(() => safeLocalStorageGet("billing.bankName"));
  const [bankBranch, setBankBranch] = useState<string>(() => safeLocalStorageGet("billing.bankBranch"));
  const [bankAccountNumber, setBankAccountNumber] = useState<string>(() => safeLocalStorageGet("billing.bankAccountNumber"));
  const [bankIfscCode, setBankIfscCode] = useState<string>(() => safeLocalStorageGet("billing.bankIfscCode"));
  const [bankAccountType, setBankAccountType] = useState<string>(() => safeLocalStorageGet("billing.bankAccountType"));
  const [manualBillTo, setManualBillTo] = useState<ManualBillTo>(() => normalizeManualBillTo(safeLocalStorageGetJson("billing.manualBillTo", {})));
  const [manualRows, setManualRows] = useState<ManualInvoiceRow[]>(() => normalizeManualRows(safeLocalStorageGetJson("billing.manualRows", [])));

  const [billableParties, setBillableParties] = useState<PartyRef[]>([]);
  const [projects, setProjects] = useState<ProjectOption[]>([]);
  const [projectBillingAgencyKeys, setProjectBillingAgencyKeys] = useState<BillingAgencyKey[] | null>(null);
  const [projectBillingSourceKey, setProjectBillingSourceKey] = useState<SelectedBillingSourceKey>("");
  const [rateCards, setRateCards] = useState<RateCardSummary[]>([]);
  const [destinations, setDestinations] = useState<MasterRow[]>([]);
  const [channels, setChannels] = useState<MasterRow[]>([]);
  const [slas, setSlas] = useState<MasterRow[]>([]);

  useEffect(() => {
    api<PartyRef[]>(`/masters/billable-parties`).then(setBillableParties).catch(() => setBillableParties([]));
    api<{ items?: ProjectOption[] }>(`/masters/projects?take=200&sort=name&order=asc`).then((res) => setProjects(Array.isArray(res?.items) ? res.items : [])).catch(() => setProjects([]));
    api<RateCardSummary[]>(`/masters/rate-cards`).then(setRateCards).catch(() => setRateCards([]));
    api<MasterRow[]>(`/masters/destinations`).then(setDestinations).catch(() => setDestinations([]));
    api<MasterRow[]>(`/masters/channels`).then(setChannels).catch(() => setChannels([]));
    api<MasterRow[]>(`/masters/slas`).then(setSlas).catch(() => setSlas([]));
  }, []);

  const selectedProject = useMemo(() => projects.find((project) => project.id === projectId) || null, [projects, projectId]);

  useEffect(() => {
    if (!selectedProject) return;
    const linkedBillablePartyId = String(selectedProject.billablePartyId || selectedProject.billableParty?.id || "").trim();
    if (!linkedBillablePartyId) return;
    if (linkedBillablePartyId !== billablePartyId) {
      setBillablePartyId(linkedBillablePartyId);
    }
  }, [selectedProject, billablePartyId]);

  const matchedBillableParty = useMemo(() => {
    if (billablePartyId) {
      return billableParties.find((party) => party.id === billablePartyId) || selectedProject?.billableParty || null;
    }
    return selectedProject?.billableParty || null;
  }, [billableParties, billablePartyId, selectedProject]);
  const matchedClientProfile = useMemo(() => findClientRateProfileByName(matchedBillableParty?.name), [matchedBillableParty]);
  const projectAgencyOptions = useMemo(() => projectBillingAgencies(selectedProject), [selectedProject]);
  const projectAgencyOptionsSignature = useMemo(() => projectAgencyOptions.map((item) => `${item.key}:${item.agency.id}`).join("|"), [projectAgencyOptions]);

  useEffect(() => {
    setProjectBillingAgencyKeys(loadProjectBillingAgencyKeys(selectedProject?.id));
    setProjectBillingSourceKey(loadProjectBillingSourceKey(selectedProject?.id));
  }, [selectedProject?.id]);

  useEffect(() => {
    if (projectBillingAgencyKeys == null) return;
    const available = new Set(projectAgencyOptions.map((item) => item.key));
    const filtered = projectBillingAgencyKeys.filter((key) => available.has(key));
    if (filtered.length === projectBillingAgencyKeys.length) return;
    setProjectBillingAgencyKeys(filtered);
    if (selectedProject?.id) saveProjectBillingAgencyKeys(selectedProject.id, filtered);
  }, [projectAgencyOptionsSignature, projectBillingAgencyKeys, selectedProject?.id]);

  const linkedProjectAgencies = useMemo(() => {
    if (projectBillingAgencyKeys == null) return projectAgencyOptions;
    return projectAgencyOptions.filter((item) => projectBillingAgencyKeys.includes(item.key));
  }, [projectAgencyOptions, projectBillingAgencyKeys]);
  const projectBillToOptions = useMemo(() => projectBillingSourceOptions(selectedProject, linkedProjectAgencies), [selectedProject, linkedProjectAgencies]);
  const projectBillToOptionsSignature = useMemo(() => projectBillToOptions.map((item) => `${item.key}:${item.party.id}`).join("|"), [projectBillToOptions]);
  useEffect(() => {
    if (!projectBillingSourceKey) return;
    const current = projectBillToOptions.find((item) => item.key === projectBillingSourceKey);
    if (!current) setProjectBillingSourceKey("");
  }, [projectBillToOptionsSignature, projectBillingSourceKey]);
  const selectedProjectBillTo = useMemo(
    () => projectBillToOptions.find((item) => item.key === projectBillingSourceKey) || null,
    [projectBillToOptions, projectBillingSourceKey],
  );
  const autoBillTo = useMemo(() => deriveAutoBillTo(selectedProject, selectedProjectBillTo, matchedBillableParty as PartyRef | null), [selectedProject, selectedProjectBillTo, matchedBillableParty]);
  const selectedProjectRateCardId = useMemo(() => loadProjectRateCardId(selectedProject?.id), [selectedProject?.id]);
  const linkedRateCard = useMemo(() => {
    const manuallySelected = rateCards.find((card) => card.id === selectedProjectRateCardId);
    if (manuallySelected) return manuallySelected;
    return pickLatestRateCard(rateCards, selectedProject?.billablePartyId || selectedProject?.billableParty?.id || billablePartyId);
  }, [rateCards, selectedProjectRateCardId, selectedProject, billablePartyId]);

  const toggleProjectBillingAgencyKey = (key: BillingAgencyKey) => {
    if (!selectedProject?.id) return;
    setProjectBillingAgencyKeys((prev) => {
      const base = Array.isArray(prev) ? prev : projectAgencyOptions.map((item) => item.key);
      const next = base.includes(key) ? base.filter((item) => item !== key) : [...base, key];
      saveProjectBillingAgencyKeys(selectedProject.id, next);
      return next;
    });
  };

  const changeProjectBillingSourceKey = (key: SelectedBillingSourceKey) => {
    setProjectBillingSourceKey(key);
    if (selectedProject?.id) saveProjectBillingSourceKey(selectedProject.id, key);
  };

  useEffect(() => {
    if (!matchedClientProfile) return;
    if (!defaultGstPercent) setDefaultGstPercent(matchedClientProfile.defaultGstPercent);
  }, [matchedClientProfile, defaultGstPercent]);

  useEffect(() => {
    safeLocalStorageSet("billing.invoiceFromName", invoiceFromName);
    safeLocalStorageSet("billing.invoiceFromAddress", invoiceFromAddress);
    safeLocalStorageSet("billing.invoiceFromEmail", invoiceFromEmail);
    safeLocalStorageSet("billing.invoiceFromPhone", invoiceFromPhone);
    safeLocalStorageSet("billing.invoiceFromGstNumber", invoiceFromGstNumber);
    safeLocalStorageSet("billing.invoiceFromPanNumber", invoiceFromPanNumber);
    safeLocalStorageSet("billing.bankBeneficiaryName", bankBeneficiaryName);
    safeLocalStorageSet("billing.bankName", bankName);
    safeLocalStorageSet("billing.bankBranch", bankBranch);
    safeLocalStorageSet("billing.bankAccountNumber", bankAccountNumber);
    safeLocalStorageSet("billing.bankIfscCode", bankIfscCode);
    safeLocalStorageSet("billing.bankAccountType", bankAccountType);
    safeLocalStorageSet("billing.invoiceSource", invoiceSource);
  }, [
    invoiceFromName,
    invoiceFromAddress,
    invoiceFromEmail,
    invoiceFromPhone,
    invoiceFromGstNumber,
    invoiceFromPanNumber,
    bankBeneficiaryName,
    bankName,
    bankBranch,
    bankAccountNumber,
    bankIfscCode,
    bankAccountType,
    invoiceSource,
  ]);

  useEffect(() => {
    safeLocalStorageSetJson("billing.manualBillTo", manualBillTo);
  }, [manualBillTo]);

  useEffect(() => {
    safeLocalStorageSetJson("billing.manualRows", manualRows);
  }, [manualRows]);

  const query = useMemo(() => {
    return {
      from: normalizeDateForApi(from),
      to: normalizeDateForApi(to),
      action,
      projectId,
      destinationId,
      channelId,
      slaId,
      billablePartyId,
      invoiceNumber,
      invoiceDate,
      dueDate,
      notes,
      invoiceFromName,
      invoiceFromAddress,
      invoiceFromEmail,
      invoiceFromPhone,
      invoiceFromGstNumber,
      invoiceFromPanNumber,
      bankBeneficiaryName,
      bankName,
      bankBranch,
      bankAccountNumber,
      bankIfscCode,
      bankAccountType,
      invoiceMode,
      indiaTaxType,
      defaultGstPercent: invoiceMode === "INDIA" ? defaultGstPercent : "",
      defaultTaxSlabPercent: invoiceMode === "GLOBAL" ? defaultTaxSlabPercent : "",
      billToName: invoiceSource === "AUTO" ? autoBillTo?.billToName || "" : "",
      billToContactName: invoiceSource === "AUTO" ? autoBillTo?.billToContactName || "" : "",
      billToAdvertiser: invoiceSource === "AUTO" ? autoBillTo?.billToAdvertiser || "" : "",
      billToAddress: invoiceSource === "AUTO" ? autoBillTo?.billToAddress || "" : "",
      billToEmail: invoiceSource === "AUTO" ? autoBillTo?.billToEmail || "" : "",
      billToPhone: invoiceSource === "AUTO" ? autoBillTo?.billToPhone || "" : "",
      billToProjectNo: invoiceSource === "AUTO" ? autoBillTo?.billToProjectNo || "" : "",
      billToBrand: invoiceSource === "AUTO" ? autoBillTo?.billToBrand || "" : "",
      billToGstNumber: invoiceSource === "AUTO" ? autoBillTo?.billToGstNumber || "" : "",
      billToPanNumber: invoiceSource === "AUTO" ? autoBillTo?.billToPanNumber || "" : "",
      billToPaymentTerms: invoiceSource === "AUTO" ? autoBillTo?.billToPaymentTerms || "" : "",
    };
  }, [from, to, action, projectId, destinationId, channelId, slaId, billablePartyId, invoiceNumber, invoiceDate, dueDate, notes, invoiceFromName, invoiceFromAddress, invoiceFromEmail, invoiceFromPhone, invoiceFromGstNumber, invoiceFromPanNumber, bankBeneficiaryName, bankName, bankBranch, bankAccountNumber, bankIfscCode, bankAccountType, invoiceMode, indiaTaxType, defaultGstPercent, defaultTaxSlabPercent, invoiceSource, autoBillTo]);

  const manualPayload = useMemo(() => {
    return {
      ...query,
      billToName: manualBillTo.name,
      billToContactName: manualBillTo.contactName,
      billToAdvertiser: manualBillTo.advertiser,
      billToAddress: manualBillTo.address,
      billToEmail: manualBillTo.email,
      billToPhone: manualBillTo.phone,
      billToProjectNo: manualBillTo.projectNo,
      billToBrand: manualBillTo.brand,
      billToPoNumber: manualBillTo.poNumber,
      billToPaymentTerms: manualBillTo.paymentTerms,
      billToGstNumber: manualBillTo.gstNumber,
      billToPanNumber: manualBillTo.panNumber,
      rows: manualRows.filter(rowHasContent).map((row) => ({
        ...row,
        date: normalizeDateForApi(row.date),
      })),
    };
  }, [query, manualBillTo, manualRows]);

  const manualRowCount = manualPayload.rows.length;
  const manualBillToName = String(manualBillTo.name || "").trim();

  function updateManualBillTo(patch: Partial<ManualBillTo>) {
    setManualBillTo((prev) => ({ ...prev, ...patch }));
  }

  function updateManualRow(rowId: string, patch: Partial<ManualInvoiceRow>) {
    setManualRows((prev) => prev.map((row) => (row.id === rowId ? { ...row, ...patch } : row)));
  }

  function addManualRow(copyFromId?: string) {
    setManualRows((prev) => {
      if (copyFromId) {
        const found = prev.find((row) => row.id === copyFromId);
        if (found) return [...prev, { ...found, id: makeManualRow(found.date).id }];
      }
      return [...prev, makeManualRow(invoiceDate)];
    });
  }

  function removeManualRow(rowId: string) {
    setManualRows((prev) => {
      const next = prev.filter((row) => row.id !== rowId);
      return next.length ? next : [makeManualRow(invoiceDate)];
    });
  }

  async function previewInvoice() {
    if (invoiceSource === "AUTO" && !projectId && !billablePartyId) {
      setErr("Select a project or a billable party for invoice generation");
      setPreview(null);
      return;
    }

    if (invoiceSource === "MANUAL" && !billablePartyId && !manualBillToName) {
      setErr("In manual mode, add a Bill To name or choose a billable party base");
      setPreview(null);
      return;
    }

    if (invoiceSource === "MANUAL" && manualRowCount === 0) {
      setErr("Add at least one manual invoice line before preview");
      setPreview(null);
      return;
    }

    setErr("");
    setLoading(true);
    try {
      const data = invoiceSource === "MANUAL"
        ? await api<InvoicePreview>(`/billing/invoices/manual/preview`, {
            method: "POST",
            body: JSON.stringify(manualPayload),
          })
        : await api<InvoicePreview>(`/billing/invoices/preview${qs(query)}`);
      setPreview(data);
    } catch (e: any) {
      const ae = e as ApiError;
      setErr(ae.message || "Failed to build invoice preview");
      setPreview(null);
    } finally {
      setLoading(false);
    }
  }

  async function download(kind: "pdf" | "csv" | "xlsx") {
    if (invoiceSource === "AUTO" && !projectId && !billablePartyId) {
      setErr("Select a project or a billable party for invoice generation");
      return;
    }
    if (invoiceSource === "MANUAL" && !billablePartyId && !manualBillToName) {
      setErr("In manual mode, add a Bill To name or choose a billable party base");
      return;
    }
    if (invoiceSource === "MANUAL" && manualRowCount === 0) {
      setErr("Add at least one manual invoice line before download");
      return;
    }

    setErr("");
    try {
      if (invoiceSource === "MANUAL") {
        await apiDownload(`/billing/invoices/manual/export.${kind}`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(manualPayload),
        }, `invoice.${kind}`);
      } else {
        await apiDownload(`/billing/invoices/export.${kind}${qs(query)}`, {}, `invoice.${kind}`);
      }
    } catch (e: any) {
      const ae = e as ApiError;
      setErr(ae.message || `Failed to download ${kind}`);
    }
  }

  return (
    <div style={{ padding: 16, display: "grid", gap: 12, maxWidth: 1400 }}>
      <HomeRefreshBar
        title="Billing — Invoice Generator"
        onRefresh={previewInvoice}
        right={
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            <button onClick={previewInvoice} disabled={loading}>Preview</button>
            <button onClick={() => download("pdf")} disabled={loading}>Download PDF</button>
            <button onClick={() => download("xlsx")} disabled={loading}>Download Excel</button>
            <button onClick={() => download("csv")} disabled={loading}>Download CSV</button>
          </div>
        }
      />

      <div className="card" style={{ display: "grid", gap: 10 }}>
        <div style={{ fontWeight: 700 }}>Invoice Setup</div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(5, minmax(0, 1fr))", gap: 10 }}>
          <label style={{ display: "grid", gap: 4 }}>
            <span style={{ fontSize: 12, opacity: 0.7 }}>{invoiceSource === "MANUAL" ? "Project (optional)" : "Project"}</span>
            <select value={projectId} onChange={(e) => setProjectId(e.target.value)}>
              <option value="">{invoiceSource === "MANUAL" ? "Optional project" : "Select project (recommended)"}</option>
              {projects.map((project) => (
                <option key={project.id} value={project.id}>
                  {project.name}{project.projectCode ? ` • ${project.projectCode}` : project.projectNumber ? ` • ${project.projectNumber}` : ""}
                </option>
              ))}
            </select>
          </label>

          <label style={{ display: "grid", gap: 4 }}>
            <span style={{ fontSize: 12, opacity: 0.7 }}>{invoiceSource === "MANUAL" ? "Billable Party Base (optional)" : projectId ? "Project Billable Party *" : "Billable Party *"}</span>
            <select value={billablePartyId} onChange={(e) => setBillablePartyId(e.target.value)}>
              <option value="">{invoiceSource === "MANUAL" ? "Optional base billable party" : projectId ? "Linked billable party for this project" : "Select billable party"}</option>
              {billableParties.map((b) => (
                <option key={b.id} value={b.id}>{b.name}</option>
              ))}
            </select>
          </label>

          <label style={{ display: "grid", gap: 4 }}>
            <span style={{ fontSize: 12, opacity: 0.7 }}>Invoice Source</span>
            <select value={invoiceSource} onChange={(e) => setInvoiceSource(e.target.value as "AUTO" | "MANUAL")}>
              <option value="AUTO">Auto from billing charges</option>
              <option value="MANUAL">Manual invoice lines</option>
            </select>
          </label>

          <label style={{ display: "grid", gap: 4 }}>
            <span style={{ fontSize: 12, opacity: 0.7 }}>Invoice Number</span>
            <input value={invoiceNumber} onChange={(e) => setInvoiceNumber(e.target.value)} />
          </label>

          <label style={{ display: "grid", gap: 4 }}>
            <span style={{ fontSize: 12, opacity: 0.7 }}>Invoice Date</span>
            <input type="date" value={invoiceDate} onChange={(e) => setInvoiceDate(e.target.value)} />
          </label>

          <label style={{ display: "grid", gap: 4 }}>
            <span style={{ fontSize: 12, opacity: 0.7 }}>Due Date</span>
            <input type="date" value={dueDate} onChange={(e) => setDueDate(e.target.value)} />
          </label>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: invoiceMode === "INDIA" ? "repeat(4, minmax(0, 1fr))" : "repeat(3, minmax(0, 1fr))", gap: 10 }}>
          <label style={{ display: "grid", gap: 4 }}>
            <span style={{ fontSize: 12, opacity: 0.7 }}>Mode</span>
            <select value={invoiceMode} onChange={(e) => setInvoiceMode(e.target.value as any)}>
              <option value="GLOBAL">Global</option>
              <option value="INDIA">India</option>
            </select>
          </label>

          {invoiceMode === "INDIA" ? (
            <>
              <label style={{ display: "grid", gap: 4 }}>
                <span style={{ fontSize: 12, opacity: 0.7 }}>GST Type</span>
                <select value={indiaTaxType} onChange={(e) => setIndiaTaxType(e.target.value as any)}>
                  <option value="INTRA">Intra-state (CGST + SGST)</option>
                  <option value="INTER">Inter-state (IGST)</option>
                </select>
              </label>
              <label style={{ display: "grid", gap: 4 }}>
                <span style={{ fontSize: 12, opacity: 0.7 }}>Default GST %</span>
                <input type="number" step="0.01" value={defaultGstPercent} onChange={(e) => setDefaultGstPercent(e.target.value)} />
              </label>
            </>
          ) : (
            <label style={{ display: "grid", gap: 4 }}>
              <span style={{ fontSize: 12, opacity: 0.7 }}>Default Tax Slab %</span>
              <input type="number" step="0.01" value={defaultTaxSlabPercent} onChange={(e) => setDefaultTaxSlabPercent(e.target.value)} />
            </label>
          )}

          <label style={{ display: "grid", gap: 4, gridColumn: invoiceMode === "INDIA" ? "span 2" : "span 2" }}>
            <span style={{ fontSize: 12, opacity: 0.7 }}>Notes</span>
            <input value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Optional invoice notes" />
          </label>
        </div>
      </div>

      <div className="card" style={{ display: "grid", gap: 10 }}>
        <div style={{ fontWeight: 700 }}>Invoice From &amp; Bank Details</div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: 12 }}>
          <div style={{ display: "grid", gap: 10 }}>
            <div style={{ fontWeight: 600, fontSize: 13 }}>Invoice From</div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: 10 }}>
              <label style={{ display: "grid", gap: 4, gridColumn: "span 2" }}>
                <span style={{ fontSize: 12, opacity: 0.7 }}>Company / Account Name</span>
                <input value={invoiceFromName} onChange={(e) => setInvoiceFromName(e.target.value)} placeholder="e.g. Digilit Digital Solutions Private Limited" />
              </label>
              <label style={{ display: "grid", gap: 4, gridColumn: "span 2" }}>
                <span style={{ fontSize: 12, opacity: 0.7 }}>Address</span>
                <textarea value={invoiceFromAddress} onChange={(e) => setInvoiceFromAddress(e.target.value)} rows={4} placeholder="Full sender address shown on invoice PDF" />
              </label>
              <label style={{ display: "grid", gap: 4 }}>
                <span style={{ fontSize: 12, opacity: 0.7 }}>Email</span>
                <input value={invoiceFromEmail} onChange={(e) => setInvoiceFromEmail(e.target.value)} placeholder="optional" />
              </label>
              <label style={{ display: "grid", gap: 4 }}>
                <span style={{ fontSize: 12, opacity: 0.7 }}>Phone</span>
                <input value={invoiceFromPhone} onChange={(e) => setInvoiceFromPhone(e.target.value)} placeholder="optional" />
              </label>
              <label style={{ display: "grid", gap: 4 }}>
                <span style={{ fontSize: 12, opacity: 0.7 }}>GST</span>
                <input value={invoiceFromGstNumber} onChange={(e) => setInvoiceFromGstNumber(e.target.value)} placeholder="optional" />
              </label>
              <label style={{ display: "grid", gap: 4 }}>
                <span style={{ fontSize: 12, opacity: 0.7 }}>PAN</span>
                <input value={invoiceFromPanNumber} onChange={(e) => setInvoiceFromPanNumber(e.target.value)} placeholder="optional" />
              </label>
            </div>
          </div>

          <div style={{ display: "grid", gap: 10 }}>
            <div style={{ fontWeight: 600, fontSize: 13 }}>Bank Details</div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: 10 }}>
              <label style={{ display: "grid", gap: 4, gridColumn: "span 2" }}>
                <span style={{ fontSize: 12, opacity: 0.7 }}>Beneficiary Name</span>
                <input value={bankBeneficiaryName} onChange={(e) => setBankBeneficiaryName(e.target.value)} placeholder="Name shown for payment" />
              </label>
              <label style={{ display: "grid", gap: 4 }}>
                <span style={{ fontSize: 12, opacity: 0.7 }}>Bank Name</span>
                <input value={bankName} onChange={(e) => setBankName(e.target.value)} placeholder="e.g. HDFC Bank" />
              </label>
              <label style={{ display: "grid", gap: 4 }}>
                <span style={{ fontSize: 12, opacity: 0.7 }}>Branch</span>
                <input value={bankBranch} onChange={(e) => setBankBranch(e.target.value)} placeholder="optional" />
              </label>
              <label style={{ display: "grid", gap: 4 }}>
                <span style={{ fontSize: 12, opacity: 0.7 }}>Account Number</span>
                <input value={bankAccountNumber} onChange={(e) => setBankAccountNumber(e.target.value)} placeholder="optional" />
              </label>
              <label style={{ display: "grid", gap: 4 }}>
                <span style={{ fontSize: 12, opacity: 0.7 }}>IFSC Code</span>
                <input value={bankIfscCode} onChange={(e) => setBankIfscCode(e.target.value)} placeholder="optional" />
              </label>
              <label style={{ display: "grid", gap: 4, gridColumn: "span 2" }}>
                <span style={{ fontSize: 12, opacity: 0.7 }}>Account Type</span>
                <input value={bankAccountType} onChange={(e) => setBankAccountType(e.target.value)} placeholder="e.g. Current Account" />
              </label>
            </div>
          </div>
        </div>
      </div>

      {invoiceSource === "MANUAL" && (
        <div className="card" style={{ display: "grid", gap: 10 }}>
          <div style={{ display: "flex", justifyContent: "space-between", gap: 12, flexWrap: "wrap", alignItems: "center" }}>
            <div style={{ fontWeight: 700 }}>Manual Bill To Details</div>
            <div style={{ fontSize: 12, opacity: 0.7 }}>In manual mode, these values can be fully entered and edited.</div>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, minmax(0, 1fr))", gap: 10 }}>
            <label style={{ display: "grid", gap: 4 }}>
              <span style={{ fontSize: 12, opacity: 0.7 }}>Bill To Name *</span>
              <input value={manualBillTo.name} onChange={(e) => updateManualBillTo({ name: e.target.value })} placeholder="Client / company name" />
            </label>
            <label style={{ display: "grid", gap: 4 }}>
              <span style={{ fontSize: 12, opacity: 0.7 }}>Contact Name</span>
              <input value={manualBillTo.contactName} onChange={(e) => updateManualBillTo({ contactName: e.target.value })} placeholder="optional" />
            </label>
            <label style={{ display: "grid", gap: 4 }}>
              <span style={{ fontSize: 12, opacity: 0.7 }}>Advertiser</span>
              <input value={manualBillTo.advertiser} onChange={(e) => updateManualBillTo({ advertiser: e.target.value })} placeholder="optional" />
            </label>

            <label style={{ display: "grid", gap: 4, gridColumn: "span 3" }}>
              <span style={{ fontSize: 12, opacity: 0.7 }}>Billing Address</span>
              <textarea value={manualBillTo.address} onChange={(e) => updateManualBillTo({ address: e.target.value })} rows={4} placeholder="Full bill to address" />
            </label>

            <label style={{ display: "grid", gap: 4 }}>
              <span style={{ fontSize: 12, opacity: 0.7 }}>Email</span>
              <input value={manualBillTo.email} onChange={(e) => updateManualBillTo({ email: e.target.value })} placeholder="optional" />
            </label>
            <label style={{ display: "grid", gap: 4 }}>
              <span style={{ fontSize: 12, opacity: 0.7 }}>Phone</span>
              <input value={manualBillTo.phone} onChange={(e) => updateManualBillTo({ phone: e.target.value })} placeholder="optional" />
            </label>
            <label style={{ display: "grid", gap: 4 }}>
              <span style={{ fontSize: 12, opacity: 0.7 }}>Payment Terms</span>
              <input value={manualBillTo.paymentTerms} onChange={(e) => updateManualBillTo({ paymentTerms: e.target.value })} placeholder="e.g. 7 days" />
            </label>

            <label style={{ display: "grid", gap: 4 }}>
              <span style={{ fontSize: 12, opacity: 0.7 }}>Project No</span>
              <input value={manualBillTo.projectNo} onChange={(e) => updateManualBillTo({ projectNo: e.target.value })} placeholder="optional" />
            </label>
            <label style={{ display: "grid", gap: 4 }}>
              <span style={{ fontSize: 12, opacity: 0.7 }}>Brand</span>
              <input value={manualBillTo.brand} onChange={(e) => updateManualBillTo({ brand: e.target.value })} placeholder="optional" />
            </label>
            <label style={{ display: "grid", gap: 4 }}>
              <span style={{ fontSize: 12, opacity: 0.7 }}>PO Number</span>
              <input value={manualBillTo.poNumber} onChange={(e) => updateManualBillTo({ poNumber: e.target.value })} placeholder="optional" />
            </label>

            <label style={{ display: "grid", gap: 4 }}>
              <span style={{ fontSize: 12, opacity: 0.7 }}>GST Number</span>
              <input value={manualBillTo.gstNumber} onChange={(e) => updateManualBillTo({ gstNumber: e.target.value })} placeholder="optional" />
            </label>
            <label style={{ display: "grid", gap: 4 }}>
              <span style={{ fontSize: 12, opacity: 0.7 }}>PAN Number</span>
              <input value={manualBillTo.panNumber} onChange={(e) => updateManualBillTo({ panNumber: e.target.value })} placeholder="optional" />
            </label>
          </div>
        </div>
      )}

      {selectedProject && (
        <div className="card" style={{ display: "grid", gap: 8, background: "#f8fafc", border: "1px solid rgba(148,163,184,0.25)" }}>
          <div style={{ fontWeight: 700 }}>Selected project</div>
          <div style={{ display: "flex", gap: 12, flexWrap: "wrap", fontSize: 13, opacity: 0.85 }}>
            <span><b>Project:</b> {selectedProject.name}</span>
            {selectedProject.projectCode ? <span><b>Code:</b> {selectedProject.projectCode}</span> : null}
            {selectedProject.projectNumber ? <span><b>Number:</b> {selectedProject.projectNumber}</span> : null}
            <span><b>Billable Party:</b> {matchedBillableParty?.name || "Not selected"}</span>
                        <span><b>Rate Card:</b> {linkedRateCard?.name || "No linked rate card"}</span>
          </div>
          {matchedBillableParty || projectAgencyOptions.length ? (
            <div style={{ display: "grid", gap: 10 }}>
              <div style={{ fontSize: 12, fontWeight: 700, color: "#475569" }}>Billing applies to</div>
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                {projectAgencyOptions.map((item) => {
                  const active = projectBillingAgencyKeys == null ? true : projectBillingAgencyKeys.includes(item.key);
                  return (
                    <button
                      key={`${item.key}-${item.agency.id}`}
                      type="button"
                      onClick={() => toggleProjectBillingAgencyKey(item.key)}
                      style={{
                        display: "inline-flex",
                        alignItems: "center",
                        gap: 6,
                        padding: "8px 12px",
                        borderRadius: 999,
                        border: active ? "1px solid #2563eb" : "1px solid rgba(148,163,184,0.28)",
                        background: active ? "#eff6ff" : "#ffffff",
                        color: active ? "#1d4ed8" : "#334155",
                        fontSize: 12,
                        fontWeight: 700,
                        cursor: "pointer",
                      }}
                    >
                      {item.label}
                    </button>
                  );
                })}
              </div>
              {projectBillToOptions.length ? (
                <div style={{ display: "grid", gap: 8 }}>
                  <div style={{ fontSize: 12, fontWeight: 700, color: "#475569" }}>Fallback bill-to source</div>
                  <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                    {projectBillToOptions.map((item) => {
                      const active = item.key === projectBillingSourceKey;
                      return (
                        <button
                          key={`${item.key}-${item.party.id}`}
                          type="button"
                          onClick={() => changeProjectBillingSourceKey(item.key)}
                          style={{
                            display: "inline-flex",
                            alignItems: "center",
                            gap: 6,
                            padding: "8px 12px",
                            borderRadius: 999,
                            border: active ? "1px solid #0f766e" : "1px solid rgba(148,163,184,0.28)",
                            background: active ? "#ecfeff" : "#ffffff",
                            color: active ? "#0f766e" : "#334155",
                            fontSize: 12,
                            fontWeight: 700,
                            cursor: "pointer",
                          }}
                        >
                          {item.label}
                        </button>
                      );
                    })}
                  </div>
                </div>
              ) : null}
              {matchedBillableParty ? (
                <div style={{ display: "flex", gap: 8, flexWrap: "wrap", fontSize: 12 }}>
                  <span style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "6px 10px", borderRadius: 999, background: "#fff", border: "1px solid rgba(148,163,184,0.24)" }}><b>Name:</b> {matchedBillableParty.name}</span>
                  {matchedBillableParty.address ? <span style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "6px 10px", borderRadius: 999, background: "#fff", border: "1px solid rgba(148,163,184,0.24)" }}><b>Address:</b> {matchedBillableParty.address}</span> : null}
                  {firstEmail(matchedBillableParty.emails) ? <span style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "6px 10px", borderRadius: 999, background: "#fff", border: "1px solid rgba(148,163,184,0.24)" }}><b>Email:</b> {firstEmail(matchedBillableParty.emails)}</span> : null}
                  {matchedBillableParty.contactNo ? <span style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "6px 10px", borderRadius: 999, background: "#fff", border: "1px solid rgba(148,163,184,0.24)" }}><b>Phone:</b> {matchedBillableParty.contactNo}</span> : null}
                  {matchedBillableParty.gstNumber ? <span style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "6px 10px", borderRadius: 999, background: "#fff", border: "1px solid rgba(148,163,184,0.24)" }}><b>GST:</b> {matchedBillableParty.gstNumber}</span> : null}
                  {matchedBillableParty.panNumber ? <span style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "6px 10px", borderRadius: 999, background: "#fff", border: "1px solid rgba(148,163,184,0.24)" }}><b>PAN:</b> {matchedBillableParty.panNumber}</span> : null}
                  {matchedBillableParty.paymentTerms ? <span style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "6px 10px", borderRadius: 999, background: "#fff", border: "1px solid rgba(148,163,184,0.24)" }}><b>Terms:</b> {matchedBillableParty.paymentTerms}</span> : null}
                </div>
              ) : linkedProjectAgencies.length ? (
                <div style={{ display: "flex", gap: 8, flexWrap: "wrap", fontSize: 12 }}>
                  {linkedProjectAgencies.map((item) => (
                    <span
                      key={`${item.label}-${item.agency.id}`}
                      style={{
                        display: "inline-flex",
                        alignItems: "center",
                        gap: 6,
                        padding: "6px 10px",
                        borderRadius: 999,
                        background: "#fff",
                        border: "1px solid rgba(148,163,184,0.24)",
                      }}
                    >
                      <b>{item.label}:</b> {item.agency.name}
                    </span>
                  ))}
                </div>
              ) : (
                <div style={{ fontSize: 12, color: "#64748b" }}>
                  No billable party is linked on this project yet. Select one on the project and billing will reuse it automatically with the linked rate card.
                </div>
              )}
            </div>
          ) : (
            <div style={{ fontSize: 12, color: "#64748b" }}>
              No billable party is linked on this project yet. Billing will still use any directly selected billable party.
            </div>
          )}
        </div>
      )}

      {matchedClientProfile && (
        <div className="card" style={{ display: "grid", gap: 8, background: "#faf8ff", border: "1px solid #eadfff" }}>
          <div style={{ fontWeight: 700 }}>Matched client billing profile</div>
          <div style={{ display: "flex", gap: 12, flexWrap: "wrap", fontSize: 13, opacity: 0.85 }}>
            <span><b>Advertiser:</b> {matchedClientProfile.advertiser}</span>
            <span><b>Billing:</b> {matchedClientProfile.billingName}</span>
            <span><b>Currency:</b> {matchedClientProfile.currency}</span>
            <span><b>GST:</b> {matchedClientProfile.gst}</span>
          </div>
        </div>
      )}

      {invoiceSource === "AUTO" ? (
        <div className="card" style={{ display: "grid", gap: 10 }}>
          <div style={{ fontWeight: 700 }}>Charge Filters</div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(4, minmax(0, 1fr))", gap: 10 }}>
            <label style={{ display: "grid", gap: 4 }}>
              <span style={{ fontSize: 12, opacity: 0.7 }}>Project</span>
              <select value={projectId} onChange={(e) => setProjectId(e.target.value)}>
                <option value="">All projects</option>
                {projects.map((project) => (
                  <option key={project.id} value={project.id}>
                    {project.name}{project.projectCode ? ` • ${project.projectCode}` : project.projectNumber ? ` • ${project.projectNumber}` : ""}
                  </option>
                ))}
              </select>
            </label>
            <label style={{ display: "grid", gap: 4 }}>
              <span style={{ fontSize: 12, opacity: 0.7 }}>From</span>
              <input type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
            </label>

            <label style={{ display: "grid", gap: 4 }}>
              <span style={{ fontSize: 12, opacity: 0.7 }}>To</span>
              <input type="date" value={to} onChange={(e) => setTo(e.target.value)} />
            </label>

            <label style={{ display: "grid", gap: 4 }}>
              <span style={{ fontSize: 12, opacity: 0.7 }}>Action</span>
              <select value={action} onChange={(e) => setAction(e.target.value)}>
                <option value="">All</option>
                <option value="UPLOAD">UPLOAD</option>
                <option value="ENCODE">ENCODE</option>
                <option value="DELIVERY">DELIVERY</option>
                <option value="OTHER">OTHER</option>
              </select>
            </label>

            <label style={{ display: "grid", gap: 4 }}>
              <span style={{ fontSize: 12, opacity: 0.7 }}>Destination</span>
              <select value={destinationId} onChange={(e) => setDestinationId(e.target.value)}>
                <option value="">All</option>
                {destinations.map((d) => (
                  <option key={d.id} value={d.id}>{d.name}</option>
                ))}
              </select>
            </label>

            <label style={{ display: "grid", gap: 4 }}>
              <span style={{ fontSize: 12, opacity: 0.7 }}>Channel</span>
              <select value={channelId} onChange={(e) => setChannelId(e.target.value)}>
                <option value="">All</option>
                {channels.map((c) => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </label>

            <label style={{ display: "grid", gap: 4 }}>
              <span style={{ fontSize: 12, opacity: 0.7 }}>SLA</span>
              <select value={slaId} onChange={(e) => setSlaId(e.target.value)}>
                <option value="">All</option>
                {slas.map((s) => (
                  <option key={s.id} value={s.id}>{s.name}</option>
                ))}
              </select>
            </label>
          </div>

          {loading && <div style={{ fontSize: 12, opacity: 0.7 }}>Loading invoice preview...</div>}
          {err && <div style={{ color: "crimson" }}>{err}</div>}
        </div>
      ) : (
        <div className="card" style={{ display: "grid", gap: 12 }}>
          <div style={{ display: "flex", justifyContent: "space-between", gap: 12, flexWrap: "wrap", alignItems: "center" }}>
            <div>
              <div style={{ fontWeight: 700 }}>Manual Invoice Lines</div>
              <div style={{ fontSize: 12, opacity: 0.7 }}>Create invoice rows directly without depending on billing charge entries.</div>
            </div>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              <button onClick={() => addManualRow()}>Add line</button>
              <button onClick={() => setManualRows([makeManualRow(invoiceDate)])}>Reset lines</button>
            </div>
          </div>

          <div style={{ display: "grid", gap: 10 }}>
            {manualRows.map((row, index) => {
              const rowQty = Math.max(num(row.quantity), 0);
              const rowRate = Math.max(num(row.unitRate), 0);
              const rowSubTotal = rowQty * rowRate;
              const taxPercent = invoiceMode === "INDIA" ? num(row.gstPercent || defaultGstPercent) : num(row.taxSlabPercent || defaultTaxSlabPercent);
              const rowTax = rowSubTotal * (taxPercent / 100);
              return (
                <div key={row.id} style={{ border: "1px solid #ececec", borderRadius: 12, padding: 12, display: "grid", gap: 10, background: "#fff" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
                    <div style={{ fontWeight: 600 }}>Line {index + 1}</div>
                    <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                      <button onClick={() => addManualRow(row.id)}>Duplicate</button>
                      <button onClick={() => removeManualRow(row.id)}>Remove</button>
                    </div>
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "repeat(4, minmax(0, 1fr))", gap: 10 }}>
                    <label style={{ display: "grid", gap: 4 }}>
                      <span style={{ fontSize: 12, opacity: 0.7 }}>Date</span>
                      <input type="date" value={row.date} onChange={(e) => updateManualRow(row.id, { date: e.target.value })} />
                    </label>

                    <label style={{ display: "grid", gap: 4, gridColumn: "span 2" }}>
                      <span style={{ fontSize: 12, opacity: 0.7 }}>Description</span>
                      <input value={row.description} onChange={(e) => updateManualRow(row.id, { description: e.target.value })} placeholder="e.g. Encoding / Uploading" />
                    </label>

                    <label style={{ display: "grid", gap: 4 }}>
                      <span style={{ fontSize: 12, opacity: 0.7 }}>Project</span>
                      <input value={row.project} onChange={(e) => updateManualRow(row.id, { project: e.target.value })} placeholder="optional" />
                    </label>

                    <label style={{ display: "grid", gap: 4 }}>
                      <span style={{ fontSize: 12, opacity: 0.7 }}>Creative</span>
                      <input value={row.creative} onChange={(e) => updateManualRow(row.id, { creative: e.target.value })} placeholder="optional" />
                    </label>

                    <label style={{ display: "grid", gap: 4 }}>
                      <span style={{ fontSize: 12, opacity: 0.7 }}>Destination</span>
                      <input value={row.destination} onChange={(e) => updateManualRow(row.id, { destination: e.target.value })} placeholder="optional" />
                    </label>

                    <label style={{ display: "grid", gap: 4 }}>
                      <span style={{ fontSize: 12, opacity: 0.7 }}>Channel</span>
                      <input value={row.channel} onChange={(e) => updateManualRow(row.id, { channel: e.target.value })} placeholder="optional" />
                    </label>

                    <label style={{ display: "grid", gap: 4 }}>
                      <span style={{ fontSize: 12, opacity: 0.7 }}>SLA</span>
                      <input value={row.sla} onChange={(e) => updateManualRow(row.id, { sla: e.target.value })} placeholder="optional" />
                    </label>

                    <label style={{ display: "grid", gap: 4 }}>
                      <span style={{ fontSize: 12, opacity: 0.7 }}>Action</span>
                      <input value={row.action} onChange={(e) => updateManualRow(row.id, { action: e.target.value })} placeholder="optional" />
                    </label>

                    <label style={{ display: "grid", gap: 4 }}>
                      <span style={{ fontSize: 12, opacity: 0.7 }}>Item Code</span>
                      <input value={row.itemCode} onChange={(e) => updateManualRow(row.id, { itemCode: e.target.value })} placeholder="optional" />
                    </label>

                    <label style={{ display: "grid", gap: 4 }}>
                      <span style={{ fontSize: 12, opacity: 0.7 }}>HSN / SAC</span>
                      <input value={row.hsnSacCode} onChange={(e) => updateManualRow(row.id, { hsnSacCode: e.target.value })} placeholder="optional" />
                    </label>

                    <label style={{ display: "grid", gap: 4 }}>
                      <span style={{ fontSize: 12, opacity: 0.7 }}>Quantity</span>
                      <input type="number" min="0" step="0.01" value={row.quantity} onChange={(e) => updateManualRow(row.id, { quantity: e.target.value })} />
                    </label>

                    <label style={{ display: "grid", gap: 4 }}>
                      <span style={{ fontSize: 12, opacity: 0.7 }}>Unit</span>
                      <input value={row.unit} onChange={(e) => updateManualRow(row.id, { unit: e.target.value })} placeholder="each" />
                    </label>

                    <label style={{ display: "grid", gap: 4 }}>
                      <span style={{ fontSize: 12, opacity: 0.7 }}>Unit Rate</span>
                      <input type="number" min="0" step="0.01" value={row.unitRate} onChange={(e) => updateManualRow(row.id, { unitRate: e.target.value })} />
                    </label>

                    <label style={{ display: "grid", gap: 4 }}>
                      <span style={{ fontSize: 12, opacity: 0.7 }}>Currency</span>
                      <input value={row.currency} onChange={(e) => updateManualRow(row.id, { currency: e.target.value.toUpperCase() })} placeholder="EUR" />
                    </label>

                    {invoiceMode === "INDIA" ? (
                      <label style={{ display: "grid", gap: 4 }}>
                        <span style={{ fontSize: 12, opacity: 0.7 }}>GST %</span>
                        <input type="number" min="0" step="0.01" value={row.gstPercent} onChange={(e) => updateManualRow(row.id, { gstPercent: e.target.value })} placeholder={defaultGstPercent || "18"} />
                      </label>
                    ) : (
                      <label style={{ display: "grid", gap: 4 }}>
                        <span style={{ fontSize: 12, opacity: 0.7 }}>Tax Slab %</span>
                        <input type="number" min="0" step="0.01" value={row.taxSlabPercent} onChange={(e) => updateManualRow(row.id, { taxSlabPercent: e.target.value })} placeholder={defaultTaxSlabPercent || "0"} />
                      </label>
                    )}
                  </div>

                  <div style={{ display: "flex", gap: 16, flexWrap: "wrap", fontSize: 12, opacity: 0.8 }}>
                    <span><b>Sub Total:</b> {fmtMoney(rowSubTotal)}</span>
                    <span><b>Tax:</b> {fmtMoney(rowTax)}</span>
                    <span><b>Estimated Grand Total:</b> {fmtMoney(rowSubTotal + rowTax)}</span>
                  </div>
                </div>
              );
            })}
          </div>

          {loading && <div style={{ fontSize: 12, opacity: 0.7 }}>Loading invoice preview...</div>}
          {err && <div style={{ color: "crimson" }}>{err}</div>}
        </div>
      )}

      {preview && (
        <>
          <div className="card" style={{ display: "grid", gap: 8 }}>
            <div style={{ display: "flex", justifyContent: "space-between", gap: 12, flexWrap: "wrap" }}>
              <div>
                <div style={{ fontWeight: 700 }}>{preview.invoiceNumber}</div>
                <div style={{ fontSize: 13, opacity: 0.8 }}>Mode: {preview.invoiceMode}{preview.invoiceMode === "INDIA" ? ` • ${preview.indiaTaxType}` : ""}</div>
                <div style={{ fontSize: 13, opacity: 0.8 }}>Rows: {preview.rowCount}</div>
              </div>
              <div style={{ textAlign: "right" }}>
                <div>Invoice Date: <b>{preview.invoiceDate}</b></div>
                <div>Due Date: <b>{preview.dueDate}</b></div>
              </div>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              <div>
                <div style={{ fontWeight: 600 }}>{preview.billableParty?.name || "Billable Party"}</div>
                {preview.billableParty?.contactName && <div>Contact: {preview.billableParty.contactName}</div>}
                {preview.billableParty?.advertiser && <div>Advertiser: {preview.billableParty.advertiser}</div>}
                {preview.billableParty?.projectNo && <div>Project No: {preview.billableParty.projectNo}</div>}
                {preview.billableParty?.brand && <div>Brand: {preview.billableParty.brand}</div>}
                {preview.billableParty?.poNumber && <div>PO Number: {preview.billableParty.poNumber}</div>}
                {preview.billableParty?.address && <div style={{ whiteSpace: "pre-wrap" }}>{preview.billableParty.address}</div>}
                {preview.billableParty?.email && <div>Email: {preview.billableParty.email}</div>}
                {preview.billableParty?.phone && <div>Phone: {preview.billableParty.phone}</div>}
                {preview.billableParty?.gstNumber && <div>GST: {preview.billableParty.gstNumber}</div>}
                {preview.billableParty?.panNumber && <div>PAN: {preview.billableParty.panNumber}</div>}
              </div>
              <div style={{ textAlign: "right" }}>
                {preview.billableParty?.paymentTerms && <div>Payment Terms: {preview.billableParty.paymentTerms}</div>}
                {preview.notes && <div>Notes: {preview.notes}</div>}
              </div>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
              <div>
                <div style={{ fontWeight: 600 }}>Invoice From</div>
                {preview.invoiceFrom?.name && <div>{preview.invoiceFrom.name}</div>}
                {preview.invoiceFrom?.address && <div style={{ whiteSpace: "pre-wrap" }}>{preview.invoiceFrom.address}</div>}
                {preview.invoiceFrom?.email && <div>Email: {preview.invoiceFrom.email}</div>}
                {preview.invoiceFrom?.phone && <div>Phone: {preview.invoiceFrom.phone}</div>}
                {preview.invoiceFrom?.gstNumber && <div>GST: {preview.invoiceFrom.gstNumber}</div>}
                {preview.invoiceFrom?.panNumber && <div>PAN: {preview.invoiceFrom.panNumber}</div>}
              </div>
              <div style={{ textAlign: "right" }}>
                <div style={{ fontWeight: 600 }}>Bank Details</div>
                {preview.bankDetails?.beneficiaryName && <div>Beneficiary: {preview.bankDetails.beneficiaryName}</div>}
                {preview.bankDetails?.bankName && <div>Bank: {preview.bankDetails.bankName}</div>}
                {preview.bankDetails?.bankBranch && <div>Branch: {preview.bankDetails.bankBranch}</div>}
                {preview.bankDetails?.accountNumber && <div>Account No: {preview.bankDetails.accountNumber}</div>}
                {preview.bankDetails?.ifscCode && <div>IFSC: {preview.bankDetails.ifscCode}</div>}
                {preview.bankDetails?.accountType && <div>Type: {preview.bankDetails.accountType}</div>}
              </div>
            </div>

            {!!preview.warnings?.length && (
              <div style={{ display: "grid", gap: 6, padding: 10, borderRadius: 10, background: "#fff7e6", border: "1px solid #f3d19c" }}>
                {preview.warnings.map((warning, idx) => (
                  <div key={`${warning}-${idx}`} style={{ fontSize: 13, color: "#8a5a00" }}>{warning}</div>
                ))}
              </div>
            )}
          </div>

          <div className="card" style={{ overflowX: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead>
                <tr>
                  {[
                    "Date",
                    "Description",
                    "Project",
                    "Qty",
                    "Unit Rate",
                    "Line Total",
                    "Tax",
                    "Grand Total",
                    "Currency",
                  ].map((h) => (
                    <th key={h} style={{ textAlign: "left", padding: 8, borderBottom: "1px solid #eee", whiteSpace: "nowrap" }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {preview.rows.map((r) => (
                  <tr key={r.id}>
                    <td style={{ padding: 8, borderBottom: "1px solid #f2f2f2", whiteSpace: "nowrap" }}>{new Date(r.date).toISOString().slice(0, 10)}</td>
                    <td style={{ padding: 8, borderBottom: "1px solid #f2f2f2" }}>
                      <div>{r.description}</div>
                      <div style={{ fontSize: 12, opacity: 0.7 }}>{r.itemCode || ""}{r.hsnSacCode ? ` • ${r.hsnSacCode}` : ""}</div>
                    </td>
                    <td style={{ padding: 8, borderBottom: "1px solid #f2f2f2" }}>{r.project}</td>
                    <td style={{ padding: 8, borderBottom: "1px solid #f2f2f2" }}>{r.quantity}</td>
                    <td style={{ padding: 8, borderBottom: "1px solid #f2f2f2" }}>{fmtMoney(r.unitRate)}</td>
                    <td style={{ padding: 8, borderBottom: "1px solid #f2f2f2" }}>{fmtMoney(r.lineTotal)}</td>
                    <td style={{ padding: 8, borderBottom: "1px solid #f2f2f2" }}>
                      {fmtMoney(r.taxAmount)}
                      <div style={{ fontSize: 12, opacity: 0.7 }}>
                        {preview.invoiceMode === "INDIA"
                          ? `CGST ${fmtMoney(r.cgstAmount)} • SGST ${fmtMoney(r.sgstAmount)} • IGST ${fmtMoney(r.igstAmount)}`
                          : `Slab ${r.taxSlabPercent || 0}%`}
                      </div>
                    </td>
                    <td style={{ padding: 8, borderBottom: "1px solid #f2f2f2" }}>{fmtMoney(r.totalWithTax)}</td>
                    <td style={{ padding: 8, borderBottom: "1px solid #f2f2f2" }}>{r.currency}</td>
                  </tr>
                ))}
                {!preview.rows.length && (
                  <tr>
                    <td colSpan={9} style={{ padding: 16, opacity: 0.7 }}>
                      {invoiceSource === "MANUAL"
                        ? "No manual invoice rows were included in the preview."
                        : "No billable charge rows matched the selected filters."}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          <div className="card" style={{ overflowX: "auto" }}>
            <div style={{ fontWeight: 700, marginBottom: 8 }}>Totals</div>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead>
                <tr>
                  {[
                    "Currency",
                    "Sub Total",
                    "Tax Total",
                    "CGST",
                    "SGST",
                    "IGST",
                    "Grand Total",
                  ].map((h) => (
                    <th key={h} style={{ textAlign: "left", padding: 8, borderBottom: "1px solid #eee" }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {preview.totals.map((t) => (
                  <tr key={t.currency}>
                    <td style={{ padding: 8, borderBottom: "1px solid #f2f2f2" }}>{t.currency}</td>
                    <td style={{ padding: 8, borderBottom: "1px solid #f2f2f2" }}>{fmtMoney(t.subTotal)}</td>
                    <td style={{ padding: 8, borderBottom: "1px solid #f2f2f2" }}>{fmtMoney(t.taxTotal)}</td>
                    <td style={{ padding: 8, borderBottom: "1px solid #f2f2f2" }}>{fmtMoney(t.cgstTotal)}</td>
                    <td style={{ padding: 8, borderBottom: "1px solid #f2f2f2" }}>{fmtMoney(t.sgstTotal)}</td>
                    <td style={{ padding: 8, borderBottom: "1px solid #f2f2f2" }}>{fmtMoney(t.igstTotal)}</td>
                    <td style={{ padding: 8, borderBottom: "1px solid #f2f2f2", fontWeight: 700 }}>{fmtMoney(t.grandTotal)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}
    </div>
  );
}
