import { useEffect, useState } from "react";
import { HomeRefreshBar } from "../../ui/HomeRefreshBar";
import { Link, useParams } from "react-router-dom";
import {
  getBulkBatch,
  createBulkItems,
  importBulkExcel,
  type BulkBatchWithItems,
} from "./bulkApi";
import { type ApiError } from "../../lib/api";
import { BulkItemsGrid } from "./BulkItemsGrid";

export function BulkBatchDetailPage() {
  const { id = "" } = useParams();

  const [batch, setBatch] = useState<BulkBatchWithItems | null>(null);
  const [loading, setLoading] = useState(false);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  const [jsonText, setJsonText] = useState(
    `[\n  { "valid": "ABC123", "caption": "My Creative", "format": "HD", "languages": ["EN"], "duration": "00:00:30:00", "remarks": "note" }\n]`,
  );

  async function load() {
    setLoading(true);
    setErr("");
    try {
      const b = await getBulkBatch(id);
      setBatch(b);
    } catch (e: any) {
      const ae = e as ApiError;
      setErr(ae?.message || "Failed to load batch");
      setBatch(null);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (id) load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  async function addItemsFromJson() {
    if (!batch) return;
    setBusy(true);
    setErr("");
    try {
      const parsed = JSON.parse(jsonText);
      if (!Array.isArray(parsed)) throw new Error("JSON must be an array");
      await createBulkItems(batch.id, parsed);
      await load();
    } catch (e: any) {
      setErr(e?.message || "Add items failed");
    } finally {
      setBusy(false);
    }
  }

  async function onExcelFile(file: File) {
    if (!batch) return;
    setBusy(true);
    setErr("");
    try {
      await importBulkExcel(batch.id, file);
      await load();
    } catch (e: any) {
      setErr(e?.message || "Excel import failed");
    } finally {
      setBusy(false);
    }
  }

  if (!id) return <div className="card">Missing batch id</div>;

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <HomeRefreshBar title="Bulk Batch" onRefresh={load} />
      <div className="card" style={{ display: "grid", gap: 8 }}>
        <div className="row" style={{ justifyContent: "space-between", alignItems: "center" }}>
          <div>
            <div style={{ fontSize: 12, opacity: 0.7 }}>
              <Link to="/bulk">← Back</Link>
            </div>
            <h3 style={{ margin: 0 }}>{batch?.name || "Bulk Batch"}</h3>
            <div style={{ fontSize: 12, opacity: 0.75 }}>
              Billing: <b>{batch?.billingMode || "—"}</b>
            </div>
          </div>

          <div className="row" style={{ gap: 8 }}>
            <button onClick={load} disabled={busy || loading}>
              {loading ? "Loading..." : "Refresh"}
            </button>
          </div>
        </div>

        {err ? (
          <div className="card" style={{ borderColor: "#f5a", background: "#fff5fa" }}>
            {err}
          </div>
        ) : null}

        <div style={{ display: "grid", gap: 10 }}>
          <div style={{ fontWeight: 800 }}>Import items (Excel)</div>
          <input
            type="file"
            accept=".xlsx"
            disabled={busy || !batch}
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) onExcelFile(f);
            }}
          />
          <div style={{ fontSize: 12, opacity: 0.7 }}>
            Expected headers (case-insensitive): valid, caption, format, languages, duration, remarks
          </div>
        </div>

        <hr />

        <div style={{ display: "grid", gap: 8 }}>
          <div style={{ fontWeight: 800 }}>Add items (JSON)</div>
          <textarea
            value={jsonText}
            onChange={(e) => setJsonText(e.target.value)}
            rows={6}
            style={{ width: "100%", fontFamily: "monospace" }}
          />
          <div className="row" style={{ gap: 8 }}>
            <button onClick={addItemsFromJson} disabled={busy || !batch}>
              {busy ? "Working..." : "Add items"}
            </button>
            <div style={{ fontSize: 12, opacity: 0.7 }}>
              Tip: paste an array of items (valid/caption/format/languages/duration/remarks)
            </div>
          </div>
        </div>
      </div>

      <BulkItemsGrid batch={batch} onReload={load} />
    </div>
  );
}
