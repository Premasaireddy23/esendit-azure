import { api, apiUrl } from "../../lib/api";

export type BulkBatch = {
  id: string;
  name: string;
  billingMode: "BILLED" | "UNBILLED";
  createdAt?: string;
};

export type BulkItem = {
  id: string;
  valid?: string | null;
  caption?: string | null;
  format?: string | null;
  languages?: string[];
  duration?: string | null;
  remarks?: string | null;
  createdAt?: string;
};

export type BulkBatchWithItems = BulkBatch & { items: BulkItem[] };

export async function listBulkBatches() {
  return api<BulkBatch[]>("/bulk/batches");
}

export async function createBulkBatch(input: { name: string; billingMode?: "BILLED" | "UNBILLED" }) {
  return api<BulkBatch>("/bulk/batches", { method: "POST", body: JSON.stringify(input) });
}

export async function getBulkBatch(id: string) {
  return api<BulkBatchWithItems>(`/bulk/batches/${id}`);
}

export async function createBulkItems(batchId: string, items: any[]) {
  return api(`/bulk/batches/${batchId}/items`, { method: "POST", body: JSON.stringify({ items }) });
}

export async function importBulkExcel(batchId: string, file: File) {
  const fd = new FormData();
  fd.append("file", file);
  return api<BulkBatchWithItems>(`/bulk/batches/${batchId}/import-excel`, { method: "POST", body: fd });
}

export async function uploadBulkSource(itemId: string, file: File) {
  const fd = new FormData();
  fd.append("file", file);
  return api(`/bulk/items/${itemId}/assets/source`, { method: "POST", body: fd });
}

export async function startBulkAutoQc(itemId: string, force = false) {
  return api(`/bulk/items/${itemId}/auto-qc`, { method: "POST", body: JSON.stringify({ force }) });
}

export async function startBulkProxy(itemId: string, force = false) {
  return api(`/bulk/items/${itemId}/proxy`, { method: "POST", body: JSON.stringify({ force }) });
}

export async function listBulkJobs(itemId: string) {
  return api<any[]>(`/bulk/items/${itemId}/jobs`);
}

export function bulkStreamUrl(itemId: string, type: "SOURCE" | "PROXY" | "OUTPUT") {
  return apiUrl(`/bulk/items/${itemId}/assets/${type}/stream`);
}
