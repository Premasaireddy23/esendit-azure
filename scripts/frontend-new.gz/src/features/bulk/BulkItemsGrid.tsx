import { useEffect, useState } from "react";
import type { BulkBatchWithItems, BulkItem } from "./bulkApi";
import { getCreativeCodeLabel, getMe, hasPerm, type MeResponse } from "../../lib/me";
import { bulkStreamUrl, listBulkJobs, startBulkAutoQc, startBulkProxy, uploadBulkSource } from "./bulkApi";

export function BulkItemsGrid({ batch, onReload }: { batch: BulkBatchWithItems | null; onReload: () => Promise<void> }) {
  const [busyId, setBusyId] = useState<string | null>(null);
  const [jobsById, setJobsById] = useState<Record<string, any[]>>({});
  const [me, setMe] = useState<MeResponse | null>(null);
  const items = batch?.items || [];
  const canDownloadMedia = hasPerm(me, "action:media:download");

  useEffect(() => {
    getMe().then(setMe).catch(() => setMe(null));
  }, []);

  async function upload(item: BulkItem, file: File) {
    setBusyId(item.id);
    try {
      await uploadBulkSource(item.id, file);
      await onReload();
    } finally {
      setBusyId(null);
    }
  }

  async function autoQc(item: BulkItem) {
    setBusyId(item.id);
    try {
      await startBulkAutoQc(item.id, false);
      await onReload();
    } finally {
      setBusyId(null);
    }
  }

  async function proxy(item: BulkItem) {
    setBusyId(item.id);
    try {
      await startBulkProxy(item.id, false);
      await onReload();
    } finally {
      setBusyId(null);
    }
  }

  async function loadJobs(item: BulkItem) {
    setBusyId(item.id);
    try {
      const j = await listBulkJobs(item.id);
      setJobsById((p) => ({ ...p, [item.id]: j }));
    } finally {
      setBusyId(null);
    }
  }

  return (
    <div className="card" style={{ padding: 0, overflowX: "auto" }}>
      <table style={{ width: "100%", borderCollapse: "collapse" }}>
        <thead>
          <tr>
            <th style={{ textAlign: "left", padding: 10 }}>{getCreativeCodeLabel(me)}</th>
            <th style={{ textAlign: "left", padding: 10 }}>Caption</th>
            <th style={{ textAlign: "left", padding: 10 }}>Format</th>
            <th style={{ textAlign: "left", padding: 10 }}>Languages</th>
            <th style={{ textAlign: "left", padding: 10 }}>Duration</th>
            <th style={{ textAlign: "left", padding: 10, width: 280 }}>Upload</th>
            <th style={{ textAlign: "left", padding: 10, width: 320 }}>Actions</th>
          </tr>
        </thead>
        <tbody>
          {items.map((it) => {
            const busy = busyId === it.id;
            const jobs = jobsById[it.id];

            return (
              <tr key={it.id} style={{ borderTop: "1px solid #eee", verticalAlign: "top" }}>
                <td style={{ padding: 10, fontWeight: 800 }}>{it.valid || "—"}</td>
                <td style={{ padding: 10 }}>{it.caption || "—"}</td>
                <td style={{ padding: 10 }}>{it.format || "—"}</td>
                <td style={{ padding: 10 }}>{(it.languages || []).join(", ") || "—"}</td>
                <td style={{ padding: 10 }}>{it.duration || "—"}</td>

                <td style={{ padding: 10 }}>
                  <input
                    type="file"
                    onChange={(e) => {
                      const f = e.target.files?.[0];
                      if (f) upload(it, f);
                    }}
                    disabled={busy}
                  />
                  <div style={{ fontSize: 12, opacity: 0.7, marginTop: 6 }}>
                    {canDownloadMedia ? (
                      <>
                        <a href={bulkStreamUrl(it.id, "SOURCE")} target="_blank" rel="noreferrer">
                          Stream SOURCE
                        </a>{" "}
                        |{" "}
                        <a href={bulkStreamUrl(it.id, "PROXY")} target="_blank" rel="noreferrer">
                          Stream PROXY
                        </a>
                      </>
                    ) : (
                      <>
                        <span style={{ opacity: 0.55 }}>Stream SOURCE</span>{" "}
                        |{" "}
                        <span style={{ opacity: 0.55 }}>Stream PROXY</span>
                      </>
                    )}
                  </div>
                </td>

                <td style={{ padding: 10 }}>
                  <div className="row" style={{ gap: 8, flexWrap: "wrap" }}>
                    <button onClick={() => autoQc(it)} disabled={busy}>Auto QC</button>
                    <button onClick={() => proxy(it)} disabled={busy}>Proxy</button>
                    <button onClick={() => loadJobs(it)} disabled={busy}>Jobs</button>
                  </div>

                  {Array.isArray(jobs) && (
                    <div style={{ marginTop: 8, fontSize: 12, opacity: 0.8 }}>
                      <div style={{ fontWeight: 800 }}>Jobs</div>
                      <pre style={{ whiteSpace: "pre-wrap" }}>{JSON.stringify(jobs, null, 2)}</pre>
                    </div>
                  )}
                </td>
              </tr>
            );
          })}

          {items.length === 0 && (
            <tr>
              <td colSpan={7} style={{ padding: 10, opacity: 0.7 }}>
                No items yet
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
