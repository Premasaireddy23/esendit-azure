import { useEffect, useState } from "react";
import { HomeRefreshBar } from "../../ui/HomeRefreshBar";
import { Link } from "react-router-dom";
import { createBulkBatch, listBulkBatches, type BulkBatch } from "./bulkApi";
import type { ApiError } from "../../lib/api";

export function BulkBatchesPage() {
  const [rows, setRows] = useState<BulkBatch[]>([]);
  const [loading, setLoading] = useState(false);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  const [name, setName] = useState("New Batch");
  const [billingMode, setBillingMode] = useState<"BILLED" | "UNBILLED">("UNBILLED");

  async function load() {
    setLoading(true);
    setErr("");
    try {
      setRows(await listBulkBatches());
    } catch (e: any) {
      const ae = e as ApiError;
      setErr(ae?.message || "Failed to load");
      setRows([]);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  async function create() {
    setBusy(true);
    setErr("");
    try {
      await createBulkBatch({ name, billingMode });
      await load();
    } catch (e: any) {
      setErr(e?.message || "Create failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <HomeRefreshBar title="Bulk Upload" onRefresh={load} />
      <div className="card" style={{ display: "grid", gap: 10 }}>
        <h3 style={{ margin: 0 }}>Bulk Upload</h3>

        {err && <div className="card" style={{ borderColor: "#f5a", background: "#fff5fa" }}>{err}</div>}

        <div className="row" style={{ gap: 10, alignItems: "center" }}>
          <input value={name} onChange={(e) => setName(e.target.value)} style={{ width: 320 }} />
          <select value={billingMode} onChange={(e) => setBillingMode(e.target.value as any)}>
            <option value="UNBILLED">UNBILLED</option>
            <option value="BILLED">BILLED</option>
          </select>

          <button onClick={create} disabled={busy}>
            {busy ? "Working..." : "Create batch"}
          </button>

          <button onClick={load} disabled={loading || busy}>
            {loading ? "Loading..." : "Refresh"}
          </button>
        </div>
      </div>

      <div className="card" style={{ padding: 0, overflowX: "auto" }}>
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr>
              <th style={{ textAlign: "left", padding: 10 }}>Name</th>
              <th style={{ textAlign: "left", padding: 10 }}>Billing</th>
              <th style={{ textAlign: "left", padding: 10 }}>Open</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((b) => (
              <tr key={b.id} style={{ borderTop: "1px solid #eee" }}>
                <td style={{ padding: 10, fontWeight: 800 }}>{b.name}</td>
                <td style={{ padding: 10 }}>{b.billingMode}</td>
                <td style={{ padding: 10 }}>
                  <Link to={`/bulk/batches/${b.id}`}>Open</Link>
                </td>
              </tr>
            ))}
            {rows.length === 0 && (
              <tr>
                <td colSpan={3} style={{ padding: 10, opacity: 0.7 }}>
                  {loading ? "Loading..." : "No batches yet"}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
