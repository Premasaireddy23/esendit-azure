export type PermissionRow = {
  id: string;
  key: string;
  type: string; // DB enum: PAGE | ACTION
  name?: string | null;
};

function titleCase(s: string) {
  return s
    .split(/\s+/g)
    .filter(Boolean)
    .map((w) => w[0].toUpperCase() + w.slice(1))
    .join(" ");
}

export function prettyNameFromKey(key: string) {
  // Prefer DB-seeded names when present, but we still need a fallback.
  const k = key.trim();
  if (!k) return "(empty)";
  const lower = k.toLowerCase();

  if (lower === "page:library" || lower === "page:dam") return "DAM / Page";
  if (lower === "action:library:read" || lower === "action:dam:read") return "DAM / Read";
  if (lower === "action:library:index" || lower === "action:dam:index") return "DAM / Index";
  if (lower === "action:library:stream" || lower === "action:dam:stream") return "DAM / Stream";

  // action:module:resource:verb -> "Module / Resource / Verb"
  if (k.includes(":")) {
    const parts = k.split(":").filter(Boolean);
    return parts.map((p) => titleCase(p.replace(/[_\-.]/g, " "))).join(" / ");
  }

  // approvals.decide -> "Approvals / Decide"
  if (k.includes(".")) {
    const parts = k.split(".").filter(Boolean);
    return parts.map((p) => titleCase(p.replace(/[_\-.]/g, " "))).join(" / ");
  }

  // ADMIN_ROLES_READ -> "Admin Roles Read"
  return titleCase(k.replace(/[_\-.]/g, " "));
}

export function permissionDisplayName(p: PermissionRow) {
  const seeded = (p.name ?? "").trim();
  const lowerKey = (p.key ?? "").trim().toLowerCase();
  if (lowerKey.startsWith("page:library") || lowerKey.startsWith("action:library:") || lowerKey.startsWith("page:dam") || lowerKey.startsWith("action:dam:")) {
    if (seeded) return seeded.replace(/\bLibrary\b/g, "DAM");
    return prettyNameFromKey(p.key);
  }
  return seeded || prettyNameFromKey(p.key);
}

export function isLegacyOrInvalidKey(key: string) {
  const k = (key ?? "").trim();
  if (!k) return true;
  if (k === "..." || k === "..") return true;
  // Avoid single-letter junk keys like "A" (seen in the screenshot).
  if (k.length < 3) return true;
  // Allow common separators used in this repo.
  return !/^[A-Za-z0-9][A-Za-z0-9:_\-.]+$/.test(k);
}

export type PermGroup = {
  key: string;
  title: string;
  items: PermissionRow[];
};

const GROUP_TITLE: Record<string, string> = {
  masters: "Masters",
  projects: "Projects",
  stakeholder: "Project Stakeholder Matrix",
  planner: "Planner",
  approvals: "Approvals",
  orders: "Orders & Send",
  library: "DAM",
  presets: "Transcode Presets",
  bulk: "Bulk",
  notifications: "Notifications",
  billing: "Billing",
  admin: "Admin",
  server: "Server Status",
  account: "Account Settings",
  legacy: "Legacy / Unknown",
};

export function inferGroupKey(p: PermissionRow): string {
  const key = (p.key ?? "").trim();
  const lower = key.toLowerCase();

  if (isLegacyOrInvalidKey(key)) return "legacy";

  // action:bulk:create , page:library , page:dam
  if (lower.startsWith("action:") || lower.startsWith("page:")) {
    const parts = lower.split(":");
    const group = parts[1] || "legacy";
    if (group === "dam") return "library";
    return group;
  }

  // Legacy Planner key
  if (key === "Page_Planner" || lower === "page_planner") return "planner";

  // approvals.decide
  if (lower.startsWith("approvals.")) return "approvals";

  // ADMIN_USERS_READ -> admin
  const token = key.split(/[_\-.]/g)[0]?.toLowerCase();
  switch (token) {
    case "masters":
      return "masters";
    case "project":
    case "projects":
    case "commit":
      return "projects";
    case "planner":
      return "planner";
    case "approvals":
    case "approval":
      return "approvals";
    case "order":
    case "orders":
      return "orders";
    case "dam":
    case "library":
      return "library";
    case "preset":
    case "presets":
      return "presets";
    case "bulk":
      return "bulk";
    case "notifications":
      return "notifications";
    case "billing":
      return "billing";
    case "admin":
      return "admin";
    case "server":
      return "server";
    case "account":
      return "account";
    default:
      break;
  }

  return "legacy";
}

export function groupPermissions(perms: PermissionRow[], opts?: { includeLegacy?: boolean; query?: string }) {
  const query = (opts?.query ?? "").trim().toLowerCase();
  const includeLegacy = opts?.includeLegacy ?? false;

  const filtered = perms.filter((p) => {
    const isLegacy = inferGroupKey(p) === "legacy";
    if (!includeLegacy && isLegacy) return false;
    if (!query) return true;
    const hay = `${p.key} ${(p.name ?? "")} ${prettyNameFromKey(p.key)}`.toLowerCase();
    return hay.includes(query);
  });

  const map = new Map<string, PermissionRow[]>();
  for (const p of filtered) {
    const g = inferGroupKey(p);
    const arr = map.get(g) ?? [];
    arr.push(p);
    map.set(g, arr);
  }

  // Stable group ordering.
  const order = [
    "projects",
    "stakeholder",
    "planner",
    "approvals",
    "orders",
    "masters",
    "library",
    "presets",
    "bulk",
    "notifications",
    "billing",
    "account",
    "admin",
    "server",
    "legacy",
  ];

  const groups: PermGroup[] = [];
  for (const k of order) {
    const items = map.get(k);
    if (!items || !items.length) continue;
    items.sort((a, b) => (a.key || "").localeCompare(b.key || ""));
    groups.push({
      key: k,
      title: GROUP_TITLE[k] ?? titleCase(k),
      items,
    });
  }
  return groups;
}

export function isReadLikeKey(key: string) {
  const k = key.toLowerCase();
  return (
    k.endsWith("_read") ||
    k.endsWith(":read") ||
    k.endsWith(":index") ||
    k.endsWith(":stream") ||
    k.includes("read") ||
    k.includes("view")
  );
}
