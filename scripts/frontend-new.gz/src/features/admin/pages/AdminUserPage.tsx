import { useEffect, useMemo, useState } from "react";
import { getMe, hasPerm } from "../../../lib/me";
import { startSupportSessionToken } from "../../../lib/api";
import {
  createUser,
  createSupportSession,
  deleteUser,
  listRoles,
  listUsers,
  resetUserPassword,
  setUserRoles,
  setUserStatus,
  syncUsersFromAccounts,
} from "../adminApi";
import { AdminPageState } from "../AdminPageState";
import { AppModal } from "../../../ui/AppModal";

export function AdminUsersPage() {
  const [pageState, setPageState] = useState<"loading" | "ready" | "denied" | "error">("loading");
  const [pageError, setPageError] = useState<any>(null);
  const [canWrite, setCanWrite] = useState(false);
  const [canSupportView, setCanSupportView] = useState(false);
  const [currentUserId, setCurrentUserId] = useState("");

  const [users, setUsers] = useState<any[]>([]);
  const [roles, setRoles] = useState<any[]>([]);
  const [q, setQ] = useState("");
  const [statusMsg, setStatusMsg] = useState("");

  const [editingUserId, setEditingUserId] = useState<string>("");
  const [checkedRoles, setCheckedRoles] = useState<Record<string, boolean>>({});

  const [passwordUserId, setPasswordUserId] = useState<string>("");
  const [passwordValue, setPasswordValue] = useState("");
  const [controlsUserId, setControlsUserId] = useState<string>("");
  const [supportUserId, setSupportUserId] = useState<string>("");
  const [supportReason, setSupportReason] = useState("");
  const [supportTicket, setSupportTicket] = useState("");
  const [supportStarting, setSupportStarting] = useState(false);

  const [newEmail, setNewEmail] = useState("");
  const [newDisplayName, setNewDisplayName] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [newRoleIds, setNewRoleIds] = useState<Record<string, boolean>>({});
  const [showCreatePersonSection, setShowCreatePersonSection] = useState(false);
  const [showPeopleListSection, setShowPeopleListSection] = useState(true);
  const [syncingFromAccounts, setSyncingFromAccounts] = useState(false);

  const selectedNewRoleIds = useMemo(
    () => Object.entries(newRoleIds).filter(([, v]) => v).map(([id]) => id),
    [newRoleIds]
  );

  const editingUser = useMemo(() => users.find((x) => x.id === editingUserId) || null, [users, editingUserId]);
  const controlsUser = useMemo(() => users.find((x) => x.id === controlsUserId) || null, [users, controlsUserId]);
  const supportUser = useMemo(() => users.find((x) => x.id === supportUserId) || null, [users, supportUserId]);

  const filteredUsers = useMemo(() => {
    const needle = q.trim().toLowerCase();
    if (!needle) return users;
    return users.filter((u) => {
      const roleNames = (u.roles ?? []).map((x: any) => x.role?.name || "").join(" ").toLowerCase();
      return `${u.email} ${u.displayName ?? ""} ${roleNames}`.toLowerCase().includes(needle);
    });
  }, [users, q]);

  function getPersonLabel(user: any) {
    return user.displayName || user.email;
  }

  function getInitials(label: string) {
    const cleaned = label.replace(/@.*$/, "").trim();
    const parts = cleaned.split(/\s+/).filter(Boolean);
    if (parts.length >= 2) return `${parts[0][0] || ""}${parts[1][0] || ""}`.toUpperCase();
    return cleaned.slice(0, 2).toUpperCase() || "PE";
  }

  function getAvatarTone(seed: string) {
    const tones = [
      { background: "linear-gradient(135deg, #dbeafe 0%, #93c5fd 100%)", color: "#1d4ed8" },
      { background: "linear-gradient(135deg, #ede9fe 0%, #c4b5fd 100%)", color: "#6d28d9" },
      { background: "linear-gradient(135deg, #dcfce7 0%, #86efac 100%)", color: "#15803d" },
      { background: "linear-gradient(135deg, #fee2e2 0%, #fca5a5 100%)", color: "#b91c1c" },
      { background: "linear-gradient(135deg, #fae8ff 0%, #f0abfc 100%)", color: "#a21caf" },
      { background: "linear-gradient(135deg, #cffafe 0%, #67e8f9 100%)", color: "#0f766e" },
    ];
    let total = 0;
    for (let i = 0; i < seed.length; i += 1) total += seed.charCodeAt(i);
    return tones[total % tones.length];
  }

  function flash(message: string) {
    setStatusMsg(message);
    setTimeout(() => setStatusMsg(""), 2200);
  }

  function getErrorMessage(error: any) {
    return error?.message || error?.error || error?.response?.data?.message || "Something went wrong";
  }

  async function refresh() {
    setPageError(null);
    const me = await getMe(true);
    const readOk = hasPerm(me, "ADMIN_USERS_READ");
    setCanWrite(hasPerm(me, "ADMIN_USERS_WRITE"));
    setCanSupportView(hasPerm(me, "action:admin:support-view"));
    setCurrentUserId((me as any)?.user?.id || "");
    if (!readOk) {
      setPageState("denied");
      return;
    }

    try {
      const [u, r] = await Promise.all([listUsers(), listRoles()]);
      setUsers(u);
      setRoles(r);

      const next: Record<string, boolean> = {};
      for (const rr of r) next[rr.id] = false;
      setNewRoleIds(next);
      setPageState("ready");
    } catch (error) {
      setPageError(error);
      setPageState("error");
      throw error;
    }
  }

  useEffect(() => {
    refresh().catch(() => undefined);
  }, []);

  function startEditRoles(userId: string) {
    const u = users.find((x) => x.id === userId);
    if (!u) return;

    const next: Record<string, boolean> = {};
    for (const r of roles) next[r.id] = false;
    for (const rr of u.roles ?? []) next[rr.role.id] = true;

    setEditingUserId(userId);
    setCheckedRoles(next);
  }

  function closeRolesPopup() {
    setEditingUserId("");
    setCheckedRoles({});
  }

  function startResetPassword(userId: string) {
    setPasswordUserId(userId);
    setPasswordValue("");
  }

  function openControls(userId: string) {
    setControlsUserId(userId);
  }

  function closeControls() {
    setControlsUserId("");
  }

  function openSupportView(userId: string) {
    setSupportUserId(userId);
    setSupportReason("");
    setSupportTicket("");
  }

  function closeSupportView() {
    if (supportStarting) return;
    setSupportUserId("");
    setSupportReason("");
    setSupportTicket("");
  }

  async function startSupportView() {
    if (!supportUserId || supportStarting) return;
    const reason = supportReason.trim();
    const ticket = supportTicket.trim();
    if (!reason) {
      alert("Enter a support reason before starting support view.");
      return;
    }

    try {
      setSupportStarting(true);
      const result = await createSupportSession(supportUserId, { reason, ticket: ticket || undefined });
      startSupportSessionToken(result.accessToken);
      window.location.href = "/";
    } catch (error) {
      alert(getErrorMessage(error));
    } finally {
      setSupportStarting(false);
    }
  }

  async function saveRoles() {
    if (!editingUserId) return;
    const roleIds = Object.entries(checkedRoles)
      .filter(([, v]) => v)
      .map(([id]) => id);

    try {
      await setUserRoles(editingUserId, roleIds);
      closeRolesPopup();
      await refresh();
      flash("Access profiles updated ✓");
    } catch (error) {
      alert(getErrorMessage(error));
    }
  }

  async function saveResetPassword() {
    if (!passwordUserId) return;
    const newPasswordValue = passwordValue.trim();
    if (newPasswordValue.length < 8) {
      alert("Password must be at least 8 characters");
      return;
    }

    try {
      await resetUserPassword(passwordUserId, newPasswordValue);
      setPasswordUserId("");
      setPasswordValue("");
      flash("Password reset updated ✓");
    } catch (error) {
      alert(getErrorMessage(error));
    }
  }

  async function toggleActive(userId: string, current: boolean) {
    if (!canWrite) return;
    try {
      await setUserStatus(userId, !current);
      await refresh();
      flash(`Person ${current ? "disabled" : "enabled"} ✓`);
    } catch (error) {
      alert(getErrorMessage(error));
    }
  }

  async function onDeleteUser(userId: string, label: string) {
    if (!canWrite) return;
    if (userId === currentUserId) {
      alert("You cannot delete your own account while signed in.");
      return;
    }
    const ok = window.confirm(`Delete ${label}?

This removes the login account. If the user is linked to operational history, the system will block deletion safely.`);
    if (!ok) return;

    try {
      await deleteUser(userId);
      if (editingUserId === userId) closeRolesPopup();
      if (passwordUserId === userId) {
        setPasswordUserId("");
        setPasswordValue("");
      }
      if (controlsUserId === userId) {
        closeControls();
      }
      if (supportUserId === userId) {
        closeSupportView();
      }
      await refresh();
      flash("Person deleted ✓");
    } catch (error) {
      alert(getErrorMessage(error));
    }
  }

  async function onCreateUser() {
    if (!canWrite) return;

    const email = newEmail.trim();
    const displayName = newDisplayName.trim();
    const password = newPassword;

    if (!email || !password || !displayName) {
      alert("Email, display name, and password are required");
      return;
    }

    try {
      await createUser({
        email,
        displayName,
        password,
        roleIds: selectedNewRoleIds.length ? selectedNewRoleIds : undefined,
      });

      setNewEmail("");
      setNewDisplayName("");
      setNewPassword("");

      const next: Record<string, boolean> = {};
      for (const r of roles) next[r.id] = false;
      setNewRoleIds(next);

      await refresh();
      flash("Person created ✓");
    } catch (error) {
      alert(getErrorMessage(error));
    }
  }


  async function onSyncFromAccounts() {
    if (!canWrite || syncingFromAccounts) return;
    try {
      setSyncingFromAccounts(true);
      const result = await syncUsersFromAccounts();
      await refresh();
      flash(`Accounts sync done ✓ Created ${result.createdCount}, existing ${result.existingCount}, skipped ${result.skippedCount}`);
    } catch (error) {
      alert(getErrorMessage(error));
    } finally {
      setSyncingFromAccounts(false);
    }
  }

  if (pageState === "denied") return <AdminPageState kind="denied" sectionLabel="People" />;
  if (pageState === "error") return <AdminPageState kind="error" sectionLabel="People" error={pageError} />;
  if (pageState === "loading") return <div className="card" style={{ padding: 16 }}>Loading people…</div>;

  return (
    <div style={{ display: "grid", gap: 14 }}>
      <div>
        <h3 style={{ margin: 0 }}>People</h3>
      </div>

      <div className="card" style={{ padding: 12, display: "grid", gap: 10 }}>
        <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
          <div style={{ display: "grid", gap: 4 }}>
            <div style={{ fontWeight: 800 }}>Create person</div>
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
            {statusMsg ? (
              <div style={{ padding: "6px 10px", borderRadius: 8, fontSize: 12, border: "1px solid rgba(34,197,94,0.25)", background: "rgba(34,197,94,0.12)" }}>
                {statusMsg}
              </div>
            ) : null}
            <button type="button" onClick={onSyncFromAccounts} disabled={!canWrite || syncingFromAccounts}>
              {syncingFromAccounts ? "Syncing accounts..." : "Sync from Accounts"}
            </button>
            <button type="button" onClick={() => setShowCreatePersonSection((prev) => !prev)}>
              {showCreatePersonSection ? "Hide section" : "Show section"}
            </button>
          </div>
        </div>

        {showCreatePersonSection ? (
          <>
            <div style={{ display: "grid", gap: 8, gridTemplateColumns: "1fr 1fr 1fr" }}>
              <input placeholder="Email" value={newEmail} onChange={(e) => setNewEmail(e.target.value)} disabled={!canWrite} />
              <input placeholder="Display name" value={newDisplayName} onChange={(e) => setNewDisplayName(e.target.value)} disabled={!canWrite} />
              <input placeholder="Password" type="password" value={newPassword} onChange={(e) => setNewPassword(e.target.value)} disabled={!canWrite} />
            </div>

            <div style={{ display: "grid", gap: 6 }}>
              <div style={{ fontSize: 12, opacity: 0.75 }}>Assign access profiles</div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: 8 }}>
                {roles.map((r) => (
                  <label key={r.id} style={{ display: "grid", gridTemplateColumns: "18px 1fr", gap: 8, alignItems: "start" }}>
                    <input
                      type="checkbox"
                      checked={!!newRoleIds[r.id]}
                      disabled={!canWrite}
                      onChange={(e) => setNewRoleIds((prev) => ({ ...prev, [r.id]: e.target.checked }))}
                    />
                    <span>
                      <span style={{ display: "block", fontWeight: 600 }}>{r.name}</span>
                      {r.description ? <span style={{ display: "block", fontSize: 12, opacity: 0.72 }}>{r.description}</span> : null}
                    </span>
                  </label>
                ))}
              </div>
            </div>

            <div>
              <button onClick={onCreateUser} disabled={!canWrite}>Create person</button>
            </div>
          </>
        ) : null}
      </div>

      <div className="card" style={{ padding: 12, display: "grid", gap: 10 }}>
        <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
          <div style={{ display: "grid", gap: 4 }}>
            <div style={{ fontWeight: 800 }}>People list</div>
            {!showPeopleListSection ? (
              <div style={{ fontSize: 12, opacity: 0.72 }}>{filteredUsers.length} people available</div>
            ) : null}
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
            {showPeopleListSection ? (
              <input placeholder="Search by name, email, or profile" value={q} onChange={(e) => setQ(e.target.value)} style={{ minWidth: 280 }} />
            ) : null}
            <button type="button" onClick={() => setShowPeopleListSection((prev) => !prev)}>
              {showPeopleListSection ? "Hide section" : "Show section"}
            </button>
          </div>
        </div>

        {showPeopleListSection ? (
          filteredUsers.length ? (
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))",
                gap: 18,
              }}
            >
              {filteredUsers.map((u) => {
                const displayLabel = getPersonLabel(u);
                const avatarTone = getAvatarTone(displayLabel || u.email || u.id);
                const initials = getInitials(displayLabel);
                return (
                  <div
                    key={u.id}
                    style={{
                      position: "relative",
                      borderRadius: 22,
                      border: "1px solid rgba(15,23,42,0.08)",
                      background: "#ffffff",
                      boxShadow: "0 10px 24px rgba(15,23,42,0.05)",
                      padding: 18,
                      minHeight: 148,
                      display: "grid",
                      gap: 14,
                    }}
                  >
                    <button
                      type="button"
                      onClick={() => openControls(u.id)}
                      title="Open person options"
                      style={{
                        position: "absolute",
                        top: 14,
                        right: 14,
                        width: 34,
                        height: 34,
                        borderRadius: 999,
                        border: "1px solid rgba(15,23,42,0.08)",
                        background: "#ffffff",
                        display: "inline-flex",
                        alignItems: "center",
                        justifyContent: "center",
                        fontSize: 18,
                        fontWeight: 800,
                        lineHeight: 1,
                        boxShadow: "0 8px 18px rgba(15,23,42,0.08)",
                        cursor: "pointer",
                      }}
                    >
                      ⋯
                    </button>

                    <div style={{ display: "flex", alignItems: "center", gap: 14, minWidth: 0, paddingRight: 38 }}>
                      <div
                        aria-hidden="true"
                        style={{
                          width: 62,
                          height: 62,
                          borderRadius: "50%",
                          background: avatarTone.background,
                          color: avatarTone.color,
                          display: "grid",
                          placeItems: "center",
                          fontWeight: 800,
                          fontSize: 22,
                          letterSpacing: 0.5,
                          flexShrink: 0,
                          boxShadow: "inset 0 1px 0 rgba(255,255,255,0.6)",
                        }}
                      >
                        {initials}
                      </div>

                      <div style={{ minWidth: 0, display: "grid", gap: 4 }}>
                        <div
                          style={{
                            fontWeight: 800,
                            fontSize: 16,
                            lineHeight: 1.2,
                            color: "#0f172a",
                            whiteSpace: "nowrap",
                            overflow: "hidden",
                            textOverflow: "ellipsis",
                          }}
                          title={displayLabel}
                        >
                          {displayLabel}
                        </div>
                        <div
                          style={{
                            fontSize: 13,
                            color: "#475569",
                            whiteSpace: "nowrap",
                            overflow: "hidden",
                            textOverflow: "ellipsis",
                          }}
                          title={u.email}
                        >
                          {u.email}
                        </div>
                        <span
                          style={{
                            display: "inline-flex",
                            alignItems: "center",
                            gap: 6,
                            width: "fit-content",
                            padding: "4px 10px",
                            borderRadius: 999,
                            fontSize: 11,
                            fontWeight: 700,
                            background: u.isActive ? "rgba(34,197,94,0.10)" : "rgba(148,163,184,0.14)",
                            color: u.isActive ? "#166534" : "#475569",
                            border: u.isActive ? "1px solid rgba(34,197,94,0.20)" : "1px solid rgba(148,163,184,0.18)",
                          }}
                        >
                          <span
                            style={{
                              width: 8,
                              height: 8,
                              borderRadius: 999,
                              background: u.isActive ? "#22c55e" : "#94a3b8",
                              display: "inline-block",
                            }}
                          />
                          {u.isActive ? "Enabled" : "Disabled"}
                        </span>
                      </div>
                    </div>

                    <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                      {(u.roles ?? []).length ? (
                        (u.roles ?? []).map((x: any) => (
                          <span
                            key={x.role.id}
                            style={{
                              padding: "4px 10px",
                              borderRadius: 999,
                              background: "#ffffff",
                              border: "1px solid rgba(99,102,241,0.26)",
                              color: "#4f46e5",
                              fontSize: 11,
                              fontWeight: 600,
                              lineHeight: 1.2,
                            }}
                          >
                            {x.role.name}
                          </span>
                        ))
                      ) : (
                        <span style={{ fontSize: 12, color: "#64748b" }}>No access profile assigned</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div style={{ padding: 18, borderRadius: 16, border: "1px dashed rgba(15,23,42,0.12)", color: "#64748b", background: "rgba(248,250,252,0.8)" }}>
              No people found for the current search.
            </div>
          )
        ) : null}
      </div>

      <AppModal
        open={!!editingUserId}
        title="Assign access profiles"
        subtitle={editingUser ? `Update access for ${editingUser.displayName || editingUser.email}` : "Choose one or more access profiles for this person."}
        onClose={closeRolesPopup}
      >
        <div style={{ display: "grid", gap: 8, gridTemplateColumns: "repeat(2, minmax(0, 1fr))" }}>
          {roles.map((r) => (
            <label key={r.id} style={{ display: "grid", gridTemplateColumns: "18px 1fr", gap: 8, alignItems: "start", border: "1px solid rgba(0,0,0,0.06)", borderRadius: 12, padding: 10 }}>
              <input
                type="checkbox"
                checked={!!checkedRoles[r.id]}
                onChange={(e) => setCheckedRoles((prev) => ({ ...prev, [r.id]: e.target.checked }))}
              />
              <span>
                <span style={{ display: "block", fontWeight: 600 }}>{r.name}</span>
                {r.description ? <span style={{ display: "block", fontSize: 12, opacity: 0.72 }}>{r.description}</span> : null}
              </span>
            </label>
          ))}
        </div>
        <div style={{ display: "flex", gap: 8, justifyContent: "flex-end", flexWrap: "wrap" }}>
          <button onClick={closeRolesPopup}>Cancel</button>
          <button onClick={saveRoles}>Save profiles</button>
        </div>
      </AppModal>

      <AppModal
        open={!!controlsUser}
        title={controlsUser ? `${controlsUser.displayName || controlsUser.email}` : "Person options"}
        subtitle="Status and actions"
        onClose={closeControls}
        width="sm"
        panelStyle={{ background: "#ffffff" }}
      >
        {controlsUser ? (
          <div style={{ display: "grid", gap: 16 }}>
            <div style={{ display: "grid", gap: 8, padding: 14, borderRadius: 14, border: "1px solid rgba(15,23,42,0.08)", background: "#ffffff" }}>
              <div style={{ fontWeight: 800 }}>Status</div>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, flexWrap: "wrap" }}>
                <span
                  style={{
                    display: "inline-flex",
                    alignItems: "center",
                    gap: 6,
                    padding: "6px 12px",
                    borderRadius: 999,
                    fontSize: 12,
                    fontWeight: 800,
                    background: controlsUser.isActive ? "rgba(34,197,94,0.12)" : "rgba(148,163,184,0.16)",
                    color: controlsUser.isActive ? "#166534" : "#475569",
                    border: controlsUser.isActive ? "1px solid rgba(34,197,94,0.22)" : "1px solid rgba(148,163,184,0.2)",
                  }}
                >
                  <span
                    style={{
                      width: 8,
                      height: 8,
                      borderRadius: 999,
                      background: controlsUser.isActive ? "#22c55e" : "#94a3b8",
                      display: "inline-block",
                    }}
                  />
                  {controlsUser.isActive ? "Enabled" : "Disabled"}
                </span>
                <button
                  onClick={async () => {
                    await toggleActive(controlsUser.id, controlsUser.isActive);
                  }}
                  disabled={!canWrite}
                  title={canWrite ? "Toggle active" : "You do not currently have access to edit people."}
                >
                  {controlsUser.isActive ? "Disable person" : "Enable person"}
                </button>
              </div>
            </div>

            <div style={{ display: "grid", gap: 8, padding: 14, borderRadius: 14, border: "1px solid rgba(15,23,42,0.08)", background: "#ffffff" }}>
              <div style={{ fontWeight: 800 }}>Actions</div>
              <div style={{ display: "grid", gap: 8 }}>
                <button
                  onClick={() => {
                    closeControls();
                    openSupportView(controlsUser.id);
                  }}
                  disabled={!canSupportView || controlsUser.id === currentUserId || !controlsUser.isActive}
                  title={
                    controlsUser.id === currentUserId
                      ? "You are already signed in as this person."
                      : !controlsUser.isActive
                        ? "Support view is available only for enabled people."
                        : canSupportView
                          ? "Open a read-only support view as this person."
                          : "You do not currently have support-view access."
                  }
                >
                  View as this person
                </button>
                <button
                  onClick={() => {
                    closeControls();
                    startEditRoles(controlsUser.id);
                  }}
                  disabled={!canWrite}
                >
                  Assign profiles
                </button>
                <button
                  onClick={() => {
                    closeControls();
                    startResetPassword(controlsUser.id);
                  }}
                  disabled={!canWrite}
                >
                  Reset password
                </button>
                <button
                  onClick={() => onDeleteUser(controlsUser.id, controlsUser.displayName || controlsUser.email)}
                  disabled={!canWrite || controlsUser.id === currentUserId}
                  title={controlsUser.id === currentUserId ? "You cannot delete your own account while signed in." : undefined}
                >
                  Delete person
                </button>
              </div>
            </div>
          </div>
        ) : null}
      </AppModal>


      <AppModal
        open={!!supportUser}
        title="Start support view"
        subtitle={supportUser ? `Open a temporary read-only session as ${supportUser.displayName || supportUser.email}` : "Open support view"}
        onClose={closeSupportView}
        width="sm"
        panelStyle={{ background: "#ffffff" }}
      >
        <div style={{ display: "grid", gap: 12 }}>
          <label style={{ display: "grid", gap: 6 }}>
            <span style={{ fontSize: 12, fontWeight: 800, color: "#475569" }}>Reason *</span>
            <textarea
              value={supportReason}
              onChange={(event) => setSupportReason(event.target.value)}
              placeholder="Example: Client reported they cannot see approval video."
              rows={3}
              disabled={supportStarting}
              style={{ resize: "vertical" }}
            />
          </label>
          <label style={{ display: "grid", gap: 6 }}>
            <span style={{ fontSize: 12, fontWeight: 800, color: "#475569" }}>Ticket / reference</span>
            <input
              value={supportTicket}
              onChange={(event) => setSupportTicket(event.target.value)}
              placeholder="Optional ticket, email, or call reference"
              disabled={supportStarting}
            />
          </label>
          <div style={{ padding: 10, borderRadius: 12, background: "#fffbeb", border: "1px solid rgba(217,119,6,0.18)", color: "#92400e", fontSize: 12, fontWeight: 700 }}>
            This opens a read-only troubleshooting session and keeps your current admin token for Exit Support View.
          </div>
          <div style={{ display: "flex", gap: 8, justifyContent: "flex-end", flexWrap: "wrap" }}>
            <button onClick={closeSupportView} disabled={supportStarting}>Cancel</button>
            <button onClick={startSupportView} disabled={supportStarting || !supportReason.trim()}>
              {supportStarting ? "Starting..." : "Start support view"}
            </button>
          </div>
        </div>
      </AppModal>

      <AppModal
        open={!!passwordUserId}
        title="Reset password"
        subtitle="Set a temporary password for this person. The password must be at least 8 characters."
        onClose={() => {
          setPasswordUserId("");
          setPasswordValue("");
        }}
        width="sm"
        panelStyle={{ background: "#ffffff" }}
      >
        <div style={{ display: "grid", gap: 12 }}>
          <input
            placeholder="New temporary password"
            type="password"
            value={passwordValue}
            onChange={(e) => setPasswordValue(e.target.value)}
          />
          <div style={{ display: "flex", gap: 8, justifyContent: "flex-end", flexWrap: "wrap" }}>
            <button
              onClick={() => {
                setPasswordUserId("");
                setPasswordValue("");
              }}
            >
              Cancel
            </button>
            <button onClick={saveResetPassword}>Save password</button>
          </div>
        </div>
      </AppModal>
    </div>
  );
}
