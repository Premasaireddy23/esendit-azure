import { useEffect, useMemo, useState } from "react";
import { emitMeUpdated, getMe, hasPerm } from "../../../lib/me";
import { createRole, getAccountUiConfig, listPermissions, listRoles, setRolePermissions, updateAccountUiConfig, type AccessProfileTemplate } from "../adminApi";
import { groupPermissions, isReadLikeKey, permissionDisplayName, type PermissionRow } from "../permissionsUi";
import { buildSavedTemplatePermissionKeys, normalizeSavedAccessTemplates, summarizeAccessCoverage, type SavedAccessTemplate } from "../accessProfiles";
import { AdminPageState } from "../AdminPageState";

function levelTone(level: "No access" | "View only" | "Manage" | "Custom") {
  if (level === "Manage") return { bg: "rgba(34,197,94,0.12)", border: "rgba(34,197,94,0.35)" };
  if (level === "View only") return { bg: "rgba(59,130,246,0.12)", border: "rgba(59,130,246,0.3)" };
  if (level === "Custom") return { bg: "rgba(245,158,11,0.14)", border: "rgba(245,158,11,0.35)" };
  return { bg: "rgba(148,163,184,0.12)", border: "rgba(148,163,184,0.3)" };
}

function makeTemplateId(name: string) {
  const base = name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60) || "access-profile-template";
  return `${base}-${Date.now()}`;
}

function mapTemplatesForSave(templates: SavedAccessTemplate[]): AccessProfileTemplate[] {
  return templates.map((tpl) => ({
    id: tpl.id,
    name: tpl.name,
    description: tpl.description || null,
    bestFor: tpl.bestFor || null,
    examples: Array.isArray(tpl.examples) ? tpl.examples : [],
    permissionKeys: Array.isArray(tpl.permissionKeys) ? tpl.permissionKeys : [],
  }));
}

function normalizeRoleSearchValue(value: string) {
  return value.trim().toLowerCase();
}

function roleSearchScore(role: any, query: string) {
  const search = normalizeRoleSearchValue(query);
  if (!search) return 0;

  const name = String(role?.name || "").toLowerCase();
  const description = String(role?.description || "").toLowerCase();
  if (!name && !description) return Number.POSITIVE_INFINITY;

  if (name === search) return 0;
  if (name.startsWith(search)) return 1;
  if (name.includes(search)) return 2;
  if (description.startsWith(search)) return 3;
  if (description.includes(search)) return 4;
  return Number.POSITIVE_INFINITY;
}


type StakeholderMatrixAction =
  | "view"
  | "update"
  | "upload"
  | "planner"
  | "commit"
  | "approve"
  | "send"
  | "dam:view"
  | "dam:stream"
  | "tracking:view"
  | "house-id:update";

const STAKEHOLDER_MATRIX_TYPES = [
  { slug: "advertiser-group", label: "Advertiser Group" },
  { slug: "advertiser", label: "Advertiser" },
  { slug: "brand", label: "Brand" },
  { slug: "billable-party", label: "Billable Party" },
  { slug: "sender-account", label: "Sender Account" },
  { slug: "receiver-account", label: "Receiver Account" },
  { slug: "media-agency", label: "Media Agency" },
  { slug: "media-agency-team", label: "Media Agency Team" },
  { slug: "creative-agency", label: "Creative Agency" },
  { slug: "creative-agency-team", label: "Creative Agency Team" },
  { slug: "production", label: "Production" },
  { slug: "production-team", label: "Production Team" },
  { slug: "post-house", label: "Post House" },
  { slug: "post-house-team", label: "Post House Team" },
  { slug: "audio-agency", label: "Audio Agency" },
  { slug: "audio-agency-team", label: "Audio Agency Team" },
  { slug: "uploader-agency", label: "Uploader Agency" },
  { slug: "uploader-agency-team", label: "Uploader Agency Team" },
] as const;

const STAKEHOLDER_MATRIX_ACTIONS: { action: StakeholderMatrixAction; label: string; hint: string }[] = [
  { action: "view", label: "View", hint: "View assigned project and related videos" },
  { action: "update", label: "Update", hint: "Update assigned project details" },
  { action: "upload", label: "Upload", hint: "Upload creatives for assigned project" },
  { action: "planner", label: "Planner", hint: "Edit planner for assigned project" },
  { action: "commit", label: "Commit", hint: "Commit the plan" },
  { action: "approve", label: "Approve", hint: "Approve or reject where approval flow allows" },
  { action: "send", label: "Send", hint: "Send delivery" },
  { action: "dam:view", label: "DAM", hint: "View DAM/library assets" },
  { action: "dam:stream", label: "Preview", hint: "Preview/stream DAM video" },
  { action: "tracking:view", label: "Tracking", hint: "View delivery tracking" },
  { action: "house-id:update", label: "House ID", hint: "Update House ID when applicable" },
];

const STAKEHOLDER_MATRIX_PRESETS: { key: string; label: string; actions: StakeholderMatrixAction[] }[] = [
  { key: "view-only", label: "View only", actions: ["view", "dam:view", "dam:stream", "tracking:view"] },
  { key: "uploader", label: "Uploader", actions: ["view", "upload", "dam:view", "dam:stream", "tracking:view"] },
  { key: "planner", label: "Planner", actions: ["view", "planner", "dam:view", "dam:stream", "tracking:view"] },
  { key: "approver", label: "Approver", actions: ["view", "approve", "dam:view", "dam:stream", "tracking:view"] },
  { key: "receiver", label: "Receiver + House ID", actions: ["view", "approve", "dam:view", "dam:stream", "tracking:view", "house-id:update"] },
  { key: "manage", label: "Full project control", actions: STAKEHOLDER_MATRIX_ACTIONS.map((item) => item.action) },
  { key: "clear", label: "Remove access", actions: [] },
];

function stakeholderMatrixPermissionKey(stakeholderSlug: string, action: StakeholderMatrixAction) {
  return `action:stakeholder:${stakeholderSlug}:${action}`;
}

function isStakeholderMatrixPermissionKey(key: string) {
  return String(key || "").toLowerCase().startsWith("action:stakeholder:");
}

function StakeholderPermissionMatrix({
  items,
  checked,
  setChecked,
  showTechnicalKeys,
}: {
  items: PermissionRow[];
  checked: Record<string, boolean>;
  setChecked: any;
  showTechnicalKeys: boolean;
  key?: any;
}) {
  const availableKeys = useMemo(() => new Set(items.map((item) => item.key)), [items]);
  const matrixKeys = useMemo(
    () =>
      new Set(
        STAKEHOLDER_MATRIX_TYPES.flatMap((stakeholder) =>
          STAKEHOLDER_MATRIX_ACTIONS.map((action) => stakeholderMatrixPermissionKey(stakeholder.slug, action.action))
        )
      ),
    []
  );
  const extraItems = useMemo(() => items.filter((item) => !matrixKeys.has(item.key)), [items, matrixKeys]);
  const selectedCount = items.filter((item) => !!checked[item.key]).length;

  const applyPresetToRow = (stakeholderSlug: string, presetKey: string) => {
    const preset = STAKEHOLDER_MATRIX_PRESETS.find((item) => item.key === presetKey);
    if (!preset) return;
    const selectedActions = new Set<StakeholderMatrixAction>(preset.actions);
    setChecked((prev: Record<string, boolean>) => {
      const next = { ...prev };
      for (const action of STAKEHOLDER_MATRIX_ACTIONS) {
        const key = stakeholderMatrixPermissionKey(stakeholderSlug, action.action);
        if (availableKeys.has(key)) next[key] = selectedActions.has(action.action);
      }
      return next;
    });
  };

  const applyPresetToAll = (presetKey: string) => {
    const preset = STAKEHOLDER_MATRIX_PRESETS.find((item) => item.key === presetKey);
    if (!preset) return;
    const selectedActions = new Set<StakeholderMatrixAction>(preset.actions);
    setChecked((prev: Record<string, boolean>) => {
      const next = { ...prev };
      for (const stakeholder of STAKEHOLDER_MATRIX_TYPES) {
        for (const action of STAKEHOLDER_MATRIX_ACTIONS) {
          const key = stakeholderMatrixPermissionKey(stakeholder.slug, action.action);
          if (availableKeys.has(key)) next[key] = selectedActions.has(action.action);
        }
      }
      return next;
    });
  };

  return (
    <div style={{ border: "1px solid rgba(0,0,0,0.1)", borderRadius: 12, padding: 12, display: "grid", gap: 12 }}>
      <div style={{ display: "flex", justifyContent: "space-between", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
        <div>
          <div style={{ fontWeight: 800 }}>Project Stakeholder Permission Matrix</div>
          <div style={{ fontSize: 12, opacity: 0.72 }}>{selectedCount} of {items.length} stakeholder permissions selected</div>
        </div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
          <span style={{ fontSize: 12, opacity: 0.72 }}>Apply to all:</span>
          {STAKEHOLDER_MATRIX_PRESETS.map((preset) => (
            <button key={preset.key} type="button" onClick={() => applyPresetToAll(preset.key)}>
              {preset.label}
            </button>
          ))}
        </div>
      </div>

      <div style={{ overflowX: "auto", border: "1px solid rgba(15,23,42,0.08)", borderRadius: 12 }}>
        <table style={{ width: "100%", minWidth: 1180, borderCollapse: "collapse", background: "white" }}>
          <thead>
            <tr>
              <th style={{ textAlign: "left", padding: "10px 12px", borderBottom: "1px solid rgba(15,23,42,0.08)", width: 220 }}>Stakeholder type</th>
              <th style={{ textAlign: "left", padding: "10px 12px", borderBottom: "1px solid rgba(15,23,42,0.08)", width: 180 }}>Quick setup</th>
              {STAKEHOLDER_MATRIX_ACTIONS.map((action) => (
                <th key={action.action} title={action.hint} style={{ textAlign: "center", padding: "10px 8px", borderBottom: "1px solid rgba(15,23,42,0.08)", fontSize: 12 }}>
                  {action.label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {STAKEHOLDER_MATRIX_TYPES.map((stakeholder) => {
              const rowKeys = STAKEHOLDER_MATRIX_ACTIONS.map((action) => stakeholderMatrixPermissionKey(stakeholder.slug, action.action));
              const rowHasAnyPermission = rowKeys.some((key) => availableKeys.has(key));
              if (!rowHasAnyPermission) return null;
              return (
                <tr key={stakeholder.slug}>
                  <td style={{ padding: "9px 12px", borderBottom: "1px solid rgba(15,23,42,0.06)", fontWeight: 700 }}>
                    {stakeholder.label}
                  </td>
                  <td style={{ padding: "9px 12px", borderBottom: "1px solid rgba(15,23,42,0.06)" }}>
                    <select
                      value=""
                      onChange={(event) => {
                        applyPresetToRow(stakeholder.slug, event.target.value);
                        event.currentTarget.value = "";
                      }}
                      style={{ minWidth: 150 }}
                    >
                      <option value="">Choose preset</option>
                      {STAKEHOLDER_MATRIX_PRESETS.map((preset) => (
                        <option key={preset.key} value={preset.key}>{preset.label}</option>
                      ))}
                    </select>
                  </td>
                  {STAKEHOLDER_MATRIX_ACTIONS.map((action) => {
                    const key = stakeholderMatrixPermissionKey(stakeholder.slug, action.action);
                    const isAvailable = availableKeys.has(key);
                    return (
                      <td key={key} style={{ padding: "9px 8px", textAlign: "center", borderBottom: "1px solid rgba(15,23,42,0.06)" }} title={showTechnicalKeys ? key : action.hint}>
                        {isAvailable ? (
                          <input
                            type="checkbox"
                            aria-label={`${stakeholder.label} ${action.label}`}
                            checked={!!checked[key]}
                            onChange={(event) => setChecked((prev: Record<string, boolean>) => ({ ...prev, [key]: event.target.checked }))}
                          />
                        ) : (
                          <span style={{ opacity: 0.28 }}>—</span>
                        )}
                      </td>
                    );
                  })}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {extraItems.length ? (
        <div style={{ display: "grid", gap: 8 }}>
          <div style={{ fontWeight: 800 }}>Other stakeholder permissions</div>
          <div style={{ display: "grid", gap: 8, gridTemplateColumns: "repeat(2, minmax(0, 1fr))" }}>
            {extraItems.map((p) => {
              const label = permissionDisplayName(p);
              return (
                <label key={p.id} style={{ display: "grid", gridTemplateColumns: "18px 1fr", gap: 10, alignItems: "start", padding: "4px 0" }}>
                  <input
                    type="checkbox"
                    checked={!!checked[p.key]}
                    onChange={(e) => setChecked((prev: Record<string, boolean>) => ({ ...prev, [p.key]: e.target.checked }))}
                  />
                  <span>
                    <span style={{ display: "block", fontWeight: 600 }}>{label}</span>
                    {showTechnicalKeys ? <span style={{ display: "block", fontSize: 12, opacity: 0.68, fontFamily: "monospace" }}>{p.key}</span> : null}
                  </span>
                </label>
              );
            })}
          </div>
        </div>
      ) : null}
    </div>
  );
}

export function AdminRolesPage() {
  const [pageState, setPageState] = useState<"loading" | "ready" | "denied" | "error">("loading");
  const [pageError, setPageError] = useState<any>(null);
  const [canWrite, setCanWrite] = useState<boolean>(false);

  const [roles, setRoles] = useState<any[]>([]);
  const [perms, setPerms] = useState<PermissionRow[]>([]);
  const [templates, setTemplates] = useState<SavedAccessTemplate[]>([]);
  const [q, setQ] = useState("");
  const [showLegacy, setShowLegacy] = useState(false);
  const [showTechnicalKeys, setShowTechnicalKeys] = useState(false);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [statusMsg, setStatusMsg] = useState<string>("");

  const [selectedRoleId, setSelectedRoleId] = useState<string>("");
  const [roleSearch, setRoleSearch] = useState("");
  const [checked, setChecked] = useState<Record<string, boolean>>({});
  const [baselineKeys, setBaselineKeys] = useState<string[]>([]);
  const [saving, setSaving] = useState<boolean>(false);
  const [savingTemplate, setSavingTemplate] = useState<boolean>(false);
  const [creatingTemplateId, setCreatingTemplateId] = useState<string>("");
  const [templateName, setTemplateName] = useState("");
  const [templateDescription, setTemplateDescription] = useState("");
  const [templateBestFor, setTemplateBestFor] = useState("");
  const [templateExamples, setTemplateExamples] = useState("");
  const [showTemplatesSection, setShowTemplatesSection] = useState(false);
  const [activePermissionGroupKey, setActivePermissionGroupKey] = useState<string>("stakeholder");

  const selectedRole = useMemo(() => roles.find((r) => r.id === selectedRoleId), [roles, selectedRoleId]);
  const groups = useMemo(() => groupPermissions(perms, { includeLegacy: showLegacy, query: q }), [perms, showLegacy, q]);
  const filteredRoles = useMemo(() => {
    const search = normalizeRoleSearchValue(roleSearch);
    const ranked = [...roles]
      .map((role) => ({ role, score: roleSearchScore(role, search) }))
      .filter((item) => !search || Number.isFinite(item.score))
      .sort((a, b) => {
        if (a.score !== b.score) return a.score - b.score;
        return String(a.role?.name || "").localeCompare(String(b.role?.name || ""));
      });

    return ranked.slice(0, search ? 8 : 12).map((item) => item.role);
  }, [roles, roleSearch]);

  const currentKeys = useMemo(
    () =>
      Object.entries(checked)
        .filter(([, v]) => v)
        .map(([k]) => k)
        .sort(),
    [checked]
  );

  const isDirty = useMemo(() => {
    if (!selectedRoleId) return false;
    if (baselineKeys.length !== currentKeys.length) return true;
    for (let i = 0; i < baselineKeys.length; i++) {
      if (baselineKeys[i] !== currentKeys[i]) return true;
    }
    return false;
  }, [selectedRoleId, baselineKeys, currentKeys]);

  const coverage = useMemo(() => summarizeAccessCoverage(perms, currentKeys), [perms, currentKeys]);
  const visiblePermissionGroups = useMemo(() => {
    if (q.trim()) return groups;
    if (!activePermissionGroupKey || activePermissionGroupKey === "all") return groups;
    return groups.filter((group) => group.key === activePermissionGroupKey);
  }, [groups, activePermissionGroupKey, q]);

  useEffect(() => {
    if (!selectedRoleId || !coverage.length) return;
    if (activePermissionGroupKey === "all") return;
    if (coverage.some((item) => item.groupKey === activePermissionGroupKey)) return;
    const stakeholderCoverage = coverage.find((item) => item.groupKey === "stakeholder");
    setActivePermissionGroupKey(stakeholderCoverage?.groupKey || coverage[0]?.groupKey || "all");
  }, [activePermissionGroupKey, coverage, selectedRoleId]);

  async function refresh() {
    setPageError(null);
    const me = await getMe(true);
    const readOk = hasPerm(me, "ADMIN_ROLES_READ");
    setCanWrite(hasPerm(me, "ADMIN_ROLES_WRITE"));
    if (!readOk) {
      setPageState("denied");
      return;
    }

    try {
      const [r, p, cfg] = await Promise.all([listRoles(), listPermissions(), getAccountUiConfig().catch(() => ({ uiConfig: {} as any }))]);
      setRoles(r);
      setPerms(p);
      setTemplates(normalizeSavedAccessTemplates(cfg?.uiConfig?.accessProfileTemplates));
      setPageState("ready");
    } catch (error) {
      setPageError(error);
      setPageState("error");
      throw error;
    }
  }

  useEffect(() => {
    refresh().catch(() => undefined);
  }, []);

  useEffect(() => {
    if (!selectedRole) return;
    const next: Record<string, boolean> = {};
    for (const p of perms) next[p.key] = false;
    for (const p of selectedRole.permissions ?? []) next[p.key] = true;
    setChecked(next);
    setBaselineKeys((selectedRole.permissions ?? []).map((p: any) => p.key).sort());
    setTemplateName((prev) => prev || selectedRole.name || "");
    setTemplateDescription((prev) => prev || selectedRole.description || "");
    setActivePermissionGroupKey("stakeholder");
  }, [selectedRole, perms]);

  function flash(message: string, timeout = 2000) {
    setStatusMsg(message);
    window.setTimeout(() => setStatusMsg(""), timeout);
  }

  async function onCreateRole() {
    const n = name.trim();
    if (!n) return;
    const created = await createRole({ name: n, description: description.trim() || undefined });
    setName("");
    setDescription("");
    await refresh();
    setSelectedRoleId(created.id);
    flash("Access profile created ✓", 1800);
  }

  async function onCreateFromTemplate(template: SavedAccessTemplate) {
    if (!canWrite) return;
    try {
      setCreatingTemplateId(template.id);
      const created = await createRole({
        name: name.trim() || template.name,
        description: description.trim() || template.description || undefined,
      });
      const keys = buildSavedTemplatePermissionKeys(template);
      await setRolePermissions(created.id, keys);
      setName("");
      setDescription("");
      await refresh();
      setSelectedRoleId(created.id);
      flash(`${template.name} profile created ✓`);
      emitMeUpdated();
    } finally {
      setCreatingTemplateId("");
    }
  }

  async function onSavePerms() {
    if (!selectedRoleId) return;
    try {
      setSaving(true);
      await setRolePermissions(selectedRoleId, currentKeys);
      await refresh();
      setBaselineKeys([...currentKeys]);
      flash("Access profile updated ✓");
      emitMeUpdated();
    } finally {
      setSaving(false);
    }
  }

  async function saveTemplate() {
    const cleanName = templateName.trim();
    if (!cleanName) {
      alert("Template name is required");
      return;
    }
    if (!currentKeys.length) {
      alert("Select or create an access profile first, then choose the permissions to save as a template.");
      return;
    }

    const nextTemplate: SavedAccessTemplate = {
      id: makeTemplateId(cleanName),
      name: cleanName,
      description: templateDescription.trim() || null,
      bestFor: templateBestFor.trim() || null,
      examples: Array.from(new Set<string>(templateExamples.split(",").map((item) => item.trim()).filter(Boolean))),
      permissionKeys: [...currentKeys],
    };

    const duplicate = templates.some((tpl) => tpl.name.trim().toLowerCase() === cleanName.toLowerCase());
    if (duplicate) {
      alert("A template with this name already exists.");
      return;
    }

    const nextTemplates = [...templates, nextTemplate];
    try {
      setSavingTemplate(true);
      await updateAccountUiConfig({ accessProfileTemplates: mapTemplatesForSave(nextTemplates) });
      setTemplates(nextTemplates);
      flash("Access profile template saved ✓");
      setTemplateName("");
      setTemplateDescription("");
      setTemplateBestFor("");
      setTemplateExamples("");
    } catch (error: any) {
      alert(error?.message || "Failed to save template");
    } finally {
      setSavingTemplate(false);
    }
  }

  async function removeTemplate(templateId: string) {
    const target = templates.find((tpl) => tpl.id === templateId);
    if (!target) return;
    if (!window.confirm(`Remove template "${target.name}"?`)) return;

    const nextTemplates = templates.filter((tpl) => tpl.id !== templateId);
    try {
      setSavingTemplate(true);
      await updateAccountUiConfig({ accessProfileTemplates: nextTemplates.length ? mapTemplatesForSave(nextTemplates) : [] });
      setTemplates(nextTemplates);
      flash("Access profile template removed ✓");
    } catch (error: any) {
      alert(error?.message || "Failed to remove template");
    } finally {
      setSavingTemplate(false);
    }
  }

  if (pageState === "denied") return <AdminPageState kind="denied" sectionLabel="Access Profiles" />;
  if (pageState === "error") return <AdminPageState kind="error" sectionLabel="Access Profiles" error={pageError} />;
  if (pageState === "loading") return <div className="card" style={{ padding: 16 }}>Loading access profiles…</div>;

  return (
    <div style={{ display: "grid", gap: 14 }}>
      <div>
        <h3 style={{ margin: 0 }}>Access Profiles</h3>
      </div>

      <div className="card" style={{ padding: 12, display: "grid", gap: 12 }}>
        <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
          <div style={{ display: "grid", gap: 4 }}>
            <div style={{ fontWeight: 800 }}>Access profile templates</div>
            {!showTemplatesSection ? (
              <div style={{ fontSize: 12, opacity: 0.72 }}>
                {templates.length} saved template{templates.length === 1 ? "" : "s"}
              </div>
            ) : null}
          </div>
          <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
            {statusMsg ? (
              <div style={{ padding: "6px 10px", borderRadius: 8, fontSize: 12, border: "1px solid rgba(34,197,94,0.25)", background: "rgba(34,197,94,0.12)" }}>
                {statusMsg}
              </div>
            ) : null}
            <button type="button" onClick={() => setShowTemplatesSection((prev) => !prev)}>
              {showTemplatesSection ? "Hide section" : "Show section"}
            </button>
          </div>
        </div>

        {showTemplatesSection ? (
          <div style={{ display: "grid", gap: 12, gridTemplateColumns: "minmax(340px, 1.2fr) minmax(320px, 0.8fr)" }}>
            <div style={{ display: "grid", gap: 10, alignContent: "start" }}>
              {templates.length ? (
                <div style={{ display: "grid", gap: 10, gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))" }}>
                  {templates.map((tpl) => (
                    <div key={tpl.id} style={{ border: "1px solid rgba(0,0,0,0.09)", borderRadius: 14, padding: 12, display: "grid", gap: 8 }}>
                      <div style={{ fontWeight: 800 }}>{tpl.name}</div>
                      <div style={{ fontSize: 13, opacity: 0.82 }}>{tpl.description || "No description added."}</div>
                      <div style={{ fontSize: 12, opacity: 0.72 }}>Best for: {tpl.bestFor || "Not specified"}</div>
                      <div style={{ fontSize: 12, opacity: 0.72 }}>Permissions in template: {tpl.permissionKeys.length}</div>
                      {tpl.examples?.length ? (
                        <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                          {tpl.examples.map((item) => (
                            <span key={item} style={{ fontSize: 12, padding: "4px 8px", borderRadius: 999, background: "rgba(15,23,42,0.06)" }}>
                              {item}
                            </span>
                          ))}
                        </div>
                      ) : null}
                      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                        <button
                          type="button"
                          onClick={() => onCreateFromTemplate(tpl)}
                          disabled={!canWrite || creatingTemplateId === tpl.id}
                          title={!canWrite ? "You do not currently have access to edit access profiles." : undefined}
                        >
                          {creatingTemplateId === tpl.id ? "Creating..." : "Create from template"}
                        </button>
                        <button type="button" onClick={() => removeTemplate(tpl.id)} disabled={!canWrite || savingTemplate}>
                          Remove template
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <div style={{ border: "1px dashed rgba(15,23,42,0.18)", borderRadius: 14, padding: 16, fontSize: 13, opacity: 0.8 }}>
                  No quick templates yet. Create or select an access profile, adjust its permissions, then save it as a reusable template here.
                </div>
              )}
            </div>

            <div style={{ border: "1px solid rgba(0,0,0,0.08)", borderRadius: 14, padding: 12, display: "grid", gap: 10, alignContent: "start" }}>
              <div style={{ fontWeight: 800 }}>Save current setup as template</div>
              <input placeholder="Template name" value={templateName} onChange={(e) => setTemplateName(e.target.value)} disabled={!canWrite} />
              <input placeholder="Short description" value={templateDescription} onChange={(e) => setTemplateDescription(e.target.value)} disabled={!canWrite} />
              <input placeholder="Best for" value={templateBestFor} onChange={(e) => setTemplateBestFor(e.target.value)} disabled={!canWrite} />
              <input
                placeholder="Examples, separated by comma"
                value={templateExamples}
                onChange={(e) => setTemplateExamples(e.target.value)}
                disabled={!canWrite}
              />
              <div style={{ fontSize: 12, opacity: 0.72 }}>
                Current permission count: {currentKeys.length}
              </div>
              <button type="button" onClick={saveTemplate} disabled={!canWrite || savingTemplate || !templateName.trim()}>
                {savingTemplate ? "Saving..." : "Save template"}
              </button>
            </div>
          </div>
        ) : null}
      </div>

      <div className="card" style={{ padding: 12, display: "grid", gap: 10 }}>
        <div style={{ fontWeight: 800 }}>Create a custom access profile</div>
        <div style={{ display: "grid", gap: 8, gridTemplateColumns: "minmax(220px, 1fr) minmax(280px, 2fr) auto" }}>
          <input placeholder="Profile name" value={name} onChange={(e) => setName(e.target.value)} disabled={!canWrite} />
          <input
            placeholder="Short description for clients, for example: Can send jobs and monitor delivery"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            disabled={!canWrite}
          />
          <button onClick={onCreateRole} disabled={!canWrite || !name.trim()}>
            Create profile
          </button>
        </div>
      </div>

      <div style={{ display: "grid", gap: 10, gridTemplateColumns: "320px 1fr" }}>
        <div className="card" style={{ padding: 12, display: "grid", gap: 10, alignContent: "start" }}>
          <div style={{ fontWeight: 800 }}>Access profile list</div>
          <input
            value={roleSearch}
            onChange={(e) => setRoleSearch(e.target.value)}
            placeholder="Search access profiles"
            style={{ width: "100%" }}
          />
          <div style={{ fontSize: 12, opacity: 0.72 }}>
            {roleSearch.trim() ? `Best matches for “${roleSearch.trim()}”` : "Top access profiles"}
          </div>
          <div style={{ display: "grid", gap: 8 }}>
            {filteredRoles.length ? (
              filteredRoles.map((role) => {
                const isActive = role.id === selectedRoleId;
                return (
                  <button
                    key={role.id}
                    type="button"
                    onClick={() => setSelectedRoleId(role.id)}
                    style={{
                      textAlign: "left",
                      borderRadius: 12,
                      padding: "10px 12px",
                      border: isActive ? "1px solid rgba(255,45,122,0.32)" : "1px solid rgba(0,0,0,0.08)",
                      background: isActive ? "rgba(255,45,122,0.08)" : "white",
                      display: "grid",
                      gap: 4,
                      cursor: "pointer",
                    }}
                  >
                    <span style={{ fontWeight: 700 }}>{role.name}</span>
                    <span style={{ fontSize: 12, opacity: 0.76 }}>{role.description || "No description added."}</span>
                  </button>
                );
              })
            ) : (
              <div style={{ border: "1px dashed rgba(15,23,42,0.18)", borderRadius: 12, padding: 12, fontSize: 13, opacity: 0.76 }}>
                No access profiles matched this search.
              </div>
            )}
          </div>

          {selectedRole ? (
            <div style={{ display: "grid", gap: 6, fontSize: 13, marginTop: 4 }}>
              <div>
                <b>Name:</b> {selectedRole.name}
              </div>
              <div>
                <b>Description:</b> {selectedRole.description || "-"}
              </div>
              <div>
                <b>Assigned permissions:</b> {(selectedRole.permissions ?? []).length}
              </div>
            </div>
          ) : null}
        </div>

        <div className="card" style={{ padding: 12, display: "grid", gap: 12 }}>
          {!selectedRoleId ? null : (
            <>
              <div style={{ display: "grid", gap: 8 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
                  <div>
                    <div style={{ fontWeight: 800 }}>Access summary</div>
                    <div style={{ fontSize: 12, opacity: 0.72 }}>Click a tile to edit only that permission set.</div>
                  </div>
                  <button
                    type="button"
                    onClick={() => setActivePermissionGroupKey("all")}
                    style={{
                      borderRadius: 999,
                      border: activePermissionGroupKey === "all" ? "1px solid rgba(255,45,122,0.36)" : "1px solid rgba(15,23,42,0.12)",
                      background: activePermissionGroupKey === "all" ? "rgba(255,45,122,0.08)" : "white",
                      fontWeight: 700,
                    }}
                  >
                    Show all sections
                  </button>
                </div>

                <div style={{ display: "grid", gap: 8, gridTemplateColumns: "repeat(auto-fit, minmax(145px, 1fr))" }}>
                  {coverage.map((item) => {
                    const tone = levelTone(item.level);
                    const isActive = activePermissionGroupKey === item.groupKey;
                    return (
                      <button
                        key={item.groupKey}
                        type="button"
                        onClick={() => setActivePermissionGroupKey(item.groupKey)}
                        style={{
                          textAlign: "left",
                          padding: "9px 10px",
                          borderRadius: 12,
                          border: isActive ? "1px solid rgba(255,45,122,0.45)" : `1px solid ${tone.border}`,
                          background: isActive ? "rgba(255,45,122,0.08)" : tone.bg,
                          minHeight: 70,
                          cursor: "pointer",
                          boxShadow: isActive ? "0 8px 18px rgba(15,23,42,0.08)" : "none",
                        }}
                        title={`Show ${item.title} permissions`}
                      >
                        <div style={{ fontSize: 12, opacity: 0.72 }}>{item.title}</div>
                        <div style={{ fontWeight: 800 }}>{item.level}</div>
                        <div style={{ fontSize: 11, opacity: 0.68 }}>{item.selectedCount}/{item.total} selected</div>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
                <input placeholder="Search access items" value={q} onChange={(e) => setQ(e.target.value)} style={{ minWidth: 240 }} />
                <label style={{ display: "flex", gap: 6, alignItems: "center", fontSize: 12, opacity: 0.9 }}>
                  <input type="checkbox" checked={showLegacy} onChange={(e) => setShowLegacy(e.target.checked)} />
                  Show legacy / unknown keys
                </label>
                <label style={{ display: "flex", gap: 6, alignItems: "center", fontSize: 12, opacity: 0.9 }}>
                  <input type="checkbox" checked={showTechnicalKeys} onChange={(e) => setShowTechnicalKeys(e.target.checked)} />
                  Show technical permission keys
                </label>
                <button
                  type="button"
                  onClick={() =>
                    setChecked((prev) => {
                      const next = { ...prev };
                      for (const g of visiblePermissionGroups) for (const p of g.items) next[p.key] = true;
                      return next;
                    })
                  }
                >
                  Select all shown
                </button>
                <button
                  type="button"
                  onClick={() =>
                    setChecked((prev) => {
                      const next = { ...prev };
                      for (const g of visiblePermissionGroups) for (const p of g.items) next[p.key] = false;
                      return next;
                    })
                  }
                >
                  Clear shown
                </button>
              </div>

              <div style={{ display: "grid", gap: 12 }}>
                {visiblePermissionGroups.map((g) => {
                  const groupKeys = g.items.map((x) => x.key);
                  const selectedCount = groupKeys.filter((k) => !!checked[k]).length;

                  const setGroup = (mode: "view" | "full" | "clear") => {
                    setChecked((prev) => {
                      const next = { ...prev };
                      for (const p of g.items) {
                        if (mode === "clear") next[p.key] = false;
                        else if (mode === "full") next[p.key] = true;
                        else next[p.key] = String(p.type).toUpperCase() === "PAGE" || isReadLikeKey(p.key);
                      }
                      return next;
                    });
                  };

                  if (g.key === "stakeholder") {
                    return (
                      <StakeholderPermissionMatrix
                        key={g.key}
                        items={g.items.filter((item) => isStakeholderMatrixPermissionKey(item.key))}
                        checked={checked}
                        setChecked={setChecked}
                        showTechnicalKeys={showTechnicalKeys}
                      />
                    );
                  }

                  return (
                    <div key={g.key} style={{ border: "1px solid rgba(0,0,0,0.1)", borderRadius: 12, padding: 12 }}>
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
                        <div>
                          <div style={{ fontWeight: 800 }}>{g.title}</div>
                          <div style={{ fontSize: 12, opacity: 0.72 }}>{selectedCount} of {g.items.length} items selected</div>
                        </div>
                        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                          <button type="button" onClick={() => setGroup("view")}>View only</button>
                          <button type="button" onClick={() => setGroup("full")}>Manage</button>
                          <button type="button" onClick={() => setGroup("clear")}>Remove access</button>
                        </div>
                      </div>

                      <div style={{ marginTop: 10, display: "grid", gap: 8, gridTemplateColumns: "repeat(2, minmax(0, 1fr))" }}>
                        {g.items.map((p) => {
                          const label = permissionDisplayName(p);
                          return (
                            <label
                              key={p.id}
                              style={{ display: "grid", gridTemplateColumns: "18px 1fr", gap: 10, alignItems: "start", padding: "4px 0" }}
                            >
                              <input
                                type="checkbox"
                                checked={!!checked[p.key]}
                                onChange={(e) => setChecked((prev) => ({ ...prev, [p.key]: e.target.checked }))}
                              />
                              <span>
                                <span style={{ display: "block", fontWeight: 600 }}>{label}</span>
                                {showTechnicalKeys ? (
                                  <span style={{ display: "block", fontSize: 12, opacity: 0.68, fontFamily: "monospace" }}>{p.key}</span>
                                ) : null}
                              </span>
                            </label>
                          );
                        })}
                      </div>
                    </div>
                  );
                })}
              </div>

              <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
                <button onClick={onSavePerms} disabled={!canWrite || !isDirty || saving}>
                  {saving ? "Saving..." : "Save access profile"}
                </button>
                {!canWrite ? <span style={{ fontSize: 12, opacity: 0.72 }}>Editing is not available for your access level.</span> : null}
                {isDirty ? <span style={{ fontSize: 12, opacity: 0.72 }}>You have unsaved changes.</span> : null}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
