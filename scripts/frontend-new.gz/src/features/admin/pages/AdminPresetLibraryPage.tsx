import { useEffect, useMemo, useState } from "react";
import type { CSSProperties } from "react";
import {
  createPresetLibraryItem,
  deletePresetLibraryItem,
  duplicatePresetLibraryItem,
  listPresetLibrary,
  type PresetLibraryItem,
  type PresetPipelineStep,
  updatePresetLibraryItem,
} from "../adminApi";

type EditorMode = "create" | "edit" | "duplicate";
type BuilderProfile = "mp4_h264" | "mov_prores" | "mxf_xdcam" | "wav_audio";
type BuilderResolution = "source" | "1080" | "720" | "576";
type BuilderFps = "source" | "25" | "29.97" | "30";
type BuilderAspect = "source" | "16:9" | "4:3";
type BuilderChannels = "source" | "1" | "2" | "8";

type BuilderState = {
  profile: BuilderProfile;
  resolution: BuilderResolution;
  fps: BuilderFps;
  aspect: BuilderAspect;
  videoQualityMode: "quality" | "bitrate";
  crf: string;
  videoBitrate: string;
  speedPreset: string;
  audioBitrate: string;
  audioSampleRate: string;
  audioChannels: BuilderChannels;
  customFilter: string;
  customExtraArgs: string;
};

type EditorExecutionMode = "single" | "pipeline";

type EditorPipelineStep = {
  key: string;
  label: string;
  tool: string;
  binary: string;
  input: string;
  output: string;
  ext: string;
  argsText: string;
};

type EditorState = {
  mode: EditorMode;
  originalKey?: string;
  key: string;
  label: string;
  ext: string;
  mimeType: string;
  argsText: string;
  useGuidedBuilder: boolean;
  builder: BuilderState;
  previewInputName: string;
  previewOutputBase: string;
  executionMode: EditorExecutionMode;
  tool: string;
  steps: EditorPipelineStep[];
};

function argsToText(args: string[] | undefined) {
  return Array.isArray(args) ? args.join("\n") : "";
}

function textToArgs(text: string) {
  return String(text || "")
    .split(/\r?\n/)
    .map((line) => line.trim())
    .filter(Boolean);
}

function splitLooseTokens(text: string) {
  return String(text || "")
    .split(/\r?\n|\s+/)
    .map((token) => token.trim())
    .filter(Boolean);
}

function shellQuote(token: string) {
  const value = String(token || "");
  if (!value) return '""';
  if (!/[\s"'`$\\]/.test(value)) return value;
  return `"${value.replace(/(["\\$`])/g, "\\$1")}"`;
}

function findArgValue(args: string[], flag: string) {
  const index = args.findIndex((token) => token === flag);
  return index >= 0 && index + 1 < args.length ? args[index + 1] : "";
}

function hasFlag(args: string[], flag: string) {
  return args.includes(flag);
}

function summarizePreset(ext: string, mimeType: string, args: string[]) {
  const videoCodec = findArgValue(args, "-c:v") || (hasFlag(args, "-vn") ? "No video" : "Source/default");
  const audioCodec = findArgValue(args, "-c:a") || (hasFlag(args, "-an") ? "No audio" : "Source/default");
  const frameRate = findArgValue(args, "-r") || "Keep source";
  const sampleRate = findArgValue(args, "-ar") || "Keep source";
  const channels = findArgValue(args, "-ac") || "Keep source";
  const videoBitrate = findArgValue(args, "-b:v") || "";
  const audioBitrate = findArgValue(args, "-b:a") || "";
  const crf = findArgValue(args, "-crf") || "";
  const speed = findArgValue(args, "-preset") || "";
  const vf = findArgValue(args, "-vf") || "";
  const pixelFormat = findArgValue(args, "-pix_fmt") || "";
  const dar = vf.includes("setdar=16/9") ? "16:9" : vf.includes("setdar=4/3") ? "4:3" : "Keep source";
  const resolution = (() => {
    const m = vf.match(/scale=-?\d+:(\d+)/);
    return m?.[1] ? `${m[1]}p` : "Keep source";
  })();

  const warnings: string[] = [];
  if (ext !== "wav" && !hasFlag(args, "-vn") && !findArgValue(args, "-c:v")) warnings.push("No explicit video codec is set. FFmpeg will rely on defaults.");
  if (ext !== "wav" && !hasFlag(args, "-an") && !findArgValue(args, "-c:a")) warnings.push("No explicit audio codec is set. FFmpeg will rely on defaults.");
  if (hasFlag(args, "-vn") && ext !== "wav") warnings.push("This preset disables video but the selected extension looks like a video container.");
  if (findArgValue(args, "-crf") && findArgValue(args, "-b:v")) warnings.push("Both CRF and video bitrate are set. This may be intentional, but check the encoding strategy.");
  if (ext === "mxf" && findArgValue(args, "-c:a") && findArgValue(args, "-c:a") !== "pcm_s16le") warnings.push("MXF presets usually use PCM audio. Check whether this matches the client requirement.");
  if (ext === "wav" && !hasFlag(args, "-vn")) warnings.push("WAV outputs are usually audio-only. Consider adding -vn.");

  return {
    videoCodec,
    audioCodec,
    frameRate,
    sampleRate,
    channels,
    videoBitrate,
    audioBitrate,
    crf,
    speed,
    vf,
    pixelFormat,
    dar,
    resolution,
    warnings,
    format: ext.toUpperCase(),
    mimeType,
    hasFastStart: args.includes("+faststart") || args.includes("-movflags"),
  };
}

function findAllArgValues(args: string[], flag: string) {
  const values: string[] = [];
  for (let index = 0; index < args.length; index += 1) {
    if (args[index] === flag && index + 1 < args.length) values.push(String(args[index + 1] || ""));
  }
  return values;
}

function presetOutputArgs(item: { tool?: string | null; args?: string[]; steps?: PresetPipelineStep[]; ext?: string }) {
  const steps = normalizePresetSteps(item);
  return steps.length ? (steps[steps.length - 1]?.args || []) : (item.args || []);
}

function presetAllArgs(item: { tool?: string | null; args?: string[]; steps?: PresetPipelineStep[]; ext?: string }) {
  return normalizePresetSteps(item).reduce<string[]>((acc, step) => {
    acc.push(...(step.args || []));
    return acc;
  }, []);
}

function humanAudioMode(raw: string) {
  const value = String(raw || "").trim();
  if (!value) return "Source";
  if (value === "1") return "Mono";
  if (value === "2") return "Stereo";
  if (value === "6") return "5.1";
  if (value === "8") return "8 channel";
  return `${value} channel`;
}

function inferPresetType(item: { key?: string | null; label?: string | null; ext?: string | null }, args: string[]) {
  const labelKey = `${item.label || ""} ${item.key || ""}`.toLowerCase();
  const resolution = findArgValue(args, "-s").toLowerCase();
  if ((item.ext || "").toLowerCase() === "wav" || labelKey.includes("audio") || labelKey.includes("wav")) return "Audio";
  if (resolution.includes("3840x2160") || resolution.includes("4096x2160") || labelKey.includes("4k")) return "4K";
  if (resolution.includes("1920x1080") || resolution.includes("1280x720") || labelKey.includes(" hd") || labelKey.endsWith("hd")) return "HD";
  if (resolution.includes("720x576") || resolution.includes("720x480") || labelKey.includes(" sd") || labelKey.endsWith("sd")) return "SD";
  if (labelKey.includes("9:16") || resolution.includes("1080x1920")) return "Vertical";
  return "Source";
}

function inferPresetFormatName(item: { key?: string | null; label?: string | null; ext?: string | null }, args: string[]) {
  const keyLabel = `${item.key || ""} ${item.label || ""}`;
  const normalized = keyLabel.toLowerCase();
  const videoCodec = findArgValue(args, "-c:v") || findArgValue(args, "-vcodec");
  const profile = findArgValue(args, "-profile:v");
  if (videoCodec === "prores_ks") {
    const profileName = ({
      "0": "Apple ProRes 422 Proxy",
      "1": "Apple ProRes 422 LT",
      "2": "Apple ProRes 422",
      "3": "Apple ProRes 422 HQ",
      "4": "Apple ProRes 4444",
      "5": "Apple ProRes 4444 XQ",
    } as Record<string, string>)[profile || ""];
    return profileName || "Apple ProRes";
  }
  if (videoCodec === "dvvideo") return normalized.includes("mxf") ? "DV25 MXF" : "DV25 MOV";
  if (videoCodec === "mpeg2video") return normalized.includes("xdcam") ? "XDCAM HD" : "MPEG-2";
  if (videoCodec === "libx264" || videoCodec === "h264") return "H.264";
  if ((item.ext || "").toLowerCase() === "wav") return "WAV";
  return String(item.label || item.key || (item.ext || "").toUpperCase() || "Preset").trim();
}

function inferPresetAudioDetails(item: { ext?: string | null }, outputArgs: string[], allArgs: string[]) {
  if (allArgs.includes("-an")) return { audio: "No audio", audioStreams: "0" };
  const explicitChannels = findArgValue(outputArgs, "-ac") || findArgValue(allArgs, "-ac");
  const mapTargets = findAllArgValues(allArgs, "-map");
  const audioMaps = mapTargets.filter((target) => /(^|:)a(?::|$)|\[(left|right|center|lfe|sl|sr|c)\]/i.test(target));
  const audioCodec = findArgValue(outputArgs, "-c:a") || findArgValue(outputArgs, "-acodec") || findArgValue(allArgs, "-c:a") || findArgValue(allArgs, "-acodec");
  const channelsplitStereo = allArgs.some((token) => /channelsplit=channel_layout=stereo/i.test(token));
  const audio = explicitChannels
    ? humanAudioMode(explicitChannels)
    : channelsplitStereo
      ? "Stereo"
      : audioCodec
        ? ((item.ext || "").toLowerCase() === "wav" ? "PCM" : "Stereo")
        : "Source";
  const audioStreams = audioMaps.length ? String(audioMaps.length) : (audioCodec ? "1" : "0");
  return { audio, audioStreams };
}

function inferPresetTimecode(allArgs: string[]) {
  return findArgValue(allArgs, "-timecode") || "Source";
}

function presetClientFacingDetails(item: PresetLibraryItem) {
  const outputArgs = presetOutputArgs(item);
  const allArgs = presetAllArgs(item);
  const audioDetails = inferPresetAudioDetails(item, outputArgs, allArgs);
  return [
    { label: "Format", value: inferPresetFormatName(item, outputArgs) },
    { label: "Type", value: inferPresetType(item, outputArgs) },
    { label: "Audio", value: audioDetails.audio },
    { label: "Audio Stream", value: audioDetails.audioStreams },
    { label: "Timecode", value: inferPresetTimecode(allArgs) },
  ];
}

function buildCommandPreview(inputName: string, outputBase: string, ext: string, args: string[], tool = "ffmpeg") {
  const input = shellQuote(inputName || "source-input.mov");
  const output = shellQuote(`${outputBase || "output-preview"}.${ext || "bin"}`);
  return [tool || "ffmpeg", "-i", input, ...args.map(shellQuote), output].join(" ");
}

function normalizePresetSteps(item: { tool?: string | null; args?: string[]; steps?: PresetPipelineStep[]; ext?: string }) {
  const rawSteps = Array.isArray(item.steps) ? item.steps : [];
  if (rawSteps.length) {
    return rawSteps.map((step, index) => ({
      key: String(step?.key || "").trim() || `step${index + 1}`,
      label: String(step?.label || "").trim() || `Step ${index + 1}`,
      tool: String(step?.tool || item.tool || "ffmpeg").trim() || "ffmpeg",
      binary: String(step?.binary || "").trim() || null,
      input: String(step?.input || "source").trim() || "source",
      output: String(step?.output || (index === rawSteps.length - 1 ? "final" : `step${index + 1}`)).trim() || (index === rawSteps.length - 1 ? "final" : `step${index + 1}`),
      ext: String(step?.ext || "").trim() || null,
      args: Array.isArray(step?.args) ? step.args.map((x) => String(x ?? "")).filter(Boolean) : [],
    }));
  }
  return [{
    key: "step1",
    label: "Single step",
    tool: String(item.tool || "ffmpeg").trim() || "ffmpeg",
    binary: null,
    input: "source",
    output: "final",
    ext: String(item.ext || "").trim() || null,
    args: Array.isArray(item.args) ? item.args.map((x) => String(x ?? "")).filter(Boolean) : [],
  }];
}

function isPipelinePreset(item: { steps?: PresetPipelineStep[] } | null | undefined) {
  return !!(item && Array.isArray(item.steps) && item.steps.length);
}

function toEditorPipelineStep(step: ReturnType<typeof normalizePresetSteps>[number]): EditorPipelineStep {
  return {
    key: String(step.key || "").trim(),
    label: String(step.label || "").trim(),
    tool: String(step.tool || "ffmpeg").trim() || "ffmpeg",
    binary: String(step.binary || "").trim(),
    input: String(step.input || "source").trim() || "source",
    output: String(step.output || "final").trim() || "final",
    ext: String(step.ext || "").trim(),
    argsText: argsToText(step.args || []),
  };
}

function toPresetPipelineStep(step: EditorPipelineStep, index: number): PresetPipelineStep {
  const output = String(step.output || "").trim() || (index === 0 ? "final" : `step${index + 1}`);
  return {
    key: String(step.key || "").trim() || `step${index + 1}`,
    label: String(step.label || "").trim() || null,
    tool: String(step.tool || "ffmpeg").trim() || "ffmpeg",
    binary: String(step.binary || "").trim() || null,
    input: String(step.input || "source").trim() || "source",
    output,
    ext: String(step.ext || "").trim() || null,
    args: textToArgs(step.argsText),
  };
}

function createPipelineStep(index: number, input = "source", output = "final", ext = ""): EditorPipelineStep {
  return {
    key: `step${index + 1}`,
    label: `Step ${index + 1}`,
    tool: "ffmpeg",
    binary: "",
    input,
    output,
    ext,
    argsText: "",
  };
}

function buildPipelineCommandPreview(inputName: string, outputBase: string, ext: string, item: { tool?: string | null; args?: string[]; steps?: PresetPipelineStep[] }) {
  const steps = normalizePresetSteps({ ...item, ext });
  const refs = new Map<string, string>([["source", inputName || "source-input.mov"]]);
  let previousOutput = inputName || "source-input.mov";
  return steps.map((step, index) => {
    const inputRef = String(step.input || "source").trim() || "source";
    const resolvedInput = refs.get(inputRef) || previousOutput || inputName || "source-input.mov";
    const outputRef = String(step.output || (index === steps.length - 1 ? "final" : `step${index + 1}`)).trim() || (index === steps.length - 1 ? "final" : `step${index + 1}`);
    const isFinal = outputRef === "final" || index === steps.length - 1;
    const stepExt = String((isFinal ? ext : step.ext) || ext || "bin").replace(/^\./, "") || "bin";
    const outputBaseName = isFinal ? `${outputBase || "output-preview"}` : `${outputBase || "output-preview"}__${outputRef}`;
    const outputName = `${outputBaseName}.${stepExt}`;
    refs.set(outputRef, outputName);
    previousOutput = outputName;
    const command = buildCommandPreview(resolvedInput, outputBaseName, stepExt, step.args || [], step.tool || "ffmpeg");
    return {
      index: index + 1,
      key: step.key || `step${index + 1}`,
      label: step.label || `Step ${index + 1}`,
      tool: step.tool || "ffmpeg",
      inputRef,
      outputRef,
      outputName,
      args: step.args || [],
      command,
      binary: step.binary || null,
    };
  });
}

function profileMeta(profile: BuilderProfile) {
  switch (profile) {
    case "mov_prores":
      return {
        title: "MOV ProRes",
        ext: "mov",
        mimeType: "video/quicktime",
        label: "MOV ProRes",
        description: "Good for high-quality interchange or master delivery.",
      };
    case "mxf_xdcam":
      return {
        title: "MXF XDCAM HD",
        ext: "mxf",
        mimeType: "application/mxf",
        label: "MXF XDCAM HD",
        description: "Broadcast-style MXF output with MPEG-2 video and PCM audio.",
      };
    case "wav_audio":
      return {
        title: "WAV Audio",
        ext: "wav",
        mimeType: "audio/wav",
        label: "WAV Audio",
        description: "Audio-only output for voice, radio, or delivery checks.",
      };
    case "mp4_h264":
    default:
      return {
        title: "MP4 H.264",
        ext: "mp4",
        mimeType: "video/mp4",
        label: "MP4 H.264",
        description: "Safe default for preview, digital delivery, and general purpose downloads.",
      };
  }
}

function defaultBuilder(profile: BuilderProfile = "mp4_h264"): BuilderState {
  switch (profile) {
    case "mov_prores":
      return {
        profile,
        resolution: "1080",
        fps: "source",
        aspect: "source",
        videoQualityMode: "quality",
        crf: "23",
        videoBitrate: "120M",
        speedPreset: "standard",
        audioBitrate: "192k",
        audioSampleRate: "48000",
        audioChannels: "2",
        customFilter: "",
        customExtraArgs: "",
      };
    case "mxf_xdcam":
      return {
        profile,
        resolution: "1080",
        fps: "25",
        aspect: "16:9",
        videoQualityMode: "bitrate",
        crf: "23",
        videoBitrate: "50M",
        speedPreset: "veryfast",
        audioBitrate: "192k",
        audioSampleRate: "48000",
        audioChannels: "2",
        customFilter: "",
        customExtraArgs: "",
      };
    case "wav_audio":
      return {
        profile,
        resolution: "source",
        fps: "source",
        aspect: "source",
        videoQualityMode: "quality",
        crf: "23",
        videoBitrate: "8M",
        speedPreset: "veryfast",
        audioBitrate: "192k",
        audioSampleRate: "48000",
        audioChannels: "2",
        customFilter: "",
        customExtraArgs: "",
      };
    case "mp4_h264":
    default:
      return {
        profile,
        resolution: "1080",
        fps: "source",
        aspect: "16:9",
        videoQualityMode: "quality",
        crf: "23",
        videoBitrate: "8M",
        speedPreset: "veryfast",
        audioBitrate: "192k",
        audioSampleRate: "48000",
        audioChannels: "2",
        customFilter: "",
        customExtraArgs: "",
      };
  }
}

function buildVideoFilter(builder: BuilderState) {
  const filters: string[] = [];
  if (builder.profile !== "wav_audio") {
    if (builder.resolution !== "source") {
      filters.push(`scale=-2:${builder.resolution}`);
    }
    if (builder.aspect === "16:9") {
      filters.push("setdar=16/9");
    } else if (builder.aspect === "4:3") {
      filters.push("setdar=4/3");
    }
  }
  const custom = String(builder.customFilter || "").trim();
  if (custom) filters.push(custom);
  return filters.join(",");
}

function buildArgsFromBuilder(builder: BuilderState): string[] {
  const args: string[] = [];
  const vf = buildVideoFilter(builder);
  const extra = splitLooseTokens(builder.customExtraArgs);

  if (builder.profile === "wav_audio") {
    args.push("-vn", "-c:a", "pcm_s16le");
    if (builder.audioSampleRate) args.push("-ar", builder.audioSampleRate);
    if (builder.audioChannels !== "source") args.push("-ac", builder.audioChannels);
    return [...args, ...extra];
  }

  if (vf) args.push("-vf", vf);
  if (builder.fps !== "source") args.push("-r", builder.fps);

  if (builder.profile === "mov_prores") {
    args.push("-c:v", "prores_ks", "-profile:v", "3", "-pix_fmt", "yuv422p10le");
    args.push("-c:a", "pcm_s16le");
    if (builder.audioSampleRate) args.push("-ar", builder.audioSampleRate);
    if (builder.audioChannels !== "source") args.push("-ac", builder.audioChannels);
    return [...args, ...extra];
  }

  if (builder.profile === "mxf_xdcam") {
    args.push("-c:v", "mpeg2video");
    if (builder.videoBitrate) {
      args.push("-b:v", builder.videoBitrate, "-minrate", builder.videoBitrate, "-maxrate", builder.videoBitrate);
    }
    args.push("-pix_fmt", "yuv422p", "-g", "12", "-bf", "2");
    args.push("-c:a", "pcm_s16le");
    if (builder.audioSampleRate) args.push("-ar", builder.audioSampleRate);
    if (builder.audioChannels !== "source") args.push("-ac", builder.audioChannels);
    return [...args, ...extra];
  }

  args.push("-c:v", "libx264", "-preset", builder.speedPreset || "veryfast");
  if (builder.videoQualityMode === "bitrate") {
    if (builder.videoBitrate) args.push("-b:v", builder.videoBitrate);
  } else {
    args.push("-crf", builder.crf || "23");
  }
  args.push("-pix_fmt", "yuv420p", "-movflags", "+faststart");
  args.push("-c:a", "aac");
  if (builder.audioBitrate) args.push("-b:a", builder.audioBitrate);
  if (builder.audioSampleRate) args.push("-ar", builder.audioSampleRate);
  if (builder.audioChannels !== "source") args.push("-ac", builder.audioChannels);
  return [...args, ...extra];
}

function makeEditor(mode: EditorMode, item?: PresetLibraryItem | null): EditorState {
  if (!item) {
    const builder = defaultBuilder("mp4_h264");
    return {
      mode,
      key: "",
      label: "",
      ext: profileMeta(builder.profile).ext,
      mimeType: profileMeta(builder.profile).mimeType,
      argsText: argsToText(buildArgsFromBuilder(builder)),
      useGuidedBuilder: true,
      builder,
      previewInputName: "source-input.mov",
      previewOutputBase: "output-preview",
      executionMode: "single",
      tool: "ffmpeg",
      steps: [],
    };
  }

  return {
    mode,
    originalKey: item.key,
    key: mode === "duplicate" ? `${item.key}_copy` : item.key,
    label: mode === "duplicate" ? `${item.label || item.key} Copy` : String(item.label || ""),
    ext: item.ext,
    mimeType: item.mimeType,
    argsText: argsToText(item.args),
    useGuidedBuilder: !isPipelinePreset(item),
    builder: defaultBuilder(item.ext === "mov" ? "mov_prores" : item.ext === "mxf" ? "mxf_xdcam" : item.ext === "wav" ? "wav_audio" : "mp4_h264"),
    previewInputName: "source-input.mov",
    previewOutputBase: mode === "duplicate" ? `${item.key || "preset"}-copy-preview` : `${item.key || "preset"}-preview`,
    executionMode: isPipelinePreset(item) ? "pipeline" : "single",
    tool: String(item.tool || "ffmpeg").trim() || "ffmpeg",
    steps: normalizePresetSteps(item).map((step) => toEditorPipelineStep(step)),
  };
}

function statBadge(label: string, value: number, tone: "neutral" | "warning" = "neutral") {
  const style: CSSProperties = {
    display: "inline-flex",
    alignItems: "center",
    gap: 6,
    padding: "4px 9px",
    borderRadius: 999,
    border: `1px solid ${tone === "warning" ? "rgba(217,119,6,0.22)" : "rgba(15,23,42,0.08)"}`,
    background: tone === "warning" ? "rgba(254,243,199,0.9)" : "rgba(248,250,252,0.95)",
    fontSize: 12,
    fontWeight: 700,
    color: tone === "warning" ? "#92400e" : "#334155",
  };
  return (
    <span style={style}>
      <span>{label}</span>
      <span>{value}</span>
    </span>
  );
}

function smallLabel(text: string) {
  return <span style={{ fontWeight: 700, fontSize: 13 }}>{text}</span>;
}

function buildPresetExportList(items: PresetLibraryItem[]) {
  return items.map((item) => {
    const base: Record<string, any> = {
      key: item.key,
      label: item.label || item.key,
      ext: item.ext,
      mimeType: item.mimeType,
    };

    if (isPipelinePreset(item)) {
      base.steps = normalizePresetSteps(item).map((step, index) => ({
        key: String(step.key || "").trim() || `step${index + 1}`,
        label: String(step.label || "").trim() || null,
        input: String(step.input || "source").trim() || "source",
        output: String(step.output || (index === (item.steps?.length || 1) - 1 ? "final" : `step${index + 1}`)).trim() || (index === (item.steps?.length || 1) - 1 ? "final" : `step${index + 1}`),
        ext: String(step.ext || "").trim() || null,
        tool: String(step.tool || item.tool || "ffmpeg").trim() || "ffmpeg",
        args: Array.isArray(step.args) ? step.args.map((arg) => String(arg ?? "")).filter(Boolean) : [],
      }));
    } else {
      if (item.tool && String(item.tool).trim()) base.tool = String(item.tool).trim();
      base.args = Array.isArray(item.args) ? item.args.map((arg) => String(arg ?? "")).filter(Boolean) : [];
    }

    return base;
  });
}

function sanitizeFileToken(value: string) {
  return String(value || "")
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 40);
}

function downloadJsonFile(filename: string, payload: unknown) {
  const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);
  window.setTimeout(() => URL.revokeObjectURL(url), 1000);
}

export function AdminPresetLibraryPage() {
  const [items, setItems] = useState<PresetLibraryItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [search, setSearch] = useState("");
  const [err, setErr] = useState("");
  const [okMsg, setOkMsg] = useState("");
  const [editor, setEditor] = useState<EditorState | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<PresetLibraryItem | null>(null);

  async function load() {
    setLoading(true);
    setErr("");
    try {
      const res = await listPresetLibrary();
      setItems(Array.isArray(res?.items) ? res.items : []);
    } catch (e: any) {
      setErr(e?.message || "Failed to load presets");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []);

  const filtered = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return items;
    return items.filter((item) => {
      const stepHay = normalizePresetSteps(item).map((step) => `${step.key || ""} ${step.label || ""} ${step.tool || ""} ${step.input || ""} ${step.output || ""} ${(step.args || []).join(" ")}`).join(" ");
      const hay = `${item.key} ${item.label || ""} ${item.ext} ${item.mimeType} ${(item.args || []).join(" ")} ${stepHay}`.toLowerCase();
      return hay.includes(q);
    });
  }, [items, search]);

  const summary = useMemo(() => {
    let inUse = 0;
    let free = 0;
    let activeJobs = 0;
    for (const item of items) {
      if (item.inUse) inUse += 1;
      else free += 1;
      activeJobs += Number(item.usage?.activeJobCount || 0);
    }
    return { total: items.length, inUse, free, activeJobs };
  }, [items]);

  const generatedGuidedArgs = useMemo(() => {
    if (!editor) return [];
    return buildArgsFromBuilder(editor.builder);
  }, [editor]);

  const isPipelineEditor = editor?.executionMode === "pipeline";
  const liveArgs = useMemo(() => {
    if (!editor) return [];
    if (editor.executionMode === "pipeline") {
      const last = editor.steps[editor.steps.length - 1];
      return textToArgs(last?.argsText || "");
    }
    return textToArgs(editor.argsText || "");
  }, [editor]);
  const activeTool = useMemo(() => {
    if (!editor) return "ffmpeg";
    if (editor.executionMode === "pipeline") {
      return String(editor.steps[editor.steps.length - 1]?.tool || editor.tool || "ffmpeg").trim() || "ffmpeg";
    }
    return String(editor.tool || "ffmpeg").trim() || "ffmpeg";
  }, [editor]);
  const previewSummary = useMemo(() => summarizePreset(editor?.ext || "", editor?.mimeType || "", liveArgs), [editor?.ext, editor?.mimeType, liveArgs]);
  const pipelinePreview = useMemo(() => {
    if (editor?.executionMode === "pipeline" && !editor.steps.length) return [];
    return buildPipelineCommandPreview(editor?.previewInputName || "source-input.mov", editor?.previewOutputBase || "output-preview", editor?.ext || "bin", { tool: editor?.tool || undefined, args: editor?.executionMode === "single" ? textToArgs(editor?.argsText || "") : [], steps: (editor?.executionMode === "pipeline" ? editor.steps.map((step, index) => toPresetPipelineStep(step, index)) : []) });
  }, [editor]);
  const commandPreview = useMemo(() => buildCommandPreview(editor?.previewInputName || "source-input.mov", editor?.previewOutputBase || "output-preview", editor?.ext || "bin", liveArgs, activeTool), [editor?.previewInputName, editor?.previewOutputBase, editor?.ext, activeTool, liveArgs]);
  const copyPreviewText = useMemo(() => {
    if (isPipelineEditor) return pipelinePreview.map((step) => step.command).join("\n\n");
    return commandPreview;
  }, [isPipelineEditor, pipelinePreview, commandPreview]);

  async function submitEditor() {
    if (!editor) return;
    setSaving(true);
    setErr("");
    setOkMsg("");
    try {
      const pipelineSteps = editor.executionMode === "pipeline" ? editor.steps.map((step, index) => toPresetPipelineStep(step, index)) : [];
      if (editor.executionMode === "pipeline" && !pipelineSteps.length) {
        throw new Error("Add at least one pipeline step before saving.");
      }
      if (editor.executionMode === "pipeline") {
        const bad = pipelineSteps.findIndex((step) => !step.args?.length);
        if (bad >= 0) throw new Error(`Pipeline step ${bad + 1} has no args.`);
      }

      const payload = {
        key: editor.key,
        label: editor.label || null,
        ext: editor.ext,
        mimeType: editor.mimeType,
        tool: editor.executionMode === "single" ? editor.tool : null,
        args: editor.executionMode === "single" ? textToArgs(editor.argsText) : [],
        steps: pipelineSteps,
      };

      if (editor.mode === "create") {
        await createPresetLibraryItem(payload);
        setOkMsg("Preset added.");
      } else if (editor.mode === "duplicate") {
        await duplicatePresetLibraryItem(String(editor.originalKey || ""), payload);
        setOkMsg("Preset duplicated.");
      } else {
        await updatePresetLibraryItem(String(editor.originalKey || editor.key), {
          label: payload.label,
          ext: payload.ext,
          mimeType: payload.mimeType,
          tool: payload.tool,
          args: payload.args,
          steps: payload.steps,
        });
        setOkMsg("Preset updated.");
      }

      setEditor(null);
      await load();
    } catch (e: any) {
      setErr(e?.message || "Failed to save preset");
    } finally {
      setSaving(false);
    }
  }

  function requestRemoveItem(item: PresetLibraryItem) {
    if (saving || item.inUse) return;
    setDeleteTarget(item);
  }

  async function removeItem(item: PresetLibraryItem) {
    setSaving(true);
    setErr("");
    setOkMsg("");
    try {
      await deletePresetLibraryItem(item.key);
      setDeleteTarget(null);
      setOkMsg("Preset deleted.");
      await load();
    } catch (e: any) {
      setErr(e?.message || "Failed to delete preset");
    } finally {
      setSaving(false);
    }
  }

  function updateEditor(mutator: (prev: EditorState) => EditorState) {
    setEditor((prev) => (prev ? mutator(prev) : prev));
  }

  function setExecutionMode(mode: EditorExecutionMode) {
    updateEditor((prev) => {
      if (prev.executionMode === mode) return prev;
      if (mode === "pipeline") {
        const existing = prev.steps.length ? prev.steps : [createPipelineStep(0, "source", "final", prev.ext)];
        const seeded = existing.length
          ? existing.map((step, index) => index === 0 && !textToArgs(step.argsText).length ? { ...step, tool: prev.tool || step.tool, ext: step.ext || prev.ext, argsText: prev.argsText || step.argsText, input: step.input || "source", output: step.output || "final" } : step)
          : [createPipelineStep(0, "source", "final", prev.ext)];
        return { ...prev, executionMode: mode, useGuidedBuilder: false, steps: seeded };
      }
      const last = prev.steps[prev.steps.length - 1];
      return {
        ...prev,
        executionMode: mode,
        tool: String(last?.tool || prev.tool || "ffmpeg").trim() || "ffmpeg",
        argsText: last?.argsText || prev.argsText,
      };
    });
  }

  function updatePipelineStep(index: number, mutator: (prev: EditorPipelineStep) => EditorPipelineStep) {
    updateEditor((prev) => ({
      ...prev,
      steps: prev.steps.map((step, stepIndex) => (stepIndex === index ? mutator(step) : step)),
    }));
  }

  function addPipelineStep() {
    updateEditor((prev) => {
      const steps = [...prev.steps];
      const nextIndex = steps.length;
      let nextInput = "source";
      if (steps.length) {
        const last = { ...steps[steps.length - 1] };
        if (!String(last.output || "").trim() || String(last.output || "").trim() === "final") {
          last.output = `step${steps.length}`;
          if (!String(last.ext || "").trim()) last.ext = prev.ext;
          steps[steps.length - 1] = last;
        }
        nextInput = last.output || `step${steps.length}`;
      }
      steps.push(createPipelineStep(nextIndex, nextInput, "final", prev.ext));
      return { ...prev, steps, executionMode: "pipeline", useGuidedBuilder: false };
    });
  }

  function movePipelineStep(index: number, direction: -1 | 1) {
    updateEditor((prev) => {
      const nextIndex = index + direction;
      if (nextIndex < 0 || nextIndex >= prev.steps.length) return prev;
      const steps = [...prev.steps];
      const [item] = steps.splice(index, 1);
      steps.splice(nextIndex, 0, item);
      return { ...prev, steps };
    });
  }

  function removePipelineStep(index: number) {
    updateEditor((prev) => {
      const steps = prev.steps.filter((_, stepIndex) => stepIndex !== index);
      return {
        ...prev,
        steps,
        executionMode: steps.length ? "pipeline" : "single",
      };
    });
  }

  function changeBuilderProfile(profile: BuilderProfile) {
    updateEditor((prev) => {
      const builder = defaultBuilder(profile);
      const meta = profileMeta(profile);
      return {
        ...prev,
        builder,
        ext: meta.ext,
        mimeType: meta.mimeType,
        label: prev.mode === "edit" && prev.label ? prev.label : prev.label || meta.label,
        argsText: prev.useGuidedBuilder ? argsToText(buildArgsFromBuilder(builder)) : prev.argsText,
      };
    });
  }

  function downloadVisiblePresetsJson() {
    try {
      const exportItems = buildPresetExportList(filtered);
      const searchToken = sanitizeFileToken(search);
      const dateToken = new Date().toISOString().slice(0, 10);
      const filename = searchToken
        ? `transcode-presets-${searchToken}-${dateToken}.json`
        : `transcode-presets-${dateToken}.json`;
      downloadJsonFile(filename, exportItems);
      setOkMsg(`Downloaded ${exportItems.length} preset${exportItems.length === 1 ? "" : "s"} as JSON.`);
      setErr("");
    } catch (e: any) {
      setErr(e?.message || "Failed to download presets JSON");
    }
  }

  function applyGuidedBuilder() {
    if (!editor) return;
    const meta = profileMeta(editor.builder.profile);
    updateEditor((prev) => ({
      ...prev,
      ext: meta.ext,
      mimeType: meta.mimeType,
      argsText: argsToText(buildArgsFromBuilder(prev.builder)),
    }));
  }

  return (
    <div style={{ display: "grid", gap: 14 }}>
      <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "flex-start", flexWrap: "wrap" }}>
        <div style={{ display: "grid", gap: 4 }}>
          <div style={{ fontWeight: 800, fontSize: 22 }}>Transcode Presets</div>
          <div style={{ fontSize: 13, color: "#64748b", maxWidth: 860 }}>
            Add new transcode presets, edit display names safely, duplicate an existing format, and see where each preset is already used.
            Internal preset keys stay stable so destinations, channels, and transcode flows do not break.
          </div>
        </div>

        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <button onClick={load} disabled={loading || saving}>{loading ? "Loading..." : "Refresh"}</button>
          <button onClick={downloadVisiblePresetsJson} disabled={loading || saving || !filtered.length}>Download JSON</button>
          <button onClick={() => setEditor(makeEditor("create"))} disabled={saving}>Add preset</button>
        </div>
      </div>

      {err ? <div className="card" style={{ border: "1px solid #fecaca", color: "#991b1b" }}>{err}</div> : null}
      {okMsg ? <div className="card" style={{ border: "1px solid rgba(34,197,94,0.25)", color: "#166534" }}>{okMsg}</div> : null}

      <div className="card" style={{ display: "grid", gap: 12 }}>
        <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap", justifyContent: "space-between" }}>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {statBadge("Total", summary.total)}
            {statBadge("In use", summary.inUse, summary.inUse ? "warning" : "neutral")}
            {statBadge("Free", summary.free)}
            {statBadge("Active jobs", summary.activeJobs, summary.activeJobs ? "warning" : "neutral")}
          </div>

          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search by preset name, key, format, mime type"
            style={{ minWidth: 320, maxWidth: 420 }}
          />
        </div>

        <div style={{ fontSize: 12, color: "#64748b" }}>
          Change the <b>display name</b> whenever the client wants a friendlier label. For a new internal key, duplicate the preset instead of renaming the key directly. The <b>Download JSON</b> action exports the presets currently visible on this page in the same JSON-style structure used for preset uploads.
        </div>
      </div>

      <div className="card" style={{ border: "1px solid rgba(59,130,246,0.16)", background: "rgba(239,246,255,0.65)", display: "grid", gap: 8 }}>
        <div style={{ fontWeight: 800 }}>Guided FFmpeg builder</div>
        <div style={{ fontSize: 13, color: "#475569" }}>
          Use the guided builder when the client wants common outputs like MP4 H.264, MOV ProRes, MXF XDCAM, or WAV audio.
          It fills single-step ffmpeg args for you, and you can still fine-tune the final command manually before saving.
        </div>
      </div>

      <div className="card" style={{ overflowX: "auto", padding: 0 }}>
        <table style={{ width: "100%", borderCollapse: "collapse", minWidth: 1080 }}>
          <thead>
            <tr style={{ background: "#f8fafc" }}>
              {[
                "Display name",
                "Internal key",
                "Format",
                "MIME type",
                "Execution",
                "Usage",
                "Actions",
              ].map((label) => (
                <th key={label} style={{ textAlign: "left", padding: "12px 14px", borderBottom: "1px solid #e2e8f0", fontSize: 13 }}>{label}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.length ? filtered.map((item) => {
              const usageText = [
                item.usage?.destinationAllowedCount ? `${item.usage.destinationAllowedCount} destination allow-list` : "",
                item.usage?.destinationDefaultCount ? `${item.usage.destinationDefaultCount} destination default` : "",
                item.usage?.channelDefaultCount ? `${item.usage.channelDefaultCount} channel default` : "",
                item.usage?.activeJobCount ? `${item.usage.activeJobCount} active job` : "",
              ].filter(Boolean).join(" • ") || "Not in use";

              return (
                <tr key={item.key}>
                  <td style={{ padding: "12px 14px", borderBottom: "1px solid #e2e8f0", verticalAlign: "top", minWidth: 260 }}>
                    <div style={{ fontWeight: 800, color: "#0f172a" }}>{item.label || item.key}</div>
                    <div style={{ display: "grid", gap: 6, marginTop: 8 }}>
                      {presetClientFacingDetails(item).map((detail) => (
                        <div key={`${item.key}-${detail.label}`} style={{ display: "grid", gridTemplateColumns: "92px minmax(0, 1fr)", gap: 8, alignItems: "start", fontSize: 12 }}>
                          <div style={{ color: "#64748b", fontWeight: 700 }}>{detail.label}:</div>
                          <div style={{ color: "#334155", lineHeight: 1.45, wordBreak: "break-word" }}>{detail.value}</div>
                        </div>
                      ))}
                    </div>
                  </td>
                  <td style={{ padding: "12px 14px", borderBottom: "1px solid #e2e8f0", verticalAlign: "top" }}>
                    <code>{item.key}</code>
                  </td>
                  <td style={{ padding: "12px 14px", borderBottom: "1px solid #e2e8f0", verticalAlign: "top" }}>
                    <div style={{ fontWeight: 700 }}>{item.ext.toUpperCase()}</div>
                  </td>
                  <td style={{ padding: "12px 14px", borderBottom: "1px solid #e2e8f0", verticalAlign: "top" }}>
                    <code>{item.mimeType}</code>
                  </td>
                  <td style={{ padding: "12px 14px", borderBottom: "1px solid #e2e8f0", verticalAlign: "top" }}>
                    {isPipelinePreset(item) ? (
                      <div style={{ display: "grid", gap: 8, maxWidth: 380 }}>
                        <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
                          <span style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "4px 9px", borderRadius: 999, background: "rgba(219,234,254,0.9)", border: "1px solid rgba(59,130,246,0.2)", color: "#1d4ed8", fontSize: 12, fontWeight: 800 }}>
                            {item.steps?.length || 0} step{(item.steps?.length || 0) === 1 ? "" : "s"}
                          </span>
                          <span style={{ fontSize: 12, color: "#475569", fontWeight: 700 }}>Pipeline preset</span>
                        </div>
                        {normalizePresetSteps(item).map((step, idx) => (
                          <div key={`${item.key}-step-${idx}`} style={{ border: "1px solid rgba(15,23,42,0.08)", borderRadius: 12, padding: "8px 10px", background: "rgba(248,250,252,0.9)" }}>
                            <div style={{ display: "flex", gap: 8, justifyContent: "space-between", alignItems: "center", flexWrap: "wrap" }}>
                              <div style={{ fontSize: 12, fontWeight: 800, color: "#0f172a" }}>{step.label || `Step ${idx + 1}`}</div>
                              <code style={{ fontSize: 11 }}>{step.tool || "ffmpeg"}</code>
                            </div>
                            <div style={{ fontSize: 12, color: "#64748b", marginTop: 4, whiteSpace: "pre-wrap", wordBreak: "break-word" }}>
                              {(step.args || []).slice(0, 6).join(" ") || "No args configured"}
                              {(step.args || []).length > 6 ? " ..." : ""}
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <>
                        <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
                          <div style={{ fontWeight: 700 }}>{item.args?.length || 0} args</div>
                          <code style={{ fontSize: 11 }}>{item.tool || "ffmpeg"}</code>
                        </div>
                        <div style={{ fontSize: 12, color: "#64748b", marginTop: 4, maxWidth: 340, whiteSpace: "pre-wrap" }}>
                          {(item.args || []).slice(0, 6).join(" ") || "No args configured"}
                          {(item.args || []).length > 6 ? " ..." : ""}
                        </div>
                      </>
                    )}
                  </td>
                  <td style={{ padding: "12px 14px", borderBottom: "1px solid #e2e8f0", verticalAlign: "top" }}>
                    <div style={{ fontWeight: item.inUse ? 800 : 700, color: item.inUse ? "#92400e" : "#166534" }}>{usageText}</div>
                    {item.deleteBlockedReason ? (
                      <div style={{ fontSize: 12, color: "#64748b", marginTop: 4, maxWidth: 260 }}>{item.deleteBlockedReason}</div>
                    ) : null}
                  </td>
                  <td style={{ padding: "12px 14px", borderBottom: "1px solid #e2e8f0", verticalAlign: "top" }}>
                    <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                      <button onClick={() => setEditor(makeEditor("edit", item))} disabled={saving}>Edit</button>
                      <button onClick={() => setEditor(makeEditor("duplicate", item))} disabled={saving}>Duplicate</button>
                      <button onClick={() => requestRemoveItem(item)} disabled={saving || item.inUse} title={item.deleteBlockedReason || "Delete preset"}>Delete</button>
                    </div>
                  </td>
                </tr>
              );
            }) : (
              <tr>
                <td colSpan={7} style={{ padding: 20, color: "#64748b" }}>
                  {loading ? "Loading presets..." : "No presets match this search."}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      <div className="card" style={{ display: "grid", gap: 8 }}>
        <div style={{ fontWeight: 800 }}>Safe preset rules</div>
        <div style={{ fontSize: 13, color: "#475569" }}>
          1. Change the display name when the client wants a new label. 2. Use duplicate when you need a new internal preset key. 3. Delete only presets that are not used by any destination, channel, or running job.
        </div>
      </div>



      {deleteTarget ? (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(15,23,42,0.32)",
            display: "grid",
            placeItems: "center",
            padding: 20,
            zIndex: 90,
          }}
          onClick={() => !saving && setDeleteTarget(null)}
        >
          <div
            className="card"
            style={{
              width: "min(520px, 100%)",
              background: "#ffffff",
              border: "1px solid rgba(148,163,184,0.22)",
              boxShadow: "0 20px 50px rgba(15,23,42,0.22)",
              display: "grid",
              gap: 14,
            }}
            onClick={(e) => e.stopPropagation()}
          >
            <div style={{ display: "grid", gap: 6 }}>
              <div style={{ fontWeight: 800, fontSize: 20, color: "#0f172a" }}>Delete preset</div>
              <div style={{ fontSize: 14, color: "#475569", lineHeight: 1.5 }}>
                Are you sure you want to delete <strong>{deleteTarget.label || deleteTarget.key}</strong>? This cannot be undone.
              </div>
            </div>
            <div
              style={{
                display: "flex",
                justifyContent: "flex-end",
                gap: 10,
                flexWrap: "wrap",
                paddingTop: 6,
              }}
            >
              <button
                type="button"
                onClick={() => setDeleteTarget(null)}
                disabled={saving}
                style={{
                  borderRadius: 10,
                  background: "#ffffff",
                  border: "1px solid rgba(148,163,184,0.35)",
                  color: "#334155",
                  fontWeight: 700,
                  padding: "10px 14px",
                }}
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => removeItem(deleteTarget)}
                disabled={saving}
                style={{
                  borderRadius: 10,
                  background: "#dc2626",
                  border: "1px solid #dc2626",
                  color: "#ffffff",
                  fontWeight: 800,
                  padding: "10px 14px",
                }}
              >
                {saving ? "Deleting..." : "Delete"}
              </button>
            </div>
          </div>
        </div>
      ) : null}

      {editor ? (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(15,23,42,0.32)",
            display: "grid",
            placeItems: "center",
            padding: 20,
            zIndex: 80,
          }}
          onClick={() => !saving && setEditor(null)}
        >
          <div
            className="card"
            style={{ width: "min(1040px, 100%)", maxHeight: "min(88vh, 900px)", overflow: "auto", display: "grid", gap: 12 }}
            onClick={(e) => e.stopPropagation()}
          >
            <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "flex-start" }}>
              <div>
                <div style={{ fontWeight: 800, fontSize: 20 }}>
                  {editor.mode === "create" ? "Add preset" : editor.mode === "duplicate" ? "Duplicate preset" : "Edit preset"}
                </div>
                <div style={{ fontSize: 12, color: "#64748b", marginTop: 4 }}>
                  {editor.mode === "edit"
                    ? "Update the client-facing label, extension, mime type, tool, or command args without changing the internal key."
                    : editor.mode === "duplicate"
                      ? "Create a new preset from an existing one, with a new internal key."
                      : "Create a brand new preset in the account library."}
                </div>
              </div>
              <button onClick={() => setEditor(null)} disabled={saving}>Close</button>
            </div>

            <div className="card" style={{ display: "grid", gap: 10, background: "rgba(248,250,252,0.92)", border: "1px solid rgba(148,163,184,0.22)" }}>
              <div style={{ fontWeight: 800 }}>Execution mode</div>
              <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                {([
                  ["single", "Single step"],
                  ["pipeline", "Multi-step pipeline"],
                ] as const).map(([mode, label]) => {
                  const active = editor.executionMode === mode;
                  return (
                    <button
                      key={mode}
                      type="button"
                      onClick={() => setExecutionMode(mode)}
                      disabled={saving}
                      style={{
                        borderRadius: 999,
                        padding: "8px 14px",
                        border: active ? "1px solid rgba(37,99,235,0.45)" : "1px solid rgba(148,163,184,0.28)",
                        background: active ? "rgba(219,234,254,0.95)" : "rgba(255,255,255,0.92)",
                        color: active ? "#1d4ed8" : "#334155",
                        fontWeight: 800,
                      }}
                    >
                      {label}
                    </button>
                  );
                })}
              </div>
              <div style={{ fontSize: 12, color: "#64748b" }}>
                Single-step presets store one command with one tool. Pipeline presets let you add multiple steps and choose <code>ffmpeg</code> or <code>ffmbc</code> per step.
              </div>
            </div>

            {isPipelineEditor ? (
              <div className="card" style={{ display: "grid", gap: 8, background: "rgba(239,246,255,0.72)", border: "1px solid rgba(59,130,246,0.22)" }}>
                <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
                  <span style={{ display: "inline-flex", alignItems: "center", gap: 6, padding: "4px 9px", borderRadius: 999, background: "rgba(219,234,254,0.95)", border: "1px solid rgba(59,130,246,0.22)", color: "#1d4ed8", fontSize: 12, fontWeight: 800 }}>
                    {editor.steps?.length || 0} pipeline step{(editor.steps?.length || 0) === 1 ? "" : "s"}
                  </span>
                  <span style={{ fontSize: 13, fontWeight: 700, color: "#1e3a8a" }}>This preset runs as a multi-step pipeline.</span>
                </div>
                <div style={{ fontSize: 13, color: "#475569" }}>
                  Add or reorder steps below, choose ffmpeg or ffmbc for each step, and keep the last step output as <code>final</code> when you want the worker to write the real download file.
                </div>
              </div>
            ) : null}

            <div style={{ display: "grid", gap: 12, gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))" }}>
              <label style={{ display: "grid", gap: 6 }}>
                {smallLabel("Internal key")}
                <input
                  value={editor.key}
                  onChange={(e) => setEditor((prev) => (prev ? { ...prev, key: e.target.value } : prev))}
                  disabled={saving || editor.mode === "edit"}
                  placeholder="mp4_1080p_h264"
                />
                <span style={{ fontSize: 12, color: "#64748b" }}>
                  Stable identifier used in destinations, channels, and background jobs.
                </span>
              </label>

              <label style={{ display: "grid", gap: 6 }}>
                {smallLabel("Display name")}
                <input
                  value={editor.label}
                  onChange={(e) => setEditor((prev) => (prev ? { ...prev, label: e.target.value } : prev))}
                  disabled={saving}
                  placeholder="MP4 1080p"
                />
                <span style={{ fontSize: 12, color: "#64748b" }}>
                  Friendly label shown to users.
                </span>
              </label>

              <label style={{ display: "grid", gap: 6 }}>
                {smallLabel("Extension")}
                <input
                  value={editor.ext}
                  onChange={(e) => setEditor((prev) => (prev ? { ...prev, ext: e.target.value } : prev))}
                  disabled={saving}
                  placeholder="mp4"
                />
              </label>

              <label style={{ display: "grid", gap: 6 }}>
                {smallLabel("MIME type")}
                <input
                  value={editor.mimeType}
                  onChange={(e) => setEditor((prev) => (prev ? { ...prev, mimeType: e.target.value } : prev))}
                  disabled={saving}
                  placeholder="video/mp4"
                />
              </label>
            </div>

            <div className="card" style={{ display: "grid", gap: 12, background: "rgba(248,250,252,0.95)", border: "1px solid rgba(148,163,184,0.25)" }}>
              <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
                <div>
                  <div style={{ fontWeight: 800 }}>Guided FFmpeg builder</div>
                  <div style={{ fontSize: 12, color: "#64748b", marginTop: 4 }}>
                    Choose a common output family, then apply the generated single-step ffmpeg args into the preset.
                  </div>
                </div>
                <label style={{ display: "inline-flex", gap: 8, alignItems: "center", fontSize: 13, fontWeight: 700, opacity: isPipelineEditor ? 0.6 : 1 }}>
                  <input
                    type="checkbox"
                    checked={editor.useGuidedBuilder}
                    onChange={(e) => updateEditor((prev) => ({ ...prev, useGuidedBuilder: e.target.checked }))}
                    disabled={saving || isPipelineEditor}
                  />
                  Use guided builder
                </label>
              </div>

              {isPipelineEditor ? (
                <div style={{ fontSize: 13, color: "#64748b" }}>
                  Guided builder fills a single-step ffmpeg arg list. Use it for simple presets, or build the multi-step pipeline manually below.
                </div>
              ) : null}

              {editor.useGuidedBuilder && !isPipelineEditor ? (
                <>
                  <div style={{ display: "grid", gap: 12, gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))" }}>
                    <label style={{ display: "grid", gap: 6 }}>
                      {smallLabel("Output family")}
                      <select
                        value={editor.builder.profile}
                        onChange={(e) => changeBuilderProfile(e.target.value as BuilderProfile)}
                        disabled={saving}
                      >
                        <option value="mp4_h264">MP4 H.264</option>
                        <option value="mov_prores">MOV ProRes</option>
                        <option value="mxf_xdcam">MXF XDCAM HD</option>
                        <option value="wav_audio">WAV Audio</option>
                      </select>
                      <span style={{ fontSize: 12, color: "#64748b" }}>{profileMeta(editor.builder.profile).description}</span>
                    </label>

                    <label style={{ display: "grid", gap: 6 }}>
                      {smallLabel("Resolution")}
                      <select
                        value={editor.builder.resolution}
                        onChange={(e) => updateEditor((prev) => ({
                          ...prev,
                          builder: { ...prev.builder, resolution: e.target.value as BuilderResolution },
                        }))}
                        disabled={saving || editor.builder.profile === "wav_audio"}
                      >
                        <option value="source">Keep source</option>
                        <option value="1080">1080p</option>
                        <option value="720">720p</option>
                        <option value="576">576p</option>
                      </select>
                    </label>

                    <label style={{ display: "grid", gap: 6 }}>
                      {smallLabel("Frame rate")}
                      <select
                        value={editor.builder.fps}
                        onChange={(e) => updateEditor((prev) => ({
                          ...prev,
                          builder: { ...prev.builder, fps: e.target.value as BuilderFps },
                        }))}
                        disabled={saving || editor.builder.profile === "wav_audio"}
                      >
                        <option value="source">Keep source</option>
                        <option value="25">25</option>
                        <option value="29.97">29.97</option>
                        <option value="30">30</option>
                      </select>
                    </label>

                    <label style={{ display: "grid", gap: 6 }}>
                      {smallLabel("Aspect")}
                      <select
                        value={editor.builder.aspect}
                        onChange={(e) => updateEditor((prev) => ({
                          ...prev,
                          builder: { ...prev.builder, aspect: e.target.value as BuilderAspect },
                        }))}
                        disabled={saving || editor.builder.profile === "wav_audio"}
                      >
                        <option value="source">Keep source</option>
                        <option value="16:9">16:9</option>
                        <option value="4:3">4:3</option>
                      </select>
                    </label>

                    <label style={{ display: "grid", gap: 6 }}>
                      {smallLabel("Audio channels")}
                      <select
                        value={editor.builder.audioChannels}
                        onChange={(e) => updateEditor((prev) => ({
                          ...prev,
                          builder: { ...prev.builder, audioChannels: e.target.value as BuilderChannels },
                        }))}
                        disabled={saving}
                      >
                        <option value="source">Keep source</option>
                        <option value="1">Mono</option>
                        <option value="2">Stereo</option>
                        <option value="8">8 channels</option>
                      </select>
                    </label>

                    <label style={{ display: "grid", gap: 6 }}>
                      {smallLabel("Audio sample rate")}
                      <input
                        value={editor.builder.audioSampleRate}
                        onChange={(e) => updateEditor((prev) => ({
                          ...prev,
                          builder: { ...prev.builder, audioSampleRate: e.target.value },
                        }))}
                        disabled={saving}
                        placeholder="48000"
                      />
                    </label>
                  </div>

                  {editor.builder.profile === "mp4_h264" ? (
                    <div style={{ display: "grid", gap: 12, gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))" }}>
                      <label style={{ display: "grid", gap: 6 }}>
                        {smallLabel("Video quality mode")}
                        <select
                          value={editor.builder.videoQualityMode}
                          onChange={(e) => updateEditor((prev) => ({
                            ...prev,
                            builder: { ...prev.builder, videoQualityMode: e.target.value as "quality" | "bitrate" },
                          }))}
                          disabled={saving}
                        >
                          <option value="quality">CRF quality</option>
                          <option value="bitrate">Fixed bitrate</option>
                        </select>
                      </label>

                      <label style={{ display: "grid", gap: 6 }}>
                        {smallLabel(editor.builder.videoQualityMode === "quality" ? "CRF" : "Video bitrate")}
                        <input
                          value={editor.builder.videoQualityMode === "quality" ? editor.builder.crf : editor.builder.videoBitrate}
                          onChange={(e) => updateEditor((prev) => ({
                            ...prev,
                            builder: {
                              ...prev.builder,
                              ...(prev.builder.videoQualityMode === "quality"
                                ? { crf: e.target.value }
                                : { videoBitrate: e.target.value }),
                            },
                          }))}
                          disabled={saving}
                          placeholder={editor.builder.videoQualityMode === "quality" ? "23" : "8M"}
                        />
                      </label>

                      <label style={{ display: "grid", gap: 6 }}>
                        {smallLabel("Encoding speed")}
                        <select
                          value={editor.builder.speedPreset}
                          onChange={(e) => updateEditor((prev) => ({
                            ...prev,
                            builder: { ...prev.builder, speedPreset: e.target.value },
                          }))}
                          disabled={saving}
                        >
                          <option value="ultrafast">ultrafast</option>
                          <option value="veryfast">veryfast</option>
                          <option value="fast">fast</option>
                          <option value="medium">medium</option>
                          <option value="slow">slow</option>
                        </select>
                      </label>

                      <label style={{ display: "grid", gap: 6 }}>
                        {smallLabel("Audio bitrate")}
                        <input
                          value={editor.builder.audioBitrate}
                          onChange={(e) => updateEditor((prev) => ({
                            ...prev,
                            builder: { ...prev.builder, audioBitrate: e.target.value },
                          }))}
                          disabled={saving}
                          placeholder="192k"
                        />
                      </label>
                    </div>
                  ) : null}

                  {editor.builder.profile === "mxf_xdcam" ? (
                    <div style={{ display: "grid", gap: 12, gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))" }}>
                      <label style={{ display: "grid", gap: 6 }}>
                        {smallLabel("Video bitrate")}
                        <input
                          value={editor.builder.videoBitrate}
                          onChange={(e) => updateEditor((prev) => ({
                            ...prev,
                            builder: { ...prev.builder, videoBitrate: e.target.value },
                          }))}
                          disabled={saving}
                          placeholder="50M"
                        />
                      </label>
                    </div>
                  ) : null}

                  <div style={{ display: "grid", gap: 12, gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))" }}>
                    <label style={{ display: "grid", gap: 6 }}>
                      {smallLabel("Extra video filter")}
                      <input
                        value={editor.builder.customFilter}
                        onChange={(e) => updateEditor((prev) => ({
                          ...prev,
                          builder: { ...prev.builder, customFilter: e.target.value },
                        }))}
                        disabled={saving}
                        placeholder="Example: pad=1920:1080:(ow-iw)/2:(oh-ih)/2"
                      />
                    </label>

                    <label style={{ display: "grid", gap: 6 }}>
                      {smallLabel("Extra FFmpeg args")}
                      <input
                        value={editor.builder.customExtraArgs}
                        onChange={(e) => updateEditor((prev) => ({
                          ...prev,
                          builder: { ...prev.builder, customExtraArgs: e.target.value },
                        }))}
                        disabled={saving}
                        placeholder="Example: -metadata service_name=eSendIT"
                      />
                    </label>
                  </div>

                  <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
                    <div style={{ fontSize: 12, color: "#64748b" }}>
                      Generated args preview: <code style={{ whiteSpace: "pre-wrap" }}>{generatedGuidedArgs.join(" ") || "No args yet"}</code>
                    </div>
                    <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                      <button type="button" onClick={() => changeBuilderProfile(editor.builder.profile)} disabled={saving}>Reset family defaults</button>
                      <button type="button" onClick={applyGuidedBuilder} disabled={saving}>Replace args from builder</button>
                    </div>
                  </div>
                </>
              ) : null}
            </div>

            {isPipelineEditor ? (
              <div className="card" style={{ display: "grid", gap: 12, background: "rgba(248,250,252,0.92)", border: "1px solid rgba(148,163,184,0.22)" }}>
                <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
                  <div>
                    <div style={{ fontWeight: 800 }}>Pipeline step editor</div>
                    <div style={{ fontSize: 12, color: "#64748b", marginTop: 4 }}>
                      Define each step exactly as the worker should run it. Use <code>source</code> for the first step input and <code>final</code> for the last step output.
                    </div>
                  </div>
                  <button type="button" onClick={addPipelineStep} disabled={saving}>Add step</button>
                </div>

                {editor.steps.length ? (
                  <div style={{ display: "grid", gap: 12 }}>
                    {editor.steps.map((step, index) => (
                      <div key={`editor-step-${index}`} style={{ border: "1px solid rgba(15,23,42,0.08)", borderRadius: 14, padding: 12, background: "rgba(255,255,255,0.92)", display: "grid", gap: 10 }}>
                        <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
                          <div style={{ fontWeight: 800, color: "#0f172a" }}>Step {index + 1}</div>
                          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                            <button type="button" onClick={() => movePipelineStep(index, -1)} disabled={saving || index === 0}>Up</button>
                            <button type="button" onClick={() => movePipelineStep(index, 1)} disabled={saving || index === editor.steps.length - 1}>Down</button>
                            <button type="button" onClick={() => removePipelineStep(index)} disabled={saving}>Remove</button>
                          </div>
                        </div>

                        <div style={{ display: "grid", gap: 12, gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))" }}>
                          <label style={{ display: "grid", gap: 6 }}>
                            {smallLabel("Step key")}
                            <input value={step.key} onChange={(e) => updatePipelineStep(index, (prev) => ({ ...prev, key: e.target.value }))} disabled={saving} placeholder={`step${index + 1}`} />
                          </label>
                          <label style={{ display: "grid", gap: 6 }}>
                            {smallLabel("Step label")}
                            <input value={step.label} onChange={(e) => updatePipelineStep(index, (prev) => ({ ...prev, label: e.target.value }))} disabled={saving} placeholder={`Step ${index + 1}`} />
                          </label>
                          <label style={{ display: "grid", gap: 6 }}>
                            {smallLabel("Tool")}
                            <select value={step.tool} onChange={(e) => updatePipelineStep(index, (prev) => ({ ...prev, tool: e.target.value }))} disabled={saving}>
                              <option value="ffmpeg">ffmpeg</option>
                              <option value="ffmbc">ffmbc</option>
                            </select>
                          </label>
                          <label style={{ display: "grid", gap: 6 }}>
                            {smallLabel("Binary override")}
                            <input value={step.binary} onChange={(e) => updatePipelineStep(index, (prev) => ({ ...prev, binary: e.target.value }))} disabled={saving} placeholder="Optional" />
                          </label>
                          <label style={{ display: "grid", gap: 6 }}>
                            {smallLabel("Input ref")}
                            <input value={step.input} onChange={(e) => updatePipelineStep(index, (prev) => ({ ...prev, input: e.target.value }))} disabled={saving} placeholder="source" />
                          </label>
                          <label style={{ display: "grid", gap: 6 }}>
                            {smallLabel("Output ref")}
                            <input value={step.output} onChange={(e) => updatePipelineStep(index, (prev) => ({ ...prev, output: e.target.value }))} disabled={saving} placeholder={index === editor.steps.length - 1 ? "final" : `step${index + 1}`} />
                          </label>
                          <label style={{ display: "grid", gap: 6 }}>
                            {smallLabel("Intermediate ext")}
                            <input value={step.ext} onChange={(e) => updatePipelineStep(index, (prev) => ({ ...prev, ext: e.target.value }))} disabled={saving} placeholder={index === editor.steps.length - 1 ? editor.ext : "mov"} />
                          </label>
                        </div>

                        <label style={{ display: "grid", gap: 6 }}>
                          {smallLabel("Step args")}
                          <textarea rows={10} value={step.argsText} onChange={(e) => updatePipelineStep(index, (prev) => ({ ...prev, argsText: e.target.value }))} disabled={saving} style={{ width: "100%", fontFamily: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace" }} />
                          <span style={{ fontSize: 12, color: "#64748b" }}>Keep one token per line. Example refs: first step input <code>source</code>, last step output <code>final</code>.</span>
                        </label>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div style={{ fontSize: 13, color: "#64748b" }}>No pipeline steps yet. Click <b>Add step</b> to start the workflow.</div>
                )}

                <div>
                  <div style={{ fontWeight: 800 }}>Pipeline preview</div>
                  <div style={{ fontSize: 12, color: "#64748b", marginTop: 4 }}>This mirrors the execution order the worker will use.</div>
                </div>
                <div style={{ display: "grid", gap: 10 }}>
                  {pipelinePreview.map((step) => (
                    <div key={`pipeline-preview-${step.index}`} style={{ border: "1px solid rgba(15,23,42,0.08)", borderRadius: 14, padding: 12, background: "rgba(255,255,255,0.92)", display: "grid", gap: 8 }}>
                      <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
                        <div style={{ fontWeight: 800, color: "#0f172a" }}>{step.label}</div>
                        <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
                          <code style={{ fontSize: 11 }}>{step.tool}</code>
                          <span style={{ fontSize: 12, color: "#64748b" }}>{step.args.length} args</span>
                        </div>
                      </div>
                      <div style={{ display: "flex", gap: 12, flexWrap: "wrap", fontSize: 12, color: "#64748b" }}>
                        <span>Input ref: <code>{step.inputRef}</code></span>
                        <span>Output ref: <code>{step.outputRef}</code></span>
                      </div>
                      {step.binary ? <div style={{ fontSize: 12, color: "#64748b" }}>Binary override: <code>{step.binary}</code></div> : null}
                      <div style={{ fontSize: 12, color: "#64748b" }}>Output file: <code>{step.outputName}</code></div>
                      <code style={{ whiteSpace: "pre-wrap", wordBreak: "break-word", fontSize: 12, padding: 12, borderRadius: 12, background: "#0f172a", color: "#e2e8f0" }}>
                        {step.command}
                      </code>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <>
                <div style={{ display: "grid", gap: 12, gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))" }}>
                  <label style={{ display: "grid", gap: 6 }}>
                    {smallLabel("Tool")}
                    <select value={editor.tool} onChange={(e) => setEditor((prev) => (prev ? { ...prev, tool: e.target.value } : prev))} disabled={saving}>
                      <option value="ffmpeg">ffmpeg</option>
                      <option value="ffmbc">ffmbc</option>
                    </select>
                  </label>
                </div>
                <label style={{ display: "grid", gap: 6 }}>
                  {smallLabel("Command args")}
                  <textarea
                    rows={14}
                    value={editor.argsText}
                    onChange={(e) => setEditor((prev) => (prev ? { ...prev, argsText: e.target.value } : prev))}
                    disabled={saving}
                    style={{ width: "100%", fontFamily: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace" }}
                  />
                  <span style={{ fontSize: 12, color: "#64748b" }}>
                    Keep one token per line in the exact order you want them sent to the worker. The guided builder only fills this box. You can still edit it manually before saving.
                  </span>
                </label>
              </>
            )}

            <div className="card" style={{ display: "grid", gap: 12, background: "rgba(254,252,232,0.78)", border: "1px solid rgba(234,179,8,0.22)" }}>
              <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
                <div>
                  <div style={{ fontWeight: 800 }}>Preset tester / preview</div>
                  <div style={{ fontSize: 12, color: "#64748b", marginTop: 4 }}>
                    Review the final command before saving. For pipeline presets, the actual worker execution is shown in the pipeline steps section above. This preview does not run ffmpeg/ffmbc or change the backend worker.
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => navigator.clipboard?.writeText(copyPreviewText)}
                  disabled={saving}
                >
                  Copy command
                </button>
              </div>

              <div style={{ display: "grid", gap: 12, gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))" }}>
                <label style={{ display: "grid", gap: 6 }}>
                  {smallLabel("Input file preview")}
                  <input
                    value={editor.previewInputName}
                    onChange={(e) => setEditor((prev) => (prev ? { ...prev, previewInputName: e.target.value } : prev))}
                    disabled={saving}
                    placeholder="source-input.mov"
                  />
                </label>
                <label style={{ display: "grid", gap: 6 }}>
                  {smallLabel("Output file preview")}
                  <input
                    value={editor.previewOutputBase}
                    onChange={(e) => setEditor((prev) => (prev ? { ...prev, previewOutputBase: e.target.value } : prev))}
                    disabled={saving}
                    placeholder="output-preview"
                  />
                </label>
              </div>

              <div style={{ display: "grid", gap: 12, gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))" }}>
                {[
                  ["Format", previewSummary.format],
                  ["MIME type", previewSummary.mimeType || "Not set"],
                  ["Video codec", previewSummary.videoCodec],
                  ["Audio codec", previewSummary.audioCodec],
                  ["Resolution", previewSummary.resolution],
                  ["DAR", previewSummary.dar],
                  ["Frame rate", previewSummary.frameRate],
                  ["Pixel format", previewSummary.pixelFormat || "Keep source/default"],
                  ["Video bitrate", previewSummary.videoBitrate || (previewSummary.crf ? `CRF ${previewSummary.crf}` : "Not set")],
                  ["Audio bitrate", previewSummary.audioBitrate || "Not set"],
                  ["Sample rate", previewSummary.sampleRate],
                  ["Audio channels", previewSummary.channels],
                ].map(([label, value]) => (
                  <div key={String(label)} style={{ border: "1px solid rgba(15,23,42,0.08)", borderRadius: 14, padding: "10px 12px", background: "rgba(255,255,255,0.9)" }}>
                    <div style={{ fontSize: 11, fontWeight: 800, color: "#64748b", textTransform: "uppercase", letterSpacing: 0.4 }}>{label}</div>
                    <div style={{ fontSize: 13, fontWeight: 700, color: "#0f172a", marginTop: 6 }}>{value || "Not set"}</div>
                  </div>
                ))}
              </div>

              <div style={{ display: "grid", gap: 8 }}>
                <div style={{ fontWeight: 700 }}>{isPipelineEditor ? "Last-step / compatibility preview" : "Command preview"}</div>
                <code style={{ whiteSpace: "pre-wrap", wordBreak: "break-word", fontSize: 12, padding: 12, borderRadius: 12, background: "#0f172a", color: "#e2e8f0" }}>
                  {commandPreview}
                </code>
              </div>

              <div style={{ display: "grid", gap: 8 }}>
                <div style={{ fontWeight: 700 }}>Validation</div>
                {previewSummary.warnings.length ? (
                  <div style={{ display: "grid", gap: 6 }}>
                    {previewSummary.warnings.map((warning) => (
                      <div key={warning} style={{ border: "1px solid rgba(217,119,6,0.25)", background: "rgba(255,251,235,0.95)", color: "#92400e", borderRadius: 12, padding: "10px 12px", fontSize: 13 }}>
                        {warning}
                      </div>
                    ))}
                  </div>
                ) : (
                  <div style={{ border: "1px solid rgba(34,197,94,0.22)", background: "rgba(240,253,244,0.95)", color: "#166534", borderRadius: 12, padding: "10px 12px", fontSize: 13 }}>
                    No obvious command issues were detected from the current args.
                  </div>
                )}
              </div>
            </div>

            <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
              <div style={{ fontSize: 12, color: "#64748b" }}>
                Existing destinations and channels keep working because edit mode does not change the internal key.{isPipelineEditor ? " Pipeline steps are preserved on save." : ""}
              </div>
              <div style={{ display: "flex", gap: 8 }}>
                <button onClick={() => setEditor(null)} disabled={saving}>Cancel</button>
                <button onClick={submitEditor} disabled={saving}>{saving ? "Saving..." : editor.mode === "edit" ? "Save changes" : editor.mode === "duplicate" ? "Duplicate preset" : "Add preset"}</button>
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
