import { useEffect, useMemo, useState } from "react";
import { api, type ApiError } from "../../../lib/api";
import { StatusPill } from "../../../ui/StatusPill";

type ChannelRow = {
  id: string;
  name: string;
  destination?: { id: string; name: string } | null;
  mainDeliveryProfile?: { id: string; name: string; protocol: string; lastStatus?: string; lastCheckedAt?: string; lastError?: string } | null;
  backupDeliveryProfile?: { id: string; name: string; protocol: string; lastStatus?: string; lastCheckedAt?: string; lastError?: string } | null;

  serverStatus?: string;
  serverCheckedAt?: string | null;
  serverLatencyMs?: number | null;
  serverMessage?: string | null;
};

export function AdminServerStatusPage() {
  const [rows, setRows] = useState<ChannelRow[]>([]);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [onlyActive, setOnlyActive] = useState(true);

  async function loadChannels() {
    const data = await api<any>("/masters/channels");
    setRows(Array.isArray(data) ? data : (data?.rows ?? []));
  }

  useEffect(() => {
    loadChannels().catch(() => setRows([]));
  }, []);

  const online = useMemo(() => rows.filter(r => (r.serverStatus || "UNKNOWN") === "ONLINE").length, [rows]);
  const offline = useMemo(() => rows.filter(r => (r.serverStatus || "UNKNOWN") === "OFFLINE").length, [rows]);

  async function runAll() {
    setBusy(true);
    setErr("");
    try {
      await api("/admin/server-status/run", {
        method: "POST",
        body: JSON.stringify({ onlyActive }),
      });
      await loadChannels();
    } catch (e: any) {
      setErr((e as ApiError)?.message || "Run failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ display: "grid" }}>
          <div style={{ fontWeight: 700 }}>Server Status</div>
          <div style={{ fontSize: 12, opacity: 0.7 }}>
            Online: {online} • Offline: {offline} • Total: {rows.length}
          </div>
        </div>

        <div className="row" style={{ alignItems: "center" }}>
          <label style={{ fontSize: 12, opacity: 0.8 }}>
            <input
              type="checkbox"
              checked={onlyActive}
              onChange={(e) => setOnlyActive(e.target.checked)}
              disabled={busy}
              style={{ marginRight: 6 }}
            />
            only active channels
          </label>

          <button onClick={runAll} disabled={busy}>
            {busy ? "Checking..." : "Run checks"}
          </button>
          <button onClick={() => loadChannels()} disabled={busy}>Refresh</button>
        </div>
      </div>

      {err && <div className="card" style={{ borderColor: "#f5a", background: "#fff5fa" }}>{err}</div>}

      <div className="card" style={{ padding: 0 }}>
        <table style={{ width: "100%", borderCollapse: "collapse" }}>
          <thead>
            <tr>
              <th style={{ textAlign: "left", padding: 10 }}>Channel</th>
              <th style={{ textAlign: "left", padding: 10 }}>Destination</th>
              <th style={{ textAlign: "left", padding: 10 }}>Main</th>
              <th style={{ textAlign: "left", padding: 10 }}>Backup</th>
              <th style={{ textAlign: "left", padding: 10 }}>Status</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r.id} style={{ borderTop: "1px solid #eee" }}>
                <td style={{ padding: 10 }}>{r.name}</td>
                <td style={{ padding: 10 }}>{r.destination?.name || "—"}</td>

                <td style={{ padding: 10 }}>
                  {r.mainDeliveryProfile ? (
                    <div style={{ display: "grid", gap: 6 }}>
                      <div>{r.mainDeliveryProfile.name} ({r.mainDeliveryProfile.protocol})</div>
                      <StatusPill
                        status={r.mainDeliveryProfile.lastStatus || "UNKNOWN"}
                        title={[
                          r.mainDeliveryProfile.lastCheckedAt ? `Last checked: ${new Date(r.mainDeliveryProfile.lastCheckedAt).toLocaleString()}` : null,
                          r.mainDeliveryProfile.lastError ? `Error: ${r.mainDeliveryProfile.lastError}` : null,
                        ].filter(Boolean).join("\n")}
                      />
                    </div>
                  ) : "—"}
                </td>

                <td style={{ padding: 10 }}>
                  {r.backupDeliveryProfile ? (
                    <div style={{ display: "grid", gap: 6 }}>
                      <div>{r.backupDeliveryProfile.name} ({r.backupDeliveryProfile.protocol})</div>
                      <StatusPill
                        status={r.backupDeliveryProfile.lastStatus || "UNKNOWN"}
                        title={[
                          r.backupDeliveryProfile.lastCheckedAt ? `Last checked: ${new Date(r.backupDeliveryProfile.lastCheckedAt).toLocaleString()}` : null,
                          r.backupDeliveryProfile.lastError ? `Error: ${r.backupDeliveryProfile.lastError}` : null,
                        ].filter(Boolean).join("\n")}
                      />
                    </div>
                  ) : "—"}
                </td>

                <td style={{ padding: 10 }}>
                  <StatusPill
                    status={r.serverStatus || "UNKNOWN"}
                    title={[
                      r.serverCheckedAt ? `Last checked: ${new Date(r.serverCheckedAt).toLocaleString()}` : "Never checked",
                      r.serverLatencyMs != null ? `Latency: ${r.serverLatencyMs}ms` : null,
                      r.serverMessage ? r.serverMessage : null,
                    ].filter(Boolean).join("\n")}
                  />
                </td>
              </tr>
            ))}
            {rows.length === 0 && (
              <tr><td colSpan={5} style={{ padding: 10, opacity: 0.7 }}>No channels</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
