import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { emitMeUpdated, getCreativeCodeLabel, getMe, type MeResponse } from "../../../lib/me";
import { getAccountDownloadPresets, getAccountUiConfig, updateAccountDownloadPresets, updateAccountUiConfig } from "../adminApi";

function pretty(v: any) {
  try {
    return JSON.stringify(v ?? null, null, 2);
  } catch {
    return String(v ?? "");
  }
}

function safeJsonParse(text: string) {
  if (!String(text ?? "").trim()) return [];
  const v = JSON.parse(text);
  return Array.isArray(v) ? v : [];
}

export function AdminAccountSettingsPage() {
  const [me, setMe] = useState<MeResponse | null>(null);
  const [label, setLabel] = useState<string>("");
  const [notificationAdminEmail, setNotificationAdminEmail] = useState<string>("");
  const [notificationAdminOnlyMode, setNotificationAdminOnlyMode] = useState<boolean>(false);
  const [downloadPresetsText, setDownloadPresetsText] = useState<string>("[]");

  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState("");
  const [okMsg, setOkMsg] = useState("");

  async function load() {
    setLoading(true);
    setErr("");
    setOkMsg("");
    try {
      const m = await getMe();
      setMe(m);

      const res: any = await getAccountUiConfig();
      const current = String(res?.uiConfig?.creativeCodeLabel || "").trim();
      setLabel(current);
      setNotificationAdminEmail(String(res?.uiConfig?.notificationAdminEmail || "").trim());
      setNotificationAdminOnlyMode(res?.uiConfig?.notificationAdminOnlyMode === true);

      const p: any = await getAccountDownloadPresets();
      setDownloadPresetsText(pretty(p?.downloadPresets ?? []));
    } catch (e: any) {
      setErr(e?.message || "Failed to load settings");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, []); // eslint-disable-line

  async function save() {
    setSaving(true);
    setErr("");
    setOkMsg("");
    try {
      await updateAccountUiConfig({
        creativeCodeLabel: label || null,
        notificationAdminEmail: notificationAdminEmail || null,
        notificationAdminOnlyMode,
      });
      // download presets are optional; if JSON invalid we show an error before calling api
      let dp: any[] = [];
      try {
        dp = safeJsonParse(downloadPresetsText);
      } catch (e: any) {
        setErr(`Download presets JSON is invalid: ${String(e?.message || e)}`);
        return;
      }
      await updateAccountDownloadPresets({ downloadPresets: dp });
      emitMeUpdated();
      const m = await getMe(true);
      setMe(m);
      setOkMsg("Saved.");
    } catch (e: any) {
      setErr(e?.message || "Save failed");
    } finally {
      setSaving(false);
    }
  }

  const currentLabel = getCreativeCodeLabel(me);

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ display: "grid" }}>
          <div style={{ fontWeight: 800 }}>Account Settings</div>
          <div style={{ fontSize: 12, opacity: 0.7 }}>
            Account-level settings for this account.
          </div>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <button onClick={load} disabled={loading || saving}>{loading ? "Loading..." : "Refresh"}</button>
        </div>
      </div>

      {err ? <div className="card" style={{ border: "1px solid #ffb3b3", color: "#a10000" }}>{err}</div> : null}
      {okMsg ? <div className="card" style={{ border: "1px solid rgba(0,150,0,0.25)", color: "#0b5" }}>{okMsg}</div> : null}

      <div className="card" style={{ display: "grid", gap: 10 }}>
        <div style={{ fontWeight: 800 }}>Creative Code label</div>

        <div style={{ display: "grid", gap: 6 }}>
          <div style={{ fontSize: 12, opacity: 0.75 }}>
            Current label used in UI: <b>{currentLabel}</b>
          </div>

          <div style={{ fontSize: 12, opacity: 0.75 }}>
            Note: This is <b>UI only</b>. Export/import headers and placeholders stay as <code>VALID</code>.
          </div>

          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <input
              value={label}
              onChange={(e) => setLabel(e.target.value)}
              placeholder="e.g. AD-ID / UK-CODE / Creative ID"
              style={{ width: 360 }}
              disabled={saving}
            />
            <button onClick={save} disabled={saving}>
              {saving ? "Saving..." : "Save"}
            </button>
            <button onClick={() => setLabel("")} disabled={saving}>Clear</button>
          </div>

          <div style={{ fontSize: 12, opacity: 0.65 }}>
            Leave empty to use default <b>VALID</b>.
          </div>
        </div>
      </div>

      <div className="card" style={{ display: "grid", gap: 12 }}>
        <div style={{ fontWeight: 800 }}>Admin email copy for all outgoing emails</div>

        <div style={{ display: "grid", gap: 8 }}>
          <div style={{ fontSize: 12, opacity: 0.75 }}>
            Every email sent from this account will also send a separate copy to this admin email.
          </div>

          <div style={{ fontSize: 12, opacity: 0.75 }}>
            Leave empty to disable the extra admin copy.
          </div>

          <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
            <input
              value={notificationAdminEmail}
              onChange={(e) => setNotificationAdminEmail(e.target.value)}
              placeholder="admin@example.com"
              style={{ width: 360 }}
              disabled={saving}
            />
            <button onClick={save} disabled={saving}>
              {saving ? "Saving..." : "Save"}
            </button>
            <button onClick={() => setNotificationAdminEmail("")} disabled={saving}>Clear</button>
          </div>

          <label
            style={{
              display: "flex",
              alignItems: "flex-start",
              gap: 10,
              padding: 12,
              borderRadius: 12,
              border: notificationAdminOnlyMode ? "1px solid rgba(245, 158, 11, 0.45)" : "1px solid rgba(15, 23, 42, 0.12)",
              background: notificationAdminOnlyMode ? "rgba(245, 158, 11, 0.08)" : "rgba(15, 23, 42, 0.03)",
              cursor: saving ? "not-allowed" : "pointer",
            }}
          >
            <input
              type="checkbox"
              checked={notificationAdminOnlyMode}
              onChange={(e) => setNotificationAdminOnlyMode(e.target.checked)}
              disabled={saving}
              style={{ marginTop: 3 }}
            />
            <span style={{ display: "grid", gap: 3 }}>
              <span style={{ fontWeight: 800 }}>Testing mode: send emails only to admin</span>
              <span style={{ fontSize: 12, opacity: 0.75 }}>
                When enabled, outgoing emails are sent only to the admin email above. Normal recipients are skipped until this is turned off.
              </span>
            </span>
          </label>
        </div>
      </div>

      <div className="card" style={{ display: "grid", gap: 10 }}>
        <div style={{ display: "flex", gap: 10, justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap" }}>
          <div style={{ display: "grid" }}>
            <div style={{ fontWeight: 800 }}>Download presets (FFmpeg profiles)</div>
            <div style={{ fontSize: 12, opacity: 0.75 }}>
              Use the new preset manager for normal day-to-day changes. Keep this JSON only for advanced troubleshooting or bulk paste.
            </div>
          </div>

          <Link to="/admin/presets">
            <button type="button">Open preset manager</button>
          </Link>
        </div>

        <textarea
          value={downloadPresetsText}
          onChange={(e) => setDownloadPresetsText(e.target.value)}
          rows={12}
          style={{ width: "100%", fontFamily: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, monospace" }}
          disabled={saving}
        />

        <div style={{ fontSize: 12, opacity: 0.7 }}>
          Each preset should look like: <code>{`{ key, label?, ext, mimeType, args: [...] }`}</code>. You can also set per-destination presets in Masters → Destinations.
        </div>
      </div>
    </div>
  );
}
