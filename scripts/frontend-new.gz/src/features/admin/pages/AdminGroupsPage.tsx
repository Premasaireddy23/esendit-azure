import { useEffect, useMemo, useState } from "react";
import { getMe, hasPerm } from "../../../lib/me";
import { createGroup, getGroup, getGroupsMeta, setGroupMembers, setGroupRoles } from "../adminApi";
import { AdminPageState } from "../AdminPageState";
import { AppModal } from "../../../ui/AppModal";

function getUserDisplay(user: any) {

  return user?.displayName || user?.name || user?.email || "Unknown user";
}

function getInitials(label: string) {
  const cleaned = label.trim();
  const parts = cleaned.split(/\s+/).filter(Boolean);
  if (parts.length >= 2) return `${parts[0][0] || ""}${parts[1][0] || ""}`.toUpperCase();
  return cleaned.slice(0, 2).toUpperCase() || "TM";
}

function getAvatarTone(seed: string) {
  const tones = [
    { background: "linear-gradient(135deg, #dbeafe 0%, #93c5fd 100%)", color: "#1d4ed8" },
    { background: "linear-gradient(135deg, #ede9fe 0%, #c4b5fd 100%)", color: "#6d28d9" },
    { background: "linear-gradient(135deg, #dcfce7 0%, #86efac 100%)", color: "#15803d" },
    { background: "linear-gradient(135deg, #fee2e2 0%, #fca5a5 100%)", color: "#b91c1c" },
    { background: "linear-gradient(135deg, #fae8ff 0%, #f0abfc 100%)", color: "#a21caf" },
    { background: "linear-gradient(135deg, #cffafe 0%, #67e8f9 100%)", color: "#0f766e" },
  ];
  let total = 0;
  for (let i = 0; i < seed.length; i += 1) total += seed.charCodeAt(i);
  return tones[total % tones.length];
}

function normalizeTeamSearchValue(value: string) {
  return value.trim().toLowerCase();
}

function teamSearchScore(group: any, query: string) {
  const search = normalizeTeamSearchValue(query);
  if (!search) return 0;

  const name = String(group?.name || "").toLowerCase();
  const description = String(group?.description || "").toLowerCase();
  if (!name && !description) return Number.POSITIVE_INFINITY;

  if (name === search) return 0;
  if (name.startsWith(search)) return 1;
  if (name.includes(search)) return 2;
  if (description.startsWith(search)) return 3;
  if (description.includes(search)) return 4;
  return Number.POSITIVE_INFINITY;
}

function roleSearchScore(role: any, query: string) {
  const search = normalizeTeamSearchValue(query);
  if (!search) return 0;

  const name = String(role?.name || "").toLowerCase();
  const description = String(role?.description || "").toLowerCase();
  if (!name && !description) return Number.POSITIVE_INFINITY;

  if (name === search) return 0;
  if (name.startsWith(search)) return 1;
  if (name.includes(search)) return 2;
  if (description.startsWith(search)) return 3;
  if (description.includes(search)) return 4;
  return Number.POSITIVE_INFINITY;
}

function mapsEqual(a: Record<string, boolean>, b: Record<string, boolean>) {
  const keys = new Set([...Object.keys(a), ...Object.keys(b)]);
  for (const key of keys) {
    if (!!a[key] !== !!b[key]) return false;
  }
  return true;
}

export function AdminGroupsPage() {
  const [pageState, setPageState] = useState<"loading" | "ready" | "denied" | "error">("loading");
  const [pageError, setPageError] = useState<any>(null);
  const [canWrite, setCanWrite] = useState(false);

  const [meta, setMeta] = useState<any | null>(null);
  const [selectedGroupId, setSelectedGroupId] = useState<string>("");
  const [teamSearch, setTeamSearch] = useState("");
  const [group, setGroup] = useState<any | null>(null);
  const [teamModalOpen, setTeamModalOpen] = useState(false);

  const [newName, setNewName] = useState("");
  const [newDesc, setNewDesc] = useState("");

  const [roleChecked, setRoleChecked] = useState<Record<string, boolean>>({});
  const [memberChecked, setMemberChecked] = useState<Record<string, boolean>>({});
  const [savedRoleChecked, setSavedRoleChecked] = useState<Record<string, boolean>>({});
  const [savedMemberChecked, setSavedMemberChecked] = useState<Record<string, boolean>>({});

  const [roleQuery, setRoleQuery] = useState("");
  const [memberQuery, setMemberQuery] = useState("");
  const [statusMsg, setStatusMsg] = useState<string>("");

  async function refreshMeta() {
    setPageError(null);
    const me = await getMe(true);
    const readOk = hasPerm(me, "ADMIN_GROUPS_READ");
    setCanWrite(hasPerm(me, "ADMIN_GROUPS_WRITE"));
    if (!readOk) {
      setPageState("denied");
      return;
    }

    try {
      const m = await getGroupsMeta();
      setMeta(m);
      setPageState("ready");
    } catch (error) {
      setPageError(error);
      setPageState("error");
      throw error;
    }
  }

  async function refreshGroup(id: string) {
    if (!id) {
      setGroup(null);
      setRoleChecked({});
      setMemberChecked({});
      setSavedRoleChecked({});
      setSavedMemberChecked({});
      return;
    }
    const g = await getGroup(id);
    setGroup(g);

    const nextRole: Record<string, boolean> = {};
    for (const r of meta?.roles ?? []) nextRole[r.id] = false;
    for (const r of g.roles ?? []) nextRole[r.id] = true;
    setRoleChecked(nextRole);
    setSavedRoleChecked(nextRole);

    const nextMem: Record<string, boolean> = {};
    for (const u of meta?.users ?? []) nextMem[u.id] = false;
    for (const u of g.members ?? []) nextMem[u.id] = true;
    setMemberChecked(nextMem);
    setSavedMemberChecked(nextMem);
  }

  useEffect(() => {
    refreshMeta().catch(() => undefined);
  }, []);

  useEffect(() => {
    if (!meta?.groups?.length) return;
    if (!selectedGroupId) setSelectedGroupId(meta.groups[0].id);
  }, [meta?.groups?.length, selectedGroupId]);

  useEffect(() => {
    if (pageState !== "ready" || !meta) return;
    refreshGroup(selectedGroupId).catch(() => undefined);
  }, [selectedGroupId, meta, pageState]);

  const filteredRoles = useMemo(() => {
    const search = normalizeTeamSearchValue(roleQuery);
    const ranked = [...(meta?.roles ?? [])]
      .map((role: any) => ({ role, score: roleSearchScore(role, search) }))
      .filter((item) => !search || Number.isFinite(item.score))
      .sort((a, b) => {
        if (a.score !== b.score) return a.score - b.score;
        const aChecked = !!roleChecked[a.role?.id];
        const bChecked = !!roleChecked[b.role?.id];
        if (aChecked !== bChecked) return aChecked ? -1 : 1;
        return String(a.role?.name || "").localeCompare(String(b.role?.name || ""));
      });

    return ranked.map((item) => item.role);
  }, [meta?.roles, roleQuery, roleChecked]);

  const filteredUsers = useMemo(() => {
    const q = memberQuery.trim().toLowerCase();
    const users = meta?.users ?? [];
    if (!q) return users;
    return users.filter((u: any) => `${u.email} ${getUserDisplay(u)}`.toLowerCase().includes(q));
  }, [meta?.users, memberQuery]);

  const roleChangesPending = useMemo(() => !mapsEqual(roleChecked, savedRoleChecked), [roleChecked, savedRoleChecked]);
  const memberChangesPending = useMemo(() => !mapsEqual(memberChecked, savedMemberChecked), [memberChecked, savedMemberChecked]);

  const filteredGroups = useMemo(() => {
    const search = normalizeTeamSearchValue(teamSearch);
    const ranked = [...(meta?.groups ?? [])]
      .map((group: any) => ({ group, score: teamSearchScore(group, search) }))
      .filter((item) => !search || Number.isFinite(item.score))
      .sort((a, b) => {
        if (a.score != b.score) return a.score - b.score;
        return String(a.group?.name || "").localeCompare(String(b.group?.name || ""));
      });

    return ranked.slice(0, search ? 8 : 12).map((item) => item.group);
  }, [meta?.groups, teamSearch]);

  if (pageState === "denied") return <AdminPageState kind="denied" sectionLabel="Teams" />;
  if (pageState === "error") return <AdminPageState kind="error" sectionLabel="Teams" error={pageError} />;
  if (pageState === "loading") return <div className="card" style={{ padding: 16 }}>Loading teams…</div>;

  async function onCreateGroup() {
    const name = newName.trim();
    if (!name) return;

    const created = await createGroup({ name, description: newDesc.trim() || undefined });
    setNewName("");
    setNewDesc("");
    await refreshMeta();
    setSelectedGroupId(created.id);
    setTeamModalOpen(true);
    setStatusMsg("Team created ✓");
    setTimeout(() => setStatusMsg(""), 1800);
  }

  async function onSaveRoles() {
    if (!selectedGroupId) return;
    const roleIds = Object.entries(roleChecked)
      .filter(([, v]) => v)
      .map(([k]) => k);

    await setGroupRoles(selectedGroupId, roleIds);
    await refreshMeta();
    await refreshGroup(selectedGroupId);
    setStatusMsg("Team access profiles saved ✓");
    setTimeout(() => setStatusMsg(""), 1800);
  }

  async function onSaveMembers() {
    if (!selectedGroupId) return;
    const userIds = Object.entries(memberChecked)
      .filter(([, v]) => v)
      .map(([k]) => k);

    await setGroupMembers(selectedGroupId, userIds);
    await refreshMeta();
    await refreshGroup(selectedGroupId);
    setStatusMsg("Team members saved ✓");
    setTimeout(() => setStatusMsg(""), 1800);
  }

  function openTeamModal(groupId: string) {
    setSelectedGroupId(groupId);
    setRoleQuery("");
    setMemberQuery("");
    setTeamModalOpen(true);
  }

  function closeTeamModal() {
    setTeamModalOpen(false);
    setRoleQuery("");
    setMemberQuery("");
  }

  const pendingSaveButtonStyle = (dirty: boolean) => ({
    borderColor: dirty ? "rgba(79,70,229,0.45)" : undefined,
    background: dirty ? "rgba(79,70,229,0.12)" : undefined,
    color: dirty ? "#312e81" : undefined,
    fontWeight: dirty ? 800 : undefined,
    boxShadow: dirty ? "0 0 0 3px rgba(79,70,229,0.10)" : undefined,
  });

  return (
    <>
      <div style={{ display: "grid", gap: 14 }}>
        <div>
          <h3 style={{ margin: 0 }}>Teams</h3>
        </div>

        <div className="card" style={{ padding: 12, display: "grid", gap: 10 }}> 
          <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
            <div>
              <div style={{ fontWeight: 800 }}>Create team</div>
            </div>
            {statusMsg ? (
              <div style={{ padding: "6px 10px", borderRadius: 8, fontSize: 12, border: "1px solid rgba(34,197,94,0.25)", background: "rgba(34,197,94,0.12)" }}>
                {statusMsg}
              </div>
            ) : null}
          </div>

          <div style={{ display: "grid", gap: 8, gridTemplateColumns: "1fr 2fr auto" }}>
            <input placeholder="Team name" value={newName} onChange={(e) => setNewName(e.target.value)} disabled={!canWrite} />
            <input placeholder="Description" value={newDesc} onChange={(e) => setNewDesc(e.target.value)} disabled={!canWrite} />
            <button onClick={onCreateGroup} disabled={!canWrite || !newName.trim()}>
              Create team
            </button>
          </div>
        </div>

        <div className="card" style={{ padding: 12, display: "grid", gap: 12 }}>
          <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
            <div>
              <div style={{ fontWeight: 800 }}>Team list</div>
            </div>
            <input
              placeholder="Search team..."
              value={teamSearch}
              onChange={(e) => setTeamSearch(e.target.value)}
              style={{ width: "100%", maxWidth: 280 }}
            />
          </div>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))",
              gap: 18,
            }}
          >
            {filteredGroups.length ? (
              filteredGroups.map((g: any) => {
                const active = g.id === selectedGroupId && teamModalOpen;
                const teamName = String(g?.name || "Team");
                const avatarTone = getAvatarTone(teamName || g.id);
                const initials = getInitials(teamName);
                return (
                  <div
                    key={g.id}
                    style={{
                      position: "relative",
                      borderRadius: 22,
                      border: active ? "1px solid rgba(79,70,229,0.22)" : "1px solid rgba(15,23,42,0.08)",
                      background: active ? "linear-gradient(180deg, #ffffff 0%, rgba(238,242,255,0.82) 100%)" : "#ffffff",
                      boxShadow: active ? "0 14px 30px rgba(79,70,229,0.10)" : "0 10px 24px rgba(15,23,42,0.05)",
                      padding: 18,
                      minHeight: 154,
                      display: "grid",
                      gap: 14,
                    }}
                  >
                    <button
                      type="button"
                      onClick={() => openTeamModal(g.id)}
                      title="Open team"
                      style={{
                        position: "absolute",
                        top: 14,
                        right: 14,
                        width: 34,
                        height: 34,
                        borderRadius: 999,
                        border: active ? "1px solid rgba(79,70,229,0.20)" : "1px solid rgba(15,23,42,0.08)",
                        background: "#ffffff",
                        display: "inline-flex",
                        alignItems: "center",
                        justifyContent: "center",
                        fontSize: 18,
                        fontWeight: 800,
                        lineHeight: 1,
                        boxShadow: "0 8px 18px rgba(15,23,42,0.08)",
                        cursor: "pointer",
                      }}
                    >
                      ⋯
                    </button>

                    <div style={{ display: "flex", alignItems: "center", gap: 14, minWidth: 0, paddingRight: 38 }}>
                      <div
                        aria-hidden="true"
                        style={{
                          width: 62,
                          height: 62,
                          borderRadius: "50%",
                          background: avatarTone.background,
                          color: avatarTone.color,
                          display: "grid",
                          placeItems: "center",
                          fontWeight: 800,
                          fontSize: 22,
                          letterSpacing: 0.5,
                          flexShrink: 0,
                          boxShadow: "inset 0 1px 0 rgba(255,255,255,0.6)",
                        }}
                      >
                        {initials}
                      </div>

                      <div style={{ minWidth: 0, display: "grid", gap: 4 }}>
                        <div
                          style={{
                            fontWeight: 800,
                            fontSize: 16,
                            lineHeight: 1.2,
                            color: "#0f172a",
                            whiteSpace: "nowrap",
                            overflow: "hidden",
                            textOverflow: "ellipsis",
                          }}
                          title={teamName}
                        >
                          {teamName}
                        </div>
                        <div
                          style={{
                            fontSize: 13,
                            color: "#475569",
                            lineHeight: 1.35,
                            display: "-webkit-box",
                            WebkitLineClamp: 2,
                            WebkitBoxOrient: "vertical",
                            overflow: "hidden",
                            maxWidth: "100%",
                          }}
                          title={g?.description || ""}
                        >
                          {g?.description || ""}
                        </div>
                      </div>
                    </div>

                    <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                      <span
                        style={{
                          padding: "4px 10px",
                          borderRadius: 999,
                          background: active ? "rgba(79,70,229,0.10)" : "#ffffff",
                          border: "1px solid rgba(99,102,241,0.26)",
                          color: "#4f46e5",
                          fontSize: 11,
                          fontWeight: 600,
                          lineHeight: 1.2,
                        }}
                      >
                        {g.memberCount} people
                      </span>
                      <span
                        style={{
                          padding: "4px 10px",
                          borderRadius: 999,
                          background: active ? "rgba(15,23,42,0.04)" : "#ffffff",
                          border: "1px solid rgba(15,23,42,0.10)",
                          color: "#334155",
                          fontSize: 11,
                          fontWeight: 600,
                          lineHeight: 1.2,
                        }}
                      >
                        {g.roleCount} access profiles
                      </span>
                    </div>
                  </div>
                );
              })
            ) : (
              <div style={{ padding: 18, borderRadius: 16, border: "1px dashed rgba(15,23,42,0.12)", color: "#64748b", background: "rgba(248,250,252,0.8)" }}>
                No teams matched your search.
              </div>
            )}
          </div>
        </div>
      </div>

      {teamModalOpen && selectedGroupId ? (
        <AppModal
          open={teamModalOpen}
          title={group?.name || "Team"}
          subtitle={group?.description || ""}
          onClose={closeTeamModal}
          width="xxl"
          bodyClassName="app-modal__stack"
        >
          <div className="app-modal__pills">
            <span className="app-modal__pill">{(group?.roles ?? []).length} access profiles</span>
            <span className="app-modal__pill">{(group?.members ?? []).length} team members</span>
          </div>

          <div className="app-modal__split">
            <div className="app-modal__section app-modal__section--equal">
              <div className="app-modal__section-head">
                <div className="app-modal__section-title">Access profiles for this team</div>
              </div>

              <input
                placeholder="Search access profiles..."
                value={roleQuery}
                onChange={(e) => setRoleQuery(e.target.value)}
                style={{ width: "100%" }}
              />

              <div className="app-modal__scroll-panel app-modal__scroll-panel--fill">
                <div style={{ display: "grid", gap: 8 }}>
                  {filteredRoles.length ? filteredRoles.map((r: any) => (
                    <label key={r.id} style={{ display: "grid", gridTemplateColumns: "18px 1fr", gap: 8, alignItems: "start", padding: "6px 0" }}>
                      <input
                        type="checkbox"
                        checked={!!roleChecked[r.id]}
                        onChange={(e) => setRoleChecked((prev) => ({ ...prev, [r.id]: e.target.checked }))}
                      />
                      <span>
                        <span style={{ display: "block", fontWeight: 700 }}>{r.name}</span>
                        {r.description ? <span style={{ display: "block", fontSize: 12, opacity: 0.72 }}>{r.description}</span> : null}
                      </span>
                    </label>
                  )) : (
                    <div style={{ fontSize: 13, color: "#64748b" }}>No access profiles matched your search.</div>
                  )}
                </div>
              </div>
              <div>
                <button onClick={onSaveRoles} disabled={!canWrite} style={pendingSaveButtonStyle(roleChangesPending)}>
                  {roleChangesPending ? "Save team access profiles changes" : "Save team access profiles"}
                </button>
              </div>
            </div>

            <div className="app-modal__section app-modal__section--equal">
              <div className="app-modal__section-head">
                <div className="app-modal__section-title">Team members</div>
              </div>

              <input placeholder="Search people..." value={memberQuery} onChange={(e) => setMemberQuery(e.target.value)} style={{ width: "100%" }} />

              <div className="app-modal__scroll-panel app-modal__scroll-panel--fill">
                {filteredUsers.map((u: any) => (
                  <label key={u.id} style={{ display: "grid", gridTemplateColumns: "18px 1fr", gap: 8, alignItems: "start", padding: "5px 0" }}>
                    <input
                      type="checkbox"
                      checked={!!memberChecked[u.id]}
                      onChange={(e) => setMemberChecked((prev) => ({ ...prev, [u.id]: e.target.checked }))}
                    />
                    <span style={{ opacity: u.isActive ? 1 : 0.6 }}>
                      <span style={{ display: "block", fontWeight: 700 }}>{getUserDisplay(u)}</span>
                      <span style={{ display: "block", fontSize: 12, opacity: 0.72 }}>{u.email} {!u.isActive ? "• inactive" : ""}</span>
                    </span>
                  </label>
                ))}
              </div>

              <div>
                <button onClick={onSaveMembers} disabled={!canWrite} style={pendingSaveButtonStyle(memberChangesPending)}>
                  {memberChangesPending ? "Save team members changes" : "Save team members"}
                </button>
              </div>
            </div>
          </div>
        </AppModal>
      ) : null}
    </>
  );
}
