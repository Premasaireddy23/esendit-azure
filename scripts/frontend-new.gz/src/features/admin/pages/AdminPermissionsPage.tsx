import { useEffect, useMemo, useState } from "react";
import { listPermissions } from "../adminApi";
import { groupPermissions, isLegacyOrInvalidKey, permissionDisplayName, type PermissionRow } from "../permissionsUi";

export function AdminPermissionsPage() {
  const [perms, setPerms] = useState<PermissionRow[]>([]);
  const [view, setView] = useState<"modules" | "raw">("modules");
  const [q, setQ] = useState("");
  const [showLegacy, setShowLegacy] = useState(false);
  const groups = useMemo(() => groupPermissions(perms, { includeLegacy: showLegacy, query: q }), [perms, showLegacy, q]);

  const ACCENT = "#ff2d7a";
  const DOT_ACTIVE = "#22c55e";
  const DOT_INACTIVE = "#94a3b8";

  const viewBtnStyle = (active: boolean) => ({
    display: "inline-flex",
    alignItems: "center",
    gap: 8,
    padding: "7px 12px",
    borderRadius: 999,
    border: `2px solid ${active ? ACCENT : "rgba(0,0,0,0.12)"}`,
    background: "white",
    fontWeight: active ? 800 : 700,
    boxShadow: active ? "0 0 0 2px rgba(255,45,122,0.12)" : "none",
  });

  const dotStyle = (active: boolean) => ({
    width: 10,
    height: 10,
    borderRadius: 999,
    background: active ? DOT_ACTIVE : DOT_INACTIVE,
    flex: "0 0 auto",
  });

  useEffect(() => {
    listPermissions().then(setPerms);
  }, []);

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div>
        <h3 style={{ margin: 0 }}>Permission Library</h3>
      </div>

      <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
        <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
          <button type="button" onClick={() => setView("modules")} style={viewBtnStyle(view === "modules")}>
            <span style={dotStyle(view === "modules")} />
            <span>Business area view</span>
          </button>
          <button type="button" onClick={() => setView("raw")} style={viewBtnStyle(view === "raw")}>
            <span style={dotStyle(view === "raw")} />
            <span>Raw technical list</span>
          </button>
        </div>

        <input
          placeholder="Search permissions (key or name)"
          value={q}
          onChange={(e) => setQ(e.target.value)}
          style={{ minWidth: 280 }}
        />
        <label style={{ display: "flex", gap: 6, alignItems: "center", fontSize: 12, opacity: 0.9 }}>
          <input type="checkbox" checked={showLegacy} onChange={(e) => setShowLegacy(e.target.checked)} />
          Show legacy / unknown keys
        </label>
      </div>

      <div className="card" style={{ padding: 10 }}>
        {view === "raw" ? (
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr>
                <th align="left">Name</th>
                <th align="left">Key</th>
                <th align="left">Type</th>
              </tr>
            </thead>
            <tbody>
              {groups
                .flatMap((g) => g.items)
                .map((p) => {
                  const label = permissionDisplayName(p);
                  const legacy = isLegacyOrInvalidKey(p.key);
                  return (
                    <tr key={p.id} style={legacy ? { opacity: 0.75 } : undefined}>
                      <td style={{ padding: "6px 0", fontWeight: 600 }}>{label}</td>
                      <td style={{ padding: "6px 0", fontFamily: "monospace", fontSize: 12 }}>{p.key}</td>
                      <td style={{ padding: "6px 0", fontSize: 12 }}>{p.type}</td>
                    </tr>
                  );
                })}
            </tbody>
          </table>
        ) : (
          <>
            {groups.map((g) => (
              <div key={g.key} style={{ marginBottom: 14 }}>
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
                  <div style={{ fontWeight: 800 }}>{g.title}</div>
                  <div style={{ fontSize: 12, opacity: 0.7 }}>{g.items.length} permissions</div>
                </div>

                <table style={{ width: "100%", borderCollapse: "collapse", marginTop: 6 }}>
                  <thead>
                    <tr>
                      <th align="left">Name</th>
                      <th align="left">Key</th>
                      <th align="left">Type</th>
                    </tr>
                  </thead>
                  <tbody>
                    {g.items.map((p) => {
                      const label = permissionDisplayName(p);
                      const legacy = isLegacyOrInvalidKey(p.key);
                      return (
                        <tr key={p.id} style={legacy ? { opacity: 0.75 } : undefined}>
                          <td style={{ padding: "6px 0", fontWeight: 600 }}>{label}</td>
                          <td style={{ padding: "6px 0", fontFamily: "monospace", fontSize: 12 }}>{p.key}</td>
                          <td style={{ padding: "6px 0", fontSize: 12 }}>{p.type}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            ))}
          </>
        )}
      </div>
    </div>
  );
}
