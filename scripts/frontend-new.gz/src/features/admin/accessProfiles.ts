import { canonicalizePermissionKey } from "../../lib/permissions";
import { inferGroupKey, isReadLikeKey, type PermissionRow } from "./permissionsUi";

export type AccessTemplate = {
  id:
    | "account-admin"
    | "sender-operations"
    | "agency-collaborator"
    | "receiver-viewer"
    | "masters-manager"
    | "read-only";
  name: string;
  description: string;
  bestFor: string;
  examples: string[];
};

export const ACCESS_TEMPLATES: AccessTemplate[] = [
  {
    id: "account-admin",
    name: "Account Admin",
    description: "Full access across admin, projects, masters, operations, and account setup.",
    bestFor: "The client owner or platform administrator.",
    examples: ["Account owner", "Platform admin", "Client super user"],
  },
  {
    id: "sender-operations",
    name: "Sender Operations",
    description: "Can manage day-to-day project flow, planner work, approvals, sending, and notifications.",
    bestFor: "Internal operations teams who prepare and send deliveries.",
    examples: ["Sender ops", "Traffic team", "Transmission team"],
  },
  {
    id: "agency-collaborator",
    name: "Agency Collaborator",
    description: "Can view project progress and take part in approvals without deep admin access.",
    bestFor: "Media, creative, post, production, or audio agency users.",
    examples: ["Media agency", "Creative agency", "Post house"],
  },
  {
    id: "receiver-viewer",
    name: "Receiver / Client Viewer",
    description: "Read-only visibility for projects, sends, notifications, and approval progress.",
    bestFor: "Receiver accounts, client reviewers, or status-only stakeholders.",
    examples: ["Receiver QA", "Client viewer", "Destination contact"],
  },
  {
    id: "masters-manager",
    name: "Master Data Manager",
    description: "Can maintain agencies, destinations, account setup, and related master data.",
    bestFor: "Teams that own setup data, destinations, rates, and configurations.",
    examples: ["Master data team", "Setup admin", "Operations setup"],
  },
  {
    id: "read-only",
    name: "Read Only",
    description: "View-only access wherever read permissions exist. No operational changes.",
    bestFor: "Leadership, auditors, external viewers, and support observers.",
    examples: ["Read only", "Audit viewer", "Management viewer"],
  },
];

function isViewPermission(p: PermissionRow) {
  return String(p.type || "").toUpperCase() === "PAGE" || isReadLikeKey(p.key);
}

function selectGroupPermissions(perms: PermissionRow[], groupKeys: string[], mode: "view" | "full") {
  return perms
    .filter((p) => groupKeys.includes(inferGroupKey(p)) && (mode === "full" || isViewPermission(p)))
    .map((p) => p.key);
}

function dedupe(keys: string[]) {
  return [...new Set(keys.filter(Boolean))].sort((a, b) => a.localeCompare(b));
}

export function buildTemplatePermissionKeys(perms: PermissionRow[], templateId: AccessTemplate["id"]) {
  if (!Array.isArray(perms) || perms.length === 0) return [];

  switch (templateId) {
    case "account-admin":
      return dedupe(perms.map((p) => p.key));

    case "sender-operations":
      return dedupe([
        ...selectGroupPermissions(perms, ["projects", "planner", "approvals", "orders", "notifications"], "full"),
        ...selectGroupPermissions(perms, ["masters", "library", "presets", "bulk", "billing"], "view"),
      ]);

    case "agency-collaborator":
      return dedupe([
        ...selectGroupPermissions(perms, ["projects", "stakeholder", "planner", "orders", "notifications", "library", "presets"], "view"),
        ...selectGroupPermissions(perms, ["approvals"], "full"),
      ]);

    case "receiver-viewer":
      return dedupe([
        ...selectGroupPermissions(perms, ["projects", "stakeholder", "orders", "notifications", "approvals"], "view"),
      ]);

    case "masters-manager":
      return dedupe([
        ...selectGroupPermissions(perms, ["masters", "billing", "account"], "full"),
        ...selectGroupPermissions(perms, ["projects", "notifications"], "view"),
      ]);

    case "read-only":
      return dedupe(perms.filter((p) => isViewPermission(p)).map((p) => p.key));

    default:
      return [];
  }
}

export function summarizeAccessCoverage(allPerms: PermissionRow[], selectedKeys: string[]) {
  const selectedCanon = new Set(selectedKeys.map((k) => canonicalizePermissionKey(k)));
  const groups = [
    "projects",
    "stakeholder",
    "planner",
    "approvals",
    "orders",
    "masters",
    "library",
    "presets",
    "bulk",
    "notifications",
    "billing",
    "account",
    "admin",
    "server",
  ];

  return groups
    .map((groupKey) => {
      const items = allPerms.filter((p) => inferGroupKey(p) === groupKey);
      if (!items.length) return null;

      const total = items.length;
      const selected = items.filter((p) => selectedCanon.has(canonicalizePermissionKey(p.key)));
      const selectedCount = selected.length;
      const viewCount = selected.filter((p) => isViewPermission(p)).length;

      let level: "No access" | "View only" | "Manage" | "Custom" = "No access";
      if (selectedCount === 0) level = "No access";
      else if (selectedCount === total) level = "Manage";
      else if (selectedCount === viewCount) level = "View only";
      else level = "Custom";

      return {
        groupKey,
        title:
          groupKey === "orders"
            ? "Orders & Send"
            : groupKey === "presets"
            ? "Transcode Presets"
            : groupKey === "library"
            ? "DAM"
            : groupKey === "bulk"
            ? "Bulk"
            : groupKey === "account"
            ? "Account Settings"
            : groupKey === "admin"
            ? "Admin"
            : groupKey === "server"
            ? "Server Status"
            : groupKey.charAt(0).toUpperCase() + groupKey.slice(1),
        level,
        selectedCount,
        total,
      };
    })
    .filter(Boolean) as Array<{ groupKey: string; title: string; level: "No access" | "View only" | "Manage" | "Custom"; selectedCount: number; total: number }>;
}


export type SavedAccessTemplate = {
  id: string;
  name: string;
  description?: string | null;
  bestFor?: string | null;
  examples?: string[];
  permissionKeys: string[];
};

export function normalizeSavedAccessTemplates(input: any): SavedAccessTemplate[] {
  if (!Array.isArray(input)) return [];
  const out: SavedAccessTemplate[] = [];
  const seenIds = new Set<string>();
  const seenNames = new Set<string>();
  for (const item of input) {
    if (!item || typeof item !== "object") continue;
    const name = String((item as any).name ?? "").trim();
    const id = String((item as any).id ?? "").trim();
    if (!name || !id) continue;
    const nameKey = name.toLowerCase();
    if (seenIds.has(id) || seenNames.has(nameKey)) continue;
    seenIds.add(id);
    seenNames.add(nameKey);
    out.push({
      id,
      name,
      description: String((item as any).description ?? "").trim() || null,
      bestFor: String((item as any).bestFor ?? "").trim() || null,
      examples: Array.isArray((item as any).examples)
        ? Array.from(new Set<string>((item as any).examples.map((x: any) => String(x ?? "").trim()).filter(Boolean)))
        : [],
      permissionKeys: dedupe(Array.isArray((item as any).permissionKeys) ? (item as any).permissionKeys.map((x: any) => String(x ?? "")) : []),
    });
  }
  return out;
}

export function buildSavedTemplatePermissionKeys(template: SavedAccessTemplate) {
  return dedupe(Array.isArray(template?.permissionKeys) ? template.permissionKeys : []);
}
