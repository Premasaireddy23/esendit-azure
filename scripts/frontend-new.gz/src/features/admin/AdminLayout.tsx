import { NavLink, Outlet } from "react-router-dom";
import { HomeRefreshBar } from "../../ui/HomeRefreshBar";
import { useEffect, useState } from "react";
import type { CSSProperties } from "react";
import { getMe, hasPerm, ME_UPDATED_EVENT, type MeResponse } from "../../lib/me";

export function AdminLayout() {
  const [me, setMe] = useState<MeResponse | null>(null);

  useEffect(() => {
    getMe().then(setMe).catch(() => setMe(null));
  }, []);

  useEffect(() => {
    const handler = () => {
      getMe(true).then(setMe).catch(() => setMe(null));
    };
    window.addEventListener(ME_UPDATED_EVENT, handler);
    return () => window.removeEventListener(ME_UPDATED_EVENT, handler);
  }, []);

  const canUsers = hasPerm(me, "ADMIN_USERS_READ");
  const canRoles = hasPerm(me, "ADMIN_ROLES_READ");
  const canGroups = hasPerm(me, "ADMIN_GROUPS_READ");
  const canServerStatus = hasPerm(me, "SERVER_STATUS_READ");
  const canPermissions = hasPerm(me, "ADMIN_ROLES_READ");
  const canAccountSettings =
    hasPerm(me, "ACCOUNT_SETTINGS_READ") || hasPerm(me, "ACCOUNT_SETTINGS_WRITE") || hasPerm(me, "ADMIN_ROLES_WRITE");
  const canPresetLibrary = canAccountSettings;

  const ACCENT = "#ff2d7a";
  const DOT_ACTIVE = "#22c55e";
  const DOT_INACTIVE = "#94a3b8";

  const tabStyle = (active: boolean, enabled: boolean): CSSProperties => ({
    padding: "7px 12px",
    borderRadius: 999,
    border: `2px solid ${active ? ACCENT : "rgba(0,0,0,0.12)"}`,
    background: "white",
    color: "inherit",
    opacity: enabled ? 1 : 0.4,
    pointerEvents: enabled ? "auto" : "none",
    fontWeight: active ? 800 : 700,
    display: "inline-flex",
    alignItems: "center",
    gap: 8,
    boxShadow: active ? "0 0 0 2px rgba(255,45,122,0.12)" : "none",
  });

  const dotStyle = (active: boolean): CSSProperties => ({
    width: 10,
    height: 10,
    borderRadius: 999,
    background: active ? DOT_ACTIVE : DOT_INACTIVE,
    flex: "0 0 auto",
  });

  return (
    <div style={{ padding: 16, display: "grid", gap: 12, width: "100%", maxWidth: "none", boxSizing: "border-box" }}>
      <HomeRefreshBar title="Access & Admin" flat />

      <div>
        <h2 style={{ margin: 0 }}>Access & Admin</h2>
      </div>

      <div style={{ display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center" }}>
        <NavLink to="/admin/users" style={({ isActive }) => tabStyle(isActive, canUsers)}>
          {({ isActive }) => (
            <>
              <span style={dotStyle(isActive)} />
              <span>People</span>
            </>
          )}
        </NavLink>

        <NavLink to="/admin/roles" style={({ isActive }) => tabStyle(isActive, canRoles)}>
          {({ isActive }) => (
            <>
              <span style={dotStyle(isActive)} />
              <span>Access Profiles</span>
            </>
          )}
        </NavLink>

        <NavLink to="/admin/groups" style={({ isActive }) => tabStyle(isActive, canGroups)}>
          {({ isActive }) => (
            <>
              <span style={dotStyle(isActive)} />
              <span>Teams</span>
            </>
          )}
        </NavLink>

        {canPermissions ? (
        <NavLink to="/admin/permissions" style={({ isActive }) => tabStyle(isActive, canPermissions)}>
          {({ isActive }) => (
            <>
              <span style={dotStyle(isActive)} />
              <span>Permission Library</span>
            </>
          )}
        </NavLink>
        ) : null}

        <NavLink to="/admin/account-settings" style={({ isActive }) => tabStyle(isActive, canAccountSettings)}>
          {({ isActive }) => (
            <>
              <span style={dotStyle(isActive)} />
              <span>Account Settings</span>
            </>
          )}
        </NavLink>

        <NavLink to="/admin/presets" style={({ isActive }) => tabStyle(isActive, canPresetLibrary)}>
          {({ isActive }) => (
            <>
              <span style={dotStyle(isActive)} />
              <span>Transcode Presets</span>
            </>
          )}
        </NavLink>

        <NavLink to="/admin/server-status" style={({ isActive }) => tabStyle(isActive, canServerStatus)}>
          {({ isActive }) => (
            <>
              <span style={dotStyle(isActive)} />
              <span>Server Status</span>
            </>
          )}
        </NavLink>
      </div>

      <Outlet />
    </div>
  );
}
