import { api } from "../../lib/api";

export type Permission = { id: string; key: string; type: string; name?: string | null };

export type Role = {
  id: string;
  name: string;
  description: string | null;
  isSystem: boolean;
  permissions?: { key: string; type: string }[];
};

export type UserRow = {
  id: string;
  email: string;
  displayName?: string | null;
  isActive: boolean;
  createdAt: string;
  roles: { role: { id: string; name: string } }[];
};

export async function listPermissions() {
  return api<Permission[]>("/admin/permissions");
}

export async function listRoles() {
  return api<Role[]>("/admin/roles");
}

export async function createRole(payload: { name: string; description?: string | null }) {
  return api<Role>("/admin/roles", {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

export async function setRolePermissions(roleId: string, permissionKeys: string[]) {
  return api<{ ok: true }>(`/admin/roles/${roleId}/permissions`, {
    method: "PUT",
    body: JSON.stringify({ permissionKeys }),
  });
}

export async function listUsers() {
  return api<UserRow[]>("/admin/users");
}

export async function createUser(payload: {
  email: string;
  password: string;
  displayName: string;
  roleIds?: string[];
}) {
  return api<{ id: string; email: string }>(`/admin/users`, {
    method: "POST",
    body: JSON.stringify(payload),
  });
}



export async function createSupportSession(userId: string, payload: { reason: string; ticket?: string }) {
  return api<{
    accessToken: string;
    expiresInMinutes: number;
    targetUser: { id: string; email: string; displayName?: string | null };
    supportView: any;
  }>(`/admin/users/${userId}/support-session`, {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

export async function syncUsersFromAccounts() {
  return api<{ ok: true; scannedCount: number; createdCount: number; existingCount: number; skippedCount: number }>(`/admin/users/sync-from-accounts`, {
    method: "POST",
  });
}

export async function setUserRoles(userId: string, roleIds: string[]) {
  return api<{ ok: true }>(`/admin/users/${userId}/roles`, {
    method: "PUT",
    body: JSON.stringify({ roleIds }),
  });
}

export async function setUserStatus(userId: string, isActive: boolean) {
  return api<{ id: string; email: string; isActive: boolean }>(
    `/admin/users/${userId}/status`,
    {
      method: "PATCH",
      body: JSON.stringify({ isActive }),
    }
  );
}

export async function resetUserPassword(userId: string, newPassword: string) {
  return api<{ ok: true; id: string; email: string }>(`/admin/users/${userId}/password`, {
    method: "PATCH",
    body: JSON.stringify({ newPassword }),
  });
}

export async function deleteUser(userId: string, reason?: string) {
  return api<{ ok: true; id: string; email: string }>(`/admin/users/${userId}`, {
    method: "DELETE",
    body: JSON.stringify(reason ? { reason } : {}),
  });
}

export type AdminGroup = {
  id: string;
  name: string;
  description: string | null;
  isSystem: boolean;
  memberCount: number;
  roleCount: number;
};

export type GroupMeta = {
  groups: AdminGroup[];
  users: { id: string; email: string; name?: string; displayName?: string; isActive: boolean }[];
  roles: { id: string; name: string; isSystem: boolean; description?: string | null }[];
};

export type GroupDetails = {
  id: string;
  name: string;
  description: string | null;
  isSystem: boolean;
  members: { id: string; email: string; name?: string; displayName?: string; isActive: boolean }[];
  roles: { id: string; name: string; isSystem: boolean }[];
};

export type AccessProfileTemplate = {
  id: string;
  name: string;
  description?: string | null;
  bestFor?: string | null;
  examples?: string[];
  permissionKeys: string[];
};

export async function getGroupsMeta() {
  return api<GroupMeta>("/admin/groups/meta");
}

export async function listGroups() {
  return api<AdminGroup[]>("/admin/groups");
}

export async function createGroup(payload: { name: string; description?: string | null }) {
  return api<{ id: string; name: string; description: string | null; isSystem: boolean }>("/admin/groups", {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

export async function getGroup(groupId: string) {
  return api<GroupDetails>(`/admin/groups/${groupId}`);
}

export async function setGroupMembers(groupId: string, userIds: string[]) {
  return api<{ ok: true }>(`/admin/groups/${groupId}/members`, {
    method: "PUT",
    body: JSON.stringify({ userIds }),
  });
}

export async function setGroupRoles(groupId: string, roleIds: string[]) {
  return api<{ ok: true }>(`/admin/groups/${groupId}/roles`, {
    method: "PUT",
    body: JSON.stringify({ roleIds }),
  });
}


// --- Phase 3: Account UI Config ---
export async function getAccountUiConfig(): Promise<{ account?: any; uiConfig?: { creativeCodeLabel?: string | null; notificationAdminEmail?: string | null; notificationAdminOnlyMode?: boolean | null; accessProfileTemplates?: AccessProfileTemplate[] } }> {
  return api("/admin/account/ui-config");
}

export async function updateAccountUiConfig(dto: { creativeCodeLabel?: string | null; notificationAdminEmail?: string | null; notificationAdminOnlyMode?: boolean | null; accessProfileTemplates?: AccessProfileTemplate[] | null }): Promise<any> {
  return api("/admin/account/ui-config", { method: "PUT", body: JSON.stringify(dto) });
}

// --- Account download presets (FFmpeg profiles) ---
export async function getAccountDownloadPresets(): Promise<{ account?: any; downloadPresets?: any[] }> {
  return api("/admin/account/download-presets");
}

export async function updateAccountDownloadPresets(dto: { downloadPresets: any[] | null }): Promise<any> {
  return api("/admin/account/download-presets", { method: "PUT", body: JSON.stringify(dto) });
}


export type PresetPipelineStep = {
  key?: string | null;
  label?: string | null;
  tool?: "ffmpeg" | "ffmbc" | string | null;
  binary?: string | null;
  input?: string | null;
  output?: string | null;
  ext?: string | null;
  args?: string[];
};

export type PresetLibraryItem = {
  key: string;
  label?: string | null;
  ext: string;
  mimeType: string;
  args: string[];
  tool?: "ffmpeg" | "ffmbc" | string | null;
  steps?: PresetPipelineStep[];
  usage: {
    destinationAllowedCount: number;
    destinationDefaultCount: number;
    channelDefaultCount: number;
    activeJobCount: number;
  };
  inUse: boolean;
  deleteBlockedReason?: string | null;
};

export async function listPresetLibrary(): Promise<{ items: PresetLibraryItem[] }> {
  return api('/admin/account/preset-library');
}

export type PresetLibraryWritePayload = {
  key: string;
  label?: string | null;
  ext: string;
  mimeType: string;
  args: string[];
  tool?: "ffmpeg" | "ffmbc" | string | null;
  steps?: PresetPipelineStep[];
};

export async function createPresetLibraryItem(dto: PresetLibraryWritePayload): Promise<any> {
  return api('/admin/account/preset-library', { method: 'POST', body: JSON.stringify(dto) });
}

export async function updatePresetLibraryItem(key: string, dto: Omit<PresetLibraryWritePayload, 'key'> & { key?: string }): Promise<any> {
  return api(`/admin/account/preset-library/${encodeURIComponent(key)}`, { method: 'PUT', body: JSON.stringify(dto) });
}

export async function duplicatePresetLibraryItem(sourceKey: string, dto: PresetLibraryWritePayload): Promise<any> {
  return api(`/admin/account/preset-library/${encodeURIComponent(sourceKey)}/duplicate`, { method: 'POST', body: JSON.stringify(dto) });
}

export async function deletePresetLibraryItem(key: string): Promise<any> {
  return api(`/admin/account/preset-library/${encodeURIComponent(key)}`, { method: 'DELETE' });
}
