import { Link } from "react-router-dom";

function getFriendlyIssue(error: any) {
  const status = Number(error?.status);

  if (status === 401) {
    return "Your session may have expired. Please sign in again and reopen this section.";
  }
  if (status === 403) {
    return "This section is currently restricted for your account.";
  }
  if (status === 404) {
    return "This section is not available in the current backend deployment yet.";
  }
  if (status >= 500) {
    return "The server could not load this section right now. Please try again in a moment.";
  }
  return "We could not open this section right now. Please try again shortly or contact your administrator.";
}

type AdminPageStateProps = {
  kind: "denied" | "error";
  sectionLabel: string;
  error?: any;
};

export function AdminPageState({ kind, sectionLabel, error }: AdminPageStateProps) {
  const denied = kind === "denied";

  return (
    <div
      className="card"
      style={{
        padding: 18,
        borderRadius: 16,
        border: `1px solid ${denied ? "rgba(245,158,11,0.28)" : "rgba(239,68,68,0.24)"}`,
        background: denied ? "rgba(245,158,11,0.08)" : "rgba(239,68,68,0.06)",
        display: "grid",
        gap: 10,
        maxWidth: 760,
      }}
    >
      <div style={{ display: "flex", alignItems: "start", gap: 12 }}>
        <div
          aria-hidden="true"
          style={{
            width: 36,
            height: 36,
            borderRadius: 999,
            display: "grid",
            placeItems: "center",
            fontSize: 18,
            background: denied ? "rgba(245,158,11,0.16)" : "rgba(239,68,68,0.12)",
            flex: "0 0 auto",
          }}
        >
          {denied ? "🔒" : "⚠️"}
        </div>

        <div style={{ display: "grid", gap: 6 }}>
          <div style={{ fontWeight: 800, fontSize: 18 }}>
            {denied ? `You do not currently have access to ${sectionLabel}.` : `We could not open ${sectionLabel}.`}
          </div>
          <div style={{ fontSize: 14, opacity: 0.84, lineHeight: 1.45 }}>
            {denied
              ? `Please contact your administrator if you need access to view or manage ${sectionLabel.toLowerCase()}.`
              : getFriendlyIssue(error)}
          </div>
          {!denied && error?.status ? (
            <div style={{ fontSize: 12, opacity: 0.68 }}>Reference: error {String(error.status)}</div>
          ) : null}
        </div>
      </div>

      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
        <Link to="/" style={{ textDecoration: "none" }}>
          <button type="button">Go to Home</button>
        </Link>
        <Link to="/admin/permissions" style={{ textDecoration: "none" }}>
          <button type="button">Open Permission Library</button>
        </Link>
      </div>
    </div>
  );
}
