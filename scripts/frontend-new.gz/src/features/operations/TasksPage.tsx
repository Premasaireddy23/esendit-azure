import { HomeRefreshBar } from "../../ui/HomeRefreshBar";

export function TasksPage() {
  return (
    <div style={{ padding: 16 }}>
      <HomeRefreshBar title="Operations / Tasks" />
      <div className="card">
        <h3 style={{ margin: 0 }}>Operations / Tasks</h3>
        <div style={{ fontSize: 13, opacity: 0.8, marginTop: 8 }}>
          Internal page. Not part of the project stepper.
        </div>
      </div>
    </div>
  );
}
