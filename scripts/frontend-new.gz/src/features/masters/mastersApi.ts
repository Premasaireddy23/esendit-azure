import { api } from "../../lib/api";

export type ListParams = { q?: string; includeInactive?: boolean };

function qp(params?: Record<string, string | undefined>) {
  if (!params) return "";
  const sp = new URLSearchParams();
  for (const [k, v] of Object.entries(params)) {
    if (v) sp.set(k, v);
  }
  const s = sp.toString();
  return s ? `?${s}` : "";
}

export async function listMasters<T>(path: string, params?: ListParams): Promise<T[]> {
  return api<T[]>(
    `${path}${qp({
      q: params?.q,
      includeInactive: params?.includeInactive ? "true" : undefined,
    })}`,
  );
}

export async function getMaster<T>(path: string, id: string): Promise<T> {
  return api<T>(`${path}/${id}`);
}

export async function createMaster<T>(path: string, payload: any): Promise<T> {
  return api<T>(path, { method: "POST", body: JSON.stringify(payload) });
}

export async function updateMaster<T>(path: string, id: string, payload: any): Promise<T> {
  return api<T>(`${path}/${id}`, { method: "PUT", body: JSON.stringify(payload) });
}

export async function disableMaster(path: string, id: string): Promise<{ ok: boolean } | any> {
  return api<any>(`${path}/${id}`, { method: "DELETE" });
}

export async function enableMaster<T>(path: string, id: string): Promise<T> {
  return api<T>(`${path}/${id}/enable`, { method: "POST" });
}

export async function permanentDeleteMaster(path: string, id: string): Promise<{ ok: boolean } | any> {
  return api<any>(`${path}/${id}/permanent`, { method: "DELETE" });
}
