export type MasterStatus = "ACTIVE" | "INACTIVE" | string;

export type AgencyType =
  | "MEDIA"
  | "CREATIVE"
  | "POST_HOUSE"
  | "AUDIO"
  | "PRODUCTION_HOUSE"
  | "UPLOADER"
  | string;

export type BaseMaster = {
  id: string;
  accountId: string;
  name: string;
  status: MasterStatus;
  createdAt: string;
  updatedAt: string;
};

export type SelectOption = { value: string; label: string };
