import type { CSSProperties } from "react";
import { useLocation, useNavigate, useSearchParams } from "react-router-dom";
import { hasAnyPerm, type MeResponse } from "../../lib/me";
import { ACCOUNTS_PAGE_PERMISSIONS } from "./accountsPermissions";
import {
  ADVERTISER_GROUPS_PAGE_PERMISSIONS,
  ADVERTISERS_PAGE_PERMISSIONS,
  BRANDS_PAGE_PERMISSIONS,
  HOT_FOLDERS_PAGE_PERMISSIONS,
  PRODUCT_CATEGORIES_PAGE_PERMISSIONS,
} from "./mastersPermissions";

const ACCENT = "#ff2d7a";
const DOT_ACTIVE = "#22c55e";
const DOT_INACTIVE = "#94a3b8";

export type MasterSectionKey =
  | "advertiser-groups"
  | "advertisers"
  | "brands"
  | "product-categories"
  | "hot-folders"
  | "accounts";

export type MasterSectionTab = {
  key: MasterSectionKey;
  label: string;
  description: string;
};

export const MASTER_SECTION_TABS: MasterSectionTab[] = [
  { key: "advertiser-groups", label: "Advertiser Groups", description: "" },
  { key: "advertisers", label: "Advertisers", description: "" },
  { key: "brands", label: "Brands", description: "" },
  { key: "product-categories", label: "Product Categories", description: "" },
  {
    key: "hot-folders",
    label: "Hot Folders",
    description: "Manage watch folders and ingestion rules for automated creative intake.",
  },
  { key: "accounts", label: "Accounts", description: "" },
];

const SECTION_PERMISSIONS: Record<MasterSectionKey, readonly string[]> = {
  "advertiser-groups": ADVERTISER_GROUPS_PAGE_PERMISSIONS,
  advertisers: ADVERTISERS_PAGE_PERMISSIONS,
  brands: BRANDS_PAGE_PERMISSIONS,
  "product-categories": PRODUCT_CATEGORIES_PAGE_PERMISSIONS,
  "hot-folders": HOT_FOLDERS_PAGE_PERMISSIONS,
  accounts: ACCOUNTS_PAGE_PERMISSIONS,
};

function toggleBtnStyle(active: boolean): CSSProperties {
  return {
    padding: "7px 12px",
    borderRadius: 999,
    border: `2px solid ${active ? ACCENT : "rgba(0,0,0,0.12)"}`,
    background: "white",
    color: "inherit",
    fontWeight: active ? 800 : 700,
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    boxShadow: active ? "0 0 0 2px rgba(255,45,122,0.12)" : "none",
    cursor: "pointer",
    whiteSpace: "nowrap",
  };
}

function toggleDotStyle(active: boolean): CSSProperties {
  return {
    width: 10,
    height: 10,
    borderRadius: 999,
    background: active ? DOT_ACTIVE : DOT_INACTIVE,
    flex: "0 0 auto",
  };
}

function normalizePath(pathname: string) {
  const trimmed = pathname.replace(/\/+$/, "");
  return trimmed || "/";
}

export function isMasterSectionKey(value: string | null | undefined): value is MasterSectionKey {
  return MASTER_SECTION_TABS.some((section) => section.key === value);
}

export function canSeeMasterSection(me: MeResponse | null | undefined, key: MasterSectionKey) {
  return hasAnyPerm(me ?? null, [...SECTION_PERMISSIONS[key]]);
}

function activeSectionFromLocation(pathname: string, querySection: string | null, visibleSections: MasterSectionTab[]) {
  const normalized = normalizePath(pathname);
  const pathKey = normalized.startsWith("/masters/") ? normalized.slice("/masters/".length).split("/")[0] : null;

  if (isMasterSectionKey(pathKey) && visibleSections.some((section) => section.key === pathKey)) {
    return pathKey;
  }

  if (isMasterSectionKey(querySection) && visibleSections.some((section) => section.key === querySection)) {
    return querySection;
  }

  return visibleSections[0]?.key ?? null;
}

function shouldShowForPath(pathname: string) {
  const normalized = normalizePath(pathname);
  if (normalized === "/masters") return true;
  if (!normalized.startsWith("/masters/")) return false;

  const rest = normalized.slice("/masters/".length);
  const [first, second] = rest.split("/");

  // Show only on the main master list pages. Keep create/edit/detail flows clean.
  return !second && isMasterSectionKey(first);
}

export function MasterSectionTabs({ me }: { me: MeResponse | null | undefined }) {
  const nav = useNavigate();
  const loc = useLocation();
  const [sp] = useSearchParams();

  if (!shouldShowForPath(loc.pathname)) return null;

  const visibleSections = MASTER_SECTION_TABS.filter((section) => canSeeMasterSection(me, section.key));
  if (!visibleSections.length) return null;

  const activeSection = activeSectionFromLocation(loc.pathname, sp.get("section"), visibleSections);

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div style={{ fontSize: 28, fontWeight: 900 }}>Masters</div>

      <div style={{ display: "grid", gap: 8 }}>
        <div className="mastersFilters__label">Master Sections</div>
        <div style={{ display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center" }}>
          {visibleSections.map((section) => {
            const active = activeSection === section.key;
            return (
              <button
                key={section.key}
                type="button"
                style={toggleBtnStyle(active)}
                title={section.description || undefined}
                onClick={() => nav(`/masters/${section.key}`)}
              >
                <span style={toggleDotStyle(active)} />
                <span>{section.label}</span>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
