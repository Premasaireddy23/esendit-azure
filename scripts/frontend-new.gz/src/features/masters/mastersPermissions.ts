export const MASTERS_SECTION_PERMISSIONS = ["page:masters", "MASTERS_READ"] as const;
export const AGENCIES_SECTION_PERMISSIONS = ["page:agencies", "MASTERS_READ"] as const;
export const DELIVERY_SECTION_PERMISSIONS = ["page:delivery", "MASTERS_READ"] as const;
export const BILLING_SECTION_PERMISSIONS = ["page:billing", "BILLING_READ"] as const;

export const MASTERS_OVERVIEW_PAGE_PERMISSIONS = ["page:masters", "MASTERS_READ"] as const;

export const ADVERTISER_GROUPS_PAGE_PERMISSIONS = ["page:masters:advertiser-groups", "MASTERS_READ"] as const;
export const ADVERTISER_GROUPS_CREATE_PERMISSIONS = ["action:masters:advertiser-groups:create", "MASTERS_CREATE"] as const;
export const ADVERTISER_GROUPS_UPDATE_PERMISSIONS = ["action:masters:advertiser-groups:update", "MASTERS_UPDATE"] as const;
export const ADVERTISER_GROUPS_DELETE_PERMISSIONS = ["action:masters:advertiser-groups:delete", "MASTERS_DELETE"] as const;

export const ADVERTISERS_PAGE_PERMISSIONS = ["page:masters:advertisers", "MASTERS_READ"] as const;
export const ADVERTISERS_CREATE_PERMISSIONS = ["action:masters:advertisers:create", "MASTERS_CREATE"] as const;
export const ADVERTISERS_UPDATE_PERMISSIONS = ["action:masters:advertisers:update", "MASTERS_UPDATE"] as const;
export const ADVERTISERS_DELETE_PERMISSIONS = ["action:masters:advertisers:delete", "MASTERS_DELETE"] as const;

export const BRANDS_PAGE_PERMISSIONS = ["page:masters:brands", "MASTERS_READ"] as const;
export const BRANDS_CREATE_PERMISSIONS = ["action:masters:brands:create", "MASTERS_CREATE"] as const;
export const BRANDS_UPDATE_PERMISSIONS = ["action:masters:brands:update", "MASTERS_UPDATE"] as const;
export const BRANDS_DELETE_PERMISSIONS = ["action:masters:brands:delete", "MASTERS_DELETE"] as const;

export const PRODUCT_CATEGORIES_PAGE_PERMISSIONS = ["page:masters:product-categories", "MASTERS_READ"] as const;
export const PRODUCT_CATEGORIES_CREATE_PERMISSIONS = ["action:masters:product-categories:create", "MASTERS_CREATE"] as const;
export const PRODUCT_CATEGORIES_UPDATE_PERMISSIONS = ["action:masters:product-categories:update", "MASTERS_UPDATE"] as const;
export const PRODUCT_CATEGORIES_DELETE_PERMISSIONS = ["action:masters:product-categories:delete", "MASTERS_DELETE"] as const;

export const AGENCIES_PAGE_PERMISSIONS = ["page:masters:agencies", "MASTERS_READ"] as const;
export const AGENCIES_CREATE_PERMISSIONS = ["action:masters:agencies:create", "MASTERS_CREATE"] as const;
export const AGENCIES_UPDATE_PERMISSIONS = ["action:masters:agencies:update", "MASTERS_UPDATE"] as const;
export const AGENCIES_DELETE_PERMISSIONS = ["action:masters:agencies:delete", "MASTERS_DELETE"] as const;

export const AGENCY_TEAMS_PAGE_PERMISSIONS = ["page:masters:agency-teams", "MASTERS_READ"] as const;
export const AGENCY_TEAMS_CREATE_PERMISSIONS = ["action:masters:agency-teams:create", "MASTERS_CREATE"] as const;
export const AGENCY_TEAMS_UPDATE_PERMISSIONS = ["action:masters:agency-teams:update", "MASTERS_UPDATE"] as const;
export const AGENCY_TEAMS_DELETE_PERMISSIONS = ["action:masters:agency-teams:delete", "MASTERS_DELETE"] as const;

export const SLAS_PAGE_PERMISSIONS = ["page:masters:slas", "MASTERS_READ"] as const;
export const SLAS_CREATE_PERMISSIONS = ["action:masters:slas:create", "MASTERS_CREATE"] as const;
export const SLAS_UPDATE_PERMISSIONS = ["action:masters:slas:update", "MASTERS_UPDATE"] as const;
export const SLAS_DELETE_PERMISSIONS = ["action:masters:slas:delete", "MASTERS_DELETE"] as const;

export const HOT_FOLDERS_PAGE_PERMISSIONS = ["page:masters:hot-folders", "MASTERS_READ"] as const;
export const HOT_FOLDERS_CREATE_PERMISSIONS = ["action:masters:hot-folders:create", "MASTERS_CREATE"] as const;
export const HOT_FOLDERS_UPDATE_PERMISSIONS = ["action:masters:hot-folders:update", "MASTERS_UPDATE"] as const;
export const HOT_FOLDERS_DELETE_PERMISSIONS = ["action:masters:hot-folders:delete", "MASTERS_DELETE"] as const;

export const DELIVERY_SETUP_PAGE_PERMISSIONS = ["page:masters:delivery-setup", "MASTERS_READ"] as const;

export const DESTINATIONS_PAGE_PERMISSIONS = ["page:masters:destinations", "MASTERS_READ"] as const;
export const DESTINATIONS_CREATE_PERMISSIONS = ["action:masters:destinations:create", "MASTERS_CREATE"] as const;
export const DESTINATIONS_UPDATE_PERMISSIONS = ["action:masters:destinations:update", "MASTERS_UPDATE"] as const;
export const DESTINATIONS_DELETE_PERMISSIONS = ["action:masters:destinations:delete", "MASTERS_DELETE"] as const;

export const DELIVERY_PROFILES_PAGE_PERMISSIONS = ["page:masters:delivery-profiles", "MASTERS_READ"] as const;
export const DELIVERY_PROFILES_CREATE_PERMISSIONS = ["action:masters:delivery-profiles:create", "MASTERS_CREATE"] as const;
export const DELIVERY_PROFILES_UPDATE_PERMISSIONS = ["action:masters:delivery-profiles:update", "MASTERS_UPDATE"] as const;
export const DELIVERY_PROFILES_DELETE_PERMISSIONS = ["action:masters:delivery-profiles:delete", "MASTERS_DELETE"] as const;

export const CHANNELS_PAGE_PERMISSIONS = ["page:masters:channels", "MASTERS_READ"] as const;
export const CHANNELS_CREATE_PERMISSIONS = ["action:masters:channels:create", "MASTERS_CREATE"] as const;
export const CHANNELS_UPDATE_PERMISSIONS = ["action:masters:channels:update", "MASTERS_UPDATE"] as const;
export const CHANNELS_DELETE_PERMISSIONS = ["action:masters:channels:delete", "MASTERS_DELETE"] as const;

export const BILLABLE_PARTIES_PAGE_PERMISSIONS = ["page:billing:billable-parties", "BILLING_READ"] as const;
export const BILLABLE_PARTIES_CREATE_PERMISSIONS = ["action:billing:billable-parties:create", "BILLING_CREATE"] as const;
export const BILLABLE_PARTIES_UPDATE_PERMISSIONS = ["action:billing:billable-parties:update", "BILLING_UPDATE"] as const;
export const BILLABLE_PARTIES_DELETE_PERMISSIONS = ["action:billing:billable-parties:delete", "BILLING_DELETE"] as const;

export const RATE_CARDS_PAGE_PERMISSIONS = ["page:billing:rate-cards", "BILLING_READ"] as const;
export const RATE_CARDS_CREATE_PERMISSIONS = ["action:billing:rate-cards:create", "BILLING_CREATE"] as const;
export const RATE_CARDS_UPDATE_PERMISSIONS = ["action:billing:rate-cards:update", "BILLING_UPDATE"] as const;
export const RATE_CARDS_DELETE_PERMISSIONS = ["action:billing:rate-cards:delete", "BILLING_DELETE"] as const;

export const BILLING_CHARGES_PAGE_PERMISSIONS = ["page:billing:charges", "BILLING_READ"] as const;
export const BILLING_INVOICES_PAGE_PERMISSIONS = ["page:billing:invoices", "BILLING_READ"] as const;

export const AGENCY_HUB_PAGE_PERMISSIONS = Array.from(
  new Set<string>([...AGENCIES_PAGE_PERMISSIONS, ...AGENCY_TEAMS_PAGE_PERMISSIONS]),
);

export const ALL_MASTERS_LAYOUT_PAGE_PERMISSIONS = Array.from(
  new Set<string>([
    ...MASTERS_SECTION_PERMISSIONS,
    ...AGENCIES_SECTION_PERMISSIONS,
    ...DELIVERY_SECTION_PERMISSIONS,
    ...BILLING_SECTION_PERMISSIONS,
    ...ADVERTISER_GROUPS_PAGE_PERMISSIONS,
    ...ADVERTISERS_PAGE_PERMISSIONS,
    ...BRANDS_PAGE_PERMISSIONS,
    ...PRODUCT_CATEGORIES_PAGE_PERMISSIONS,
    ...AGENCIES_PAGE_PERMISSIONS,
    ...AGENCY_TEAMS_PAGE_PERMISSIONS,
    ...SLAS_PAGE_PERMISSIONS,
    ...HOT_FOLDERS_PAGE_PERMISSIONS,
    ...DELIVERY_SETUP_PAGE_PERMISSIONS,
    ...DESTINATIONS_PAGE_PERMISSIONS,
    ...DELIVERY_PROFILES_PAGE_PERMISSIONS,
    ...CHANNELS_PAGE_PERMISSIONS,
    ...BILLABLE_PARTIES_PAGE_PERMISSIONS,
    ...RATE_CARDS_PAGE_PERMISSIONS,
    ...BILLING_CHARGES_PAGE_PERMISSIONS,
    ...BILLING_INVOICES_PAGE_PERMISSIONS,
  ]),
);
