import { useEffect, useMemo, useState, type CSSProperties, type ReactNode } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import type { ApiError } from "../../lib/api";
import { getMe, hasAnyPerm, type MeResponse } from "../../lib/me";
import { EmailChipsInput } from "../../ui/EmailChipsInput";
import { createMaster } from "./mastersApi";
import type { FieldDef } from "./MasterCrudPage";

type Props = {
  heading: string | ((form: Record<string, any>) => string);
  apiPath: string;
  backTo: string;
  fields: FieldDef[];
  defaultCreate?: Record<string, any>;
  toPayload?: (form: Record<string, any>) => any;
  submitLabel?: string | ((form: Record<string, any>) => string);
  createPermissionsAny?: string[];

  // Button beside a specific select field (example: "type")
  inlineSelectAction?: {
    fieldName: string;
    label: string;
    onClick?: (form: Record<string, any>) => void;
  };

  // Optional section rendered below the standard fields (example: Teams)
  extra?: ReactNode;
};

function initForm(fields: FieldDef[], defaults?: Record<string, any>) {
  const form: Record<string, any> = { ...(defaults || {}) };
  for (const f of fields) {
    if (f.name in form) continue;
    form[f.name] = f.type === "emails" ? [] : "";
  }
  return form;
}

function normalizeEmails(v: any): string[] {
  if (Array.isArray(v)) return v.map((s) => String(s).trim()).filter(Boolean);
  return String(v || "")
    .split(/[\s,]+/g)
    .map((s) => s.trim())
    .filter(Boolean);
}


function segmentedButtonStyle(active: boolean): CSSProperties {
  return {
    minHeight: 40,
    padding: "10px 14px",
    borderRadius: 999,
    border: active ? "1px solid #2563eb" : "1px solid #d7dde5",
    background: active ? "#eff6ff" : "#fff",
    color: active ? "#1d4ed8" : "#1f2937",
    fontWeight: 700,
    boxShadow: active ? "0 8px 18px rgba(37, 99, 235, 0.14)" : "none",
    cursor: "pointer",
  };
}

export function MasterCreateFormPage(props: Props) {
  const nav = useNavigate();
  const [sp] = useSearchParams();

  const [me, setMe] = useState<MeResponse | null>(null);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  const [form, setForm] = useState<Record<string, any>>(() => initForm(props.fields, props.defaultCreate));

  useEffect(() => {
    setForm((prev) => ({ ...initForm(props.fields, props.defaultCreate), ...prev }));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.fields.length]);

  useEffect(() => {
    getMe().then(setMe).catch(() => setMe(null));
  }, []);

  const fieldMap = useMemo(() => new Map(props.fields.map((f) => [f.name, f])), [props.fields]);

  const returnTo = useMemo(() => {
    const rt = sp.get("rt");
    if (!rt) return props.backTo;
    try {
      return decodeURIComponent(rt);
    } catch {
      return rt;
    }
  }, [sp, props.backTo]);

  const canCreate = hasAnyPerm(me, props.createPermissionsAny ?? ["MASTERS_CREATE"]);

  const headingText = typeof props.heading === "function" ? props.heading(form) : props.heading;
  const submitText =
    typeof props.submitLabel === "function" ? props.submitLabel(form) : props.submitLabel || "Add";

  function setValue(name: string, value: any) {
    setForm((p) => ({ ...p, [name]: value }));
  }

  function normalize(input: Record<string, any>) {
    const out: Record<string, any> = {};
    for (const [k, v] of Object.entries(input)) {
      const f = fieldMap.get(k);
      if (f?.type === "emails") {
        const emails = normalizeEmails(v);
        out[k] = emails.length ? emails : undefined;
      } else {
        out[k] = v === "" ? undefined : v;
      }
    }
    return props.toPayload ? props.toPayload(out) : out;
  }

  async function submit() {
    if (!canCreate) return;

    const visibleFields = props.fields.filter((f) => !f.showWhen || f.showWhen(form));

    for (const f of visibleFields) {
      if (!f.required) continue;
      const v = form[f.name];
      if (f.type === "emails") {
        const emails = normalizeEmails(v);
        if (!emails.length) {
          setErr(`${f.label} is required`);
          return;
        }
      } else {
        if (v === undefined || v === null || String(v).trim() === "") {
          setErr(`${f.label} is required`);
          return;
        }
      }
    }

    setBusy(true);
    setErr("");
    try {
      await createMaster(props.apiPath, normalize(form));
      nav(returnTo);
    } catch (e: any) {
      const ae = e as ApiError;
      setErr(ae.message || "Failed to create");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div style={{ display: "grid", gap: 14, maxWidth: 1100 }}>
      <div style={{ display: "grid", gap: 6 }}>
        <div style={{ fontSize: 12, opacity: 0.7 }}>
          <Link to={returnTo}>← Back</Link>
        </div>
        <h2 style={{ margin: 0 }}>{headingText}</h2>
      </div>

      {err ? (
        <div style={{ border: "1px solid #ffd3d3", background: "#fff2f2", padding: 12, borderRadius: 12 }}>
          {err}
        </div>
      ) : null}

      <div style={{ display: "grid", gap: 14 }}>
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
            gap: 14,
          }}
        >
          {props.fields.filter((f) => !f.showWhen || f.showWhen(form)).map((f) => {
            const isFull = f.type === "textarea" || f.type === "emails" || (f as any).fullWidth;

            const hasInlineAction =
              props.inlineSelectAction && props.inlineSelectAction.fieldName === f.name && f.type === "select";

            const fieldEl =
              f.type === "textarea" ? (
                <textarea
                  value={form[f.name] ?? ""}
                  placeholder={f.placeholder}
                  onChange={(e) => setValue(f.name, e.target.value)}
                  rows={4}
                  style={{ width: "100%" }}
                />
              ) : f.type === "select" ? (
                <select value={form[f.name] ?? ""} onChange={(e) => setValue(f.name, e.target.value)}>
                  <option value="">-- Select --</option>
                  {(f.options || []).map((o) => (
                    <option key={o.value} value={o.value}>
                      {o.label}
                    </option>
                  ))}
                </select>
              ) : f.type === "segmented" ? (
                <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                  {(f.options || []).map((o) => {
                    const active = String(form[f.name] ?? "") === String(o.value);
                    return (
                      <button
                        key={o.value}
                        type="button"
                        onClick={() => setValue(f.name, o.value)}
                        style={segmentedButtonStyle(active)}
                        disabled={!canCreate || busy}
                      >
                        {o.label}
                      </button>
                    );
                  })}
                </div>
              ) : f.type === "emails" ? (
                <EmailChipsInput
                  value={Array.isArray(form[f.name]) ? form[f.name] : normalizeEmails(form[f.name])}
                  onChange={(next) => setValue(f.name, next)}
                  placeholder={f.placeholder || "Type email(s) and press Enter"}
                  disabled={!canCreate || busy}
                  onInvalidEmail={(v) => setErr(`Invalid email: ${v}`)}
                />
              ) : (
                <input
                  value={form[f.name] ?? ""}
                  placeholder={f.placeholder}
                  onChange={(e) => setValue(f.name, e.target.value)}
                />
              );

            return (
              <div
                key={f.name}
                style={{
                  display: "grid",
                  gap: 6,
                  ...(isFull ? { gridColumn: "1 / -1" } : null),
                }}
              >
                <label style={{ fontWeight: 800 }}>
                  {f.label} {f.required ? <span style={{ color: "crimson" }}>*</span> : null}
                </label>

                {hasInlineAction ? (
                  <div style={{ display: "grid", gridTemplateColumns: "1fr auto", gap: 10 }}>
                    {fieldEl}
                    <button
                      className="btnPrimary"
                      type="button"
                      onClick={() => props.inlineSelectAction?.onClick?.(form)}
                      disabled={!canCreate || busy}
                    >
                      {props.inlineSelectAction?.label || "Add"}
                    </button>
                  </div>
                ) : (
                  fieldEl
                )}

                {f.help ? <div style={{ fontSize: 12, opacity: 0.7 }}>{f.help}</div> : null}
              </div>
            );
          })}
        </div>

        {props.extra ? <div style={{ display: "grid", gap: 12 }}>{props.extra}</div> : null}

        <div className="row" style={{ justifyContent: "flex-end" }}>
          <button type="button" onClick={() => nav(returnTo)} disabled={busy}>
            Cancel
          </button>
          <button className="btnPrimary" type="button" onClick={submit} disabled={!canCreate || busy}>
            {busy ? "Saving..." : submitText}
          </button>
        </div>
      </div>
    </div>
  );
}
