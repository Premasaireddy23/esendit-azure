import { useCallback, useEffect, useMemo, useState, type CSSProperties } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import type { ApiError } from "../../lib/api";
import { AppModal } from "../../ui/AppModal";
import { createMaster, disableMaster, enableMaster, listMasters, permanentDeleteMaster, updateMaster } from "./mastersApi";
import type { SelectOption } from "./types";

export type FieldType = "text" | "number" | "textarea" | "select" | "emails" | "segmented";

export type FieldDef = {
  name: string;
  label: string;
  type: FieldType;
  required?: boolean;
  placeholder?: string;
  options?: SelectOption[];
  help?: string;
  fullWidth?: boolean;
  showWhen?: (form: Record<string, any>) => boolean;
};

export type ColumnDef<T> = {
  key: string;
  label: string;
  render?: (row: T) => any;
};

type Props<T extends { id: string; name?: string; status?: string }> = {
  title: string;
  path: string;
  columns: ColumnDef<T>[];
  fields: FieldDef[];
  canCreate: boolean;
  canUpdate: boolean;
  canDelete: boolean;
  defaultCreate?: Record<string, any>;
  createTo?: string;
  createLabel?: string;
  toPayload?: (form: Record<string, any>) => any;
  transformRows?: (rows: T[]) => T[];
  supportsInactive?: boolean;
  supportsEnableAndPermanentDelete?: boolean;
  enhancedCrudUi?: boolean;
};

type StatusView = "ACTIVE" | "INACTIVE";

function segmentedButtonStyle(active: boolean): CSSProperties {
  return {
    minHeight: 40,
    padding: "10px 14px",
    borderRadius: 999,
    border: active ? "1px solid #2563eb" : "1px solid #d7dde5",
    background: active ? "#eff6ff" : "#fff",
    color: active ? "#1d4ed8" : "#1f2937",
    fontWeight: 700,
    boxShadow: active ? "0 8px 18px rgba(37, 99, 235, 0.14)" : "none",
    cursor: "pointer",
  };
}

function tabButtonStyle(active: boolean): CSSProperties {
  return {
    minHeight: 38,
    padding: "8px 16px",
    borderRadius: 12,
    border: active ? "1px solid #2563eb" : "1px solid #d7dde5",
    background: "#fff",
    color: active ? "#1d4ed8" : "#111827",
    fontWeight: active ? 800 : 600,
    boxShadow: active ? "0 10px 24px rgba(37, 99, 235, 0.10)" : "0 2px 8px rgba(15, 23, 42, 0.04)",
    cursor: "pointer",
  };
}

function actionButtonStyle(kind: "primary" | "neutral" | "danger"): CSSProperties {
  const base: CSSProperties = {
    width: "100%",
    textAlign: "left",
    padding: "12px 14px",
    borderRadius: 12,
    border: "1px solid #e5e7eb",
    background: "#fff",
    fontWeight: 700,
    cursor: "pointer",
  };
  if (kind === "primary") return { ...base, color: "#1d4ed8", borderColor: "#bfdbfe" };
  if (kind === "danger") return { ...base, color: "#b91c1c", borderColor: "#fecaca" };
  return base;
}

export function MasterCrudPage<T extends { id: string; status?: string; createdAt?: string; updatedAt?: string }>(
  props: Props<T>,
) {
  const {
    title,
    path,
    columns,
    fields,
    canCreate,
    canUpdate,
    canDelete,
    defaultCreate,
    toPayload,
    supportsInactive,
    transformRows,
    createTo,
    createLabel,
    supportsEnableAndPermanentDelete,
    enhancedCrudUi,
  } = props;

  const nav = useNavigate();
  const loc = useLocation();

  const [rows, setRows] = useState<T[]>([]);
  const [loading, setLoading] = useState(false);
  const [q, setQ] = useState("");
  const [includeInactive, setIncludeInactive] = useState(false);
  const [statusView, setStatusView] = useState<StatusView>("ACTIVE");
  const [err, setErr] = useState<string | null>(null);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [selectionMode, setSelectionMode] = useState(false);
  const [actionsRow, setActionsRow] = useState<any | null>(null);
  const [confirmAction, setConfirmAction] = useState<null | {
    title: string;
    message: string;
    confirmLabel: string;
    tone: "primary" | "danger";
    onConfirm: () => Promise<void> | void;
  }>(null);
  const [confirmBusy, setConfirmBusy] = useState(false);

  const [open, setOpen] = useState<
    | null
    | { mode: "create"; form: Record<string, any> }
    | { mode: "edit"; id: string; form: Record<string, any> }
  >(null);

  const fieldMap = useMemo(() => new Map(fields.map((f) => [f.name, f])), [fields]);

  const effectiveIncludeInactive = supportsInactive ? (enhancedCrudUi ? true : includeInactive) : false;

  const transformedRows = useMemo(() => {
    try {
      return transformRows ? transformRows(rows) : rows;
    } catch {
      return rows;
    }
  }, [rows, transformRows]);

  const visibleRows = useMemo(() => {
    if (!supportsInactive || !enhancedCrudUi) return transformedRows;
    return transformedRows.filter((row: any) => (statusView === "INACTIVE" ? row.status === "INACTIVE" : row.status !== "INACTIVE"));
  }, [enhancedCrudUi, statusView, supportsInactive, transformedRows]);

  const hasSelection = selectedIds.length > 0;
  const showSelectionUi = enhancedCrudUi && selectionMode;
  const allVisibleSelected = visibleRows.length > 0 && visibleRows.every((row: any) => selectedIds.includes(row.id));

  const refresh = useCallback(async () => {
    setLoading(true);
    setErr(null);
    try {
      const data = await listMasters<T>(path, {
        q: q.trim() || undefined,
        includeInactive: effectiveIncludeInactive ? true : undefined,
      });
      setRows(data);
    } catch (e: any) {
      const ae = e as ApiError;
      setErr(ae.message || "Failed to load");
    } finally {
      setLoading(false);
    }
  }, [effectiveIncludeInactive, path, q]);

  useEffect(() => {
    if (!enhancedCrudUi) {
      refresh();
      return;
    }
    const timer = window.setTimeout(() => {
      refresh();
    }, 250);
    return () => window.clearTimeout(timer);
  }, [enhancedCrudUi, refresh]);

  useEffect(() => {
    setSelectedIds((prev) => prev.filter((id) => visibleRows.some((row: any) => row.id === id)));
  }, [visibleRows]);

  function initCreate() {
    const form: Record<string, any> = { ...(defaultCreate || {}) };
    for (const f of fields) {
      if (!(f.name in form)) form[f.name] = f.type === "emails" ? [] : "";
    }
    setOpen({ mode: "create", form });
  }

  function goCreate() {
    if (createTo) {
      const rt = encodeURIComponent(loc.pathname + loc.search);
      const sep = createTo.includes("?") ? "&" : "?";
      nav(`${createTo}${sep}rt=${rt}`);
      return;
    }
    initCreate();
  }

  function initEdit(row: any) {
    const form: Record<string, any> = {};
    for (const f of fields) {
      let v = row[f.name];
      if (f.type === "emails") {
        v = Array.isArray(v) ? v.join(", ") : "";
      }
      form[f.name] = v ?? "";
    }
    setOpen({ mode: "edit", id: row.id, form });
  }

  function setForm(name: string, value: any) {
    setOpen((prev) => {
      if (!prev) return prev;
      return { ...prev, form: { ...prev.form, [name]: value } } as any;
    });
  }

  function normalize(form: Record<string, any>) {
    const out: Record<string, any> = {};
    for (const [k, v] of Object.entries(form)) {
      const f = fieldMap.get(k);
      if (f?.type === "emails") {
        const arr = String(v || "")
          .split(",")
          .map((s) => s.trim())
          .filter(Boolean);
        out[k] = arr;
      } else {
        out[k] = v === "" ? undefined : v;
      }
    }
    return toPayload ? toPayload(out) : out;
  }

  async function submit() {
    if (!open) return;

    const visibleFields = fields.filter((f) => !f.showWhen || f.showWhen(open.form));

    for (const f of visibleFields) {
      if (!f.required) continue;
      const v = open.form[f.name];
      if (f.type === "emails") {
        if (!String(v || "").trim()) {
          setErr(`${f.label} is required`);
          return;
        }
      } else if (v === undefined || v === null || String(v).trim() === "") {
        setErr(`${f.label} is required`);
        return;
      }
    }

    setErr(null);
    try {
      const payload = normalize(open.form);
      if (open.mode === "create") {
        await createMaster<T>(path, payload);
      } else {
        await updateMaster<T>(path, open.id, payload);
      }
      setOpen(null);
      await refresh();
    } catch (e: any) {
      const ae = e as ApiError;
      setErr(ae.message || "Failed to save");
    }
  }

  async function doDisable(id: string) {
    if (!canDelete) return;
    openActionConfirm({
      title: "Disable item?",
      message: "This will move the item to inactive state. You can enable it again later.",
      confirmLabel: "Disable",
      tone: "danger",
      onConfirm: async () => {
        await disableMaster(path, id);
        await refresh();
      },
    });
  }

  async function doEnable(id: string) {
    if (!canUpdate) return;
    openActionConfirm({
      title: "Enable item?",
      message: "This will make the item active again and available for normal use.",
      confirmLabel: "Enable",
      tone: "primary",
      onConfirm: async () => {
        await enableMaster(path, id);
        await refresh();
      },
    });
  }

  async function doPermanentDelete(id: string) {
    if (!canDelete) return;
    openActionConfirm({
      title: "Delete item permanently?",
      message: "This action cannot be undone. Only inactive items should be deleted permanently.",
      confirmLabel: "Delete permanently",
      tone: "danger",
      onConfirm: async () => {
        await permanentDeleteMaster(path, id);
        await refresh();
      },
    });
  }

  async function runBulkAction(action: "disable" | "enable" | "delete") {
    if (!hasSelection) return;

    const count = selectedIds.length;
    const title =
      action === "disable"
        ? `Disable ${count} selected item(s)?`
        : action === "enable"
          ? `Enable ${count} selected item(s)?`
          : `Delete ${count} selected inactive item(s)?`;
    const message =
      action === "disable"
        ? "Selected items will move to inactive state. You can enable them again later."
        : action === "enable"
          ? "Selected items will become active again and available for normal use."
          : "This action cannot be undone. Only inactive items should be deleted permanently.";

    const targets = [...selectedIds];
    const runner =
      action === "disable"
        ? (id: string) => disableMaster(path, id)
        : action === "enable"
          ? (id: string) => enableMaster(path, id)
          : (id: string) => permanentDeleteMaster(path, id);

    openActionConfirm({
      title,
      message,
      confirmLabel: action === "disable" ? "Disable selected" : action === "enable" ? "Enable selected" : "Delete selected",
      tone: action === "enable" ? "primary" : "danger",
      onConfirm: async () => {
        const results = await Promise.allSettled(targets.map((id) => runner(id)));
        const failed = results.filter((r) => r.status === "rejected");

        setSelectedIds([]);
        await refresh();

        if (failed.length > 0) {
          const first = failed[0] as PromiseRejectedResult;
          const ae = first.reason as ApiError;
          throw new Error(ae?.message || `${failed.length} item(s) failed during bulk ${action}.`);
        }
      },
    });
  }

  function startSelectionMode() {
    setSelectionMode(true);
  }

  function stopSelectionMode() {
    setSelectionMode(false);
    setSelectedIds([]);
  }

  function toggleSelected(id: string, checked: boolean) {
    setSelectedIds((prev) => {
      if (checked) return prev.includes(id) ? prev : [...prev, id];
      return prev.filter((x) => x !== id);
    });
  }

  function toggleSelectAll(checked: boolean) {
    if (!checked) {
      setSelectedIds([]);
      return;
    }
    setSelectedIds(visibleRows.map((row: any) => row.id));
  }

  function isInactiveRow(row: any) {
    return row?.status === "INACTIVE";
  }

  function openActionConfirm(config: {
    title: string;
    message: string;
    confirmLabel: string;
    tone: "primary" | "danger";
    onConfirm: () => Promise<void> | void;
  }) {
    setConfirmAction(config);
  }

  async function runConfirmedAction(action: () => Promise<void> | void) {
    setErr(null);
    try {
      await action();
      setConfirmAction(null);
    } catch (e: any) {
      const ae = e as ApiError;
      setErr(ae.message || "Action failed");
    }
  }

  async function handleConfirmAction() {
    if (!confirmAction || confirmBusy) return;
    setConfirmBusy(true);
    try {
      await runConfirmedAction(confirmAction.onConfirm);
    } finally {
      setConfirmBusy(false);
    }
  }

  function rowActionItems(row: any) {
    if (supportsEnableAndPermanentDelete && isInactiveRow(row)) {
      return [
        canUpdate ? { label: "Edit", kind: "neutral" as const, onClick: () => initEdit(row) } : null,
        canUpdate ? { label: "Enable", kind: "primary" as const, onClick: () => doEnable(row.id) } : null,
        canDelete ? { label: "Delete", kind: "danger" as const, onClick: () => doPermanentDelete(row.id) } : null,
      ].filter(Boolean) as Array<{ label: string; kind: "primary" | "neutral" | "danger"; onClick: () => void | Promise<void> }>;
    }

    return [
      canUpdate ? { label: "Edit", kind: "neutral" as const, onClick: () => initEdit(row) } : null,
      canDelete ? { label: "Disable", kind: "danger" as const, onClick: () => doDisable(row.id) } : null,
    ].filter(Boolean) as Array<{ label: string; kind: "primary" | "neutral" | "danger"; onClick: () => void | Promise<void> }>;
  }

  return (
    <div style={{ padding: 16, display: "grid", gap: 12, width: "100%", minWidth: 0 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
        <h2 style={{ margin: 0 }}>{title}</h2>

        <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap", justifyContent: "flex-end" }}>
          {supportsInactive && enhancedCrudUi ? (
            <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
              <button type="button" onClick={() => setStatusView("ACTIVE")} style={tabButtonStyle(statusView === "ACTIVE")}>
                Active
              </button>
              <button type="button" onClick={() => setStatusView("INACTIVE")} style={tabButtonStyle(statusView === "INACTIVE")}>
                Inactive
              </button>
            </div>
          ) : supportsInactive ? (
            <label style={{ display: "flex", gap: 6, alignItems: "center", fontSize: 13, opacity: 0.85 }}>
              <input type="checkbox" checked={includeInactive} onChange={(e) => setIncludeInactive(e.target.checked)} />
              Include inactive
            </label>
          ) : null}

          <input
            placeholder="Search by name"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            style={{ width: 260, minHeight: 38 }}
          />

          {!enhancedCrudUi && (
            <button onClick={refresh} disabled={loading}>
              Search
            </button>
          )}

          {enhancedCrudUi ? (
            <button type="button" onClick={selectionMode ? stopSelectionMode : startSelectionMode}>
              {selectionMode ? "Cancel Select" : "Select Multiple"}
            </button>
          ) : null}

          {canCreate && <button onClick={goCreate}>{createLabel || "Add"}</button>}
        </div>
      </div>

      {showSelectionUi && hasSelection ? (
        <div
          style={{
            display: "flex",
            gap: 10,
            alignItems: "center",
            flexWrap: "wrap",
            padding: "12px 14px",
            border: "1px solid #e5e7eb",
            borderRadius: 14,
            background: "#fff",
            boxShadow: "0 6px 18px rgba(15, 23, 42, 0.05)",
          }}
        >
          <div style={{ fontWeight: 700 }}>{selectedIds.length} selected</div>
          {statusView === "ACTIVE" ? (
            canDelete ? <button onClick={() => runBulkAction("disable")}>Disable Selected</button> : null
          ) : (
            <>
              {canUpdate ? <button onClick={() => runBulkAction("enable")}>Enable Selected</button> : null}
              {canDelete ? <button onClick={() => runBulkAction("delete")}>Delete Selected</button> : null}
            </>
          )}
          <button type="button" onClick={stopSelectionMode}>
            Clear Selection
          </button>
        </div>
      ) : null}

      {err ? <div style={{ color: "crimson", fontWeight: 600 }}>{err}</div> : null}

      {showSelectionUi && !hasSelection ? (
        <div style={{ fontSize: 13, color: "#475569" }}>Select the rows you want for bulk action.</div>
      ) : null}

      {loading ? (
        <div>Loading...</div>
      ) : visibleRows.length === 0 ? (
        <div style={{ opacity: 0.7 }}>No data</div>
      ) : (
        <div style={{ width: "100%", minWidth: 0, overflowX: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", background: "#fff", borderRadius: 14, overflow: "hidden" }}>
            <thead>
              <tr>
                {showSelectionUi ? (
                  <th style={{ width: 44, textAlign: "center", padding: "10px 6px", borderBottom: "1px solid #e5e7eb" }}>
                    <input type="checkbox" checked={allVisibleSelected} onChange={(e) => toggleSelectAll(e.target.checked)} />
                  </th>
                ) : null}
                {columns.map((c) => (
                  <th key={c.key} style={{ textAlign: "left", padding: "10px 8px", borderBottom: "1px solid #e5e7eb", background: "#f8fafc" }}>
                    {c.label}
                  </th>
                ))}
                <th style={{ width: showSelectionUi ? 72 : enhancedCrudUi ? 72 : 220, borderBottom: "1px solid #e5e7eb", background: "#f8fafc" }} />
              </tr>
            </thead>
            <tbody>
              {visibleRows.map((r: any) => {
                const checked = selectedIds.includes(r.id);
                return (
                  <tr key={r.id} style={checked ? { background: "#f8fbff" } : undefined}>
                    {showSelectionUi ? (
                      <td style={{ padding: "10px 6px", borderBottom: "1px solid #f1f5f9", textAlign: "center" }}>
                        <input type="checkbox" checked={checked} onChange={(e) => toggleSelected(r.id, e.target.checked)} />
                      </td>
                    ) : null}
                    {columns.map((c) => (
                      <td key={c.key} style={{ padding: "10px 8px", borderBottom: "1px solid #f1f5f9" }}>
                        {c.render ? c.render(r) : r[c.key]}
                      </td>
                    ))}
                    <td style={{ padding: "10px 8px", borderBottom: "1px solid #f1f5f9" }}>
                      {enhancedCrudUi ? (
                        <div style={{ display: "flex", justifyContent: "center" }}>
                          <button
                            type="button"
                            aria-label="Actions"
                            onClick={() => setActionsRow(r)}
                            style={{
                              width: 34,
                              height: 34,
                              border: "none",
                              background: "transparent",
                              fontSize: 20,
                              lineHeight: 1,
                              cursor: "pointer",
                              padding: 0,
                            }}
                          >
                            ⋯
                          </button>
                        </div>
                      ) : (
                        <div style={{ display: "flex", gap: 8, justifyContent: "flex-end", flexWrap: "wrap" }}>
                          {canUpdate && <button onClick={() => initEdit(r)}>Edit</button>}
                          {supportsEnableAndPermanentDelete && r.status === "INACTIVE" ? (
                            <>
                              {canUpdate && <button onClick={() => doEnable(r.id)}>Enable</button>}
                              {canDelete && <button onClick={() => doPermanentDelete(r.id)}>Delete</button>}
                            </>
                          ) : (
                            canDelete && <button onClick={() => doDisable(r.id)}>Disable</button>
                          )}
                        </div>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}

      {open && (
        <AppModal
          open={!!open}
          title={open.mode === "create" ? `Create ${title}` : `Edit ${title}`}
          onClose={() => setOpen(null)}
          width={720}
        >
          <div style={{ display: "grid", gap: 10 }}>
            {fields.filter((f) => !f.showWhen || f.showWhen(open.form)).map((f) => (
              <div key={f.name} style={{ display: "grid", gap: 6 }}>
                <label style={{ fontWeight: 600 }}>
                  {f.label} {f.required ? <span style={{ color: "crimson" }}>*</span> : null}
                </label>

                {f.type === "textarea" ? (
                  <textarea
                    value={open.form[f.name] ?? ""}
                    placeholder={f.placeholder}
                    onChange={(e) => setForm(f.name, e.target.value)}
                    rows={4}
                  />
                ) : f.type === "select" ? (
                  <select value={open.form[f.name] ?? ""} onChange={(e) => setForm(f.name, e.target.value)}>
                    <option value="">-- Select --</option>
                    {(f.options || []).map((o) => (
                      <option key={o.value} value={o.value}>
                        {o.label}
                      </option>
                    ))}
                  </select>
                ) : f.type === "segmented" ? (
                  <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                    {(f.options || []).map((o) => {
                      const active = String(open.form[f.name] ?? "") === String(o.value);
                      return (
                        <button
                          key={o.value}
                          type="button"
                          onClick={() => setForm(f.name, o.value)}
                          style={segmentedButtonStyle(active)}
                        >
                          {o.label}
                        </button>
                      );
                    })}
                  </div>
                ) : (
                  <input
                    type={f.type === "number" ? "number" : "text"}
                    value={open.form[f.name] ?? ""}
                    placeholder={f.placeholder}
                    onChange={(e) => setForm(f.name, e.target.value)}
                  />
                )}

                {f.help && <div style={{ fontSize: 12, opacity: 0.75 }}>{f.help}</div>}
              </div>
            ))}

            <div style={{ display: "flex", gap: 8, justifyContent: "flex-end", marginTop: 8 }}>
              <button onClick={() => setOpen(null)}>Cancel</button>
              <button onClick={submit}>{open.mode === "create" ? "Create" : "Save"}</button>
            </div>
          </div>
        </AppModal>
      )}

      {enhancedCrudUi && actionsRow ? (
        <AppModal open={!!actionsRow} title="Actions" onClose={() => setActionsRow(null)} width="sm">
          <div style={{ display: "grid", gap: 10, padding: 4 }}>
            {rowActionItems(actionsRow).map((item) => (
              <button
                key={item.label}
                type="button"
                style={actionButtonStyle(item.kind)}
                onClick={async () => {
                  setActionsRow(null);
                  await item.onClick();
                }}
              >
                {item.label}
              </button>
            ))}
          </div>
        </AppModal>
      ) : null}


      {confirmAction ? (
        <AppModal
          open={!!confirmAction}
          title={confirmAction.title}
          onClose={() => {
            if (!confirmBusy) setConfirmAction(null);
          }}
          width="sm"
          closeLabel="Close confirmation"
          panelStyle={{ background: "#ffffff" }}
          bodyStyle={{ paddingTop: 12 }}
          footer={
            <>
              <button type="button" className="btn btn--ghost" onClick={() => setConfirmAction(null)} disabled={confirmBusy}>
                Cancel
              </button>
              <button
                type="button"
                className={confirmAction.tone === "danger" ? "btn btn--danger" : "btn btn--primary"}
                onClick={handleConfirmAction}
                disabled={confirmBusy}
              >
                {confirmBusy ? "Please wait..." : confirmAction.confirmLabel}
              </button>
            </>
          }
        >
          <div style={{ display: "grid", gap: 12 }}>
            <div style={{ fontSize: 14, lineHeight: 1.6, color: "#334155" }}>{confirmAction.message}</div>
          </div>
        </AppModal>
      ) : null}
    </div>
  );
}
