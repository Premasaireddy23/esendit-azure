export const ACCOUNTS_PAGE_PERMISSIONS = ["page:masters:accounts", "MASTERS_READ"] as const;
export const ACCOUNTS_CREATE_PERMISSIONS = ["action:masters:accounts:create", "MASTERS_CREATE"] as const;
export const ACCOUNTS_UPDATE_PERMISSIONS = ["action:masters:accounts:update", "MASTERS_UPDATE"] as const;
export const ACCOUNTS_DELETE_PERMISSIONS = ["action:masters:accounts:delete", "MASTERS_DELETE"] as const;
