import { useEffect, useState } from "react";
import { Outlet } from "react-router-dom";
import { getMe, hasAnyPerm, type MeResponse } from "../../lib/me";
import { ACCOUNTS_PAGE_PERMISSIONS } from "./accountsPermissions";
import { ALL_MASTERS_LAYOUT_PAGE_PERMISSIONS } from "./mastersPermissions";
import { HomeRefreshBar } from "../../ui/HomeRefreshBar";
import { MasterSectionTabs } from "./MasterSectionTabs";

export function MastersLayout() {
  const [me, setMe] = useState<MeResponse | null | undefined>(undefined);

  useEffect(() => {
    getMe().then(setMe).catch(() => setMe(null));
  }, []);

  const canLayoutAccess = hasAnyPerm(me ?? null, [...ALL_MASTERS_LAYOUT_PAGE_PERMISSIONS, ...ACCOUNTS_PAGE_PERMISSIONS]);

  if (me === undefined) {
    return <div style={{ padding: 16 }}>Checking permissions…</div>;
  }

  if (!canLayoutAccess) {
    return (
      <div style={{ padding: 16 }}>
        <HomeRefreshBar title="Masters" flat />
        <div className="card" style={{ padding: 12, marginTop: 12 }}>
          You don’t have permission to open this section.
        </div>
      </div>
    );
  }

  // ✅ IMPORTANT: no extra internal sidebar/menu here
  return (
    <div style={{ padding: 16, display: "grid", gap: 12 }}>
      <HomeRefreshBar title="Masters" flat />
      <MasterSectionTabs me={me ?? null} />
      <Outlet />
    </div>
  );
}
