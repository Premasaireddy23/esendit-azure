import { useEffect, useState } from "react";
import { getMe, hasAnyPerm, type MeResponse } from "../../../lib/me";
import { MasterCrudPage, type ColumnDef, type FieldDef } from "../MasterCrudPage";
import { ACCOUNTS_CREATE_PERMISSIONS, ACCOUNTS_DELETE_PERMISSIONS, ACCOUNTS_PAGE_PERMISSIONS, ACCOUNTS_UPDATE_PERMISSIONS } from "../accountsPermissions";

type AccountRow = {
  id: string;
  name: string;
  accountType: "SENDER" | "RECEIVER" | string;
  receiverCategory: "TV" | "DIGITAL" | "OTT" | "CINEMA" | "RADIO" | null;
  contactNo: string | null;
  gstNumber: string | null;
  panNumber: string | null;
  address: string | null;
  emails: string[];
  remarks: string | null;
  status: "ACTIVE" | "INACTIVE" | string;
  createdAt: string;
  updatedAt: string;
};

const ACCOUNT_TYPES = [
  { value: "SENDER", label: "Sender Account" },
  { value: "RECEIVER", label: "Receiver Account" },
];

const RECEIVER_CATEGORIES = [
  { value: "TV", label: "TV Broadcaster" },
  { value: "DIGITAL", label: "Digital" },
  { value: "OTT", label: "OTT" },
  { value: "CINEMA", label: "Cinema" },
  { value: "RADIO", label: "Radio" },
];

const RECEIVER_CATEGORY_LABELS: Record<string, string> = {
  TV: "TV Broadcaster",
  DIGITAL: "Digital",
  OTT: "OTT",
  CINEMA: "Cinema",
  RADIO: "Radio",
};

export function AccountsPage() {
  const [me, setMe] = useState<MeResponse | null | undefined>(undefined);

  useEffect(() => {
    getMe().then(setMe).catch(() => setMe(null));
  }, []);

  if (me === undefined) {
    return <div style={{ padding: 16 }}>Checking permissions…</div>;
  }

  if (!hasAnyPerm(me ?? null, [...ACCOUNTS_PAGE_PERMISSIONS])) {
    return (
      <div className="card" style={{ padding: 12 }}>
        You don’t have permission. Need <code>page:masters:accounts</code> (or temporary legacy <code>MASTERS_READ</code>).
      </div>
    );
  }

  const canCreate = hasAnyPerm(me ?? null, [...ACCOUNTS_CREATE_PERMISSIONS]);
  const canUpdate = hasAnyPerm(me ?? null, [...ACCOUNTS_UPDATE_PERMISSIONS]);
  const canDelete = hasAnyPerm(me ?? null, [...ACCOUNTS_DELETE_PERMISSIONS]);

  const columns: ColumnDef<AccountRow>[] = [
    { key: "name", label: "Name" },
    {
      key: "accountType",
      label: "Type",
      render: (r) => (r.accountType === "SENDER" ? "Sender" : r.accountType === "RECEIVER" ? "Receiver" : r.accountType),
    },
    { key: "receiverCategory", label: "Receiver Category", render: (r) => (r.receiverCategory ? RECEIVER_CATEGORY_LABELS[r.receiverCategory] || r.receiverCategory : "-") },
    { key: "status", label: "Status" },
    { key: "updatedAt", label: "Updated" },
  ];

  const fields: FieldDef[] = [
    { name: "name", label: "Account Name", type: "text", required: true, placeholder: "e.g. Zee TV / JioCinema" },
    {
      name: "accountType",
      label: "Account Type",
      type: "segmented",
      required: true,
      options: ACCOUNT_TYPES,
    },
    {
      name: "receiverCategory",
      label: "Receiver Category",
      type: "segmented",
      required: true,
      options: RECEIVER_CATEGORIES,
      showWhen: (form) => form.accountType === "RECEIVER",
    },

    { name: "contactNo", label: "Contact No", type: "text", required: false, placeholder: "+91..." },
    { name: "gstNumber", label: "GST No", type: "text", required: false },
    { name: "panNumber", label: "PAN No", type: "text", required: false },
    { name: "address", label: "Address", type: "textarea", required: false, fullWidth: true },
    { name: "emails", label: "Email IDs", type: "emails", required: false, placeholder: "a@x.com, b@y.com" },
    { name: "remarks", label: "Remarks", type: "textarea", required: false, fullWidth: true },
  ];

  return (
    <MasterCrudPage<AccountRow>
      title="Accounts"
      path="/masters/partner-accounts"
      columns={columns}
      fields={fields}
      canCreate={canCreate}
      canUpdate={canUpdate}
      canDelete={canDelete}
      supportsInactive
      supportsEnableAndPermanentDelete
      enhancedCrudUi
      defaultCreate={{ accountType: "SENDER" }}
      createLabel="Create Account"
      toPayload={(form) => ({
        ...form,
        receiverCategory: form.accountType === "RECEIVER" ? form.receiverCategory : undefined,
      })}
    />
  );
}
