import { useEffect, useMemo, useState } from "react";
import { getMe, hasPerm, type MeResponse } from "../../../lib/me";
import { listMasters } from "../mastersApi";
import { MasterCrudPage } from "../MasterCrudPage";
import type { SelectOption } from "../types";

type CountryRow = { id: string; name: string; status?: string };

export function CitiesPage() {
  const [me, setMe] = useState<MeResponse | null>(null);
  const [countries, setCountries] = useState<SelectOption[]>([]);

  useEffect(() => {
    getMe().then(setMe).catch(() => setMe(null));
  }, []);

  useEffect(() => {
    listMasters<CountryRow>("/masters/countries")
      .then((rows) => rows.map((r) => ({ value: r.id, label: `${r.name}${r.status === "INACTIVE" ? " (inactive)" : ""}` })))
      .then(setCountries)
      .catch(() => setCountries([]));
  }, []);

  const fields = useMemo(
    () => [
      { name: "name", label: "Name", type: "text" as const, required: true, placeholder: "e.g. Dublin" },
      { name: "countryId", label: "Country", type: "select" as const, required: true, options: countries },
    ],
    [countries],
  );

  return (
    <MasterCrudPage
      title="Cities"
      path="/masters/cities"
      canCreate={hasPerm(me, "MASTERS_CREATE")}
      canUpdate={hasPerm(me, "MASTERS_UPDATE")}
      canDelete={hasPerm(me, "MASTERS_DELETE")}
      columns={[
        { key: "name", label: "Name" },
        { key: "countryId", label: "CountryId" },
        { key: "status", label: "Status" },
      ]}
      fields={fields}
    />
  );
}
