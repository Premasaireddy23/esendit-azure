import { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { getMe, hasAnyPerm, type MeResponse } from "../../../lib/me";
import {
  AGENCY_TEAMS_CREATE_PERMISSIONS,
  AGENCY_TEAMS_DELETE_PERMISSIONS,
  AGENCY_TEAMS_UPDATE_PERMISSIONS,
} from "../mastersPermissions";
import { listMasters } from "../mastersApi";
import { MasterCrudPage } from "../MasterCrudPage";
import type { AgencyType, SelectOption } from "../types";

const AGENCY_TYPES = ["MEDIA", "CREATIVE", "POST_HOUSE", "PRODUCTION_HOUSE", "AUDIO", "UPLOADER"] as const;

type AgencyRow = { id: string; name: string; type?: string; status?: string };

function normalizeType(v: string | null): AgencyType {
  if (!v) return "MEDIA";
  const up = v.toUpperCase();
  return (AGENCY_TYPES as readonly string[]).includes(up) ? (up as AgencyType) : ("MEDIA" as AgencyType);
}

function prettyType(t: string) {
  switch (t) {
    case "MEDIA":
      return "Media Agency";
    case "CREATIVE":
      return "Creative Agency";
    case "POST_HOUSE":
      return "Post House";
    case "PRODUCTION_HOUSE":
      return "Production House";
    case "AUDIO":
      return "Audio Agency";
    case "UPLOADER":
      return "Uploader Agency";
    default:
      return t;
  }
}

export function AgencyTeamsPage() {
  const [sp] = useSearchParams();
  const type = normalizeType(sp.get("type"));

  const [me, setMe] = useState<MeResponse | null>(null);
  const [agencyId, setAgencyId] = useState<string>("");
  const [agencies, setAgencies] = useState<SelectOption[]>([]);

  useEffect(() => {
    getMe().then(setMe).catch(() => setMe(null));
  }, []);

  useEffect(() => {
    // Load agencies for the selected type (for dropdown)
    listMasters<AgencyRow>("/masters/agencies")
      .then((rows) =>
        rows
          .filter((r) => String(r.type || "").toUpperCase() === String(type).toUpperCase())
          .map((r) => ({
            value: r.id,
            label: `${r.name}${r.status === "INACTIVE" ? " (inactive)" : ""}`,
          })),
      )
      .then(setAgencies)
      .catch(() => setAgencies([]));
  }, [type]);

  const fields = useMemo(
    () => [
      { name: "name", label: "Team Name", type: "text" as const, required: true },
      { name: "emails", label: "Email IDs", type: "emails" as const, help: "Comma-separated" },
      { name: "contactNo", label: "Contact No", type: "text" as const, placeholder: "optional" },
      { name: "gstNumber", label: "GST No", type: "text" as const, placeholder: "optional" },
      { name: "panNumber", label: "PAN No", type: "text" as const, placeholder: "optional" },
      { name: "address", label: "Address", type: "textarea" as const, placeholder: "optional" },
      { name: "remarks", label: "Remarks", type: "textarea" as const, placeholder: "optional" },
    ],
    [],
  );

  const canCrud = Boolean(agencyId);

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div className="card" style={{ padding: 12 }}>
        <div style={{ display: "grid", gap: 6, maxWidth: 520 }}>
          <div style={{ fontWeight: 800 }}>{prettyType(String(type))} — Select Agency</div>
          <select value={agencyId} onChange={(e) => setAgencyId(e.target.value)}>
            <option value="">-- choose --</option>
            {agencies.map((a) => (
              <option key={a.value} value={a.value}>
                {a.label}
              </option>
            ))}
          </select>
          {!agencyId ? <div style={{ color: "#666", fontSize: 13 }}>Choose an agency to view its teams.</div> : null}
        </div>
      </div>

      <MasterCrudPage
        title={`${prettyType(String(type))} Teams`}
        path="/masters/agency-teams"
        canCreate={hasAnyPerm(me, [...AGENCY_TEAMS_CREATE_PERMISSIONS]) && canCrud}
        canUpdate={hasAnyPerm(me, [...AGENCY_TEAMS_UPDATE_PERMISSIONS]) && canCrud}
        canDelete={hasAnyPerm(me, [...AGENCY_TEAMS_DELETE_PERMISSIONS]) && canCrud}
        supportsInactive
        createTo={`/masters/agency-teams/new?type=${encodeURIComponent(String(type))}${agencyId ? `&agencyId=${encodeURIComponent(agencyId)}` : ""}`}
        createLabel="Add Team"
        transformRows={(rows: any[]) => (agencyId ? rows.filter((r) => String(r.agencyId) === String(agencyId)) : [])}
        columns={[
          { key: "name", label: "Team" },
          {
            key: "emails",
            label: "Emails",
            render: (r: any) => (Array.isArray(r.emails) ? r.emails.join(", ") : ""),
          },
          { key: "status", label: "Status" },
        ]}
        fields={fields}
      />
    </div>
  );
}
