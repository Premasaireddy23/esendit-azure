import { useEffect, useMemo, useRef, useState, type CSSProperties } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { api, type ApiError } from "../../../lib/api";
import { SearchSelect } from "../../../ui/SearchSelect";

type MasterStatus = "ACTIVE" | "INACTIVE";
// Backend enum (Prisma) expects: TV, DIGITAL, OTT, CINEMA, RADIO
type DestinationCategory = "TV" | "DIGITAL" | "OTT" | "CINEMA" | "RADIO";

type Country = { id: string; name: string; code?: string };
type City = { id: string; name: string; countryId: string };

type Channel = { id: string; name: string; destinationId?: string | null };
type DeliveryProfile = { id: string; name: string; protocol?: string | null };

type Preset = { key: string; label?: string; ext: string; mimeType: string; args?: string[] };

type Destination = {
  id: string;
  name: string;
  uri: string;
  category?: DestinationCategory | null;
  destinationAccount?: string | null;
  countryId?: string | null;
  cityId?: string | null;
  status?: MasterStatus | null;
  config?: any;
  fileNameTemplate?: string | null;
  downloadPresets?: any; // legacy (kept for backward compatibility)
  createdAt?: string;
  updatedAt?: string;
};

type PartnerAccount = {
  id: string;
  name: string;
  accountType: "SENDER" | "RECEIVER" | string;
  receiverCategory?: DestinationCategory | null;
  emails?: string[];
  status?: MasterStatus | null;
};

function receiverAccountIdFromConfig(raw: any) {
  const cfg = raw && typeof raw === "object" ? raw : {};
  return String((cfg as any).receiverAccountId || "").trim();
}

function withReceiverAccountId(raw: any, receiverAccountId: string) {
  const cfg = raw && typeof raw === "object" ? { ...raw } : {};
  const clean = String(receiverAccountId || "").trim();
  if (clean) (cfg as any).receiverAccountId = clean;
  else delete (cfg as any).receiverAccountId;
  return cfg;
}
function destinationClientEmailsFromConfig(raw: any): string[] {
  const cfg = raw && typeof raw === "object" ? raw : {};
  const candidates = [
    (cfg as any).clientEmails,
    (cfg as any).clientNotificationEmails,
    (cfg as any).notificationEmails,
    (cfg as any).emails,
  ];
  for (const candidate of candidates) {
    if (Array.isArray(candidate)) {
      return Array.from(new Set(candidate.map((v: any) => String(v || "").trim().toLowerCase()).filter(Boolean)));
    }
    if (typeof candidate === "string") {
      return Array.from(new Set(candidate.split(/[;,\n]+/g).map((v) => String(v || "").trim().toLowerCase()).filter(Boolean)));
    }
  }
  return [];
}

function withDestinationClientEmails(raw: any, emailsText: string) {
  const cfg = raw && typeof raw === "object" ? { ...raw } : {};
  const emails = Array.from(
    new Set(
      String(emailsText || "")
        .split(/[;,\n]+/g)
        .map((v) => String(v || "").trim().toLowerCase())
        .filter(Boolean),
    ),
  );
  if (emails.length) (cfg as any).clientEmails = emails;
  else delete (cfg as any).clientEmails;
  delete (cfg as any).clientNotificationEmails;
  delete (cfg as any).notificationEmails;
  delete (cfg as any).emails;
  return cfg;
}

function partnerAccountEmailsText(account?: PartnerAccount | null) {
  if (!account) return "";
  return Array.from(
    new Set(
      (Array.isArray(account.emails) ? account.emails : [])
        .map((value) => String(value || "").trim().toLowerCase())
        .filter(Boolean),
    ),
  ).join(", ");
}

function destinationDeliveryDefinitionFromConfig(raw: any): "" | "SD" | "HD" {
  const cfg = raw && typeof raw === "object" ? raw : {};
  const value = String((cfg as any).deliveryDefinition ?? (cfg as any).clientDeliveryType ?? "").trim().toUpperCase();
  return value === "SD" || value === "HD" ? (value as "SD" | "HD") : "";
}

function withDestinationDeliveryDefinition(raw: any, deliveryDefinition: string) {
  const cfg = raw && typeof raw === "object" ? { ...raw } : {};
  const clean = String(deliveryDefinition || "").trim().toUpperCase();
  if (clean === "SD" || clean === "HD") (cfg as any).deliveryDefinition = clean;
  else delete (cfg as any).deliveryDefinition;
  delete (cfg as any).clientDeliveryType;
  return cfg;
}

function destinationApprovalRequiredFromConfig(raw: any) {
  const cfg = raw && typeof raw === "object" ? raw : {};
  return (cfg as any).approvalRequired === true;
}

function withDestinationApprovalRequired(raw: any, approvalRequired: boolean) {
  const cfg = raw && typeof raw === "object" ? { ...raw } : {};
  if (approvalRequired) (cfg as any).approvalRequired = true;
  else delete (cfg as any).approvalRequired;
  return cfg;
}

function receiverAccountLabel(account?: PartnerAccount | null) {
  if (!account) return "";
  const category = account.receiverCategory ? categoryLabel(account.receiverCategory) : "";
  const inactive = account.status === "INACTIVE" ? " • Inactive" : "";
  return `${account.name}${category ? ` • ${category}` : ""}${inactive}`;
}

const FILE_NOMEN_TOKENS: Array<{ token: string; label: string; hint?: string }> = [
  { token: "{DESTINATION}", label: "Destination" },
  { token: "{CHANNEL}", label: "Channel" },
  { token: "{PROJECT}", label: "Project" },
  { token: "{VALID}", label: "Creative Valid" },
  { token: "{CREATIVE}", label: "Creative Name" },
  { token: "{CAPTION}", label: "Caption" },
  { token: "{HOUSE_ID}", label: "House ID", hint: "Used for approval-required deliveries" },
  { token: "{DUR}", label: "Duration" },
  { token: "{DURSEC}", label: "Duration (sec)" },
  { token: "{DATE}", label: "Date (YYYYMMDD)" },
  { token: "{TIME}", label: "Time (HHmm)" },
  { token: "{UUID8}", label: "Unique 8" },
  { token: "{EXT}", label: "Ext (no dot)" },
];

const FILE_NOMEN_SEPARATORS: Array<{ token: string; label: string }> = [
  { token: "_", label: "_" },
  { token: "-", label: "-" },
  { token: ".", label: "." },
];

function safeJsonParse(text: string, fallback: any) {
  try {
    if (!text?.trim()) return fallback;
    return JSON.parse(text);
  } catch {
    return fallback;
  }
}

function pretty(v: any) {
  try {
    return JSON.stringify(v ?? {}, null, 2);
  } catch {
    return "{}";
  }
}

const DESTINATION_ICON_SRC = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAACXBIWXMAAAB2AAAAdgFOeyYIAAAAGXRFWHRTb2Z0d2FyZQB3d3cuaW5rc2NhcGUub3Jnm+48GgAAAh5JREFUOI2FkTtMU2EYhp/v7zkUECgtRARNqHiJGhaNi9EQNS66EAmCYjAlxuDiqomDcXBSE1E3F+IFIeJggokbzsY4qWhw8UrActHKaWlPz/kctKY9NvpNf973/Z98FyhTiVGND4zr2XJesExQOPJAq2qrGG6NcOrYfd3yP4AVFOpDnN/axB7LYCV/cAnoDmZ6R7RLYJ2BJ6UdqEokzP5MjmUnx3K8kY4TY9pZHDk6qnGB6NhxueH5HJJis29EN7U3M+lkCbXGaBZgao7JLykuCOxAMSIkEVrU5yuGXMkIrtBSZRNzcnwvkDc0sHshTV/bW8683oYVynJODLdW8mQfDci3EkAoj+N6ZIq1sEV4bR273m2kRVxOemFujvfIYsEv2YGTYWopw0yFgRWXbEGPR9kesrmnNkPFn/8CTAxKOrXCyzW1NOeKOjEGNjfSugrWBw5SCtj7VK3FNMnZZabrKqkv9ppqiNfaXPwnoOkz/Wq4/H6JoQWHmWC4rYGOxKj2lQUcvq0NCDs1T5eTo/7VHNem53me9/EKmZow0cYaTieGtbKg/bmCHSIBPEboEVhwfZ59WOTqbIqOWDWRCkPMB9/JMe+EWA18/APovaPtCgdEeSHKXSxmfBffGLpdj8j1TukPjlMoGXyoV6rD7ENRY/BVEVHAoAB5jwrXI/UpycGJQUkHAVbeJ43yBsD3f4kK8PttBDzBroxil+vgJ3lMw9MPGaYBAAAAAElFTkSuQmCC";

function DestinationIcon() {
  return <img src={DESTINATION_ICON_SRC} alt="" aria-hidden="true" style={{ width: 18, height: 18, objectFit: "contain", display: "block" }} />;
}


function approvalToggleButtonStyle(active: boolean): CSSProperties {
  return {
    minHeight: 38,
    padding: "9px 14px",
    borderRadius: 999,
    border: active ? "1px solid #2563eb" : "1px solid #d7dde5",
    background: active ? "#eff6ff" : "#fff",
    color: active ? "#1d4ed8" : "#1f2937",
    fontWeight: 700,
    boxShadow: active ? "0 8px 18px rgba(37, 99, 235, 0.14)" : "none",
    cursor: "pointer",
    transition: "all 180ms ease",
  };
}

function ApprovalRequiredToggle(props: { value: boolean; onChange: (next: boolean) => void }) {
  const { value, onChange } = props;
  return (
    <div style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: 8, marginBottom: 8 }}>
      <span style={{ fontSize: 13, fontWeight: 700, color: "#0f172a" }}>Approval required for this destination</span>
      <div style={{ display: "inline-flex", gap: 8, padding: 4, borderRadius: 999, background: "#f8fafc", border: "1px solid rgba(15,23,42,0.08)" }}>
        <button type="button" onClick={() => onChange(true)} aria-pressed={value} style={approvalToggleButtonStyle(value)}>
          Approval needed
        </button>
        <button type="button" onClick={() => onChange(false)} aria-pressed={!value} style={approvalToggleButtonStyle(!value)}>
          No approval
        </button>
      </div>
    </div>
  );
}

function WizardStepper(props: {
  steps: readonly string[];
  currentStep: number;
  canOpenStep: (index: number) => boolean;
  onStepClick: (index: number) => void;
}) {
  const { steps, currentStep, canOpenStep, onStepClick } = props;
  return (
    <div style={{ display: "grid", gap: 14 }}>
      <style>{`
        @keyframes wizardStepFade {
          from { opacity: 0; transform: translateX(10px); }
          to { opacity: 1; transform: translateX(0); }
        }
      `}</style>
      <div>
        <div style={{ display: "grid", gridTemplateColumns: `repeat(${steps.length}, minmax(0, 1fr))`, gap: 10, alignItems: "stretch" }}>
          {steps.map((step, index) => {
            const isActive = index === currentStep;
            const isDone = index < currentStep;
            const clickable = canOpenStep(index);
            return (
              <button
                key={step}
                type="button"
                onClick={() => clickable && onStepClick(index)}
                disabled={!clickable}
                style={{
                  width: "100%",
                  minWidth: 0,
                  minHeight: 72,
                  display: "flex",
                  alignItems: "center",
                  gap: 10,
                  padding: "12px 14px",
                  borderRadius: 16,
                  border: isActive ? "1px solid #2563eb" : isDone ? "1px solid #16a34a" : "1px solid rgba(15,23,42,0.10)",
                  background: isActive ? "rgba(37,99,235,0.08)" : isDone ? "rgba(22,163,74,0.08)" : "#fff",
                  color: "#0f172a",
                  cursor: clickable ? "pointer" : "not-allowed",
                  opacity: clickable ? 1 : 0.55,
                  transition: "all 180ms ease",
                  textAlign: "left",
                  position: "relative",
                  zIndex: 1,
                }}
              >
                <span
                  style={{
                    width: 30,
                    height: 30,
                    borderRadius: 999,
                    display: "inline-flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontSize: 12,
                    fontWeight: 900,
                    background: isActive ? "#2563eb" : isDone ? "#16a34a" : "rgba(15,23,42,0.08)",
                    color: isActive || isDone ? "#fff" : "#0f172a",
                    flex: "0 0 auto",
                  }}
                >
                  {index + 1}
                </span>
                <div style={{ minWidth: 0 }}>
                  <div style={{ fontSize: 11, fontWeight: 800, opacity: 0.7 }}>Step {index + 1}</div>
                  <div style={{ fontSize: 14, fontWeight: 900, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{step}</div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

const DESTINATION_CREATE_STEPS = ["General", "Location", "Presets"] as const;


function destinationDefaultProfileIdFromConfig(raw: any) {
  const cfg = raw && typeof raw === "object" ? raw : {};
  const defaults = cfg.deliveryProfileDefaults && typeof cfg.deliveryProfileDefaults === "object" ? cfg.deliveryProfileDefaults : {};
  return String(defaults.defaultProfileId || cfg.defaultDeliveryProfileId || "").trim();
}

function withDestinationDefaultProfile(raw: any, profileId: string) {
  const cfg = raw && typeof raw === "object" ? { ...raw } : {};
  const defaults = cfg.deliveryProfileDefaults && typeof cfg.deliveryProfileDefaults === "object" ? { ...cfg.deliveryProfileDefaults } : {};
  const nextId = String(profileId || "").trim();
  if (nextId) {
    cfg.defaultDeliveryProfileId = nextId;
    defaults.defaultProfileId = nextId;
    cfg.deliveryProfileDefaults = defaults;
  } else {
    delete cfg.defaultDeliveryProfileId;
    delete defaults.defaultProfileId;
    if (Object.keys(defaults).length) cfg.deliveryProfileDefaults = defaults;
    else delete cfg.deliveryProfileDefaults;
  }
  return cfg;
}

function splitConfig(raw: any): { config: any; allowedPresetKeys: string[]; defaultPresetKey: string; xmlEnabled: boolean; xmlConfig: any; receiverAccountId: string; clientEmailsText: string; deliveryDefinition: "" | "SD" | "HD"; approvalRequired: boolean } {
  const cfg = raw && typeof raw === "object" ? raw : {};

  const allowed = Array.isArray((cfg as any).allowedPresetKeys)
    ? (cfg as any).allowedPresetKeys.map((k: any) => String(k)).filter(Boolean)
    : [];
  const defaultPresetKey = String((cfg as any).defaultPresetKey || "").trim();
  const receiverAccountId = receiverAccountIdFromConfig(cfg);
  const clientEmailsText = destinationClientEmailsFromConfig(cfg).join(", ");
  const deliveryDefinition = destinationDeliveryDefinitionFromConfig(cfg);
  const approvalRequired = destinationApprovalRequiredFromConfig(cfg);

  const xmlRaw = (cfg as any).xml && typeof (cfg as any).xml === "object" ? (cfg as any).xml : null;
  const xmlEnabled = Boolean(xmlRaw?.enabled);
  const xmlConfig: any = xmlRaw ? { ...xmlRaw } : {};
  delete xmlConfig.enabled;

  const rest: any = { ...cfg };
  delete rest.allowedPresetKeys;
  delete rest.defaultPresetKey;
  delete rest.xml;
  delete rest.receiverAccountId;
  delete rest.clientEmails;
  delete rest.clientNotificationEmails;
  delete rest.notificationEmails;
  delete rest.emails;
  delete rest.deliveryDefinition;
  delete rest.clientDeliveryType;
  delete rest.approvalRequired;

  return { config: rest, allowedPresetKeys: allowed, defaultPresetKey, xmlEnabled, xmlConfig, receiverAccountId, clientEmailsText, deliveryDefinition, approvalRequired };
}

function mergeAllowedPresets(cfg: any, allowedPresetKeys: string[]) {
  const next: any = cfg && typeof cfg === "object" ? { ...cfg } : {};
  const keys = (allowedPresetKeys || []).map((k) => String(k)).filter(Boolean);
  if (keys.length) next.allowedPresetKeys = Array.from(new Set(keys));
  else delete next.allowedPresetKeys;
  return next;
}

function mergeDefaultPresetKey(cfg: any, presetKey: string) {
  const next: any = cfg && typeof cfg === "object" ? { ...cfg } : {};
  const clean = String(presetKey || "").trim();
  if (clean) next.defaultPresetKey = clean;
  else delete next.defaultPresetKey;
  return next;
}

function mergeXmlConfig(cfg: any, enabled: boolean, xmlCfg: any) {
  const next: any = cfg && typeof cfg === "object" ? { ...cfg } : {};
  if (enabled) {
    const x = xmlCfg && typeof xmlCfg === "object" ? { ...xmlCfg } : {};
    (x as any).enabled = true;
    next.xml = x;
  } else {
    delete next.xml;
  }
  return next;
}

function sanitizeFileNamePart(v: string) {
  const s = String(v || "")
    .trim()
    .replace(/[\/\\?%*:|"<>]/g, "_")
    .replace(/\s+/g, "_")
    .replace(/_+/g, "_")
    .slice(0, 120);
  return s || "metadata";
}

function xmlEscape(v: any) {
  return String(v ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function renderTemplateWithValues(tpl: string, values: Record<string, string>) {
  return String(tpl || "").replace(/\{([A-Z0-9_]+)\}/g, (_m, k) => {
    const v = values[k];
    return v == null ? "" : String(v);
  });
}

function computeXmlFileNamePreview(xmlCfg: any, values: Record<string, string>) {
  const base = values.BASENAME || "metadata";
  const fallback = `${sanitizeFileNamePart(base)}.xml`;

  const fileName = xmlCfg?.fileName && String(xmlCfg.fileName).trim() ? String(xmlCfg.fileName).trim() : "";
  if (fileName) return fileName.toLowerCase().endsWith(".xml") ? fileName : `${fileName}.xml`;

  const tpl = xmlCfg?.fileNameTemplate && String(xmlCfg.fileNameTemplate).trim() ? String(xmlCfg.fileNameTemplate).trim() : "";
  if (tpl) {
    const n = sanitizeFileNamePart(renderTemplateWithValues(tpl, values));
    return n.toLowerCase().endsWith(".xml") ? n : `${n}.xml`;
  }

  return fallback;
}

function buildXmlPreview(xmlCfg: any, values: Record<string, string>) {
  const cfg = xmlCfg && typeof xmlCfg === "object" ? xmlCfg : {};

  if (cfg?.template && String(cfg.template).trim()) {
    return renderTemplateWithValues(String(cfg.template), values);
  }

  const rootTag = String(cfg?.rootTag || "DeliveryMetadata");
  const ns = cfg?.namespace || cfg?.xmlns || null;
  const xmlns = ns ? ` xmlns="${xmlEscape(ns)}"` : "";

  const defaultKeys = ["TASK_ID", "ACCOUNT_ID", "PROJECT", "CREATIVE", "VALID", "FILENAME", "REMOTE_PATH", "BYTES", "GENERATED_AT"];
  const fields = Array.isArray(cfg?.fields) && cfg.fields.length ? cfg.fields : defaultKeys;

  const lines: string[] = [];
  for (const f of fields) {
    if (typeof f === "string") {
      const key = String(f || "").trim();
      if (!key) continue;
      lines.push(`  <${key}>${xmlEscape(values[key] ?? "")}</${key}>`);
      continue;
    }
    if (f && typeof f === "object") {
      const tag = String((f as any).tag || (f as any).key || "").trim();
      if (!tag) continue;
      const rawVal = (f as any).value ?? (f as any).template ?? "";
      const val = renderTemplateWithValues(String(rawVal), values);
      lines.push(`  <${tag}>${xmlEscape(val)}</${tag}>`);
    }
  }

  const inner = lines.join("\n");
  return `<?xml version="1.0" encoding="UTF-8"?>\n<${rootTag}${xmlns}>\n${inner}\n</${rootTag}>\n`;
}

function defaultXmlConfigJson() {
  return pretty({
    required: false,
    fileNameTemplate: "{BASENAME}.xml",
    rootTag: "DeliveryMetadata",
    fields: ["TASK_ID", "VALID", "FILENAME", "REMOTE_PATH", "BYTES", "GENERATED_AT"],
  });
}

function categoryLabel(c?: string | null) {
  switch (c) {
    case "TV":
      return "Television";
    case "DIGITAL":
      return "Digital";
    case "OTT":
      return "OTT";
    case "CINEMA":
      return "Cinema";
    case "RADIO":
      return "Radio";
    default:
      return c || "—";
  }
}


type PresetFilter = "ALL" | "MOV" | "MXF" | "MP4" | "HD" | "SD" | "AUDIO" | "SPECIAL";

const PRESET_FILTER_OPTIONS: Array<{ key: PresetFilter; label: string }> = [
  { key: "ALL", label: "All presets" },
  { key: "MOV", label: "MOV" },
  { key: "MXF", label: "MXF" },
  { key: "MP4", label: "MP4" },
  { key: "HD", label: "HD" },
  { key: "SD", label: "SD" },
  { key: "AUDIO", label: "Audio" },
  { key: "SPECIAL", label: "Special" },
];

function presetMeta(p: Preset) {
  const label = String(p.label || p.key || "").toUpperCase();
  const key = String(p.key || "").toUpperCase();
  const ext = String(p.ext || "").replace(/^\./, "").toUpperCase();
  const hay = `${label} ${key} ${ext}`;
  const isAudio = /\b(AAC|PCM|MP3|WAV|AUDIO|MONO|STEREO|TRACK)\b/.test(hay);
  const isHd = /\b(1920X1080|1280X720|HD|1080|720)\b/.test(hay);
  const isSd = /\b(720X576|SD|PAL|NTSC|576|480|4:3)\b/.test(hay);
  const isSpecial = /\b(IMX|XDCAM|DVCPRO|PRORES|SONY|BAT|LOUDNORM|TIMECODE)\b/.test(hay);
  return { label, key, ext, isAudio, isHd, isSd, isSpecial };
}

function presetMatchesFilter(p: Preset, filter: PresetFilter) {
  if (filter === "ALL") return true;
  const meta = presetMeta(p);
  if (filter === "MOV") return meta.ext === "MOV" || /\bMOV\b/.test(meta.label) || /\bMOV\b/.test(meta.key);
  if (filter === "MXF") return meta.ext === "MXF" || /\bMXF\b/.test(meta.label) || /\bMXF\b/.test(meta.key);
  if (filter === "MP4") return meta.ext === "MP4" || /\bMP4\b/.test(meta.label) || /\bMP4\b/.test(meta.key);
  if (filter === "HD") return meta.isHd;
  if (filter === "SD") return meta.isSd;
  if (filter === "AUDIO") return meta.isAudio;
  if (filter === "SPECIAL") return meta.isSpecial;
  return true;
}

function PresetSelectionModal(props: {
  open: boolean;
  title: string;
  subtitle: string;
  presets: Preset[];
  selectedKeys: string[];
  setSelectedKeys: (next: string[]) => void;
  search: string;
  setSearch: (value: string) => void;
  filter: PresetFilter;
  setFilter: (value: PresetFilter) => void;
  selectedOnly: boolean;
  setSelectedOnly: (value: boolean) => void;
  onClose: () => void;
  error?: string;
}) {
  const { open, title, subtitle, presets, selectedKeys, setSelectedKeys, search, setSearch, filter, setFilter, selectedOnly, setSelectedOnly, onClose, error } = props;

  const selectedSet = useMemo(() => new Set(selectedKeys), [selectedKeys]);

  const visiblePresets = useMemo(() => {
    const term = search.trim().toLowerCase();
    return presets.filter((p) => {
      if (selectedOnly && !selectedSet.has(p.key)) return false;
      if (!presetMatchesFilter(p, filter)) return false;
      if (!term) return true;
      const hay = `${p.label || ""} ${p.key || ""} ${p.ext || ""} ${p.mimeType || ""}`.toLowerCase();
      return hay.includes(term);
    });
  }, [presets, search, filter, selectedOnly, selectedSet]);

  const selectedPresets = useMemo(() => presets.filter((p) => selectedSet.has(p.key)), [presets, selectedSet]);

  useEffect(() => {
    if (!open) return;
    const onKey = (ev: KeyboardEvent) => {
      if (ev.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(15,23,42,0.45)",
        zIndex: 90,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: 20,
      }}
      onClick={onClose}
    >
      <div
        className="card"
        style={{
          width: "min(1220px, 100%)",
          height: "90vh",
          maxHeight: "90vh",
          overflow: "hidden",
          padding: 0,
          borderRadius: 20,
          boxShadow: "0 24px 60px rgba(15,23,42,0.24)",
          display: "flex",
          flexDirection: "column",
        }}
        onClick={(e) => e.stopPropagation()}
      >
        <div style={{ padding: "18px 20px", borderBottom: "1px solid rgba(15,23,42,0.08)", display: "flex", gap: 16, justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap" }}>
          <div>
            <div style={{ fontSize: 22, fontWeight: 800, color: "#0f172a" }}>{title}</div>
            <div style={{ fontSize: 13, color: "#475569", marginTop: 6, maxWidth: 760 }}>{subtitle}</div>
          </div>
          <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap", justifyContent: "flex-end" }}>
            <div style={{ borderRadius: 999, padding: "8px 12px", background: selectedKeys.length ? "#ecfdf3" : "#f8fafc", border: selectedKeys.length ? "1px solid #bbf7d0" : "1px solid rgba(15,23,42,0.08)", color: selectedKeys.length ? "#166534" : "#334155", fontSize: 12, fontWeight: 800 }}>
              {selectedKeys.length ? `${selectedKeys.length} selected` : "All presets allowed"}
            </div>
            <button type="button" className="btn btn--ghost" onClick={onClose}>Done</button>
          </div>
        </div>

        <div style={{ padding: 18, display: "grid", gridTemplateColumns: "220px minmax(0, 1fr) 320px", gap: 16, alignItems: "stretch", flex: 1, minHeight: 0, overflow: "hidden" }}>
          <div style={{ border: "1px solid rgba(15,23,42,0.08)", borderRadius: 16, background: "#f8fafc", padding: 14, overflow: "auto", minHeight: 0, height: "100%" }}>
            <div style={{ fontSize: 12, fontWeight: 800, textTransform: "uppercase", letterSpacing: 0.4, color: "#475569", marginBottom: 10 }}>Format groups</div>
            <div style={{ display: "grid", gap: 8 }}>
              {PRESET_FILTER_OPTIONS.map((opt) => {
                const active = opt.key === filter;
                return (
                  <button
                    key={opt.key}
                    type="button"
                    onClick={() => setFilter(opt.key)}
                    style={{
                      textAlign: "left",
                      borderRadius: 12,
                      padding: "10px 12px",
                      border: active ? "1px solid #22c55e" : "1px solid rgba(15,23,42,0.08)",
                      background: active ? "#ecfdf3" : "#fff",
                      color: active ? "#166534" : "#0f172a",
                      fontSize: 13,
                      fontWeight: 700,
                      cursor: "pointer",
                    }}
                  >
                    {opt.label}
                  </button>
                );
              })}
            </div>

            <div style={{ marginTop: 16, paddingTop: 14, borderTop: "1px solid rgba(15,23,42,0.08)" }}>
              <label style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13, fontWeight: 700, color: "#0f172a", cursor: "pointer" }}>
                <input type="checkbox" checked={selectedOnly} onChange={(e) => setSelectedOnly(e.target.checked)} />
                Show selected only
              </label>
            </div>
          </div>

          <div style={{ border: "1px solid rgba(15,23,42,0.08)", borderRadius: 16, background: "#fff", overflow: "hidden", minHeight: 0, display: "flex", flexDirection: "column" }}>
            <div style={{ padding: 14, borderBottom: "1px solid rgba(15,23,42,0.08)", display: "grid", gap: 8 }}>
              <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
                <input
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search by format, label, or preset key"
                  style={{ flex: "1 1 300px", minWidth: 220, padding: "11px 12px" }}
                />
                <button type="button" className="btn btn--ghost btn--sm" onClick={() => setSelectedKeys(Array.from(new Set([...selectedKeys, ...visiblePresets.map((p) => p.key)])))} disabled={!visiblePresets.length}>
                  Select visible
                </button>
                <button type="button" className="btn btn--ghost btn--sm" onClick={() => setSearch("")} disabled={!search}>
                  Clear search
                </button>
              </div>
              <div style={{ fontSize: 12, color: "#64748b" }}>Showing {visiblePresets.length} preset{visiblePresets.length === 1 ? "" : "s"}. Use this picker only when this destination should offer a limited preset list.</div>
            </div>

            {error ? (
              <div className="card" style={{ margin: 14, borderColor: "#f5a", background: "#fff5fa" }}>
                Preset library could not be loaded: {error}
              </div>
            ) : null}

            <div style={{ padding: 14, overflowY: "scroll", overflowX: "hidden", display: "grid", gap: 10, flex: 1, minHeight: 0 }}>
              {!visiblePresets.length ? (
                <div style={{ border: "1px dashed rgba(15,23,42,0.18)", borderRadius: 14, padding: 20, textAlign: "center", color: "#64748b", fontSize: 13 }}>
                  No presets match this search.
                </div>
              ) : (
                visiblePresets.map((p) => {
                  const meta = presetMeta(p);
                  const selected = selectedSet.has(p.key);
                  return (
                    <button
                      key={p.key}
                      type="button"
                      onClick={() => {
                        const next = new Set(selectedKeys);
                        if (next.has(p.key)) next.delete(p.key);
                        else next.add(p.key);
                        setSelectedKeys(Array.from(next));
                      }}
                      style={{
                        width: "100%",
                        borderRadius: 14,
                        border: selected ? "1px solid #22c55e" : "1px solid rgba(15,23,42,0.10)",
                        background: selected ? "#f0fdf4" : "#fff",
                        padding: 14,
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "flex-start",
                        gap: 12,
                        cursor: "pointer",
                        textAlign: "left",
                      }}
                    >
                      <div style={{ minWidth: 0 }}>
                        <div style={{ fontSize: 14, fontWeight: 800, color: "#0f172a", wordBreak: "break-word" }}>{p.label || p.key}</div>
                        <div style={{ fontSize: 12, color: "#64748b", marginTop: 6, wordBreak: "break-all" }}>{p.key}</div>
                        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 10 }}>
                          <span style={{ borderRadius: 999, padding: "4px 8px", fontSize: 11, fontWeight: 800, background: "#eff6ff", color: "#1d4ed8" }}>{meta.ext || "FILE"}</span>
                          {meta.isHd ? <span style={{ borderRadius: 999, padding: "4px 8px", fontSize: 11, fontWeight: 800, background: "#ecfeff", color: "#0f766e" }}>HD</span> : null}
                          {meta.isSd ? <span style={{ borderRadius: 999, padding: "4px 8px", fontSize: 11, fontWeight: 800, background: "#fff7ed", color: "#c2410c" }}>SD</span> : null}
                          {meta.isAudio ? <span style={{ borderRadius: 999, padding: "4px 8px", fontSize: 11, fontWeight: 800, background: "#faf5ff", color: "#7e22ce" }}>Audio</span> : null}
                        </div>
                      </div>
                      <div style={{ flexShrink: 0, borderRadius: 999, padding: "6px 10px", fontSize: 12, fontWeight: 800, background: selected ? "#dcfce7" : "#f8fafc", color: selected ? "#166534" : "#334155", border: selected ? "1px solid #86efac" : "1px solid rgba(15,23,42,0.08)" }}>
                        {selected ? "Selected" : "Choose"}
                      </div>
                    </button>
                  );
                })
              )}
            </div>
          </div>

          <div style={{ border: "1px solid rgba(15,23,42,0.08)", borderRadius: 16, background: "#f8fafc", overflow: "hidden", minHeight: 0, display: "flex", flexDirection: "column" }}>
            <div style={{ padding: 14, borderBottom: "1px solid rgba(15,23,42,0.08)", display: "flex", justifyContent: "space-between", gap: 8, alignItems: "center" }}>
              <div>
                <div style={{ fontSize: 14, fontWeight: 800, color: "#0f172a" }}>Selected presets</div>
                <div style={{ fontSize: 12, color: "#64748b", marginTop: 4 }}>These formats will be available for this destination.</div>
              </div>
              <button type="button" className="btn btn--ghost btn--sm" onClick={() => setSelectedKeys([])} disabled={!selectedKeys.length}>Clear all</button>
            </div>

            <div style={{ padding: 14, overflowY: "scroll", overflowX: "hidden", display: "grid", gap: 10, flex: 1, minHeight: 0 }}>
              {!selectedPresets.length ? (
                <div style={{ border: "1px dashed rgba(15,23,42,0.18)", borderRadius: 14, padding: 18, background: "#fff", color: "#64748b", fontSize: 13, lineHeight: 1.5 }}>
                  No specific presets selected yet. If you leave it this way, this destination can use the full preset library.
                </div>
              ) : (
                selectedPresets.map((p) => (
                  <div key={p.key} style={{ borderRadius: 14, border: "1px solid rgba(22,101,52,0.16)", background: "#fff", padding: 12, display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 10 }}>
                    <div style={{ minWidth: 0 }}>
                      <div style={{ fontSize: 13, fontWeight: 800, color: "#166534", wordBreak: "break-word" }}>{p.label || p.key}</div>
                      <div style={{ fontSize: 12, color: "#64748b", marginTop: 4, wordBreak: "break-all" }}>{p.key}</div>
                    </div>
                    <button
                      type="button"
                      className="btn btn--ghost btn--sm"
                      onClick={() => setSelectedKeys(selectedKeys.filter((k) => k !== p.key))}
                    >
                      Remove
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function PresetSelectionSummary(props: {
  selectedKeys: string[];
  presets: Preset[];
  description?: string;
  onOpen: () => void;
  onClear: () => void;
}) {
  const { selectedKeys, presets, description, onOpen, onClear } = props;
  const selectedPresets = useMemo(() => presets.filter((p) => selectedKeys.includes(p.key)), [presets, selectedKeys]);
  return (
    <div style={{ border: "1px solid rgba(15,23,42,0.08)", borderRadius: 16, background: "linear-gradient(180deg, #ffffff 0%, #f8fafc 100%)", padding: 16 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12, flexWrap: "wrap" }}>
        <div>
          <div style={{ fontSize: 13, fontWeight: 800, color: "#0f172a" }}>Allowed presets</div>
          {description ? <div style={{ fontSize: 12, color: "#475569", marginTop: 4, maxWidth: 760 }}>{description}</div> : null}
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap", justifyContent: "flex-end" }}>
          <div style={{ borderRadius: 999, padding: "6px 10px", fontSize: 12, fontWeight: 800, background: selectedKeys.length ? "#ecfdf3" : "#f8fafc", border: selectedKeys.length ? "1px solid #bbf7d0" : "1px solid rgba(15,23,42,0.08)", color: selectedKeys.length ? "#166534" : "#334155" }}>
            {selectedKeys.length ? `${selectedKeys.length} selected` : "All presets allowed"}
          </div>
          <button type="button" className="btn btn--ghost btn--sm" onClick={onOpen}>Choose presets</button>
          <button type="button" className="btn btn--ghost btn--sm" onClick={onClear} disabled={!selectedKeys.length}>Clear</button>
        </div>
      </div>

      <div style={{ marginTop: 14, borderRadius: 14, border: "1px solid rgba(15,23,42,0.08)", background: "#fff", padding: 14 }}>
        <div style={{ fontSize: 12, fontWeight: 800, color: "#0f172a", marginBottom: 8 }}>Selected presets</div>
        {!selectedPresets.length ? (
          <div style={{ fontSize: 13, lineHeight: 1.5, color: "#64748b" }}>
            No specific presets selected. This destination can use the full preset library.
          </div>
        ) : (
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            {selectedPresets.slice(0, 6).map((p) => (
              <span key={p.key} style={{ borderRadius: 999, padding: "7px 10px", background: "#f0fdf4", border: "1px solid #bbf7d0", color: "#166534", fontSize: 12, fontWeight: 700 }} title={p.label || p.key}>
                {p.label || p.key}
              </span>
            ))}
            {selectedPresets.length > 6 ? (
              <span style={{ borderRadius: 999, padding: "7px 10px", background: "#f8fafc", border: "1px solid rgba(15,23,42,0.08)", color: "#475569", fontSize: 12, fontWeight: 700 }}>
                +{selectedPresets.length - 6} more
              </span>
            ) : null}
          </div>
        )}
      </div>
    </div>
  );
}

function DefaultPresetSelectionModal(props: {
  open: boolean;
  title: string;
  subtitle: string;
  presets: Preset[];
  selectedKey: string;
  setSelectedKey: (next: string) => void;
  search: string;
  setSearch: (value: string) => void;
  filter: PresetFilter;
  setFilter: (value: PresetFilter) => void;
  selectedOnly: boolean;
  setSelectedOnly: (value: boolean) => void;
  onClose: () => void;
  error?: string;
}) {
  const { open, title, subtitle, presets, selectedKey, setSelectedKey, search, setSearch, filter, setFilter, selectedOnly, setSelectedOnly, onClose, error } = props;

  const visiblePresets = useMemo(() => {
    const term = search.trim().toLowerCase();
    return presets.filter((p) => {
      if (selectedOnly && p.key !== selectedKey) return false;
      if (!presetMatchesFilter(p, filter)) return false;
      if (!term) return true;
      const hay = `${p.label || ""} ${p.key || ""} ${p.ext || ""} ${p.mimeType || ""}`.toLowerCase();
      return hay.includes(term);
    });
  }, [presets, search, filter, selectedOnly, selectedKey]);

  const selectedPreset = useMemo(() => presets.find((p) => p.key === selectedKey) || null, [presets, selectedKey]);

  useEffect(() => {
    if (!open) return;
    const onKey = (ev: KeyboardEvent) => {
      if (ev.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(15,23,42,0.45)",
        zIndex: 90,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: 20,
      }}
      onClick={onClose}
    >
      <div
        className="card"
        style={{
          width: "min(1220px, 100%)",
          height: "90vh",
          maxHeight: "90vh",
          overflow: "hidden",
          padding: 0,
          borderRadius: 20,
          boxShadow: "0 24px 60px rgba(15,23,42,0.24)",
          display: "flex",
          flexDirection: "column",
        }}
        onClick={(e) => e.stopPropagation()}
      >
        <div style={{ padding: "18px 20px", borderBottom: "1px solid rgba(15,23,42,0.08)", display: "flex", gap: 16, justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap" }}>
          <div>
            <div style={{ fontSize: 22, fontWeight: 800, color: "#0f172a" }}>{title}</div>
            <div style={{ fontSize: 13, color: "#475569", marginTop: 6, maxWidth: 760 }}>{subtitle}</div>
          </div>
          <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap", justifyContent: "flex-end" }}>
            <div style={{ borderRadius: 999, padding: "8px 12px", background: selectedKey ? "#ecfdf3" : "#f8fafc", border: selectedKey ? "1px solid #bbf7d0" : "1px solid rgba(15,23,42,0.08)", color: selectedKey ? "#166534" : "#334155", fontSize: 12, fontWeight: 800 }}>
              {selectedKey ? "Default preset selected" : "No default preset"}
            </div>
            <button type="button" className="btn btn--ghost" onClick={onClose}>Done</button>
          </div>
        </div>

        <div style={{ padding: 18, display: "grid", gridTemplateColumns: "220px minmax(0, 1fr) 320px", gap: 16, alignItems: "stretch", flex: 1, minHeight: 0, overflow: "hidden" }}>
          <div style={{ border: "1px solid rgba(15,23,42,0.08)", borderRadius: 16, background: "#f8fafc", padding: 14, overflow: "auto", minHeight: 0, height: "100%" }}>
            <div style={{ fontSize: 12, fontWeight: 800, textTransform: "uppercase", letterSpacing: 0.4, color: "#475569", marginBottom: 10 }}>Format groups</div>
            <div style={{ display: "grid", gap: 8 }}>
              {PRESET_FILTER_OPTIONS.map((opt) => {
                const active = opt.key === filter;
                return (
                  <button
                    key={opt.key}
                    type="button"
                    onClick={() => setFilter(opt.key)}
                    style={{
                      textAlign: "left",
                      borderRadius: 12,
                      padding: "10px 12px",
                      border: active ? "1px solid #22c55e" : "1px solid rgba(15,23,42,0.08)",
                      background: active ? "#ecfdf3" : "#fff",
                      color: active ? "#166534" : "#0f172a",
                      fontSize: 13,
                      fontWeight: 700,
                      cursor: "pointer",
                    }}
                  >
                    {opt.label}
                  </button>
                );
              })}
            </div>

            <div style={{ marginTop: 16, paddingTop: 14, borderTop: "1px solid rgba(15,23,42,0.08)" }}>
              <label style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13, fontWeight: 700, color: "#0f172a", cursor: "pointer" }}>
                <input type="checkbox" checked={selectedOnly} onChange={(e) => setSelectedOnly(e.target.checked)} />
                Show selected only
              </label>
            </div>
          </div>

          <div style={{ border: "1px solid rgba(15,23,42,0.08)", borderRadius: 16, background: "#fff", overflow: "hidden", minHeight: 0, display: "flex", flexDirection: "column" }}>
            <div style={{ padding: 14, borderBottom: "1px solid rgba(15,23,42,0.08)", display: "grid", gap: 10 }}>
              <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
                <input
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search by format, label, or preset key"
                  style={{ flex: "1 1 300px", minWidth: 220, padding: "11px 12px" }}
                />
                <button type="button" className="btn btn--ghost btn--sm" onClick={() => setSearch("")} disabled={!search}>
                  Clear search
                </button>
              </div>
              <div style={{ fontSize: 12, color: "#64748b" }}>
                Showing {visiblePresets.length} preset{visiblePresets.length === 1 ? "" : "s"}. Choose one default preset from the allowed formats for this destination.
              </div>
            </div>

            {error ? (
              <div className="card" style={{ margin: 14, borderColor: "#f5a", background: "#fff5fa" }}>
                Preset library could not be loaded: {error}
              </div>
            ) : null}

            <div style={{ padding: 14, overflowY: "scroll", overflowX: "hidden", display: "grid", gap: 10, flex: 1, minHeight: 0 }}>
              {!visiblePresets.length ? (
                <div style={{ border: "1px dashed rgba(15,23,42,0.18)", borderRadius: 14, padding: 20, textAlign: "center", color: "#64748b", fontSize: 13 }}>
                  No presets match this search.
                </div>
              ) : (
                visiblePresets.map((p) => {
                  const meta = presetMeta(p);
                  const selected = p.key === selectedKey;
                  return (
                    <button
                      key={p.key}
                      type="button"
                      onClick={() => setSelectedKey(selected ? "" : p.key)}
                      style={{
                        width: "100%",
                        borderRadius: 14,
                        border: selected ? "1px solid #22c55e" : "1px solid rgba(15,23,42,0.10)",
                        background: selected ? "#f0fdf4" : "#fff",
                        padding: 14,
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "flex-start",
                        gap: 12,
                        cursor: "pointer",
                        textAlign: "left",
                      }}
                    >
                      <div style={{ minWidth: 0 }}>
                        <div style={{ fontSize: 14, fontWeight: 800, color: "#0f172a", wordBreak: "break-word" }}>{p.label || p.key}</div>
                        <div style={{ fontSize: 12, color: "#64748b", marginTop: 6, wordBreak: "break-all" }}>{p.key}</div>
                        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 10 }}>
                          <span style={{ borderRadius: 999, padding: "4px 8px", fontSize: 11, fontWeight: 800, background: "#eff6ff", color: "#1d4ed8" }}>{meta.ext || "FILE"}</span>
                          {meta.isHd ? <span style={{ borderRadius: 999, padding: "4px 8px", fontSize: 11, fontWeight: 800, background: "#ecfeff", color: "#0f766e" }}>HD</span> : null}
                          {meta.isSd ? <span style={{ borderRadius: 999, padding: "4px 8px", fontSize: 11, fontWeight: 800, background: "#fff7ed", color: "#c2410c" }}>SD</span> : null}
                          {meta.isAudio ? <span style={{ borderRadius: 999, padding: "4px 8px", fontSize: 11, fontWeight: 800, background: "#faf5ff", color: "#7e22ce" }}>Audio</span> : null}
                        </div>
                      </div>
                      <div style={{ flexShrink: 0, borderRadius: 999, padding: "6px 10px", fontSize: 12, fontWeight: 800, background: selected ? "#dcfce7" : "#f8fafc", color: selected ? "#166534" : "#334155", border: selected ? "1px solid #86efac" : "1px solid rgba(15,23,42,0.08)" }}>
                        {selected ? "Selected" : "Choose"}
                      </div>
                    </button>
                  );
                })
              )}
            </div>
          </div>

          <div style={{ border: "1px solid rgba(15,23,42,0.08)", borderRadius: 16, background: "#f8fafc", overflow: "hidden", minHeight: 0, display: "flex", flexDirection: "column" }}>
            <div style={{ padding: 14, borderBottom: "1px solid rgba(15,23,42,0.08)", display: "flex", justifyContent: "space-between", gap: 8, alignItems: "center" }}>
              <div>
                <div style={{ fontSize: 14, fontWeight: 800, color: "#0f172a" }}>Selected default preset</div>
                <div style={{ fontSize: 12, color: "#64748b", marginTop: 4 }}>New channels under this destination can start with this preset auto-filled.</div>
              </div>
              <button type="button" className="btn btn--ghost btn--sm" onClick={() => setSelectedKey("")} disabled={!selectedKey}>Clear</button>
            </div>

            <div style={{ padding: 14, overflowY: "scroll", overflowX: "hidden", display: "grid", gap: 10, flex: 1, minHeight: 0 }}>
              {!selectedPreset ? (
                <div style={{ border: "1px dashed rgba(15,23,42,0.18)", borderRadius: 14, padding: 18, background: "#fff", color: "#64748b", fontSize: 13, lineHeight: 1.5 }}>
                  No default preset selected yet. Channels without their own preset will inherit from the destination only after you choose one here.
                </div>
              ) : (
                <div style={{ borderRadius: 14, border: "1px solid rgba(22,101,52,0.16)", background: "#fff", padding: 12, display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 10 }}>
                  <div style={{ minWidth: 0 }}>
                    <div style={{ fontSize: 13, fontWeight: 800, color: "#166534", wordBreak: "break-word" }}>{selectedPreset.label || selectedPreset.key}</div>
                    <div style={{ fontSize: 12, color: "#64748b", marginTop: 4, wordBreak: "break-all" }}>{selectedPreset.key}</div>
                  </div>
                  <button type="button" className="btn btn--ghost btn--sm" onClick={() => setSelectedKey("")}>Remove</button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function DefaultPresetSelectionSummary(props: {
  selectedKey: string;
  presets: Preset[];
  description?: string;
  onOpen: () => void;
  onClear: () => void;
}) {
  const { selectedKey, presets, description, onOpen, onClear } = props;
  const selectedPreset = useMemo(() => presets.find((p) => p.key === selectedKey) || null, [presets, selectedKey]);
  return (
    <div style={{ border: "1px solid rgba(15,23,42,0.08)", borderRadius: 16, background: "linear-gradient(180deg, #ffffff 0%, #f8fafc 100%)", padding: 16 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12, flexWrap: "wrap" }}>
        <div>
          <div style={{ fontSize: 13, fontWeight: 800, color: "#0f172a" }}>Destination default preset</div>
          {description ? <div style={{ fontSize: 12, color: "#475569", marginTop: 4, maxWidth: 760 }}>{description}</div> : null}
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap", justifyContent: "flex-end" }}>
          <div style={{ borderRadius: 999, padding: "6px 10px", fontSize: 12, fontWeight: 800, background: selectedPreset ? "#ecfdf3" : "#f8fafc", border: selectedPreset ? "1px solid #bbf7d0" : "1px solid rgba(15,23,42,0.08)", color: selectedPreset ? "#166534" : "#334155" }}>
            {selectedPreset ? "1 selected" : "No default preset"}
          </div>
          <button type="button" className="btn btn--ghost btn--sm" onClick={onOpen}>Choose preset</button>
          <button type="button" className="btn btn--ghost btn--sm" onClick={onClear} disabled={!selectedPreset}>Clear</button>
        </div>
      </div>

      <div style={{ marginTop: 14, borderRadius: 14, border: "1px solid rgba(15,23,42,0.08)", background: "#fff", padding: 14 }}>
        <div style={{ fontSize: 12, fontWeight: 800, color: "#0f172a", marginBottom: 8 }}>Selected default preset</div>
        {!selectedPreset ? (
          <div style={{ fontSize: 13, lineHeight: 1.5, color: "#64748b" }}>
            No default preset selected. New channels will stay empty until the client chooses one.
          </div>
        ) : (
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            <span style={{ borderRadius: 999, padding: "7px 10px", background: "#f0fdf4", border: "1px solid #bbf7d0", color: "#166534", fontSize: 12, fontWeight: 700 }} title={selectedPreset.label || selectedPreset.key}>
              {selectedPreset.label || selectedPreset.key}
            </span>
          </div>
        )}
      </div>
    </div>
  );
}

function DestinationActionsModal(props: {
  row: Destination | null;
  channelCount: number;
  countryLabel: string;
  cityLabel: string;
  receiverLabel: string;
  onClose: () => void;
  onEdit: () => void;
  onOpenChannels: () => void;
  onDelete: () => void;
}) {
  const { row, channelCount, countryLabel, cityLabel, receiverLabel, onClose, onEdit, onOpenChannels, onDelete } = props;
  if (!row) return null;
  const statusLabel = row.status || "UNKNOWN";
  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(15,23,42,0.14)",
        zIndex: 85,
        display: "grid",
        placeItems: "center",
        padding: 16,
      }}
      onClick={onClose}
    >
      <div
        className="card"
        style={{ width: "min(380px, 100%)", borderRadius: 22, padding: 0, overflow: "hidden", boxShadow: "0 24px 60px rgba(15,23,42,0.20)", background: "#fff" }}
        onClick={(e) => e.stopPropagation()}
      >
        <div style={{ padding: "18px 18px 10px", display: "flex", justifyContent: "space-between", gap: 12, alignItems: "flex-start" }}>
          <div style={{ minWidth: 0 }}>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center", marginBottom: 8 }}>
              <span style={{ fontSize: 15, color: "#334155" }}>{categoryLabel(row.category)}</span>
              <span style={{ display: "inline-flex", alignItems: "center", borderRadius: 999, padding: "4px 8px", fontSize: 12, fontWeight: 800, background: statusLabel === "ACTIVE" ? "#eaf8ef" : "#f1f5f9", color: statusLabel === "ACTIVE" ? "#166534" : "#475569" }}>{statusLabel}</span>
            </div>
            <div style={{ fontSize: 18, fontWeight: 900, color: "#0f172a", wordBreak: "break-word" }}>{row.name}</div>
          </div>
          <button type="button" onClick={onClose} aria-label="Close" style={{ border: "none", background: "transparent", color: "#64748b", fontSize: 28, lineHeight: 1, cursor: "pointer", padding: 0 }}>×</button>
        </div>

        <div style={{ padding: "0 18px 18px", display: "grid", gap: 10 }}>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: 10 }}>
            <div style={{ borderRadius: 16, border: "1px solid rgba(15,23,42,0.10)", background: "#fff", padding: 12, minHeight: 92 }}>
              <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: 0.35, textTransform: "uppercase", color: "#64748b", marginBottom: 8 }}>Location</div>
              <div style={{ fontSize: 14, color: "#0f172a", lineHeight: 1.5 }}>{countryLabel || "—"}<br />{cityLabel || "—"}</div>
            </div>
            <div style={{ borderRadius: 16, border: "1px solid rgba(15,23,42,0.10)", background: "#fff", padding: 12, minHeight: 92 }}>
              <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: 0.35, textTransform: "uppercase", color: "#64748b", marginBottom: 8 }}>Channels</div>
              <div style={{ fontSize: 34, lineHeight: 1, fontWeight: 900, color: "#0f172a" }}>{channelCount}</div>
            </div>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: 10 }}>
            <div style={{ borderRadius: 16, border: "1px solid rgba(15,23,42,0.10)", background: "#fff", padding: 12 }}>
              <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: 0.35, textTransform: "uppercase", color: "#64748b", marginBottom: 6 }}>Destination account</div>
              <div style={{ fontSize: 14, color: "#0f172a", wordBreak: "break-word" }}>{row.destinationAccount || row.name || "—"}</div>
            </div>
            <div style={{ borderRadius: 16, border: "1px solid rgba(15,23,42,0.10)", background: "#fff", padding: 12 }}>
              <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: 0.35, textTransform: "uppercase", color: "#64748b", marginBottom: 6 }}>Receiver account</div>
              <div style={{ fontSize: 14, color: "#0f172a", wordBreak: "break-word" }}>{receiverLabel || "—"}</div>
            </div>
          </div>

          <div style={{ display: "grid", gap: 8, marginTop: 4 }}>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: 8 }}>
              <button type="button" className="btn btn--ghost" onClick={onEdit}>Edit</button>
              <button type="button" className="btn btn--ghost" onClick={onOpenChannels}>View channels</button>
            </div>
            <button type="button" className="btn btn--primary" onClick={onEdit}>Manage connection</button>
            <button type="button" className="btn btn--ghost btn--sm" onClick={onDelete} style={{ color: "#b91c1c", borderColor: "rgba(185,28,28,0.20)" }}>Delete destination</button>
          </div>
        </div>
      </div>
    </div>
  );
}

export function DestinationsPage() {
  const nav = useNavigate();
const [searchParams] = useSearchParams();
const returnTo = (searchParams.get("returnTo") || "").trim();
const returnOnSave = String(searchParams.get("returnOnSave") || "") === "1";
const editIdParam = (searchParams.get("editId") || "").trim();
const createMode = String(searchParams.get("create") || "") === "1";

  const [rows, setRows] = useState<Destination[]>([]);
  const [channels, setChannels] = useState<Channel[]>([]);
  const [countries, setCountries] = useState<Country[]>([]);
  const [cities, setCities] = useState<City[]>([]);
  const [presetLibrary, setPresetLibrary] = useState<Preset[]>([]);
  const [presetErr, setPresetErr] = useState<string>("");
  const [deliveryProfiles, setDeliveryProfiles] = useState<DeliveryProfile[]>([]);
  const [partnerAccounts, setPartnerAccounts] = useState<PartnerAccount[]>([]);

  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [banner, setBanner] = useState<string>("");
  const [showCreateSection, setShowCreateSection] = useState(createMode);
  const [createStep, setCreateStep] = useState<0 | 1 | 2>(0);
  const [listSearch, setListSearch] = useState("");
  const [listStatusFilter, setListStatusFilter] = useState<"ALL" | MasterStatus>("ALL");
  const [listCategoryFilter, setListCategoryFilter] = useState<"ALL" | DestinationCategory>("ALL");

  // create form
  const [name, setName] = useState("");
  const createNameRef = useRef<HTMLInputElement | null>(null);

  const [category, setCategory] = useState<DestinationCategory>("TV");
  const [destinationAccount, setDestinationAccount] = useState("");
  const [receiverAccountId, setReceiverAccountId] = useState("");
  const [clientEmailsText, setClientEmailsText] = useState("");
  const [deliveryDefinition, setDeliveryDefinition] = useState<"" | "SD" | "HD">("");
  const [countryId, setCountryId] = useState("");
  const [cityId, setCityId] = useState("");
  const [locationNotRequiredCreate, setLocationNotRequiredCreate] = useState(false);
  const [status, setStatus] = useState<MasterStatus>("ACTIVE");
  const [fileNameTemplate, setFileNameTemplate] = useState("");
  const [approvalRequired, setApprovalRequired] = useState(false);
  const fileNameTemplateRef = useRef<HTMLTextAreaElement | null>(null);
  const [configText, setConfigText] = useState(`{}`);
  const [defaultDeliveryProfileId, setDefaultDeliveryProfileId] = useState("");
  const [showAdvancedCreate, setShowAdvancedCreate] = useState(false);
  const [allowedPresetKeys, setAllowedPresetKeys] = useState<string[]>([]);
  const [defaultPresetKey, setDefaultPresetKey] = useState<string>("");
  const [presetSearch, setPresetSearch] = useState<string>("");
  const [createPresetFilter, setCreatePresetFilter] = useState<PresetFilter>("ALL");
  const [createPresetPickerOpen, setCreatePresetPickerOpen] = useState(false);
  const [createPresetSelectedOnly, setCreatePresetSelectedOnly] = useState(false);
  const [createDefaultPresetSearch, setCreateDefaultPresetSearch] = useState<string>("");
  const [createDefaultPresetFilter, setCreateDefaultPresetFilter] = useState<PresetFilter>("ALL");
  const [createDefaultPresetPickerOpen, setCreateDefaultPresetPickerOpen] = useState(false);
  const [createDefaultPresetSelectedOnly, setCreateDefaultPresetSelectedOnly] = useState(false);

const [xmlEnabledCreate, setXmlEnabledCreate] = useState(false);
const [xmlConfigTextCreate, setXmlConfigTextCreate] = useState(`{}`);

  // edit modal
  const [edit, setEdit] = useState<Destination | null>(null);
  const [editApprovalRequired, setEditApprovalRequired] = useState(false);
  const [editReceiverAccountId, setEditReceiverAccountId] = useState("");
  const [editClientEmailsText, setEditClientEmailsText] = useState("");
  const [editDeliveryDefinition, setEditDeliveryDefinition] = useState<"" | "SD" | "HD">("");
  const [actionRow, setActionRow] = useState<Destination | null>(null);
  const editFileNameTemplateRef = useRef<HTMLTextAreaElement | null>(null);
  const [editConfigText, setEditConfigText] = useState(`{}`);
  const [editDefaultDeliveryProfileId, setEditDefaultDeliveryProfileId] = useState("");
  const [showAdvancedEdit, setShowAdvancedEdit] = useState(false);
  const [editAllowedPresetKeys, setEditAllowedPresetKeys] = useState<string[]>([]);
  const [editDefaultPresetKey, setEditDefaultPresetKey] = useState<string>("");
  const [editPresetSearch, setEditPresetSearch] = useState<string>("");
  const [editPresetFilter, setEditPresetFilter] = useState<PresetFilter>("ALL");
  const [editPresetPickerOpen, setEditPresetPickerOpen] = useState(false);
  const [editPresetSelectedOnly, setEditPresetSelectedOnly] = useState(false);
  const [editDefaultPresetSearch, setEditDefaultPresetSearch] = useState<string>("");
  const [editDefaultPresetFilter, setEditDefaultPresetFilter] = useState<PresetFilter>("ALL");
  const [editDefaultPresetPickerOpen, setEditDefaultPresetPickerOpen] = useState(false);
  const [editDefaultPresetSelectedOnly, setEditDefaultPresetSelectedOnly] = useState(false);

const [editXmlEnabled, setEditXmlEnabled] = useState(false);
const [editXmlConfigText, setEditXmlConfigText] = useState(`{}`);

  async function loadAll() {
    setErr("");
    try {
      const [dest, ctry, cty, ch, pl, dp, pa] = await Promise.all([
        api<Destination[]>("/masters/destinations"),
        api<Country[]>("/masters/countries"),
        api<City[]>("/masters/cities"),
        api<Channel[]>("/masters/channels"),
        api<{ presets: Preset[] }>("/presets").catch((e: any) => {
          setPresetErr(e?.message || String(e));
          return { presets: [] } as any;
        }),
        api<DeliveryProfile[]>("/masters/delivery-profiles").catch(() => [] as any),
        api<PartnerAccount[]>("/masters/partner-accounts?includeInactive=true").catch(() => [] as any),
      ]);
      setRows(Array.isArray(dest) ? dest : []);
      setCountries(Array.isArray(ctry) ? ctry : []);
      setCities(Array.isArray(cty) ? cty : []);
      setChannels(Array.isArray(ch) ? ch : []);
      setPresetLibrary(Array.isArray((pl as any)?.presets) ? (pl as any).presets : []);
      setDeliveryProfiles(Array.isArray(dp) ? dp : []);
      setPartnerAccounts(Array.isArray(pa) ? pa : []);
    } catch (e: any) {
      setErr((e as ApiError)?.message || "Failed to load destinations");
    }
  }

  useEffect(() => {
    loadAll();
  }, []);

  useEffect(() => {
    if (!banner) return;
    const t = setTimeout(() => setBanner(""), 2200);
    return () => clearTimeout(t);
  }, [banner]);

  const createDefaultPresetOptions = useMemo(() => {
    const allowedSet = new Set((allowedPresetKeys || []).map((k) => String(k || "").trim()).filter(Boolean));
    const base = presetLibrary.filter((preset) => !allowedSet.size || allowedSet.has(String(preset.key || "").trim()));
    return base.sort((a, b) => String(a.label || a.key || "").localeCompare(String(b.label || b.key || "")));
  }, [presetLibrary, allowedPresetKeys]);

  const editDefaultPresetOptions = useMemo(() => {
    const allowedSet = new Set((editAllowedPresetKeys || []).map((k) => String(k || "").trim()).filter(Boolean));
    const base = presetLibrary.filter((preset) => !allowedSet.size || allowedSet.has(String(preset.key || "").trim()));
    return base.sort((a, b) => String(a.label || a.key || "").localeCompare(String(b.label || b.key || "")));
  }, [presetLibrary, editAllowedPresetKeys]);

  useEffect(() => {
    if (defaultPresetKey && createDefaultPresetOptions.length && !createDefaultPresetOptions.some((preset) => preset.key === defaultPresetKey)) {
      setDefaultPresetKey("");
    }
  }, [defaultPresetKey, createDefaultPresetOptions]);

  useEffect(() => {
    if (editDefaultPresetKey && editDefaultPresetOptions.length && !editDefaultPresetOptions.some((preset) => preset.key === editDefaultPresetKey)) {
      setEditDefaultPresetKey("");
    }
  }, [editDefaultPresetKey, editDefaultPresetOptions]);

function goBackWithDestination(id?: string) {
  if (!returnTo) return;
  try {
    const u = new URL(returnTo, window.location.origin);
    if (id) u.searchParams.set("destinationId", id);
    nav(`${u.pathname}${u.search || ""}`);
  } catch {
    nav(returnTo);
  }
}

const openedParamRef = useRef<string>("");

useEffect(() => {
  if (!createMode) return;
  setShowCreateSection(true);
  setCreateStep(0);
  requestAnimationFrame(() => {
    try {
      createNameRef.current?.focus();
      createNameRef.current?.scrollIntoView({ block: "center", behavior: "smooth" });
    } catch {
      // ignore
    }
  });
}, [createMode]);

useEffect(() => {
  if (!editIdParam) return;
  if (openedParamRef.current === editIdParam) return;
  const row = rows.find((r) => r.id === editIdParam);
  if (!row) return;
  openedParamRef.current = editIdParam;
  openEdit(row);
}, [editIdParam, rows]);

  const generalStepComplete = useMemo(() => name.trim().length > 0, [name]);
  const locationStepComplete = useMemo(() => locationNotRequiredCreate || Boolean(countryId && cityId), [locationNotRequiredCreate, countryId, cityId]);
  const createStepValidity = useMemo(() => [generalStepComplete, locationStepComplete, true] as const, [generalStepComplete, locationStepComplete]);
  const canOpenCreateStep = (targetStep: number) => targetStep === 0 || createStepValidity.slice(0, targetStep).every(Boolean);
  const canCreate = useMemo(() => generalStepComplete, [generalStepComplete]);

  const receiverAccounts = useMemo(
    () => (partnerAccounts || []).filter((account) => account.accountType === "RECEIVER"),
    [partnerAccounts],
  );
  const receiverAccountsById = useMemo(
    () => new Map(receiverAccounts.map((account) => [account.id, account] as const)),
    [receiverAccounts],
  );
  const receiverOptionsFor = (categoryValue?: DestinationCategory | null, selectedId?: string) =>
    receiverAccounts
      .filter((account) => {
        if ((account.status || "ACTIVE") !== "ACTIVE" && account.id !== selectedId) return false;
        if (!categoryValue) return true;
        return account.id === selectedId || !account.receiverCategory || account.receiverCategory === categoryValue;
      })
      .sort((a, b) => String(a.name || "").localeCompare(String(b.name || "")))
      .map((account) => ({ id: account.id, name: receiverAccountLabel(account) }));
  const receiverSummaryForDestination = (row: Destination) => receiverAccountLabel(receiverAccountsById.get(receiverAccountIdFromConfig(row.config)) || null);

  useEffect(() => {
    const selected = receiverAccountsById.get(receiverAccountId) || null;
    if (!selected) return;
    setClientEmailsText(partnerAccountEmailsText(selected));
  }, [receiverAccountId, receiverAccountsById]);

  useEffect(() => {
    const selected = receiverAccountsById.get(editReceiverAccountId) || null;
    if (!selected) return;
    setEditClientEmailsText(partnerAccountEmailsText(selected));
  }, [editReceiverAccountId, receiverAccountsById]);

  const channelsCountByDestination = useMemo(() => {
    const m = new Map<string, number>();
    for (const ch of channels) {
      const did = ch.destinationId || "";
      if (!did) continue;
      m.set(did, (m.get(did) || 0) + 1);
    }
    return m;
  }, [channels]);
  const filteredRows = useMemo(() => {
    const term = listSearch.trim().toLowerCase();
    return rows.filter((r) => {
      if (listStatusFilter !== "ALL" && (r.status || "") !== listStatusFilter) return false;
      if (listCategoryFilter !== "ALL" && (r.category || "") !== listCategoryFilter) return false;
      if (!term) return true;
      const hay = [
        r.name,
        r.uri,
        r.destinationAccount,
        receiverSummaryForDestination(r),
        categoryLabel(r.category),
        countryName(r.countryId),
        cityName(r.cityId),
        r.status,
      ]
        .filter(Boolean)
        .join(" ")
        .toLowerCase();
      return hay.includes(term);
    });
  }, [rows, listSearch, listStatusFilter, listCategoryFilter, countries, cities, receiverAccountsById]);

  const deliveryProfileOptions = useMemo(() =>
    deliveryProfiles.map((p) => ({
      id: p.id,
      name: p.protocol ? `${p.name} (${p.protocol})` : p.name,
    })),
  [deliveryProfiles]);

  function insertTemplateToken(
    ref: { current: HTMLInputElement | HTMLTextAreaElement | null },
    currentValue: string,
    setValue: (v: string) => void,
    token: string,
  ) {
    const el = ref.current;
    const cur = currentValue ?? "";
    // If we have cursor position, insert there; otherwise append.
    if (el && typeof (el as any).selectionStart === "number" && typeof (el as any).selectionEnd === "number") {
      const start = (el as any).selectionStart as number;
      const end = (el as any).selectionEnd as number;
      const next = cur.slice(0, start) + token + cur.slice(end);
      setValue(next);
      // re-focus at end of inserted token
      requestAnimationFrame(() => {
        try {
          el.focus();
          const p = start + token.length;
          el.setSelectionRange(p, p);
        } catch {
          // ignore
        }
      });
      return;
    }

    // Fallback: smart append (add '_' between tokens)
    const isSep = token === "_" || token === "-" || token === ".";
    let next = cur;
    if (!isSep && next && !/[_\-.]$/.test(next)) next += "_";
    next += token;
    setValue(next);
  }

  function renderTemplateButtons(value: string, setValue: (v: string) => void, ref: { current: HTMLInputElement | HTMLTextAreaElement | null }) {
    return (
      <div style={{ marginTop: 8 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 10, flexWrap: "wrap", marginBottom: 6 }}>
          <div style={{ fontSize: 12, fontWeight: 700 }}>Build template (click to insert)</div>
          <button type="button" onClick={() => setValue("")} className="btn btn--ghost btn--sm">
            Clear template
          </button>
        </div>

        <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
          {FILE_NOMEN_TOKENS.map((t) => {
            const selected = (value || "").includes(t.token);
            return (
              <button
                key={t.token}
                type="button"
                onClick={() => insertTemplateToken(ref, value, setValue, t.token)}
                title={t.token}
                aria-pressed={selected}
                style={{
  borderRadius: 999,
  padding: "8px 12px",
  border: selected ? "1px solid #16a34a" : "1px solid rgba(15,23,42,0.12)",
  background: selected ? "#ecfdf3" : "#ffffff",
  color: selected ? "#166534" : "#0f172a",
  fontSize: 12,
  fontWeight: 700,
  cursor: "pointer",
  textAlign: "left",
}}
              >
                {selected ? "✓ " : ""}
                {t.label}
              </button>
            );
          })}
        </div>

        <div style={{ marginTop: 8, display: "flex", flexWrap: "wrap", gap: 8, alignItems: "center" }}>
          <div style={{ fontSize: 12, opacity: 0.7, fontWeight: 700 }}>Separators:</div>
          {FILE_NOMEN_SEPARATORS.map((t) => (
            <button
              key={t.token}
              type="button"
              onClick={() => insertTemplateToken(ref, value, setValue, t.token)}
              title={t.token}
              className="btn btn--ghost btn--sm"
            >
              {t.label}
            </button>
          ))}
        </div>

        <div style={{ marginTop: 6, fontSize: 12, opacity: 0.75 }}>
          Example: <code style={{ fontWeight: 800 }}>{`{DESTINATION}_{CHANNEL}_{VALID}_{DATE}_{UUID8}`}</code>
        </div>
      </div>
    );
  }


  function countryName(id?: string | null) {
    if (!id) return "—";
    const c = countries.find((x) => x.id === id);
    return c ? c.name : id;
  }

  function cityName(id?: string | null) {
    if (!id) return "—";
    const c = cities.find((x) => x.id === id);
    return c ? c.name : id;
  }


  function sortCountries(list: Country[]) {
    return [...list].sort((a, b) => String(a.name || "").localeCompare(String(b.name || "")));
  }

  function sortCities(list: City[]) {
    return [...list].sort((a, b) => String(a.name || "").localeCompare(String(b.name || "")));
  }

  async function ensureCountryOption(rawName: string) {
    const clean = String(rawName || "").trim();
    if (!clean) return "";
    const existing = countries.find((c) => String(c.name || "").trim().toLowerCase() === clean.toLowerCase());
    if (existing) return existing.id;
    const created = await api<Country>("/masters/countries", {
      method: "POST",
      body: JSON.stringify({ name: clean, status: "ACTIVE" }),
    });
    setCountries((prev) => sortCountries([...prev, created]));
    return created.id;
  }

  async function ensureCityOption(countryIdValue: string, rawName: string) {
    const clean = String(rawName || "").trim();
    if (!countryIdValue || !clean) return "";
    const existing = cities.find(
      (c) => c.countryId === countryIdValue && String(c.name || "").trim().toLowerCase() === clean.toLowerCase(),
    );
    if (existing) return existing.id;
    const created = await api<City>("/masters/cities", {
      method: "POST",
      body: JSON.stringify({ name: clean, countryId: countryIdValue, status: "ACTIVE" }),
    });
    setCities((prev) => sortCities([...prev, created]));
    return created.id;
  }

  async function create() {
    if (!canCreate) return;
    setBusy(true);
    setErr("");
    try {
      const createdName = name.trim();
      const base = safeJsonParse(configText, {});
      let config = mergeAllowedPresets(base, allowedPresetKeys);
      config = mergeDefaultPresetKey(config, defaultPresetKey);
      config = mergeXmlConfig(config, xmlEnabledCreate, safeJsonParse(xmlConfigTextCreate, {}));
      config = withDestinationDefaultProfile(config, defaultDeliveryProfileId);
      config = withReceiverAccountId(config, receiverAccountId);
      config = withDestinationClientEmails(config, clientEmailsText);
      config = withDestinationDeliveryDefinition(config, deliveryDefinition);
      config = withDestinationApprovalRequired(config, approvalRequired);
      const created: any = await api<any>("/masters/destinations", {
        method: "POST",
        body: JSON.stringify({
          name: name.trim(),
          uri: "n/a",
          category,
          destinationAccount: destinationAccount.trim() || undefined,
          countryId: countryId || undefined,
          cityId: cityId || undefined,
          status,
          fileNameTemplate: fileNameTemplate.trim() || undefined,
          config,
        }),
      });

      setName("");
      setDestinationAccount("");
      setReceiverAccountId("");
      setClientEmailsText("");
      setDeliveryDefinition("");
      setCountryId("");
      setCityId("");
      setLocationNotRequiredCreate(false);
      setStatus("ACTIVE");
      setFileNameTemplate("");
      setApprovalRequired(false);
      setConfigText(`{}`);
      setDefaultDeliveryProfileId("");
      setAllowedPresetKeys([]);
      setDefaultPresetKey("");
      setPresetSearch("");
      setXmlEnabledCreate(false);
      setXmlConfigTextCreate(`{}`);
      setCreateStep(0);
      setBanner("Destination created");
    setCreatePresetPickerOpen(false);

      await loadAll();

if (returnTo && returnOnSave) {
  let id = created?.id as string | undefined;
  if (!id) {
    try {
      const all = await api<any>("/masters/destinations");
      if (Array.isArray(all)) {
        const found = all.find((d: any) => String(d?.name || "").trim().toLowerCase() === createdName.toLowerCase());
        id = found?.id;
      }
    } catch {
      // ignore
    }
  }
  goBackWithDestination(id);
  return;
}
    } catch (e: any) {
      setErr((e as ApiError)?.message || "Create failed (check JSON fields)");
    } finally {
      setBusy(false);
    }
  }

  async function patch(id: string, data: Partial<Destination>) {
    setBusy(true);
    setErr("");
    try {
      await api(`/masters/destinations/${id}`, {
        method: "PATCH",
        body: JSON.stringify(data),
      });
      setBanner("Changes saved");
      await loadAll();
    } catch (e: any) {
      setErr((e as ApiError)?.message || "Update failed");
    } finally {
      setBusy(false);
    }
  }

  async function remove(id: string) {
    if (!confirm("Delete this destination?")) return;
    setBusy(true);
    setErr("");
    try {
      await api(`/masters/destinations/${id}`, { method: "DELETE" });
      setBanner("Destination deleted");
      await loadAll();
    } catch (e: any) {
      setErr((e as ApiError)?.message || "Delete failed");
    } finally {
      setBusy(false);
    }
  }

  function openEdit(row: Destination) {
    setEdit(row);
    setShowAdvancedEdit(false);
    const { config, allowedPresetKeys, defaultPresetKey, xmlEnabled, xmlConfig, receiverAccountId, clientEmailsText, deliveryDefinition, approvalRequired } = splitConfig(row.config ?? {});
    setEditConfigText(pretty(config));
    setEditDefaultDeliveryProfileId(destinationDefaultProfileIdFromConfig(row.config));
    setEditAllowedPresetKeys(allowedPresetKeys);
    setEditDefaultPresetKey(defaultPresetKey);
    setEditReceiverAccountId(receiverAccountId);
    setEditClientEmailsText(clientEmailsText);
    setEditDeliveryDefinition(deliveryDefinition);
    setEditApprovalRequired(approvalRequired);
    setEditXmlEnabled(xmlEnabled);
    setEditXmlConfigText(pretty(xmlConfig));
    setEditPresetSearch("");
    setEditPresetFilter("ALL");
    setEditPresetSelectedOnly(false);
  }

  async function saveEdit() {
    if (!edit) return;
    const base = safeJsonParse(editConfigText, {});
    let config = mergeAllowedPresets(base, editAllowedPresetKeys);
    config = mergeDefaultPresetKey(config, editDefaultPresetKey);
    config = mergeXmlConfig(config, editXmlEnabled, safeJsonParse(editXmlConfigText, {}));
    config = withDestinationDefaultProfile(config, editDefaultDeliveryProfileId);
    config = withReceiverAccountId(config, editReceiverAccountId);
    config = withDestinationClientEmails(config, editClientEmailsText);
    config = withDestinationDeliveryDefinition(config, editDeliveryDefinition);
    config = withDestinationApprovalRequired(config, editApprovalRequired);
    await patch(edit.id, {
      name: edit.name?.trim(),
      uri: edit.uri?.trim(),
      category: (edit.category as any) || undefined,
      destinationAccount: edit.destinationAccount?.trim() || undefined,
      countryId: edit.countryId || undefined,
      cityId: edit.cityId || undefined,
      status: (edit.status as any) || undefined,
      fileNameTemplate: edit.fileNameTemplate?.trim() || undefined,
      config,
    });
    setEditPresetPickerOpen(false);
    setEditReceiverAccountId("");
    setEditClientEmailsText("");
    setEditDeliveryDefinition("");
    setEditApprovalRequired(false);
    setEdit(null);

    if (returnTo && returnOnSave) {
      goBackWithDestination(edit.id);
    }
  }


function sampleXmlValues(destName: string) {
  const safeDest = String(destName || "").trim() || "DESTINATION";
  const now = new Date().toISOString();
  const file = "example.mxf";
  const base = file.replace(/\.[^.]+$/, "");
  const remote = `/out/${file}`;
  return {
    TASK_ID: "TASK_123",
    ACCOUNT_ID: "ACCOUNT_123",
    PROFILE_ID: "PROFILE_123",
    PROFILE_NAME: "PROFILE",
    PROTOCOL: "FTP",
    DESTINATION: safeDest,
    CHANNEL: "CHANNEL",
    PROJECT: "PROJECT",
    CREATIVE: "CREATIVE",
    VALID: "VALID_0001",
    FILENAME: file,
    BASENAME: base,
    REMOTE_PATH: remote,
    BYTES: "123456789",
    GENERATED_AT: now,
    UUID8: "a1b2c3d4",
  } as Record<string, string>;
}

const createXmlCfgObj = useMemo(() => safeJsonParse(xmlConfigTextCreate, {}), [xmlConfigTextCreate]);
const createXmlValues = useMemo(() => sampleXmlValues(name), [name]);
const createXmlFileName = useMemo(
  () => (xmlEnabledCreate ? computeXmlFileNamePreview(createXmlCfgObj, createXmlValues) : ""),
  [xmlEnabledCreate, createXmlCfgObj, createXmlValues],
);
const createXmlRemotePath = useMemo(() => {
  if (!xmlEnabledCreate) return "";
  const mediaPath = createXmlValues.REMOTE_PATH || createXmlValues.FILENAME || "";
  const dir = mediaPath.includes("/") ? mediaPath.split("/").slice(0, -1).join("/") : "";
  return dir ? `${dir}/${createXmlFileName}` : createXmlFileName;
}, [xmlEnabledCreate, createXmlFileName, createXmlValues]);

const createXmlPreview = useMemo(
  () => (xmlEnabledCreate ? buildXmlPreview(createXmlCfgObj, { ...createXmlValues, XML_REMOTE_PATH: createXmlRemotePath }) : ""),
  [xmlEnabledCreate, createXmlCfgObj, createXmlValues, createXmlRemotePath],
);

const editXmlCfgObj = useMemo(() => safeJsonParse(editXmlConfigText, {}), [editXmlConfigText]);
const editXmlValues = useMemo(() => sampleXmlValues(edit?.name || "DESTINATION"), [edit?.name]);
const editXmlFileName = useMemo(
  () => (editXmlEnabled ? computeXmlFileNamePreview(editXmlCfgObj, editXmlValues) : ""),
  [editXmlEnabled, editXmlCfgObj, editXmlValues],
);
const editXmlRemotePath = useMemo(() => {
  if (!editXmlEnabled) return "";
  const mediaPath = editXmlValues.REMOTE_PATH || editXmlValues.FILENAME || "";
  const dir = mediaPath.includes("/") ? mediaPath.split("/").slice(0, -1).join("/") : "";
  return dir ? `${dir}/${editXmlFileName}` : editXmlFileName;
}, [editXmlEnabled, editXmlFileName, editXmlValues]);

const editXmlPreview = useMemo(
  () => (editXmlEnabled ? buildXmlPreview(editXmlCfgObj, { ...editXmlValues, XML_REMOTE_PATH: editXmlRemotePath }) : ""),
  [editXmlEnabled, editXmlCfgObj, editXmlValues, editXmlRemotePath],
);

async function copyToClipboard(v: string) {
  try {
    await navigator.clipboard.writeText(v);
    setBanner("Copied");
    setTimeout(() => setBanner(""), 1200);
  } catch {
    // ignore
  }
}

  return (
    <div className="masters-wrap">

{returnTo ? (
  <div className="card card--soft" style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12 }}>
    <div style={{ fontWeight: 800 }}>Back</div>
    <button type="button" disabled={busy} onClick={() => nav(returnTo)}>
      Back to Delivery Setup
    </button>
  </div>
) : null}

      <div className="card card--soft" style={{ display: "grid", gap: 10 }}>
        <div className="page-head">
          <div className="page-head__title">
            <h3 style={{ margin: 0 }}>Destinations</h3>
          </div>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
            <button className="btn btn--ghost" onClick={() => setShowCreateSection((v) => { const next = !v; if (next) setCreateStep(0); return next; })} disabled={busy}>
              {showCreateSection ? "Hide create" : "Create destination"}
            </button>
            <button className="btn btn--ghost" onClick={loadAll} disabled={busy}>Refresh</button>
          </div>
        </div>

        {banner && (
          <div className="card" style={{ borderColor: "rgba(0,0,0,0.12)", background: "rgba(0,0,0,0.03)" }}>
            {banner}
          </div>
        )}

        {showCreateSection ? (
          <>
            <div className="card" style={{ borderColor: "rgba(37,99,235,0.12)", background: "rgba(255,255,255,0.96)", display: "grid", gap: 14 }}>
              <WizardStepper
                steps={DESTINATION_CREATE_STEPS}
                currentStep={createStep}
                canOpenStep={canOpenCreateStep}
                onStepClick={(index) => {
                  if (canOpenCreateStep(index)) setCreateStep(index as 0 | 1 | 2);
                }}
              />

              <div key={`destination-step-${createStep}`} style={{ display: "grid", gap: 12, animation: "wizardStepFade 220ms ease" }}>
                {createStep === 0 ? (
                  <>
                    <div style={{ display: "grid", gap: 4 }}>
                      <div style={{ fontSize: 18, fontWeight: 900, color: "#0f172a" }}>1. General</div>
                    </div>

                    <div className="row" style={{ flexWrap: "wrap", alignItems: "end" }}>
                      <div style={{ minWidth: 220, flex: 1 }}>
                        <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Name</div>
                        <input ref={createNameRef} placeholder="Name" value={name} onChange={(e) => setName(e.target.value)} />
                      </div>
                      <div style={{ minWidth: 180 }}>
                        <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Category</div>
                        <select value={category} onChange={(e) => setCategory(e.target.value as any)}>
                          <option value="TV">Television</option>
                          <option value="DIGITAL">Digital</option>
                          <option value="OTT">OTT</option>
                          <option value="CINEMA">Cinema</option>
                          <option value="RADIO">Radio</option>
                        </select>
                      </div>
                      <div style={{ minWidth: 200, flex: 1 }}>
                        <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Destination Account</div>
                        <input
                          placeholder="Destination Account"
                          value={destinationAccount}
                          onChange={(e) => setDestinationAccount(e.target.value)}
                        />
                      </div>
                      <div style={{ minWidth: 180 }}>
                        <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Status</div>
                        <select value={status} onChange={(e) => setStatus(e.target.value as any)}>
                          <option value="ACTIVE">Active</option>
                          <option value="INACTIVE">Inactive</option>
                        </select>
                      </div>
                    </div>

                    <div className="row" style={{ flexWrap: "wrap", alignItems: "end" }}>
                      <div style={{ minWidth: 320, flex: 1 }}>
                        <SearchSelect
                          label="Receiver Account"
                          value={receiverAccountId}
                          onChange={setReceiverAccountId}
                          options={receiverOptionsFor(category, receiverAccountId)}
                          placeholder="Search receiver account"
                        />
                      </div>
                    </div>

                    <div className="row" style={{ flexWrap: "wrap", alignItems: "end" }}>
                      <div style={{ minWidth: 300, flex: 1 }}>
                        <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Client Email IDs</div>
                        <input
                          placeholder="client@example.com, ops@example.com"
                          value={clientEmailsText}
                          onChange={(e) => setClientEmailsText(e.target.value)}
                          readOnly={!!receiverAccountId}
                        />
                        <div style={{ fontSize: 11, color: "#64748b", marginTop: 4 }}>
                          {receiverAccountId
                            ? "Auto-synced from the linked receiver account email IDs. Update the account to change these emails."
                            : "These emails will override channel-level client emails for this destination."}
                        </div>
                      </div>
                      <div style={{ minWidth: 220 }}>
                        <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Client Delivery Type</div>
                        <select value={deliveryDefinition} onChange={(e) => setDeliveryDefinition(((e.target.value as any) || "") as any)}>
                          <option value="">Auto / Not set</option>
                          <option value="HD">HD</option>
                          <option value="SD">SD</option>
                        </select>
                        <div style={{ fontSize: 11, color: "#64748b", marginTop: 4 }}>
                          Used to choose HD or SD delivery path when the profile has both.
                        </div>
                      </div>
                    </div>
                  </>
                ) : null}

                {createStep === 1 ? (
                  <>
                    <div style={{ display: "grid", gap: 4 }}>
                      <div style={{ fontSize: 18, fontWeight: 900, color: "#0f172a" }}>2. Location</div>
                    </div>

                    <div className="card" style={{ borderColor: locationStepComplete ? "rgba(22,163,74,0.18)" : "rgba(245,158,11,0.18)", background: locationStepComplete ? "rgba(236,253,243,0.55)" : "rgba(255,251,235,0.7)" }}>
                      <label style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13, fontWeight: 800, color: "#0f172a" }}>
                        <input
                          type="checkbox"
                          checked={locationNotRequiredCreate}
                          onChange={(e) => setLocationNotRequiredCreate(e.target.checked)}
                        />
                        No location details for now
                      </label>
                      <div style={{ marginTop: 6, fontSize: 12, color: "#64748b" }}>
                        To continue, either pick both country and city, or enable this option.
                      </div>
                    </div>

                    <div className="row" style={{ flexWrap: "wrap", alignItems: "end" }}>
                      <div style={{ minWidth: 260, flex: 1 }}>
                        <SearchSelect
                          label="Country"
                          value={countryId}
                          onChange={(id) => {
                            setCountryId(id);
                            const c = cities.find((x) => x.id === cityId);
                            if (c && id && c.countryId !== id) setCityId("");
                            if (id) setLocationNotRequiredCreate(false);
                          }}
                          onCreateOption={async (query) => {
                            setErr("");
                            const id = await ensureCountryOption(query);
                            if (!id) return;
                            setCountryId(id);
                            const c = cities.find((x) => x.id === cityId);
                            if (c && c.countryId !== id) setCityId("");
                            setLocationNotRequiredCreate(false);
                            setBanner("Country added");
                          }}
                          createOptionLabel="Add country"
                          options={countries}
                          placeholder="Search country"
                        />
                      </div>
                      <div style={{ minWidth: 260, flex: 1 }}>
                        <SearchSelect
                          label="City"
                          value={cityId}
                          onChange={(id) => {
                            setCityId(id);
                            if (id) setLocationNotRequiredCreate(false);
                          }}
                          onCreateOption={async (query) => {
                            setErr("");
                            if (!countryId) {
                              setErr("Please select country first");
                              return;
                            }
                            const id = await ensureCityOption(countryId, query);
                            if (!id) return;
                            setCityId(id);
                            setLocationNotRequiredCreate(false);
                            setBanner("City added");
                          }}
                          createOptionLabel="Add city"
                          createOptionDisabled={!countryId}
                          options={countryId ? cities.filter((c) => c.countryId === countryId) : cities}
                          placeholder={countryId ? "Search city in country" : "Search city"}
                        />
                      </div>
                    </div>
                  </>
                ) : null}

                {createStep === 2 ? (
                  <>
                    <div style={{ display: "grid", gap: 4 }}>
                      <div style={{ fontSize: 18, fontWeight: 900, color: "#0f172a" }}>3. Presets</div>
                    </div>

                    <div className="row" style={{ flexWrap: "wrap", alignItems: "end" }}>
                      <div style={{ minWidth: 320, flex: 1 }}>
                        <SearchSelect
                          label="Fallback Delivery Profile"
                          value={defaultDeliveryProfileId}
                          onChange={setDefaultDeliveryProfileId}
                          options={deliveryProfileOptions}
                          placeholder="Search delivery profile"
                        />
                      </div>
                    </div>

                    <div style={{ marginTop: 10, marginBottom: 10 }}>
                      <div style={{ minWidth: 0 }}>
                        <PresetSelectionSummary
                          selectedKeys={allowedPresetKeys}
                          presets={presetLibrary}
                          onOpen={() => setCreatePresetPickerOpen(true)}
                          onClear={() => setAllowedPresetKeys([])}
                        />
                        {presetErr ? (
                          <div className="card" style={{ marginTop: 8, borderColor: "#f5a", background: "#fff5fa" }}>
                            Preset library could not be loaded: {presetErr}
                          </div>
                        ) : null}
                        <div style={{ marginTop: 10 }}>
                          <DefaultPresetSelectionSummary
                            selectedKey={defaultPresetKey}
                            presets={createDefaultPresetOptions}
                            onOpen={() => setCreateDefaultPresetPickerOpen(true)}
                            onClear={() => setDefaultPresetKey("")}
                          />
                        </div>
                      </div>

                      <div
                        style={{
                          marginTop: 12,
                          border: "1px solid rgba(0,0,0,0.10)",
                          borderRadius: 12,
                          background: "#fff",
                          padding: 10,
                        }}
                      >
                        <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>File Nomenclature (Template)</div>
                        <ApprovalRequiredToggle value={approvalRequired} onChange={setApprovalRequired} />
                        <textarea
                          ref={fileNameTemplateRef}
                          placeholder="e.g. {DESTINATION}_{CHANNEL}_{VALID}_{DATE}"
                          value={fileNameTemplate}
                          onChange={(e) => setFileNameTemplate(e.target.value)}
                          rows={2}
                          wrap="off"
                          spellCheck={false}
                          style={{
                            width: "100%",
                            minHeight: 54,
                            fontFamily: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, \"Liberation Mono\", \"Courier New\", monospace",
                            fontWeight: 700,
                            fontSize: 14,
                            lineHeight: 1.3,
                            overflowX: "auto",
                            whiteSpace: "pre",
                          }}
                        />
                        {renderTemplateButtons(fileNameTemplate, setFileNameTemplate, fileNameTemplateRef)}
                        {approvalRequired ? (
                          <div style={{ marginTop: 8, fontSize: 12, color: "#92400e", background: "#fffbeb", border: "1px solid #fde68a", borderRadius: 10, padding: "8px 10px" }}>
                            Approval-required destinations stage the file first and wait for manual release. Include <code>{"{HOUSE_ID}"}</code> in the file nomenclature so the final delivered file uses the receiver house ID.
                          </div>
                        ) : null}
                      </div>

                      <div style={{ marginTop: 10 }}>
                        <button
                          type="button"
                          onClick={() => setShowAdvancedCreate((v) => !v)}
                          className="btn btn--ghost btn--sm"
                        >
                          {showAdvancedCreate ? "Hide advanced" : "Advanced"}
                        </button>

                        {showAdvancedCreate ? (
                          <div style={{ marginTop: 8 }}>
                            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Config (JSON)</div>
                            <textarea
                              style={{ width: "100%", maxWidth: "100%", minHeight: 120, fontFamily: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, \"Liberation Mono\", \"Courier New\", monospace", boxSizing: "border-box" }}
                              value={configText}
                              onChange={(e) => setConfigText(e.target.value)}
                            />
                            <div style={{ marginTop: 6, fontSize: 12, opacity: 0.7 }}>
                              Advanced/internal use. You can leave this as {"{}"}
                            </div>

                            <div
                              style={{
                                marginTop: 12,
                                border: "1px solid rgba(0,0,0,0.10)",
                                borderRadius: 12,
                                background: "#fff",
                                padding: 10,
                              }}
                            >
                              <div className="row" style={{ justifyContent: "space-between", alignItems: "center" }}>
                                <div style={{ fontSize: 12, fontWeight: 900 }}>Metadata XML (optional)</div>
                                <label style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12, fontWeight: 800 }}>
                                  <input
                                    type="checkbox"
                                    checked={xmlEnabledCreate}
                                    onChange={(e) => {
                                      const on = e.target.checked;
                                      setXmlEnabledCreate(on);
                                      if (on && (!xmlConfigTextCreate || !xmlConfigTextCreate.trim() || xmlConfigTextCreate.trim() === "{}")) {
                                        setXmlConfigTextCreate(defaultXmlConfigJson());
                                      }
                                    }}
                                  />
                                  Enable
                                </label>
                              </div>

                              {xmlEnabledCreate ? (
                                <div style={{ marginTop: 8, display: "grid", gap: 8 }}>
                                  <div style={{ fontSize: 12, fontWeight: 700 }}>XML config (JSON)</div>
                                  <textarea
                                    style={{
                                      width: "100%",
                                      maxWidth: "100%",
                                      minHeight: 140,
                                      fontFamily: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, \"Liberation Mono\", \"Courier New\", monospace",
                                      boxSizing: "border-box",
                                    }}
                                    value={xmlConfigTextCreate}
                                    onChange={(e) => setXmlConfigTextCreate(e.target.value)}
                                  />
                                  <div style={{ fontSize: 12, opacity: 0.75 }}>
                                    Placeholders: <code>{"{TASK_ID}"}</code>, <code>{"{VALID}"}</code>, <code>{"{FILENAME}"}</code>,{" "}
                                    <code>{"{REMOTE_PATH}"}</code>, <code>{"{BASENAME}"}</code>, <code>{"{GENERATED_AT}"}</code>
                                  </div>

                                  <div style={{ fontSize: 12, fontWeight: 800 }}>Preview</div>
                                  <div className="row" style={{ justifyContent: "space-between", alignItems: "center", gap: 8 }}>
                                    <div style={{ fontSize: 12, opacity: 0.8 }}>
                                      File: <span style={{ fontWeight: 900 }}>{createXmlFileName || "—"}</span> &nbsp;•&nbsp; Remote:{" "}
                                      <span style={{ fontWeight: 900 }}>{createXmlRemotePath || "—"}</span>
                                    </div>
                                    <button
                                      type="button"
                                      className="btn btn--ghost btn--sm"
                                      onClick={() => copyToClipboard(createXmlPreview)}
                                      disabled={!createXmlPreview}
                                      title="Copy preview XML"
                                    >
                                      Copy
                                    </button>
                                  </div>
                                  <pre
                                    style={{
                                      margin: 0,
                                      padding: 10,
                                      borderRadius: 10,
                                      border: "1px solid rgba(0,0,0,0.12)",
                                      background: "rgba(0,0,0,0.03)",
                                      overflowX: "auto",
                                      whiteSpace: "pre",
                                      fontSize: 12,
                                      lineHeight: 1.3,
                                    }}
                                  >
                                    {createXmlPreview}
                                  </pre>
                                </div>
                              ) : (
                                <div style={{ marginTop: 6, fontSize: 12, opacity: 0.7 }}>
                                  When enabled, the Delivery Worker will generate an XML sidecar and send it with the media file.
                                </div>
                              )}
                            </div>
                          </div>
                        ) : null}
                      </div>
                    </div>
                  </>
                ) : null}
              </div>

              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12, flexWrap: "wrap", paddingTop: 4, borderTop: "1px solid rgba(15,23,42,0.08)" }}>
                <div style={{ fontSize: 12, color: "#64748b" }}>
                  Step {createStep + 1} of {DESTINATION_CREATE_STEPS.length}
                </div>
                <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                  <button type="button" className="btn btn--ghost" onClick={() => setCreateStep((s) => Math.max(0, s - 1) as 0 | 1 | 2)} disabled={createStep === 0 || busy}>
                    Back
                  </button>
                  {createStep < 2 ? (
                    <button
                      type="button"
                      className="btn btn--primary"
                      onClick={() => setCreateStep((s) => Math.min(2, s + 1) as 0 | 1 | 2)}
                      disabled={!createStepValidity[createStep] || busy}
                    >
                      Next
                    </button>
                  ) : (
                    <button className="btn btn--primary" onClick={create} disabled={busy || !canCreate}>
                      {busy ? "Saving..." : "Create"}
                    </button>
                  )}
                </div>
              </div>
            </div>
          </>
        ) : (
          <div className="card" style={{ borderStyle: "dashed", color: "#64748b", background: "rgba(248,250,252,0.8)" }}>
            Create section is hidden. Use <b>Create destination</b> to open it.
          </div>
        )}

        {err && <div className="card" style={{ borderColor: "#f5a", background: "#fff5fa" }}>{err}</div>}
      </div>

      <div className="card card--soft" style={{ marginTop: 12, display: "grid", gap: 12 }}>
        <div className="page-head" style={{ paddingBottom: 0 }}>
          <div className="page-head__title">
            <h3 style={{ margin: 0 }}>Destination list</h3>
          </div>
        </div>

        <div className="card" style={{ borderRadius: 18, background: "rgba(248,250,252,0.85)", border: "1px solid rgba(15,23,42,0.08)", display: "grid", gap: 10 }}>
          <div className="row" style={{ flexWrap: "wrap", alignItems: "end", gap: 10 }}>
            <div style={{ minWidth: 240, flex: 1 }}>
              <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Search</div>
              <input placeholder="Search destinations" value={listSearch} onChange={(e) => setListSearch(e.target.value)} />
            </div>
            <div style={{ minWidth: 180 }}>
              <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Status</div>
              <select value={listStatusFilter} onChange={(e) => setListStatusFilter(e.target.value as any)}>
                <option value="ALL">All statuses</option>
                <option value="ACTIVE">Active</option>
                <option value="INACTIVE">Inactive</option>
              </select>
            </div>
            <div style={{ minWidth: 180 }}>
              <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Category</div>
              <select value={listCategoryFilter} onChange={(e) => setListCategoryFilter(e.target.value as any)}>
                <option value="ALL">All categories</option>
                <option value="TV">Television</option>
                <option value="DIGITAL">Digital</option>
                <option value="OTT">OTT</option>
                <option value="CINEMA">Cinema</option>
                <option value="RADIO">Radio</option>
              </select>
            </div>
            <button
              type="button"
              className="btn btn--ghost btn--sm"
              onClick={() => {
                setListSearch("");
                setListStatusFilter("ALL");
                setListCategoryFilter("ALL");
              }}
              disabled={!listSearch && listStatusFilter === "ALL" && listCategoryFilter === "ALL"}
            >
              Clear filters
            </button>
          </div>
        </div>

        {filteredRows.length === 0 ? (
          <div className="card" style={{ borderColor: "rgba(0,0,0,0.10)", background: "rgba(0,0,0,0.03)", textAlign: "center", color: "#64748b" }}>
            No destinations match the current filters.
          </div>
        ) : (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))", gap: 12 }}>
            {filteredRows.map((r) => {
              const channelCount = channelsCountByDestination.get(r.id) || 0;
              const active = actionRow?.id === r.id;
              return (
                <button
                  key={r.id}
                  type="button"
                  className="card"
                  onClick={() => setActionRow(r)}
                  disabled={busy}
                  style={{
                    borderRadius: 20,
                    padding: 18,
                    background: "#fff",
                    display: "grid",
                    gap: 14,
                    minHeight: 188,
                    textAlign: "left",
                    cursor: busy ? "not-allowed" : "pointer",
                    boxShadow: active ? "0 18px 40px rgba(37,99,235,0.16)" : "0 10px 28px rgba(15,23,42,0.07)",
                    border: active ? "1px solid rgba(37,99,235,0.30)" : "1px solid rgba(15,23,42,0.08)",
                    transition: "transform 180ms ease, box-shadow 180ms ease, border-color 180ms ease",
                  }}
                >
                  <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "flex-start" }}>
                    <div style={{ minWidth: 0 }}>
                      <div style={{ fontSize: 17, fontWeight: 900, color: "#0f172a", lineHeight: 1.2, wordBreak: "break-word" }}>{r.name}</div>
                      <div style={{ marginTop: 8, display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
                        <span style={{ fontSize: 15, color: "#334155" }}>{categoryLabel(r.category)}</span>
                        <span style={{ display: "inline-flex", alignItems: "center", borderRadius: 999, padding: "4px 8px", fontSize: 12, fontWeight: 800, background: r.status === "ACTIVE" ? "#eaf8ef" : "#f1f5f9", color: r.status === "ACTIVE" ? "#166534" : "#475569" }}>{r.status || "UNKNOWN"}</span>
                      </div>
                      {receiverSummaryForDestination(r) ? (
                        <div style={{ marginTop: 8, fontSize: 12, color: "#475569", lineHeight: 1.4, wordBreak: "break-word" }}>
                          Receiver: <span style={{ fontWeight: 800, color: "#0f172a" }}>{receiverSummaryForDestination(r)}</span>
                        </div>
                      ) : null}
                    </div>
                    <span style={{ fontSize: 12, fontWeight: 800, color: active ? "#2563eb" : "#94a3b8", whiteSpace: "nowrap" }}>Details</span>
                  </div>

                  <div style={{ flex: 1 }} />

                  <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "flex-end" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 10, minWidth: 0 }}>
                      <DestinationIcon />
                      <div style={{ minWidth: 0 }}>
                        <div style={{ fontSize: 15, fontWeight: 700, color: "#0f172a", wordBreak: "break-word" }}>{categoryLabel(r.category)}</div>
                      </div>
                    </div>
                    <div style={{ fontSize: 13, fontWeight: 700, color: "#64748b", whiteSpace: "nowrap" }}>{channelCount} channel{channelCount === 1 ? "" : "s"}</div>
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </div>

      <DestinationActionsModal
        row={actionRow}
        channelCount={actionRow ? (channelsCountByDestination.get(actionRow.id) || 0) : 0}
        countryLabel={actionRow ? countryName(actionRow.countryId) : ""}
        cityLabel={actionRow ? cityName(actionRow.cityId) : ""}
        receiverLabel={actionRow ? receiverSummaryForDestination(actionRow) : ""}
        onClose={() => setActionRow(null)}
        onEdit={() => {
          if (!actionRow) return;
          setActionRow(null);
          openEdit(actionRow);
        }}
        onOpenChannels={() => {
          if (!actionRow) return;
          const id = actionRow.id;
          setActionRow(null);
          nav(`/masters/channels?destinationId=${encodeURIComponent(id)}`);
        }}
        onDelete={() => {
          if (!actionRow) return;
          const id = actionRow.id;
          setActionRow(null);
          void remove(id);
        }}
      />

      <PresetSelectionModal
        open={createPresetPickerOpen}
        title="Choose presets for this destination"
        subtitle="Keep the main page clean, and pick only the formats this client should be allowed to request. Leaving the selection empty means the full preset library stays available."
        presets={presetLibrary}
        selectedKeys={allowedPresetKeys}
        setSelectedKeys={setAllowedPresetKeys}
        search={presetSearch}
        setSearch={setPresetSearch}
        filter={createPresetFilter}
        setFilter={setCreatePresetFilter}
        selectedOnly={createPresetSelectedOnly}
        setSelectedOnly={setCreatePresetSelectedOnly}
        onClose={() => setCreatePresetPickerOpen(false)}
        error={presetErr}
      />

      <PresetSelectionModal
        open={editPresetPickerOpen}
        title="Update destination presets"
        subtitle="Use this guided picker to control which output formats are available here, without forcing clients to scan a long wall of preset names on the page."
        presets={presetLibrary}
        selectedKeys={editAllowedPresetKeys}
        setSelectedKeys={setEditAllowedPresetKeys}
        search={editPresetSearch}
        setSearch={setEditPresetSearch}
        filter={editPresetFilter}
        setFilter={setEditPresetFilter}
        selectedOnly={editPresetSelectedOnly}
        setSelectedOnly={setEditPresetSelectedOnly}
        onClose={() => setEditPresetPickerOpen(false)}
        error={presetErr}
      />


      <DefaultPresetSelectionModal
        open={createDefaultPresetPickerOpen}
        title="Choose destination default preset"
        subtitle="Use the same guided preset popup here as well. Pick one default preset from the allowed formats for this destination. New channels will auto-fill with it, and channels without their own preset will inherit it."
        presets={createDefaultPresetOptions}
        selectedKey={defaultPresetKey}
        setSelectedKey={setDefaultPresetKey}
        search={createDefaultPresetSearch}
        setSearch={setCreateDefaultPresetSearch}
        filter={createDefaultPresetFilter}
        setFilter={setCreateDefaultPresetFilter}
        selectedOnly={createDefaultPresetSelectedOnly}
        setSelectedOnly={setCreateDefaultPresetSelectedOnly}
        onClose={() => setCreateDefaultPresetPickerOpen(false)}
        error={presetErr}
      />

      <DefaultPresetSelectionModal
        open={editDefaultPresetPickerOpen}
        title="Update destination default preset"
        subtitle="Use the same guided preset popup here as well. Pick the one default preset that should auto-fill new channels and act as the fallback when a channel has no explicit preset."
        presets={editDefaultPresetOptions}
        selectedKey={editDefaultPresetKey}
        setSelectedKey={setEditDefaultPresetKey}
        search={editDefaultPresetSearch}
        setSearch={setEditDefaultPresetSearch}
        filter={editDefaultPresetFilter}
        setFilter={setEditDefaultPresetFilter}
        selectedOnly={editDefaultPresetSelectedOnly}
        setSelectedOnly={setEditDefaultPresetSelectedOnly}
        onClose={() => setEditDefaultPresetPickerOpen(false)}
        error={presetErr}
      />

      {edit && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(0,0,0,0.45)",
            display: "grid",
            placeItems: "center",
            padding: 16,
            zIndex: 60,
          }}
          onClick={() => setEdit(null)}
        >
          <div
            className="card"
            style={{ width: "min(980px, 95vw)", maxHeight: "85vh", overflow: "auto" }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="row" style={{ justifyContent: "space-between", alignItems: "center" }}>
              <h3 style={{ margin: 0 }}>Edit Destination</h3>
              <button onClick={() => setEdit(null)} disabled={busy}>Close</button>
            </div>

            <div style={{ display: "grid", gap: 12, marginTop: 12 }}>
              <div className="card" style={{ borderColor: "rgba(0,0,0,0.12)", background: "rgba(0,0,0,0.03)" }}>
                <div className="row" style={{ justifyContent: "space-between", alignItems: "center" }}>
                  <div style={{ fontWeight: 900 }}>Channels under this destination</div>
                  <button
                    onClick={() => nav(`/masters/channels?destinationId=${encodeURIComponent(edit.id)}`)}
                    disabled={busy}
                  >
                    Manage channels
                  </button>
                </div>
                <div style={{ marginTop: 8, display: "flex", flexWrap: "wrap", gap: 8 }}>
                  {channels.filter((c) => c.destinationId === edit.id).slice(0, 12).map((c) => (
                    <span key={c.id} style={{ padding: "4px 8px", borderRadius: 999, background: "rgba(0,0,0,0.06)", fontSize: 12, fontWeight: 700 }}>
                      {c.name}
                    </span>
                  ))}
                  {channels.filter((c) => c.destinationId === edit.id).length > 12 ? (
                    <span style={{ opacity: 0.7, fontSize: 12 }}>+ more…</span>
                  ) : null}
                  {channels.filter((c) => c.destinationId === edit.id).length === 0 ? (
                    <span style={{ opacity: 0.7, fontSize: 12 }}>No channels assigned yet.</span>
                  ) : null}
                </div>
              </div>

              <div className="row" style={{ flexWrap: "wrap", alignItems: "end" }}>
                <div style={{ minWidth: 240, flex: 1 }}>
                  <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Name</div>
                  <input value={edit.name || ""} onChange={(e) => setEdit({ ...edit, name: e.target.value })} />
                </div>
                <div style={{ minWidth: 180 }}>
                  <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Category</div>
                  <select
                    value={(edit.category as any) || "TV"}
                    onChange={(e) => setEdit({ ...edit, category: e.target.value as any })}
                  >
                    <option value="TV">Television</option>
                    <option value="DIGITAL">Digital</option>
                    <option value="OTT">OTT</option>
                    <option value="CINEMA">Cinema</option>
                    <option value="RADIO">Radio</option>
                  </select>
                </div>
                <div style={{ minWidth: 200, flex: 1 }}>
                  <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Destination Account</div>
                  <input
                    value={edit.destinationAccount || ""}
                    onChange={(e) => setEdit({ ...edit, destinationAccount: e.target.value })}
                  />
                </div>
                <div style={{ minWidth: 180 }}>
                  <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Status</div>
                  <select value={(edit.status as any) || "ACTIVE"} onChange={(e) => setEdit({ ...edit, status: e.target.value as any })}>
                    <option value="ACTIVE">Active</option>
                    <option value="INACTIVE">Inactive</option>
                  </select>
                </div>
              </div>

              <div className="row" style={{ flexWrap: "wrap", alignItems: "end" }}>
                <div style={{ minWidth: 320, flex: 1 }}>
                  <SearchSelect
                    label="Receiver Account"
                    value={editReceiverAccountId}
                    onChange={setEditReceiverAccountId}
                    options={receiverOptionsFor(edit.category, editReceiverAccountId)}
                    placeholder="Search receiver account"
                  />
                  <div style={{ marginTop: 6, fontSize: 12, color: "#64748b" }}>
                    Optional. The linked receiver must match the destination category.
                  </div>
                </div>
              </div>

              <div className="row" style={{ flexWrap: "wrap", alignItems: "end" }}>
                <div style={{ minWidth: 300, flex: 1 }}>
                  <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Client Email IDs</div>
                  <input
                    placeholder="client@example.com, ops@example.com"
                    value={editClientEmailsText}
                    onChange={(e) => setEditClientEmailsText(e.target.value)}
                    readOnly={!!editReceiverAccountId}
                  />
                  <div style={{ marginTop: 6, fontSize: 12, color: "#64748b" }}>
                    {editReceiverAccountId
                      ? "Auto-synced from the linked receiver account email IDs. Update the account to change these emails."
                      : "These emails override channel-level client emails for this destination."}
                  </div>
                </div>
                <div style={{ minWidth: 220 }}>
                  <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Client Delivery Type</div>
                  <select value={editDeliveryDefinition} onChange={(e) => setEditDeliveryDefinition(((e.target.value as any) || "") as any)}>
                    <option value="">Auto / Not set</option>
                    <option value="HD">HD</option>
                    <option value="SD">SD</option>
                  </select>
                  <div style={{ marginTop: 6, fontSize: 12, color: "#64748b" }}>
                    Used to choose HD or SD delivery path when the profile has both.
                  </div>
                </div>
              </div>

              <div className="row" style={{ flexWrap: "wrap", alignItems: "end" }}>
                <div style={{ minWidth: 260, flex: 1 }}>
                  <SearchSelect
                    label="Country"
                    value={edit.countryId || ""}
                    onChange={(id) => {
                      const next: Destination = { ...edit, countryId: id || null };
                      const c = cities.find((x) => x.id === (edit.cityId || ""));
                      if (c && id && c.countryId !== id) next.cityId = null;
                      setEdit(next);
                    }}
                    onCreateOption={async (query) => {
                      setErr("");
                      const id = await ensureCountryOption(query);
                      if (!id) return;
                      const next: Destination = { ...edit, countryId: id || null };
                      const c = cities.find((x) => x.id === (edit.cityId || ""));
                      if (c && c.countryId !== id) next.cityId = null;
                      setEdit(next);
                      setBanner("Country added");
                    }}
                    createOptionLabel="Add country"
                    options={countries}
                    placeholder="Search country"
                  />
                </div>
                <div style={{ minWidth: 260, flex: 1 }}>
                  <SearchSelect
                    label="City"
                    value={edit.cityId || ""}
                    onChange={(id) => setEdit({ ...edit, cityId: id || null })}
                    onCreateOption={async (query) => {
                      setErr("");
                      if (!edit.countryId) {
                        setErr("Please select country first");
                        return;
                      }
                      const id = await ensureCityOption(edit.countryId, query);
                      if (!id) return;
                      setEdit({ ...edit, cityId: id || null });
                      setBanner("City added");
                    }}
                    createOptionLabel="Add city"
                    createOptionDisabled={!edit.countryId}
                    options={edit.countryId ? cities.filter((c) => c.countryId === edit.countryId) : cities}
                    placeholder={edit.countryId ? "Search city in country" : "Search city"}
                  />
                </div>
              </div>

              <div className="row" style={{ flexWrap: "wrap", alignItems: "end" }}>
                <div style={{ minWidth: 320, flex: 1 }}>
                  <SearchSelect
                    label="Fallback Delivery Profile"
                    value={editDefaultDeliveryProfileId}
                    onChange={setEditDefaultDeliveryProfileId}
                    options={deliveryProfileOptions}
                    placeholder="Search delivery profile"
                  />
                      </div>
              </div>


              <div style={{ marginTop: 10, marginBottom: 10 }}>
                <div style={{ minWidth: 0 }}>
                  <PresetSelectionSummary
                    selectedKeys={editAllowedPresetKeys}
                    presets={presetLibrary}
                    description="Adjust which deliverable formats are available for this destination."
                    onOpen={() => setEditPresetPickerOpen(true)}
                    onClear={() => setEditAllowedPresetKeys([])}
                  />
                  <div style={{ marginTop: 10 }}>
                    <DefaultPresetSelectionSummary
                      selectedKey={editDefaultPresetKey}
                      presets={editDefaultPresetOptions}
                      description=""
                      onOpen={() => setEditDefaultPresetPickerOpen(true)}
                      onClear={() => setEditDefaultPresetKey("")}
                    />
                  </div>
                </div>

                {/* File nomenclature builder (placed below Allowed Presets) */}
                <div
                  style={{
                    marginTop: 12,
                    border: "1px solid rgba(0,0,0,0.10)",
                    borderRadius: 12,
                    background: "#fff",
                    padding: 10,
                  }}
                >
                  <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>File Nomenclature (Template)</div>
                  <ApprovalRequiredToggle value={editApprovalRequired} onChange={setEditApprovalRequired} />
                  <textarea
                    ref={editFileNameTemplateRef}
                    placeholder="e.g. {DESTINATION}_{CHANNEL}_{VALID}_{DATE}"
                    value={edit.fileNameTemplate || ""}
                    onChange={(e) => setEdit({ ...edit, fileNameTemplate: e.target.value })}
                    rows={2}
                    wrap="off"
                    spellCheck={false}
                    style={{
                      width: "100%",
                      minHeight: 54,
                      fontFamily: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, \"Liberation Mono\", \"Courier New\", monospace",
                      fontWeight: 700,
                      fontSize: 14,
                      lineHeight: 1.3,
                      overflowX: "auto",
                      whiteSpace: "pre",
                    }}
                  />
                  {renderTemplateButtons(
                    edit.fileNameTemplate || "",
                    (v) => setEdit({ ...edit, fileNameTemplate: v }),
                    editFileNameTemplateRef,
                  )}
                  {editApprovalRequired ? (
                    <div style={{ marginTop: 8, fontSize: 12, color: "#92400e", background: "#fffbeb", border: "1px solid #fde68a", borderRadius: 10, padding: "8px 10px" }}>
                      Approval-required destinations stage the file first and wait for manual release. Include <code>{"{HOUSE_ID}"}</code> in the file nomenclature so the final delivered file uses the receiver house ID.
                    </div>
                  ) : null}
                </div>

                <div style={{ marginTop: 10 }}>
                  <button
                    type="button"
                    onClick={() => setShowAdvancedEdit((v) => !v)}
                    className="btn btn--ghost btn--sm"
                  >
                    {showAdvancedEdit ? "Hide advanced" : "Advanced"}
                  </button>

                  {showAdvancedEdit ? (
                    <div style={{ marginTop: 8 }}>
                      <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Config (JSON)</div>
                      <textarea
                        style={{ width: "100%", maxWidth: "100%", minHeight: 160, fontFamily: "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, \"Liberation Mono\", \"Courier New\", monospace", boxSizing: "border-box" }}
                        value={editConfigText}
                        onChange={(e) => setEditConfigText(e.target.value)}
                      />
                      <div style={{ marginTop: 6, fontSize: 12, opacity: 0.7 }}>
                        Advanced/internal use. You can leave this as {"{}"}
                      </div>

                      <div
                        style={{
                          marginTop: 12,
                          border: "1px solid rgba(0,0,0,0.10)",
                          borderRadius: 12,
                          background: "#fff",
                          padding: 10,
                        }}
                      >
                        <div className="row" style={{ justifyContent: "space-between", alignItems: "center" }}>
                          <div style={{ fontSize: 12, fontWeight: 900 }}>Metadata XML (optional)</div>
                          <label style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12, fontWeight: 800 }}>
                            <input
                              type="checkbox"
                              checked={editXmlEnabled}
                              onChange={(e) => {
                                const on = e.target.checked;
                                setEditXmlEnabled(on);
                                if (on && (!editXmlConfigText || !editXmlConfigText.trim() || editXmlConfigText.trim() === "{}")) {
                                  setEditXmlConfigText(defaultXmlConfigJson());
                                }
                              }}
                            />
                            Enable
                          </label>
                        </div>

                        {editXmlEnabled ? (
                          <div style={{ marginTop: 8, display: "grid", gap: 8 }}>
                            <div style={{ fontSize: 12, fontWeight: 700 }}>XML config (JSON)</div>
                            <textarea
                              style={{
                                width: "100%",
                                maxWidth: "100%",
                                minHeight: 140,
                                fontFamily:
                                  "ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, \"Liberation Mono\", \"Courier New\", monospace",
                                boxSizing: "border-box",
                              }}
                              value={editXmlConfigText}
                              onChange={(e) => setEditXmlConfigText(e.target.value)}
                            />
                            <div style={{ fontSize: 12, opacity: 0.75 }}>
                              Placeholders: <code>{"{TASK_ID}"}</code>, <code>{"{VALID}"}</code>, <code>{"{FILENAME}"}</code>,{" "}
                              <code>{"{REMOTE_PATH}"}</code>, <code>{"{BASENAME}"}</code>, <code>{"{GENERATED_AT}"}</code>
                            </div>

                            <div style={{ fontSize: 12, fontWeight: 800 }}>Preview</div>
                            <div className="row" style={{ justifyContent: "space-between", alignItems: "center", gap: 8 }}>
                              <div style={{ fontSize: 12, opacity: 0.8 }}>
                                File: <span style={{ fontWeight: 900 }}>{editXmlFileName || "—"}</span> &nbsp;•&nbsp; Remote:{" "}
                                <span style={{ fontWeight: 900 }}>{editXmlRemotePath || "—"}</span>
                              </div>
                              <button
                                type="button"
                                className="btn btn--ghost btn--sm"
                                onClick={() => copyToClipboard(editXmlPreview)}
                                disabled={!editXmlPreview}
                                title="Copy preview XML"
                              >
                                Copy
                              </button>
                            </div>
                            <pre
                              style={{
                                margin: 0,
                                padding: 10,
                                borderRadius: 10,
                                border: "1px solid rgba(0,0,0,0.12)",
                                background: "rgba(0,0,0,0.03)",
                                overflowX: "auto",
                                whiteSpace: "pre",
                                fontSize: 12,
                                lineHeight: 1.3,
                              }}
                            >
                              {editXmlPreview}
                            </pre>
                          </div>
                        ) : (
                          <div style={{ marginTop: 6, fontSize: 12, opacity: 0.7 }}>
                            When enabled, the Delivery Worker will generate an XML sidecar and send it with the media file.
                          </div>
                        )}
                      </div>
                    </div>
                  ) : null}
                </div>
              </div>


              <div className="row" style={{ justifyContent: "flex-end", gap: 8 }}>
                <button onClick={() => setEdit(null)} disabled={busy}>Cancel</button>
                <button onClick={saveEdit} disabled={busy || !edit.name?.trim()}>
                  {busy ? "Saving..." : "Save"}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
