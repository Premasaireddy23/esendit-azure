import { useEffect, useMemo, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { api, type ApiError } from "../../../lib/api";
import { StatusPill } from "../../../ui/StatusPill";
import { presetDisplayName } from "../../presets/presetDisplay";

type MasterStatus = "ACTIVE" | "INACTIVE" | string;

type Destination = {
  id: string;
  name: string;
  status?: MasterStatus | null;
  category?: string | null;
  config?: any;
};

type DeliveryProtocol = "SFTP" | "FTP" | "S3" | "EMAIL" | string;
type DeliveryWorkerRoute = "ACA" | "STATIC_VM";
type CreateProfileSection = "protocol" | "route" | "status" | "connection" | "check" | "advanced";

type TestResult = {
  checkedAt?: string;
  protocol?: DeliveryProtocol;
  status?: string;
  latencyMs?: number | null;
  message?: string | null;
};

type DeliveryProfile = {
  id: string;
  name: string;
  protocol: DeliveryProtocol;
  status: MasterStatus;
  config?: any;
  stagingPath?: string | null;
  finalPath?: string | null;
  lastStatus?: string | null;
  lastCheckedAt?: string | null;
  lastError?: string | null;
  active?: boolean;
};

type Preset = { key: string; label?: string | null; ext?: string | null };

type Channel = {
  id: string;
  name: string;
  destinationId?: string | null;
  mainProfileId?: string | null;
  backupProfileId?: string | null;
  defaultPresetKey?: string | null;
  transcodeOnCommit?: boolean;
  config?: any;
};

type ProfileUsage = {
  main: number;
  backup: number;
  total: number;
};

function normalizeList<T>(data: any): T[] {
  if (Array.isArray(data)) return data as T[];
  if (Array.isArray(data?.rows)) return data.rows as T[];
  if (Array.isArray(data?.data)) return data.data as T[];
  return (data ? [data] : []) as T[];
}

function safeJsonParse(text: string, fallback: any) {
  try {
    if (!text?.trim()) return fallback;
    return JSON.parse(text);
  } catch {
    return fallback;
  }
}

function pretty(v: any) {
  try {
    return JSON.stringify(v ?? {}, null, 2);
  } catch {
    return "{}";
  }
}


function normalizeProtocolConfig(protocol: DeliveryProtocol, raw: any) {
  const cfg = { ...(raw ?? {}) } as Record<string, any>;
  if (protocol === "SFTP" || protocol === "FTP") {
    delete cfg.path;
  }
  return cfg;
}

function pathVariantsFromConfig(raw: any) {
  const cfg = raw && typeof raw === "object" ? raw : {};
  return {
    sdStagingPath: String((cfg as any).sdStagingPath || "").trim(),
    sdFinalPath: String((cfg as any).sdFinalPath || "").trim(),
    hdStagingPath: String((cfg as any).hdStagingPath || "").trim(),
    hdFinalPath: String((cfg as any).hdFinalPath || "").trim(),
  };
}

function withPathVariants(raw: any, next: { sdStagingPath?: string | null; sdFinalPath?: string | null; hdStagingPath?: string | null; hdFinalPath?: string | null }) {
  const cfg = raw && typeof raw === "object" ? { ...raw } : {};
  const mappings: Array<[keyof typeof next, string]> = [
    ["sdStagingPath", "sdStagingPath"],
    ["sdFinalPath", "sdFinalPath"],
    ["hdStagingPath", "hdStagingPath"],
    ["hdFinalPath", "hdFinalPath"],
  ];
  for (const [sourceKey, targetKey] of mappings) {
    const value = String(next[sourceKey] || "").trim();
    if (value) (cfg as any)[targetKey] = value;
    else delete (cfg as any)[targetKey];
  }
  return cfg;
}

function tryParseJson(raw: string) {
  try {
    if (!raw?.trim()) return { ok: true, value: {} } as const;
    return { ok: true, value: JSON.parse(raw) } as const;
  } catch (e: any) {
    return { ok: false, error: String(e?.message || e) } as const;
  }
}

function fmtDt(iso?: string | null) {
  if (!iso) return "—";
  try {
    const d = new Date(iso);
    if (isNaN(d.getTime())) return iso;
    return d.toLocaleString();
  } catch {
    return iso;
  }
}

function protocolLabel(p: DeliveryProtocol) {
  return p === "EMAIL" ? "Email" : p;
}

function defaultsFor(p: DeliveryProtocol) {
  switch (p) {
    case "SFTP":
      return { host: "", port: 22, username: "", password: "" };
    case "FTP":
      return { host: "", port: 21, username: "", password: "" };
    case "S3":
      return { bucket: "", region: "", prefix: "" };
    case "EMAIL":
      return { to: "", cc: "", subject: "", from: "" };
    case "ASPERA":
      return { host: "", port: 33001, username: "", password: "", rateMbps: 0 };
    case "FILECATALYST":
      return { host: "", port: 21, username: "", password: "", secure: true, rateKbps: 0, numThreads: 1, autoResume: true };
    default:
      return {};
  }
}

function splitProfileConfig(p: DeliveryProtocol, raw: any) {
  const cfg = raw && typeof raw === "object" ? { ...raw } : {};
  const simple = defaultsFor(p) as any;
  const extra: any = { ...cfg };

  for (const key of Object.keys(simple)) {
    if (cfg[key] !== undefined) simple[key] = cfg[key];
    delete extra[key];
  }

  return { simpleConfig: simple, extraConfig: extra };
}

function normalizeWorkerRoute(raw: any): DeliveryWorkerRoute {
  return String(raw || "").trim().toUpperCase() === "STATIC_VM" ? "STATIC_VM" : "ACA";
}

function workerRouteLabel(route: DeliveryWorkerRoute) {
  return route === "STATIC_VM" ? "SiP" : "NSiP";
}

function workerRouteHelp(_route: DeliveryWorkerRoute) {
  return "";
}

function workerRouteFromConfig(raw: any): DeliveryWorkerRoute {
  const cfg = raw && typeof raw === "object" ? raw : {};
  return normalizeWorkerRoute((cfg as any).workerRoute);
}

function withWorkerRoute(raw: any, route: DeliveryWorkerRoute) {
  const cfg = raw && typeof raw === "object" ? { ...raw } : {};
  cfg.workerRoute = normalizeWorkerRoute(route);
  return cfg;
}


function destinationDefaultProfileIdFromConfig(config: any) {
  const cfg = config && typeof config === "object" ? config : {};
  const defaults = cfg.deliveryProfileDefaults && typeof cfg.deliveryProfileDefaults === "object" ? cfg.deliveryProfileDefaults : {};
  return String(defaults.defaultProfileId || cfg.defaultDeliveryProfileId || "").trim();
}


function destinationDefaultPresetKeyFromConfig(config: any) {
  const cfg = config && typeof config === "object" ? config : {};
  return String(cfg.defaultPresetKey || "").trim();
}

function destinationTranscodeOnCommitFromConfig(config: any) {
  const cfg = config && typeof config === "object" ? config : {};
  const raw = cfg.transcodeOnCommit;
  if (raw === false || raw === "false" || raw === 0 || raw === "0") return false;
  return true;
}


function testResultTone(status?: string) {
  switch (String(status || "").toUpperCase()) {
    case "ONLINE":
      return { bg: "#ecfdf3", border: "#b7e4c7", color: "#065f46" };
    case "OFFLINE":
      return { bg: "#fef2f2", border: "#fecaca", color: "#991b1b" };
    default:
      return { bg: "#f8fafc", border: "#dbe4ee", color: "#334155" };
  }
}

function segmentedButtonStyle(active: boolean, tone: "purple" | "green" = "purple") {
  const palette =
    tone === "green"
      ? {
          activeBg: "#dff6e7",
          activeBorder: "#86d0a2",
          activeText: "#14532d",
          activeShadow: "0 0 0 1px rgba(22,101,52,0.06), 0 8px 16px rgba(22,101,52,0.10)",
        }
      : {
          activeBg: "#ece9ff",
          activeBorder: "#8b5cf6",
          activeText: "#4c1d95",
          activeShadow: "0 0 0 1px rgba(139,92,246,0.10), 0 8px 16px rgba(76,29,149,0.12)",
        };

  return {
    minWidth: 88,
    padding: "10px 16px",
    borderRadius: 12,
    border: active ? `1.5px solid ${palette.activeBorder}` : "1px solid #d0d5dd",
    background: active ? palette.activeBg : "#ffffff",
    color: active ? palette.activeText : "#101828",
    fontWeight: active ? 800 : 700,
    boxShadow: active ? palette.activeShadow : "none",
    transform: active ? "translateY(-1px)" : "none",
    transition: "all 140ms ease",
  } as const;
}

function wizardNavButtonStyle(active: boolean) {
  return {
    width: "100%",
    textAlign: "left" as const,
    padding: "12px 14px",
    borderRadius: 12,
    border: active ? "1px solid #8b5cf6" : "1px solid #d0d5dd",
    background: active ? "#f5f3ff" : "#ffffff",
    color: active ? "#4c1d95" : "#111827",
    fontWeight: active ? 800 : 700,
    boxShadow: active ? "0 10px 24px rgba(139,92,246,0.12)" : "none",
    transition: "all 140ms ease",
  };
}

function compactSectionBodyStyle(section: CreateProfileSection) {
  const wide = section === "connection" || section === "advanced";
  return {
    width: "100%",
    maxWidth: wide ? "100%" : 760,
    display: "grid",
    gap: 12,
    alignContent: "start" as const,
    justifyItems: "stretch" as const,
  };
}

function StatusButtons({
  value,
  onChange,
  disabled,
}: {
  value: MasterStatus;
  onChange: (next: MasterStatus) => void;
  disabled?: boolean;
}) {
  const options: MasterStatus[] = ["ACTIVE", "INACTIVE"];
  return (
    <div className="row" style={{ gap: 8, flexWrap: "wrap" }}>
      {options.map((opt) => {
        const active = value === opt;
        return (
          <button
            key={opt}
            type="button"
            className="btn"
            style={{ ...segmentedButtonStyle(active, opt === "ACTIVE" ? "green" : "purple"), minWidth: 110 }}
            onClick={() => onChange(opt)}
            disabled={disabled}
            aria-pressed={active}
          >
            {opt === "ACTIVE" ? "Active" : "Inactive"}
          </button>
        );
      })}
    </div>
  );
}

function ProtocolButtons({
  value,
  onChange,
  disabled,
}: {
  value: DeliveryProtocol;
  onChange: (next: DeliveryProtocol) => void;
  disabled?: boolean;
}) {
  const options: DeliveryProtocol[] = ["SFTP", "FTP", "S3", "EMAIL", "ASPERA", "FILECATALYST"];
  return (
    <div className="row" style={{ gap: 8, flexWrap: "wrap" }}>
      {options.map((opt) => {
        const active = value === opt;
        return (
          <button
            key={opt}
            type="button"
            className="btn"
            style={segmentedButtonStyle(active, "purple")}
            onClick={() => onChange(opt)}
            disabled={disabled}
            aria-pressed={active}
          >
            {protocolLabel(opt)}
          </button>
        );
      })}
    </div>
  );
}

function WorkerRouteButtons({
  value,
  onChange,
  disabled,
}: {
  value: DeliveryWorkerRoute;
  onChange: (next: DeliveryWorkerRoute) => void;
  disabled?: boolean;
}) {
  const options: DeliveryWorkerRoute[] = ["ACA", "STATIC_VM"];
  return (
    <div className="row" style={{ gap: 8, flexWrap: "wrap" }}>
      {options.map((opt) => {
        const active = value === opt;
        return (
          <button
            key={opt}
            type="button"
            className="btn"
            style={segmentedButtonStyle(active, opt === "STATIC_VM" ? "green" : "purple")}
            onClick={() => onChange(opt)}
            disabled={disabled}
            aria-pressed={active}
            title={workerRouteHelp(opt)}
          >
            {workerRouteLabel(opt)}
          </button>
        );
      })}
    </div>
  );
}

function TestResultCard({ title, result }: { title: string; result: TestResult | null }) {
  if (!result) return null;
  const tone = testResultTone(result.status);
  return (
    <div className="card" style={{ background: tone.bg, borderColor: tone.border, color: tone.color }}>
      <div style={{ display: "grid", gap: 6 }}>
        <div style={{ fontWeight: 800 }}>{title}</div>
        <div style={{ fontSize: 13 }}>
          <strong>Status:</strong> {result.status || "UNKNOWN"}
          {typeof result.latencyMs === "number" ? ` · ${result.latencyMs} ms` : ""}
        </div>
        {result.message ? <div style={{ fontSize: 13 }}>{result.message}</div> : null}
        {result.checkedAt ? <div style={{ fontSize: 12, opacity: 0.8 }}>Checked: {fmtDt(result.checkedAt)}</div> : null}
      </div>
    </div>
  );
}

function ConfigQuickFields({
  protocol,
  configText,
  setConfigText,
}: {
  protocol: DeliveryProtocol;
  configText: string;
  setConfigText: (next: string) => void;
}) {
  const parsed = safeJsonParse(configText, defaultsFor(protocol));
  const cfg = normalizeProtocolConfig(protocol, parsed);

  function setField(key: string, value: string) {
    const next = normalizeProtocolConfig(protocol, safeJsonParse(configText, defaultsFor(protocol)));
    next[key] = ["port", "rateMbps", "rateKbps", "numThreads"].includes(key) ? (value === "" ? "" : Number(value)) : value === "true" ? true : value === "false" ? false : value;
    setConfigText(pretty(next));
  }

  if (protocol === "SFTP" || protocol === "FTP") {
    return (
      <div style={{ display: "grid", gap: 10 }}>
        <div className="row" style={{ flexWrap: "wrap", alignItems: "end" }}>
          <div style={{ minWidth: 220, flex: 1 }}>
            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Host</div>
            <input placeholder="sftp.example.com" value={String(cfg.host ?? "")} onChange={(e) => setField("host", e.target.value)} />
          </div>
          <div style={{ minWidth: 120 }}>
            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Port</div>
            <input placeholder={protocol === "SFTP" ? "22" : "21"} value={String(cfg.port ?? "")} onChange={(e) => setField("port", e.target.value)} />
          </div>
          <div style={{ minWidth: 220, flex: 1 }}>
            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Username</div>
            <input placeholder="username" value={String(cfg.username ?? "")} onChange={(e) => setField("username", e.target.value)} />
          </div>
          <div style={{ minWidth: 220, flex: 1 }}>
            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Password</div>
            <input type="password" placeholder="password" value={String(cfg.password ?? "")} onChange={(e) => setField("password", e.target.value)} />
          </div>
        </div>
      </div>
    );
  }

  if (protocol === "ASPERA") {
    return (
      <div style={{ display: "grid", gap: 10 }}>
        <div style={{ fontSize: 12, color: "#475467" }}>Use this for direct Aspera server transfers. The worker image must include the Aspera transfer engine.</div>
        <div className="row" style={{ flexWrap: "wrap", alignItems: "end" }}>
          <div style={{ minWidth: 220, flex: 1 }}>
            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Host</div>
            <input placeholder="aspera.example.com" value={String(cfg.host ?? "")} onChange={(e) => setField("host", e.target.value)} />
          </div>
          <div style={{ minWidth: 120 }}>
            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Port</div>
            <input placeholder="33001" value={String(cfg.port ?? "")} onChange={(e) => setField("port", e.target.value)} />
          </div>
          <div style={{ minWidth: 220, flex: 1 }}>
            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Username</div>
            <input placeholder="username" value={String(cfg.username ?? "")} onChange={(e) => setField("username", e.target.value)} />
          </div>
          <div style={{ minWidth: 220, flex: 1 }}>
            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Password</div>
            <input type="password" placeholder="password" value={String(cfg.password ?? "")} onChange={(e) => setField("password", e.target.value)} />
          </div>
          <div style={{ minWidth: 160 }}>
            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Rate (Mbps)</div>
            <input placeholder="optional" value={String(cfg.rateMbps ?? "")} onChange={(e) => setField("rateMbps", e.target.value)} />
          </div>
        </div>
      </div>
    );
  }

  if (protocol === "FILECATALYST") {
    return (
      <div style={{ display: "grid", gap: 10 }}>
        <div style={{ fontSize: 12, color: "#475467" }}>Use this for FileCatalyst CLI based deliveries. The worker image must include Java and the FileCatalyst client runtime.</div>
        <div className="row" style={{ flexWrap: "wrap", alignItems: "end" }}>
          <div style={{ minWidth: 220, flex: 1 }}>
            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Host</div>
            <input placeholder="filecatalyst.example.com" value={String(cfg.host ?? "")} onChange={(e) => setField("host", e.target.value)} />
          </div>
          <div style={{ minWidth: 120 }}>
            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Port</div>
            <input placeholder="21" value={String(cfg.port ?? "")} onChange={(e) => setField("port", e.target.value)} />
          </div>
          <div style={{ minWidth: 220, flex: 1 }}>
            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Username</div>
            <input placeholder="username" value={String(cfg.username ?? "")} onChange={(e) => setField("username", e.target.value)} />
          </div>
          <div style={{ minWidth: 220, flex: 1 }}>
            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Password</div>
            <input type="password" placeholder="password" value={String(cfg.password ?? "")} onChange={(e) => setField("password", e.target.value)} />
          </div>
          <div style={{ minWidth: 140 }}>
            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Rate (Kbps)</div>
            <input placeholder="optional" value={String(cfg.rateKbps ?? "")} onChange={(e) => setField("rateKbps", e.target.value)} />
          </div>
          <div style={{ minWidth: 140 }}>
            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Threads</div>
            <input placeholder="1" value={String(cfg.numThreads ?? "")} onChange={(e) => setField("numThreads", e.target.value)} />
          </div>
          <label style={{ display: "flex", alignItems: "center", gap: 8, minWidth: 150, paddingBottom: 8 }}>
            <input type="checkbox" checked={Boolean(cfg.secure)} onChange={(e) => setField("secure", e.target.checked ? "true" : "false")} />
            Secure control channel
          </label>
          <label style={{ display: "flex", alignItems: "center", gap: 8, minWidth: 150, paddingBottom: 8 }}>
            <input type="checkbox" checked={cfg.autoResume !== false} onChange={(e) => setField("autoResume", e.target.checked ? "true" : "false")} />
            Auto resume
          </label>
        </div>
      </div>
    );
  }

  if (protocol === "S3") {
    return (
      <div style={{ display: "grid", gap: 10 }}>
        <div style={{ fontSize: 12, color: "#475467" }}>Fill the common S3 details here. Use advanced JSON only for extra settings.</div>
        <div className="row" style={{ flexWrap: "wrap", alignItems: "end" }}>
          <div style={{ minWidth: 240, flex: 1 }}>
            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Bucket</div>
            <input placeholder="bucket-name" value={String(cfg.bucket ?? "")} onChange={(e) => setField("bucket", e.target.value)} />
          </div>
          <div style={{ minWidth: 180, flex: 1 }}>
            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Region</div>
            <input placeholder="eu-west-1" value={String(cfg.region ?? "")} onChange={(e) => setField("region", e.target.value)} />
          </div>
          <div style={{ minWidth: 240, flex: 1 }}>
            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Prefix</div>
            <input placeholder="deliveries/final" value={String(cfg.prefix ?? "")} onChange={(e) => setField("prefix", e.target.value)} />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={{ display: "grid", gap: 10 }}>
      <div style={{ fontSize: 12, color: "#475467" }}>Fill the common email values here. Use advanced JSON only for extra settings.</div>
      <div className="row" style={{ flexWrap: "wrap", alignItems: "end" }}>
        <div style={{ minWidth: 240, flex: 1 }}>
          <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>To</div>
          <input placeholder="ops@example.com" value={String(cfg.to ?? "")} onChange={(e) => setField("to", e.target.value)} />
        </div>
        <div style={{ minWidth: 240, flex: 1 }}>
          <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>CC</div>
          <input placeholder="team@example.com" value={String(cfg.cc ?? "")} onChange={(e) => setField("cc", e.target.value)} />
        </div>
        <div style={{ minWidth: 240, flex: 1 }}>
          <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>From</div>
          <input placeholder="noreply@example.com" value={String(cfg.from ?? "")} onChange={(e) => setField("from", e.target.value)} />
        </div>
        <div style={{ minWidth: 260, flex: 1 }}>
          <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Subject</div>
          <input placeholder="Delivery notification" value={String(cfg.subject ?? "")} onChange={(e) => setField("subject", e.target.value)} />
        </div>
      </div>
    </div>
  );
}

function profileServerBadge(statusLike?: string | null) {
  const raw = String(statusLike || "").trim().toUpperCase();
  const isOffline = raw.includes("OFFLINE") || raw.includes("DOWN") || raw.includes("ERROR") || raw.includes("FAILED");
  const label = raw || "ONLINE";
  return {
    label,
    style: {
      fontSize: 11,
      fontWeight: 800,
      padding: "4px 10px",
      borderRadius: 999,
      whiteSpace: "nowrap" as const,
      border: isOffline ? "1px solid rgba(239, 68, 68, 0.22)" : "1px solid rgba(74, 222, 128, 0.22)",
      background: isOffline
        ? "linear-gradient(180deg, rgba(254, 242, 242, 0.96) 0%, rgba(254, 226, 226, 0.96) 100%)"
        : "linear-gradient(180deg, rgba(240, 253, 244, 0.96) 0%, rgba(220, 252, 231, 0.96) 100%)",
      color: isOffline ? "#b91c1c" : "#166534",
      boxShadow: isOffline
        ? "inset 0 1px 0 rgba(255,255,255,0.65), 0 6px 18px rgba(239, 68, 68, 0.10)"
        : "inset 0 1px 0 rgba(255,255,255,0.7), 0 8px 20px rgba(34, 197, 94, 0.12)",
    },
  };
}

export function DeliverySetupPage() {
  const [sp, setSp] = useSearchParams();
  const nav = useNavigate();


  const [destinations, setDestinations] = useState<Destination[]>([]);
  const [profiles, setProfiles] = useState<DeliveryProfile[]>([]);
  const [channels, setChannels] = useState<Channel[]>([]);
  const [presetLibrary, setPresetLibrary] = useState<Preset[]>([]);

  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [banner, setBanner] = useState("");

  const [destQ, setDestQ] = useState("");
  const [profileQ, setProfileQ] = useState("");
  const [channelQ, setChannelQ] = useState("");
  const [profilePickerQ, setProfilePickerQ] = useState("");

  const [showAllProfiles, setShowAllProfiles] = useState(true);
  const [mappedOnly, setMappedOnly] = useState(true);

  const selectedDestinationId = (sp.get("destinationId") || "").trim();
  const selectedProfileId = (sp.get("profileId") || "").trim();

  const [selectedChannelIds, setSelectedChannelIds] = useState<Record<string, boolean>>({});


function hereReturnTo() {
  const n = new URLSearchParams();
  if (selectedDestinationId) n.set("destinationId", selectedDestinationId);
  if (selectedProfileId) n.set("profileId", selectedProfileId);
  n.set("view", activePane);
  const qs = n.toString();
  return `/masters/delivery-setup${qs ? `?${qs}` : ""}`;
}

function goToDestinationCreate() {
  const rt = hereReturnTo();
  nav(`/masters/destinations?create=1&returnTo=${encodeURIComponent(rt)}&returnOnSave=1`);
}

function goToDestinationEdit(id: string) {
  const rt = hereReturnTo();
  nav(`/masters/destinations?editId=${encodeURIComponent(id)}&returnTo=${encodeURIComponent(rt)}&returnOnSave=1`);
}

function goToChannelCreate() {
  if (!selectedDestinationId) return;
  const rt = hereReturnTo();
  nav(
    `/masters/channels?destinationId=${encodeURIComponent(selectedDestinationId)}&create=1&returnTo=${encodeURIComponent(rt)}&returnOnSave=1`,
  );
}

function goToChannelEdit(id: string) {
  if (!selectedDestinationId) return;
  const rt = hereReturnTo();
  nav(
    `/masters/channels?destinationId=${encodeURIComponent(selectedDestinationId)}&editId=${encodeURIComponent(id)}&returnTo=${encodeURIComponent(rt)}&returnOnSave=1`,
  );
}

  // Profile modal state
  const [profileModal, setProfileModal] = useState<
    | null
    | {
        mode: "create" | "edit";
        id?: string;
        name: string;
        protocol: DeliveryProtocol;
        status: MasterStatus;
        stagingPath: string;
        finalPath: string;
        sdStagingPath: string;
        sdFinalPath: string;
        hdStagingPath: string;
        hdFinalPath: string;
        configText: string;
        simpleConfig: any;
        showAdvanced: boolean;
        section: CreateProfileSection;
      }
  >(null);
  const [testingProfile, setTestingProfile] = useState(false);
  const [profileTestResult, setProfileTestResult] = useState<TestResult | null>(null);

  function setProfileModalWorkerRoute(nextRoute: DeliveryWorkerRoute) {
    if (!profileModal) return;
    const nextConfig = withWorkerRoute(safeJsonParse(profileModal.configText, {}), nextRoute);
    setProfileModal({ ...profileModal, configText: pretty(nextConfig) });
  }

  function closeProfileModal() {
    setProfileModal(null);
    setProfileTestResult(null);
    setErr("");
  }

  function profileSectionTitle(section: CreateProfileSection) {
    switch (section) {
      case "protocol":
        return "Protocol";
      case "route":
        return "Delivery route";
      case "status":
        return "Status";
      case "connection":
        return "Connection details";
      case "check":
        return "Check connection";
      case "advanced":
        return "Advanced config";
      default:
        return "Delivery profile";
    }
  }

  function applyDefaultsInModal() {
    if (!profileModal) return;
    const nextRoute = workerRouteFromConfig(safeJsonParse(profileModal.configText, {}));
    setProfileModal({ ...profileModal, configText: pretty(withWorkerRoute(defaultsFor(profileModal.protocol), nextRoute)) });
    setProfileTestResult(null);
    setBanner("Starter config applied");
  }

  function prettifyModalConfig() {
    if (!profileModal) return;
    const parsed = tryParseJson(profileModal.configText);
    if (!parsed.ok) {
      setErr(`Invalid JSON config: ${parsed.error}`);
      return;
    }
    const nextRoute = workerRouteFromConfig(parsed.value);
    setProfileModal({ ...profileModal, configText: pretty(withWorkerRoute(normalizeProtocolConfig(profileModal.protocol, parsed.value), nextRoute)) });
    setBanner("Advanced config prettified");
  }

  async function runConnectionTest(payload: { protocol: DeliveryProtocol; configText: string }) {
    const parsed = tryParseJson(payload.configText);
    if (!parsed.ok) {
      throw new Error(`Invalid JSON config: ${parsed.error}`);
    }
    return api<TestResult>("/masters/delivery-profiles/test", {
      method: "POST",
      body: JSON.stringify({
        protocol: payload.protocol,
        config: normalizeProtocolConfig(payload.protocol, parsed.value),
        timeoutMs: 3000,
      }),
    });
  }

  async function testProfileConnection() {
    if (!profileModal) return;
    setTestingProfile(true);
    setErr("");
    setProfileTestResult(null);
    try {
      const result = await runConnectionTest({ protocol: profileModal.protocol, configText: profileModal.configText });
      setProfileTestResult(result);
      setBanner("Connection check completed");
    } catch (e: any) {
      setErr((e as ApiError)?.message || String(e?.message || e) || "Connection test failed");
    } finally {
      setTestingProfile(false);
    }
  }

  async function loadBase() {
    setErr("");
    setBusy(true);
    try {
      const [d0, p0, pl] = await Promise.all([
        api<any>("/masters/destinations"),
        api<any>("/masters/delivery-profiles"),
        api<{ presets: Preset[] }>("/presets").catch(() => ({ presets: [] })),
      ]);
      const d = normalizeList<Destination>(d0);
      const pRaw = normalizeList<any>(p0);
      const p: DeliveryProfile[] = pRaw.map((r: any) => ({
        ...r,
        status: r.status ?? (r.active === false ? "INACTIVE" : "ACTIVE"),
      }));

      setDestinations(d);
      setProfiles(p);
      setPresetLibrary(Array.isArray((pl as any)?.presets) ? (pl as any).presets : []);

      // Keep destination unselected until the user explicitly picks one.
    } catch (e: any) {
      setErr((e as ApiError)?.message || "Failed to load destinations/profiles");
    } finally {
      setBusy(false);
    }
  }

  async function loadChannels(destinationId: string) {
    if (!destinationId) {
      setChannels([]);
      return;
    }
    setErr("");
    setBusy(true);
    try {
      const c0 = await api<any>(`/masters/channels?destinationId=${encodeURIComponent(destinationId)}`);
      const c = normalizeList<any>(c0).map((row: any) => ({
        ...row,
        defaultPresetKey: String(row?.defaultPresetKey || row?.config?.defaultPresetKey || "").trim() || null,
        transcodeOnCommit: Boolean(row?.transcodeOnCommit ?? row?.config?.transcodeOnCommit ?? true),
      })) as Channel[];
      setChannels(c);
      setSelectedChannelIds({});

    } catch (e: any) {
      setErr((e as ApiError)?.message || "Failed to load channels");
    } finally {
      setBusy(false);
    }
  }

  useEffect(() => {
    loadBase();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!selectedDestinationId) return;
    loadChannels(selectedDestinationId);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedDestinationId]);

  useEffect(() => {
    if (!banner) return;
    const t = setTimeout(() => setBanner(""), 2200);
    return () => clearTimeout(t);
  }, [banner]);

  const filteredDestinations = useMemo(() => {
    const q = destQ.trim().toLowerCase();
    const base = destinations.slice();
    if (!q) return base;
    return base.filter((d) => d.name.toLowerCase().includes(q));
  }, [destinations, destQ]);

  const usageByProfile = useMemo(() => {
    const m = new Map<string, ProfileUsage>();
    for (const ch of channels) {
      if (ch.mainProfileId) {
        const u = m.get(ch.mainProfileId) || { main: 0, backup: 0, total: 0 };
        u.main += 1;
        u.total += 1;
        m.set(ch.mainProfileId, u);
      }
      if (ch.backupProfileId) {
        const u = m.get(ch.backupProfileId) || { main: 0, backup: 0, total: 0 };
        u.backup += 1;
        u.total += 1;
        m.set(ch.backupProfileId, u);
      }
    }
    return m;
  }, [channels]);

  const profilesForDestination = useMemo(() => {
    const q = profileQ.trim().toLowerCase();
    const list = !selectedDestinationId || showAllProfiles
      ? profiles
      : profiles.filter((p) => usageByProfile.has(p.id));

    const sorted = list.slice().sort((a, b) => {
      const ua = usageByProfile.get(a.id)?.total || 0;
      const ub = usageByProfile.get(b.id)?.total || 0;
      if (ua !== ub) return ub - ua;
      return a.name.localeCompare(b.name);
    });

    if (!q) return sorted;
    return sorted.filter((p) => (p.name || "").toLowerCase().includes(q) || String(p.protocol || "").toLowerCase().includes(q));
  }, [profiles, usageByProfile, showAllProfiles, profileQ]);

  const visibleChannels = useMemo(() => {
    const q = channelQ.trim().toLowerCase();
    let list = channels;

    if (selectedProfileId && mappedOnly) {
      list = list.filter((c) => resolvedMainProfileIdForChannel(c) === selectedProfileId || resolvedBackupProfileIdForChannel(c) === selectedProfileId);
    }

    if (q) {
      list = list.filter((c) => c.name.toLowerCase().includes(q));
    }

    return list.slice().sort((a, b) => a.name.localeCompare(b.name));
  }, [channels, channelQ, selectedProfileId, mappedOnly]);

  const selectedCount = useMemo(() => Object.values(selectedChannelIds).filter(Boolean).length, [selectedChannelIds]);

  function setSelectedDestination(id: string) {
    setSp((prev) => {
      const n = new URLSearchParams(prev);
      n.set("destinationId", id);
      return n;
    });
  }

  function setSelectedProfile(id: string) {
    setSp((prev) => {
      const n = new URLSearchParams(prev);
      if (id) n.set("profileId", id);
      else n.delete("profileId");
      return n;
    });
  }

  function resolvedMainProfileIdForChannel(ch: Channel) {
    return ch.mainProfileId || destinationDefaultProfileId || "";
  }

  function presetLabel(key?: string | null) {
    const clean = String(key || "").trim();
    if (!clean) return "";
    const p = presetLibrary.find((x) => x.key === clean);
    return p ? `${presetDisplayName(p)} (${p.key})` : clean;
  }

  function resolvedBackupProfileIdForChannel(ch: Channel) {
    return ch.backupProfileId || "";
  }

  function openCreateProfile() {
    const protocol: DeliveryProtocol = "SFTP";
    const split = splitProfileConfig(protocol, withWorkerRoute(defaultsFor(protocol), "ACA"));
    setProfileTestResult(null);
    setErr("");
    setProfileModal({
      mode: "create",
      name: "",
      protocol,
      status: "ACTIVE",
      stagingPath: "",
      finalPath: "",
      sdStagingPath: "",
      sdFinalPath: "",
      hdStagingPath: "",
      hdFinalPath: "",
      configText: pretty(withWorkerRoute(defaultsFor(protocol), "ACA")),
      simpleConfig: split.simpleConfig,
      showAdvanced: false,
      section: "protocol",
    });
  }

  function openEditProfile(p: DeliveryProfile) {
    const protocol = (p.protocol || "SFTP") as DeliveryProtocol;
    const split = splitProfileConfig(protocol, withWorkerRoute(p.config ?? {}, workerRouteFromConfig(p.config)));
    const variants = pathVariantsFromConfig(p.config ?? {});
    setProfileTestResult(null);
    setErr("");
    setProfileModal({
      mode: "edit",
      id: p.id,
      name: p.name || "",
      protocol,
      status: (p.status as any) || "ACTIVE",
      stagingPath: String(p.stagingPath ?? ""),
      finalPath: String(p.finalPath ?? ""),
      sdStagingPath: variants.sdStagingPath,
      sdFinalPath: variants.sdFinalPath,
      hdStagingPath: variants.hdStagingPath,
      hdFinalPath: variants.hdFinalPath,
      configText: pretty(withWorkerRoute(normalizeProtocolConfig(protocol, p.config ?? {}), workerRouteFromConfig(p.config))),
      simpleConfig: split.simpleConfig,
      showAdvanced: false,
      section: "protocol",
    });
  }

  async function saveProfileModal() {
    if (!profileModal) return;
    const name = profileModal.name.trim();
    if (!name) return;

    const parsed = tryParseJson(profileModal.configText);
    if (!parsed.ok) {
      setErr(`Invalid JSON config: ${parsed.error}`);
      return;
    }

    setBusy(true);
    setErr("");
    try {
      const payload = {
        name,
        protocol: profileModal.protocol,
        status: profileModal.status,
        stagingPath: profileModal.stagingPath.trim() || null,
        finalPath: profileModal.finalPath.trim() || null,
        config: withPathVariants(
          normalizeProtocolConfig(profileModal.protocol, parsed.value),
          {
            sdStagingPath: profileModal.sdStagingPath,
            sdFinalPath: profileModal.sdFinalPath,
            hdStagingPath: profileModal.hdStagingPath,
            hdFinalPath: profileModal.hdFinalPath,
          },
        ),
      };

      if (profileModal.mode === "create") {
        const created: any = await api<any>("/masters/delivery-profiles", {
          method: "POST",
          body: JSON.stringify(payload),
        });
        setBanner("Delivery profile created");
        closeProfileModal();
        await loadBase();
        const createdId = created?.id;
        if (createdId) setSelectedProfile(createdId);
      } else {
        await api(`/masters/delivery-profiles/${profileModal.id}`, {
          method: "PATCH",
          body: JSON.stringify(payload),
        });
        setBanner("Changes saved");
        closeProfileModal();
        await loadBase();
      }
    } catch (e: any) {
      setErr((e as ApiError)?.message || "Save failed (check profile values)");
    } finally {
      setBusy(false);
    }
  }

  async function deleteProfile(id: string) {

    if (!confirm("Delete this delivery profile?")) return;
    setBusy(true);
    setErr("");
    try {
      await api(`/masters/delivery-profiles/${id}`, { method: "DELETE" });
      setBanner("Delivery profile deleted");
      setProfileModal(null);
      await loadBase();
      if (selectedProfileId === id) {
        setSelectedProfile("");
      }
    } catch (e: any) {
      setErr((e as ApiError)?.message || "Delete failed");
    } finally {
      setBusy(false);
    }
  }

  function toggleChannel(id: string, checked: boolean) {
    setSelectedChannelIds((m) => ({ ...m, [id]: checked }));
  }

  function selectAllVisible(checked: boolean) {
    const next: Record<string, boolean> = { ...selectedChannelIds };
    for (const ch of visibleChannels) next[ch.id] = checked;
    setSelectedChannelIds(next);
  }

  async function batchPatchChannels(mode: "main" | "backup" | "clearMain" | "clearBackup") {
    if (!selectedDestinationId || !selectedProfileId) return;

    const selectedIds = Object.entries(selectedChannelIds)
      .filter(([, v]) => v)
      .map(([k]) => k);
    if (!selectedIds.length) return;

    const byId = new Map<string, Channel>(channels.map((c) => [c.id, c] as const));

    setBusy(true);
    setErr("");
    try {
      for (const id of selectedIds) {
        const ch = byId.get(id);
        if (!ch) continue;

        let patch: any = null;
        if (mode === "main") {
          patch = { mainProfileId: selectedProfileId };
        } else if (mode === "backup") {
          patch = { backupProfileId: selectedProfileId };
        } else if (mode === "clearMain") {
          if (ch.mainProfileId !== selectedProfileId) continue;
          patch = { mainProfileId: null };
        } else if (mode === "clearBackup") {
          if (ch.backupProfileId !== selectedProfileId) continue;
          patch = { backupProfileId: null };
        }

        if (!patch) continue;
        await api(`/masters/channels/${id}`, { method: "PATCH", body: JSON.stringify(patch) });
      }

      setBanner("Channels updated");
      await loadChannels(selectedDestinationId);
    } catch (e: any) {
      setErr((e as ApiError)?.message || "Failed to update channels");
    } finally {
      setBusy(false);
    }
  }

  const selectedDestination = destinations.find((d) => d.id === selectedDestinationId);
  const selectedProfile = profiles.find((p) => p.id === selectedProfileId);
  const destinationDefaultProfileId = destinationDefaultProfileIdFromConfig(selectedDestination?.config);
  const destinationDefaultProfile = profiles.find((p) => p.id === destinationDefaultProfileId);
  const destinationDefaultPresetKey = destinationDefaultPresetKeyFromConfig(selectedDestination?.config);
  const destinationTranscodeOnCommit = destinationTranscodeOnCommitFromConfig(selectedDestination?.config);

  const paneOrder = ["profiles", "destinations", "channels"] as const;
  type SetupPane = (typeof paneOrder)[number];

  const activePane: SetupPane = (() => {
    const raw = (sp.get("view") || "profiles").toLowerCase();
    return (paneOrder as readonly string[]).includes(raw) ? (raw as SetupPane) : "profiles";
  })();

  function setActivePane(pane: SetupPane) {
    setSp((prev) => {
      const n = new URLSearchParams(prev);
      n.set("view", pane);
      return n;
    });
  }

  function paneLabel(pane: SetupPane) {
    if (pane === "profiles") return "Profiles";
    if (pane === "destinations") return "Destinations";
    return "Channels";
  }

  function paneSummary(pane: SetupPane) {
    if (pane === "profiles") return `${profiles.length} available`;
    if (pane === "destinations") return selectedDestination?.name || `${destinations.length} available`;
    if (!selectedDestinationId) return "Pick destination";
    if (!selectedProfileId) return "Pick profile";
    return `${visibleChannels.length} visible`;
  }

  const compactSearchWrapStyle = { width: "min(420px, 100%)" } as const;
  const compactSearchInputStyle = {
    width: "100%",
    maxWidth: 420,
    boxSizing: "border-box" as const,
    padding: "10px 14px",
    borderRadius: 12,
  };


  useEffect(() => {
    if (!selectedProfile) return;
    if (profilePickerQ.trim()) return;
    setProfilePickerQ(selectedProfile.name || "");
  }, [selectedProfile?.id]);

  const profileSearchMatches = useMemo(() => {
    const q = profilePickerQ.trim().toLowerCase();
    if (!q) return [] as DeliveryProfile[];
    return profiles
      .filter((p) => {
        const name = String(p.name || "").toLowerCase();
        const protocol = String(p.protocol || "").toLowerCase();
        return name.includes(q) || protocol.includes(q);
      })
      .sort((a, b) => {
        const aStarts = String(a.name || "").toLowerCase().startsWith(q) ? 1 : 0;
        const bStarts = String(b.name || "").toLowerCase().startsWith(q) ? 1 : 0;
        if (aStarts !== bStarts) return bStarts - aStarts;
        return String(a.name || "").localeCompare(String(b.name || ""));
      })
      .slice(0, 5);
  }, [profiles, profilePickerQ]);

  function renderSetupStepper() {
    return (
      <div style={{ width: "100%", minWidth: 0, overflow: "hidden" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "nowrap", width: "100%", minWidth: 0 }}>
          {paneOrder.map((pane, idx) => {
            const active = activePane === pane;
            const enabled = pane === "profiles" || !!selectedDestinationId || (pane === "destinations" && !!profiles.length);
            return (
              <div key={pane} style={{ display: "flex", alignItems: "center", gap: 8, flex: "1 1 0", minWidth: 0 }}>
                <button
                  type="button"
                  onClick={() => enabled && setActivePane(pane)}
                  disabled={!enabled}
                  title={paneSummary(pane)}
                  style={{
                    display: "inline-flex",
                    alignItems: "center",
                    gap: 8,
                    padding: "10px 10px",
                    borderRadius: 999,
                    background: "white",
                    border: active ? "2px solid #ff4fa1" : "1px solid rgba(0,0,0,0.10)",
                    boxShadow: active ? "0 6px 16px rgba(255,79,161,0.15)" : undefined,
                    width: "100%",
                    minWidth: 0,
                    justifyContent: "flex-start",
                    boxSizing: "border-box",
                    opacity: enabled ? 1 : 0.55,
                    cursor: enabled ? "pointer" : "not-allowed",
                  }}
                >
                  <span
                    style={{
                      width: 10,
                      height: 10,
                      borderRadius: 999,
                      background:
                        pane === "profiles"
                          ? selectedProfileId
                            ? "#22c55e"
                            : "#94a3b8"
                          : pane === "destinations"
                            ? selectedDestinationId
                              ? "#22c55e"
                              : "#94a3b8"
                            : selectedDestinationId && selectedProfileId
                              ? "#22c55e"
                              : "#94a3b8",
                      boxShadow:
                        (pane === "profiles" && selectedProfileId) ||
                        (pane === "destinations" && selectedDestinationId) ||
                        (pane === "channels" && selectedDestinationId && selectedProfileId)
                          ? "0 0 0 3px rgba(34,197,94,0.15)"
                          : undefined,
                      flex: "0 0 auto",
                    }}
                  />
                  <span style={{ fontSize: 12, fontWeight: 900, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", minWidth: 0 }}>
                    {paneLabel(pane)}
                  </span>
                  <span style={{ marginLeft: "auto", fontSize: 11, opacity: 0.7, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", minWidth: 0 }}>
                    {paneSummary(pane)}
                  </span>
                </button>
                {idx < paneOrder.length - 1 ? <span style={{ opacity: 0.42, fontWeight: 900, flex: "0 0 auto" }}>→</span> : null}
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  function renderActivePanePanel() {
    if (activePane === "profiles") return renderProfilesPanel();
    if (activePane === "destinations") return renderDestinationsPanel();
    return renderChannelsPanel();
  }

  function goPrevPane() {
    const idx = paneOrder.indexOf(activePane);
    if (idx > 0) setActivePane(paneOrder[idx - 1]);
  }

  function goNextPane() {
    const idx = paneOrder.indexOf(activePane);
    if (idx < paneOrder.length - 1) setActivePane(paneOrder[idx + 1]);
  }

  function canGoNextPane() {
    if (activePane === "profiles") return true;
    if (activePane === "destinations") return !!selectedDestinationId;
    return false;
  }

  function renderDestinationsPanel() {
    return (
      <div className="card card--soft" style={{ minWidth: 0, minHeight: 620, display: "grid", gap: 10, alignContent: "start", gridAutoRows: "max-content" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12, flexWrap: "wrap" }}>
          <div style={{ display: "grid", gap: 6 }}>
            <div style={{ fontWeight: 800, fontSize: 18 }}>Destinations</div>
            <div style={{ fontSize: 12, opacity: 0.75 }}>Choose the destination you want to work with in this flow.</div>
          </div>
          <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
            <button disabled={busy} onClick={goToDestinationCreate}>+ New</button>
            <button disabled={!selectedDestinationId || busy} onClick={() => goToDestinationEdit(selectedDestinationId)}>Edit</button>
            <div style={{ fontSize: 12, opacity: 0.7 }}>{filteredDestinations.length}</div>
          </div>
        </div>

        <div style={compactSearchWrapStyle}>
          <input value={destQ} onChange={(e) => setDestQ(e.target.value)} placeholder="Search destinations…" style={compactSearchInputStyle} />
        </div>

        <div style={{ maxHeight: 300, overflow: "auto", border: "1px solid #eee", borderRadius: 12 }}>
          {filteredDestinations.length ? filteredDestinations.map((d) => {
            const selected = d.id === selectedDestinationId;
            return (
              <button
                key={d.id}
                type="button"
                onClick={() => setSelectedDestination(d.id)}
                style={{ width: "100%", textAlign: "left", border: "0", borderBottom: "1px solid #f1f5f9", borderRadius: 0, background: selected ? "rgba(56,216,20,0.15)" : "white", padding: "10px 12px", display: "grid", gap: 2 }}
              >
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 10 }}>
                  <div style={{ fontWeight: 700 }}>{d.name}</div>
                  {d.status ? <StatusPill status={String(d.status)} /> : null}
                </div>
                <div style={{ fontSize: 12, opacity: 0.7 }}>{d.category || "—"}</div>
              </button>
            );
          }) : <div style={{ padding: 12, opacity: 0.7 }}>No destinations.</div>}
        </div>
      </div>
    );
  }

  function renderProfilesPanel() {
    return (
      <div className="card card--soft" style={{ minWidth: 0, minHeight: 620, display: "grid", gap: 10, alignContent: "start", gridAutoRows: "max-content" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12, flexWrap: "wrap" }}>
          <div style={{ display: "grid", gap: 6 }}>
            <div style={{ fontWeight: 800, fontSize: 18 }}>Profiles</div>
            <div style={{ fontSize: 12, opacity: 0.75 }}>Choose the delivery profile you want to work with in this flow.</div>
          </div>
          <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
            <label style={{ display: "flex", gap: 8, alignItems: "center", fontSize: 12, fontWeight: 600 }}>
              <input type="checkbox" checked={showAllProfiles} onChange={(e) => setShowAllProfiles(e.target.checked)} />
              Show all
            </label>
            <button disabled={busy} onClick={openCreateProfile}>+ New</button>
            <button disabled={!selectedProfileId || busy} onClick={() => selectedProfile && openEditProfile(selectedProfile)}>Edit</button>
            <div style={{ fontSize: 12, opacity: 0.7 }}>{profilesForDestination.length}</div>
          </div>
        </div>

        <div style={compactSearchWrapStyle}>
          <input
            value={profileQ}
            onChange={(e) => setProfileQ(e.target.value)}
            placeholder="Search profiles (name/protocol)…"
            style={compactSearchInputStyle}
          />
        </div>

        <div style={{ maxHeight: 520, overflow: "auto", border: "1px solid #eee", borderRadius: 12 }}>
          {profilesForDestination.length ? (
            profilesForDestination.map((p) => {
              const selected = p.id === selectedProfileId;
              const u = usageByProfile.get(p.id);
              const usageText = u
                ? `Used ${u.total}`
                : selectedDestinationId
                  ? "Unused"
                  : "Ready";
              const serverBadge = profileServerBadge(p.lastStatus || p.status);
              return (
                <div
                  key={p.id}
                  style={{
                    display: "grid",
                    gridTemplateColumns: "minmax(0, 1fr) auto",
                    alignItems: "stretch",
                    borderTop: "1px solid #f1f5f9",
                  }}
                >
                  <button
                    type="button"
                    onClick={() => setSelectedProfile(p.id)}
                    style={{
                      width: "100%",
                      textAlign: "left",
                      border: 0,
                      borderRadius: 0,
                      background: selected ? "rgba(56,216,20,0.15)" : "white",
                      padding: "10px 12px",
                      display: "grid",
                      gap: 4,
                    }}
                  >
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 10 }}>
                      <div style={{ fontWeight: 700, minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{p.name}</div>
                      <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap", justifyContent: "flex-end" }}>
                        <span
                          style={{
                            fontSize: 11,
                            fontWeight: 700,
                            padding: "4px 8px",
                            borderRadius: 999,
                            background: "rgba(15, 23, 42, 0.05)",
                            whiteSpace: "nowrap",
                          }}
                        >
                          {String(p.protocol)}
                        </span>
                        <span
                          style={{
                            fontSize: 11,
                            fontWeight: 700,
                            padding: "4px 8px",
                            borderRadius: 999,
                            background: workerRouteFromConfig(p.config) === "STATIC_VM" ? "rgba(16, 185, 129, 0.14)" : "rgba(99, 102, 241, 0.12)",
                            color: workerRouteFromConfig(p.config) === "STATIC_VM" ? "#065f46" : "#4338ca",
                            whiteSpace: "nowrap",
                          }}
                          title={workerRouteHelp(workerRouteFromConfig(p.config))}
                        >
                          {workerRouteLabel(workerRouteFromConfig(p.config))}
                        </span>
                        <span style={serverBadge.style}>{serverBadge.label}</span>
                      </div>
                    </div>
                    <div style={{ fontSize: 12, opacity: 0.7 }}>{usageText}</div>
                  </button>
                  <div style={{ display: "flex", alignItems: "center", justifyContent: "center", padding: "10px 12px", background: selected ? "rgba(56,216,20,0.08)" : "white" }}>
                    <button type="button" onClick={() => openEditProfile(p)} disabled={busy} style={{ padding: "6px 10px", borderRadius: 999 }}>
                      Edit
                    </button>
                  </div>
                </div>
              );
            })
          ) : (
            <div style={{ padding: 12, opacity: 0.7 }}>No profiles found.</div>
          )}
        </div>

      </div>
    );
  }


  function renderChannelsPanel() {
    return (
      <div className="card card--soft" style={{ minWidth: 0, minHeight: 620, display: "grid", gap: 10, alignContent: "start", gridAutoRows: "max-content" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12, flexWrap: "wrap" }}>
          <div style={{ display: "grid", gap: 6 }}>
            <div style={{ fontWeight: 800, fontSize: 18 }}>Channels</div>
            <div style={{ fontSize: 12, opacity: 0.75 }}>
              {selectedDestination ? <>Choose a profile here and assign it to channels of <b>{selectedDestination.name}</b>.</> : <>Choose a destination first, then pick a profile here for channel mapping.</>}
            </div>
            {destinationDefaultProfile ? <div style={{ fontSize: 12, opacity: 0.8 }}>Destination fallback profile: <b>{destinationDefaultProfile.name}</b></div> : null}
          </div>

          <div style={{ display: "grid", gap: 8, justifyItems: "end" }}>
            <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap", justifyContent: "flex-end" }}>
              <button disabled={!selectedDestinationId || busy} onClick={goToChannelCreate}>+ New</button>
              <label style={{ display: "flex", gap: 8, alignItems: "center", fontSize: 12, fontWeight: 600 }}>
                <input type="checkbox" checked={mappedOnly} onChange={(e) => setMappedOnly(e.target.checked)} />
                Mapped only
              </label>
            </div>
            <div style={{ width: 320, maxWidth: "100%", display: "grid", gap: 8 }}>
              <input value={profilePickerQ} onChange={(e) => { const next = e.target.value; setProfilePickerQ(next); if (!next.trim()) setSelectedProfile(""); }} placeholder="Search profile…" style={{ width: "100%", boxSizing: "border-box", padding: "10px 14px", borderRadius: 12 }} />
              {selectedProfile ? (
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8, padding: "8px 10px", borderRadius: 12, border: "1px solid rgba(74, 222, 128, 0.22)", background: "linear-gradient(180deg, rgba(240, 253, 244, 0.98) 0%, rgba(220, 252, 231, 0.96) 100%)" }}>
                  <div style={{ display: "flex", gap: 8, alignItems: "center", minWidth: 0, flexWrap: "wrap" }}>
                    <span style={{ fontSize: 11, fontWeight: 800, padding: "4px 8px", borderRadius: 999, background: "rgba(22, 163, 74, 0.12)", color: "#166534" }}>Selected</span>
                    <span style={{ fontWeight: 700 }}>{selectedProfile.name}</span>
                    <span style={{ fontSize: 11, opacity: 0.7 }}>{String(selectedProfile.protocol || "")}</span>
                  </div>
                  <button type="button" onClick={() => { setSelectedProfile(""); setProfilePickerQ(""); }} style={{ padding: "6px 10px", borderRadius: 999 }}>Clear</button>
                </div>
              ) : null}
              {profilePickerQ.trim() ? (
                <div style={{ border: "1px solid #e5e7eb", borderRadius: 12, overflow: "hidden", background: "#fff" }}>
                  {profileSearchMatches.length ? profileSearchMatches.map((p) => (
                    <button key={p.id} type="button" onClick={() => { setSelectedProfile(p.id); setProfilePickerQ(p.name || ""); }} style={{ width: "100%", border: 0, borderTop: "1px solid #f1f5f9", background: selectedProfileId === p.id ? "rgba(56,216,20,0.12)" : "#fff", textAlign: "left", padding: "10px 12px", display: "grid", gap: 2 }}>
                      <span style={{ fontWeight: 700 }}>{p.name}</span>
                      <span style={{ fontSize: 11, opacity: 0.72 }}>{String(p.protocol || "")}</span>
                    </button>
                  )) : <div style={{ padding: "10px 12px", fontSize: 12, opacity: 0.7 }}>No profile matches.</div>}
                </div>
              ) : null}
            </div>
          </div>
        </div>

        <div style={{ display: "grid", gap: 8 }}>
          <div style={compactSearchWrapStyle}>
            <input value={channelQ} onChange={(e) => setChannelQ(e.target.value)} placeholder="Search channels…" style={compactSearchInputStyle} />
          </div>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
            <div style={{ fontSize: 12, opacity: 0.75 }}>Selected: <b>{selectedCount}</b></div>
            <button disabled={!selectedProfileId || !selectedCount || busy} onClick={() => batchPatchChannels("main")}>Set as Main</button>
            <button disabled={!selectedProfileId || !selectedCount || busy} onClick={() => batchPatchChannels("backup")}>Set as Backup</button>
            <button disabled={!selectedProfileId || !selectedCount || busy} onClick={() => batchPatchChannels("clearMain")}>Clear Main</button>
            <button disabled={!selectedProfileId || !selectedCount || busy} onClick={() => batchPatchChannels("clearBackup")}>Clear Backup</button>
          </div>
        </div>

        <div style={{ maxHeight: 520, overflow: "auto", border: "1px solid #eee", borderRadius: 12 }}>
          {visibleChannels.length ? (
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead>
                <tr style={{ background: "#f8fafc" }}>
                  <th style={{ textAlign: "left", padding: "10px 12px", width: 44 }}><input type="checkbox" checked={visibleChannels.length > 0 && visibleChannels.every((c) => selectedChannelIds[c.id])} onChange={(e) => selectAllVisible(e.target.checked)} /></th>
                  <th style={{ textAlign: "left", padding: "10px 12px" }}>Channel</th>
                  <th style={{ textAlign: "left", padding: "10px 12px" }}>Main</th>
                  <th style={{ textAlign: "left", padding: "10px 12px" }}>Backup</th>
                  <th style={{ textAlign: "left", padding: "10px 12px" }}>Preset</th>
                  <th style={{ textAlign: "left", padding: "10px 12px" }}>Transcode</th>
                  <th style={{ textAlign: "left", padding: "10px 12px", width: 90 }}>Actions</th>
                </tr>
              </thead>
              <tbody>
                {visibleChannels.map((c) => {
                  const resolvedMain = resolvedMainProfileIdForChannel(c);
                  const resolvedBackup = resolvedBackupProfileIdForChannel(c);
                  const isMain = selectedProfileId && resolvedMain === selectedProfileId;
                  const isBackup = selectedProfileId && resolvedBackup === selectedProfileId;
                  const inheritedMain = !c.mainProfileId && !!destinationDefaultProfileId;
                  const effectivePresetKey = c.defaultPresetKey || destinationDefaultPresetKey || "";
                  const inheritedPreset = !c.defaultPresetKey && !!destinationDefaultPresetKey;
                  const effectiveTranscodeOnCommit = c.defaultPresetKey ? Boolean(c.transcodeOnCommit) : Boolean(destinationTranscodeOnCommit && destinationDefaultPresetKey);
                  return (
                    <tr key={c.id} style={{ borderTop: "1px solid #f1f5f9" }}>
                      <td style={{ padding: "10px 12px" }}><input type="checkbox" checked={Boolean(selectedChannelIds[c.id])} onChange={(e) => toggleChannel(c.id, e.target.checked)} /></td>
                      <td style={{ padding: "10px 12px", fontWeight: 700 }}>{c.name}</td>
                      <td style={{ padding: "10px 12px" }}>
                        {isMain ? <span style={{ padding: "4px 8px", borderRadius: 999, background: inheritedMain ? "rgba(59, 130, 246, 0.14)" : "rgba(56,216,20,0.18)", fontWeight: 700 }}>{inheritedMain ? "Inherited" : "This"}</span> : inheritedMain && !selectedProfileId ? <span style={{ padding: "4px 8px", borderRadius: 999, background: "rgba(59, 130, 246, 0.14)", fontWeight: 700 }}>Destination default</span> : "—"}
                      </td>
                      <td style={{ padding: "10px 12px" }}>{isBackup ? <span style={{ padding: "4px 8px", borderRadius: 999, background: "rgba(56,216,20,0.18)", fontWeight: 700 }}>This</span> : "—"}</td>
                      <td style={{ padding: "10px 12px" }}>
                        {effectivePresetKey ? (
                          <div style={{ display: "inline-flex", alignItems: "center", gap: 6, maxWidth: 320, borderRadius: 999, padding: "6px 10px", background: inheritedPreset ? "#eff6ff" : "#ecfdf3", border: inheritedPreset ? "1px solid #bfdbfe" : "1px solid #bbf7d0", color: inheritedPreset ? "#1d4ed8" : "#166534", fontSize: 12, fontWeight: 700 }} title={presetLabel(effectivePresetKey)}>
                            <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{presetDisplayName(presetLibrary.find((x) => x.key === effectivePresetKey) || { key: effectivePresetKey })}</span>
                            {inheritedPreset ? <span style={{ fontSize: 11, opacity: 0.8 }}>Inherited</span> : null}
                          </div>
                        ) : (
                          <span style={{ color: "#94a3b8" }}>—</span>
                        )}
                      </td>
                      <td style={{ padding: "10px 12px" }}>
                        {effectivePresetKey ? (
                          <span style={{ display: "inline-flex", alignItems: "center", borderRadius: 999, padding: "4px 10px", fontSize: 12, fontWeight: 700, background: effectiveTranscodeOnCommit ? "#ecfdf5" : "#f8fafc", border: `1px solid ${effectiveTranscodeOnCommit ? "#bbf7d0" : "#e2e8f0"}`, color: effectiveTranscodeOnCommit ? "#166534" : "#64748b" }}>
                            {effectiveTranscodeOnCommit ? "After commit" : "Manual / on send"}
                          </span>
                        ) : (
                          <span style={{ color: "#94a3b8" }}>—</span>
                        )}
                      </td>
                      <td style={{ padding: "10px 12px" }}><button disabled={busy} onClick={() => goToChannelEdit(c.id)}>Edit</button></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          ) : (
            <div style={{ padding: 12, opacity: 0.7 }}>{selectedDestinationId ? <>No channels found{mappedOnly && selectedProfileId ? " for this profile" : ""}.</> : <>Select a destination.</>}</div>
          )}
        </div>

      </div>
    );
  }


  return (
    <div className="masters-wrap" style={{ display: "grid", gap: 12 }}>
      <div className="card card--soft" style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, flexWrap: "wrap" }}>
        <h3 style={{ margin: 0 }}>Delivery Setup</h3>
        <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap", justifyContent: "flex-end" }}>
          <button disabled={busy} onClick={() => loadBase().then(() => { if (selectedDestinationId) return loadChannels(selectedDestinationId); })}>Refresh</button>
        </div>
      </div>

      {err ? (
        <div className="card" style={{ borderColor: "#fecaca", background: "#fff1f2", color: "#991b1b" }}>
          {err}
        </div>
      ) : null}

      {banner ? (
        <div className="card" style={{ borderColor: "#bbf7d0", background: "#ecfdf5", color: "#065f46" }}>
          {banner}
        </div>
      ) : null}

      <div style={{ display: "grid", gap: 12, minWidth: 0 }}>
        <div className="card card--soft" style={{ display: "grid", gap: 10, minWidth: 0 }}>
          <div style={{ display: "grid", gap: 4 }}>
            <div style={{ fontWeight: 800, fontSize: 16 }}>Delivery Setup Flow</div>
          </div>
          {renderSetupStepper()}
        </div>

        {renderActivePanePanel()}

        <div className="card card--soft" style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, flexWrap: "wrap" }}>
          <div style={{ fontSize: 12, opacity: 0.72 }}>
            {activePane === "profiles"
              ? "Choose the delivery profile you want to work with."
              : activePane === "destinations"
                ? "Choose the destination you want to work with."
                : "Map the selected profile to channels for the selected destination."}
          </div>
          <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
            <button type="button" onClick={goPrevPane} disabled={paneOrder.indexOf(activePane) === 0}>Back</button>
            <button type="button" className="btn btn--primary" onClick={goNextPane} disabled={!canGoNextPane()}>Next</button>
          </div>
        </div>
      </div>

      {profileModal ? (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(15, 23, 42, 0.45)",
            display: "grid",
            placeItems: "center",
            padding: 16,
            zIndex: 60,
          }}
          onClick={closeProfileModal}
        >
          <div
            className="card"
            style={{ width: "min(1040px, 94vw)", maxHeight: "88vh", overflow: "auto", background: "#ffffff", borderColor: "#e5e7eb", boxShadow: "0 24px 80px rgba(15, 23, 42, 0.22)" }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="row" style={{ justifyContent: "space-between", alignItems: "center", gap: 12 }}>
              <div>
                <h3 style={{ margin: 0 }}>{profileModal.mode === "create" ? "Add Delivery Profile" : "Edit Delivery Profile"}</h3>
              </div>
              <button className="btn btn--ghost" onClick={closeProfileModal} disabled={busy || testingProfile}>Close</button>
            </div>

            <div style={{ display: "grid", gap: 12, marginTop: 12 }}>
              <div className="card" style={{ background: "#ffffff", borderColor: "#e5e7eb", display: "grid", gap: 12 }}>
                <div style={{ fontWeight: 800 }}>Basic details</div>
                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
                    gap: 10,
                    alignItems: "end",
                  }}
                >
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Name</div>
                    <input placeholder="Profile name" value={profileModal.name} onChange={(e) => setProfileModal({ ...profileModal, name: e.target.value })} />
                  </div>
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Staging Path</div>
                    <input placeholder="/staging" value={profileModal.stagingPath} onChange={(e) => setProfileModal({ ...profileModal, stagingPath: e.target.value })} />
                  </div>
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Final Path</div>
                    <input placeholder="/final" value={profileModal.finalPath} onChange={(e) => setProfileModal({ ...profileModal, finalPath: e.target.value })} />
                  </div>
                  {profileModal.mode === "edit" ? (
                    <div className="card" style={{ background: "#f8fafc", borderColor: "#e2e8f0", padding: 12 }}>
                      <div style={{ fontSize: 11, color: "#667085", marginBottom: 6 }}>Server status</div>
                      <StatusPill status={profiles.find((p) => p.id === profileModal.id)?.lastStatus || "UNKNOWN"} title={profiles.find((p) => p.id === profileModal.id)?.lastError || ""} />
                      <div style={{ fontSize: 11, color: "#667085", marginTop: 8 }}>Last checked: {fmtDt(profiles.find((p) => p.id === profileModal.id)?.lastCheckedAt)}</div>
                    </div>
                  ) : null}
                </div>
              </div>

              <div className="card" style={{ background: "#ffffff", borderColor: "#e5e7eb", display: "grid", gap: 12 }}>
                <div style={{ fontWeight: 800 }}>HD / SD path overrides</div>
                <div style={{ fontSize: 12, color: "#475467" }}>
                  Optional. When a destination is marked as HD or SD, these paths override the default staging/final paths.
                </div>
                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
                    gap: 10,
                    alignItems: "end",
                  }}
                >
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>SD Staging Path</div>
                    <input placeholder="/sd/staging" value={profileModal.sdStagingPath} onChange={(e) => setProfileModal({ ...profileModal, sdStagingPath: e.target.value })} />
                  </div>
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>SD Final Path</div>
                    <input placeholder="/sd/final" value={profileModal.sdFinalPath} onChange={(e) => setProfileModal({ ...profileModal, sdFinalPath: e.target.value })} />
                  </div>
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>HD Staging Path</div>
                    <input placeholder="/hd/staging" value={profileModal.hdStagingPath} onChange={(e) => setProfileModal({ ...profileModal, hdStagingPath: e.target.value })} />
                  </div>
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>HD Final Path</div>
                    <input placeholder="/hd/final" value={profileModal.hdFinalPath} onChange={(e) => setProfileModal({ ...profileModal, hdFinalPath: e.target.value })} />
                  </div>
                </div>
              </div>

              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: "minmax(210px, 240px) minmax(0, 1fr)",
                  gap: 12,
                  alignItems: "start",
                }}
              >
                <div className="card" style={{ background: "#ffffff", borderColor: "#e5e7eb", display: "grid", gap: 8 }}>
                  {[
                    { key: "protocol", label: "Protocol", note: protocolLabel(profileModal.protocol) },
                    { key: "route", label: "Delivery route", note: workerRouteLabel(workerRouteFromConfig(safeJsonParse(profileModal.configText, {}))) },
                    { key: "status", label: "Status", note: profileModal.status === "ACTIVE" ? "Active" : "Inactive" },
                    { key: "connection", label: "Connection details", note: protocolLabel(profileModal.protocol) },
                    { key: "check", label: "Check connection", note: profileTestResult?.status || "Not checked" },
                    { key: "advanced", label: "Advanced config", note: "JSON" },
                  ].map((item) => {
                    const active = profileModal.section === item.key;
                    return (
                      <button
                        key={item.key}
                        type="button"
                        className="btn"
                        style={wizardNavButtonStyle(active)}
                        onClick={() => setProfileModal({ ...profileModal, section: item.key as CreateProfileSection })}
                        disabled={busy || testingProfile}
                      >
                        <div style={{ fontSize: 14 }}>{item.label}</div>
                        <div style={{ fontSize: 12, opacity: 0.78, marginTop: 4 }}>{item.note}</div>
                      </button>
                    );
                  })}
                </div>

                <div className="card" style={{ background: "#ffffff", borderColor: "#e5e7eb", display: "grid", gap: 12, alignContent: "start" }}>
                  <div>
                    <div style={{ fontSize: 18, fontWeight: 800 }}>{profileSectionTitle(profileModal.section)}</div>
                    <div style={{ fontSize: 13, color: "#475467", marginTop: 4 }}>
                      {profileModal.section === "route" && workerRouteHelp(workerRouteFromConfig(safeJsonParse(profileModal.configText, {})))}
                      {profileModal.section === "advanced" && "Optional. Use this only for extra protocol-specific settings that are not exposed in the normal form."}
                    </div>
                  </div>

                  {profileModal.section === "protocol" && (
                    <div style={compactSectionBodyStyle(profileModal.section)}>
                      <ProtocolButtons
                        value={profileModal.protocol}
                        onChange={(next) => {
                          const nextRoute = workerRouteFromConfig(safeJsonParse(profileModal.configText, {}));
                          const split = splitProfileConfig(next, withWorkerRoute(defaultsFor(next), nextRoute));
                          setProfileModal({
                            ...profileModal,
                            protocol: next,
                            configText: pretty(withWorkerRoute(defaultsFor(next), nextRoute)),
                            simpleConfig: split.simpleConfig,
                          });
                          setProfileTestResult(null);
                        }}
                        disabled={busy || testingProfile}
                      />
                    </div>
                  )}

                  {profileModal.section === "route" && (
                    <div style={compactSectionBodyStyle(profileModal.section)}>
                      <WorkerRouteButtons
                        value={workerRouteFromConfig(safeJsonParse(profileModal.configText, {}))}
                        onChange={setProfileModalWorkerRoute}
                        disabled={busy || testingProfile}
                      />
                      <div className="card" style={{ background: "#f8fafc", borderColor: "#e2e8f0" }}>
                        <div style={{ fontSize: 13, color: "#334155" }}>{workerRouteHelp(workerRouteFromConfig(safeJsonParse(profileModal.configText, {})))}</div>
                      </div>
                    </div>
                  )}

                  {profileModal.section === "status" && (
                    <div style={compactSectionBodyStyle(profileModal.section)}>
                      <StatusButtons value={profileModal.status} onChange={(nextStatus) => setProfileModal({ ...profileModal, status: nextStatus })} disabled={busy || testingProfile} />
                    </div>
                  )}

                  {profileModal.section === "connection" && (
                    <div style={compactSectionBodyStyle(profileModal.section)}>
                      <ConfigQuickFields protocol={profileModal.protocol} configText={profileModal.configText} setConfigText={(next) => setProfileModal({ ...profileModal, configText: next })} />
                      {profileModal.mode === "edit" && profiles.find((p) => p.id === profileModal.id)?.lastError ? (
                        <div className="card" style={{ borderColor: "#f5a", background: "#fff5fa" }}>
                          <div style={{ fontWeight: 800, marginBottom: 6 }}>Last Error</div>
                          <div style={{ whiteSpace: "pre-wrap" }}>{profiles.find((p) => p.id === profileModal.id)?.lastError}</div>
                        </div>
                      ) : null}
                    </div>
                  )}

                  {profileModal.section === "check" && (
                    <div style={compactSectionBodyStyle(profileModal.section)}>
                      <div className="card" style={{ background: "#f8fafc", borderColor: "#e2e8f0" }}>
                        <div style={{ fontSize: 13, color: "#334155" }}>
                          Selected protocol: <strong>{protocolLabel(profileModal.protocol)}</strong> · Route: <strong>{workerRouteLabel(workerRouteFromConfig(safeJsonParse(profileModal.configText, {})))}</strong>
                        </div>
                      </div>
                      <div className="row" style={{ gap: 8, flexWrap: "wrap" }}>
                        <button type="button" className="btn btn--ghost" onClick={testProfileConnection} disabled={busy || testingProfile}>
                          {testingProfile ? "Checking..." : "Test connection"}
                        </button>
                      </div>
                      <TestResultCard title="Connection check" result={profileTestResult} />
                    </div>
                  )}

                  {profileModal.section === "advanced" && (
                    <div style={compactSectionBodyStyle(profileModal.section)}>
                      <div className="row" style={{ justifyContent: "space-between", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
                        <div style={{ fontSize: 12, fontWeight: 700 }}>Advanced Config (JSON)</div>
                        <div className="row" style={{ gap: 8, flexWrap: "wrap" }}>
                          <button type="button" className="btn btn--ghost btn--sm" onClick={applyDefaultsInModal} disabled={busy || testingProfile} title="Load a starter config for the selected protocol">Use defaults</button>
                          <button type="button" className="btn btn--ghost btn--sm" onClick={prettifyModalConfig} disabled={busy || testingProfile} title="Format JSON">Prettify</button>
                          {profileModal.mode === "edit" ? (
                            <button
                              type="button"
                              className="btn btn--ghost btn--sm"
                              onClick={() => profileModal.id && deleteProfile(profileModal.id)}
                              disabled={busy || testingProfile}
                              style={{ color: "#b91c1c", borderColor: "rgba(185,28,28,0.20)" }}
                            >
                              Delete
                            </button>
                          ) : null}
                        </div>
                      </div>
                      <textarea
                        className="codearea"
                        style={{ width: "100%", minHeight: 220 }}
                        value={profileModal.configText}
                        onChange={(e) => setProfileModal({ ...profileModal, configText: e.target.value })}
                      />
                    </div>
                  )}
                </div>
              </div>

              {err && <div className="card" style={{ borderColor: "#f5a", background: "#fff5fa" }}>{err}</div>}

              <div className="row" style={{ justifyContent: "flex-end", gap: 8, flexWrap: "wrap" }}>
                <button className="btn btn--ghost" onClick={closeProfileModal} disabled={busy || testingProfile}>Cancel</button>
                <button className="btn btn--primary" onClick={saveProfileModal} disabled={busy || testingProfile || !profileModal.name.trim()}>
                  {busy ? "Saving..." : profileModal.mode === "create" ? "Create" : "Save"}
                </button>
              </div>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}

