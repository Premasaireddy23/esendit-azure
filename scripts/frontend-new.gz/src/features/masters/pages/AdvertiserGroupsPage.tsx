import { useEffect, useState } from "react";
import { getMe, hasAnyPerm, type MeResponse } from "../../../lib/me";
import {
  ADVERTISER_GROUPS_CREATE_PERMISSIONS,
  ADVERTISER_GROUPS_DELETE_PERMISSIONS,
  ADVERTISER_GROUPS_UPDATE_PERMISSIONS,
} from "../mastersPermissions";
import { MasterCrudPage } from "../MasterCrudPage";

export function AdvertiserGroupsPage() {
  const [me, setMe] = useState<MeResponse | null>(null);

  useEffect(() => {
    getMe().then(setMe).catch(() => setMe(null));
  }, []);

  return (
    <MasterCrudPage
      title="Advertiser Groups"
      path="/masters/advertiser-groups"
      canCreate={hasAnyPerm(me, [...ADVERTISER_GROUPS_CREATE_PERMISSIONS])}
      canUpdate={hasAnyPerm(me, [...ADVERTISER_GROUPS_UPDATE_PERMISSIONS])}
      canDelete={hasAnyPerm(me, [...ADVERTISER_GROUPS_DELETE_PERMISSIONS])}
      columns={[
        { key: "name", label: "Name" },
        { key: "status", label: "Status" },
        { key: "updatedAt", label: "Updated" },
      ]}
      fields={[{ name: "name", label: "Name", type: "text", required: true, placeholder: "e.g. Group A" }]}
      supportsInactive
      supportsEnableAndPermanentDelete
      enhancedCrudUi
      createTo="/masters/advertiser-groups/new"
      createLabel="Add"
    />
  );
}
