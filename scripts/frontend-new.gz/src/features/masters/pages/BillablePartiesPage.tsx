import { useEffect, useState } from "react";
import { MasterCrudPage, type ColumnDef, type FieldDef } from "../MasterCrudPage";
import { getMe, hasAnyPerm, type MeResponse } from "../../../lib/me";
import {
  BILLABLE_PARTIES_CREATE_PERMISSIONS,
  BILLABLE_PARTIES_DELETE_PERMISSIONS,
  BILLABLE_PARTIES_PAGE_PERMISSIONS,
  BILLABLE_PARTIES_UPDATE_PERMISSIONS,
} from "../mastersPermissions";

type BillablePartyRow = {
  id: string;
  name: string;
  code?: string | null;
  emails: string[];
  address?: string | null;
  gstNumber?: string | null;
  panNumber?: string | null;
  paymentTerms?: string | null;
  status: "ACTIVE" | "INACTIVE" | string;
  createdAt?: string;
  updatedAt?: string;
};

export function BillablePartiesPage() {
  const [me, setMe] = useState<MeResponse | null>(null);

  useEffect(() => {
    getMe().then(setMe).catch(() => setMe(null));
  }, []);

  // Billing masters should be finance-controlled
  const canRead = hasAnyPerm(me, [...BILLABLE_PARTIES_PAGE_PERMISSIONS]);
  const canCreate = hasAnyPerm(me, [...BILLABLE_PARTIES_CREATE_PERMISSIONS]);
  const canUpdate = hasAnyPerm(me, [...BILLABLE_PARTIES_UPDATE_PERMISSIONS]);
  const canDelete = hasAnyPerm(me, [...BILLABLE_PARTIES_DELETE_PERMISSIONS]);

  if (!canRead) {
    return (
      <div style={{ padding: 16 }}>
        <h2 style={{ margin: 0 }}>Billable Parties</h2>
        <div className="card" style={{ padding: 12, marginTop: 10 }}>
          You don’t have the Billable Parties view permission.
        </div>
      </div>
    );
  }

  const columns: ColumnDef<BillablePartyRow>[] = [
    { key: "name", label: "Name" },
    { key: "code", label: "Code" },
    { key: "gstNumber", label: "GST" },
    { key: "panNumber", label: "PAN" },
    { key: "address", label: "Address" },
    { key: "paymentTerms", label: "Payment Terms" },
    {
      key: "emails",
      label: "Finance Emails",
      render: (r) => (Array.isArray(r.emails) ? r.emails.join(", ") : ""),
    },
    { key: "status", label: "Status" },
  ];

  const fields: FieldDef[] = [
    { name: "name", label: "Billable Party Name", type: "text", required: true, placeholder: "e.g. Client Finance" },
    { name: "code", label: "Code", type: "text", placeholder: "e.g. FIN01" },
    { name: "gstNumber", label: "GST", type: "text", placeholder: "e.g. 27ABCDE1234F1Z5" },
    { name: "panNumber", label: "PAN", type: "text", placeholder: "e.g. ABCDE1234F" },
    { name: "address", label: "Address", type: "textarea", fullWidth: true, placeholder: "Full billing address" },
    { name: "paymentTerms", label: "Payment Terms", type: "textarea", fullWidth: true, placeholder: "e.g. 30 days from invoice" },
    {
      name: "emails",
      label: "Finance Emails",
      type: "emails",
      required: false,
      placeholder: "a@x.com, b@y.com",
      help: "Optional. Comma-separated list of finance recipients for Billing Master change notifications.",
    },
  ];

  return (
    <MasterCrudPage<BillablePartyRow>
      title="Billable Parties"
      path="/masters/billable-parties"
      columns={columns}
      fields={fields}
      canCreate={canCreate}
      canUpdate={canUpdate}
      canDelete={canDelete}
      defaultCreate={{ emails: "", gstNumber: "", panNumber: "", address: "", paymentTerms: "" }}
      supportsInactive={true}
    />
  );
}
