import { useEffect, useMemo, useState } from "react";
import type { CSSProperties } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { getMe, hasAnyPerm, type MeResponse } from "../../../lib/me";
import { AGENCIES_PAGE_PERMISSIONS, AGENCY_TEAMS_PAGE_PERMISSIONS } from "../mastersPermissions";
import { AgenciesPage } from "./AgenciesPage";
import { AgencyTeamsPage } from "./AgencyTeamsPage";

type View = "group" | "team";
type Type = "MEDIA" | "CREATIVE" | "POST_HOUSE" | "PRODUCTION_HOUSE" | "AUDIO" | "UPLOADER";

const TYPE_LABEL: Record<Type, string> = {
  MEDIA: "Media Agency",
  CREATIVE: "Creative Agency",
  POST_HOUSE: "Post House",
  PRODUCTION_HOUSE: "Production House",
  AUDIO: "Audio Agency",
  UPLOADER: "Uploader Agency",
};

const TYPE_ORDER: Type[] = ["MEDIA", "CREATIVE", "POST_HOUSE", "PRODUCTION_HOUSE", "AUDIO", "UPLOADER"];

const TAB_LABEL: Record<Type, { group: string; team: string }> = {
  MEDIA: { group: "Media Agencies", team: "Media Agency Teams" },
  CREATIVE: { group: "Creative Agencies", team: "Creative Agency Teams" },
  POST_HOUSE: { group: "Post Houses", team: "Post House Teams" },
  PRODUCTION_HOUSE: { group: "Production Houses", team: "Production House Teams" },
  AUDIO: { group: "Audio Agencies", team: "Audio Agency Teams" },
  UPLOADER: { group: "Uploader Agencies", team: "Uploader Agency Teams" },
};

const ACCENT = "#ff2d7a";
const DOT_ACTIVE = "#22c55e";
const DOT_INACTIVE = "#94a3b8";

function toggleBtnStyle(active: boolean): CSSProperties {
  return {
    padding: "7px 12px",
    borderRadius: 999,
    border: `2px solid ${active ? ACCENT : "rgba(0,0,0,0.12)"}`,
    background: "white",
    color: "inherit",
    fontWeight: active ? 800 : 700,
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: 8,
    boxShadow: active ? "0 0 0 2px rgba(255,45,122,0.12)" : "none",
    cursor: "pointer",
    whiteSpace: "nowrap",
  };
}

function toggleDotStyle(active: boolean): CSSProperties {
  return {
    width: 10,
    height: 10,
    borderRadius: 999,
    background: active ? DOT_ACTIVE : DOT_INACTIVE,
    flex: "0 0 auto",
  };
}

export function AgencyHubPage() {
  const nav = useNavigate();
  const [sp] = useSearchParams();
  const [me, setMe] = useState<MeResponse | null>(null);

  const type = ((sp.get("type") as Type) || "MEDIA") as Type;
  const requestedView = ((sp.get("view") as View) || "group") as View;

  useEffect(() => {
    getMe().then(setMe).catch(() => setMe(null));
  }, []);

  const canSeeGroups = hasAnyPerm(me, [...AGENCIES_PAGE_PERMISSIONS]);
  const canSeeTeams = hasAnyPerm(me, [...AGENCY_TEAMS_PAGE_PERMISSIONS]);
  const view: View = requestedView === "team"
    ? (canSeeTeams ? "team" : canSeeGroups ? "group" : "team")
    : (canSeeGroups ? "group" : canSeeTeams ? "team" : "group");

  const tabs = useMemo(() => TAB_LABEL[type] ?? TAB_LABEL.MEDIA, [type]);

  const setParam = (k: string, v: string) => {
    const p = new URLSearchParams(sp);
    p.set(k, v);

    // remove old q if it exists from previous versions
    p.delete("q");

    nav(`/masters/agency-hub?${p.toString()}`);
  };

  useEffect(() => {
    if ((requestedView !== view || !sp.get("view")) && (canSeeGroups || canSeeTeams)) {
      const p = new URLSearchParams(sp);
      p.set("view", view);
      if (!p.get("type")) p.set("type", type);
      p.delete("q");
      nav(`/masters/agency-hub?${p.toString()}`, { replace: true });
    }
  }, [canSeeGroups, canSeeTeams, nav, requestedView, sp, type, view]);

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div style={{ fontSize: 28, fontWeight: 900 }}>Agencies</div>

      <div style={{ display: "grid", gap: 8 }}>
        <div className="mastersFilters__label">Agency Type</div>
        <div style={{ display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center" }}>
          {TYPE_ORDER.map((agencyType) => {
            const active = type === agencyType;
            return (
              <button key={agencyType} onClick={() => setParam("type", agencyType)} type="button" style={toggleBtnStyle(active)}>
                <span style={toggleDotStyle(active)} />
                <span>{TYPE_LABEL[agencyType]}</span>
              </button>
            );
          })}
        </div>
      </div>

      <div style={{ display: "grid", gap: 10, justifyItems: "start" }}>
        <div style={{ fontSize: 20, fontWeight: 900 }}>{TYPE_LABEL[type]}</div>

        <div style={{ display: "flex", gap: 10, flexWrap: "wrap", alignItems: "center" }}>
          <button onClick={() => setParam("view", "group")} type="button" style={toggleBtnStyle(view === "group")}>
            <span style={toggleDotStyle(view === "group")} />
            <span>{tabs.group}</span>
          </button>
          <button onClick={() => setParam("view", "team")} type="button" style={toggleBtnStyle(view === "team")}>
            <span style={toggleDotStyle(view === "team")} />
            <span>{tabs.team}</span>
          </button>
        </div>
      </div>

      {view === "team" ? <AgencyTeamsPage /> : <AgenciesPage />}
    </div>
  );
}
