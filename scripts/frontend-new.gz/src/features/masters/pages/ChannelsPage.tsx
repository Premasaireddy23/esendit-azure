import { useEffect, useMemo, useRef, useState, type CSSProperties } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { api, type ApiError } from "../../../lib/api";
import { StatusPill } from "../../../ui/StatusPill";
import { presetDisplayName } from "../../presets/presetDisplay";

type Destination = { id: string; name: string; config?: any; downloadPresets?: any };
type DeliveryProfile = { id: string; name: string; protocol: string };
type Preset = { key: string; label?: string; ext?: string; mimeType?: string; args?: string[] };

type ApprovalStep = {
  order: number;
  teamName?: string | null;
  label?: string | null;
  approverEmails: string[];
  ccEmails?: string[];
};

type Channel = {
  id: string;
  name: string;
  destinationId?: string | null;

  mainProfileId?: string | null;
  backupProfileId?: string | null;

  notificationEmails?: string[];
  defaultPresetKey?: string | null;
  transcodeOnCommit?: boolean;
  alignment?: LogoPosition | null;
  approverMode?: "PARALLEL" | "SEQUENTIAL";
  approverEmails?: string[]; // legacy (flattened)
  approvalSteps?: ApprovalStep[];
  config?: any;

  serverStatus?: "UNKNOWN" | "ONLINE" | "OFFLINE";
  serverCheckedAt?: string | null;
  serverLatencyMs?: number | null;
  serverMessage?: string | null;

  mainDeliveryProfile?: { id: string; name: string; protocol: string; lastStatus?: string; lastCheckedAt?: string; lastError?: string };
  backupDeliveryProfile?: { id: string; name: string; protocol: string; lastStatus?: string; lastCheckedAt?: string; lastError?: string };
};

type StepDraft = {
  teamName: string;
  approverEmailsText: string;
  ccEmailsText: string;
};

type ApprovalModeUi = "PARALLEL" | "SEQUENTIAL" | "NONE";
type LogoPosition = "LHS" | "RHS" | "BLHS" | "BRHS";
const LOGO_POSITION_OPTIONS: LogoPosition[] = ["LHS", "RHS", "BLHS", "BRHS"];

function parseEmails(text: string): string[] {
  return text
    .split(",")
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean);
}

function emailsToText(v?: string[] | null) {
  return Array.isArray(v) ? v.join(", ") : "";
}

function destinationDefaultPresetKeyFromConfig(raw: any) {
  const cfg = raw && typeof raw === "object" ? raw : {};
  return String(cfg.defaultPresetKey || "").trim();
}

function parsePresets(downloadPresets: any): Preset[] {
  return Array.isArray(downloadPresets) ? (downloadPresets as Preset[]) : [];
}

function pickPresetsByKeys(all: Preset[], keys: any): Preset[] {
  const list = Array.isArray(keys) ? keys.map((k) => String(k || "").trim()).filter(Boolean) : [];
  if (!list.length) return [];
  const map = new Map(all.map((preset) => [String(preset.key || "").trim(), preset] as const));
  const seen = new Set<string>();
  const out: Preset[] = [];
  for (const key of list) {
    if (seen.has(key)) continue;
    const preset = map.get(key);
    if (!preset) continue;
    seen.add(key);
    out.push(preset);
  }
  return out;
}

function resolveDestinationPresetLibrary(destination: Destination | null | undefined, presetLibrary: Preset[]): Preset[] {
  if (!destination) return presetLibrary;
  const destinationPresets = parsePresets((destination as any)?.downloadPresets);
  if (destinationPresets.length) return destinationPresets;
  const filtered = pickPresetsByKeys(presetLibrary, (destination as any)?.config?.allowedPresetKeys);
  return filtered.length ? filtered : presetLibrary;
}

function safeJsonParse(text: string, fallback: any) {
  try {
    if (!text?.trim()) return fallback;
    return JSON.parse(text);
  } catch {
    return fallback;
  }
}

function pretty(v: any) {
  try {
    return JSON.stringify(v ?? {}, null, 2);
  } catch {
    return "{}";
  }
}

const CHANNEL_ICON_SRC = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAAAdgAAAHYBTnsmCAAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAAGHSURBVDiNnZC9S1tRGIef99wvw71eGk1FtEYLDS7FOpaCm5OWTq5dioMSQgdBbLs4tJNbBP+FjoKDIFSEUuhqwSypqNipUW8I+BXIzdvBZtGrrXngDIfze3/vw4EEypHO7FV1sHXfq+pgOdKZpGwiW6p2OdLizxMNSxUNypEWS6puUlZuKynVtCvVYKGpaOyyNBzK8X8btChMv60uzi1u35WR94V3K51B+CLwg+z1R0VtQZpA85b5z7ZRJud/bGfNw25OX23g9B5Q65iiu8difX+c1fPXDLjfyDzegUPgq3J2dorjOHhux0sDIE0FMRiJsUyMsRTLKGJAxQJjrvY5NxXMvT4lgXsXiAj9o8/JPBpo3+DBk6f05XIA2O0U/NpcReNG+wZ9YxMMjYy2b3AZ/aYeRdcL9N+TfyP+9y8cOx5YNvIhv7DWH/jP3FSQldQ5YgDjADYXmqIeewgNbKlDzNVpIawJwOyb/EWXH5pMb8+QZ7zLuyQqtUr6qHKym/bDnY/Ln0b+AHF2emmVw2IdAAAAAElFTkSuQmCC";

function ChannelIcon() {
  return <img src={CHANNEL_ICON_SRC} alt="" aria-hidden="true" style={{ width: 18, height: 18, objectFit: "contain", display: "block" }} />;
}

function WizardStepper(props: {
  steps: readonly string[];
  currentStep: number;
  canOpenStep: (index: number) => boolean;
  onStepClick: (index: number) => void;
}) {
  const { steps, currentStep, canOpenStep, onStepClick } = props;
  return (
    <div style={{ display: "grid", gap: 14 }}>
      <style>{`
        @keyframes wizardStepFade {
          from { opacity: 0; transform: translateX(10px); }
          to { opacity: 1; transform: translateX(0); }
        }
      `}</style>
      <div>
        <div style={{ display: "grid", gridTemplateColumns: `repeat(${steps.length}, minmax(0, 1fr))`, gap: 10, alignItems: "stretch" }}>
          {steps.map((step, index) => {
            const isActive = index === currentStep;
            const isDone = index < currentStep;
            const clickable = canOpenStep(index);
            return (
              <button
                key={step}
                type="button"
                onClick={() => clickable && onStepClick(index)}
                disabled={!clickable}
                style={{
                  width: "100%",
                  minWidth: 0,
                  minHeight: 72,
                  display: "flex",
                  alignItems: "center",
                  gap: 10,
                  padding: "12px 14px",
                  borderRadius: 16,
                  border: isActive ? "1px solid #2563eb" : isDone ? "1px solid #16a34a" : "1px solid rgba(15,23,42,0.10)",
                  background: isActive ? "rgba(37,99,235,0.08)" : isDone ? "rgba(22,163,74,0.08)" : "#fff",
                  color: "#0f172a",
                  cursor: clickable ? "pointer" : "not-allowed",
                  opacity: clickable ? 1 : 0.55,
                  transition: "all 180ms ease",
                  textAlign: "left",
                  position: "relative",
                  zIndex: 1,
                }}
              >
                <span
                  style={{
                    width: 30,
                    height: 30,
                    borderRadius: 999,
                    display: "inline-flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontSize: 12,
                    fontWeight: 900,
                    background: isActive ? "#2563eb" : isDone ? "#16a34a" : "rgba(15,23,42,0.08)",
                    color: isActive || isDone ? "#fff" : "#0f172a",
                    flex: "0 0 auto",
                  }}
                >
                  {index + 1}
                </span>
                <div style={{ minWidth: 0 }}>
                  <div style={{ fontSize: 11, fontWeight: 800, opacity: 0.7 }}>Step {index + 1}</div>
                  <div style={{ fontSize: 14, fontWeight: 900, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{step}</div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

const CHANNEL_CREATE_STEPS = ["General", "Location", "Presets"] as const;

function sanitizeFileNamePart(v: string) {
  const s = String(v || "")
    .trim()
    .replace(/[\/\\?%*:|"<>]/g, "_")
    .replace(/\s+/g, "_")
    .replace(/_+/g, "_")
    .slice(0, 120);
  return s || "metadata";
}

function xmlEscape(v: any) {
  return String(v ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&apos;");
}

function renderTemplateWithValues(tpl: string, values: Record<string, string>) {
  return String(tpl || "").replace(/\{([A-Z0-9_]+)\}/g, (_m, k) => {
    const v = values[k];
    return v == null ? "" : String(v);
  });
}

function computeXmlFileNamePreview(xmlCfg: any, values: Record<string, string>) {
  const base = values.BASENAME || "metadata";
  const fallback = `${sanitizeFileNamePart(base)}.xml`;

  const fileName = xmlCfg?.fileName && String(xmlCfg.fileName).trim() ? String(xmlCfg.fileName).trim() : "";
  if (fileName) return fileName.toLowerCase().endsWith(".xml") ? fileName : `${fileName}.xml`;

  const tpl = xmlCfg?.fileNameTemplate && String(xmlCfg.fileNameTemplate).trim() ? String(xmlCfg.fileNameTemplate).trim() : "";
  if (tpl) {
    const n = sanitizeFileNamePart(renderTemplateWithValues(tpl, values));
    return n.toLowerCase().endsWith(".xml") ? n : `${n}.xml`;
  }

  return fallback;
}

function buildXmlPreview(xmlCfg: any, values: Record<string, string>) {
  const cfg = xmlCfg && typeof xmlCfg === "object" ? xmlCfg : {};

  if (cfg?.template && String(cfg.template).trim()) {
    return renderTemplateWithValues(String(cfg.template), values);
  }

  const rootTag = String(cfg?.rootTag || "DeliveryMetadata");
  const ns = cfg?.namespace || cfg?.xmlns || null;
  const xmlns = ns ? ` xmlns="${xmlEscape(ns)}"` : "";

  const defaultKeys = ["TASK_ID", "ACCOUNT_ID", "PROJECT", "CREATIVE", "VALID", "FILENAME", "REMOTE_PATH", "BYTES", "GENERATED_AT"];
  const fields = Array.isArray(cfg?.fields) && cfg.fields.length ? cfg.fields : defaultKeys;

  const lines: string[] = [];
  for (const f of fields) {
    if (typeof f === "string") {
      const key = String(f || "").trim();
      if (!key) continue;
      lines.push(`  <${key}>${xmlEscape(values[key] ?? "")}</${key}>`);
      continue;
    }
    if (f && typeof f === "object") {
      const tag = String((f as any).tag || (f as any).key || "").trim();
      if (!tag) continue;
      const rawVal = (f as any).value ?? (f as any).template ?? "";
      const val = renderTemplateWithValues(String(rawVal), values);
      lines.push(`  <${tag}>${xmlEscape(val)}</${tag}>`);
    }
  }

  const inner = lines.join("\n");
  return `<?xml version="1.0" encoding="UTF-8"?>\n<${rootTag}${xmlns}>\n${inner}\n</${rootTag}>\n`;
}

function defaultXmlConfigJson() {
  return pretty({
    required: false,
    fileNameTemplate: "{BASENAME}.xml",
    rootTag: "DeliveryMetadata",
    fields: ["TASK_ID", "VALID", "FILENAME", "REMOTE_PATH", "BYTES", "GENERATED_AT"],
  });
}


function defaultApprovalStep(): StepDraft {
  return { teamName: "Step 1", approverEmailsText: "", ccEmailsText: "" };
}

function getApprovalModeUi(ch: Channel): ApprovalModeUi {
  const hasSteps = Array.isArray(ch.approvalSteps) && ch.approvalSteps.length > 0;
  const hasLegacyEmails = Array.isArray(ch.approverEmails) && ch.approverEmails.length > 0;
  if (!hasSteps && !hasLegacyEmails) return "NONE";
  return (ch.approverMode || "PARALLEL") as ApprovalModeUi;
}

function normalizeStepsForUi(ch: Channel): StepDraft[] {
  const steps = Array.isArray(ch.approvalSteps) && ch.approvalSteps.length ? ch.approvalSteps : null;
  if (steps) {
    return steps
      .slice()
      .sort((a, b) => a.order - b.order)
      .map((s) => ({
        teamName: String(s.label || s.teamName || `Step ${s.order}`),
        approverEmailsText: emailsToText(s.approverEmails),
        ccEmailsText: emailsToText(s.ccEmails || []),
      }));
  }
  // fallback to legacy list
  const legacy = Array.isArray(ch.approverEmails) ? ch.approverEmails : [];
  return [
    {
      teamName: "Approvals",
      approverEmailsText: emailsToText(legacy),
      ccEmailsText: "",
    },
  ];
}

function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: any }) {
  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.45)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: 16,
        zIndex: 50,
      }}
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div style={{ background: "white", borderRadius: 10, width: 880, maxWidth: "100%", padding: 16 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
          <div style={{ fontWeight: 700 }}>{title}</div>
          <button onClick={onClose}>Close</button>
        </div>
        {children}
      </div>
    </div>
  );
}


type PresetFilter = "ALL" | "MOV" | "MXF" | "MP4" | "HD" | "SD" | "AUDIO" | "SPECIAL";

const PRESET_FILTER_OPTIONS: Array<{ key: PresetFilter; label: string }> = [
  { key: "ALL", label: "All presets" },
  { key: "MOV", label: "MOV" },
  { key: "MXF", label: "MXF" },
  { key: "MP4", label: "MP4" },
  { key: "HD", label: "HD" },
  { key: "SD", label: "SD" },
  { key: "AUDIO", label: "Audio" },
  { key: "SPECIAL", label: "Special" },
];

function presetMeta(p: Preset) {
  const label = String(p.label || p.key || "").toUpperCase();
  const key = String(p.key || "").toUpperCase();
  const ext = String(p.ext || "").replace(/^\./, "").toUpperCase();
  const hay = `${label} ${key} ${ext}`;
  const isAudio = /\b(AAC|PCM|MP3|WAV|AUDIO|MONO|STEREO|TRACK)\b/.test(hay);
  const isHd = /\b(1920X1080|1280X720|HD|1080|720)\b/.test(hay);
  const isSd = /\b(720X576|SD|PAL|NTSC|576|480|4:3)\b/.test(hay);
  const isSpecial = /\b(IMX|XDCAM|DVCPRO|PRORES|SONY|BAT|LOUDNORM|TIMECODE)\b/.test(hay);
  return { label, key, ext, isAudio, isHd, isSd, isSpecial };
}

function presetMatchesFilter(p: Preset, filter: PresetFilter) {
  if (filter === "ALL") return true;
  const meta = presetMeta(p);
  if (filter === "MOV") return meta.ext === "MOV" || /\bMOV\b/.test(meta.label) || /\bMOV\b/.test(meta.key);
  if (filter === "MXF") return meta.ext === "MXF" || /\bMXF\b/.test(meta.label) || /\bMXF\b/.test(meta.key);
  if (filter === "MP4") return meta.ext === "MP4" || /\bMP4\b/.test(meta.label) || /\bMP4\b/.test(meta.key);
  if (filter === "HD") return meta.isHd;
  if (filter === "SD") return meta.isSd;
  if (filter === "AUDIO") return meta.isAudio;
  if (filter === "SPECIAL") return meta.isSpecial;
  return true;
}

function ChannelPresetSelectionModal(props: {
  open: boolean;
  title: string;
  subtitle: string;
  presets: Preset[];
  selectedKey: string;
  setSelectedKey: (next: string) => void;
  search: string;
  setSearch: (value: string) => void;
  filter: PresetFilter;
  setFilter: (value: PresetFilter) => void;
  onClose: () => void;
}) {
  const { open, title, subtitle, presets, selectedKey, setSelectedKey, search, setSearch, filter, setFilter, onClose } = props;
  const [selectedOnly, setSelectedOnly] = useState(false);

  const selectedPreset = useMemo(() => presets.find((p) => p.key === selectedKey) || null, [presets, selectedKey]);

  const visiblePresets = useMemo(() => {
    const term = search.trim().toLowerCase();
    return presets.filter((p) => {
      if (selectedOnly && selectedKey !== p.key) return false;
      if (!presetMatchesFilter(p, filter)) return false;
      if (!term) return true;
      const hay = `${p.label || ""} ${p.key || ""} ${p.ext || ""} ${p.mimeType || ""}`.toLowerCase();
      return hay.includes(term);
    });
  }, [presets, search, filter, selectedOnly, selectedKey]);

  useEffect(() => {
    if (!open) return;
    const onKey = (ev: KeyboardEvent) => {
      if (ev.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(15,23,42,0.45)",
        zIndex: 90,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: 20,
      }}
      onClick={onClose}
    >
      <div
        className="card"
        style={{
          width: "min(1220px, 100%)",
          height: "90vh",
          maxHeight: "90vh",
          overflow: "hidden",
          padding: 0,
          borderRadius: 20,
          boxShadow: "0 24px 60px rgba(15,23,42,0.24)",
          display: "flex",
          flexDirection: "column",
        }}
        onClick={(e) => e.stopPropagation()}
      >
        <div style={{ padding: "18px 20px", borderBottom: "1px solid rgba(15,23,42,0.08)", display: "flex", gap: 16, justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap" }}>
          <div>
            <div style={{ fontSize: 22, fontWeight: 800, color: "#0f172a" }}>{title}</div>
            <div style={{ fontSize: 13, color: "#475569", marginTop: 6, maxWidth: 760 }}>{subtitle}</div>
          </div>
          <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap", justifyContent: "flex-end" }}>
            <div style={{ borderRadius: 999, padding: "8px 12px", background: selectedPreset ? "#ecfdf3" : "#f8fafc", border: selectedPreset ? "1px solid #bbf7d0" : "1px solid rgba(15,23,42,0.08)", color: selectedPreset ? "#166534" : "#334155", fontSize: 12, fontWeight: 800 }}>
              {selectedPreset ? "1 preset selected" : "No default preset"}
            </div>
            <button type="button" className="btn btn--ghost" onClick={onClose}>Done</button>
          </div>
        </div>

        <div style={{ padding: 18, display: "grid", gridTemplateColumns: "220px minmax(0, 1fr) 320px", gap: 16, alignItems: "stretch", flex: 1, minHeight: 0, overflow: "hidden" }}>
          <div style={{ border: "1px solid rgba(15,23,42,0.08)", borderRadius: 16, background: "#f8fafc", padding: 14, overflow: "auto", minHeight: 0, height: "100%" }}>
            <div style={{ fontSize: 12, fontWeight: 800, textTransform: "uppercase", letterSpacing: 0.4, color: "#475569", marginBottom: 10 }}>Format groups</div>
            <div style={{ display: "grid", gap: 8 }}>
              {PRESET_FILTER_OPTIONS.map((opt) => {
                const active = opt.key === filter;
                return (
                  <button
                    key={opt.key}
                    type="button"
                    onClick={() => setFilter(opt.key)}
                    style={{
                      textAlign: "left",
                      borderRadius: 12,
                      padding: "10px 12px",
                      border: active ? "1px solid #22c55e" : "1px solid rgba(15,23,42,0.08)",
                      background: active ? "#ecfdf3" : "#fff",
                      color: active ? "#166534" : "#0f172a",
                      fontSize: 13,
                      fontWeight: 700,
                      cursor: "pointer",
                    }}
                  >
                    {opt.label}
                  </button>
                );
              })}
            </div>

            <div style={{ marginTop: 16, paddingTop: 14, borderTop: "1px solid rgba(15,23,42,0.08)" }}>
              <label style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13, fontWeight: 700, color: "#0f172a", cursor: "pointer" }}>
                <input type="checkbox" checked={selectedOnly} onChange={(e) => setSelectedOnly(e.target.checked)} />
                Show selected only
              </label>
            </div>
          </div>

          <div style={{ border: "1px solid rgba(15,23,42,0.08)", borderRadius: 16, background: "#fff", overflow: "hidden", minHeight: 0, display: "flex", flexDirection: "column" }}>
            <div style={{ padding: 14, borderBottom: "1px solid rgba(15,23,42,0.08)", display: "grid", gap: 10 }}>
              <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
                <input
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search by format, label, or preset key"
                  style={{ flex: "1 1 300px", minWidth: 220, padding: "11px 12px" }}
                />
                <button type="button" className="btn btn--ghost btn--sm" onClick={() => setSelectedKey(selectedKey || (visiblePresets[0]?.key || ""))} disabled={!visiblePresets.length || !!selectedKey}>
                  Select visible
                </button>
                <button type="button" className="btn btn--ghost btn--sm" onClick={() => setSearch("")} disabled={!search}>
                  Clear search
                </button>
              </div>
              <div style={{ fontSize: 12, color: "#64748b" }}>Showing {visiblePresets.length} preset{visiblePresets.length === 1 ? "" : "s"}. Use this picker only when this channel should auto-pick one preset by default.</div>
            </div>

            <div style={{ padding: 14, overflowY: "scroll", overflowX: "hidden", display: "grid", gap: 10, flex: 1, minHeight: 0 }}>
              {!visiblePresets.length ? (
                <div style={{ border: "1px dashed rgba(15,23,42,0.18)", borderRadius: 14, padding: 20, textAlign: "center", color: "#64748b", fontSize: 13 }}>
                  No presets match this search.
                </div>
              ) : (
                visiblePresets.map((p) => {
                  const meta = presetMeta(p);
                  const selected = selectedKey === p.key;
                  return (
                    <button
                      key={p.key}
                      type="button"
                      onClick={() => setSelectedKey(selected ? "" : p.key)}
                      style={{
                        width: "100%",
                        borderRadius: 14,
                        border: selected ? "1px solid #22c55e" : "1px solid rgba(15,23,42,0.10)",
                        background: selected ? "#f0fdf4" : "#fff",
                        padding: 14,
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "flex-start",
                        gap: 12,
                        cursor: "pointer",
                        textAlign: "left",
                      }}
                    >
                      <div style={{ minWidth: 0 }}>
                        <div style={{ fontSize: 14, fontWeight: 800, color: "#0f172a", wordBreak: "break-word" }}>{presetDisplayName(p)}</div>
                        <div style={{ fontSize: 12, color: "#64748b", marginTop: 6, wordBreak: "break-all" }}>{p.key}</div>
                        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 10 }}>
                          <span style={{ borderRadius: 999, padding: "4px 8px", fontSize: 11, fontWeight: 800, background: "#eff6ff", color: "#1d4ed8" }}>{meta.ext || "FILE"}</span>
                          {meta.isHd ? <span style={{ borderRadius: 999, padding: "4px 8px", fontSize: 11, fontWeight: 800, background: "#ecfeff", color: "#0f766e" }}>HD</span> : null}
                          {meta.isSd ? <span style={{ borderRadius: 999, padding: "4px 8px", fontSize: 11, fontWeight: 800, background: "#fff7ed", color: "#c2410c" }}>SD</span> : null}
                          {meta.isAudio ? <span style={{ borderRadius: 999, padding: "4px 8px", fontSize: 11, fontWeight: 800, background: "#faf5ff", color: "#7e22ce" }}>Audio</span> : null}
                        </div>
                      </div>
                      <div style={{ flexShrink: 0, borderRadius: 999, padding: "6px 10px", fontSize: 12, fontWeight: 800, background: selected ? "#dcfce7" : "#f8fafc", color: selected ? "#166534" : "#334155", border: selected ? "1px solid #86efac" : "1px solid rgba(15,23,42,0.08)" }}>
                        {selected ? "Selected" : "Choose"}
                      </div>
                    </button>
                  );
                })
              )}
            </div>
          </div>

          <div style={{ border: "1px solid rgba(15,23,42,0.08)", borderRadius: 16, background: "#f8fafc", overflow: "hidden", minHeight: 0, display: "flex", flexDirection: "column" }}>
            <div style={{ padding: 14, borderBottom: "1px solid rgba(15,23,42,0.08)", display: "flex", justifyContent: "space-between", gap: 8, alignItems: "center" }}>
              <div>
                <div style={{ fontSize: 14, fontWeight: 800, color: "#0f172a" }}>Selected preset</div>
                <div style={{ fontSize: 12, color: "#64748b", marginTop: 4 }}>This preset will be used as the channel default.</div>
              </div>
              <button type="button" className="btn btn--ghost btn--sm" onClick={() => setSelectedKey("")} disabled={!selectedKey}>Clear</button>
            </div>

            <div style={{ padding: 14, overflowY: "scroll", overflowX: "hidden", display: "grid", gap: 10, flex: 1, minHeight: 0 }}>
              {!selectedPreset ? (
                <div style={{ border: "1px dashed rgba(15,23,42,0.18)", borderRadius: 14, padding: 18, background: "#fff", color: "#64748b", fontSize: 13, lineHeight: 1.5 }}>
                  No default preset selected yet. Leave it empty when this channel should not auto-pick any preset.
                </div>
              ) : (
                <div style={{ borderRadius: 14, border: "1px solid rgba(22,101,52,0.16)", background: "#fff", padding: 12, display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 10 }}>
                  <div style={{ minWidth: 0 }}>
                    <div style={{ fontSize: 13, fontWeight: 800, color: "#166534", wordBreak: "break-word" }}>{presetDisplayName(selectedPreset)}</div>
                    <div style={{ fontSize: 12, color: "#64748b", marginTop: 4, wordBreak: "break-all" }}>{selectedPreset.key}</div>
                  </div>
                  <button type="button" className="btn btn--ghost btn--sm" onClick={() => setSelectedKey("")}>Remove</button>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function ChannelPresetSelectionSummary(props: {
  selectedKey: string;
  presets: Preset[];
  description: string;
  onOpen: () => void;
  onClear: () => void;
}) {
  const { selectedKey, presets, description, onOpen, onClear } = props;
  const selectedPreset = useMemo(() => presets.find((p) => p.key === selectedKey) || null, [presets, selectedKey]);
  return (
    <div style={{ border: "1px solid rgba(15,23,42,0.08)", borderRadius: 16, background: "linear-gradient(180deg, #ffffff 0%, #f8fafc 100%)", padding: 16 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12, flexWrap: "wrap" }}>
        <div>
          <div style={{ fontSize: 13, fontWeight: 800, color: "#0f172a" }}>Default preset</div>
          <div style={{ fontSize: 12, color: "#475569", marginTop: 4, maxWidth: 760 }}>{description}</div>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap", justifyContent: "flex-end" }}>
          <div style={{ borderRadius: 999, padding: "6px 10px", fontSize: 12, fontWeight: 800, background: selectedPreset ? "#ecfdf3" : "#f8fafc", border: selectedPreset ? "1px solid #bbf7d0" : "1px solid rgba(15,23,42,0.08)", color: selectedPreset ? "#166534" : "#334155" }}>
            {selectedPreset ? "Preset selected" : "Optional"}
          </div>
          <button type="button" className="btn btn--ghost btn--sm" onClick={onOpen}>Choose preset</button>
          <button type="button" className="btn btn--ghost btn--sm" onClick={onClear} disabled={!selectedKey}>Clear</button>
        </div>
      </div>

      <div style={{ marginTop: 14, borderRadius: 14, border: "1px solid rgba(15,23,42,0.08)", background: "#fff", padding: 14 }}>
        <div style={{ fontSize: 12, fontWeight: 800, color: "#0f172a", marginBottom: 8 }}>Selected preset</div>
        {!selectedPreset ? (
          <div style={{ fontSize: 13, lineHeight: 1.5, color: "#64748b" }}>
            No default preset selected. This channel will behave as it does today until a preset is chosen.
          </div>
        ) : (
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
            <span style={{ borderRadius: 999, padding: "7px 10px", background: "#f0fdf4", border: "1px solid #bbf7d0", color: "#166534", fontSize: 12, fontWeight: 700 }} title={presetDisplayName(selectedPreset)}>
              {presetDisplayName(selectedPreset)}
            </span>
            <span style={{ borderRadius: 999, padding: "7px 10px", background: "#f8fafc", border: "1px solid rgba(15,23,42,0.08)", color: "#475569", fontSize: 12, fontWeight: 700 }}>
              {selectedPreset.key}
            </span>
          </div>
        )}
      </div>
    </div>
  );
}

function DestinationFilterPicker(props: {
  destinations: Destination[];
  value: string;
  onChange: (destinationId: string) => void;
  allLabel?: string;
  searchPlaceholder?: string;
}) {
  const { destinations, value, onChange, allLabel = "All destinations", searchPlaceholder = "Search destination" } = props;
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const inputRef = useRef<HTMLInputElement | null>(null);
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");

  const selectedDestination = useMemo(() => destinations.find((d) => d.id === value) || null, [destinations, value]);
  const filteredDestinations = useMemo(() => {
    const q = query.trim().toLowerCase();
    const base = !q
      ? destinations
      : destinations.filter((d) => String(d.name || "").toLowerCase().includes(q));
    return [...base].sort((a, b) => String(a.name || "").localeCompare(String(b.name || "")));
  }, [destinations, query]);

  useEffect(() => {
    if (!open) return;
    const handlePointerDown = (event: MouseEvent) => {
      if (!wrapRef.current) return;
      if (wrapRef.current.contains(event.target as Node)) return;
      setOpen(false);
    };
    document.addEventListener("mousedown", handlePointerDown);
    return () => document.removeEventListener("mousedown", handlePointerDown);
  }, [open]);

  useEffect(() => {
    if (!open) return;
    const next = selectedDestination?.name || "";
    setQuery(next);
    const id = window.setTimeout(() => {
      try {
        inputRef.current?.focus();
        inputRef.current?.select();
      } catch {
        // ignore
      }
    }, 0);
    return () => window.clearTimeout(id);
  }, [open, selectedDestination]);

  function choose(nextDestinationId: string) {
    onChange(nextDestinationId);
    setOpen(false);
    setQuery("");
  }

  return (
    <div ref={wrapRef} style={{ position: "relative", minWidth: 220, width: "100%" }}>
      <button
        type="button"
        className="btn btn--ghost"
        onClick={() => setOpen((v) => !v)}
        style={{ width: "100%", justifyContent: "space-between", paddingInline: 12, minHeight: 40, borderRadius: 12 }}
        title={selectedDestination?.name || allLabel}
      >
        <span style={{ minWidth: 0, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", textAlign: "left" }}>
          {selectedDestination?.name || allLabel}
        </span>
        <span aria-hidden="true" style={{ opacity: 0.7, paddingLeft: 8 }}>{open ? "▲" : "▼"}</span>
      </button>

      {open ? (
        <div style={{ position: "absolute", top: "calc(100% + 8px)", left: 0, right: 0, zIndex: 30, border: "1px solid rgba(15,23,42,0.12)", borderRadius: 14, background: "#fff", boxShadow: "0 18px 48px rgba(15,23,42,0.14)", padding: 10, display: "grid", gap: 8 }}>
          <input
            ref={inputRef}
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder={searchPlaceholder}
            style={{ width: "100%", boxSizing: "border-box" }}
          />

          <div style={{ maxHeight: 260, overflowY: "auto", border: "1px solid rgba(15,23,42,0.08)", borderRadius: 12, background: "#f8fafc" }}>
            <button
              type="button"
              onClick={() => choose("")}
              style={{ width: "100%", textAlign: "left", border: 0, borderBottom: "1px solid rgba(15,23,42,0.06)", background: value ? "#fff" : "rgba(34,197,94,0.10)", padding: "10px 12px", display: "grid", gap: 2 }}
            >
              <span style={{ fontWeight: 700 }}>{allLabel}</span>
              <span style={{ fontSize: 11, opacity: 0.68 }}>Show channels from every destination</span>
            </button>

            {filteredDestinations.length ? filteredDestinations.map((d) => {
              const selected = d.id === value;
              return (
                <button
                  key={d.id}
                  type="button"
                  onClick={() => choose(d.id)}
                  title={d.name}
                  style={{ width: "100%", textAlign: "left", border: 0, borderTop: "1px solid rgba(15,23,42,0.06)", background: selected ? "rgba(34,197,94,0.10)" : "#fff", padding: "10px 12px", display: "grid", gap: 2 }}
                >
                  <span style={{ fontWeight: 700, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>{d.name}</span>
                  <span style={{ fontSize: 11, opacity: 0.68 }}>{selected ? "Selected destination" : "Click to filter"}</span>
                </button>
              );
            }) : (
              <div style={{ padding: "12px 12px", fontSize: 12, color: "#64748b" }}>No destinations match your search.</div>
            )}
          </div>
        </div>
      ) : null}
    </div>
  );
}

export function ChannelsPage() {
  const [searchParams, setSearchParams] = useSearchParams();
const nav = useNavigate();
const returnTo = (searchParams.get("returnTo") || "").trim();
const returnOnSave = String(searchParams.get("returnOnSave") || "") === "1";
const editIdParam = (searchParams.get("editId") || "").trim();
const createMode = String(searchParams.get("create") || "") === "1";

  const [rows, setRows] = useState<Channel[]>([]);
  const filterDestinationId = (searchParams.get("destinationId") || "").trim();
  const [destinations, setDestinations] = useState<Destination[]>([]);
  const [profiles, setProfiles] = useState<DeliveryProfile[]>([]);
  const [presetLibrary, setPresetLibrary] = useState<Preset[]>([]);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [showCreateSection, setShowCreateSection] = useState(createMode);
  const [createStep, setCreateStep] = useState<0 | 1 | 2>(0);
  const [listSearch, setListSearch] = useState("");
  const [listHealthFilter, setListHealthFilter] = useState<"ALL" | "UNKNOWN" | "ONLINE" | "OFFLINE">("ALL");

  // Create form
  const [name, setName] = useState("");
  const createNameRef = useRef<HTMLInputElement | null>(null);

  const [destinationId, setDestinationId] = useState<string>("");
  const [mainProfileId, setMainProfileId] = useState<string>("");
  const [backupProfileId, setBackupProfileId] = useState<string>("");
  const [logoPosition, setLogoPosition] = useState<"" | LogoPosition>("");
  const [defaultPresetKey, setDefaultPresetKey] = useState<string>("");
  const [transcodeOnCommit, setTranscodeOnCommit] = useState(true);
  const [createPresetSearch, setCreatePresetSearch] = useState("");
  const [createPresetFilter, setCreatePresetFilter] = useState<PresetFilter>("ALL");
  const [createPresetPickerOpen, setCreatePresetPickerOpen] = useState(false);
  const [notificationEmails, setNotificationEmails] = useState("");
  const [approverMode, setApproverMode] = useState<ApprovalModeUi>("PARALLEL");
  const [steps, setSteps] = useState<StepDraft[]>([defaultApprovalStep()]);

const [showAdvancedCreate, setShowAdvancedCreate] = useState(false);
const [xmlEnabledCreate, setXmlEnabledCreate] = useState(false);
const [xmlConfigTextCreate, setXmlConfigTextCreate] = useState(`{}`);

const [showAdvancedEdit, setShowAdvancedEdit] = useState(false);


  // Edit modal
  const [edit, setEdit] = useState<null | { row: Channel; form: any }>(null);
  const [actionRow, setActionRow] = useState<Channel | null>(null);
  const [editPresetSearch, setEditPresetSearch] = useState("");
  const [editPresetFilter, setEditPresetFilter] = useState<PresetFilter>("ALL");
  const [editPresetPickerOpen, setEditPresetPickerOpen] = useState(false);

  async function load() {
    setErr("");
    try {
      const [d, p, c, pl] = await Promise.all([
        api<Destination[]>("/masters/destinations"),
        api<DeliveryProfile[]>("/masters/delivery-profiles"),
        api<Channel[]>(`/masters/channels${filterDestinationId ? `?destinationId=${encodeURIComponent(filterDestinationId)}` : ""}`),
        api<{ presets: Preset[] }>("/presets").catch(() => ({ presets: [] })),
      ]);
      setDestinations(d);
      setProfiles(p);
      setRows(c);
      setPresetLibrary(Array.isArray((pl as any)?.presets) ? (pl as any).presets : []);

      // set defaults for create form
      if (filterDestinationId) setDestinationId(filterDestinationId);
      else if (!destinationId && d.length) setDestinationId(d[0].id);
    } catch (e: any) {
      setErr((e as ApiError)?.message || "Failed to load channels");
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [filterDestinationId]);

function goBackToDeliverySetup(destId?: string) {
  if (!returnTo) return;
  try {
    const u = new URL(returnTo, window.location.origin);
    if (destId) u.searchParams.set("destinationId", destId);
    nav(`${u.pathname}${u.search || ""}`);
  } catch {
    nav(returnTo);
  }
}

const openedParamRef = useRef<string>("");

useEffect(() => {
  if (!createMode) return;
  setShowCreateSection(true);
  setCreateStep(0);
  requestAnimationFrame(() => {
    try {
      createNameRef.current?.focus();
      createNameRef.current?.scrollIntoView({ block: "center", behavior: "smooth" });
    } catch {
      // ignore
    }
  });
}, [createMode]);

useEffect(() => {
  if (!editIdParam) return;
  if (openedParamRef.current === editIdParam) return;
  const row = rows.find((r) => r.id === editIdParam);
  if (!row) return;
  openedParamRef.current = editIdParam;
  openEdit(row);
}, [editIdParam, rows]);

  const generalStepComplete = useMemo(() => name.trim().length > 0, [name]);
  const locationStepComplete = useMemo(() => Boolean(destinationId), [destinationId]);
  const createStepValidity = useMemo(() => [generalStepComplete, locationStepComplete, true] as const, [generalStepComplete, locationStepComplete]);
  const canOpenCreateStep = (targetStep: number) => targetStep === 0 || createStepValidity.slice(0, targetStep).every(Boolean);
  const canCreate = useMemo(() => generalStepComplete && !!destinationId, [generalStepComplete, destinationId]);


  const selectedDestination = useMemo(
    () => destinations.find((d) => d.id === destinationId) || null,
    [destinations, destinationId],
  );
  const selectedDestinationDefaultPresetKey = useMemo(
    () => destinationDefaultPresetKeyFromConfig(selectedDestination?.config),
    [selectedDestination],
  );
  const createPresetOptions = useMemo(
    () => resolveDestinationPresetLibrary(selectedDestination, presetLibrary),
    [selectedDestination, presetLibrary],
  );
  const filteredRows = useMemo(() => {
    const term = listSearch.trim().toLowerCase();
    return rows.filter((r) => {
      if (listHealthFilter !== "ALL" && (r.serverStatus || "UNKNOWN") !== listHealthFilter) return false;
      if (!term) return true;
      const destination = destinations.find((d) => d.id === (r.destinationId || "")) || null;
      const inheritedPresetKey = destinationDefaultPresetKeyFromConfig(destination?.config);
      const effectivePresetKey = r.defaultPresetKey || inheritedPresetKey || "";
      const hay = [
        r.name,
        destination?.name,
        profileLabel(r.mainProfileId),
        profileLabel(r.backupProfileId),
        effectivePresetKey,
        r.alignment,
        r.serverStatus,
        r.serverMessage,
      ]
        .filter(Boolean)
        .join(" ")
        .toLowerCase();
      return hay.includes(term);
    });
  }, [rows, listSearch, listHealthFilter, destinations, profiles, presetLibrary]);

  useEffect(() => {
    if (!destinationId) return;
    if (defaultPresetKey) return;
    if (selectedDestinationDefaultPresetKey) setDefaultPresetKey(selectedDestinationDefaultPresetKey);
  }, [destinationId, defaultPresetKey, selectedDestinationDefaultPresetKey]);

  useEffect(() => {
    if (defaultPresetKey && createPresetOptions.length && !createPresetOptions.some((preset) => preset.key === defaultPresetKey)) {
      if (selectedDestinationDefaultPresetKey && createPresetOptions.some((preset) => preset.key === selectedDestinationDefaultPresetKey)) {
        setDefaultPresetKey(selectedDestinationDefaultPresetKey);
      } else {
        setDefaultPresetKey("");
      }
    }
  }, [defaultPresetKey, createPresetOptions, selectedDestinationDefaultPresetKey]);

  function buildStepsPayload(drafts: StepDraft[]) {
    const out: any[] = [];
    for (let i = 0; i < drafts.length; i++) {
      const s = drafts[i];
      const to = parseEmails(s.approverEmailsText);
      const cc = parseEmails(s.ccEmailsText);
      if (!to.length && !cc.length) continue;
      out.push({
        order: i + 1,
        teamName: s.teamName?.trim() || `Step ${i + 1}`,
        approverEmails: to,
        ccEmails: cc,
      });
    }
    return out;
  }

  function buildApprovalPayload(mode: ApprovalModeUi, drafts: StepDraft[]) {
    if (mode === "NONE") {
      return { approverMode: "PARALLEL" as const, approvalSteps: [] as any[] };
    }
    return { approverMode: mode as "PARALLEL" | "SEQUENTIAL", approvalSteps: buildStepsPayload(drafts) };
  }

  async function create() {
    if (!canCreate) return;
    setBusy(true);
    setErr("");
    try {
      const approvalPayload = buildApprovalPayload(approverMode, steps);
      const created: any = await api<any>("/masters/channels", {
        method: "POST",
        body: JSON.stringify({
          name: name.trim(),
          destinationId,
          mainProfileId: mainProfileId || null,
          backupProfileId: backupProfileId || null,
          alignment: logoPosition || null,
          defaultPresetKey: defaultPresetKey || null,
          transcodeOnCommit: Boolean(transcodeOnCommit),
          notificationEmails: parseEmails(notificationEmails),
          ...approvalPayload,
          config: xmlEnabledCreate ? { xml: { ...safeJsonParse(xmlConfigTextCreate, {}), enabled: true } } : undefined,
        }),
      });
      setName("");
      setNotificationEmails("");
      setLogoPosition("");
      setDefaultPresetKey(selectedDestinationDefaultPresetKey || "");
      setTranscodeOnCommit(true);
      setCreatePresetSearch("");
      setCreatePresetFilter("ALL");
      setCreatePresetPickerOpen(false);
      setApproverMode("PARALLEL");
      setSteps([defaultApprovalStep()]);
      setShowAdvancedCreate(false);
      setXmlEnabledCreate(false);
      setXmlConfigTextCreate(`{}`);
      setCreateStep(0);
      await load();

      if (returnTo && returnOnSave) {
        let destId = (destinationId || created?.destinationId) as string | undefined;
        // If API didn't return, best-effort: reload list and match by name
        if (!destId) destId = filterDestinationId || undefined;
        goBackToDeliverySetup(destId);
        return;
      }
    } catch (e: any) {
      setErr((e as ApiError)?.message || "Create failed");
    } finally {
      setBusy(false);
    }
  }

  async function patch(id: string, data: any) {
    setBusy(true);
    setErr("");
    try {
      await api(`/masters/channels/${id}`, { method: "PATCH", body: JSON.stringify(data) });
      await load();
    } catch (e: any) {
      setErr((e as ApiError)?.message || "Update failed");
    } finally {
      setBusy(false);
    }
  }

  async function remove(id: string) {
    if (!confirm("Delete this channel?")) return;
    setBusy(true);
    setErr("");
    try {
      await api(`/masters/channels/${id}`, { method: "DELETE" });
      await load();
    } catch (e: any) {
      setErr((e as ApiError)?.message || "Delete failed");
    } finally {
      setBusy(false);
    }
  }

  function destName(id?: string | null) {
    if (!id) return "—";
    return destinations.find((d) => d.id === id)?.name || id;
  }
  function profileLabel(id?: string | null) {
    if (!id) return "—";
    const p = profiles.find((x) => x.id === id);
    return p ? `${p.name} (${p.protocol})` : id;
  }

  function presetLabel(key?: string | null) {
    if (!key) return "—";
    const p = presetLibrary.find((x) => x.key === key);
    return p ? `${presetDisplayName(p)} (${p.key})` : key;
  }

function openEdit(row: Channel) {
  setShowAdvancedEdit(false);
  setEditPresetSearch("");
  setEditPresetFilter("ALL");
  setEditPresetPickerOpen(false);

  const xmlRaw = row.config?.xml && typeof row.config.xml === "object" ? row.config.xml : null;
  const xmlEnabled = Boolean((xmlRaw as any)?.enabled);
  const xmlCfg: any = xmlRaw ? { ...(xmlRaw as any) } : {};
  delete xmlCfg.enabled;

  setEdit({
    row,
    form: {
      name: row.name,
      destinationId: row.destinationId || (destinations[0]?.id ?? ""),
      mainProfileId: row.mainProfileId || "",
      backupProfileId: row.backupProfileId || "",
      alignment: row.alignment || "",
      defaultPresetKey: row.defaultPresetKey || destinationDefaultPresetKeyFromConfig(destinations.find((d) => d.id === (row.destinationId || ""))?.config) || "",
      transcodeOnCommit: Boolean(row.transcodeOnCommit ?? row.config?.transcodeOnCommit ?? true),
      notificationEmails: emailsToText(row.notificationEmails),
      approverMode: getApprovalModeUi(row),
      steps: normalizeStepsForUi(row),

      xmlEnabled,
      xmlConfigText: pretty(xmlCfg),
    },
  });
}

  const editDestination = useMemo(
    () => (edit ? destinations.find((d) => d.id === (edit.form.destinationId || "")) || null : null),
    [destinations, edit],
  );
  const editDestinationDefaultPresetKey = useMemo(
    () => destinationDefaultPresetKeyFromConfig(editDestination?.config),
    [editDestination],
  );
  const editPresetOptions = useMemo(
    () => resolveDestinationPresetLibrary(editDestination, presetLibrary),
    [editDestination, presetLibrary],
  );

  function renderStepsEditor(current: StepDraft[], onChange: (next: StepDraft[]) => void) {
    const stepsInputStyle: CSSProperties = {
      width: "100%",
      minWidth: 0,
      maxWidth: "100%",
      boxSizing: "border-box",
      // Chrome default focus ring can paint outside the cell and look like overlap.
      // Keep focus visible via border, but remove the ring so it doesn't bleed into next column.
      outline: "none",
    };

    return (
      <div style={{ display: "grid", gap: 8 }}>
        <div style={{ fontWeight: 700 }}>Approval teams (steps)</div>
        {/* NOTE: This editor is inside a card and can get wide. Wrap with overflow to prevent any visual overlap. */}
        <div style={{ overflowX: "auto" }}>
          <table style={{ width: "100%", minWidth: 980, borderCollapse: "collapse", tableLayout: "fixed" }}>
            <colgroup>
              <col style={{ width: 60 }} />
              <col style={{ width: 220 }} />
              <col style={{ width: 370 }} />
              <col style={{ width: 220 }} />
              <col style={{ width: 110 }} />
            </colgroup>
            <thead>
              <tr>
                <th style={{ textAlign: "left", padding: 8, width: 60 }}>Step</th>
                <th style={{ textAlign: "left", padding: 8, width: 220 }}>Team</th>
                <th style={{ textAlign: "left", padding: 8 }}>Approver emails (To)</th>
                <th style={{ textAlign: "left", padding: 8, width: 220 }}>CC (optional)</th>
                <th style={{ textAlign: "left", padding: 8, width: 110 }}>Actions</th>
              </tr>
            </thead>
            <tbody>
              {current.map((s, idx) => (
                <tr key={idx} style={{ borderTop: "1px solid #eee" }}>
                  <td style={{ padding: 8 }}>{idx + 1}</td>
                  <td style={{ padding: 8, overflow: "hidden" }}>
                    <input
                      value={s.teamName}
                      onChange={(e) => {
                        const next = current.slice();
                        next[idx] = { ...next[idx], teamName: e.target.value };
                        onChange(next);
                      }}
                      placeholder={`Step ${idx + 1}`}
                      style={stepsInputStyle}
                    />
                  </td>
                  <td style={{ padding: 8, overflow: "hidden" }}>
                    <input
                      value={s.approverEmailsText}
                      onChange={(e) => {
                        const next = current.slice();
                        next[idx] = { ...next[idx], approverEmailsText: e.target.value };
                        onChange(next);
                      }}
                      placeholder="a@x.com, b@x.com"
                      style={stepsInputStyle}
                    />
                  </td>
                  <td style={{ padding: 8, overflow: "hidden" }}>
                    <input
                      value={s.ccEmailsText}
                      onChange={(e) => {
                        const next = current.slice();
                        next[idx] = { ...next[idx], ccEmailsText: e.target.value };
                        onChange(next);
                      }}
                      placeholder="optional"
                      style={stepsInputStyle}
                    />
                  </td>
                  <td style={{ padding: 8 }}>
                    <button
                      onClick={() => {
                        const next = current.slice();
                        next.splice(idx, 1);
                        onChange(next.length ? next : [defaultApprovalStep()]);
                      }}
                    >
                      Remove
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="row" style={{ alignItems: "center" }}>
          <button
            onClick={() => {
              const last = current[current.length - 1] || { teamName: "", approverEmailsText: "", ccEmailsText: "" };
              onChange([...current, { teamName: `Step ${current.length + 1}`, approverEmailsText: last.approverEmailsText, ccEmailsText: last.ccEmailsText }]);
            }}
          >
            + Add step
          </button>
          <button
            onClick={() => onChange([defaultApprovalStep()])}
            title="Clear all steps"
          >
            Reset steps
          </button>
        </div>
      </div>
    );
  }

  const rowSummary = useMemo(() => {
    return rows.map((r) => {
      const stepsCount = Array.isArray(r.approvalSteps) && r.approvalSteps.length ? r.approvalSteps.length : 0;
      const notifyCount = Array.isArray(r.notificationEmails) ? r.notificationEmails.length : 0;
      return { id: r.id, stepsCount, notifyCount };
    });
  }, [rows]);

  function getCounts(id: string) {
    return rowSummary.find((x) => x.id === id) || { stepsCount: 0, notifyCount: 0 };
  }


function sampleXmlValues(destName: string, channelName: string) {
  const safeDest = String(destName || "").trim() || "DESTINATION";
  const safeCh = String(channelName || "").trim() || "CHANNEL";
  const now = new Date().toISOString();
  const file = "example.mxf";
  const base = file.replace(/\.[^.]+$/, "");
  const remote = `/out/${file}`;
  return {
    TASK_ID: "TASK_123",
    ACCOUNT_ID: "ACCOUNT_123",
    PROFILE_ID: "PROFILE_123",
    PROFILE_NAME: "PROFILE",
    PROTOCOL: "FTP",
    DESTINATION: safeDest,
    CHANNEL: safeCh,
    PROJECT: "PROJECT",
    CREATIVE: "CREATIVE",
    VALID: "VALID_0001",
    FILENAME: file,
    BASENAME: base,
    REMOTE_PATH: remote,
    BYTES: "123456789",
    GENERATED_AT: now,
    UUID8: "a1b2c3d4",
  } as Record<string, string>;
}

const createDestName = useMemo(() => destinations.find((d) => d.id === destinationId)?.name || "DESTINATION", [destinations, destinationId]);
const createXmlCfgObj = useMemo(() => safeJsonParse(xmlConfigTextCreate, {}), [xmlConfigTextCreate]);
const createXmlValues = useMemo(() => sampleXmlValues(createDestName, name), [createDestName, name]);
const createXmlFileName = useMemo(
  () => (xmlEnabledCreate ? computeXmlFileNamePreview(createXmlCfgObj, createXmlValues) : ""),
  [xmlEnabledCreate, createXmlCfgObj, createXmlValues],
);
const createXmlRemotePath = useMemo(() => {
  if (!xmlEnabledCreate) return "";
  const mediaPath = createXmlValues.REMOTE_PATH || createXmlValues.FILENAME || "";
  const dir = mediaPath.includes("/") ? mediaPath.split("/").slice(0, -1).join("/") : "";
  return dir ? `${dir}/${createXmlFileName}` : createXmlFileName;
}, [xmlEnabledCreate, createXmlFileName, createXmlValues]);

const createXmlPreview = useMemo(
  () => (xmlEnabledCreate ? buildXmlPreview(createXmlCfgObj, { ...createXmlValues, XML_REMOTE_PATH: createXmlRemotePath }) : ""),
  [xmlEnabledCreate, createXmlCfgObj, createXmlValues, createXmlRemotePath],
);

const editDestName = useMemo(
  () => destinations.find((d) => d.id === (edit?.form?.destinationId || ""))?.name || "DESTINATION",
  [destinations, edit?.form?.destinationId],
);
const editXmlCfgObj = useMemo(() => safeJsonParse(String(edit?.form?.xmlConfigText || "{}"), {}), [edit?.form?.xmlConfigText]);
const editXmlValues = useMemo(() => sampleXmlValues(editDestName, String(edit?.form?.name || "CHANNEL")), [editDestName, edit?.form?.name]);
const editXmlFileName = useMemo(
  () => ((edit?.form?.xmlEnabled ? true : false) ? computeXmlFileNamePreview(editXmlCfgObj, editXmlValues) : ""),
  [edit?.form?.xmlEnabled, editXmlCfgObj, editXmlValues],
);
const editXmlRemotePath = useMemo(() => {
  if (!(edit?.form?.xmlEnabled ? true : false)) return "";
  const mediaPath = editXmlValues.REMOTE_PATH || editXmlValues.FILENAME || "";
  const dir = mediaPath.includes("/") ? mediaPath.split("/").slice(0, -1).join("/") : "";
  return dir ? `${dir}/${editXmlFileName}` : editXmlFileName;
}, [edit?.form?.xmlEnabled, editXmlFileName, editXmlValues]);

const editXmlPreview = useMemo(
  () => ((edit?.form?.xmlEnabled ? true : false) ? buildXmlPreview(editXmlCfgObj, { ...editXmlValues, XML_REMOTE_PATH: editXmlRemotePath }) : ""),
  [edit?.form?.xmlEnabled, editXmlCfgObj, editXmlValues, editXmlRemotePath],
);

function setDestinationFilter(nextDestinationId: string) {
  const next = new URLSearchParams(searchParams);
  if (nextDestinationId) next.set("destinationId", nextDestinationId);
  else next.delete("destinationId");
  setSearchParams(next);
}

const destinationFilterControl = (
  <div className="row" style={{ alignItems: "center", gap: 8, flexWrap: "wrap" }}>
    <div style={{ fontSize: 12, fontWeight: 800, opacity: 0.85 }}>Filter</div>
    <div style={{ minWidth: 260, width: "min(360px, 100%)" }}>
      <DestinationFilterPicker
        destinations={destinations}
        value={filterDestinationId}
        onChange={setDestinationFilter}
      />
    </div>

    {filterDestinationId ? (
      <button className="btn btn--ghost btn--sm" onClick={() => setDestinationFilter("")}>
        Clear filter
      </button>
    ) : null}
  </div>
);

async function copyToClipboard(v: string) {
  try {
    await navigator.clipboard.writeText(v);
  } catch {
    // ignore
  }
}


  return (
    <div className="masters-wrap">
{returnTo ? (
  <div className="card card--soft" style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12 }}>
    <div style={{ fontWeight: 800 }}>Back</div>
    <button type="button" disabled={busy} onClick={() => nav(returnTo)}>
      Back to Delivery Setup
    </button>
  </div>
) : null}

      <div className="card card--soft" style={{ display: "grid", gap: 10 }}>
        <div className="page-head">
          <div className="page-head__title">
            <h3 style={{ margin: 0 }}>Channels</h3>
          </div>
          <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
            <button className="btn btn--ghost" onClick={() => setShowCreateSection((v) => { const next = !v; if (next) setCreateStep(0); return next; })} disabled={busy}>
              {showCreateSection ? "Hide create" : "Create channel"}
            </button>
            <button className="btn btn--ghost" onClick={load} disabled={busy}>
              Refresh
            </button>
          </div>
        </div>

        {showCreateSection ? (
          <>
            <div className="card" style={{ borderColor: "rgba(37,99,235,0.12)", background: "rgba(255,255,255,0.96)", display: "grid", gap: 14 }}>
              <WizardStepper
                steps={CHANNEL_CREATE_STEPS}
                currentStep={createStep}
                canOpenStep={canOpenCreateStep}
                onStepClick={(index) => {
                  if (canOpenCreateStep(index)) setCreateStep(index as 0 | 1 | 2);
                }}
              />

              <div key={`channel-step-${createStep}`} style={{ display: "grid", gap: 12, animation: "wizardStepFade 220ms ease" }}>
                {createStep === 0 ? (
                  <>
                    <div style={{ display: "grid", gap: 4 }}>
                      <div style={{ fontSize: 18, fontWeight: 900, color: "#0f172a" }}>1. General</div>
                    </div>

                    <div className="card card--soft" style={{ padding: 12, display: "grid", gap: 8 }}>
                      <div style={{ fontSize: 12, fontWeight: 800, color: "#0f172a" }}>Destination filter</div>
                      <div style={{ fontSize: 12, color: "#475569" }}>Use this only when you want to narrow the channel list and preselect the same destination while creating a channel.</div>
                      {destinationFilterControl}
                    </div>

                    <div className="row" style={{ alignItems: "center", flexWrap: "wrap" }}>
                      <div style={{ minWidth: 260, flex: 1 }}>
                        <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Channel name</div>
                        <input ref={createNameRef} placeholder="Channel name" value={name} onChange={(e) => setName(e.target.value)} />
                      </div>
                      <div style={{ minWidth: 260, flex: 1 }}>
                        <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Notification emails</div>
                        <input
                          placeholder="Notification emails (comma separated) — used for Project Complete + fallback"
                          value={notificationEmails}
                          onChange={(e) => setNotificationEmails(e.target.value)}
                          style={{ width: "100%" }}
                        />
                      </div>
                    </div>

                    <div className="row" style={{ alignItems: "center", flexWrap: "wrap" }}>
                      <div style={{ minWidth: 260 }}>
                        <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Approvals</div>
                        <select
                          value={approverMode}
                          onChange={(e) => {
                            const nextMode = e.target.value as ApprovalModeUi;
                            setApproverMode(nextMode);
                            if (nextMode !== "NONE" && !steps.length) setSteps([defaultApprovalStep()]);
                          }}
                        >
                          <option value="NONE">Approvals: NONE</option>
                          <option value="PARALLEL">Approvals: PARALLEL</option>
                          <option value="SEQUENTIAL">Approvals: SEQUENTIAL</option>
                        </select>
                      </div>
                    </div>

                    {approverMode === "NONE" ? (
                      <div className="card" style={{ padding: 12, borderColor: "rgba(0,0,0,0.08)", background: "rgba(148,163,184,0.08)" }}>
                        <div style={{ fontSize: 13, fontWeight: 700 }}>No approval required for this channel.</div>
                        <div style={{ fontSize: 12, opacity: 0.72 }}>Files on this channel will skip approval routing.</div>
                      </div>
                    ) : renderStepsEditor(steps, setSteps)}
                  </>
                ) : null}

                {createStep === 1 ? (
                  <>
                    <div style={{ display: "grid", gap: 4 }}>
                      <div style={{ fontSize: 18, fontWeight: 900, color: "#0f172a" }}>2. Location</div>
                    </div>

                    <div className="row" style={{ alignItems: "center", flexWrap: "wrap" }}>
                      <div style={{ minWidth: 280, flex: 1 }}>
                        <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Destination</div>
                        <select
                          value={destinationId}
                          onChange={(e) => {
                            const nextDestinationId = e.target.value;
                            const nextDestination = destinations.find((d) => d.id === nextDestinationId) || null;
                            const nextDefaultPresetKey = destinationDefaultPresetKeyFromConfig(nextDestination?.config);
                            setDestinationId(nextDestinationId);
                            if (!defaultPresetKey || defaultPresetKey === selectedDestinationDefaultPresetKey) {
                              setDefaultPresetKey(nextDefaultPresetKey || "");
                            }
                          }}>
                          {destinations.map((d) => (
                            <option key={d.id} value={d.id}>
                              {d.name}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>

                    <div className="row" style={{ alignItems: "center", flexWrap: "wrap" }}>
                      <div style={{ minWidth: 260, flex: 1 }}>
                        <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Main profile</div>
                        <select value={mainProfileId} onChange={(e) => setMainProfileId(e.target.value)}>
                          <option value="">Main profile (optional)</option>
                          {profiles.map((p) => (
                            <option key={p.id} value={p.id}>
                              {p.name} ({p.protocol})
                            </option>
                          ))}
                        </select>
                      </div>
                      <div style={{ minWidth: 260, flex: 1 }}>
                        <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Backup profile</div>
                        <select value={backupProfileId} onChange={(e) => setBackupProfileId(e.target.value)}>
                          <option value="">Backup profile (optional)</option>
                          {profiles.map((p) => (
                            <option key={p.id} value={p.id}>
                              {p.name} ({p.protocol})
                            </option>
                          ))}
                        </select>
                      </div>
                      <div style={{ minWidth: 220 }}>
                        <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Logo position</div>
                        <select value={logoPosition} onChange={(e) => setLogoPosition((e.target.value as "" | LogoPosition) || "")}>
                          <option value="">Logo position (optional)</option>
                          {LOGO_POSITION_OPTIONS.map((pos) => (
                            <option key={pos} value={pos}>
                              {pos}
                            </option>
                          ))}
                        </select>
                      </div>
                    </div>
                  </>
                ) : null}

                {createStep === 2 ? (
                  <>
                    <div style={{ display: "grid", gap: 4 }}>
                      <div style={{ fontSize: 18, fontWeight: 900, color: "#0f172a" }}>3. Presets</div>
                    </div>

                    <div className="card card--soft" style={{ padding: 12, display: "grid", gap: 8 }}>
                      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, flexWrap: "wrap" }}>
                        <div>
                          <div style={{ fontSize: 13, fontWeight: 800, color: "#0f172a" }}>Preset</div>
                        </div>
                        {defaultPresetKey ? (
                          <span className="badge" title={presetLabel(defaultPresetKey)} style={{ whiteSpace: "nowrap" }}>
                            {presetLabel(defaultPresetKey)}
                          </span>
                        ) : selectedDestinationDefaultPresetKey ? (
                          <span className="badge" title={presetLabel(selectedDestinationDefaultPresetKey)} style={{ whiteSpace: "nowrap" }}>
                            Inherit {presetLabel(selectedDestinationDefaultPresetKey)}
                          </span>
                        ) : (
                          <span className="badge">No preset selected</span>
                        )}
                      </div>
                      <ChannelPresetSelectionSummary
                        selectedKey={defaultPresetKey}
                        presets={createPresetOptions}
                        description=""
                        onOpen={() => setCreatePresetPickerOpen(true)}
                        onClear={() => { setDefaultPresetKey(""); }}
                      />
                      <label style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13, fontWeight: 700, color: (defaultPresetKey || selectedDestinationDefaultPresetKey) ? "#0f172a" : "#94a3b8" }}>
                        <input
                          type="checkbox"
                          checked={Boolean(transcodeOnCommit)}
                          disabled={!(defaultPresetKey || selectedDestinationDefaultPresetKey)}
                          onChange={(e) => setTranscodeOnCommit(e.target.checked)}
                        />
                        Auto transcode after commit
                      </label>
                    </div>

                    <div className="row" style={{ alignItems: "center", justifyContent: "space-between" }}>
                      <button className="btn btn--ghost btn--sm" type="button" onClick={() => setShowAdvancedCreate((v) => !v)} disabled={busy}>
                        {showAdvancedCreate ? "Advanced ▲" : "Advanced ▼"}
                      </button>
                      <div style={{ fontSize: 12, opacity: 0.7 }}>Metadata XML: <b>{xmlEnabledCreate ? "ON" : "OFF"}</b></div>
                    </div>

                    {showAdvancedCreate ? (
                      <div className="card" style={{ padding: 12, borderColor: "rgba(0,0,0,0.12)" }}>
                        <div className="row" style={{ justifyContent: "space-between", alignItems: "center" }}>
                          <div style={{ fontWeight: 900 }}>Metadata XML (optional)</div>
                          <label style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12, fontWeight: 800 }}>
                            <input
                              type="checkbox"
                              checked={xmlEnabledCreate}
                              onChange={(e) => {
                                const on = e.target.checked;
                                setXmlEnabledCreate(on);
                                if (on && (!xmlConfigTextCreate || !xmlConfigTextCreate.trim() || xmlConfigTextCreate.trim() === "{}")) {
                                  setXmlConfigTextCreate(defaultXmlConfigJson());
                                }
                              }}
                            />
                            Enable
                          </label>
                        </div>

                        {xmlEnabledCreate ? (
                          <div style={{ marginTop: 10, display: "grid", gap: 8 }}>
                            <div style={{ fontSize: 12, fontWeight: 700 }}>XML config (JSON)</div>
                            <textarea
                              style={{ width: "100%", maxWidth: "100%", minHeight: 140, fontFamily: "monospace", boxSizing: "border-box" }}
                              value={xmlConfigTextCreate}
                              onChange={(e) => setXmlConfigTextCreate(e.target.value)}
                            />
                            <div style={{ fontSize: 12, opacity: 0.75 }}>
                              Placeholders: <code>{"{TASK_ID}"}</code>, <code>{"{VALID}"}</code>, <code>{"{FILENAME}"}</code>,{" "}
                              <code>{"{REMOTE_PATH}"}</code>, <code>{"{BASENAME}"}</code>, <code>{"{GENERATED_AT}"}</code>
                            </div>

                            <div style={{ fontSize: 12, fontWeight: 800 }}>Preview</div>
                            <div className="row" style={{ justifyContent: "space-between", alignItems: "center", gap: 8 }}>
                              <div style={{ fontSize: 12, opacity: 0.8 }}>
                                File: <span style={{ fontWeight: 900 }}>{createXmlFileName || "—"}</span> &nbsp;•&nbsp; Remote:{" "}
                                <span style={{ fontWeight: 900 }}>{createXmlRemotePath || "—"}</span>
                              </div>
                              <button type="button" onClick={() => copyToClipboard(createXmlPreview)} disabled={!createXmlPreview}>
                                Copy
                              </button>
                            </div>
                            <pre
                              style={{
                                margin: 0,
                                padding: 10,
                                borderRadius: 10,
                                border: "1px solid rgba(0,0,0,0.12)",
                                background: "rgba(0,0,0,0.03)",
                                overflowX: "auto",
                                whiteSpace: "pre",
                                fontSize: 12,
                                lineHeight: 1.3,
                              }}
                            >
                              {createXmlPreview}
                            </pre>
                          </div>
                        ) : (
                          <div style={{ marginTop: 8, fontSize: 12, opacity: 0.7 }}>
                            When enabled, the Delivery Worker will generate an XML sidecar and send it with the media file.
                          </div>
                        )}
                      </div>
                    ) : null}
                  </>
                ) : null}
              </div>

              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12, flexWrap: "wrap", paddingTop: 4, borderTop: "1px solid rgba(15,23,42,0.08)" }}>
                <div style={{ fontSize: 12, color: "#64748b" }}>
                  Step {createStep + 1} of {CHANNEL_CREATE_STEPS.length}
                </div>
                <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                  <button type="button" className="btn btn--ghost" onClick={() => setCreateStep((s) => Math.max(0, s - 1) as 0 | 1 | 2)} disabled={createStep === 0 || busy}>
                    Back
                  </button>
                  {createStep < 2 ? (
                    <button
                      type="button"
                      className="btn btn--primary"
                      onClick={() => setCreateStep((s) => Math.min(2, s + 1) as 0 | 1 | 2)}
                      disabled={!createStepValidity[createStep] || busy}
                    >
                      Next
                    </button>
                  ) : (
                    <button className="btn btn--primary" onClick={create} disabled={busy || !canCreate}>
                      {busy ? "Saving..." : "Create"}
                    </button>
                  )}
                </div>
              </div>
            </div>
          </>
        ) : null}

        {err && <div className="card" style={{ borderColor: "#f5a", background: "#fff5fa" }}>{err}</div>}
      </div>

      <div className="row" style={{ alignItems: "center", justifyContent: "space-between", marginTop: 12 }}>
        <div style={{ fontWeight: 700 }}>Existing channels</div>
      </div>

      <div className="card card--soft" style={{ display: "grid", gap: 14 }}>
        <div className="page-head" style={{ paddingBottom: 0 }}>
          <div className="page-head__title">
            <h3 style={{ margin: 0 }}>Channel list</h3>
          </div>
        </div>

        <div className="card" style={{ borderRadius: 18, background: "rgba(248,250,252,0.85)", border: "1px solid rgba(15,23,42,0.08)", display: "grid", gap: 10 }}>
          <div className="row" style={{ flexWrap: "wrap", alignItems: "end", gap: 10 }}>
            <div style={{ minWidth: 220, flex: 1 }}>
              <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Search</div>
              <input placeholder="Search channels" value={listSearch} onChange={(e) => setListSearch(e.target.value)} />
            </div>
            <div style={{ minWidth: 220, flex: 1 }}>
              <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Destination</div>
              <DestinationFilterPicker
                destinations={destinations}
                value={filterDestinationId}
                onChange={setDestinationFilter}
              />
            </div>
            <div style={{ minWidth: 180 }}>
              <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Health</div>
              <select value={listHealthFilter} onChange={(e) => setListHealthFilter(e.target.value as any)}>
                <option value="ALL">All health</option>
                <option value="ONLINE">Online</option>
                <option value="OFFLINE">Offline</option>
                <option value="UNKNOWN">Unknown</option>
              </select>
            </div>
            <button
              type="button"
              className="btn btn--ghost btn--sm"
              onClick={() => {
                setListSearch("");
                setListHealthFilter("ALL");
                const next = new URLSearchParams(searchParams);
                next.delete("destinationId");
                setSearchParams(next);
              }}
              disabled={!listSearch && listHealthFilter === "ALL" && !filterDestinationId}
            >
              Clear filters
            </button>
          </div>
        </div>

        {filteredRows.length === 0 ? (
          <div className="card" style={{ borderColor: "rgba(0,0,0,0.10)", background: "rgba(0,0,0,0.03)" }}>
            No channels match the current filters.
          </div>
        ) : (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))", gap: 12 }}>
            {filteredRows.map((r) => {
              const destination = destinations.find((d) => d.id === (r.destinationId || "")) || null;
              const inheritedPresetKey = destinationDefaultPresetKeyFromConfig(destination?.config);
              const effectivePresetKey = r.defaultPresetKey || inheritedPresetKey || "";
              const active = actionRow?.id === r.id;
              return (
                <button
                  key={r.id}
                  type="button"
                  className="card"
                  onClick={() => setActionRow(r)}
                  disabled={busy}
                  style={{
                    borderRadius: 20,
                    padding: 18,
                    background: "#fff",
                    display: "grid",
                    gap: 14,
                    minHeight: 188,
                    textAlign: "left",
                    cursor: busy ? "not-allowed" : "pointer",
                    boxShadow: active ? "0 18px 40px rgba(37,99,235,0.16)" : "0 10px 28px rgba(15,23,42,0.07)",
                    border: active ? "1px solid rgba(37,99,235,0.30)" : "1px solid rgba(15,23,42,0.08)",
                    transition: "transform 180ms ease, box-shadow 180ms ease, border-color 180ms ease",
                  }}
                >
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12 }}>
                    <div style={{ minWidth: 0 }}>
                      <div style={{ fontSize: 17, fontWeight: 900, color: "#0f172a", lineHeight: 1.2, wordBreak: "break-word" }}>{r.name}</div>
                      <div style={{ marginTop: 8, display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
                        <span style={{ fontSize: 15, color: "#334155", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", maxWidth: 160 }}>{destName(r.destinationId)}</span>
                        <StatusPill status={r.serverStatus || "UNKNOWN"} title={r.serverMessage || ""} />
                      </div>
                    </div>
                    <span style={{ fontSize: 12, fontWeight: 800, color: active ? "#2563eb" : "#94a3b8", whiteSpace: "nowrap" }}>Details</span>
                  </div>

                  <div style={{ flex: 1 }} />

                  <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "flex-end" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 10, minWidth: 0 }}>
                      <ChannelIcon />
                      <div style={{ minWidth: 0 }}>
                        <div style={{ fontSize: 15, fontWeight: 700, color: "#0f172a", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", maxWidth: 170 }}>{destName(r.destinationId)}</div>
                        <div style={{ marginTop: 2, fontSize: 12, color: "#64748b", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap", maxWidth: 170 }}>{effectivePresetKey ? presetDisplayName(presetLibrary.find((x) => x.key === effectivePresetKey) || { key: effectivePresetKey }) : "No preset selected"}</div>
                      </div>
                    </div>
                    {typeof r.serverLatencyMs === "number" ? <div style={{ fontSize: 13, fontWeight: 700, color: "#64748b", whiteSpace: "nowrap" }}>{r.serverLatencyMs} ms</div> : null}
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </div>

      {actionRow ? (() => {
        const counts = getCounts(actionRow.id);
        const destination = destinations.find((d) => d.id === (actionRow.destinationId || "")) || null;
        const inheritedPresetKey = destinationDefaultPresetKeyFromConfig(destination?.config);
        const effectivePresetKey = actionRow.defaultPresetKey || inheritedPresetKey || "";
        const presetTitle = effectivePresetKey ? presetDisplayName(presetLibrary.find((x) => x.key === effectivePresetKey) || { key: effectivePresetKey }) : "No preset selected";
        return (
          <div
            style={{
              position: "fixed",
              inset: 0,
              background: "rgba(15,23,42,0.14)",
              zIndex: 80,
              display: "grid",
              placeItems: "center",
              padding: 16,
            }}
            onClick={() => setActionRow(null)}
          >
            <div
              className="card"
              style={{ width: "min(420px, 100%)", borderRadius: 22, padding: 0, overflow: "hidden", boxShadow: "0 24px 60px rgba(15,23,42,0.20)", background: "#fff" }}
              onClick={(e) => e.stopPropagation()}
            >
              <div style={{ padding: "18px 18px 10px", display: "flex", justifyContent: "space-between", gap: 12, alignItems: "flex-start" }}>
                <div style={{ minWidth: 0 }}>
                  <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center", marginBottom: 8 }}>
                    <span style={{ fontSize: 15, color: "#334155" }}>{destName(actionRow.destinationId)}</span>
                    <StatusPill status={actionRow.serverStatus || "UNKNOWN"} title={actionRow.serverMessage || ""} />
                  </div>
                  <div style={{ fontSize: 18, fontWeight: 900, color: "#0f172a", wordBreak: "break-word" }}>{actionRow.name}</div>
                </div>
                <button type="button" onClick={() => setActionRow(null)} aria-label="Close" style={{ border: "none", background: "transparent", color: "#64748b", fontSize: 28, lineHeight: 1, cursor: "pointer", padding: 0 }}>×</button>
              </div>

              <div style={{ padding: "0 18px 18px", display: "grid", gap: 10 }}>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: 10 }}>
                  <div style={{ borderRadius: 16, border: "1px solid rgba(15,23,42,0.10)", background: "#fff", padding: 12 }}>
                    <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: 0.35, textTransform: "uppercase", color: "#64748b", marginBottom: 6 }}>Main profile</div>
                    <div style={{ fontSize: 14, color: "#0f172a", wordBreak: "break-word" }}>{profileLabel(actionRow.mainProfileId)}</div>
                  </div>
                  <div style={{ borderRadius: 16, border: "1px solid rgba(15,23,42,0.10)", background: "#fff", padding: 12 }}>
                    <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: 0.35, textTransform: "uppercase", color: "#64748b", marginBottom: 6 }}>Backup profile</div>
                    <div style={{ fontSize: 14, color: "#0f172a", wordBreak: "break-word" }}>{profileLabel(actionRow.backupProfileId)}</div>
                  </div>
                </div>

                <div style={{ display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: 10 }}>
                  <div style={{ borderRadius: 16, border: "1px solid rgba(15,23,42,0.10)", background: "#f8fafc", padding: 12 }}>
                    <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: 0.35, textTransform: "uppercase", color: "#64748b", marginBottom: 6 }}>Preset</div>
                    <div style={{ fontSize: 14, color: "#0f172a", wordBreak: "break-word" }}>{presetTitle}</div>
                    {effectivePresetKey ? <div style={{ marginTop: 6, fontSize: 11, color: "#64748b", wordBreak: "break-all" }}>{effectivePresetKey}</div> : null}
                  </div>
                  <div style={{ borderRadius: 16, border: "1px solid rgba(15,23,42,0.10)", background: "#f8fafc", padding: 12 }}>
                    <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: 0.35, textTransform: "uppercase", color: "#64748b", marginBottom: 6 }}>Connection</div>
                    <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
                      <StatusPill status={actionRow.serverStatus || "UNKNOWN"} title={actionRow.serverMessage || ""} />
                      {typeof actionRow.serverLatencyMs === "number" ? <span className="badge">{actionRow.serverLatencyMs}ms</span> : null}
                      {actionRow.alignment ? <span className="badge">{actionRow.alignment}</span> : null}
                    </div>
                  </div>
                </div>

                <div style={{ display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: 10 }}>
                  <div style={{ borderRadius: 16, border: "1px solid rgba(15,23,42,0.10)", background: "#fff", padding: 12 }}>
                    <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: 0.35, textTransform: "uppercase", color: "#64748b", marginBottom: 6 }}>Notify emails</div>
                    <div style={{ fontSize: 30, lineHeight: 1, fontWeight: 900, color: "#0f172a" }}>{counts.notifyCount || 0}</div>
                  </div>
                  <div style={{ borderRadius: 16, border: "1px solid rgba(15,23,42,0.10)", background: "#fff", padding: 12 }}>
                    <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: 0.35, textTransform: "uppercase", color: "#64748b", marginBottom: 6 }}>Approval steps</div>
                    <div style={{ fontSize: 30, lineHeight: 1, fontWeight: 900, color: "#0f172a" }}>{counts.stepsCount || 0}</div>
                  </div>
                </div>

                <div style={{ display: "grid", gap: 8, marginTop: 4 }}>
                  <button className="btn btn--primary" onClick={() => { const row = actionRow; setActionRow(null); openEdit(row); }} disabled={busy}>Configure channel</button>
                  <button
                    className="btn btn--ghost"
                    onClick={() => {
                      const row = actionRow;
                      setActionRow(null);
                      void patch(row.id, {
                        destinationId: destinationId || row.destinationId || null,
                        mainProfileId: mainProfileId || null,
                        backupProfileId: backupProfileId || null,
                      });
                    }}
                    disabled={busy}
                    title="Quick-apply the current create form profiles to this channel"
                  >
                    Apply current profiles
                  </button>
                  <button className="btn btn--ghost btn--sm" onClick={() => { const id = actionRow.id; setActionRow(null); void remove(id); }} disabled={busy} style={{ color: "#b91c1c", borderColor: "rgba(185,28,28,0.20)" }}>Delete channel</button>
                </div>
              </div>
            </div>
          </div>
        );
      })() : null}

      <ChannelPresetSelectionModal
        open={createPresetPickerOpen}
        title="Choose default preset"
        subtitle="Pick one preset to auto-fill as the channel default, or leave it empty."
        presets={createPresetOptions}
        selectedKey={defaultPresetKey}
        setSelectedKey={setDefaultPresetKey}
        search={createPresetSearch}
        setSearch={setCreatePresetSearch}
        filter={createPresetFilter}
        setFilter={setCreatePresetFilter}
        onClose={() => setCreatePresetPickerOpen(false)}
      />

      <ChannelPresetSelectionModal
        open={editPresetPickerOpen}
        title={`Choose default preset${edit ? ` · ${edit.row.name}` : ""}`}
        subtitle="Use the same searchable preset picker used in destinations for channel-level default preset selection."
        presets={editPresetOptions}
        selectedKey={edit?.form?.defaultPresetKey || ""}
        setSelectedKey={(next) => {
          if (!edit) return;
          setEdit({ ...edit, form: { ...edit.form, defaultPresetKey: next } });
        }}
        search={editPresetSearch}
        setSearch={setEditPresetSearch}
        filter={editPresetFilter}
        setFilter={setEditPresetFilter}
        onClose={() => setEditPresetPickerOpen(false)}
      />

      {edit && (
        <Modal title={`Configure Channel: ${edit.row.name}`} onClose={() => setEdit(null)}>
          <div style={{ display: "grid", gap: 10 }}>
            <div className="row" style={{ alignItems: "center" }}>
              <input
                value={edit.form.name}
                onChange={(e) => setEdit({ ...edit, form: { ...edit.form, name: e.target.value } })}
                style={{ width: "100%" }}
              />
            </div>

            <div className="row" style={{ alignItems: "center" }}>
              <select
                value={edit.form.destinationId}
                onChange={(e) => {
                  const nextDestinationId = e.target.value;
                  const nextDestination = destinations.find((d) => d.id === nextDestinationId) || null;
                  const nextDefaultPresetKey = destinationDefaultPresetKeyFromConfig(nextDestination?.config);
                  setEdit({
                    ...edit,
                    form: {
                      ...edit.form,
                      destinationId: nextDestinationId,
                      defaultPresetKey: edit.form.defaultPresetKey || nextDefaultPresetKey || "",
                    },
                  });
                }}
              >
                {destinations.map((d) => (
                  <option key={d.id} value={d.id}>
                    {d.name}
                  </option>
                ))}
              </select>

              <select
                value={edit.form.mainProfileId}
                onChange={(e) => setEdit({ ...edit, form: { ...edit.form, mainProfileId: e.target.value } })}
              >
                <option value="">Main profile (optional)</option>
                {profiles.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({p.protocol})
                  </option>
                ))}
              </select>

              <select
                value={edit.form.backupProfileId}
                onChange={(e) => setEdit({ ...edit, form: { ...edit.form, backupProfileId: e.target.value } })}
              >
                <option value="">Backup profile (optional)</option>
                {profiles.map((p) => (
                  <option key={p.id} value={p.id}>
                    {p.name} ({p.protocol})
                  </option>
                ))}
              </select>

              <select
                value={edit.form.alignment || ""}
                onChange={(e) => setEdit({ ...edit, form: { ...edit.form, alignment: (e.target.value as "" | LogoPosition) || "" } })}
              >
                <option value="">Logo position (optional)</option>
                {LOGO_POSITION_OPTIONS.map((pos) => (
                  <option key={pos} value={pos}>
                    {pos}
                  </option>
                ))}
              </select>
            </div>

            <div className="card card--soft" style={{ padding: 12, display: "grid", gap: 8 }}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, flexWrap: "wrap" }}>
                <div>
                  <div style={{ fontSize: 13, fontWeight: 800, color: "#0f172a" }}>Preset</div>
                </div>
                {edit.form.defaultPresetKey ? (
                  <span className="badge" title={presetLabel(edit.form.defaultPresetKey)} style={{ whiteSpace: "nowrap" }}>
                    {presetLabel(edit.form.defaultPresetKey)}
                  </span>
                ) : editDestinationDefaultPresetKey ? (
                  <span className="badge" title={presetLabel(editDestinationDefaultPresetKey)} style={{ whiteSpace: "nowrap" }}>
                    Inherit {presetLabel(editDestinationDefaultPresetKey)}
                  </span>
                ) : (
                  <span className="badge">No preset selected</span>
                )}
              </div>
              <ChannelPresetSelectionSummary
                selectedKey={edit.form.defaultPresetKey}
                presets={editPresetOptions}
                description=""
                onOpen={() => setEditPresetPickerOpen(true)}
                onClear={() => setEdit({ ...edit, form: { ...edit.form, defaultPresetKey: "" } })}
              />
              <label style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13, fontWeight: 700, color: (edit.form.defaultPresetKey || editDestinationDefaultPresetKey) ? "#0f172a" : "#94a3b8" }}>
                <input
                  type="checkbox"
                  checked={Boolean(edit.form.transcodeOnCommit)}
                  disabled={!(edit.form.defaultPresetKey || editDestinationDefaultPresetKey)}
                  onChange={(e) => setEdit({ ...edit, form: { ...edit.form, transcodeOnCommit: e.target.checked } })}
                />
                Auto transcode after commit
              </label>
            </div>

            <div className="row">
              <input
                placeholder="Notification emails (comma separated)"
                value={edit.form.notificationEmails}
                onChange={(e) => setEdit({ ...edit, form: { ...edit.form, notificationEmails: e.target.value } })}
                style={{ width: "100%" }}
              />
            </div>

            <div className="row" style={{ alignItems: "center" }}>
              <select
                value={edit.form.approverMode}
                onChange={(e) => {
                  const nextMode = e.target.value as ApprovalModeUi;
                  setEdit({
                    ...edit,
                    form: {
                      ...edit.form,
                      approverMode: nextMode,
                      steps: nextMode !== "NONE" && (!Array.isArray(edit.form.steps) || !edit.form.steps.length) ? [defaultApprovalStep()] : edit.form.steps,
                    },
                  });
                }}
              >
                <option value="NONE">Approvals: NONE</option>
                <option value="PARALLEL">Approvals: PARALLEL</option>
                <option value="SEQUENTIAL">Approvals: SEQUENTIAL</option>
              </select>
            </div>

            {edit.form.approverMode === "NONE" ? (
              <div className="card" style={{ padding: 12, borderColor: "rgba(0,0,0,0.08)", background: "rgba(148,163,184,0.08)" }}>
                <div style={{ fontSize: 13, fontWeight: 700 }}>No approval required for this channel.</div>
                <div style={{ fontSize: 12, opacity: 0.72 }}>Files on this channel will skip approval routing.</div>
              </div>
            ) : renderStepsEditor(edit.form.steps, (next) => setEdit({ ...edit, form: { ...edit.form, steps: next } }))}

<div className="row" style={{ alignItems: "center", justifyContent: "space-between" }}>
  <button className="btn btn--ghost btn--sm" type="button" onClick={() => setShowAdvancedEdit((v) => !v)} disabled={busy}>
    {showAdvancedEdit ? "Advanced ▲" : "Advanced ▼"}
  </button>
  <div style={{ fontSize: 12, opacity: 0.7 }}>
    Metadata XML: <b>{edit.form.xmlEnabled ? "ON" : "OFF"}</b>
  </div>
</div>

{showAdvancedEdit ? (
  <div className="card" style={{ padding: 12, borderColor: "rgba(0,0,0,0.12)" }}>
    <div className="row" style={{ justifyContent: "space-between", alignItems: "center" }}>
      <div style={{ fontWeight: 900 }}>Metadata XML (optional)</div>
      <label style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 12, fontWeight: 800 }}>
        <input
          type="checkbox"
          checked={edit.form.xmlEnabled}
          onChange={(e) => {
            const on = e.target.checked;
            const nextXmlText =
              on && (!edit.form.xmlConfigText || !edit.form.xmlConfigText.trim() || edit.form.xmlConfigText.trim() === "{}")
                ? defaultXmlConfigJson()
                : edit.form.xmlConfigText;

            setEdit({ ...edit, form: { ...edit.form, xmlEnabled: on, xmlConfigText: nextXmlText } });
          }}
        />
        Enable
      </label>
    </div>

    {edit.form.xmlEnabled ? (
      <div style={{ marginTop: 10, display: "grid", gap: 8 }}>
        <div style={{ fontSize: 12, fontWeight: 700 }}>XML config (JSON)</div>
        <textarea
          style={{ width: "100%", maxWidth: "100%", minHeight: 140, fontFamily: "monospace", boxSizing: "border-box" }}
          value={edit.form.xmlConfigText}
          onChange={(e) => setEdit({ ...edit, form: { ...edit.form, xmlConfigText: e.target.value } })}
        />
        <div style={{ fontSize: 12, opacity: 0.75 }}>
          Placeholders: <code>{"{TASK_ID}"}</code>, <code>{"{VALID}"}</code>, <code>{"{FILENAME}"}</code>,{" "}
          <code>{"{REMOTE_PATH}"}</code>, <code>{"{BASENAME}"}</code>, <code>{"{GENERATED_AT}"}</code>
        </div>

        <div style={{ fontSize: 12, fontWeight: 800 }}>Preview</div>
        <div className="row" style={{ justifyContent: "space-between", alignItems: "center", gap: 8 }}>
          <div style={{ fontSize: 12, opacity: 0.8 }}>
            File: <span style={{ fontWeight: 900 }}>{editXmlFileName || "—"}</span> &nbsp;•&nbsp; Remote:{" "}
            <span style={{ fontWeight: 900 }}>{editXmlRemotePath || "—"}</span>
          </div>
          <button type="button" onClick={() => copyToClipboard(editXmlPreview)} disabled={!editXmlPreview}>
            Copy
          </button>
        </div>
        <pre
          style={{
            margin: 0,
            padding: 10,
            borderRadius: 10,
            border: "1px solid rgba(0,0,0,0.12)",
            background: "rgba(0,0,0,0.03)",
            overflowX: "auto",
            whiteSpace: "pre",
            fontSize: 12,
            lineHeight: 1.3,
          }}
        >
          {editXmlPreview}
        </pre>
      </div>
    ) : (
      <div style={{ marginTop: 8, fontSize: 12, opacity: 0.7 }}>
        When enabled, the Delivery Worker will generate an XML sidecar and send it with the media file.
      </div>
    )}
  </div>
) : null}
            <div className="row" style={{ justifyContent: "flex-end", gap: 8 }}>
              <button className="btn btn--ghost" onClick={() => setEdit(null)} disabled={busy}>Cancel</button>
              <button className="btn btn--primary"
                onClick={async () => {
                  const approvalPayload = buildApprovalPayload((edit.form.approverMode || "PARALLEL") as ApprovalModeUi, edit.form.steps || []);
                  const payload = {
                    name: String(edit.form.name || "").trim(),
                    destinationId: edit.form.destinationId || null,
                    mainProfileId: edit.form.mainProfileId || null,
                    backupProfileId: edit.form.backupProfileId || null,
                    alignment: edit.form.alignment || null,
                    defaultPresetKey: edit.form.defaultPresetKey || null,
                    transcodeOnCommit: Boolean(edit.form.transcodeOnCommit),
                    notificationEmails: parseEmails(edit.form.notificationEmails || ""),
                    ...approvalPayload,
                  } as any;
                  const currentConfig = edit.row.config && typeof edit.row.config === "object" ? { ...(edit.row.config as any) } : {};
                  if (edit.form.xmlEnabled) {
                    currentConfig.xml = { ...safeJsonParse(String(edit.form.xmlConfigText || "{}"), {}), enabled: true };
                  } else {
                    delete currentConfig.xml;
                  }
                  payload.config = currentConfig;
                  await patch(edit.row.id, payload);
                  setEdit(null);
                  if (returnTo && returnOnSave) {
                    goBackToDeliverySetup(edit.form.destinationId || edit.row.destinationId || filterDestinationId);
                    return;
                  }
                  }}
                disabled={busy}
              >
                Save
              </button>
            </div>

            {err && <div className="card" style={{ borderColor: "#f5a", background: "#fff5fa" }}>{err}</div>}
          </div>
        </Modal>
      )}
    </div>
  );
}
