import { useEffect, useMemo, useState } from "react";
import { listMasters } from "../mastersApi";
import type { SelectOption } from "../types";
import { MasterCreateFormPage } from "../MasterCreateFormPage";
import { BRANDS_CREATE_PERMISSIONS } from "../mastersPermissions";

type AdvertiserRow = { id: string; name: string; status?: string };

export function BrandsCreatePage() {
  const [advertisers, setAdvertisers] = useState<SelectOption[]>([]);

  useEffect(() => {
    listMasters<AdvertiserRow>("/masters/advertisers")
      .then((rows) => rows.map((r) => ({ value: r.id, label: `${r.name}${r.status === "INACTIVE" ? " (inactive)" : ""}` })))
      .then(setAdvertisers)
      .catch(() => setAdvertisers([]));
  }, []);

  const fields = useMemo(
    () => [
      { name: "name", label: "Name", type: "text" as const, required: true },
      { name: "advertiserId", label: "Advertiser", type: "select" as const, required: true, options: advertisers },
      { name: "emails", label: "Email IDs", type: "emails" as const, help: "You can add multiple emails using comma" },
      { name: "contactNo", label: "Contact No", type: "text" as const },
      { name: "address", label: "Address", type: "textarea" as const },
      { name: "gstNumber", label: "GST Number", type: "text" as const },
      { name: "panNumber", label: "PAN Number", type: "text" as const },
      { name: "remarks", label: "Remarks", type: "textarea" as const },
    ],
    [advertisers],
  );

  return (
    <MasterCreateFormPage
      heading="Add Brand"
      apiPath="/masters/brands"
      backTo="/masters/brands"
      fields={fields}
      submitLabel="Add Brand"
          createPermissionsAny={[...BRANDS_CREATE_PERMISSIONS]}
    />
  );
}
