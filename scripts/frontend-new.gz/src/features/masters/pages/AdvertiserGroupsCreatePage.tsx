import { MasterCreateFormPage } from "../MasterCreateFormPage";
import { ADVERTISER_GROUPS_CREATE_PERMISSIONS } from "../mastersPermissions";

export function AdvertiserGroupsCreatePage() {
  const fields = [
    { name: "name", label: "Advertiser Group Name", type: "text" as const, required: true, placeholder: "#Name" },
    {
      name: "emails",
      label: "Emails",
      type: "emails" as const,
      placeholder: "Type email(s) and press Enter",
      help: "Optional: emails used for approvals/notifications for this Advertiser Group.",
      fullWidth: true,
    },
    { name: "remarks", label: "Remarks", type: "textarea" as const, placeholder: "Enter a value..." },
  ];

  return (
    <MasterCreateFormPage
      heading="Add Advertiser Group"
      apiPath="/masters/advertiser-groups"
      backTo="/masters/advertiser-groups"
      fields={fields}
      submitLabel="Add Advertiser Group"
      createPermissionsAny={[...ADVERTISER_GROUPS_CREATE_PERMISSIONS]}
    />
  );
}
