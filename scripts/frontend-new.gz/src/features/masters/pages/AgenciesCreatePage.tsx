import { useMemo } from "react";
import { useSearchParams } from "react-router-dom";
import { MasterCreateFormPage } from "../MasterCreateFormPage";
import { AGENCIES_CREATE_PERMISSIONS } from "../mastersPermissions";

const AGENCY_TYPES = ["MEDIA", "CREATIVE", "POST_HOUSE", "PRODUCTION_HOUSE", "AUDIO", "UPLOADER"] as const;
type AgencyType = (typeof AGENCY_TYPES)[number];

function prettyType(t: string) {
  switch (t) {
    case "MEDIA":
      return "Media Agency";
    case "CREATIVE":
      return "Creative Agency";
    case "POST_HOUSE":
      return "Post House";
    case "PRODUCTION_HOUSE":
      return "Production House";
    case "AUDIO":
      return "Audio Agency";
    case "UPLOADER":
      return "Uploader Agency";
    default:
      return t;
  }
}

function normalizeTypeParam(v: string | null): AgencyType | null {
  if (!v) return null;
  const up = v.toUpperCase();
  return (AGENCY_TYPES as readonly string[]).includes(up) ? (up as AgencyType) : null;
}

export function AgenciesCreatePage() {
  const [sp] = useSearchParams();

  const typeFromUrl = normalizeTypeParam(sp.get("type"));
  const defaultType: AgencyType = typeFromUrl ?? "MEDIA";

  const typeOptions = useMemo(
    () => AGENCY_TYPES.map((t) => ({ value: t, label: `${prettyType(t)} (${t})` })),
    []
  );

  const fields = useMemo(
    () => [
      // ✅ full width + inline "Add" beside dropdown (like your reference UI)
      { name: "type", label: "Select Account", type: "select" as const, required: true, options: typeOptions, fullWidth: true },

      { name: "name", label: "Name", type: "text" as const, required: true },
      { name: "contactNo", label: "Contact No", type: "text" as const },
      { name: "gstNumber", label: "GST Number", type: "text" as const },
      { name: "panNumber", label: "PAN Number", type: "text" as const },
      { name: "address", label: "Address", type: "textarea" as const },
      {
        name: "emails",
        label: "Email IDs",
        type: "emails" as const,
        help: "You can add multiple emails using comma",
      },
      { name: "remarks", label: "Remarks", type: "textarea" as const },
    ],
    [typeOptions]
  );

  return (
    <MasterCreateFormPage
      heading="Add Master"
      apiPath="/masters/agencies"
      backTo="/masters/agency-hub?type=MEDIA&view=group"
      fields={fields}
      defaultCreate={{ type: defaultType }}

      // ✅ Bottom button changes based on selected account type
      submitLabel={(form) => {
        const t = String(form.type || defaultType).toUpperCase();
        return `Add ${prettyType(t)}`;
      }}

      // ✅ Shows the "Add" button beside the account dropdown
      inlineSelectAction={{
        fieldName: "type",
        label: "Add",
        onClick: () => {
          // no-op: visual button only (as per reference image)
          // you can later use this to open "Add Team" section etc.
        },
      }}
          createPermissionsAny={[...AGENCIES_CREATE_PERMISSIONS]}
    />
  );
}
