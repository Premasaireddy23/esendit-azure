import { MasterCreateFormPage } from "../MasterCreateFormPage";
import { PRODUCT_CATEGORIES_CREATE_PERMISSIONS } from "../mastersPermissions";

export function ProductCategoriesCreatePage() {
  const fields = [{ name: "name", label: "Name", type: "text" as const, required: true, placeholder: "e.g. FMCG" }];

  return (
    <MasterCreateFormPage
      heading="Add Product Category"
      apiPath="/masters/product-categories"
      backTo="/masters/product-categories"
      fields={fields}
      submitLabel="Add Product Category"
          createPermissionsAny={[...PRODUCT_CATEGORIES_CREATE_PERMISSIONS]}
    />
  );
}
