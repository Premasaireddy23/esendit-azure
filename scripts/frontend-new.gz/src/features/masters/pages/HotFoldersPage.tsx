import { useEffect, useState } from "react";
import { getMe, hasAnyPerm, type MeResponse } from "../../../lib/me";
import {
  HOT_FOLDERS_CREATE_PERMISSIONS,
  HOT_FOLDERS_DELETE_PERMISSIONS,
  HOT_FOLDERS_UPDATE_PERMISSIONS,
} from "../mastersPermissions";
import { MasterCrudPage } from "../MasterCrudPage";

type HotFolderSourceType = "LOCAL_PATH" | "SMB" | "SFTP" | "AZURE_BLOB" | "S3";
type MasterStatus = "ACTIVE" | "INACTIVE";
type MappingMode = "CREATIVE_ID" | "VALID_FROM_FILENAME" | "ADVANCED_JSON";

type HotFolderRow = {
  id: string;
  name: string;
  sourceType: HotFolderSourceType;
  basePath: string;
  pollIntervalSec: number;
  enabled: boolean;
  connectionConfig?: any;
  mappingRules?: any;
  qcEnabled: boolean;
  qcConfig?: any;
  remarks?: string | null;
  status: MasterStatus;
  createdAt?: string;
  updatedAt?: string;
};

function parseReplaceTokens(text: string | undefined): Record<string, string> | undefined {
  const t = String(text || "").trim();
  if (!t) return undefined;
  const out: Record<string, string> = {};
  const lines = t.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  for (const l of lines) {
    const m = l.split(/=|:/);
    const k = String(m[0] || "").trim().toUpperCase();
    const v = String(m.slice(1).join("=") || "").trim().toUpperCase();
    if (!k) continue;
    out[k.replace(/[^A-Z0-9]/g, "")] = v;
  }
  return Object.keys(out).length ? out : undefined;
}

function parseStripTokens(text: string | undefined): string[] | undefined {
  const t = String(text || "").trim();
  if (!t) return undefined;
  const tokens = t
    .split(/[,\r\n]/)
    .map((s) => s.trim())
    .filter(Boolean)
    .map((s) => s.toUpperCase().replace(/[^A-Z0-9]/g, ""))
    .filter(Boolean);
  return tokens.length ? Array.from(new Set(tokens)) : undefined;
}

function formatReplaceTokens(obj: any): string {
  if (!obj || typeof obj !== "object") return "";
  return Object.entries(obj)
    .map(([k, v]) => `${String(k).toUpperCase()}=${String(v ?? "").toUpperCase()}`)
    .join("\n");
}

function formatStripTokens(arr: any): string {
  if (!Array.isArray(arr)) return "";
  return arr.map((x) => String(x).toUpperCase()).join("\n");
}

function boolToSelect(v: any, def = false) {
  const b = typeof v === "boolean" ? v : String(v ?? "").toLowerCase() === "true";
  return (b ?? def) ? "true" : "false";
}

function pretty(v: any) {
  try {
    return JSON.stringify(v ?? {}, null, 2);
  } catch {
    return "{}";
  }
}

function safeJsonParse(text: any, fallback: any) {
  try {
    if (text === undefined || text === null) return fallback;
    if (typeof text !== "string") return text;
    if (!text.trim()) return fallback;
    return JSON.parse(text);
  } catch {
    return fallback;
  }
}

export function HotFoldersPage() {
  const [me, setMe] = useState<MeResponse | null>(null);
  useEffect(() => {
    getMe().then(setMe).catch(() => setMe(null));
  }, []);

  return (
    <MasterCrudPage<HotFolderRow>
      title="Hot Folders"
      path="/masters/hot-folders"
      supportsInactive
      canCreate={hasAnyPerm(me, [...HOT_FOLDERS_CREATE_PERMISSIONS])}
      canUpdate={hasAnyPerm(me, [...HOT_FOLDERS_UPDATE_PERMISSIONS])}
      canDelete={hasAnyPerm(me, [...HOT_FOLDERS_DELETE_PERMISSIONS])}
      columns={[
        { key: "name", label: "Name" },
        { key: "sourceType", label: "Source" },
        { key: "basePath", label: "Base Path" },
        {
          key: "mappingMode",
          label: "Mapping",
          render: (r: any) =>
            r.mappingMode === "CREATIVE_ID"
              ? "Creative"
              : r.mappingMode === "VALID_FROM_FILENAME"
                ? "VALID from filename"
                : "Advanced",
        },
        { key: "enabled", label: "Enabled", render: (r) => (String(r.enabled) === "true" ? "Yes" : "No") },
        { key: "pollIntervalSec", label: "Poll (sec)" },
        { key: "qcEnabled", label: "Auto QC", render: (r) => (String(r.qcEnabled) === "true" ? "Yes" : "No") },
        { key: "status", label: "Status" },
      ]}
      fields={[
        { name: "name", label: "Name", type: "text", required: true, placeholder: "e.g. Mumbai Hot Folder" },
        {
          name: "sourceType",
          label: "Source Type",
          type: "select",
          required: true,
          options: [
            { value: "LOCAL_PATH", label: "Local Path" },
            { value: "SMB", label: "SMB" },
            { value: "SFTP", label: "SFTP" },
            { value: "AZURE_BLOB", label: "Azure Blob" },
            { value: "S3", label: "S3" },
          ],
        },
        { name: "basePath", label: "Base Path / Prefix", type: "text", required: true, placeholder: "/mnt/hot" },
        {
          name: "pollIntervalSec",
          label: "Poll Interval (sec)",
          type: "text",
          placeholder: "60",
          help: "How often to scan the folder/prefix.",
        },
        {
          name: "enabled",
          label: "Enabled",
          type: "select",
          options: [
            { value: "true", label: "Yes" },
            { value: "false", label: "No" },
          ],
        },
        {
          name: "qcEnabled",
          label: "Auto QC Enabled",
          type: "select",
          options: [
            { value: "false", label: "No" },
            { value: "true", label: "Yes" },
          ],
        },

        // --- Mapping (Admin configurable) ---
        {
          name: "mappingMode",
          label: "Mapping Mode",
          type: "select",
          options: [
            { value: "VALID_FROM_FILENAME", label: "VALID from filename (recommended)" },
            { value: "CREATIVE_ID", label: "Attach to specific Creative (Option A)" },
            { value: "ADVANCED_JSON", label: "Advanced (raw JSON)" },
          ],
          help: "Choose how files map to creatives. For your naming like JAN26_Jio_BP_Petrol_MSD_10Sec_TEL_HD.mov use VALID from filename.",
        },

        { name: "ruleProjectId", label: "Project ID (for VALID mode)", type: "text", placeholder: "<project-uuid>", help: "Required when Mapping Mode = VALID from filename." },
        { name: "ruleCreativeId", label: "Creative ID (for Creative mode)", type: "text", placeholder: "<creative-uuid>", help: "Required when Mapping Mode = Attach to specific Creative." },

        {
          name: "enforceMonthYearPrefix",
          label: "Require Month+Year prefix (e.g., JAN26)",
          type: "select",
          options: [
            { value: "true", label: "Yes" },
            { value: "false", label: "No" },
          ],
          help: "If Yes, filename must start with MMMYY (JAN26/FEB26/etc).",
        },
        { name: "monthYearPrefix", label: "Month+Year override (optional)", type: "text", placeholder: "JAN26", help: "If your filename doesn't include MMMYY prefix, set it here." },

        {
          name: "stripUnderscores",
          label: "Strip underscores (_) from caption",
          type: "select",
          options: [
            { value: "true", label: "Yes" },
            { value: "false", label: "No" },
          ],
        },
        {
          name: "stripNonAlnum",
          label: "Strip non-alphanumeric characters",
          type: "select",
          options: [
            { value: "true", label: "Yes" },
            { value: "false", label: "No" },
          ],
          help: "Recommended: converts caption to A-Z0-9 only.",
        },

        {
          name: "captionReplaceTokensText",
          label: "Replace tokens (one per line: FROM=TO)",
          type: "textarea",
          placeholder: "PETROL=PETRO",
          help: "Example: PETROL=PETRO. Tokens are uppercased and applied before final sanitization.",
        },
        {
          name: "captionStripTokensText",
          label: "Remove tokens (one per line or comma-separated)",
          type: "textarea",
          placeholder: "SEC",
          help: "Example: SEC removes SEC from 10SEC.",
        },

        {
          name: "autoCreateCreative",
          label: "Auto-create Creative if VALID not found",
          type: "select",
          options: [
            { value: "false", label: "No (safer)" },
            { value: "true", label: "Yes" },
          ],
        },

        {
          name: "queueAutoQc",
          label: "Queue AUTO_QC job",
          type: "select",
          options: [
            { value: "true", label: "Yes" },
            { value: "false", label: "No" },
          ],
        },
        {
          name: "queueProxy",
          label: "Queue PROXY job",
          type: "select",
          options: [
            { value: "false", label: "No" },
            { value: "true", label: "Yes" },
          ],
        },

        {
          name: "mappingRulesRaw",
          label: "Mapping Rules (Advanced JSON)",
          type: "textarea",
          fullWidth: true,
          placeholder: "{}",
          help: "Only used when Mapping Mode = Advanced. For most cases use the fields above.",
        },
        {
          name: "connectionConfig",
          label: "Connection Config (JSON)",
          type: "textarea",
          fullWidth: true,
          placeholder: "{}",
          help: "Connector config for SMB/SFTP/Blob/S3. For LOCAL_PATH you can leave {}.",
        },
        {
          name: "qcConfig",
          label: "QC Config (JSON)",
          type: "textarea",
          fullWidth: true,
          placeholder: "{}",
          help: "Optional QC settings/profile for this hot folder.",
        },
        { name: "remarks", label: "Remarks", type: "textarea", fullWidth: true, placeholder: "" },
        {
          name: "status",
          label: "Status",
          type: "select",
          options: [
            { value: "ACTIVE", label: "ACTIVE" },
            { value: "INACTIVE", label: "INACTIVE" },
          ],
        },
      ]}
      defaultCreate={{
        pollIntervalSec: "60",
        // ✅ default to Disabled; configure mapping first, then enable.
        enabled: "false",
        qcEnabled: "false",
        mappingMode: "VALID_FROM_FILENAME",
        ruleProjectId: "",
        ruleCreativeId: "",
        enforceMonthYearPrefix: "true",
        monthYearPrefix: "",
        stripUnderscores: "true",
        stripNonAlnum: "true",
        captionReplaceTokensText: "",
        captionStripTokensText: "",
        autoCreateCreative: "false",
        queueAutoQc: "true",
        queueProxy: "false",
        connectionConfig: pretty({}),
        mappingRulesRaw: pretty({}),
        qcConfig: pretty({}),
        status: "ACTIVE",
      }}
      toPayload={(form) => {
        const poll = form.pollIntervalSec !== undefined ? Number(form.pollIntervalSec) : undefined;

        const enabled = String(form.enabled ?? "false") === "true";
        const qcEnabled = String(form.qcEnabled ?? "false") === "true";

        const connectionConfig = safeJsonParse(form.connectionConfig, {});
        const qcConfig = safeJsonParse(form.qcConfig, {});

        const mode = (form.mappingMode || "ADVANCED_JSON") as MappingMode;

        const queueAutoQc = String(form.queueAutoQc ?? "true") === "true";
        const queueProxy = String(form.queueProxy ?? "false") === "true";

        let mappingRules: any = {};

        if (mode === "CREATIVE_ID") {
          const creativeId = String(form.ruleCreativeId || "").trim();
          mappingRules = {
            creativeId: creativeId || undefined,
            queueAutoQc,
            queueProxy,
          };
        } else if (mode === "VALID_FROM_FILENAME") {
          const projectId = String(form.ruleProjectId || "").trim();
          const replaceTokens = parseReplaceTokens(form.captionReplaceTokensText);
          const stripTokens = parseStripTokens(form.captionStripTokensText);
          const monthYearPrefix = String(form.monthYearPrefix || "").trim();

          mappingRules = {
            projectId: projectId || undefined,
            validIdFromFilename: true,
            enforceMonthYearPrefix: String(form.enforceMonthYearPrefix ?? "true") === "true",
            stripUnderscores: String(form.stripUnderscores ?? "true") === "true",
            stripNonAlnum: String(form.stripNonAlnum ?? "true") === "true",
            monthYearPrefix: monthYearPrefix || undefined,
            captionReplaceTokens: replaceTokens,
            captionStripTokens: stripTokens,
            autoCreateCreative: String(form.autoCreateCreative ?? "false") === "true",
            queueAutoQc,
            queueProxy,
          };
        } else {
          mappingRules = safeJsonParse(form.mappingRulesRaw, {});
        }

        // drop undefined keys for cleaner payload
        if (mappingRules && typeof mappingRules === "object") {
          for (const k of Object.keys(mappingRules)) {
            if (mappingRules[k] === undefined) delete mappingRules[k];
          }
        }

        // ✅ return ONLY fields backend DTO accepts (ValidationPipe whitelist = true)
        return {
          name: form.name,
          sourceType: form.sourceType,
          basePath: form.basePath,
          pollIntervalSec: Number.isFinite(poll) ? poll : undefined,
          enabled,
          qcEnabled,
          status: form.status,
          remarks: form.remarks,
          connectionConfig,
          mappingRules,
          qcConfig,
        };
      }}
      transformRows={(rows) =>
        rows.map((r: any) => {
          const mr = safeJsonParse(r.mappingRules, {});
          const mode: MappingMode = mr?.creativeId
            ? "CREATIVE_ID"
            : mr?.validIdFromFilename
              ? "VALID_FROM_FILENAME"
              : "ADVANCED_JSON";

          return {
            ...r,

            // ✅ strings for select inputs
            enabled: boolToSelect(r.enabled, false),
            qcEnabled: boolToSelect(r.qcEnabled, false),
            pollIntervalSec: r.pollIntervalSec ? String(r.pollIntervalSec) : "",

            // JSON fields as formatted strings
            connectionConfig: typeof r.connectionConfig === "string" ? r.connectionConfig : pretty(r.connectionConfig),
            qcConfig: typeof r.qcConfig === "string" ? r.qcConfig : pretty(r.qcConfig),

            // mapping form fields (derived from mappingRules)
            mappingMode: mode,
            ruleProjectId: mr?.projectId || "",
            ruleCreativeId: mr?.creativeId || "",
            enforceMonthYearPrefix: boolToSelect(mr?.enforceMonthYearPrefix, true),
            monthYearPrefix: mr?.monthYearPrefix || "",
            stripUnderscores: boolToSelect(mr?.stripUnderscores, true),
            stripNonAlnum: boolToSelect(mr?.stripNonAlnum, true),
            captionReplaceTokensText: formatReplaceTokens(mr?.captionReplaceTokens),
            captionStripTokensText: formatStripTokens(mr?.captionStripTokens),
            autoCreateCreative: boolToSelect(mr?.autoCreateCreative, false),
            queueAutoQc: boolToSelect(mr?.queueAutoQc, true),
            queueProxy: boolToSelect(mr?.queueProxy, false),
            mappingRulesRaw: pretty(mr),
          };
        })
      }
    />
  );
}
