import { useEffect, useMemo, useState } from "react";
import { getMe, hasAnyPerm, type MeResponse } from "../../../lib/me";
import {
  ADVERTISERS_CREATE_PERMISSIONS,
  ADVERTISERS_DELETE_PERMISSIONS,
  ADVERTISERS_UPDATE_PERMISSIONS,
} from "../mastersPermissions";
import { listMasters } from "../mastersApi";
import { MasterCrudPage } from "../MasterCrudPage";
import type { SelectOption } from "../types";

type GroupRow = { id: string; name: string; status?: string };

export function AdvertisersPage() {
  const [me, setMe] = useState<MeResponse | null>(null);
  const [groups, setGroups] = useState<SelectOption[]>([]);

  useEffect(() => {
    getMe().then(setMe).catch(() => setMe(null));
  }, []);

  useEffect(() => {
    listMasters<GroupRow>("/masters/advertiser-groups")
      .then((rows) =>
        rows.map((r) => ({
          value: r.id,
          label: `${r.name}${r.status === "INACTIVE" ? " (inactive)" : ""}`,
        })),
      )
      .then(setGroups)
      .catch(() => setGroups([]));
  }, []);

  const fields = useMemo(
    () => [
      { name: "name", label: "Name", type: "text" as const, required: true, placeholder: "e.g. Advertiser A" },
      {
        name: "advertiserGroupId",
        label: "Advertiser Group",
        type: "select" as const,
        options: groups,
        placeholder: "optional",
      },
      { name: "emails", label: "Emails", type: "emails" as const, placeholder: "a@x.com, b@x.com", help: "Comma-separated" },
            { name: "contactNo", label: "Contact No", type: "text" as const, placeholder: "optional" },
      { name: "gstNumber", label: "GST No", type: "text" as const, placeholder: "optional" },
      { name: "panNumber", label: "PAN No", type: "text" as const, placeholder: "optional" },
      { name: "address", label: "Address", type: "textarea" as const, placeholder: "optional" },
      { name: "remarks", label: "Remarks", type: "textarea" as const, placeholder: "optional" },
    ],
    [groups],
  );

  return (
    <MasterCrudPage
      title="Advertisers"
      path="/masters/advertisers"
      canCreate={hasAnyPerm(me, [...ADVERTISERS_CREATE_PERMISSIONS])}
      canUpdate={hasAnyPerm(me, [...ADVERTISERS_UPDATE_PERMISSIONS])}
      canDelete={hasAnyPerm(me, [...ADVERTISERS_DELETE_PERMISSIONS])}
      columns={[
        { key: "name", label: "Name" },
        { key: "advertiserGroupId", label: "GroupId" },
        {
          key: "emails",
          label: "Emails",
          render: (r: any) => (Array.isArray(r.emails) ? r.emails.join(", ") : ""),
        },
        { key: "status", label: "Status" },
      ]}
      fields={fields}
      supportsInactive
      supportsEnableAndPermanentDelete
      enhancedCrudUi
      createTo="/masters/advertisers/new"
      createLabel="Add"
    />
  );
}
