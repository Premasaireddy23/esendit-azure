import { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { AdvertiserGroupsPage } from "./AdvertiserGroupsPage";
import { AdvertisersPage } from "./AdvertisersPage";
import { BrandsPage } from "./BrandsPage";
import { ProductCategoriesPage } from "./ProductCategoriesPage";
import { HotFoldersPage } from "./HotFoldersPage";
import { AccountsPage } from "./AccountsPage";
import { getMe, type MeResponse } from "../../../lib/me";
import {
  canSeeMasterSection,
  isMasterSectionKey,
  MASTER_SECTION_TABS,
  type MasterSectionKey,
} from "../MasterSectionTabs";

export function MastersHomePage() {
  const [sp] = useSearchParams();
  const [me, setMe] = useState<MeResponse | null>(null);

  useEffect(() => {
    getMe().then(setMe).catch(() => setMe(null));
  }, []);

  const visibleSections = useMemo(() => {
    return MASTER_SECTION_TABS.filter((section) => canSeeMasterSection(me, section.key));
  }, [me]);

  const activeSection: MasterSectionKey = useMemo(() => {
    const requested = sp.get("section");
    if (isMasterSectionKey(requested) && visibleSections.some((section) => section.key === requested)) {
      return requested;
    }
    return visibleSections[0]?.key ?? "advertiser-groups";
  }, [sp, visibleSections]);

  const activeMeta = useMemo(
    () => visibleSections.find((section) => section.key === activeSection) ?? visibleSections[0] ?? MASTER_SECTION_TABS[0],
    [activeSection, visibleSections],
  );

  return (
    <div style={{ display: "grid", gap: 12 }}>
      {visibleSections.length ? (
        <>
          <div style={{ display: "grid", gap: 8, justifyItems: "start" }}>
            <div style={{ fontSize: 20, fontWeight: 900 }}>{activeMeta.label}</div>
            {activeMeta.description ? <div style={{ opacity: 0.78, maxWidth: 920 }}>{activeMeta.description}</div> : null}
          </div>

          {activeSection === "advertiser-groups" ? <AdvertiserGroupsPage /> : null}
          {activeSection === "advertisers" ? <AdvertisersPage /> : null}
          {activeSection === "brands" ? <BrandsPage /> : null}
          {activeSection === "product-categories" ? <ProductCategoriesPage /> : null}
          {activeSection === "hot-folders" ? <HotFoldersPage /> : null}
          {activeSection === "accounts" ? <AccountsPage /> : null}
        </>
      ) : (
        <div className="card" style={{ padding: 16 }}>
          No master sections are assigned to this user.
        </div>
      )}
    </div>
  );
}
