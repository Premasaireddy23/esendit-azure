import { useMemo } from "react";
import { MasterCreateFormPage } from "../MasterCreateFormPage";
import { ACCOUNTS_CREATE_PERMISSIONS } from "../accountsPermissions";

export function PartnerAccountsCreatePage() {
  const fields = useMemo(
    () => [
      { name: "name", label: "Account Name", type: "text" as const, required: true, placeholder: "e.g. Zee TV / JioCinema" },
      {
        name: "accountType",
        label: "Account Type",
        type: "segmented" as const,
        required: true,
        options: [
          { value: "SENDER", label: "Sender Account" },
          { value: "RECEIVER", label: "Receiver Account" },
        ],
        help: "Sender=your organization. Receiver=TV/Digital/OTT/Cinema/Radio destination.",
      },
      {
        name: "receiverCategory",
        label: "Receiver Category",
        type: "segmented" as const,
        required: true,
        options: [
          { value: "TV", label: "TV Broadcaster" },
          { value: "DIGITAL", label: "Digital" },
          { value: "OTT", label: "OTT" },
          { value: "CINEMA", label: "Cinema" },
          { value: "RADIO", label: "Radio" },
        ],
        showWhen: (form: Record<string, any>) => form.accountType === "RECEIVER",
      },

      { name: "contactNo", label: "Contact No", type: "text" as const, placeholder: "+91..." },
      { name: "gstNumber", label: "GST No", type: "text" as const },
      { name: "panNumber", label: "PAN No", type: "text" as const },
      { name: "address", label: "Address", type: "textarea" as const, fullWidth: true },
      { name: "emails", label: "Email IDs", type: "emails" as const, placeholder: "a@x.com, b@y.com" },
      { name: "remarks", label: "Remarks", type: "textarea" as const, fullWidth: true },
    ],
    [],
  );

  return (
    <MasterCreateFormPage
      heading="Add Account"
      apiPath="/masters/partner-accounts"  // backend API
      backTo="/masters/accounts"
      fields={fields}
      defaultCreate={{ accountType: "SENDER" }}
      submitLabel="Create"
      createPermissionsAny={[...ACCOUNTS_CREATE_PERMISSIONS]}
      toPayload={(p) => {
        const accountType = p.accountType;
        return {
          ...p,
          accountType,
          receiverCategory: accountType === "RECEIVER" ? p.receiverCategory : undefined,
        };
      }}
    />
  );
}
