import { useEffect, useMemo, useRef, useState } from "react";
import type { ApiError } from "../../../lib/api";
import { api } from "../../../lib/api";
import { getMe, hasAnyPerm, type MeResponse } from "../../../lib/me";
import {
  RATE_CARDS_CREATE_PERMISSIONS,
  RATE_CARDS_DELETE_PERMISSIONS,
  RATE_CARDS_PAGE_PERMISSIONS,
  RATE_CARDS_UPDATE_PERMISSIONS,
} from "../mastersPermissions";
import { CLIENT_RATE_PROFILES, buildClientRateCardItems, findClientRateProfileByKey, findClientRateProfileByName } from "../../billing/clientRateProfiles";

type BillableParty = { id: string; name: string; status?: string };
type Sla = { id: string; name: string; status?: string };

type RateCardItem = {
  id?: string;
  action: "UPLOAD" | "ENCODE" | "DELIVERY" | "OTHER" | string;
  slaId?: string | null;
  code?: string | null;
  label?: string | null;
  sortOrder?: number | null;
  meta?: any;
  billingMode?: "BOTH" | "INDIA" | "GLOBAL";
  hsnSacCode?: string | null;
  gstPercent?: string;
  taxSlabPercent?: string;
  notes?: string | null;
  sourceHeaders?: string[];
  sdAmount: string;
  hdAmount: string;
  amount?: string;
  currency?: string | null;
  unit?: string | null;
};

type RateCardRow = {
  id: string;
  name: string;
  billablePartyId?: string | null;
  effectiveFrom: string;
  effectiveTo?: string | null;
  status: "ACTIVE" | "INACTIVE" | string;
  items?: RateCardItem[];
};

type TemplateSeed = {
  code: string;
  label: string;
  action: RateCardItem["action"];
  unit: string;
  sortOrder: number;
  sourceHeaders: string[];
};

const CLIENT_PAIRED_FIELDS: TemplateSeed[] = [
  {
    code: "ENCODING_UPLOADING",
    label: "Encoding / Uploading",
    action: "ENCODE",
    unit: "per_file",
    sortOrder: 10,
    sourceHeaders: ["SD Encoding/Uploading", "HD Encoding/Uploading"],
  },
  {
    code: "REGULAR_DELIVERY",
    label: "Regular Delivery",
    action: "DELIVERY",
    unit: "per_file",
    sortOrder: 20,
    sourceHeaders: ["SD Regular", "HD Regular"],
  },
  {
    code: "EXPRESS_DELIVERY",
    label: "Express Delivery",
    action: "DELIVERY",
    unit: "per_file",
    sortOrder: 30,
    sourceHeaders: ["SD Express", "HD Express"],
  },
  {
    code: "IMMEDIATE_DELIVERY",
    label: "Immediate Delivery",
    action: "DELIVERY",
    unit: "per_file",
    sortOrder: 40,
    sourceHeaders: ["SD Immediate", "HD Immediate"],
  },
];

const CLIENT_SINGLE_FIELDS: TemplateSeed[] = [
  { code: "MP4", label: "MP4", action: "OTHER", unit: "per_file", sortOrder: 50, sourceHeaders: ["MP4"] },
  { code: "SUBTITILING", label: "Subtitiling", action: "OTHER", unit: "per_file", sortOrder: 60, sourceHeaders: ["Subtitiling"] },
  { code: "LOGO_SLAPPING", label: "Logo Slapping", action: "OTHER", unit: "per_file", sortOrder: 70, sourceHeaders: ["Logo Slapping"] },
  { code: "J2K", label: "J2K", action: "OTHER", unit: "per_file", sortOrder: 80, sourceHeaders: ["J2K"] },
  { code: "CBFC", label: "CBFC", action: "OTHER", unit: "per_file", sortOrder: 90, sourceHeaders: ["CBFC"] },
  { code: "HD_SD", label: "HD-SD", action: "OTHER", unit: "per_file", sortOrder: 100, sourceHeaders: ["HD-SD"] },
  { code: "ASPECT_9_16", label: "9:16", action: "OTHER", unit: "per_file", sortOrder: 110, sourceHeaders: ["9:16"] },
  { code: "4K", label: "4K", action: "OTHER", unit: "per_file", sortOrder: 120, sourceHeaders: ["4K"] },
  { code: "MASKING", label: "Masking", action: "OTHER", unit: "per_file", sortOrder: 130, sourceHeaders: ["Masking"] },
  { code: "AUDIO_SLAP", label: "Audio Slap", action: "OTHER", unit: "per_file", sortOrder: 140, sourceHeaders: ["Audio Slap"] },
  { code: "LUFS", label: "LUFS", action: "OTHER", unit: "per_file", sortOrder: 150, sourceHeaders: ["LUFS"] },
  { code: "VIDEO_LOOP", label: "Video Loop", action: "OTHER", unit: "per_file", sortOrder: 160, sourceHeaders: ["Video Loop"] },
  { code: "MUTES", label: "Mutes", action: "OTHER", unit: "per_file", sortOrder: 170, sourceHeaders: ["Mutes"] },
  { code: "MASTERING", label: "Mastering", action: "OTHER", unit: "per_file", sortOrder: 180, sourceHeaders: ["Mastering"] },
  { code: "TEXT", label: "Text", action: "OTHER", unit: "per_file", sortOrder: 190, sourceHeaders: ["Text"] },
];

const CLIENT_RATE_TEMPLATE = [...CLIENT_PAIRED_FIELDS, ...CLIENT_SINGLE_FIELDS];

const RATE_CARD_CURRENCIES = ["EUR", "USD", "GBP", "INR", "AED", "AUD", "CAD", "CHF", "SGD"] as const;

function normalizeCurrencyCode(value?: string | null) {
  return String(value || "").trim().toUpperCase();
}

function currencySelectValue(value?: string | null) {
  const normalized = normalizeCurrencyCode(value);
  if (!normalized) return "EUR";
  return (RATE_CARD_CURRENCIES as readonly string[]).includes(normalized) ? normalized : "CUSTOM";
}

function Card({ children }: { children: any }) {
  return (
    <div className="card" style={{ display: "grid", gap: 10, padding: 12 }}>
      {children}
    </div>
  );
}

function Modal({ title, onClose, children }: { title: string; onClose: () => void; children: any }) {
  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(15, 23, 42, 0.42)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: 16,
        zIndex: 50,
      }}
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        style={{
          background: "white",
          borderRadius: 16,
          width: "min(1780px, 97vw)",
          maxWidth: "97vw",
          maxHeight: "94vh",
          overflow: "hidden",
          display: "grid",
          gridTemplateRows: "auto minmax(0, 1fr)",
          boxShadow: "0 24px 80px rgba(15, 23, 42, 0.22)",
          border: "1px solid rgba(148, 163, 184, 0.22)",
        }}
      >
        <div
          style={{
            position: "sticky",
            top: 0,
            zIndex: 1,
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            gap: 12,
            padding: "18px 24px 14px 24px",
            background: "white",
            borderBottom: "1px solid #e5e7eb",
          }}
        >
          <div style={{ fontWeight: 800, fontSize: 18, paddingRight: 12 }}>{title}</div>
          <button
            onClick={onClose}
            aria-label="Close"
            style={{
              minWidth: 40,
              height: 40,
              borderRadius: 999,
              border: "1px solid #d1d5db",
              background: "#fff",
              fontSize: 18,
              lineHeight: 1,
              display: "inline-flex",
              alignItems: "center",
              justifyContent: "center",
              cursor: "pointer",
              flexShrink: 0,
            }}
          >
            ×
          </button>
        </div>
        <div style={{ overflow: "auto", padding: "22px 28px 28px 28px" }}>{children}</div>
      </div>
    </div>
  );
}


type ClientSamplePickerProps = {
  value: string;
  onChange: (value: string) => void;
  options: typeof CLIENT_RATE_PROFILES;
};

function ClientSamplePicker({ value, onChange, options }: ClientSamplePickerProps) {
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");

  const selected = useMemo(() => options.find((profile) => profile.key === value) || null, [options, value]);

  useEffect(() => {
    setQuery("");
  }, [value]);

  useEffect(() => {
    function onDocDown(e: MouseEvent) {
      if (!wrapRef.current) return;
      if (!wrapRef.current.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", onDocDown);
    return () => document.removeEventListener("mousedown", onDocDown);
  }, []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return options;
    return options.filter((profile) => {
      const haystack = [profile.billingName, profile.advertiser, profile.gst, profile.currency].join(" ").toLowerCase();
      return haystack.includes(q);
    });
  }, [options, query]);

  return (
    <div ref={wrapRef} style={{ position: "relative" }}>
      <label style={{ fontWeight: 600, display: "block", marginBottom: 8 }}>Client sample values</label>
      <button
        type="button"
        onClick={() => setOpen((prev) => !prev)}
        style={{
          width: "100%",
          minHeight: 56,
          padding: "12px 16px",
          borderRadius: 14,
          border: open ? "1px solid #8b5cf6" : "1px solid #d6d3f1",
          background: open ? "#ffffff" : "#fcfbff",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          gap: 12,
          textAlign: "left",
          boxShadow: open ? "0 0 0 3px rgba(139, 92, 246, 0.12)" : "none",
          cursor: "pointer",
        }}
      >
        <span style={{ minWidth: 0 }}>
          {selected ? (
            <span style={{ display: "grid", gap: 2 }}>
              <span style={{ fontWeight: 700, color: "#111827", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                {selected.billingName}
              </span>
              <span style={{ fontSize: 12, color: "#6b7280", whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                {selected.advertiser} • {selected.currency} • GST {selected.gst || "—"}
              </span>
            </span>
          ) : (
            <span style={{ display: "grid", gap: 2 }}>
              <span style={{ fontWeight: 600, color: "#111827" }}>Select client sample</span>
              <span style={{ fontSize: 12, color: "#6b7280" }}>Choose one of the uploaded client profiles</span>
            </span>
          )}
        </span>
        <span style={{ flexShrink: 0, fontSize: 18, color: "#6b7280" }}>{open ? "▴" : "▾"}</span>
      </button>

      {open && (
        <div
          style={{
            position: "absolute",
            top: "calc(100% + 10px)",
            left: 0,
            right: 0,
            zIndex: 30,
            borderRadius: 16,
            border: "1px solid #ddd6fe",
            background: "#fff",
            boxShadow: "0 24px 60px rgba(15, 23, 42, 0.16)",
            overflow: "hidden",
          }}
        >
          <div style={{ padding: 12, borderBottom: "1px solid #ede9fe", background: "#faf8ff" }}>
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search by billing name, advertiser, GST, or currency"
              style={{ width: "100%", minHeight: 44, borderRadius: 12, padding: "0 14px" }}
              autoFocus
            />
          </div>
          <div style={{ maxHeight: 280, overflow: "auto", padding: 8 }}>
            <button
              type="button"
              onClick={() => {
                onChange("");
                setOpen(false);
              }}
              style={{
                width: "100%",
                padding: "12px 14px",
                borderRadius: 12,
                border: "none",
                background: value ? "transparent" : "#eff6ff",
                textAlign: "left",
                cursor: "pointer",
                marginBottom: 6,
              }}
            >
              <div style={{ fontWeight: 700, color: "#111827" }}>No sample</div>
              <div style={{ fontSize: 12, color: "#6b7280" }}>Keep the rate card fully manual</div>
            </button>
            {filtered.length === 0 ? (
              <div style={{ padding: "12px 14px", color: "#6b7280", fontSize: 13 }}>No matching client profiles</div>
            ) : (
              filtered.map((profile) => {
                const active = profile.key === value;
                return (
                  <button
                    key={profile.key}
                    type="button"
                    onClick={() => {
                      onChange(profile.key);
                      setOpen(false);
                    }}
                    style={{
                      width: "100%",
                      padding: "12px 14px",
                      borderRadius: 12,
                      border: active ? "1px solid #8b5cf6" : "1px solid #ede9fe",
                      background: active ? "#f5f3ff" : "#fff",
                      textAlign: "left",
                      cursor: "pointer",
                      marginBottom: 8,
                    }}
                  >
                    <div style={{ display: "flex", justifyContent: "space-between", gap: 10, alignItems: "flex-start" }}>
                      <div style={{ minWidth: 0 }}>
                        <div style={{ fontWeight: 700, color: "#111827", marginBottom: 2 }}>{profile.billingName}</div>
                        <div style={{ fontSize: 12, color: "#6b7280" }}>{profile.advertiser}</div>
                      </div>
                      <div style={{ flexShrink: 0, fontSize: 12, color: "#6b7280" }}>{profile.currency}</div>
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
}

function toDateInput(iso?: string | null) {
  if (!iso) return "";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  return d.toISOString().slice(0, 10);
}

function dateToIso(dateStr: string) {
  if (!dateStr) return undefined;
  return `${dateStr}T00:00:00.000Z`;
}

function createBlankItem(sortOrder = 10): RateCardItem {
  return {
    action: "UPLOAD",
    slaId: "",
    code: "",
    label: "",
    sortOrder,
    billingMode: "BOTH",
    hsnSacCode: "",
    gstPercent: "",
    taxSlabPercent: "",
    notes: "",
    sourceHeaders: [],
    meta: null,
    sdAmount: "0.00",
    hdAmount: "0.00",
    amount: "0.00",
    currency: "EUR",
    unit: "per_file",
  };
}

function seedToItem(seed: TemplateSeed): RateCardItem {
  const billingMode = seed.code === "CBFC" ? "INDIA" : "BOTH";
  return {
    ...createBlankItem(seed.sortOrder),
    action: seed.action,
    code: seed.code,
    label: seed.label,
    sortOrder: seed.sortOrder,
    billingMode,
    sourceHeaders: [...seed.sourceHeaders],
    meta: {
      clientRateSheet: true,
      sourceHeaders: [...seed.sourceHeaders],
      billingMode,
    },
    unit: seed.unit,
  };
}

function mergeTemplateItems(items: RateCardItem[]) {
  const out = [...items];
  const seen = new Set(out.map((it) => String(it.code || "").trim().toUpperCase()).filter(Boolean));
  for (const seed of CLIENT_RATE_TEMPLATE) {
    if (seen.has(seed.code.toUpperCase())) continue;
    out.push(seedToItem(seed));
    seen.add(seed.code.toUpperCase());
  }
  return out.sort((a, b) => Number(a.sortOrder || 0) - Number(b.sortOrder || 0));
}

function normalizeMeta(item: RateCardItem) {
  const base = item.meta && typeof item.meta === "object" ? { ...item.meta } : {};
  const sourceHeaders = (item.sourceHeaders || []).filter(Boolean);
  const out = {
    ...base,
    billingMode: item.billingMode || "BOTH",
    hsnSacCode: (item.hsnSacCode ?? "").trim() || undefined,
    gstPercent: (item.gstPercent ?? "").trim() || undefined,
    taxSlabPercent: (item.taxSlabPercent ?? "").trim() || undefined,
    notes: (item.notes ?? "").trim() || undefined,
    sourceHeaders: sourceHeaders.length ? sourceHeaders : undefined,
    clientRateSheet: base.clientRateSheet ?? (sourceHeaders.length > 0 ? true : undefined),
  };
  const cleaned = Object.fromEntries(Object.entries(out).filter(([, v]) => v !== undefined && v !== null && v !== ""));
  return Object.keys(cleaned).length ? cleaned : undefined;
}

export function RateCardsPage() {
  const [me, setMe] = useState<MeResponse | null>(null);

  const canRead = hasAnyPerm(me, [...RATE_CARDS_PAGE_PERMISSIONS]);
  const canCreate = hasAnyPerm(me, [...RATE_CARDS_CREATE_PERMISSIONS]);
  const canUpdate = hasAnyPerm(me, [...RATE_CARDS_UPDATE_PERMISSIONS]);
  const canDelete = hasAnyPerm(me, [...RATE_CARDS_DELETE_PERMISSIONS]);

  const [rows, setRows] = useState<RateCardRow[]>([]);
  const [billableParties, setBillableParties] = useState<BillableParty[]>([]);
  const [slas, setSlas] = useState<Sla[]>([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [q, setQ] = useState("");
  const [includeInactive, setIncludeInactive] = useState(false);

  const [open, setOpen] = useState<
    | null
    | {
        mode: "create";
        form: {
          name: string;
          billablePartyId: string;
          effectiveFrom: string;
          effectiveTo: string;
          sampleProfileKey: string;
          items: RateCardItem[];
        };
      }
    | {
        mode: "edit";
        id: string;
        form: {
          name: string;
          billablePartyId: string;
          effectiveFrom: string;
          effectiveTo: string;
          sampleProfileKey: string;
          items: RateCardItem[];
        };
      }
  >(null);

  useEffect(() => {
    getMe().then(setMe).catch(() => setMe(null));
  }, []);

  async function refresh() {
    setLoading(true);
    setErr(null);
    try {
      const qs = new URLSearchParams();
      if (q.trim()) qs.set("q", q.trim());
      if (includeInactive) qs.set("includeInactive", "true");
      const url = qs.toString() ? `/masters/rate-cards?${qs.toString()}` : "/masters/rate-cards";
      const data = await api<RateCardRow[]>(url);
      setRows(data || []);
    } catch (e: any) {
      const ae = e as ApiError;
      setErr(ae.message || "Failed to load rate cards");
      setRows([]);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (!canRead) return;
    refresh();
    api<BillableParty[]>("/masters/billable-parties")
      .then((x) => setBillableParties(x || []))
      .catch(() => setBillableParties([]));
    api<Sla[]>("/masters/slas")
      .then((x) => setSlas(x || []))
      .catch(() => setSlas([]));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [canRead, includeInactive]);

  const bpMap = useMemo(() => new Map(billableParties.map((b) => [b.id, b.name])), [billableParties]);
  const slaMap = useMemo(() => new Map(slas.map((s) => [s.id, s.name])), [slas]);

  if (!canRead) {
    return (
      <div style={{ padding: 16 }}>
        <h2 style={{ margin: 0 }}>Rate Cards</h2>
        <div className="card" style={{ padding: 12, marginTop: 10 }}>
          You don’t have <code>FINANCE_READ</code> permission.
        </div>
      </div>
    );
  }

  function initCreate() {
    setOpen({
      mode: "create",
      form: {
        name: "",
        billablePartyId: "",
        effectiveFrom: "",
        effectiveTo: "",
        sampleProfileKey: "",
        items: [createBlankItem(10)],
      },
    });
  }

  function initEdit(r: RateCardRow) {
    setOpen({
      mode: "edit",
      id: r.id,
      form: {
        name: r.name ?? "",
        billablePartyId: r.billablePartyId ?? "",
        effectiveFrom: toDateInput(r.effectiveFrom),
        effectiveTo: toDateInput(r.effectiveTo),
        sampleProfileKey: (() => {
          const firstMeta = (r.items || []).find((it) => it.meta && typeof it.meta === "object" && (it.meta as any).clientRateProfileKey)?.meta as any;
          return firstMeta?.clientRateProfileKey || "";
        })(),
        items:
          (r.items || []).map((it, idx) => {
            const meta = it.meta && typeof it.meta === "object" ? it.meta : {};
            return {
              id: it.id,
              action: (it.action as any) || "UPLOAD",
              slaId: it.slaId ?? "",
              code: it.code ?? "",
              label: it.label ?? "",
              sortOrder: Number.isFinite(it.sortOrder as any) ? Number(it.sortOrder) : (idx + 1) * 10,
              meta: meta ?? null,
              billingMode: meta.billingMode || "BOTH",
              hsnSacCode: meta.hsnSacCode || meta.hsnSac || "",
              gstPercent: meta.gstPercent ? String(meta.gstPercent) : "",
              taxSlabPercent: meta.taxSlabPercent || meta.globalTaxSlabPercent ? String(meta.taxSlabPercent ?? meta.globalTaxSlabPercent) : "",
              notes: meta.notes || "",
              sourceHeaders: Array.isArray(meta.sourceHeaders) ? meta.sourceHeaders.map(String) : [],
              sdAmount: String((it as any).sdAmount ?? it.amount ?? "0.00"),
              hdAmount: String((it as any).hdAmount ?? it.amount ?? "0.00"),
              amount: String(it.amount ?? "0.00"),
              currency: normalizeCurrencyCode(it.currency) || "EUR",
              unit: it.unit ?? "per_file",
            } as RateCardItem;
          }) || [],
      },
    });
  }

  function setForm(key: string, value: any) {
    setOpen((prev) => {
      if (!prev) return prev;
      return { ...prev, form: { ...prev.form, [key]: value } } as any;
    });
  }

  function setItem(idx: number, patch: Partial<RateCardItem>) {
    setOpen((prev) => {
      if (!prev) return prev;
      const items = [...prev.form.items];
      items[idx] = { ...items[idx], ...patch };
      return { ...prev, form: { ...prev.form, items } } as any;
    });
  }

  function addItem() {
    setOpen((prev) => {
      if (!prev) return prev;
      return {
        ...prev,
        form: {
          ...prev.form,
          items: [...prev.form.items, createBlankItem((prev.form.items.length + 1) * 10)],
        },
      } as any;
    });
  }

  function addClientTemplateFields() {
    setOpen((prev) => {
      if (!prev) return prev;
      return {
        ...prev,
        form: {
          ...prev.form,
          items: mergeTemplateItems(prev.form.items),
        },
      } as any;
    });
  }

  function findBillablePartyBySample(profileKey?: string | null) {
    const profile = findClientRateProfileByKey(profileKey);
    if (!profile) return null;
    return billableParties.find((party) => findClientRateProfileByName(party.name)?.key === profile.key) || null;
  }

  function resolveActiveClientProfile(form: { billablePartyId: string; sampleProfileKey: string }) {
    const explicit = findClientRateProfileByKey(form.sampleProfileKey);
    if (explicit) return explicit;
    const selectedBillableParty = billableParties.find((party) => party.id === form.billablePartyId);
    return findClientRateProfileByName(selectedBillableParty?.name) || null;
  }

  function applyClientSample() {
    setOpen((prev) => {
      if (!prev) return prev;
      const profile = resolveActiveClientProfile(prev.form);
      if (!profile) return prev;
      const matchedBillableParty = findBillablePartyBySample(profile.key);
      return {
        ...prev,
        form: {
          ...prev.form,
          sampleProfileKey: profile.key,
          name: prev.form.name.trim() ? prev.form.name : profile.billingName,
          billablePartyId: prev.form.billablePartyId || matchedBillableParty?.id || "",
          items: buildClientRateCardItems(profile).map((item) => ({ ...item })),
        },
      } as any;
    });
  }

  function removeItem(idx: number) {
    setOpen((prev) => {
      if (!prev) return prev;
      const items = prev.form.items.filter((_, i) => i !== idx);
      return { ...prev, form: { ...prev.form, items } } as any;
    });
  }

  async function submit() {
    if (!open) return;

    if (!open.form.name.trim()) return setErr("Name is required");
    if (!open.form.effectiveFrom.trim()) return setErr("Effective From is required");
    if (open.form.items.length === 0) return setErr("At least 1 rate item is required");

    for (const it of open.form.items) {
      if (!String(it.action || "").trim()) return setErr("Rate item action is required");
      if (!String(it.sdAmount || "").trim()) return setErr("Rate item SD rate is required");
      if (!String(it.hdAmount || "").trim()) return setErr("Rate item HD rate is required");
    }

    setErr(null);
    const payload = {
      name: open.form.name.trim(),
      billablePartyId: open.form.billablePartyId || undefined,
      effectiveFrom: dateToIso(open.form.effectiveFrom),
      effectiveTo: open.form.effectiveTo ? dateToIso(open.form.effectiveTo) : undefined,
      items: open.form.items.map((it, idx) => ({
        action: it.action,
        slaId: it.slaId ? it.slaId : undefined,
        code: (it.code ?? "").trim() || undefined,
        label: (it.label ?? "").trim() || undefined,
        sortOrder: Number.isFinite(it.sortOrder as any) ? Number(it.sortOrder) : (idx + 1) * 10,
        meta: normalizeMeta(it),
        sdAmount: String(it.sdAmount),
        hdAmount: String(it.hdAmount),
        amount: String(it.amount ?? it.sdAmount),
        currency: normalizeCurrencyCode(it.currency) || "EUR",
        unit: it.unit || undefined,
      })),
    };

    try {
      if (open.mode === "create") {
        await api("/masters/rate-cards", { method: "POST", body: JSON.stringify(payload) });
      } else {
        await api(`/masters/rate-cards/${open.id}`, { method: "PUT", body: JSON.stringify(payload) });
      }
      setOpen(null);
      await refresh();
    } catch (e: any) {
      const ae = e as ApiError;
      setErr(ae.message || "Failed to save rate card");
    }
  }

  async function doDisable(id: string) {
    if (!canDelete) return;
    if (!confirm("Disable this rate card?")) return;

    setErr(null);
    try {
      await api(`/masters/rate-cards/${id}`, { method: "DELETE" });
      await refresh();
    } catch (e: any) {
      const ae = e as ApiError;
      setErr(ae.message || "Failed to disable");
    }
  }

  return (
    <div style={{ padding: 16, display: "grid", gap: 12, width: "100%", minWidth: 0 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 8 }}>
        <h2 style={{ margin: 0 }}>Rate Cards</h2>

        <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap", justifyContent: "flex-end" }}>
          <label style={{ display: "flex", gap: 6, alignItems: "center", fontSize: 13, opacity: 0.85 }}>
            <input type="checkbox" checked={includeInactive} onChange={(e) => setIncludeInactive(e.target.checked)} />
            Include inactive
          </label>

          <input placeholder="Search by name, code or label" value={q} onChange={(e) => setQ(e.target.value)} style={{ width: 280 }} />
          <button onClick={refresh} disabled={loading}>Search</button>
          {canCreate && <button onClick={initCreate}>Create</button>}
        </div>
      </div>



      {err && (
        <Card>
          <div style={{ color: "crimson", fontWeight: 600 }}>{err}</div>
        </Card>
      )}

      <Card>
        {loading ? (
          <div>Loading...</div>
        ) : rows.length === 0 ? (
          <div style={{ opacity: 0.7 }}>No data</div>
        ) : (
          <div style={{ overflowX: "auto" }}>
            <table style={{ width: "100%", borderCollapse: "collapse" }}>
              <thead>
                <tr>
                  <th style={{ textAlign: "left", padding: "8px 6px", borderBottom: "1px solid #ddd" }}>Name</th>
                  <th style={{ textAlign: "left", padding: "8px 6px", borderBottom: "1px solid #ddd" }}>Billable Party</th>
                  <th style={{ textAlign: "left", padding: "8px 6px", borderBottom: "1px solid #ddd" }}>Effective</th>
                  <th style={{ textAlign: "left", padding: "8px 6px", borderBottom: "1px solid #ddd" }}>Items</th>
                  <th style={{ textAlign: "left", padding: "8px 6px", borderBottom: "1px solid #ddd" }}>Status</th>
                  <th style={{ width: 220, borderBottom: "1px solid #ddd" }} />
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.id}>
                    <td style={{ padding: "8px 6px", borderBottom: "1px solid #f0f0f0" }}>{r.name}</td>
                    <td style={{ padding: "8px 6px", borderBottom: "1px solid #f0f0f0" }}>
                      {r.billablePartyId ? bpMap.get(r.billablePartyId) || r.billablePartyId : "—"}
                    </td>
                    <td style={{ padding: "8px 6px", borderBottom: "1px solid #f0f0f0" }}>
                      {toDateInput(r.effectiveFrom)} {r.effectiveTo ? `→ ${toDateInput(r.effectiveTo)}` : ""}
                    </td>
                    <td style={{ padding: "8px 6px", borderBottom: "1px solid #f0f0f0" }}>{(r.items || []).length}</td>
                    <td style={{ padding: "8px 6px", borderBottom: "1px solid #f0f0f0" }}>{r.status}</td>

                    <td style={{ padding: "8px 6px", borderBottom: "1px solid #f0f0f0", textAlign: "right" }}>
                      {canUpdate && <button onClick={() => initEdit(r)}>Edit</button>}
                      {canDelete && (
                        <button style={{ marginLeft: 8 }} onClick={() => doDisable(r.id)} disabled={String(r.status) === "INACTIVE"}>
                          Disable
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {open && (
        <Modal title={open.mode === "create" ? "Create Rate Card" : "Edit Rate Card"} onClose={() => setOpen(null)}>
          <div style={{ display: "grid", gap: 12 }}>
            <div style={{ display: "grid", gap: 12, gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", alignItems: "start" }}>
              <div style={{ display: "grid", gap: 6 }}>
                <label style={{ fontWeight: 600 }}>Name *</label>
                <input value={open.form.name} onChange={(e) => setForm("name", e.target.value)} placeholder="e.g. 2026 Default" style={{ minHeight: 44, borderRadius: 12, padding: "0 14px" }} />
              </div>

              <div style={{ display: "grid", gap: 6 }}>
                <label style={{ fontWeight: 600 }}>Billable Party</label>
                <select value={open.form.billablePartyId} onChange={(e) => setForm("billablePartyId", e.target.value)} style={{ minHeight: 44, borderRadius: 12, padding: "0 14px" }}>
                  <option value="">-- none --</option>
                  {billableParties
                    .filter((b) => String(b.status || "ACTIVE") !== "INACTIVE")
                    .map((b) => (
                      <option key={b.id} value={b.id}>
                        {b.name}
                      </option>
                    ))}
                </select>
              </div>

              <div style={{ display: "grid", gap: 6 }}>
                <label style={{ fontWeight: 600 }}>Effective From *</label>
                <input type="date" value={open.form.effectiveFrom} onChange={(e) => setForm("effectiveFrom", e.target.value)} style={{ minHeight: 44, borderRadius: 12, padding: "0 14px" }} />
              </div>

              <div style={{ display: "grid", gap: 6 }}>
                <label style={{ fontWeight: 600 }}>Effective To</label>
                <input type="date" value={open.form.effectiveTo} onChange={(e) => setForm("effectiveTo", e.target.value)} style={{ minHeight: 44, borderRadius: 12, padding: "0 14px" }} />
              </div>
            </div>

            {(() => {
              const activeProfile = resolveActiveClientProfile(open.form);
              return (
                <div className="card" style={{ display: "grid", gap: 10, padding: 12, background: "#faf8ff", border: "1px solid #eadfff" }}>
                  <div style={{ display: "grid", gap: 10, gridTemplateColumns: "minmax(0, 1fr) auto", alignItems: "end" }}>
                    <div style={{ display: "grid", gap: 6 }}>
                      <ClientSamplePicker
                        value={open.form.sampleProfileKey || activeProfile?.key || ""}
                        onChange={(value) => setForm("sampleProfileKey", value)}
                        options={CLIENT_RATE_PROFILES}
                      />
                    </div>
                    <button
                      onClick={applyClientSample}
                      disabled={!activeProfile && !open.form.sampleProfileKey}
                      style={{ minHeight: 56, padding: "0 18px", alignSelf: "stretch", borderRadius: 14, fontWeight: 700 }}
                    >
                      Apply Sample Values
                    </button>
                  </div>

                  {activeProfile && (
                    <div style={{ fontSize: 13, opacity: 0.9, display: "flex", gap: 10, flexWrap: "wrap" }}>
                      <span style={{ background: "#fff", border: "1px solid #e9d5ff", borderRadius: 999, padding: "6px 10px" }}><b>Advertiser:</b> {activeProfile.advertiser}</span>
                      <span style={{ background: "#fff", border: "1px solid #e9d5ff", borderRadius: 999, padding: "6px 10px" }}><b>Billing:</b> {activeProfile.billingName}</span>
                      <span style={{ background: "#fff", border: "1px solid #e9d5ff", borderRadius: 999, padding: "6px 10px" }}><b>Currency:</b> {activeProfile.currency}</span>
                      <span style={{ background: "#fff", border: "1px solid #e9d5ff", borderRadius: 999, padding: "6px 10px" }}><b>GST:</b> {activeProfile.gst}</span>
                    </div>
                  )}
                </div>
              );
            })()}

            <div>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
                <div style={{ fontWeight: 800 }}>Rate Items</div>
                <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                  <button onClick={addClientTemplateFields}>Load Client Template Fields</button>
                  <button onClick={addItem}>Add Item</button>
                </div>
              </div>

              <div style={{ marginTop: 8, overflowX: "auto" }}>
                <table style={{ width: "100%", borderCollapse: "collapse", minWidth: 1800 }}>
                  <thead>
                    <tr>
                      {[
                        "Code",
                        "Label",
                        "Sheet Header(s)",
                        "Action",
                        "SLA",
                        "SD Rate *",
                        "HD Rate *",
                        "Currency",
                        "Unit",
                        "Invoice Mode",
                        "HSN/SAC",
                        "GST %",
                        "Global Tax %",
                        "Notes",
                        "",
                      ].map((h) => (
                        <th key={h} style={{ textAlign: "left", padding: "8px 6px", borderBottom: "1px solid #ddd", whiteSpace: "nowrap" }}>
                          {h}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {open.form.items.map((it, idx) => (
                      <tr key={idx}>
                        <td style={{ padding: "8px 6px", borderBottom: "1px solid #f0f0f0" }}>
                          <input value={it.code || ""} onChange={(e) => setItem(idx, { code: e.target.value })} style={{ width: 130 }} />
                        </td>

                        <td style={{ padding: "8px 6px", borderBottom: "1px solid #f0f0f0" }}>
                          <input value={it.label || ""} onChange={(e) => setItem(idx, { label: e.target.value })} style={{ width: 180 }} />
                        </td>

                        <td style={{ padding: "8px 6px", borderBottom: "1px solid #f0f0f0", minWidth: 220 }}>
                          <input
                            value={(it.sourceHeaders || []).join(", ")}
                            onChange={(e) => setItem(idx, {
                              sourceHeaders: e.target.value
                                .split(",")
                                .map((x) => x.trim())
                                .filter(Boolean),
                            })}
                            placeholder="e.g. SD Regular, HD Regular"
                            style={{ width: 220 }}
                          />
                        </td>

                        <td style={{ padding: "8px 6px", borderBottom: "1px solid #f0f0f0" }}>
                          <select value={it.action} onChange={(e) => setItem(idx, { action: e.target.value })}>
                            {["UPLOAD", "ENCODE", "DELIVERY", "OTHER"].map((a) => (
                              <option key={a} value={a}>
                                {a}
                              </option>
                            ))}
                          </select>
                        </td>

                        <td style={{ padding: "8px 6px", borderBottom: "1px solid #f0f0f0" }}>
                          <select value={it.slaId || ""} onChange={(e) => setItem(idx, { slaId: e.target.value })}>
                            <option value="">-- any / none --</option>
                            {slas
                              .filter((s) => String(s.status || "ACTIVE") !== "INACTIVE")
                              .map((s) => (
                                <option key={s.id} value={s.id}>
                                  {slaMap.get(s.id) || s.name}
                                </option>
                              ))}
                          </select>
                        </td>

                        <td style={{ padding: "8px 6px", borderBottom: "1px solid #f0f0f0" }}>
                          <input
                            type="number"
                            step="0.01"
                            value={it.sdAmount}
                            onChange={(e) => setItem(idx, { sdAmount: e.target.value, amount: e.target.value })}
                            style={{ width: 110 }}
                          />
                        </td>

                        <td style={{ padding: "8px 6px", borderBottom: "1px solid #f0f0f0" }}>
                          <input
                            type="number"
                            step="0.01"
                            value={it.hdAmount}
                            onChange={(e) => setItem(idx, { hdAmount: e.target.value })}
                            style={{ width: 110 }}
                          />
                        </td>

                        <td style={{ padding: "8px 6px", borderBottom: "1px solid #f0f0f0" }}>
                          <div style={{ display: "grid", gap: 6 }}>
                            <select
                              value={currencySelectValue(it.currency)}
                              onChange={(e) => {
                                const next = e.target.value;
                                if (next === "CUSTOM") {
                                  const existing = normalizeCurrencyCode(it.currency);
                                  setItem(idx, { currency: (RATE_CARD_CURRENCIES as readonly string[]).includes(existing) ? "" : existing });
                                  return;
                                }
                                setItem(idx, { currency: next });
                              }}
                              style={{ width: 110 }}
                            >
                              {RATE_CARD_CURRENCIES.map((code) => (
                                <option key={code} value={code}>
                                  {code}
                                </option>
                              ))}
                              <option value="CUSTOM">Other</option>
                            </select>
                            {currencySelectValue(it.currency) === "CUSTOM" && (
                              <input
                                value={normalizeCurrencyCode(it.currency)}
                                onChange={(e) => setItem(idx, { currency: normalizeCurrencyCode(e.target.value) })}
                                placeholder="Code"
                                maxLength={6}
                                style={{ width: 110 }}
                              />
                            )}
                          </div>
                        </td>

                        <td style={{ padding: "8px 6px", borderBottom: "1px solid #f0f0f0" }}>
                          <input value={it.unit || ""} onChange={(e) => setItem(idx, { unit: e.target.value })} placeholder="per_file" style={{ width: 100 }} />
                        </td>

                        <td style={{ padding: "8px 6px", borderBottom: "1px solid #f0f0f0" }}>
                          <select value={it.billingMode || "BOTH"} onChange={(e) => setItem(idx, { billingMode: e.target.value as any })}>
                            <option value="BOTH">Both</option>
                            <option value="INDIA">India</option>
                            <option value="GLOBAL">Global</option>
                          </select>
                        </td>

                        <td style={{ padding: "8px 6px", borderBottom: "1px solid #f0f0f0" }}>
                          <input value={it.hsnSacCode || ""} onChange={(e) => setItem(idx, { hsnSacCode: e.target.value })} style={{ width: 100 }} />
                        </td>

                        <td style={{ padding: "8px 6px", borderBottom: "1px solid #f0f0f0" }}>
                          <input type="number" step="0.01" value={it.gstPercent || ""} onChange={(e) => setItem(idx, { gstPercent: e.target.value })} style={{ width: 90 }} />
                        </td>

                        <td style={{ padding: "8px 6px", borderBottom: "1px solid #f0f0f0" }}>
                          <input type="number" step="0.01" value={it.taxSlabPercent || ""} onChange={(e) => setItem(idx, { taxSlabPercent: e.target.value })} style={{ width: 110 }} />
                        </td>

                        <td style={{ padding: "8px 6px", borderBottom: "1px solid #f0f0f0", minWidth: 180 }}>
                          <input value={it.notes || ""} onChange={(e) => setItem(idx, { notes: e.target.value })} placeholder="Optional notes" style={{ width: 180 }} />
                        </td>

                        <td style={{ padding: "8px 6px", borderBottom: "1px solid #f0f0f0", textAlign: "right" }}>
                          <button onClick={() => removeItem(idx)} disabled={open.form.items.length <= 1}>
                            X
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>


              </div>
            </div>

            <div style={{ display: "flex", justifyContent: "flex-end", gap: 8, marginTop: 8, paddingTop: 12, borderTop: "1px solid #e5e7eb", position: "sticky", bottom: 0, background: "white" }}>
              <button onClick={() => setOpen(null)}>Cancel</button>
              <button onClick={submit}>{open.mode === "create" ? "Create" : "Save"}</button>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
}
