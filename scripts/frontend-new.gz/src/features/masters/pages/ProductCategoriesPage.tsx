import { useEffect, useState } from "react";
import { getMe, hasAnyPerm, type MeResponse } from "../../../lib/me";
import {
  PRODUCT_CATEGORIES_CREATE_PERMISSIONS,
  PRODUCT_CATEGORIES_DELETE_PERMISSIONS,
  PRODUCT_CATEGORIES_UPDATE_PERMISSIONS,
} from "../mastersPermissions";
import { MasterCrudPage } from "../MasterCrudPage";

export function ProductCategoriesPage() {
  const [me, setMe] = useState<MeResponse | null>(null);

  useEffect(() => {
    getMe().then(setMe).catch(() => setMe(null));
  }, []);

  return (
    <MasterCrudPage
      title="Product Categories"
      path="/masters/product-categories"
      canCreate={hasAnyPerm(me, [...PRODUCT_CATEGORIES_CREATE_PERMISSIONS])}
      canUpdate={hasAnyPerm(me, [...PRODUCT_CATEGORIES_UPDATE_PERMISSIONS])}
      canDelete={hasAnyPerm(me, [...PRODUCT_CATEGORIES_DELETE_PERMISSIONS])}
      columns={[
        { key: "name", label: "Name" },
        { key: "status", label: "Status" },
        { key: "updatedAt", label: "Updated" },
      ]}
      fields={[{ name: "name", label: "Name", type: "text", required: true, placeholder: "e.g. FMCG" }]}
      supportsInactive
      supportsEnableAndPermanentDelete
      enhancedCrudUi
      createTo="/masters/product-categories/new"
      createLabel="Add"
    />
  );
}
