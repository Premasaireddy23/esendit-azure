import { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { getMe, hasAnyPerm, type MeResponse } from "../../../lib/me";
import {
  AGENCIES_CREATE_PERMISSIONS,
  AGENCIES_DELETE_PERMISSIONS,
  AGENCIES_UPDATE_PERMISSIONS,
} from "../mastersPermissions";
import { MasterCrudPage } from "../MasterCrudPage";
import type { AgencyType } from "../types";

const AGENCY_TYPES = ["MEDIA", "CREATIVE", "POST_HOUSE", "PRODUCTION_HOUSE", "AUDIO", "UPLOADER"] as const;

function normalizeType(v: string | null): AgencyType {
  if (!v) return "MEDIA";
  const up = v.toUpperCase();
  return (AGENCY_TYPES as readonly string[]).includes(up) ? (up as AgencyType) : ("MEDIA" as AgencyType);
}

function prettyType(t: string) {
  switch (t) {
    case "MEDIA":
      return "Media Agency";
    case "CREATIVE":
      return "Creative Agency";
    case "POST_HOUSE":
      return "Post House";
    case "PRODUCTION_HOUSE":
      return "Production House";
    case "AUDIO":
      return "Audio Agency";
    case "UPLOADER":
      return "Uploader Agency";
    default:
      return t;
  }
}

export function AgenciesPage() {
  const [sp] = useSearchParams();
  const type = normalizeType(sp.get("type"));
  const [me, setMe] = useState<MeResponse | null>(null);

  useEffect(() => {
    getMe().then(setMe).catch(() => setMe(null));
  }, []);

  const fields = useMemo(
    () => [
      { name: "name", label: "Name", type: "text" as const, required: true },
      { name: "emails", label: "Email IDs", type: "emails" as const, help: "Comma-separated" },
      { name: "contactNo", label: "Contact No", type: "text" as const, placeholder: "optional" },
      { name: "gstNumber", label: "GST No", type: "text" as const, placeholder: "optional" },
      { name: "panNumber", label: "PAN No", type: "text" as const, placeholder: "optional" },
      { name: "address", label: "Address", type: "textarea" as const, placeholder: "optional" },
      { name: "remarks", label: "Remarks", type: "textarea" as const, placeholder: "optional" },
    ],
    [],
  );

  return (
    <MasterCrudPage
      title={`${prettyType(String(type))}s`}
      path="/masters/agencies"
      canCreate={hasAnyPerm(me, [...AGENCIES_CREATE_PERMISSIONS])}
      canUpdate={hasAnyPerm(me, [...AGENCIES_UPDATE_PERMISSIONS])}
      canDelete={hasAnyPerm(me, [...AGENCIES_DELETE_PERMISSIONS])}
      supportsInactive
      supportsEnableAndPermanentDelete
      enhancedCrudUi
      createTo={`/masters/agencies/new?type=${encodeURIComponent(String(type))}`}
      createLabel={`Add ${prettyType(String(type))}`}
      transformRows={(rows: any[]) => rows.filter((r) => String(r.type || "").toUpperCase() === String(type).toUpperCase())}
      columns={[
        { key: "name", label: "Name" },
        { key: "type", label: "Type" },
        {
          key: "emails",
          label: "Emails",
          render: (r: any) => (Array.isArray(r.emails) ? r.emails.join(", ") : ""),
        },
        { key: "status", label: "Status" },
      ]}
      fields={fields}
    />
  );
}
