import { useEffect, useMemo, useState } from "react";
import { AppModal } from "../../../ui/AppModal";
import { getMe, hasAnyPerm, type MeResponse } from "../../../lib/me";
import {
  SLAS_CREATE_PERMISSIONS,
  SLAS_DELETE_PERMISSIONS,
  SLAS_PAGE_PERMISSIONS,
  SLAS_UPDATE_PERMISSIONS,
} from "../mastersPermissions";
import { createMaster, disableMaster, listMasters, updateMaster } from "../mastersApi";

type SlaRow = {
  id: string;
  name: string;
  code: string | null;
  description: string | null;
  hoursTarget: number;
  targetMinutes?: number;
  durationValue?: number;
  durationUnit?: "HOURS" | "MINUTES" | string;
  durationLabel?: string;
  status: "ACTIVE" | "INACTIVE" | string;
  createdAt?: string;
  updatedAt?: string;
};

type FormState = {
  name: string;
  code: string;
  description: string;
  durationValue: string;
  durationUnit: "HOURS" | "MINUTES";
  status: "ACTIVE" | "INACTIVE";
};

const SLA_ICON_SRC = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAAAdgAAAHYBTnsmCAAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAAMMSURBVDiNdZBdbFMFGIafc05Pu85mjE3WlUEHs25srWl1NGd/YoXxo0wTksUEuPHGGBIC0QSvCCHEYEQTCSZGhBiJUUJkEueGFxLAsTYShhAdkK5sc11dLY52W3u6nvXneKFbYhff2+/9nnzfI1CUtW7vNclodAPk5jPJyPBtB5At7i1GBFCa7ceVZvt7AKIgRRaSSS2XVPOCJMUA3dlg29HsqekDjMsASrP9+IF9HftlWVQAaXoieCKfVqf1fC6f0DLvA4LZLG0+dNDn8z3/VG8xRGjx1n4iG8TGwNBUqGlLl9Pzymuu6oZnytB1otPx7M/f9/z5x0+9d+1PpGatT1pqBwJjLwHqEgDA0f6is8676fIGRbEn/F9SXZpmMBSjzFbDCmsTkco2bfS7L76O/XjhzWIfEiB5unb31ntcTZFv3+XCx524N1Twiyag7PfxwP8bpsh9Q+rpzsZC6q9BLTo5/h8Hq53ufe6XuzcWhr/h0w92Lg10XScWjKLscWFx2GhptJWY1jg/Wiax3Lr2BS0xJe7ZYcVaZQHg0lfDzHx+j5GTA1hWleHqcpK4eZFCedWaYoDBYC4tzU+N0nc+yOCZMAVdRw9meN1YT788RurERcgKVMRNiHK1vAyQmZuZM9sb8UkjbFnZAMBnlgGuVTzk7AHfP605E6fHzfwQUBeWvTATjfTnS8qyl+YfcvdxBIBdjmfxPFe1VDrbf48btu1I0+FgMUAAROfWVwM73ziohI4d4px3L7ML87yVOM9GTw0g8FgzkpNLFnKJ6KRRFvOLy3eGJldKgK4l49eT6fnO1qMnV/Xd7uFWfITW7avJCWAyyxx+u4OxYFg68k5nxbbN9ZWnTvsrz5zqrpwMPtIlAC2djs9OhHrC939dX6hzmcW2rRYrE5LDbuH3cIL2lnVcHRilo3U9N4fC5HIFZucyOKvLU4bFc1RVjYX8V7pD/isWoEP5cNe5lFpalUxpZLMFxifiPAg+4vrgGKIoMHQngqxmjUKxlH9j3dRed6vNW1v4nzkAgRujK/4GRT4ztUPI/k8AAAAASUVORK5CYII=";

function SlaIcon() {
  return <img src={SLA_ICON_SRC} alt="" aria-hidden="true" style={{ width: 18, height: 18, objectFit: "contain", display: "block" }} />;
}

function defaultForm(): FormState {
  return {
    name: "",
    code: "",
    description: "",
    durationValue: "24",
    durationUnit: "HOURS",
    status: "ACTIVE",
  };
}

function statusTone(status?: string | null) {
  return String(status || "").toUpperCase() === "ACTIVE"
    ? { bg: "#eaf8ef", color: "#166534" }
    : { bg: "#f1f5f9", color: "#475569" };
}

function fmtDt(iso?: string | null) {
  if (!iso) return "—";
  try {
    const d = new Date(iso);
    return Number.isNaN(d.getTime()) ? iso : d.toLocaleString();
  } catch {
    return iso;
  }
}

function formatDurationLabel(row?: Pick<SlaRow, "durationLabel" | "durationUnit" | "durationValue" | "targetMinutes" | "hoursTarget"> | null) {
  if (!row) return "—";
  const direct = String(row.durationLabel || "").trim();
  if (direct) return direct;
  if (String(row.durationUnit || "").toUpperCase() === "MINUTES") {
    const mins = Number(row.durationValue ?? row.targetMinutes ?? 0);
    if (Number.isFinite(mins) && mins > 0) return `${mins} minute${mins === 1 ? "" : "s"}`;
  }
  const hours = Number(row.durationValue ?? row.hoursTarget ?? 0);
  if (Number.isFinite(hours) && hours > 0) return `${hours} hour${hours === 1 ? "" : "s"}`;
  return "—";
}

function cleanPayload(form: FormState) {
  const name = String(form.name || "").trim();
  const code = String(form.code || "").trim();
  const description = String(form.description || "").trim();
  const durationValue = Number(form.durationValue);
  if (!name) throw new Error("Name is required");
  if (!Number.isFinite(durationValue) || durationValue <= 0) throw new Error("Target duration must be a positive number");

  const rounded = Math.trunc(durationValue);
  return {
    name,
    code: code || undefined,
    description: description || null,
    ...(form.durationUnit === "MINUTES" ? { targetMinutes: rounded } : { hoursTarget: rounded }),
    status: form.status || "ACTIVE",
  };
}

function rowToForm(row: SlaRow): FormState {
  return {
    name: row.name || "",
    code: row.code || "",
    description: row.description || "",
    durationValue: String(row.durationValue ?? (String(row.durationUnit || "").toUpperCase() === "MINUTES" ? row.targetMinutes : row.hoursTarget) ?? 24),
    durationUnit: String(row.durationUnit || "").toUpperCase() === "MINUTES" ? "MINUTES" : "HOURS",
    status: String(row.status || "ACTIVE").toUpperCase() === "INACTIVE" ? "INACTIVE" : "ACTIVE",
  };
}

function SlaDetailsModal(props: {
  row: SlaRow | null;
  onClose: () => void;
  onEdit: () => void;
  onDisable: () => void;
  canUpdate: boolean;
  canDelete: boolean;
}) {
  const { row, onClose, onEdit, onDisable, canUpdate, canDelete } = props;
  if (!row) return null;
  const tone = statusTone(row.status);
  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(15,23,42,0.14)",
        zIndex: 85,
        display: "grid",
        placeItems: "center",
        padding: 16,
      }}
      onClick={onClose}
    >
      <div
        className="card"
        style={{ width: "min(380px, 100%)", borderRadius: 22, padding: 0, overflow: "hidden", boxShadow: "0 24px 60px rgba(15,23,42,0.20)", background: "#fff" }}
        onClick={(e) => e.stopPropagation()}
      >
        <div style={{ padding: "18px 18px 10px", display: "flex", justifyContent: "space-between", gap: 12, alignItems: "flex-start" }}>
          <div style={{ minWidth: 0 }}>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center", marginBottom: 8 }}>
              <span style={{ fontSize: 15, color: "#334155" }}>{row.code || "SLA"}</span>
              <span style={{ display: "inline-flex", alignItems: "center", borderRadius: 999, padding: "4px 8px", fontSize: 12, fontWeight: 800, background: tone.bg, color: tone.color }}>{row.status || "ACTIVE"}</span>
            </div>
            <div style={{ fontSize: 18, fontWeight: 900, color: "#0f172a", wordBreak: "break-word" }}>{row.name}</div>
          </div>
          <button type="button" onClick={onClose} aria-label="Close" style={{ border: "none", background: "transparent", color: "#64748b", fontSize: 28, lineHeight: 1, cursor: "pointer", padding: 0 }}>×</button>
        </div>

        <div style={{ padding: "0 18px 18px", display: "grid", gap: 10 }}>
          <div style={{ borderRadius: 16, border: "1px solid rgba(15,23,42,0.10)", background: "#f8fafc", padding: 12 }}>
            <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: 0.35, textTransform: "uppercase", color: "#64748b", marginBottom: 6 }}>Description</div>
            <div style={{ fontSize: 14, color: "#0f172a", whiteSpace: "pre-wrap" }}>{row.description || "—"}</div>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: 10 }}>
            <div style={{ borderRadius: 16, border: "1px solid rgba(15,23,42,0.10)", background: "#fff", padding: 12, minHeight: 92 }}>
              <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: 0.35, textTransform: "uppercase", color: "#64748b", marginBottom: 8 }}>Target duration</div>
              <div style={{ fontSize: 26, lineHeight: 1.1, fontWeight: 900, color: "#0f172a" }}>{formatDurationLabel(row)}</div>
            </div>
            <div style={{ borderRadius: 16, border: "1px solid rgba(15,23,42,0.10)", background: "#fff", padding: 12, minHeight: 92 }}>
              <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: 0.35, textTransform: "uppercase", color: "#64748b", marginBottom: 8 }}>Code</div>
              <div style={{ fontSize: 18, lineHeight: 1.2, fontWeight: 900, color: "#0f172a", wordBreak: "break-word" }}>{row.code || "—"}</div>
            </div>
          </div>

          <div style={{ borderRadius: 16, border: "1px solid rgba(15,23,42,0.10)", background: "#fff", padding: 12 }}>
            <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: 0.35, textTransform: "uppercase", color: "#64748b", marginBottom: 6 }}>Audit</div>
            <div style={{ fontSize: 14, color: "#0f172a", display: "grid", gap: 6 }}>
              <div><strong>Created:</strong> {fmtDt(row.createdAt)}</div>
              <div><strong>Updated:</strong> {fmtDt(row.updatedAt)}</div>
            </div>
          </div>

          <div style={{ display: "grid", gap: 8, marginTop: 4 }}>
            {canUpdate ? <button type="button" className="btn btn--primary" onClick={onEdit}>Edit</button> : null}
            {canDelete ? <button type="button" className="btn btn--ghost btn--sm" onClick={onDisable} style={{ color: "#b91c1c", borderColor: "rgba(185,28,28,0.20)" }}>Disable SLA</button> : null}
          </div>
        </div>
      </div>
    </div>
  );
}

export function SlasPage() {
  const [me, setMe] = useState<MeResponse | null>(null);
  const [rows, setRows] = useState<SlaRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<"ALL" | "ACTIVE" | "INACTIVE">("ALL");
  const [detailRow, setDetailRow] = useState<SlaRow | null>(null);
  const [editingRow, setEditingRow] = useState<SlaRow | null>(null);
  const [formOpen, setFormOpen] = useState(false);
  const [form, setForm] = useState<FormState>(defaultForm());
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    getMe().then(setMe).catch(() => setMe(null));
  }, []);

  const canRead = hasAnyPerm(me, [...SLAS_PAGE_PERMISSIONS]);
  const canCreate = hasAnyPerm(me, [...SLAS_CREATE_PERMISSIONS]);
  const canUpdate = hasAnyPerm(me, [...SLAS_UPDATE_PERMISSIONS]);
  const canDelete = hasAnyPerm(me, [...SLAS_DELETE_PERMISSIONS]);

  async function refresh() {
    setLoading(true);
    setError(null);
    try {
      const data = await listMasters<SlaRow>("/masters/slas", { q: search.trim() || undefined, includeInactive: true });
      setRows(Array.isArray(data) ? data : []);
    } catch (e: any) {
      setError(e?.message || "Failed to load SLAs");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (!canRead) return;
    refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [canRead]);

  const visibleRows = useMemo(() => {
    const q = search.trim().toLowerCase();
    return rows.filter((row) => {
      if (statusFilter !== "ALL" && String(row.status || "").toUpperCase() !== statusFilter) return false;
      if (!q) return true;
      const hay = [row.name, row.code, row.description, formatDurationLabel(row), String(row.targetMinutes ?? ""), String(row.hoursTarget)]
        .filter(Boolean)
        .join(" ")
        .toLowerCase();
      return hay.includes(q);
    });
  }, [rows, search, statusFilter]);

  function openCreate() {
    setEditingRow(null);
    setForm(defaultForm());
    setFormOpen(true);
  }

  function openEdit(row: SlaRow) {
    setEditingRow(row);
    setForm(rowToForm(row));
    setFormOpen(true);
  }

  async function submit() {
    try {
      setSaving(true);
      setError(null);
      const payload = cleanPayload(form);
      if (editingRow) await updateMaster<SlaRow>("/masters/slas", editingRow.id, payload);
      else await createMaster<SlaRow>("/masters/slas", payload);
      setFormOpen(false);
      setEditingRow(null);
      setForm(defaultForm());
      await refresh();
    } catch (e: any) {
      setError(e?.message || "Failed to save SLA");
    } finally {
      setSaving(false);
    }
  }

  async function doDisable(row: SlaRow) {
    if (!canDelete) return;
    if (!window.confirm(`Disable SLA "${row.name}"?`)) return;
    try {
      setError(null);
      await disableMaster("/masters/slas", row.id);
      if (detailRow?.id === row.id) setDetailRow(null);
      await refresh();
    } catch (e: any) {
      setError(e?.message || "Failed to disable SLA");
    }
  }

  if (!canRead) return <div style={{ padding: 16 }}>You do not have access to Masters.</div>;

  return (
    <div style={{ padding: 16, display: "grid", gap: 16 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
        <div>
          <h2 style={{ margin: 0, fontSize: 28, color: "#0f172a" }}>SLAs</h2>
        </div>
        {canCreate ? (
          <button type="button" className="btn btn--primary" onClick={openCreate}>
            Create SLA
          </button>
        ) : null}
      </div>

      {error ? <div style={{ color: "#b91c1c", fontWeight: 700 }}>{error}</div> : null}

      <section className="card" style={{ padding: 14, borderRadius: 20, display: "grid", gap: 12 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
          <div>
            <div style={{ fontSize: 18, fontWeight: 900, color: "#0f172a" }}>Existing SLAs</div>
            <div style={{ fontSize: 13, color: "#64748b", marginTop: 2 }}>{visibleRows.length} item{visibleRows.length === 1 ? "" : "s"}</div>
          </div>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search name, code, description"
              style={{ minWidth: 240 }}
            />
            <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value as "ALL" | "ACTIVE" | "INACTIVE") }>
              <option value="ALL">All statuses</option>
              <option value="ACTIVE">Active</option>
              <option value="INACTIVE">Inactive</option>
            </select>
            <button type="button" className="btn btn--ghost" onClick={() => { setSearch(""); setStatusFilter("ALL"); }}>
              Clear filters
            </button>
            <button type="button" className="btn btn--ghost" onClick={refresh} disabled={loading}>
              {loading ? "Refreshing..." : "Refresh"}
            </button>
          </div>
        </div>

        {loading ? (
          <div style={{ padding: 24, color: "#64748b" }}>Loading SLAs...</div>
        ) : visibleRows.length === 0 ? (
          <div style={{ padding: 24, color: "#64748b" }}>No SLAs found.</div>
        ) : (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))", gap: 16 }}>
            {visibleRows.map((row) => {
              const tone = statusTone(row.status);
              return (
                <button
                  key={row.id}
                  type="button"
                  onClick={() => setDetailRow(row)}
                  className="card"
                  style={{
                    textAlign: "left",
                    borderRadius: 20,
                    padding: 14,
                    border: "1px solid rgba(15,23,42,0.08)",
                    background: "linear-gradient(180deg, #ffffff 0%, #fbfdff 100%)",
                    boxShadow: "0 8px 24px rgba(15,23,42,0.06)",
                    display: "grid",
                    gap: 12,
                    cursor: "pointer",
                    minHeight: 156,
                  }}
                >
                  <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 10 }}>
                    <div style={{ minWidth: 0 }}>
                      <div style={{ fontSize: 13, color: "#475569", marginBottom: 4 }}>{row.code || "SLA"} <span style={{ display: "inline-flex", marginLeft: 6, borderRadius: 999, padding: "2px 8px", fontSize: 11, fontWeight: 800, background: tone.bg, color: tone.color }}>{row.status || "ACTIVE"}</span></div>
                      <div style={{ fontSize: 17, fontWeight: 900, color: "#0f172a", lineHeight: 1.25, wordBreak: "break-word" }}>{row.name}</div>
                    </div>
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: 10 }}>
                    <div style={{ borderRadius: 14, border: "1px solid rgba(15,23,42,0.08)", background: "#fff", padding: 10 }}>
                      <div style={{ fontSize: 11, fontWeight: 800, color: "#64748b", letterSpacing: 0.35, textTransform: "uppercase", marginBottom: 6 }}>Target</div>
                      <div style={{ fontSize: 19, fontWeight: 900, color: "#0f172a", lineHeight: 1.1 }}>{formatDurationLabel(row)}</div>
                    </div>
                    <div style={{ borderRadius: 14, border: "1px solid rgba(15,23,42,0.08)", background: "#fff", padding: 10 }}>
                      <div style={{ fontSize: 11, fontWeight: 800, color: "#64748b", letterSpacing: 0.35, textTransform: "uppercase", marginBottom: 6 }}>Updated</div>
                      <div style={{ fontSize: 13, fontWeight: 700, color: "#0f172a", lineHeight: 1.2 }}>{fmtDt(row.updatedAt)}</div>
                    </div>
                  </div>

                  <div style={{ display: "flex", alignItems: "center", gap: 10, marginTop: "auto" }}>
                    <div style={{ width: 30, height: 30, borderRadius: 999, display: "grid", placeItems: "center", background: "rgba(15,23,42,0.06)", color: "#334155", flex: "0 0 auto" }}>
                      <SlaIcon />
                    </div>
                    <div style={{ fontSize: 14, color: "#0f172a", fontWeight: 700 }}>Service level agreement</div>
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </section>

      <SlaDetailsModal
        row={detailRow}
        onClose={() => setDetailRow(null)}
        onEdit={() => {
          if (!detailRow) return;
          setDetailRow(null);
          openEdit(detailRow);
        }}
        onDisable={() => {
          if (!detailRow) return;
          void doDisable(detailRow);
        }}
        canUpdate={canUpdate}
        canDelete={canDelete}
      />

      <AppModal
        open={formOpen}
        onClose={() => {
          setFormOpen(false);
          setEditingRow(null);
        }}
        title={editingRow ? "Edit SLA" : "Create SLA"}
        subtitle={editingRow ? "Update the SLA details." : "Add a new SLA."}
        width="md"
        footer={
          <div style={{ display: "flex", justifyContent: "flex-end", gap: 8, width: "100%" }}>
            <button type="button" className="btn btn--ghost" onClick={() => { setFormOpen(false); setEditingRow(null); }} disabled={saving}>Cancel</button>
            <button type="button" className="btn btn--primary" onClick={submit} disabled={saving}>{saving ? "Saving..." : editingRow ? "Save changes" : "Create SLA"}</button>
          </div>
        }
      >
        <div style={{ display: "grid", gap: 12 }}>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: 12 }}>
            <label style={{ display: "grid", gap: 6 }}>
              <span>Name</span>
              <input value={form.name} onChange={(e) => setForm((prev) => ({ ...prev, name: e.target.value }))} placeholder="Standard 24H" />
            </label>
            <label style={{ display: "grid", gap: 6 }}>
              <span>Code</span>
              <input value={form.code} onChange={(e) => setForm((prev) => ({ ...prev, code: e.target.value }))} placeholder="STD24 (optional)" />
            </label>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "minmax(0, 1.3fr) minmax(0, 0.9fr) minmax(0, 1fr)", gap: 12 }}>
            <label style={{ display: "grid", gap: 6 }}>
              <span>Target duration</span>
              <input type="number" min={1} step={1} value={form.durationValue} onChange={(e) => setForm((prev) => ({ ...prev, durationValue: e.target.value }))} placeholder="24" />
            </label>
            <label style={{ display: "grid", gap: 6 }}>
              <span>Unit</span>
              <select value={form.durationUnit} onChange={(e) => setForm((prev) => ({ ...prev, durationUnit: e.target.value as "HOURS" | "MINUTES" }))}>
                <option value="HOURS">Hours</option>
                <option value="MINUTES">Minutes</option>
              </select>
            </label>
            <label style={{ display: "grid", gap: 6 }}>
              <span>Status</span>
              <select value={form.status} onChange={(e) => setForm((prev) => ({ ...prev, status: e.target.value as "ACTIVE" | "INACTIVE" }))}>
                <option value="ACTIVE">ACTIVE</option>
                <option value="INACTIVE">INACTIVE</option>
              </select>
            </label>
          </div>

          <label style={{ display: "grid", gap: 6 }}>
            <span>Description</span>
            <textarea value={form.description} onChange={(e) => setForm((prev) => ({ ...prev, description: e.target.value }))} placeholder="Optional" rows={4} />
          </label>
        </div>
      </AppModal>
    </div>
  );
}
