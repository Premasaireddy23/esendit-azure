import { useEffect, useMemo, useState } from "react";
import { useSearchParams } from "react-router-dom";
import { listMasters } from "../mastersApi";
import type { SelectOption } from "../types";
import { MasterCreateFormPage } from "../MasterCreateFormPage";
import { AGENCY_TEAMS_CREATE_PERMISSIONS } from "../mastersPermissions";

const AGENCY_TYPES = ["MEDIA", "CREATIVE", "POST_HOUSE", "PRODUCTION_HOUSE", "AUDIO", "UPLOADER"] as const;
type AgencyType = (typeof AGENCY_TYPES)[number];
type AgencyRow = { id: string; name: string; type?: string; status?: string };

function prettyType(t: string) {
  switch (t) {
    case "MEDIA": return "Media Agency";
    case "CREATIVE": return "Creative";
    case "POST_HOUSE": return "Post House";
    case "PRODUCTION_HOUSE": return "Production House";
    case "AUDIO": return "Audio";
    case "UPLOADER": return "Uploader";
    default: return t;
  }
}
function normalizeTypeParam(v: string | null): AgencyType | null {
  if (!v) return null;
  const up = v.toUpperCase();
  return (AGENCY_TYPES as readonly string[]).includes(up) ? (up as AgencyType) : null;
}

export function AgencyTeamsCreatePage() {
  const [sp] = useSearchParams();
  const typeFilter = normalizeTypeParam(sp.get("type"));
  const preselectAgencyId = (sp.get("agencyId") || "").trim();
  const [agencies, setAgencies] = useState<SelectOption[]>([]);

  useEffect(() => {
    listMasters<AgencyRow>("/masters/agencies")
      .then((rows) => {
        const filtered = typeFilter ? rows.filter((r) => String(r.type || "").toUpperCase() === typeFilter) : rows;
        return filtered.map((r) => ({
          value: r.id,
          label: `${r.name}${r.type ? ` (${prettyType(String(r.type))})` : ""}${r.status === "INACTIVE" ? " (inactive)" : ""}`,
        }));
      })
      .then(setAgencies)
      .catch(() => setAgencies([]));
  }, [typeFilter]);

  const fields = useMemo(
    () => [
      { name: "agencyId", label: "Agency", type: "select" as const, required: true, options: agencies },
      { name: "name", label: "Team Name", type: "text" as const, required: true },
      { name: "emails", label: "Email IDs", type: "emails" as const, help: "You can add multiple emails using comma" },
      { name: "contactNo", label: "Contact No", type: "text" as const },
      { name: "gstNumber", label: "GST Number", type: "text" as const },
      { name: "panNumber", label: "PAN Number", type: "text" as const },
      { name: "address", label: "Address", type: "textarea" as const },
      { name: "remarks", label: "Remarks", type: "textarea" as const },
    ],
    [agencies],
  );

  const heading = typeFilter ? `Add ${prettyType(typeFilter)} Team` : "Add Agency Team";

  return (
    <MasterCreateFormPage
      heading={heading}
      apiPath="/masters/agency-teams"
      backTo="/masters/agency-teams"
      fields={fields}
      defaultCreate={preselectAgencyId ? { agencyId: preselectAgencyId } : undefined}
      submitLabel={heading}
          createPermissionsAny={[...AGENCY_TEAMS_CREATE_PERMISSIONS]}
    />
  );
}
