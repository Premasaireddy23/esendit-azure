import { useEffect, useState } from "react";
import { getMe, hasPerm, type MeResponse } from "../../../lib/me";
import { MasterCrudPage } from "../MasterCrudPage";

export function CountriesPage() {
  const [me, setMe] = useState<MeResponse | null>(null);
  useEffect(() => {
    getMe().then(setMe).catch(() => setMe(null));
  }, []);

  return (
    <MasterCrudPage
      title="Countries"
      path="/masters/countries"
      canCreate={hasPerm(me, "MASTERS_CREATE")}
      canUpdate={hasPerm(me, "MASTERS_UPDATE")}
      canDelete={hasPerm(me, "MASTERS_DELETE")}
      columns={[
        { key: "name", label: "Name" },
        { key: "iso2", label: "ISO2" },
        { key: "status", label: "Status" },
      ]}
      fields={[
        { name: "name", label: "Name", type: "text", required: true, placeholder: "e.g. Ireland" },
        { name: "iso2", label: "ISO2", type: "text", placeholder: "e.g. IE" },
      ]}
    />
  );
}
