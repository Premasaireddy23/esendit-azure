import { useEffect, useMemo, useState } from "react";
import { listMasters } from "../mastersApi";
import type { SelectOption } from "../types";
import { MasterCreateFormPage } from "../MasterCreateFormPage";
import { ADVERTISERS_CREATE_PERMISSIONS } from "../mastersPermissions";

type GroupRow = { id: string; name: string; status?: string };

export function AdvertisersCreatePage() {
  const [groups, setGroups] = useState<SelectOption[]>([]);

  useEffect(() => {
    listMasters<GroupRow>("/masters/advertiser-groups")
      .then((rows) =>
        rows.map((r) => ({
          value: r.id,
          label: `${r.name}${r.status === "INACTIVE" ? " (inactive)" : ""}`,
        })),
      )
      .then(setGroups)
      .catch(() => setGroups([]));
  }, []);

  const fields = useMemo(
    () => [
      { name: "name", label: "Advertiser Name", type: "text" as const, required: true },
      {
        name: "advertiserGroupId",
        label: "Advertiser Group",
        type: "select" as const,
        options: groups,
        placeholder: "optional",
      },
      { name: "contactNo", label: "Contact No", type: "text" as const, placeholder: "optional" },
      { name: "gstNumber", label: "GST No", type: "text" as const, placeholder: "optional" },
      { name: "panNumber", label: "PAN No", type: "text" as const, placeholder: "optional" },
      { name: "address", label: "Address", type: "textarea" as const, placeholder: "optional" },
      {
        name: "emails",
        label: "Email IDs",
        type: "emails" as const,
        help: "You can add multiple emails using comma",
      },
      { name: "remarks", label: "Remarks", type: "textarea" as const, placeholder: "optional" },
    ],
    [groups],
  );

  return (
    <MasterCreateFormPage
      heading="Add Advertiser"
      apiPath="/masters/advertisers"
      backTo="/masters/advertisers"
      fields={fields}
      submitLabel="Add Advertiser"
          createPermissionsAny={[...ADVERTISERS_CREATE_PERMISSIONS]}
    />
  );
}
