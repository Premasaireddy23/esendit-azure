import { useEffect, useMemo, useState } from "react";
import { getMe, hasAnyPerm, type MeResponse } from "../../../lib/me";
import {
  BRANDS_CREATE_PERMISSIONS,
  BRANDS_DELETE_PERMISSIONS,
  BRANDS_UPDATE_PERMISSIONS,
} from "../mastersPermissions";
import { listMasters } from "../mastersApi";
import { MasterCrudPage } from "../MasterCrudPage";
import type { SelectOption } from "../types";

type AdvertiserRow = { id: string; name: string; status?: string };

export function BrandsPage() {
  const [me, setMe] = useState<MeResponse | null>(null);
  const [advertisers, setAdvertisers] = useState<SelectOption[]>([]);

  useEffect(() => {
    getMe().then(setMe).catch(() => setMe(null));
  }, []);

  useEffect(() => {
    listMasters<AdvertiserRow>("/masters/advertisers")
      .then((rows) =>
        rows.map((r) => ({
          value: r.id,
          label: `${r.name}${r.status === "INACTIVE" ? " (inactive)" : ""}`,
        })),
      )
      .then(setAdvertisers)
      .catch(() => setAdvertisers([]));
  }, []);

  const fields = useMemo(
    () => [
      { name: "name", label: "Name", type: "text" as const, required: true, placeholder: "e.g. Brand A" },
      { name: "advertiserId", label: "Advertiser", type: "select" as const, required: true, options: advertisers },
      { name: "emails", label: "Emails", type: "emails" as const, placeholder: "a@x.com, b@x.com", help: "Comma-separated" },

      { name: "contactNo", label: "Contact No", type: "text" as const, placeholder: "optional" },
      { name: "address", label: "Address", type: "textarea" as const, placeholder: "optional" },

      { name: "gstNumber", label: "GST Number", type: "text" as const, placeholder: "optional" },
      { name: "panNumber", label: "PAN Number", type: "text" as const, placeholder: "optional" },

      { name: "remarks", label: "Remarks", type: "textarea" as const, placeholder: "optional" },
    ],
    [advertisers],
  );

  return (
    <MasterCrudPage
      title="Brands"
      path="/masters/brands"
      canCreate={hasAnyPerm(me, [...BRANDS_CREATE_PERMISSIONS])}
      canUpdate={hasAnyPerm(me, [...BRANDS_UPDATE_PERMISSIONS])}
      canDelete={hasAnyPerm(me, [...BRANDS_DELETE_PERMISSIONS])}
      columns={[
        { key: "name", label: "Name" },
        { key: "advertiserId", label: "AdvertiserId" },
        {
          key: "emails",
          label: "Emails",
          render: (r: any) => (Array.isArray(r.emails) ? r.emails.join(", ") : ""),
        },
        { key: "gstNumber", label: "GST" },
        { key: "panNumber", label: "PAN" },
        { key: "status", label: "Status" },
      ]}
      fields={fields}
      supportsInactive
      supportsEnableAndPermanentDelete
      enhancedCrudUi
      createTo="/masters/brands/new"
      createLabel="Add"
    />
  );
}
