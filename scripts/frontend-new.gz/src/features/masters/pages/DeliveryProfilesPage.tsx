import { useEffect, useMemo, useState } from "react";
import { api, type ApiError } from "../../../lib/api";
import { StatusPill } from "../../../ui/StatusPill";

type MasterStatus = "ACTIVE" | "INACTIVE";
type DeliveryProtocol = "SFTP" | "FTP" | "S3" | "EMAIL" | "ASPERA" | "FILECATALYST";
type DeliveryWorkerRoute = "ACA" | "STATIC_VM";
type CreateProfileSection = "protocol" | "route" | "status" | "connection" | "check" | "advanced";

type DeliveryProfile = {
  id: string;
  name: string;
  protocol: DeliveryProtocol;
  status: MasterStatus;
  active?: boolean;
  config?: any;
  stagingPath?: string | null;
  finalPath?: string | null;
  lastStatus?: string | null;
  lastCheckedAt?: string | null;
  lastError?: string | null;
};

type TestResult = {
  checkedAt?: string;
  protocol?: DeliveryProtocol;
  status?: string;
  latencyMs?: number | null;
  message?: string | null;
};

type DeliveryProfileListStatusFilter = "ALL" | MasterStatus;
type DeliveryProfileListProtocolFilter = "ALL" | DeliveryProtocol;
type DeliveryProfileListRouteFilter = "ALL" | DeliveryWorkerRoute;
type DeliveryProfileListHealthFilter = "ALL" | "ONLINE" | "OFFLINE" | "UNKNOWN";

function safeJsonParse(text: string, fallback: any) {
  try {
    if (!text?.trim()) return fallback;
    return JSON.parse(text);
  } catch {
    return fallback;
  }
}

function pretty(v: any) {
  try {
    return JSON.stringify(v ?? {}, null, 2);
  } catch {
    return "{}";
  }
}

function defaultsFor(p: DeliveryProtocol) {
  switch (p) {
    case "SFTP":
      return { host: "", port: 22, username: "", password: "" };
    case "FTP":
      return { host: "", port: 21, username: "", password: "" };
    case "S3":
      return { bucket: "", region: "", prefix: "" };
    case "EMAIL":
      return { to: "", cc: "", subject: "", from: "" };
    case "ASPERA":
      return { host: "", port: 33001, username: "", password: "", rateMbps: 0 };
    case "FILECATALYST":
      return { host: "", port: 21, username: "", password: "", secure: true, rateKbps: 0, numThreads: 1, autoResume: true };
    default:
      return {};
  }
}

function normalizeProtocolConfig(protocol: DeliveryProtocol, raw: any) {
  const cfg = { ...(raw ?? {}) } as Record<string, any>;
  if (protocol === "SFTP" || protocol === "FTP") {
    delete cfg.path;
  }
  return cfg;
}
function pathVariantsFromConfig(raw: any) {
  const cfg = raw && typeof raw === "object" ? raw : {};
  return {
    sdStagingPath: String((cfg as any).sdStagingPath || "").trim(),
    sdFinalPath: String((cfg as any).sdFinalPath || "").trim(),
    hdStagingPath: String((cfg as any).hdStagingPath || "").trim(),
    hdFinalPath: String((cfg as any).hdFinalPath || "").trim(),
  };
}

function withPathVariants(raw: any, next: { sdStagingPath?: string | null; sdFinalPath?: string | null; hdStagingPath?: string | null; hdFinalPath?: string | null }) {
  const cfg = raw && typeof raw === "object" ? { ...raw } : {};
  const mappings: Array<[keyof typeof next, string]> = [
    ["sdStagingPath", "sdStagingPath"],
    ["sdFinalPath", "sdFinalPath"],
    ["hdStagingPath", "hdStagingPath"],
    ["hdFinalPath", "hdFinalPath"],
  ];
  for (const [sourceKey, targetKey] of mappings) {
    const value = String(next[sourceKey] || "").trim();
    if (value) (cfg as any)[targetKey] = value;
    else delete (cfg as any)[targetKey];
  }
  return cfg;
}


function tryParseJson(raw: string) {
  try {
    if (!raw?.trim()) return { ok: true, value: {} } as const;
    return { ok: true, value: JSON.parse(raw) } as const;
  } catch (e: any) {
    return { ok: false, error: String(e?.message || e) } as const;
  }
}

function fmtDt(iso?: string | null) {
  if (!iso) return "—";
  try {
    const d = new Date(iso);
    if (isNaN(d.getTime())) return iso;
    return d.toLocaleString();
  } catch {
    return iso;
  }
}

function protocolLabel(p: DeliveryProtocol) {
  return p === "EMAIL" ? "Email" : p;
}

function normalizeWorkerRoute(raw: any): DeliveryWorkerRoute {
  return String(raw || "").trim().toUpperCase() === "STATIC_VM" ? "STATIC_VM" : "ACA";
}

function workerRouteLabel(route: DeliveryWorkerRoute) {
  return route === "STATIC_VM" ? "SiP" : "NSiP";
}

function workerRouteHelp(route: DeliveryWorkerRoute) {
  switch (route) {
    case "STATIC_VM":
    case "ACA":
    default:
      return "";
  }
}

function workerRouteFromConfig(raw: any): DeliveryWorkerRoute {
  const cfg = raw && typeof raw === "object" ? raw : {};
  return normalizeWorkerRoute((cfg as any).workerRoute);
}

function withWorkerRoute(raw: any, route: DeliveryWorkerRoute) {
  const cfg = raw && typeof raw === "object" ? { ...raw } : {};
  cfg.workerRoute = normalizeWorkerRoute(route);
  return cfg;
}


function testResultTone(status?: string) {
  switch (String(status || "").toUpperCase()) {
    case "ONLINE":
      return { bg: "#ecfdf3", border: "#b7e4c7", color: "#065f46" };
    case "OFFLINE":
      return { bg: "#fef2f2", border: "#fecaca", color: "#991b1b" };
    default:
      return { bg: "#f8fafc", border: "#dbe4ee", color: "#334155" };
  }
}

const DELIVERY_PROFILE_ICON_SRC = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAABHNCSVQICAgIfAhkiAAAAAlwSFlzAAAAdgAAAHYBTnsmCAAAABl0RVh0U29mdHdhcmUAd3d3Lmlua3NjYXBlLm9yZ5vuPBoAAAKfSURBVDiNhZJbSJNhHMZ/347NwzYnNpczT9hWLVwnRC0oKYION0lddBdUUChCQRAUnSyCrkoICjK8CiKJwItIsAMVbVKK8zjTOZ2bbtS+HVykza+LnC0req5envfh9/55/q9QYjW611SsUpImv1eUu957dgKj/Efy6j3rTtc37S/OM+n0AoL+SOMOvUqtULx9NvAQCKSHzSWGE1HxqxuYS3kKAGlBouVGB5nZagITX5gYCamABmBmMdcOzCeT0nX9yuyQGIz5AccSQJAJXLp/hD6nF3tNKa/b++ecne5m4GP6BIGJsAmYT/cUAJ1PeslfrcflGCdLpwEJMk1FV+UrVqyTJAS5JqNDHOxuBBLLO5ClDh9efSJbp8FUZODx03B0a1PL3oJddcXm3XVF9jM3j+VWVDmAjH8CAOw1pTy40x+QtIUm1+3zfAuH+BYO4Wq+gLbYYtOv3dj8xxakhYVdM1ORQDgU9/a883jdnqR28+UW3axvjPUnL2KsrCXuG8NWf4WZd88X4pOj937r4FP/9AGYXjLyq/d8AFZLaSEh9Voskre7xPIy5QcTsZjAMukt9pYcq/1odHwYXbkNgMhIH9piC9tmwwHL93nTlnwz45EvOP2T47LlAHG4pz7qdfdtaLiKOicPdU4etlOXUAd9gWtrK0wAHR73rw6WA4D5r9OTreKIyxgd7jVERwdEX0ebs6nMUm43FqgylSqGPgfJ1WQwFYuKir8AlEBCHOw+nuZtAuE1QCgxy9mqWlRyOU7/JOmAypVZWWaNXHnXGwnvWwTtX7wzPhrqUblCfsbCn7nV9Yq2uqMAvwEcwXh8oMxgOMfiPwfepCY4bLUfOmjdoGzt7WJTvhmZ8LP/P7bwD5VtLyx9UaLPTaab3dO+uR+tR/tl/JiMvQAAAABJRU5ErkJggg==";

function DeliveryProfileIcon() {
  return <img src={DELIVERY_PROFILE_ICON_SRC} alt="" aria-hidden="true" style={{ width: 18, height: 18, objectFit: "contain", display: "block" }} />;
}

function endpointSummary(row: DeliveryProfile) {
  const cfg = row.config && typeof row.config === "object" ? row.config : {};
  switch (row.protocol) {
    case "SFTP":
    case "FTP":
    case "ASPERA":
    case "FILECATALYST": {
      const host = String((cfg as any).host || "").trim();
      const port = String((cfg as any).port || "").trim();
      if (host && port) return `${host}:${port}`;
      return host || port || "—";
    }
    case "S3": {
      const bucket = String((cfg as any).bucket || "").trim();
      const region = String((cfg as any).region || "").trim();
      if (bucket && region) return `${bucket} · ${region}`;
      return bucket || region || "—";
    }
    case "EMAIL": {
      const to = String((cfg as any).to || "").trim();
      const subject = String((cfg as any).subject || "").trim();
      if (to && subject) return `${to} · ${subject}`;
      return to || subject || "—";
    }
    default:
      return "—";
  }
}

function healthLabel(row: DeliveryProfile): "ONLINE" | "OFFLINE" | "UNKNOWN" {
  const normalized = String(row.lastStatus || "").trim().toUpperCase();
  return normalized === "ONLINE" || normalized == "OFFLINE" ? (normalized as "ONLINE" | "OFFLINE") : "UNKNOWN";
}

function DeliveryProfileActionsModal(props: {
  row: DeliveryProfile | null;
  onClose: () => void;
  onEdit: () => void;
  onManageConnection: () => void;
  onOpenCheck: () => void;
  onDelete: () => void;
}) {
  const { row, onClose, onEdit, onManageConnection, onOpenCheck, onDelete } = props;
  if (!row) return null;
  const route = workerRouteFromConfig(row.config);
  const statusLabel = row.status || (row.active === false ? "INACTIVE" : "ACTIVE");
  const checkTone = testResultTone(row.lastStatus || undefined);
  const endpoint = endpointSummary(row);
  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(15,23,42,0.14)",
        zIndex: 85,
        display: "grid",
        placeItems: "center",
        padding: 16,
      }}
      onClick={onClose}
    >
      <div
        className="card"
        style={{ width: "min(380px, 100%)", borderRadius: 22, padding: 0, overflow: "hidden", boxShadow: "0 24px 60px rgba(15,23,42,0.20)", background: "#fff" }}
        onClick={(e) => e.stopPropagation()}
      >
        <div style={{ padding: "18px 18px 10px", display: "flex", justifyContent: "space-between", gap: 12, alignItems: "flex-start" }}>
          <div style={{ minWidth: 0 }}>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center", marginBottom: 8 }}>
              <span style={{ fontSize: 15, color: "#334155" }}>{protocolLabel(row.protocol)}</span>
              <span style={{ display: "inline-flex", alignItems: "center", borderRadius: 999, padding: "4px 8px", fontSize: 12, fontWeight: 800, background: statusLabel === "ACTIVE" ? "#eaf8ef" : "#f1f5f9", color: statusLabel === "ACTIVE" ? "#166534" : "#475569" }}>{statusLabel}</span>
            </div>
            <div style={{ fontSize: 18, fontWeight: 900, color: "#0f172a", wordBreak: "break-word" }}>{row.name}</div>
          </div>
          <button type="button" onClick={onClose} aria-label="Close" style={{ border: "none", background: "transparent", color: "#64748b", fontSize: 28, lineHeight: 1, cursor: "pointer", padding: 0 }}>×</button>
        </div>

        <div style={{ padding: "0 18px 18px", display: "grid", gap: 10 }}>
          <div style={{ borderRadius: 16, border: "1px solid rgba(15,23,42,0.10)", background: "#f8fafc", padding: 12 }}>
            <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: 0.35, textTransform: "uppercase", color: "#64748b", marginBottom: 6 }}>Endpoint</div>
            <div style={{ fontSize: 14, color: "#0f172a", wordBreak: "break-all" }}>{endpoint}</div>
          </div>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: 10 }}>
            <div style={{ borderRadius: 16, border: "1px solid rgba(15,23,42,0.10)", background: "#fff", padding: 12, minHeight: 92 }}>
              <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: 0.35, textTransform: "uppercase", color: "#64748b", marginBottom: 8 }}>Route</div>
              <div style={{ fontSize: 20, lineHeight: 1.2, fontWeight: 900, color: "#0f172a" }}>{workerRouteLabel(route)}</div>
            </div>
            <div style={{ borderRadius: 16, border: "1px solid rgba(15,23,42,0.10)", background: "#fff", padding: 12, minHeight: 92 }}>
              <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: 0.35, textTransform: "uppercase", color: "#64748b", marginBottom: 8 }}>Check</div>
              <div style={{ display: "inline-flex", alignItems: "center", borderRadius: 999, padding: "5px 10px", fontSize: 12, fontWeight: 800, background: checkTone.bg, color: checkTone.color, border: `1px solid ${checkTone.border}` }}>{row.lastStatus || "UNKNOWN"}</div>
              {row.lastCheckedAt ? <div style={{ fontSize: 12, color: "#64748b", marginTop: 8 }}>{fmtDt(row.lastCheckedAt)}</div> : null}
            </div>
          </div>

          <div style={{ borderRadius: 16, border: "1px solid rgba(15,23,42,0.10)", background: "#fff", padding: 12 }}>
            <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: 0.35, textTransform: "uppercase", color: "#64748b", marginBottom: 6 }}>Paths</div>
            <div style={{ fontSize: 14, color: "#0f172a", display: "grid", gap: 6 }}>
              <div><strong>Staging:</strong> {row.stagingPath || "—"}</div>
              <div><strong>Final:</strong> {row.finalPath || "—"}</div>
              {pathVariantsFromConfig(row.config).sdStagingPath || pathVariantsFromConfig(row.config).sdFinalPath ? (
                <div><strong>SD:</strong> {pathVariantsFromConfig(row.config).sdStagingPath || "—"} → {pathVariantsFromConfig(row.config).sdFinalPath || "—"}</div>
              ) : null}
              {pathVariantsFromConfig(row.config).hdStagingPath || pathVariantsFromConfig(row.config).hdFinalPath ? (
                <div><strong>HD:</strong> {pathVariantsFromConfig(row.config).hdStagingPath || "—"} → {pathVariantsFromConfig(row.config).hdFinalPath || "—"}</div>
              ) : null}
            </div>
          </div>

          {row.lastError ? (
            <div style={{ borderRadius: 16, border: "1px solid rgba(239,68,68,0.18)", background: "#fef2f2", padding: 12 }}>
              <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: 0.35, textTransform: "uppercase", color: "#b91c1c", marginBottom: 6 }}>Last error</div>
              <div style={{ fontSize: 13, color: "#7f1d1d", wordBreak: "break-word" }}>{row.lastError}</div>
            </div>
          ) : null}

          <div style={{ display: "grid", gap: 8, marginTop: 4 }}>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: 8 }}>
              <button type="button" className="btn btn--ghost" onClick={onEdit}>Edit</button>
              <button type="button" className="btn btn--ghost" onClick={onOpenCheck}>Check connection</button>
            </div>
            <button type="button" className="btn btn--primary" onClick={onManageConnection}>Manage connection</button>
            <button type="button" className="btn btn--ghost btn--sm" onClick={onDelete} style={{ color: "#b91c1c", borderColor: "rgba(185,28,28,0.20)" }}>Delete delivery profile</button>
          </div>
        </div>
      </div>
    </div>
  );
}

function segmentedButtonStyle(active: boolean, tone: "purple" | "green" = "purple") {
  const palette =
    tone === "green"
      ? {
          activeBg: "#dff6e7",
          activeBorder: "#86d0a2",
          activeText: "#14532d",
          activeShadow: "0 0 0 1px rgba(22,101,52,0.06), 0 8px 16px rgba(22,101,52,0.10)",
        }
      : {
          activeBg: "#ece9ff",
          activeBorder: "#8b5cf6",
          activeText: "#4c1d95",
          activeShadow: "0 0 0 1px rgba(139,92,246,0.10), 0 8px 16px rgba(76,29,149,0.12)",
        };

  return {
    minWidth: 88,
    padding: "10px 16px",
    borderRadius: 12,
    border: active ? `1.5px solid ${palette.activeBorder}` : "1px solid #d0d5dd",
    background: active ? palette.activeBg : "#ffffff",
    color: active ? palette.activeText : "#101828",
    fontWeight: active ? 800 : 700,
    boxShadow: active ? palette.activeShadow : "none",
    transform: active ? "translateY(-1px)" : "none",
    transition: "all 140ms ease",
  } as const;
}

function wizardNavButtonStyle(active: boolean) {
  return {
    width: "100%",
    textAlign: "left" as const,
    padding: "12px 14px",
    borderRadius: 12,
    border: active ? "1px solid #8b5cf6" : "1px solid #d0d5dd",
    background: active ? "#f5f3ff" : "#ffffff",
    color: active ? "#4c1d95" : "#111827",
    fontWeight: active ? 800 : 700,
    boxShadow: active ? "0 10px 24px rgba(139,92,246,0.12)" : "none",
    transition: "all 140ms ease",
  };
}

function compactSectionBodyStyle(section: CreateProfileSection) {
  const wide = section === "connection" || section === "advanced";
  return {
    width: "100%",
    maxWidth: wide ? "100%" : 760,
    display: "grid",
    gap: 12,
    alignContent: "start" as const,
    justifyItems: "stretch" as const,
  };
}

function StatusButtons({
  value,
  onChange,
  disabled,
}: {
  value: MasterStatus;
  onChange: (next: MasterStatus) => void;
  disabled?: boolean;
}) {
  const options: MasterStatus[] = ["ACTIVE", "INACTIVE"];
  return (
    <div className="row" style={{ gap: 8, flexWrap: "wrap" }}>
      {options.map((opt) => {
        const active = value === opt;
        return (
          <button
            key={opt}
            type="button"
            className="btn"
            style={{ ...segmentedButtonStyle(active, opt === "ACTIVE" ? "green" : "purple"), minWidth: 110 }}
            onClick={() => onChange(opt)}
            disabled={disabled}
            aria-pressed={active}
          >
            {opt === "ACTIVE" ? "Active" : "Inactive"}
          </button>
        );
      })}
    </div>
  );
}

function ProtocolButtons({
  value,
  onChange,
  disabled,
}: {
  value: DeliveryProtocol;
  onChange: (next: DeliveryProtocol) => void;
  disabled?: boolean;
}) {
  const options: DeliveryProtocol[] = ["SFTP", "FTP", "S3", "EMAIL", "ASPERA", "FILECATALYST"];
  return (
    <div className="row" style={{ gap: 8, flexWrap: "wrap" }}>
      {options.map((opt) => {
        const active = value === opt;
        return (
          <button
            key={opt}
            type="button"
            className="btn"
            style={segmentedButtonStyle(active, "purple")}
            onClick={() => onChange(opt)}
            disabled={disabled}
            aria-pressed={active}
          >
            {protocolLabel(opt)}
          </button>
        );
      })}
    </div>
  );
}

function WorkerRouteButtons({
  value,
  onChange,
  disabled,
}: {
  value: DeliveryWorkerRoute;
  onChange: (next: DeliveryWorkerRoute) => void;
  disabled?: boolean;
}) {
  const options: DeliveryWorkerRoute[] = ["ACA", "STATIC_VM"];
  return (
    <div className="row" style={{ gap: 8, flexWrap: "wrap" }}>
      {options.map((opt) => {
        const active = value === opt;
        return (
          <button
            key={opt}
            type="button"
            className="btn"
            style={segmentedButtonStyle(active, opt === "STATIC_VM" ? "green" : "purple")}
            onClick={() => onChange(opt)}
            disabled={disabled}
            aria-pressed={active}
            title={workerRouteHelp(opt)}
          >
            {workerRouteLabel(opt)}
          </button>
        );
      })}
    </div>
  );
}

function TestResultCard({ title, result }: { title: string; result: TestResult | null }) {
  if (!result) return null;
  const tone = testResultTone(result.status);
  return (
    <div className="card" style={{ background: tone.bg, borderColor: tone.border, color: tone.color }}>
      <div style={{ display: "grid", gap: 6 }}>
        <div style={{ fontWeight: 800 }}>{title}</div>
        <div style={{ fontSize: 13 }}>
          <strong>Status:</strong> {result.status || "UNKNOWN"}
          {typeof result.latencyMs === "number" ? ` · ${result.latencyMs} ms` : ""}
        </div>
        {result.message ? <div style={{ fontSize: 13 }}>{result.message}</div> : null}
        {result.checkedAt ? <div style={{ fontSize: 12, opacity: 0.8 }}>Checked: {fmtDt(result.checkedAt)}</div> : null}
      </div>
    </div>
  );
}

function ConfigQuickFields({
  protocol,
  configText,
  setConfigText,
}: {
  protocol: DeliveryProtocol;
  configText: string;
  setConfigText: (next: string) => void;
}) {
  const parsed = safeJsonParse(configText, defaultsFor(protocol));
  const cfg = normalizeProtocolConfig(protocol, parsed);

  function setField(key: string, value: string) {
    const next = normalizeProtocolConfig(protocol, safeJsonParse(configText, defaultsFor(protocol)));
    next[key] = ["port", "rateMbps", "rateKbps", "numThreads"].includes(key) ? (value === "" ? "" : Number(value)) : value === "true" ? true : value === "false" ? false : value;
    setConfigText(pretty(next));
  }

  if (protocol === "SFTP" || protocol === "FTP") {
    return (
      <div style={{ display: "grid", gap: 10 }}>
        <div className="row" style={{ flexWrap: "wrap", alignItems: "end" }}>
          <div style={{ minWidth: 220, flex: 1 }}>
            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Host</div>
            <input placeholder="sftp.example.com" value={String(cfg.host ?? "")} onChange={(e) => setField("host", e.target.value)} />
          </div>
          <div style={{ minWidth: 120 }}>
            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Port</div>
            <input placeholder={protocol === "SFTP" ? "22" : "21"} value={String(cfg.port ?? "")} onChange={(e) => setField("port", e.target.value)} />
          </div>
          <div style={{ minWidth: 220, flex: 1 }}>
            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Username</div>
            <input placeholder="username" value={String(cfg.username ?? "")} onChange={(e) => setField("username", e.target.value)} />
          </div>
          <div style={{ minWidth: 220, flex: 1 }}>
            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Password</div>
            <input type="password" placeholder="password" value={String(cfg.password ?? "")} onChange={(e) => setField("password", e.target.value)} />
          </div>
        </div>
      </div>
    );
  }

  if (protocol === "ASPERA") {
    return (
      <div style={{ display: "grid", gap: 10 }}>
        <div style={{ fontSize: 12, color: "#475467" }}>Use this for direct Aspera server transfers. The worker image must include the Aspera transfer engine.</div>
        <div className="row" style={{ flexWrap: "wrap", alignItems: "end" }}>
          <div style={{ minWidth: 220, flex: 1 }}>
            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Host</div>
            <input placeholder="aspera.example.com" value={String(cfg.host ?? "")} onChange={(e) => setField("host", e.target.value)} />
          </div>
          <div style={{ minWidth: 120 }}>
            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Port</div>
            <input placeholder="33001" value={String(cfg.port ?? "")} onChange={(e) => setField("port", e.target.value)} />
          </div>
          <div style={{ minWidth: 220, flex: 1 }}>
            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Username</div>
            <input placeholder="username" value={String(cfg.username ?? "")} onChange={(e) => setField("username", e.target.value)} />
          </div>
          <div style={{ minWidth: 220, flex: 1 }}>
            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Password</div>
            <input type="password" placeholder="password" value={String(cfg.password ?? "")} onChange={(e) => setField("password", e.target.value)} />
          </div>
          <div style={{ minWidth: 160 }}>
            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Rate (Mbps)</div>
            <input placeholder="optional" value={String(cfg.rateMbps ?? "")} onChange={(e) => setField("rateMbps", e.target.value)} />
          </div>
        </div>
      </div>
    );
  }

  if (protocol === "FILECATALYST") {
    return (
      <div style={{ display: "grid", gap: 10 }}>
        <div style={{ fontSize: 12, color: "#475467" }}>Use this for FileCatalyst CLI based deliveries. The worker image must include Java and the FileCatalyst client runtime.</div>
        <div className="row" style={{ flexWrap: "wrap", alignItems: "end" }}>
          <div style={{ minWidth: 220, flex: 1 }}>
            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Host</div>
            <input placeholder="filecatalyst.example.com" value={String(cfg.host ?? "")} onChange={(e) => setField("host", e.target.value)} />
          </div>
          <div style={{ minWidth: 120 }}>
            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Port</div>
            <input placeholder="21" value={String(cfg.port ?? "")} onChange={(e) => setField("port", e.target.value)} />
          </div>
          <div style={{ minWidth: 220, flex: 1 }}>
            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Username</div>
            <input placeholder="username" value={String(cfg.username ?? "")} onChange={(e) => setField("username", e.target.value)} />
          </div>
          <div style={{ minWidth: 220, flex: 1 }}>
            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Password</div>
            <input type="password" placeholder="password" value={String(cfg.password ?? "")} onChange={(e) => setField("password", e.target.value)} />
          </div>
          <div style={{ minWidth: 140 }}>
            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Rate (Kbps)</div>
            <input placeholder="optional" value={String(cfg.rateKbps ?? "")} onChange={(e) => setField("rateKbps", e.target.value)} />
          </div>
          <div style={{ minWidth: 140 }}>
            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Threads</div>
            <input placeholder="1" value={String(cfg.numThreads ?? "")} onChange={(e) => setField("numThreads", e.target.value)} />
          </div>
          <label style={{ display: "flex", alignItems: "center", gap: 8, minWidth: 150, paddingBottom: 8 }}>
            <input type="checkbox" checked={Boolean(cfg.secure)} onChange={(e) => setField("secure", e.target.checked ? "true" : "false")} />
            Secure control channel
          </label>
          <label style={{ display: "flex", alignItems: "center", gap: 8, minWidth: 150, paddingBottom: 8 }}>
            <input type="checkbox" checked={cfg.autoResume !== false} onChange={(e) => setField("autoResume", e.target.checked ? "true" : "false")} />
            Auto resume
          </label>
        </div>
      </div>
    );
  }

  if (protocol === "S3") {
    return (
      <div style={{ display: "grid", gap: 10 }}>
        <div style={{ fontSize: 12, color: "#475467" }}>Fill the common S3 details here. Use advanced JSON only for extra settings.</div>
        <div className="row" style={{ flexWrap: "wrap", alignItems: "end" }}>
          <div style={{ minWidth: 240, flex: 1 }}>
            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Bucket</div>
            <input placeholder="bucket-name" value={String(cfg.bucket ?? "")} onChange={(e) => setField("bucket", e.target.value)} />
          </div>
          <div style={{ minWidth: 180, flex: 1 }}>
            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Region</div>
            <input placeholder="eu-west-1" value={String(cfg.region ?? "")} onChange={(e) => setField("region", e.target.value)} />
          </div>
          <div style={{ minWidth: 240, flex: 1 }}>
            <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Prefix</div>
            <input placeholder="deliveries/final" value={String(cfg.prefix ?? "")} onChange={(e) => setField("prefix", e.target.value)} />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div style={{ display: "grid", gap: 10 }}>
      <div style={{ fontSize: 12, color: "#475467" }}>Fill the common email values here. Use advanced JSON only for extra settings.</div>
      <div className="row" style={{ flexWrap: "wrap", alignItems: "end" }}>
        <div style={{ minWidth: 240, flex: 1 }}>
          <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>To</div>
          <input placeholder="ops@example.com" value={String(cfg.to ?? "")} onChange={(e) => setField("to", e.target.value)} />
        </div>
        <div style={{ minWidth: 240, flex: 1 }}>
          <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>CC</div>
          <input placeholder="team@example.com" value={String(cfg.cc ?? "")} onChange={(e) => setField("cc", e.target.value)} />
        </div>
        <div style={{ minWidth: 240, flex: 1 }}>
          <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>From</div>
          <input placeholder="noreply@example.com" value={String(cfg.from ?? "")} onChange={(e) => setField("from", e.target.value)} />
        </div>
        <div style={{ minWidth: 260, flex: 1 }}>
          <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Subject</div>
          <input placeholder="Delivery notification" value={String(cfg.subject ?? "")} onChange={(e) => setField("subject", e.target.value)} />
        </div>
      </div>
    </div>
  );
}

export function DeliveryProfilesPage() {
  const [rows, setRows] = useState<DeliveryProfile[]>([]);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");
  const [banner, setBanner] = useState<string>("");

  const [listSearch, setListSearch] = useState("");
  const [listStatusFilter, setListStatusFilter] = useState<DeliveryProfileListStatusFilter>("ALL");
  const [listProtocolFilter, setListProtocolFilter] = useState<DeliveryProfileListProtocolFilter>("ALL");
  const [listRouteFilter, setListRouteFilter] = useState<DeliveryProfileListRouteFilter>("ALL");
  const [listHealthFilter, setListHealthFilter] = useState<DeliveryProfileListHealthFilter>("ALL");

  const [name, setName] = useState("");
  const [protocol, setProtocol] = useState<DeliveryProtocol>("SFTP");
  const [status, setStatus] = useState<MasterStatus>("ACTIVE");
  const [stagingPath, setStagingPath] = useState("");
  const [finalPath, setFinalPath] = useState("");
  const [sdStagingPath, setSdStagingPath] = useState("");
  const [sdFinalPath, setSdFinalPath] = useState("");
  const [hdStagingPath, setHdStagingPath] = useState("");
  const [hdFinalPath, setHdFinalPath] = useState("");
  const [configText, setConfigText] = useState(pretty(withWorkerRoute(defaultsFor("SFTP"), "ACA")));
  const [createTestResult, setCreateTestResult] = useState<TestResult | null>(null);
  const [testingCreate, setTestingCreate] = useState(false);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [createSection, setCreateSection] = useState<CreateProfileSection>("protocol");

  const [actionRow, setActionRow] = useState<DeliveryProfile | null>(null);
  const [edit, setEdit] = useState<DeliveryProfile | null>(null);
  const [editSdStagingPath, setEditSdStagingPath] = useState("");
  const [editSdFinalPath, setEditSdFinalPath] = useState("");
  const [editHdStagingPath, setEditHdStagingPath] = useState("");
  const [editHdFinalPath, setEditHdFinalPath] = useState("");
  const [editConfigText, setEditConfigText] = useState("{}");
  const [editTestResult, setEditTestResult] = useState<TestResult | null>(null);
  const [testingEdit, setTestingEdit] = useState(false);
  const [editSection, setEditSection] = useState<CreateProfileSection>("protocol");

  async function load() {
    setErr("");
    try {
      const data: any = await api<any>("/masters/delivery-profiles");
      const arr: any[] = Array.isArray(data) ? data : (data?.rows ?? data ?? []);
      const normalized: DeliveryProfile[] = arr.map((r: any) => ({
        ...r,
        status: r.status ?? (r.active === false ? "INACTIVE" : "ACTIVE"),
      }));
      setRows(normalized);
    } catch (e: any) {
      setErr((e as ApiError)?.message || "Failed to load delivery profiles");
    }
  }

  useEffect(() => {
    load();
  }, []);

  useEffect(() => {
    if (!banner) return;
    const t = setTimeout(() => setBanner(""), 2200);
    return () => clearTimeout(t);
  }, [banner]);

  const canCreate = useMemo(() => name.trim().length > 0, [name]);

  const createWorkerRoute = workerRouteFromConfig(safeJsonParse(configText, defaultsFor(protocol)));
  const editWorkerRoute = workerRouteFromConfig(safeJsonParse(editConfigText, edit ? defaultsFor(edit.protocol) : {}));

  const filteredRows = useMemo(() => {
    const term = listSearch.trim().toLowerCase();
    return rows.filter((row) => {
      const statusLabel = row.status || (row.active === false ? "INACTIVE" : "ACTIVE");
      const route = workerRouteFromConfig(row.config);
      const health = healthLabel(row);
      if (listStatusFilter !== "ALL" && statusLabel !== listStatusFilter) return false;
      if (listProtocolFilter !== "ALL" && row.protocol !== listProtocolFilter) return false;
      if (listRouteFilter !== "ALL" && route !== listRouteFilter) return false;
      if (listHealthFilter !== "ALL" && health !== listHealthFilter) return false;
      if (!term) return true;

      const hay = [
        row.name,
        protocolLabel(row.protocol),
        statusLabel,
        workerRouteLabel(route),
        health,
        endpointSummary(row),
        row.stagingPath,
        row.finalPath,
        row.lastError,
      ]
        .filter(Boolean)
        .join(" ")
        .toLowerCase();

      return hay.includes(term);
    });
  }, [rows, listSearch, listStatusFilter, listProtocolFilter, listRouteFilter, listHealthFilter]);

  function setCreateWorkerRoute(nextRoute: DeliveryWorkerRoute) {
    const nextConfig = withWorkerRoute(normalizeProtocolConfig(protocol, safeJsonParse(configText, defaultsFor(protocol))), nextRoute);
    setConfigText(pretty(nextConfig));
  }

  function setEditWorkerRoute(nextRoute: DeliveryWorkerRoute) {
    if (!edit) return;
    const nextConfig = withWorkerRoute(normalizeProtocolConfig(edit.protocol, safeJsonParse(editConfigText, defaultsFor(edit.protocol))), nextRoute);
    setEditConfigText(pretty(nextConfig));
  }

  function resetCreateDraft() {
    setName("");
    setProtocol("SFTP");
    setStatus("ACTIVE");
    setStagingPath("");
    setFinalPath("");
    setSdStagingPath("");
    setSdFinalPath("");
    setHdStagingPath("");
    setHdFinalPath("");
    setConfigText(pretty(withWorkerRoute(defaultsFor("SFTP"), "ACA")));
    setCreateTestResult(null);
    setCreateSection("protocol");
  }

  function openCreateModal() {
    setErr("");
    setCreateSection("protocol");
    setShowCreateModal(true);
  }

  function closeCreateModal() {
    setShowCreateModal(false);
    setCreateTestResult(null);
    setErr("");
  }

  function createSectionTitle(section: CreateProfileSection) {
    switch (section) {
      case "protocol":
        return "Protocol";
      case "route":
        return "Delivery route";
      case "status":
        return "Status";
      case "connection":
        return "Connection details";
      case "check":
        return "Check connection";
      case "advanced":
        return "Advanced config";
      default:
        return "Delivery profile";
    }
  }

  function prettifyCreate() {
    const parsed = tryParseJson(configText);
    if (!parsed.ok) {
      setErr(`Invalid JSON config: ${parsed.error}`);
      return;
    }
    setConfigText(pretty(withWorkerRoute(normalizeProtocolConfig(protocol, parsed.value), createWorkerRoute)));
    setBanner("Advanced config prettified");
  }

  function applyDefaultsCreate() {
    setConfigText(pretty(withWorkerRoute(defaultsFor(protocol), createWorkerRoute)));
    setBanner("Starter config applied");
  }

  function prettifyEdit() {
    if (!edit) return;
    const parsed = tryParseJson(editConfigText);
    if (!parsed.ok) {
      setErr(`Invalid JSON config: ${parsed.error}`);
      return;
    }
    setEditConfigText(pretty(withWorkerRoute(normalizeProtocolConfig(edit.protocol, parsed.value), editWorkerRoute)));
    setBanner("Advanced config prettified");
  }

  function applyDefaultsEdit() {
    if (!edit) return;
    setEditConfigText(pretty(withWorkerRoute(defaultsFor(edit.protocol), editWorkerRoute)));
    setBanner("Starter config applied");
  }

  async function runConnectionTest(payload: { protocol: DeliveryProtocol; configText: string }) {
    const parsed = tryParseJson(payload.configText);
    if (!parsed.ok) {
      throw new Error(`Invalid JSON config: ${parsed.error}`);
    }
    return api<TestResult>("/masters/delivery-profiles/test", {
      method: "POST",
      body: JSON.stringify({
        protocol: payload.protocol,
        config: normalizeProtocolConfig(payload.protocol, parsed.value),
        timeoutMs: 3000,
      }),
    });
  }

  async function testCreateConnection() {
    setTestingCreate(true);
    setErr("");
    setCreateTestResult(null);
    try {
      const result = await runConnectionTest({ protocol, configText });
      setCreateTestResult(result);
      setBanner("Connection check completed");
    } catch (e: any) {
      setErr((e as ApiError)?.message || String(e?.message || e) || "Connection test failed");
    } finally {
      setTestingCreate(false);
    }
  }

  async function testEditConnection() {
    if (!edit) return;
    setTestingEdit(true);
    setErr("");
    setEditTestResult(null);
    try {
      const result = await runConnectionTest({ protocol: edit.protocol, configText: editConfigText });
      setEditTestResult(result);
      setBanner("Connection check completed");
    } catch (e: any) {
      setErr((e as ApiError)?.message || String(e?.message || e) || "Connection test failed");
    } finally {
      setTestingEdit(false);
    }
  }

  async function create() {
    if (!canCreate) return;
    setBusy(true);
    setErr("");
    try {
      const config = withPathVariants(
        normalizeProtocolConfig(protocol, safeJsonParse(configText, defaultsFor(protocol))),
        { sdStagingPath, sdFinalPath, hdStagingPath, hdFinalPath },
      );
      await api("/masters/delivery-profiles", {
        method: "POST",
        body: JSON.stringify({
          name: name.trim(),
          protocol,
          status,
          stagingPath: stagingPath.trim() || null,
          finalPath: finalPath.trim() || null,
          config,
        }),
      });
      resetCreateDraft();
      setShowCreateModal(false);
      setBanner("Delivery profile created");
      await load();
    } catch (e: any) {
      setErr((e as ApiError)?.message || "Create failed (check advanced config)");
    } finally {
      setBusy(false);
    }
  }

  async function patch(id: string, data: Partial<DeliveryProfile>) {
    setBusy(true);
    setErr("");
    try {
      await api(`/masters/delivery-profiles/${id}`, {
        method: "PATCH",
        body: JSON.stringify(data),
      });
      setBanner("Changes saved");
      await load();
    } catch (e: any) {
      setErr((e as ApiError)?.message || "Update failed");
    } finally {
      setBusy(false);
    }
  }

  async function remove(id: string) {
    if (!confirm("Delete this delivery profile?")) return;
    setBusy(true);
    setErr("");
    try {
      await api(`/masters/delivery-profiles/${id}`, { method: "DELETE" });
      setBanner("Delivery profile deleted");
      await load();
    } catch (e: any) {
      setErr((e as ApiError)?.message || "Delete failed");
    } finally {
      setBusy(false);
    }
  }

  function openEditAtSection(row: DeliveryProfile, section: CreateProfileSection = "protocol") {
    setEdit({ ...row });
    const variants = pathVariantsFromConfig(row.config ?? {});
    setEditSdStagingPath(variants.sdStagingPath);
    setEditSdFinalPath(variants.sdFinalPath);
    setEditHdStagingPath(variants.hdStagingPath);
    setEditHdFinalPath(variants.hdFinalPath);
    setEditConfigText(pretty(withWorkerRoute(normalizeProtocolConfig(row.protocol, row.config ?? {}), workerRouteFromConfig(row.config))));
    setEditTestResult(null);
    setEditSection(section);
  }


  async function saveEdit() {
    if (!edit) return;
    const config = withPathVariants(normalizeProtocolConfig(edit.protocol, safeJsonParse(editConfigText, {})), {
      sdStagingPath: editSdStagingPath,
      sdFinalPath: editSdFinalPath,
      hdStagingPath: editHdStagingPath,
      hdFinalPath: editHdFinalPath,
    });
    await patch(edit.id, {
      name: edit.name?.trim(),
      protocol: edit.protocol,
      status: (edit.status as any) || undefined,
      stagingPath: edit.stagingPath ?? null,
      finalPath: edit.finalPath ?? null,
      config,
    });
    setEditSdStagingPath("");
    setEditSdFinalPath("");
    setEditHdStagingPath("");
    setEditHdFinalPath("");
    setEdit(null);
  }

  return (
    <div className="masters-wrap">
      <div className="card card--soft" style={{ display: "grid", gap: 10 }}>
        <div className="page-head">
          <div className="page-head__title">
            <h3 style={{ margin: 0 }}>Delivery Profiles</h3>
          </div>
          <div className="row" style={{ gap: 8, flexWrap: "wrap" }}>
            <button className="btn btn--ghost" onClick={load} disabled={busy}>Refresh</button>
            <button className="btn btn--primary" onClick={openCreateModal} disabled={busy}>Add Delivery Profile</button>
          </div>
        </div>

        {banner && (
          <div className="card" style={{ borderColor: "rgba(0,0,0,0.12)", background: "rgba(0,0,0,0.03)" }}>
            {banner}
          </div>
        )}

        {err && !showCreateModal && <div className="card" style={{ borderColor: "#f5a", background: "#fff5fa" }}>{err}</div>}

      <div style={{ display: "grid", gap: 10 }}>
        <div className="card" style={{ borderRadius: 18, background: "rgba(248,250,252,0.85)", border: "1px solid rgba(15,23,42,0.08)", display: "grid", gap: 10 }}>
          <div className="row" style={{ flexWrap: "wrap", alignItems: "end", gap: 10 }}>
            <div style={{ minWidth: 220, flex: 1 }}>
              <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Search</div>
              <input placeholder="Search delivery profiles" value={listSearch} onChange={(e) => setListSearch(e.target.value)} />
            </div>
            <div style={{ minWidth: 180 }}>
              <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Protocol</div>
              <select value={listProtocolFilter} onChange={(e) => setListProtocolFilter(e.target.value as DeliveryProfileListProtocolFilter)}>
                <option value="ALL">All protocols</option>
                <option value="SFTP">SFTP</option>
                <option value="FTP">FTP</option>
                <option value="S3">S3</option>
                <option value="EMAIL">Email</option>
                <option value="ASPERA">Aspera</option>
                <option value="FILECATALYST">FileCatalyst</option>
              </select>
            </div>
            <div style={{ minWidth: 180 }}>
              <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Status</div>
              <select value={listStatusFilter} onChange={(e) => setListStatusFilter(e.target.value as DeliveryProfileListStatusFilter)}>
                <option value="ALL">All statuses</option>
                <option value="ACTIVE">Active</option>
                <option value="INACTIVE">Inactive</option>
              </select>
            </div>
            <div style={{ minWidth: 180 }}>
              <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Route</div>
              <select value={listRouteFilter} onChange={(e) => setListRouteFilter(e.target.value as DeliveryProfileListRouteFilter)}>
                <option value="ALL">All routes</option>
                <option value="ACA">{workerRouteLabel("ACA")}</option>
                <option value="STATIC_VM">{workerRouteLabel("STATIC_VM")}</option>
              </select>
            </div>
            <div style={{ minWidth: 180 }}>
              <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Health</div>
              <select value={listHealthFilter} onChange={(e) => setListHealthFilter(e.target.value as DeliveryProfileListHealthFilter)}>
                <option value="ALL">All health</option>
                <option value="ONLINE">Online</option>
                <option value="OFFLINE">Offline</option>
                <option value="UNKNOWN">Unknown</option>
              </select>
            </div>
            <button
              type="button"
              className="btn btn--ghost btn--sm"
              onClick={() => {
                setListSearch("");
                setListProtocolFilter("ALL");
                setListStatusFilter("ALL");
                setListRouteFilter("ALL");
                setListHealthFilter("ALL");
              }}
              disabled={!listSearch && listProtocolFilter === "ALL" && listStatusFilter === "ALL" && listRouteFilter === "ALL" && listHealthFilter === "ALL"}
            >
              Clear filters
            </button>
          </div>
        </div>

        {rows.length === 0 ? (
          <div className="card" style={{ opacity: 0.72 }}>No delivery profiles</div>
        ) : filteredRows.length === 0 ? (
          <div className="card" style={{ borderColor: "rgba(0,0,0,0.10)", background: "rgba(0,0,0,0.03)", textAlign: "center", color: "#64748b" }}>
            No delivery profiles match the current filters.
          </div>
        ) : (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(250px, 1fr))", gap: 12 }}>
            {filteredRows.map((r) => {
              const route = workerRouteFromConfig(r.config);
              const statusLabel = r.status || (r.active === false ? "INACTIVE" : "ACTIVE");
              const active = actionRow?.id === r.id;
              return (
                <button
                  key={r.id}
                  type="button"
                  className="card"
                  onClick={() => setActionRow(r)}
                  disabled={busy}
                  style={{
                    borderRadius: 20,
                    padding: 18,
                    background: "#fff",
                    display: "grid",
                    gap: 14,
                    minHeight: 188,
                    textAlign: "left",
                    cursor: busy ? "not-allowed" : "pointer",
                    boxShadow: active ? "0 18px 40px rgba(37,99,235,0.16)" : "0 10px 28px rgba(15,23,42,0.07)",
                    border: active ? "1px solid rgba(37,99,235,0.30)" : "1px solid rgba(15,23,42,0.08)",
                    transition: "transform 180ms ease, box-shadow 180ms ease, border-color 180ms ease",
                  }}
                >
                  <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "flex-start" }}>
                    <div style={{ minWidth: 0 }}>
                      <div style={{ fontSize: 17, fontWeight: 900, color: "#0f172a", lineHeight: 1.2, wordBreak: "break-word" }}>{r.name}</div>
                      <div style={{ marginTop: 8, display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
                        <span style={{ fontSize: 15, color: "#334155" }}>{protocolLabel(r.protocol)}</span>
                        <span style={{ display: "inline-flex", alignItems: "center", borderRadius: 999, padding: "4px 8px", fontSize: 12, fontWeight: 800, background: statusLabel === "ACTIVE" ? "#eaf8ef" : "#f1f5f9", color: statusLabel === "ACTIVE" ? "#166534" : "#475569" }}>{statusLabel}</span>
                      </div>
                    </div>
                    <span style={{ fontSize: 12, fontWeight: 800, color: active ? "#2563eb" : "#94a3b8", whiteSpace: "nowrap" }}>Details</span>
                  </div>

                  <div style={{ borderRadius: 14, border: "1px solid rgba(15,23,42,0.08)", background: "#f8fafc", padding: "10px 12px", minHeight: 58 }}>
                    <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: 0.35, textTransform: "uppercase", color: "#64748b", marginBottom: 6 }}>Endpoint</div>
                    <div style={{ fontSize: 14, color: "#0f172a", wordBreak: "break-word" }}>{endpointSummary(r)}</div>
                  </div>

                  <div style={{ flex: 1 }} />

                  <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "flex-end" }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 10, minWidth: 0 }}>
                      <DeliveryProfileIcon />
                      <div style={{ minWidth: 0 }}>
                        <div style={{ fontSize: 15, fontWeight: 700, color: "#0f172a", wordBreak: "break-word" }}>{workerRouteLabel(route)}</div>
                      </div>
                    </div>
                    <div style={{ fontSize: 13, fontWeight: 700, color: "#64748b", whiteSpace: "nowrap" }}>{healthLabel(r)}</div>
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </div>

      <DeliveryProfileActionsModal
        row={actionRow}
        onClose={() => setActionRow(null)}
        onEdit={() => {
          if (!actionRow) return;
          const row = actionRow;
          setActionRow(null);
          openEditAtSection(row, "protocol");
        }}
        onManageConnection={() => {
          if (!actionRow) return;
          const row = actionRow;
          setActionRow(null);
          openEditAtSection(row, "connection");
        }}
        onOpenCheck={() => {
          if (!actionRow) return;
          const row = actionRow;
          setActionRow(null);
          openEditAtSection(row, "check");
        }}
        onDelete={() => {
          if (!actionRow) return;
          const id = actionRow.id;
          setActionRow(null);
          void remove(id);
        }}
      />

      {showCreateModal && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(15, 23, 42, 0.45)",
            display: "grid",
            placeItems: "center",
            padding: 16,
            zIndex: 60,
          }}
          onClick={closeCreateModal}
        >
          <div
            className="card"
            style={{ width: "min(1040px, 94vw)", maxHeight: "88vh", overflow: "auto", background: "#ffffff", borderColor: "#e5e7eb", boxShadow: "0 24px 80px rgba(15, 23, 42, 0.22)" }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="row" style={{ justifyContent: "space-between", alignItems: "center", gap: 12 }}>
              <div>
                <h3 style={{ margin: 0 }}>Add Delivery Profile</h3>
              </div>
              <button className="btn btn--ghost" onClick={closeCreateModal} disabled={busy || testingCreate}>Close</button>
            </div>

            <div style={{ display: "grid", gap: 12, marginTop: 12 }}>
              <div className="card" style={{ background: "#ffffff", borderColor: "#e5e7eb", display: "grid", gap: 12 }}>
                <div style={{ fontWeight: 800 }}>Basic details</div>
                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
                    gap: 10,
                    alignItems: "end",
                  }}
                >
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Name</div>
                    <input placeholder="Profile name" value={name} onChange={(e) => setName(e.target.value)} />
                  </div>
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Staging Path</div>
                    <input placeholder="/staging" value={stagingPath} onChange={(e) => setStagingPath(e.target.value)} />
                  </div>
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Final Path</div>
                    <input placeholder="/final" value={finalPath} onChange={(e) => setFinalPath(e.target.value)} />
                  </div>
                </div>
              </div>

              <div className="card" style={{ background: "#ffffff", borderColor: "#e5e7eb", display: "grid", gap: 12 }}>
                <div style={{ fontWeight: 800 }}>HD / SD path overrides</div>
                <div style={{ fontSize: 12, color: "#475467" }}>
                  Optional. When a destination is marked as HD or SD, these paths override the default staging/final paths.
                </div>
                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
                    gap: 10,
                    alignItems: "end",
                  }}
                >
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>SD Staging Path</div>
                    <input placeholder="/sd/staging" value={sdStagingPath} onChange={(e) => setSdStagingPath(e.target.value)} />
                  </div>
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>SD Final Path</div>
                    <input placeholder="/sd/final" value={sdFinalPath} onChange={(e) => setSdFinalPath(e.target.value)} />
                  </div>
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>HD Staging Path</div>
                    <input placeholder="/hd/staging" value={hdStagingPath} onChange={(e) => setHdStagingPath(e.target.value)} />
                  </div>
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>HD Final Path</div>
                    <input placeholder="/hd/final" value={hdFinalPath} onChange={(e) => setHdFinalPath(e.target.value)} />
                  </div>
                </div>
              </div>

              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: "minmax(210px, 240px) minmax(0, 1fr)",
                  gap: 12,
                  alignItems: "start",
                }}
              >
                <div className="card" style={{ background: "#ffffff", borderColor: "#e5e7eb", display: "grid", gap: 8 }}>
                  {[
                    { key: "protocol", label: "Protocol", note: protocolLabel(protocol) },
                    { key: "route", label: "Delivery route", note: workerRouteLabel(createWorkerRoute) },
                    { key: "status", label: "Status", note: status === "ACTIVE" ? "Active" : "Inactive" },
                    { key: "connection", label: "Connection details", note: protocolLabel(protocol) },
                    { key: "check", label: "Check connection", note: createTestResult?.status || "Not checked" },
                    { key: "advanced", label: "Advanced config", note: "JSON" },
                  ].map((item) => {
                    const active = createSection === item.key;
                    return (
                      <button
                        key={item.key}
                        type="button"
                        className="btn"
                        style={wizardNavButtonStyle(active)}
                        onClick={() => setCreateSection(item.key as CreateProfileSection)}
                      >
                        <div style={{ fontSize: 14 }}>{item.label}</div>
                        <div style={{ fontSize: 12, opacity: 0.78, marginTop: 4 }}>{item.note}</div>
                      </button>
                    );
                  })}
                </div>

                <div className="card" style={{ background: "#ffffff", borderColor: "#e5e7eb", display: "grid", gap: 12, alignContent: "start" }}>
                  <div>
                    <div style={{ fontSize: 18, fontWeight: 800 }}>{createSectionTitle(createSection)}</div>
                    <div style={{ fontSize: 13, color: "#475467", marginTop: 4 }}>
                      {createSection === "route" && workerRouteHelp(createWorkerRoute)}
                      {createSection === "advanced" && "Optional. Use this only for extra protocol-specific settings that are not exposed in the normal form."}
                    </div>
                  </div>

                  {createSection === "protocol" && (
                    <div style={compactSectionBodyStyle(createSection)}>
                      <ProtocolButtons
                        value={protocol}
                        onChange={(next) => {
                          setProtocol(next);
                          const nextConfig = withWorkerRoute(defaultsFor(next), createWorkerRoute);
                          setConfigText(pretty(nextConfig));
                          setCreateTestResult(null);
                        }}
                        disabled={busy || testingCreate}
                      />
                    </div>
                  )}

                  {createSection === "route" && (
                    <div style={compactSectionBodyStyle(createSection)}>
                      <WorkerRouteButtons
                        value={createWorkerRoute}
                        onChange={setCreateWorkerRoute}
                        disabled={busy || testingCreate}
                      />
                      <div className="card" style={{ background: "#f8fafc", borderColor: "#e2e8f0" }}>
                        <div style={{ fontSize: 13, color: "#334155" }}>{workerRouteHelp(createWorkerRoute)}</div>
                      </div>
                    </div>
                  )}

                  {createSection === "status" && (
                    <div style={compactSectionBodyStyle(createSection)}>
                      <StatusButtons value={status} onChange={setStatus} disabled={busy || testingCreate} />
                    </div>
                  )}

                  {createSection === "connection" && (
                    <div style={compactSectionBodyStyle(createSection)}>
                      <ConfigQuickFields protocol={protocol} configText={configText} setConfigText={setConfigText} />
                    </div>
                  )}

                  {createSection === "check" && (
                    <div style={compactSectionBodyStyle(createSection)}>
                      <div className="card" style={{ background: "#f8fafc", borderColor: "#e2e8f0" }}>
                        <div style={{ fontSize: 13, color: "#334155" }}>
                          Selected protocol: <strong>{protocolLabel(protocol)}</strong> · Route: <strong>{workerRouteLabel(createWorkerRoute)}</strong>
                        </div>
                      </div>
                      <div className="row" style={{ gap: 8, flexWrap: "wrap" }}>
                        <button type="button" className="btn btn--ghost" onClick={testCreateConnection} disabled={busy || testingCreate}>
                          {testingCreate ? "Checking..." : "Test connection"}
                        </button>
                      </div>
                      <TestResultCard title="Connection check" result={createTestResult} />
                    </div>
                  )}

                  {createSection === "advanced" && (
                    <div style={compactSectionBodyStyle(createSection)}>
                      <div className="row" style={{ justifyContent: "space-between", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
                        <div style={{ fontSize: 12, fontWeight: 700 }}>Advanced Config (JSON)</div>
                        <div className="row" style={{ gap: 8, flexWrap: "wrap" }}>
                          <button type="button" className="btn btn--ghost btn--sm" onClick={applyDefaultsCreate} disabled={busy} title="Load a starter config for the selected protocol">Use defaults</button>
                          <button type="button" className="btn btn--ghost btn--sm" onClick={prettifyCreate} disabled={busy} title="Format JSON">Prettify</button>
                        </div>
                      </div>
                      <textarea
                        className="codearea"
                        style={{ width: "100%", minHeight: 220 }}
                        value={configText}
                        onChange={(e) => setConfigText(e.target.value)}
                      />
                    </div>
                  )}
                </div>
              </div>

              {err && <div className="card" style={{ borderColor: "#f5a", background: "#fff5fa" }}>{err}</div>}

              <div className="row" style={{ justifyContent: "flex-end", gap: 8, flexWrap: "wrap" }}>
                <button className="btn btn--ghost" onClick={closeCreateModal} disabled={busy || testingCreate}>Cancel</button>
                <button className="btn btn--primary" onClick={create} disabled={busy || !canCreate}>
                  {busy ? "Saving..." : "Create"}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {edit && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(15, 23, 42, 0.45)",
            display: "grid",
            placeItems: "center",
            padding: 16,
            zIndex: 60,
          }}
          onClick={() => setEdit(null)}
        >
          <div
            className="card"
            style={{ width: "min(1040px, 94vw)", maxHeight: "88vh", overflow: "auto", background: "#ffffff", borderColor: "#e5e7eb", boxShadow: "0 24px 80px rgba(15, 23, 42, 0.22)" }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="row" style={{ justifyContent: "space-between", alignItems: "center", gap: 12 }}>
              <div>
                <h3 style={{ margin: 0 }}>Edit Delivery Profile</h3>
              </div>
              <button className="btn btn--ghost" onClick={() => setEdit(null)} disabled={busy || testingEdit}>Close</button>
            </div>

            <div style={{ display: "grid", gap: 12, marginTop: 12 }}>
              <div className="card" style={{ background: "#ffffff", borderColor: "#e5e7eb", display: "grid", gap: 12 }}>
                <div style={{ fontWeight: 800 }}>Basic details</div>
                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
                    gap: 10,
                    alignItems: "end",
                  }}
                >
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Name</div>
                    <input value={edit.name || ""} onChange={(e) => setEdit({ ...edit, name: e.target.value })} />
                  </div>
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Staging Path</div>
                    <input value={edit.stagingPath || ""} onChange={(e) => setEdit({ ...edit, stagingPath: e.target.value })} />
                  </div>
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>Final Path</div>
                    <input value={edit.finalPath || ""} onChange={(e) => setEdit({ ...edit, finalPath: e.target.value })} />
                  </div>
                  <div className="card" style={{ background: "#f8fafc", borderColor: "#e2e8f0", padding: 12 }}>
                    <div style={{ fontSize: 11, color: "#667085", marginBottom: 6 }}>Server status</div>
                    <StatusPill status={edit.lastStatus || "UNKNOWN"} title={edit.lastError || ""} />
                    <div style={{ fontSize: 11, color: "#667085", marginTop: 8 }}>Last checked: {fmtDt(edit.lastCheckedAt)}</div>
                  </div>
                </div>
              </div>

              <div className="card" style={{ background: "#ffffff", borderColor: "#e5e7eb", display: "grid", gap: 12 }}>
                <div style={{ fontWeight: 800 }}>HD / SD path overrides</div>
                <div style={{ fontSize: 12, color: "#475467" }}>
                  Optional. When a destination is marked as HD or SD, these paths override the default staging/final paths.
                </div>
                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
                    gap: 10,
                    alignItems: "end",
                  }}
                >
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>SD Staging Path</div>
                    <input value={editSdStagingPath} onChange={(e) => setEditSdStagingPath(e.target.value)} />
                  </div>
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>SD Final Path</div>
                    <input value={editSdFinalPath} onChange={(e) => setEditSdFinalPath(e.target.value)} />
                  </div>
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>HD Staging Path</div>
                    <input value={editHdStagingPath} onChange={(e) => setEditHdStagingPath(e.target.value)} />
                  </div>
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 700, marginBottom: 4 }}>HD Final Path</div>
                    <input value={editHdFinalPath} onChange={(e) => setEditHdFinalPath(e.target.value)} />
                  </div>
                </div>
              </div>

              <div
                className="card"
                style={{
                  background: "#ffffff",
                  borderColor: "#e5e7eb",
                  display: "grid",
                  gridTemplateColumns: "220px minmax(0, 1fr)",
                  gap: 14,
                  alignItems: "start",
                }}
              >
                <div style={{ display: "grid", gap: 8, alignContent: "start" }}>
                  {([
                    "protocol",
                    "route",
                    "status",
                    "connection",
                    "check",
                    "advanced",
                  ] as CreateProfileSection[]).map((section) => (
                    <button
                      key={section}
                      type="button"
                      className="btn"
                      style={wizardNavButtonStyle(editSection === section)}
                      onClick={() => setEditSection(section)}
                      disabled={busy || testingEdit}
                    >
                      {createSectionTitle(section)}
                    </button>
                  ))}
                </div>

                <div style={{ display: "grid", gap: 12, alignContent: "start", minHeight: 0 }}>
                  <div>
                    <div style={{ fontSize: 12, fontWeight: 700, color: "#667085", marginBottom: 6 }}>Current section</div>
                    <div style={{ fontSize: 18, fontWeight: 800 }}>{createSectionTitle(editSection)}</div>
                  </div>

                  {editSection === "protocol" && (
                    <div style={compactSectionBodyStyle(editSection)}>
                      <ProtocolButtons
                        value={edit.protocol}
                        onChange={(nextProtocol) => {
                          setEdit({ ...edit, protocol: nextProtocol });
                          const nextConfig = withWorkerRoute(normalizeProtocolConfig(nextProtocol, safeJsonParse(editConfigText, defaultsFor(nextProtocol))), editWorkerRoute);
                          setEditConfigText(pretty(nextConfig));
                          setEditTestResult(null);
                        }}
                        disabled={busy || testingEdit}
                      />
                    </div>
                  )}

                  {editSection === "route" && (
                    <div style={compactSectionBodyStyle(editSection)}>
                      <WorkerRouteButtons
                        value={editWorkerRoute}
                        onChange={setEditWorkerRoute}
                        disabled={busy || testingEdit}
                      />
                      <div style={{ fontSize: 12, color: "#475467" }}>{workerRouteHelp(editWorkerRoute)}</div>
                    </div>
                  )}

                  {editSection === "status" && (
                    <div style={compactSectionBodyStyle(editSection)}>
                      <StatusButtons
                        value={edit.status}
                        onChange={(nextStatus) => setEdit({ ...edit, status: nextStatus })}
                        disabled={busy || testingEdit}
                      />
                    </div>
                  )}

                  {editSection === "connection" && (
                    <div style={compactSectionBodyStyle(editSection)}>
                      <ConfigQuickFields protocol={edit.protocol} configText={editConfigText} setConfigText={setEditConfigText} />
                      {edit.lastError && (
                        <div className="card" style={{ borderColor: "#f5a", background: "#fff5fa" }}>
                          <div style={{ fontWeight: 800, marginBottom: 6 }}>Last Error</div>
                          <div style={{ whiteSpace: "pre-wrap" }}>{edit.lastError}</div>
                        </div>
                      )}
                    </div>
                  )}

                  {editSection === "check" && (
                    <div style={compactSectionBodyStyle(editSection)}>
                      <div className="card" style={{ background: "#f8fafc", borderColor: "#e2e8f0" }}>
                        <div style={{ fontSize: 13, color: "#334155" }}>
                          Selected protocol: <strong>{protocolLabel(edit.protocol)}</strong> · Route: <strong>{workerRouteLabel(editWorkerRoute)}</strong>
                        </div>
                      </div>
                      <div className="row" style={{ gap: 8, flexWrap: "wrap" }}>
                        <button type="button" className="btn btn--ghost" onClick={testEditConnection} disabled={busy || testingEdit}>
                          {testingEdit ? "Checking..." : "Test connection"}
                        </button>
                      </div>
                      <TestResultCard title="Connection check" result={editTestResult} />
                    </div>
                  )}

                  {editSection === "advanced" && (
                    <div style={compactSectionBodyStyle(editSection)}>
                      <div className="row" style={{ justifyContent: "space-between", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
                        <div style={{ fontSize: 12, fontWeight: 700 }}>Advanced Config (JSON)</div>
                        <div className="row" style={{ gap: 8, flexWrap: "wrap" }}>
                          <button type="button" className="btn btn--ghost btn--sm" onClick={applyDefaultsEdit} disabled={busy} title="Load a starter config for the selected protocol">Use defaults</button>
                          <button type="button" className="btn btn--ghost btn--sm" onClick={prettifyEdit} disabled={busy} title="Format JSON">Prettify</button>
                        </div>
                      </div>
                      <textarea
                        className="codearea"
                        style={{ width: "100%", minHeight: 220 }}
                        value={editConfigText}
                        onChange={(e) => setEditConfigText(e.target.value)}
                      />
                    </div>
                  )}
                </div>
              </div>

              {err && <div className="card" style={{ borderColor: "#f5a", background: "#fff5fa" }}>{err}</div>}

              <div className="row" style={{ justifyContent: "space-between", gap: 8, flexWrap: "wrap" }}>
                <div className="row" style={{ gap: 8, flexWrap: "wrap" }}>
                  <button
                    className="btn btn--ghost"
                    onClick={() => patch(edit.id, { status: edit.status === "ACTIVE" ? "INACTIVE" : "ACTIVE" })}
                    disabled={busy || testingEdit}
                  >
                    {edit.status === "ACTIVE" ? "Set inactive" : "Set active"}
                  </button>
                  <button className="btn btn--danger" onClick={() => { const id = edit.id; setEdit(null); remove(id); }} disabled={busy || testingEdit}>
                    Delete
                  </button>
                </div>
                <div className="row" style={{ gap: 8, flexWrap: "wrap" }}>
                  <button className="btn btn--ghost" onClick={() => setEdit(null)} disabled={busy || testingEdit}>Cancel</button>
                  <button className="btn btn--primary" onClick={saveEdit} disabled={busy || !edit.name?.trim()}>
                    {busy ? "Saving..." : "Save"}
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
      </div>
    </div>
  );
}
