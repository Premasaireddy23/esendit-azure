import { useEffect, useMemo, useState } from "react";
import { api } from "../../lib/api";
import { getMe, hasPerm, type MeResponse } from "../../lib/me";
import { presetDisplayName, presetExtBadge } from "./presetDisplay";
import { SearchSelect } from "../../ui/SearchSelect";

type Preset = { key: string; label?: string; ext: string; mimeType: string; args: string[] };
type DestinationLite = { id: string; name: string };
type PresetJob = {
  id: string;
  status: "QUEUED" | "RUNNING" | "SUCCEEDED" | "FAILED" | string;
  error?: string | null;
};

export function PresetDownloadModal(props: {
  title: string;
  sourceType: "CREATIVE" | "DAM" | "BULK";
  sourceId: string;
  // Optional: if provided, backend can use destination-level overrides.
  destinationId?: string | null;
  lockDestination?: boolean;
  onClose: () => void;
}) {
  const [destinationId, setDestinationId] = useState<string>(props.destinationId || "");
  const destinationLocked = Boolean(props.lockDestination && props.destinationId);
  const [destinations, setDestinations] = useState<DestinationLite[]>([]);
  const [presets, setPresets] = useState<Preset[]>([]);
  const [selectedKey, setSelectedKey] = useState<string>("");
  const [jobId, setJobId] = useState<string>("");
  const [job, setJob] = useState<PresetJob | null>(null);
  const [error, setError] = useState<string>("");
  const [showTechnical, setShowTechnical] = useState(false);
  const [downloading, setDownloading] = useState(false);
  const [me, setMe] = useState<MeResponse | null>(null);

  const selectedPreset = useMemo(
    () => presets.find((p) => p.key === selectedKey) || null,
    [presets, selectedKey]
  );

  const canDownloadMedia = hasPerm(me, "action:media:download");

  useEffect(() => {
    getMe().then(setMe).catch(() => setMe(null));
  }, []);

  useEffect(() => {
    if (props.destinationId !== undefined) {
      setDestinationId(props.destinationId || "");
    }
  }, [props.destinationId]);

  // Non-blocking: load destinations so user can filter presets by destination
  useEffect(() => {
    api<any[]>("/masters/destinations")
      .then((d) => setDestinations(Array.isArray(d) ? d.map((x: any) => ({ id: String(x.id), name: String(x.name || x.id) })) : []))
      .catch(() => setDestinations([]));
  }, []);

  // Fetch presets (global library or destination filtered)
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        setError("");
        const p = destinationId ? `/presets/destinations/${encodeURIComponent(destinationId)}` : `/presets`;
        const r = await api<{ presets: Preset[] }>(p);
        if (cancelled) return;
        const list = r?.presets || [];
        setPresets(list);
        if (!list.find((x) => x.key === selectedKey)) setSelectedKey(list[0]?.key || "");
      } catch (e: any) {
        if (!cancelled) setError(e?.message || String(e));
      }
    })();
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [destinationId]);

  async function request(presetKey: string) {
    setError("");
    setJob(null);
    setJobId("");

    try {
      const body: any = {
        sourceType: props.sourceType,
        sourceId: props.sourceId,
        presetKey,
      };
      // destinationId is optional now; include only if user provided one
      if (destinationId && destinationId.trim()) body.destinationId = destinationId.trim();

      const j = await api<any>(`/presets/jobs`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      const id = j?.id || j?.jobId;
      if (!id) throw new Error("Preset job creation succeeded but no job id returned.");

      setJobId(id);
      setJob(j);
    } catch (e: any) {
      setError(e?.message || String(e));
    }
  }

  // Poll job status
  useEffect(() => {
    if (!jobId) return;

    let cancelled = false;
    const tick = async () => {
      try {
        const j = await api<any>(`/presets/jobs/${jobId}`);
        if (cancelled) return;
        setJob(j);

        const st = j?.status;
        if (st === "SUCCEEDED" || st === "FAILED") return; // stop polling
        setTimeout(tick, 2000);
      } catch (e: any) {
        if (!cancelled) setError(e?.message || String(e));
        setTimeout(tick, 3000);
      }
    };

    const t = setTimeout(tick, 500);
    return () => {
      cancelled = true;
      clearTimeout(t);
    };
  }, [jobId]);

  async function downloadOutput() {
    if (!jobId || job?.status !== "SUCCEEDED" || !canDownloadMedia) return;

    setError("");
    setDownloading(true);

    // Open a blank tab immediately so browsers don't block the final download URL
    // after the authenticated API call returns.
    const pendingWindow = window.open("", "_blank", "noopener,noreferrer");

    try {
      const r = await api<{ url?: string | null }>(`/presets/jobs/${jobId}/stream-url`);
      const url = String(r?.url || "").trim();
      if (!url) throw new Error("Converted output is ready but no download URL was returned.");

      if (pendingWindow) {
        pendingWindow.location.href = url;
      } else {
        window.location.assign(url);
      }
    } catch (e: any) {
      if (pendingWindow) pendingWindow.close();
      setError(e?.message || String(e) || "Download failed");
    } finally {
      setDownloading(false);
    }
  }

  const actionButtonStyle = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    minHeight: 38,
    padding: "10px 14px",
    borderRadius: 10,
    border: "1px solid #1f6feb",
    background: "#1f6feb",
    color: "#fff",
    fontWeight: 700,
    fontSize: 14,
    textDecoration: "none",
    cursor: "pointer",
    boxShadow: "0 1px 2px rgba(16, 24, 40, 0.12)",
  };

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.35)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: 1000,
      }}
      onClick={props.onClose}
    >
      <div
        style={{
          background: "#fff",
          width: 720,
          maxWidth: "95vw",
          borderRadius: 12,
          padding: 16,
        }}
        onClick={(e) => e.stopPropagation()}
      >
        <div style={{ display: "flex", justifyContent: "space-between", gap: 12 }}>
          <div style={{ fontWeight: 800, fontSize: 18 }}>{props.title}</div>
          <button className="btn" onClick={props.onClose}>
            Close
          </button>
        </div>

        <div style={{ marginTop: 12 }}>
          {!canDownloadMedia ? (
            <div className="card" style={{ border: "1px solid #f59e0b", color: "#92400e", background: "#fffbeb" }}>
              Unauthorised
            </div>
          ) : null}

          {error ? (
            <div className="card" style={{ border: "1px solid #a10000", color: "#a10000" }}>
              {error}
            </div>
          ) : null}

          <div className="card" style={{ display: "grid", gap: 10 }}>
            <div style={{ display: "grid", gap: 6 }}>
              <div style={{ fontWeight: 700 }}>Format / Preset</div>
              <select
                value={selectedKey}
                onChange={(e) => setSelectedKey(e.target.value)}
                style={{ padding: 8 }}
              >
                {presets.map((p) => (
                  <option key={p.key} value={p.key}>
                    {presetDisplayName(p)} ({presetExtBadge(p) || p.ext})
                  </option>
                ))}
              </select>

              <label style={{ display: "flex", gap: 8, alignItems: "center", fontSize: 12, opacity: 0.85 }}>
                <input
                  type="checkbox"
                  checked={showTechnical}
                  onChange={(e) => setShowTechnical(e.target.checked)}
                />
                Show technical details
              </label>

              {selectedPreset && showTechnical ? (
                <div style={{ opacity: 0.75, fontSize: 12 }}>
                  key: <code>{selectedPreset.key}</code> · mime: <code>{selectedPreset.mimeType}</code>
                </div>
              ) : null}
            </div>

            <div style={{ display: "grid", gap: 6 }}>
              {destinationLocked ? (
                <>
                  <div style={{ fontWeight: 700 }}>Destination</div>
                  <div
                    style={{
                      minHeight: 40,
                      border: "1px solid #d0d7de",
                      borderRadius: 10,
                      padding: "10px 12px",
                      background: "#f8fafc",
                      display: "flex",
                      alignItems: "center",
                    }}
                  >
                    {destinations.find((d) => d.id === destinationId)?.name || "Selected destination"}
                  </div>
                  <div style={{ opacity: 0.75, fontSize: 12 }}>
                    Showing only presets allowed for this destination.
                  </div>
                </>
              ) : (
                <>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "end", gap: 10 }}>
                    <div style={{ flex: 1, minWidth: 260 }}>
                      <SearchSelect
                        label="Destination (optional)"
                        value={destinationId}
                        onChange={setDestinationId}
                        options={destinations}
                        placeholder="Search destination"
                      />
                    </div>
                    <button className="btn" onClick={() => setDestinationId("")} disabled={!destinationId} title="Clear destination">
                      Clear
                    </button>
                  </div>
                </>
              )}
            </div>

            <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
              <button
                className="btn btn-primary"
                disabled={!selectedKey}
                onClick={() => request(selectedKey)}
              >
                Start conversion
              </button>
              {jobId ? <span style={{ opacity: 0.75 }}>Job: {jobId}</span> : null}
            </div>
          </div>

          {job ? (
            <div className="card" style={{ marginTop: 12, display: "grid", gap: 10 }}>
              <div style={{ fontWeight: 800 }}>Job status: {job.status}</div>
              {job.error ? <div style={{ color: "#a10000" }}>{job.error}</div> : null}
              {job.status === "SUCCEEDED" ? (
                <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
                  <button
                    type="button"
                    onClick={downloadOutput}
                    disabled={downloading}
                    style={{
                      ...actionButtonStyle,
                      opacity: downloading ? 0.7 : 1,
                      cursor: downloading ? "progress" : actionButtonStyle.cursor,
                    }}
                  >
                    {downloading ? "Preparing download..." : "Download output"}
                  </button>
                  <span style={{ opacity: 0.72, fontSize: 12 }}>
                    Your converted file is ready.
                  </span>
                </div>
              ) : null}
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
}
