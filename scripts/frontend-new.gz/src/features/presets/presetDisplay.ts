// Customer-friendly preset labels.
//
// Backend preset "key" may come from legacy Windows batch filenames (e.g. "IMX50MXF.bat").
// We keep keys stable for API calls, but show a clean label in the UI.

export type PresetLike = { key: string; label?: string | null; ext?: string | null };

const LEGACY_EXT_RE = /\.(bat|sh|cmd|ps1)$/i;

function stripLegacyExt(s: string) {
  return s.replace(LEGACY_EXT_RE, "");
}

function stripPath(s: string) {
  // If someone pasted a filename with a path into label, drop the path.
  return s.replace(/^.*[\\/]/, "");
}

function shortForm(s: string) {
  // If label contains verbose details, keep only the first chunk.
  const splitters = [" - ", " | ", " :: "];
  for (const sp of splitters) {
    const idx = s.indexOf(sp);
    if (idx > 0) return s.slice(0, idx);
  }
  // Also trim anything after an opening bracket (often used for details).
  const bracketIdx = Math.min(
    ...["(", "[", "{"].map((ch) => {
      const i = s.indexOf(ch);
      return i === -1 ? Number.POSITIVE_INFINITY : i;
    })
  );
  if (Number.isFinite(bracketIdx) && bracketIdx > 0) return s.slice(0, bracketIdx);
  return s;
}

export function presetDisplayName(p: PresetLike) {
  const base = (p.label || p.key || "").trim();
  let s = stripPath(base);
  s = stripLegacyExt(s);
  s = shortForm(s);

  // Normalize separators for readability
  s = s.replace(/[_\-]+/g, " ");
  s = s.replace(/\s+/g, " ").trim();

  return s || p.key;
}

export function presetExtBadge(p: PresetLike) {
  const ext = (p.ext || "").trim();
  return ext ? ext.toUpperCase() : "";
}
