import { api } from "../../lib/api";

export type DamAsset = {
  id: string;
  type: "SOURCE"|"PROXY"|"OUTPUT";
  uploadStatus: string;
  filename?: string|null;
  mimeType?: string|null;
  sizeBytes?: string | number | null;
};
export type DamItem = {
  id: string;
  uniqueEditKey: string;
  sourceType?: "DAM" | "CREATIVE" | "BULK" | string | null;
  sourceCreativeId?: string | null;
  valid?: string|null;
  caption?: string|null;
  format?: string|null;
  languages: string[];
  duration?: string|null;
  remarks?: string|null;
  qcStatus: string;
  qcReport?: any;
  assets: DamAsset[];
  createdAt?: string;
  updatedAt: string;
};

export async function listDam(params: {
  q?: string;
  format?: string;
  valid?: string;
  qcStatus?: string;
  language?: string;
  skip?: number;
  take?: number;
}) {
  const qs = new URLSearchParams();
  if (params.q) qs.set("q", params.q);
  if (params.format) qs.set("format", params.format);
  if (params.valid) qs.set("valid", params.valid);
  if (params.qcStatus) qs.set("qcStatus", params.qcStatus);
  if (params.language) qs.set("language", params.language);
  if (params.skip != null) qs.set("skip", String(params.skip));
  if (params.take != null) qs.set("take", String(params.take));
  return api<{ rows: DamItem[]; total: number }>(`/dam/items?${qs.toString()}`);
}

export async function indexCreativeToDam(creativeId: string) {
  return api(`/dam/index/creative/${creativeId}`, { method: "POST", body: "{}" });
}

export async function getDamAssetStreamUrl(damItemId: string, type: "SOURCE"|"PROXY"|"OUTPUT") {
  return api<{ url: string }>(`/dam/items/${damItemId}/assets/${type}/stream-url`);
}

export async function getDamThumbnailUrl(damItemId: string) {
  return api<{ url: string | null; kind: "image" | "video" | null }>(`/dam/items/${damItemId}/thumbnail-url`);
}
