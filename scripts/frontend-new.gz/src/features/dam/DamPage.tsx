import { useEffect, useMemo, useRef, useState, type CSSProperties, type MouseEvent as ReactMouseEvent, type WheelEvent as ReactWheelEvent } from "react";
import { getCreativeCodeLabel, getMe, type MeResponse } from "../../lib/me";
import { HomeRefreshBar } from "../../ui/HomeRefreshBar";
import { getDamThumbnailUrl, listDam, type DamItem } from "./damApi";
import { DamPlayerModal } from "./DamPlayerModal";

type ThumbResult = { url: string | null; kind: "image" | "video" | null };

const QC_STATUS_OPTIONS = ["", "NOT_STARTED", "IN_PROGRESS", "PASSED", "FAILED"];

function niceQcLabel(v?: string | null) {
  const raw = String(v || "").trim();
  if (!raw) return "Unknown";
  return raw
    .toLowerCase()
    .split(/[_\s]+/)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");
}

function formatWhen(v?: string | null) {
  if (!v) return "—";
  const dt = new Date(v);
  if (Number.isNaN(dt.getTime())) return String(v);
  return dt.toLocaleString();
}

function firstNonEmpty(values: Array<string | null | undefined>) {
  for (const value of values) {
    const s = String(value || "").trim();
    if (s) return s;
  }
  return "Untitled asset";
}

function activeCircleZ(index: number, active: boolean) {
  if (active) return 2000;
  return 1000 + index;
}

function quickChipStyle(active: boolean): CSSProperties {
  return {
    border: active ? "1px solid #86efac" : "1px solid #d7deea",
    background: active ? "linear-gradient(180deg, #f0fdf4 0%, #dcfce7 100%)" : "#fff",
    color: active ? "#166534" : "#334155",
    boxShadow: active ? "0 8px 18px rgba(34,197,94,0.12)" : "none",
    borderRadius: 999,
    padding: "7px 12px",
    fontSize: 12,
    fontWeight: 700,
    cursor: "pointer",
    transition: "all 160ms ease",
    whiteSpace: "nowrap",
  };
}

function fieldShellStyle(): CSSProperties {
  return {
    display: "flex",
    flexDirection: "column",
    justifyContent: "center",
    gap: 8,
    padding: 12,
    borderRadius: 18,
    border: "1px solid rgba(214, 223, 234, 0.95)",
    background: "linear-gradient(180deg, rgba(255,255,255,0.96) 0%, rgba(248,250,252,0.92) 100%)",
    boxShadow: "0 8px 20px rgba(15,23,42,0.04)",
    minWidth: 0,
  };
}

function inputStyle(): CSSProperties {
  return {
    width: "100%",
    maxWidth: "100%",
    minWidth: 0,
    boxSizing: "border-box",
    border: "1px solid #d7deea",
    background: "rgba(255,255,255,0.92)",
    borderRadius: 12,
    minHeight: 42,
    padding: "0 14px",
    fontSize: 14,
    outline: "none",
    boxShadow: "inset 0 1px 0 rgba(255,255,255,0.9)",
  };
}

function glassPillStyle(): CSSProperties {
  return {
    border: "1px solid rgba(255,255,255,0.72)",
    background: "linear-gradient(180deg, rgba(255,255,255,0.38) 0%, rgba(255,255,255,0.18) 100%)",
    color: "#1e293b",
    boxShadow: "0 10px 22px rgba(15,23,42,0.08), inset 0 1px 0 rgba(255,255,255,0.55)",
    backdropFilter: "blur(10px)",
    WebkitBackdropFilter: "blur(10px)",
  };
}

function ThumbnailCircle({
  item,
  index,
  active,
  onActivate,
  onOpen,
  buttonRef,
}: {
  item: DamItem;
  index: number;
  active: boolean;
  onActivate: (item: DamItem) => void;
  onOpen: (item: DamItem) => void;
  buttonRef?: (node: HTMLButtonElement | null) => void;
}) {
  const [thumb, setThumb] = useState<ThumbResult>({ url: null, kind: null });

  useEffect(() => {
    let alive = true;
    setThumb({ url: null, kind: null });

    getDamThumbnailUrl(item.id)
      .then((res) => {
        if (alive) setThumb(res);
      })
      .catch(() => {
        if (alive) setThumb({ url: null, kind: null });
      });

    return () => {
      alive = false;
    };
  }, [item.id]);

  const title = firstNonEmpty([item.valid, item.caption, item.format, item.id]);

  return (
    <button
      ref={buttonRef}
      type="button"
      onClick={() => onOpen(item)}
      onMouseEnter={() => onActivate(item)}
      title={title}
      aria-label={`Open ${title}`}
      style={{
        width: 172,
        height: 172,
        minWidth: 172,
        marginLeft: index === 0 ? 0 : -34,
        borderRadius: "50%",
        overflow: "hidden",
        position: "relative",
        border: active ? "4px solid rgba(37,99,235,0.95)" : "4px solid #ffffff",
        boxShadow: active ? "0 26px 45px rgba(15,23,42,0.26)" : "0 12px 28px rgba(15,23,42,0.16)",
        padding: 0,
        background: "#0f172a",
        cursor: active ? "pointer" : "grab",
        transform: active ? "translateY(-14px) scale(1.2)" : "translateY(0) scale(1)",
        transition: "transform 180ms ease, box-shadow 180ms ease, border-color 180ms ease",
        zIndex: activeCircleZ(index, active),
      }}
    >
      {thumb.url && thumb.kind === "image" ? (
        <img src={thumb.url} alt={title} style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }} />
      ) : thumb.url && thumb.kind === "video" ? (
        <video
          src={thumb.url}
          muted
          playsInline
          preload="metadata"
          style={{ width: "100%", height: "100%", objectFit: "cover", display: "block" }}
        />
      ) : (
        <div
          style={{
            width: "100%",
            height: "100%",
            display: "grid",
            placeItems: "center",
            padding: 18,
            textAlign: "center",
            color: "#fff",
            background: "radial-gradient(circle at top, #334155, #0f172a 65%)",
            fontWeight: 800,
            fontSize: 12,
            lineHeight: 1.3,
          }}
        >
          {item.valid || item.caption || "Preview"}
        </div>
      )}

      <div
        style={{
          position: "absolute",
          inset: 0,
          background: "linear-gradient(180deg, rgba(15,23,42,0.08) 0%, rgba(15,23,42,0.06) 50%, rgba(15,23,42,0.42) 100%)",
        }}
      />

      <div
        aria-hidden="true"
        style={{
          position: "absolute",
          inset: "50% auto auto 50%",
          transform: "translate(-50%, -50%)",
          width: 52,
          height: 52,
          borderRadius: "50%",
          background: "rgba(255,255,255,0.72)",
          backdropFilter: "blur(6px)",
          display: "grid",
          placeItems: "center",
          boxShadow: "0 10px 30px rgba(15,23,42,0.22)",
        }}
      >
        <div
          style={{
            width: 0,
            height: 0,
            marginLeft: 3,
            borderTop: "11px solid transparent",
            borderBottom: "11px solid transparent",
            borderLeft: "18px solid rgba(15,23,42,0.78)",
          }}
        />
      </div>
    </button>
  );
}

export function DamPage() {
  const [q, setQ] = useState("");
  const [valid, setValid] = useState("");
  const [format, setFormat] = useState("");
  const [qcStatus, setQcStatus] = useState("");
  const [language, setLanguage] = useState("");

  const appliedFilterCount = [q, valid, format, qcStatus, language].filter((v) => String(v || "").trim()).length;
  const defaultTake = 30;

  const [rows, setRows] = useState<DamItem[]>([]);
  const [total, setTotal] = useState(0);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");
  const [selected, setSelected] = useState<DamItem | null>(null);
  const [activeId, setActiveId] = useState<string>("");
  const [me, setMe] = useState<MeResponse | null>(null);
  const stripRef = useRef<HTMLDivElement | null>(null);
  const thumbRefs = useRef<Record<string, HTMLButtonElement | null>>({});
  const autoScrollRafRef = useRef<number | null>(null);
  const autoScrollVelocityRef = useRef(0);
  const dragStateRef = useRef<{ active: boolean; startX: number; startScrollLeft: number }>({ active: false, startX: 0, startScrollLeft: 0 });

  const languageOptions = useMemo(() => {
    const values = Array.from(new Set(rows.flatMap((row) => (Array.isArray(row.languages) ? row.languages : [])).filter(Boolean)));
    return values.sort((a, b) => a.localeCompare(b));
  }, [rows]);

  const formatOptions = useMemo(() => {
    const values = Array.from(new Set(rows.map((row) => String(row.format || "").trim()).filter(Boolean)));
    return values.sort((a, b) => a.localeCompare(b));
  }, [rows]);

  const quickLanguages = useMemo(() => languageOptions.slice(0, 8), [languageOptions]);

  async function load(overrides?: Partial<{ q: string; valid: string; format: string; qcStatus: string; language: string }>) {
    const nextQ = overrides?.q ?? q;
    const nextValid = overrides?.valid ?? valid;
    const nextFormat = overrides?.format ?? format;
    const nextQcStatus = overrides?.qcStatus ?? qcStatus;
    const nextLanguage = overrides?.language ?? language;
    const nextAppliedFilterCount = [nextQ, nextValid, nextFormat, nextQcStatus, nextLanguage].filter((v) => String(v || "").trim()).length;

    setLoading(true);
    setErr("");
    try {
      const r = await listDam({
        q: nextQ.trim() || undefined,
        valid: nextValid.trim() || undefined,
        format: nextFormat.trim() || undefined,
        qcStatus: nextQcStatus || undefined,
        language: nextLanguage || undefined,
        take: nextAppliedFilterCount ? 60 : defaultTake,
        skip: 0,
      });
      setRows(Array.isArray(r.rows) ? r.rows : []);
      setTotal(Number(r.total || 0));
    } catch (e: any) {
      setErr(e?.message || String(e));
      setRows([]);
      setTotal(0);
    } finally {
      setLoading(false);
    }
  }

  function applyAndLoad(next: { q: string; valid: string; format: string; qcStatus: string; language: string }) {
    setQ(next.q);
    setValid(next.valid);
    setFormat(next.format);
    setQcStatus(next.qcStatus);
    setLanguage(next.language);
    void load(next);
  }

  function clearFilters() {
    applyAndLoad({ q: "", valid: "", format: "", qcStatus: "", language: "" });
  }

  function removeFilter(key: "q" | "valid" | "format" | "qcStatus" | "language") {
    applyAndLoad({
      q: key === "q" ? "" : q,
      valid: key === "valid" ? "" : valid,
      format: key === "format" ? "" : format,
      qcStatus: key === "qcStatus" ? "" : qcStatus,
      language: key === "language" ? "" : language,
    });
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    getMe().then(setMe).catch(() => setMe(null));
  }, []);

  useEffect(() => {
    if (!rows.length) {
      setActiveId("");
      return;
    }
    const exists = rows.some((row) => row.id === activeId);
    if (!exists) setActiveId(rows[0].id);
  }, [rows, activeId]);

  const activeItem = useMemo(() => rows.find((row) => row.id === activeId) || rows[0] || null, [rows, activeId]);

  useEffect(() => {
    const node = activeId ? thumbRefs.current[activeId] : null;
    node?.scrollIntoView({ behavior: "smooth", block: "nearest", inline: "center" });
  }, [activeId]);

  useEffect(() => {
    return () => {
      if (autoScrollRafRef.current != null) {
        cancelAnimationFrame(autoScrollRafRef.current);
      }
    };
  }, []);

  function stopAutoScroll() {
    autoScrollVelocityRef.current = 0;
    if (autoScrollRafRef.current != null) {
      cancelAnimationFrame(autoScrollRafRef.current);
      autoScrollRafRef.current = null;
    }
  }

  function ensureAutoScroll() {
    if (autoScrollRafRef.current != null) return;
    const step = () => {
      const host = stripRef.current;
      const velocity = autoScrollVelocityRef.current;
      if (!host || Math.abs(velocity) < 0.25) {
        autoScrollRafRef.current = null;
        return;
      }
      host.scrollLeft += velocity;
      autoScrollRafRef.current = requestAnimationFrame(step);
    };
    autoScrollRafRef.current = requestAnimationFrame(step);
  }

  function handleStripMouseMove(e: ReactMouseEvent<HTMLDivElement>) {
    const host = stripRef.current;
    if (!host) return;
    if (dragStateRef.current.active) {
      const delta = e.clientX - dragStateRef.current.startX;
      host.scrollLeft = dragStateRef.current.startScrollLeft - delta;
      return;
    }

    const rect = host.getBoundingClientRect();
    const threshold = Math.min(140, rect.width * 0.24);
    const x = e.clientX - rect.left;
    let velocity = 0;

    if (x < threshold) {
      const ratio = (threshold - x) / threshold;
      velocity = -Math.max(3, ratio * 18);
    } else if (x > rect.width - threshold) {
      const ratio = (x - (rect.width - threshold)) / threshold;
      velocity = Math.max(3, ratio * 18);
    }

    autoScrollVelocityRef.current = velocity;
    if (velocity) ensureAutoScroll();
    else stopAutoScroll();
  }

  function handleStripMouseDown(e: ReactMouseEvent<HTMLDivElement>) {
    const host = stripRef.current;
    if (!host) return;
    dragStateRef.current = { active: true, startX: e.clientX, startScrollLeft: host.scrollLeft };
    host.style.cursor = "grabbing";
    stopAutoScroll();
  }

  function handleStripMouseUp() {
    dragStateRef.current.active = false;
    if (stripRef.current) stripRef.current.style.cursor = "grab";
  }

  function handleStripWheel(e: ReactWheelEvent<HTMLDivElement>) {
    const host = stripRef.current;
    if (!host) return;
    const delta = Math.abs(e.deltaX) > Math.abs(e.deltaY) ? e.deltaX : e.deltaY;
    if (!delta) return;
    e.preventDefault();
    host.scrollLeft += delta;
  }

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <style>{`
        .dam-thumb-strip::-webkit-scrollbar{display:none;}
        .dam-filter-grid{display:grid;grid-template-columns:minmax(0,4fr) minmax(180px,1.4fr) minmax(220px,2fr) auto;gap:10px 12px;align-items:start;}
        .dam-filter-search{grid-column:1;}
        .dam-filter-valid{grid-column:2;}
        .dam-filter-format{grid-column:3;}
        .dam-filter-actions{grid-column:4;display:flex;align-items:stretch;justify-content:flex-end;}
        .dam-filter-qc{grid-column:1 / span 2;}
        .dam-filter-language{grid-column:3 / span 2;}
        @media (max-width: 1280px){
          .dam-filter-grid{grid-template-columns:repeat(6,minmax(0,1fr));}
          .dam-filter-search{grid-column:span 3;}
          .dam-filter-valid{grid-column:span 1;}
          .dam-filter-format{grid-column:span 2;}
          .dam-filter-actions{grid-column:span 6;justify-content:stretch;}
          .dam-filter-qc{grid-column:span 3;}
          .dam-filter-language{grid-column:span 3;}
        }
        @media (max-width: 900px){
          .dam-filter-grid{grid-template-columns:1fr;}
          .dam-filter-search,.dam-filter-valid,.dam-filter-format,.dam-filter-actions,.dam-filter-qc,.dam-filter-language{grid-column:auto;grid-row:auto;}
        }
      `}</style>
      <HomeRefreshBar title="DAM" onRefresh={load} flat />

      <div className="card" style={{ display: "grid", gap: 14, background: "linear-gradient(180deg, #ffffff 0%, #f8fafc 100%)" }}>
        <div style={{ display: "flex", gap: 12, justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap" }}>
          <div>
            <h3 style={{ margin: 0 }}>DAM</h3>
          </div>
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 10,
              flexWrap: "wrap",
              justifyContent: "flex-end",
            }}
          >
            <span
              style={{
                borderRadius: 999,
                padding: "7px 12px",
                background: appliedFilterCount ? "#ecfdf3" : "#f1f5f9",
                border: appliedFilterCount ? "1px solid #bbf7d0" : "1px solid #dbe3ec",
                color: appliedFilterCount ? "#166534" : "#475569",
                fontSize: 12,
                fontWeight: 800,
              }}
            >
              {appliedFilterCount ? `${appliedFilterCount} filter${appliedFilterCount > 1 ? "s" : ""} active` : "Default latest view"}
            </span>
            <span style={{ fontSize: 12, opacity: 0.68 }}>Results: {total}</span>
          </div>
        </div>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            void load();
          }}
          style={{ display: "grid", gap: 10 }}
        >
          <div
            style={{
              display: "grid",
              gap: 10,
              padding: 12,
              borderRadius: 20,
              border: "1px solid #dde5ef",
              background: "linear-gradient(180deg, #f8fafc 0%, #f1f5f9 100%)",
            }}
          >
            <div className="dam-filter-grid">
              <div className="dam-filter-search" style={fieldShellStyle()}>
                <div style={{ display: "flex", justifyContent: "space-between", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
                  <label style={{ fontSize: 12, fontWeight: 800, color: "#334155" }}>Search videos</label>
                  <span style={{ fontSize: 11, opacity: 0.65 }}>caption, format, language, remarks</span>
                </div>
                <div style={{ position: "relative" }}>
                  <span style={{ position: "absolute", left: 14, top: "50%", transform: "translateY(-50%)", fontSize: 15, opacity: 0.55 }}>⌕</span>
                  <input
                    value={q}
                    onChange={(e) => setQ(e.target.value)}
                    placeholder="Search videos..."
                    style={{ ...inputStyle(), paddingLeft: 38, minHeight: 40 }}
                  />
                </div>
              </div>

              <div className="dam-filter-valid" style={fieldShellStyle()}>
                <label style={{ fontSize: 12, fontWeight: 800, color: "#334155" }}>{getCreativeCodeLabel(me)}</label>
                <input
                  value={valid}
                  onChange={(e) => setValid(e.target.value)}
                  placeholder={`Enter ${getCreativeCodeLabel(me).toLowerCase()}`}
                  style={{ ...inputStyle(), minHeight: 40 }}
                />
              </div>

              <div className="dam-filter-format" style={fieldShellStyle()}>
                <label style={{ fontSize: 12, fontWeight: 800, color: "#334155" }}>Format</label>
                <input
                  value={format}
                  onChange={(e) => setFormat(e.target.value)}
                  placeholder="Search by format"
                  list="dam-format-suggestions"
                  style={{ ...inputStyle(), minHeight: 40 }}
                />
                {formatOptions.length ? (
                  <datalist id="dam-format-suggestions">
                    {formatOptions.map((option) => (
                      <option key={option} value={option} />
                    ))}
                  </datalist>
                ) : null}
              </div>

              <div className="dam-filter-actions" style={{ minWidth: 0 }}>
                <div
                  style={{
                    display: "flex",
                    gap: 10,
                    alignItems: "stretch",
                    justifyContent: "flex-end",
                    flexWrap: "wrap",
                    width: "100%",
                  }}
                >
                  <button
                    type="submit"
                    disabled={loading}
                    style={{
                      minHeight: 40,
                      padding: "0 18px",
                      borderRadius: 12,
                      border: "1px solid #86efac",
                      background: "linear-gradient(180deg, #dcfce7 0%, #bbf7d0 100%)",
                      color: "#166534",
                      fontWeight: 800,
                      boxShadow: "0 10px 20px rgba(34,197,94,0.12)",
                      whiteSpace: "nowrap",
                    }}
                  >
                    {loading ? "Loading..." : appliedFilterCount ? `Apply filter${appliedFilterCount > 1 ? "s" : ""}` : "Show latest videos"}
                  </button>
                  <button
                    type="button"
                    onClick={clearFilters}
                    disabled={loading && !appliedFilterCount}
                    style={{
                      minHeight: 40,
                      padding: "0 18px",
                      borderRadius: 12,
                      border: "1px solid #d7deea",
                      background: "rgba(255,255,255,0.92)",
                      color: "#334155",
                      fontWeight: 700,
                      whiteSpace: "nowrap",
                    }}
                  >
                    Clear filters
                  </button>
                </div>
              </div>

              <div className="dam-filter-qc" style={fieldShellStyle()}>
                <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
                  <label style={{ fontSize: 12, fontWeight: 800, color: "#334155" }}>QC status</label>
                  <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                    {QC_STATUS_OPTIONS.map((status) => {
                      const selectedStatus = qcStatus === status;
                      return (
                        <button key={status || "all"} type="button" onClick={() => setQcStatus(status)} style={quickChipStyle(selectedStatus)}>
                          {status ? niceQcLabel(status) : "All statuses"}
                        </button>
                      );
                    })}
                  </div>
                </div>
              </div>

              <div className="dam-filter-language" style={fieldShellStyle()}>
                <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
                  <label style={{ fontSize: 12, fontWeight: 800, color: "#334155" }}>Language</label>
                  {quickLanguages.length ? (
                    <>
                      <button type="button" onClick={() => setLanguage("")} style={quickChipStyle(language === "")}>All languages</button>
                      {quickLanguages.map((lang) => (
                        <button key={lang} type="button" onClick={() => setLanguage(lang)} style={quickChipStyle(language === lang)}>
                          {lang}
                        </button>
                      ))}
                    </>
                  ) : (
                    <span style={{ fontSize: 12, opacity: 0.6 }}>Languages will appear from loaded items.</span>
                  )}
                </div>
                {languageOptions.length > quickLanguages.length ? (
                  <select value={language} onChange={(e) => setLanguage(e.target.value)} style={{ ...inputStyle(), minHeight: 40 }}>
                    <option value="">More languages…</option>
                    {languageOptions.map((lang) => (
                      <option key={lang} value={lang}>
                        {lang}
                      </option>
                    ))}
                  </select>
                ) : null}
              </div>
            </div>

            <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap", fontSize: 12 }}>
              <span style={{ opacity: 0.7, fontWeight: 700 }}>Applied filters:</span>
              {appliedFilterCount ? (
                <>
                  {q ? (
                    <button type="button" className="pill" onClick={() => removeFilter("q")} style={{ cursor: "pointer" }}>
                      Search: {q} ×
                    </button>
                  ) : null}
                  {valid ? (
                    <button type="button" className="pill" onClick={() => removeFilter("valid")} style={{ cursor: "pointer" }}>
                      {getCreativeCodeLabel(me)}: {valid} ×
                    </button>
                  ) : null}
                  {format ? (
                    <button type="button" className="pill" onClick={() => removeFilter("format")} style={{ cursor: "pointer" }}>
                      Format: {format} ×
                    </button>
                  ) : null}
                  {qcStatus ? (
                    <button type="button" className="pill" onClick={() => removeFilter("qcStatus")} style={{ cursor: "pointer" }}>
                      QC: {niceQcLabel(qcStatus)} ×
                    </button>
                  ) : null}
                  {language ? (
                    <button type="button" className="pill" onClick={() => removeFilter("language")} style={{ cursor: "pointer" }}>
                      Language: {language} ×
                    </button>
                  ) : null}
                </>
              ) : (
                <span style={{ opacity: 0.6 }}>None</span>
              )}
            </div>
          </div>
        </form>
      </div>

      {err ? <div className="card" style={{ border: "1px solid #ffb3b3", color: "#a10000" }}>{err}</div> : null}

      <div
        style={{
          display: "grid",
          gap: 18,
          overflow: "hidden",
          visibility: selected ? "hidden" : "visible",
          background: "transparent",
          border: "none",
          boxShadow: "none",
          padding: 0,
        }}
      >
        {!appliedFilterCount ? (
          <div style={{ display: "flex", justifyContent: "flex-end", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
            <div style={{ fontSize: 12, opacity: 0.68 }}>Showing latest {Math.min(total || 0, defaultTake)} of {total} items</div>
          </div>
        ) : null}

        {!rows.length && !loading ? (
          <div style={{ padding: 32, textAlign: "center", opacity: 0.7 }}>No DAM items matched the current filters.</div>
        ) : (
          <div
            ref={stripRef}
            className="dam-thumb-strip"
            onMouseMove={handleStripMouseMove}
            onMouseLeave={() => {
              dragStateRef.current.active = false;
              if (stripRef.current) stripRef.current.style.cursor = "grab";
              stopAutoScroll();
            }}
            onMouseDown={handleStripMouseDown}
            onMouseUp={handleStripMouseUp}
            onWheel={handleStripWheel}
            style={{
              overflowX: "auto",
              overflowY: "hidden",
              paddingBottom: 10,
              scrollbarWidth: "none",
              msOverflowStyle: "none",
              cursor: "grab",
              userSelect: "none",
            }}
          >
            <div style={{ display: "flex", alignItems: "center", padding: "26px 150px 30px 8px", minHeight: 236 }}>
              {rows.map((item, index) => (
                <ThumbnailCircle
                  key={item.id}
                  item={item}
                  index={index}
                  active={item.id === activeItem?.id}
                  onActivate={(next) => setActiveId(next.id)}
                  onOpen={(next) => {
                    setActiveId(next.id);
                    setSelected(next);
                  }}
                  buttonRef={(node) => {
                    thumbRefs.current[item.id] = node;
                  }}
                />
              ))}
            </div>
          </div>
        )}

        {activeItem ? (
          <div
            className="card"
            style={{
              marginTop: -2,
              border: "1px solid rgba(255,255,255,0.72)",
              background: "linear-gradient(135deg, rgba(255,255,255,0.48) 0%, rgba(241,245,249,0.3) 100%)",
              boxShadow: "0 20px 36px rgba(15,23,42,0.08), inset 0 1px 0 rgba(255,255,255,0.72)",
              backdropFilter: "blur(12px)",
              WebkitBackdropFilter: "blur(12px)",
              display: "grid",
              gridTemplateColumns: "1fr auto",
              gap: 16,
              alignItems: "center",
            }}
          >
            <div style={{ display: "grid", gap: 10 }}>
              <div>
                <div style={{ fontSize: 19, fontWeight: 900, color: "#0f172a" }}>{firstNonEmpty([activeItem.valid, activeItem.caption, activeItem.id])}</div>
                <div style={{ fontSize: 13, color: "rgba(51,65,85,0.82)", marginTop: 4 }}>{activeItem.caption || "No caption available"}</div>
              </div>

              <div style={{ display: "flex", gap: 10, flexWrap: "wrap", fontSize: 12 }}>
                <span className="pill" style={glassPillStyle()}>QC: {niceQcLabel(activeItem.qcStatus)}</span>
                {activeItem.format ? <span className="pill" style={glassPillStyle()}>Format: {activeItem.format}</span> : null}
                {activeItem.languages?.length ? <span className="pill" style={glassPillStyle()}>Languages: {activeItem.languages.join(", ")}</span> : null}
                <span className="pill" style={glassPillStyle()}>Updated: {formatWhen(activeItem.updatedAt)}</span>
              </div>
            </div>

            <div style={{ display: "flex", gap: 8, flexWrap: "wrap", justifyContent: "flex-end" }}>
              <button
                type="button"
                onClick={() => setSelected(activeItem)}
                style={{
                  minHeight: 44,
                  borderRadius: 14,
                  padding: "0 16px",
                  border: "1px solid rgba(255,255,255,0.72)",
                  background: "linear-gradient(180deg, rgba(255,255,255,0.72) 0%, rgba(255,255,255,0.42) 100%)",
                  boxShadow: "0 14px 30px rgba(15,23,42,0.08)",
                  color: "#0f172a",
                  fontWeight: 800,
                  backdropFilter: "blur(8px)",
                  WebkitBackdropFilter: "blur(8px)",
                }}
              >
                Open preview
              </button>
            </div>
          </div>
        ) : null}
      </div>

      {selected ? <DamPlayerModal item={selected} onClose={() => setSelected(null)} /> : null}
    </div>
  );
}
