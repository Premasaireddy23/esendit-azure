import { useEffect, useMemo, useState } from "react";
import type { DamItem } from "./damApi";
import { getDamAssetStreamUrl } from "./damApi";
import { PresetDownloadModal } from "../presets/PresetDownloadModal";

type AssetType = "SOURCE" | "PROXY" | "OUTPUT";


function niceQcLabel(v?: string | null) {
  const raw = String(v || "").trim();
  if (!raw) return "Unknown";
  return raw
    .toLowerCase()
    .split(/[_\s]+/)
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(" ");
}

function formatWhen(v?: string | null) {
  if (!v) return "—";
  const dt = new Date(v);
  if (Number.isNaN(dt.getTime())) return String(v);
  return dt.toLocaleString();
}

function numOrNull(value: any) {
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}

function parseFrameRate(value: any) {
  if (typeof value === "number" && Number.isFinite(value)) return value;
  const raw = String(value || "").trim();
  if (!raw) return null;
  if (raw.includes("/")) {
    const [a, b] = raw.split("/").map((part) => Number(part));
    if (Number.isFinite(a) && Number.isFinite(b) && b !== 0) return a / b;
    return null;
  }
  return numOrNull(raw);
}

function fmtRounded(value: number, digits = 1) {
  return value.toFixed(digits).replace(/\.0+$/, "").replace(/(\.\d*[1-9])0+$/, "$1");
}

function fmtBytes(n?: number | null) {
  if (n == null || !Number.isFinite(n)) return "";
  const u = ["B", "KB", "MB", "GB", "TB"];
  let i = 0;
  let x = n;
  while (x >= 1024 && i < u.length - 1) {
    x /= 1024;
    i += 1;
  }
  return `${x.toFixed(x >= 10 || i === 0 ? 0 : 1)} ${u[i]}`;
}

function fmtFriendlyDuration(sec?: number | null) {
  if (sec == null || !Number.isFinite(sec)) return "";
  const whole = Math.max(0, Math.round(sec));
  const hrs = Math.floor(whole / 3600);
  const mins = Math.floor((whole % 3600) / 60);
  const secs = whole % 60;
  if (hrs > 0) return `${hrs} hr ${mins} min ${secs} sec`;
  if (mins > 0 && secs > 0) return `${mins} min ${secs} sec`;
  if (mins > 0) return `${mins} min`;
  return `${secs} sec`;
}

function resolutionLabel(width?: number | null, height?: number | null) {
  if (!width || !height) return "";
  const w = Number(width);
  const h = Number(height);
  if (w >= 3840 || h >= 2160) return "4K";
  if (w >= 1920 || h >= 1080) return "Full HD";
  if (w >= 1280 || h >= 720) return "HD";
  if (w >= 720 || h >= 576) return "SD";
  return "Custom size";
}

function friendlyFrameRateLabel(frameRate?: any) {
  const fps = parseFrameRate(frameRate);
  if (fps == null || fps <= 0) return "";
  if (Math.abs(fps - 25) < 0.2) return "25 fps";
  if (Math.abs(fps - 24) < 0.2) return "24 fps";
  if (Math.abs(fps - 30) < 0.2 || Math.abs(fps - 29.97) < 0.05) return "30 fps";
  if (Math.abs(fps - 50) < 0.2 || Math.abs(fps - 60) < 0.2 || Math.abs(fps - 59.94) < 0.05) return `${fmtRounded(fps, 2)} fps`;
  return `${fmtRounded(fps, 2)} fps`;
}

function friendlyChannelLabel(channels?: any) {
  const n = numOrNull(channels);
  if (n == null || n <= 0) return "";
  if (n === 1) return "Mono";
  if (n === 2) return "Stereo";
  if (n === 6) return "5.1 surround";
  if (n === 8) return "7.1 surround";
  return `${n} channels`;
}

function friendlyScanType(scanType?: string | null, fieldOrder?: string | null) {
  const raw = String(scanType || fieldOrder || "").toLowerCase();
  if (!raw) return "";
  if (raw.includes("progressive")) return "Progressive";
  if (raw.includes("interlaced")) return "Interlaced";
  if (raw === "tt" || raw === "bb" || raw === "tb" || raw === "bt") return "Interlaced";
  return String(scanType || fieldOrder || "");
}

function firstVideoStream(ffprobe: any) {
  const streams = Array.isArray(ffprobe?.streams) ? ffprobe.streams : [];
  return streams.find((stream: any) => stream?.codec_type === "video") || null;
}

function firstAudioStream(ffprobe: any) {
  const streams = Array.isArray(ffprobe?.streams) ? ffprobe.streams : [];
  return streams.find((stream: any) => stream?.codec_type === "audio") || null;
}

function pickAsset(item: DamItem, type: AssetType | null) {
  const assets = Array.isArray(item.assets) ? item.assets : [];
  if (type) {
    const exact = assets.find((asset) => String(asset?.type || "").toUpperCase() === type);
    if (exact) return exact;
  }
  return (
    assets.find((asset) => String(asset?.type || "").toUpperCase() === "PROXY") ||
    assets.find((asset) => String(asset?.type || "").toUpperCase() === "SOURCE") ||
    assets[0] ||
    null
  );
}

function mediaInfoTracks(mediaInfo: any, type?: string) {
  const tracks = Array.isArray(mediaInfo?.media?.track) ? mediaInfo.media.track : [];
  if (!type) return tracks;
  const want = String(type || "").toLowerCase();
  return tracks.filter((track: any) => String(track?.["@type"] || track?.["@Type"] || track?.type || "").toLowerCase() === want);
}

function mediaInfoTrack(mediaInfo: any, type: string, index = 0) {
  return mediaInfoTracks(mediaInfo, type)[index] || null;
}

function mediaInfoValue(track: any, ...keys: string[]) {
  for (const key of keys) {
    const value = track?.[key];
    if (value === 0 || value === "0") return String(value);
    if (value !== null && value !== undefined) {
      const str = String(value).trim();
      if (str) return str;
    }
  }
  return "";
}



function InfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "minmax(120px, 150px) minmax(0, 1fr)",
        gap: 10,
        padding: "10px 0",
        borderBottom: "1px solid #eef2f7",
        alignItems: "start",
      }}
    >
      <div style={{ fontSize: 12, fontWeight: 800, color: "#64748b", textTransform: "uppercase", letterSpacing: 0.3 }}>{label}</div>
      <div style={{ fontSize: 14, color: "#0f172a", wordBreak: "break-word" }}>{value || "—"}</div>
    </div>
  );
}

function InfoSection({ title, subtitle, rows }: { title: string; subtitle?: string; rows: Array<[string, string]> }) {
  const cleanRows = rows.filter(([, value]) => String(value || "").trim());
  if (!cleanRows.length) return null;

  return (
    <div
      style={{
        border: "1px solid #e2e8f0",
        borderRadius: 18,
        background: "linear-gradient(180deg, #ffffff 0%, #f8fafc 100%)",
        padding: 16,
        boxShadow: "0 14px 30px rgba(15,23,42,0.05)",
      }}
    >
      <div style={{ marginBottom: 10 }}>
        <div style={{ fontWeight: 900, fontSize: 16, color: "#0f172a" }}>{title}</div>
        {subtitle ? <div style={{ fontSize: 12, color: "#64748b", marginTop: 3 }}>{subtitle}</div> : null}
      </div>
      <div>
        {cleanRows.map(([label, value]) => (
          <InfoRow key={label} label={label} value={value} />
        ))}
      </div>
    </div>
  );
}

function StatCard({ label, value, tone = "default" }: { label: string; value: string; tone?: "default" | "success" | "accent" }) {
  const palette =
    tone === "success"
      ? {
          border: "1px solid #bbf7d0",
          background: "linear-gradient(180deg, #f0fdf4 0%, #dcfce7 100%)",
          value: "#166534",
        }
      : tone === "accent"
        ? {
            border: "1px solid #bfdbfe",
            background: "linear-gradient(180deg, #eff6ff 0%, #dbeafe 100%)",
            value: "#1d4ed8",
          }
        : {
            border: "1px solid #e2e8f0",
            background: "linear-gradient(180deg, #ffffff 0%, #f8fafc 100%)",
            value: "#0f172a",
          };

  return (
    <div
      style={{
        border: palette.border,
        background: palette.background,
        borderRadius: 16,
        padding: "12px 14px",
        minHeight: 82,
        display: "grid",
        alignContent: "space-between",
        gap: 6,
        boxShadow: "0 12px 24px rgba(15,23,42,0.05)",
      }}
    >
      <div style={{ fontSize: 12, fontWeight: 800, color: "#64748b", textTransform: "uppercase", letterSpacing: 0.28 }}>{label}</div>
      <div style={{ fontSize: 15, fontWeight: 900, color: palette.value, lineHeight: 1.25 }}>{value || "—"}</div>
    </div>
  );
}

export function DamPlayerModal({ item, onClose }: { item: DamItem; onClose: () => void }) {
  const [showSafe, setShowSafe] = useState(true);
  const [presetOpen, setPresetOpen] = useState(false);
  const [videoUrl, setVideoUrl] = useState<string>("");
  const [videoError, setVideoError] = useState<string>("");
  const [loading, setLoading] = useState(true);
  const [streamType, setStreamType] = useState<AssetType | null>(null);

  useEffect(() => {
    let alive = true;

    (async () => {
      setLoading(true);
      setVideoError("");
      setVideoUrl("");
      setStreamType(null);
      try {
        try {
          const r = await getDamAssetStreamUrl(item.id, "PROXY");
          if (alive) {
            setVideoUrl(r.url);
            setStreamType("PROXY");
          }
        } catch {
          const r = await getDamAssetStreamUrl(item.id, "SOURCE");
          if (alive) {
            setVideoUrl(r.url);
            setStreamType("SOURCE");
          }
        }
      } catch (e: any) {
        if (alive) setVideoError(e?.message || "Preview could not be loaded.");
      } finally {
        if (alive) setLoading(false);
      }
    })();

    return () => {
      alive = false;
    };
  }, [item.id]);

  useEffect(() => {
    const previous = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = previous;
    };
  }, []);

  const media = useMemo(() => {
    const report = item.qcReport || {};
    const primaryProbe = report?.primaryProbe || report?.qcli?.probe || report?.ffprobe || {};
    const metadata = report?.metadata || {};
    const clientMetadata = report?.clientMetadata || {};
    const mediaInfo = report?.qcTools?.mediainfo || report?.mediainfo || null;
    const miGeneral = mediaInfoTrack(mediaInfo, "General");
    const miVideo = mediaInfoTrack(mediaInfo, "Video");
    const miAudioTracks = mediaInfoTracks(mediaInfo, "Audio");
    const miAudio = miAudioTracks[0] || null;
    const format = metadata?.format || primaryProbe?.format || {};
    const video = (Array.isArray(metadata?.videoStreams) && metadata.videoStreams[0]) || firstVideoStream(primaryProbe);
    const audio = (Array.isArray(metadata?.audioStreams) && metadata.audioStreams[0]) || firstAudioStream(primaryProbe);
    const asset = pickAsset(item, streamType);
    const fileSize = numOrNull(asset?.sizeBytes) ?? numOrNull(mediaInfoValue(miGeneral, "FileSize")) ?? numOrNull(format?.sizeBytes ?? format?.size);
    const durationSeconds = numOrNull(mediaInfoValue(miGeneral, "Duration")) ?? numOrNull(format?.durationSeconds ?? format?.duration) ?? numOrNull(video?.durationSeconds ?? video?.duration) ?? numOrNull(audio?.durationSeconds ?? audio?.duration);
    const frameRate = parseFrameRate(clientMetadata?.video?.FrameRate ?? mediaInfoValue(miVideo, "FrameRate") ?? video?.frameRate ?? (video?.avg_frame_rate && video?.avg_frame_rate !== "0/0" ? video?.avg_frame_rate : video?.r_frame_rate));
    const clientWidth = Number(clientMetadata?.video?.Width || mediaInfoValue(miVideo, "Width") || 0) || null;
    const clientHeight = Number(clientMetadata?.video?.Height || mediaInfoValue(miVideo, "Height") || 0) || null;
    const resolution = clientWidth && clientHeight
      ? `${clientWidth} × ${clientHeight}${resolutionLabel(clientWidth, clientHeight) ? ` (${resolutionLabel(clientWidth, clientHeight)})` : ""}`
      : video?.width && video?.height
        ? `${video.width} × ${video.height}${resolutionLabel(video.width, video.height) ? ` (${resolutionLabel(video.width, video.height)})` : ""}`
        : "";
    const audioLabel = [friendlyChannelLabel(mediaInfoValue(miAudio, "Channels") || audio?.channels), mediaInfoValue(miAudio, "Format") || audio?.codecLongName || audio?.codec_long_name || audio?.codec_name || audio?.codec].filter(Boolean).join(" • ");
    const languageLabel = Array.isArray(item.languages) && item.languages.length
      ? item.languages.join(", ")
      : String(mediaInfoValue(miAudio, "Language", "Language_String3") || audio?.language || audio?.tags?.language || "").trim().toUpperCase();
    const containerLabel = [mediaInfoValue(miGeneral, "Format_Commercial_IfAny", "Format"), format?.containerLongName || format?.format_long_name || format?.format_name || format?.container, asset?.mimeType || format?.mimeType].filter(Boolean).join(" • ");
    const scanType = friendlyScanType(clientMetadata?.video?.ScanType || mediaInfoValue(miVideo, "ScanType", "ScanType_String") || video?.scanType || video?.scan_type, video?.field_order);
    const bitrate = numOrNull(clientMetadata?.general?.BitRate) ?? numOrNull(mediaInfoValue(miGeneral, "OverallBitRate", "BitRate")) ?? numOrNull(format?.bitRate ?? format?.bit_rate) ?? numOrNull(video?.bitRate ?? video?.bit_rate) ?? numOrNull(audio?.bitRate ?? audio?.bit_rate);

    return {
      report,
      primaryProbe,
      metadata,
      clientMetadata,
      mediaInfo,
      miGeneral,
      miVideo,
      miAudioTracks,
      miAudio,
      format,
      video,
      audio,
      asset,
      fileSize,
      durationSeconds,
      frameRate,
      resolution,
      audioLabel,
      languageLabel,
      containerLabel,
      scanType,
      bitrate,
    };
  }, [item, streamType]);

  const summaryCards: Array<{ label: string; value: string; tone?: "default" | "success" | "accent" }> = [
    { label: "Preview source", value: streamType === "PROXY" ? "Proxy video" : streamType === "SOURCE" ? "Source video" : "Video preview", tone: "accent" },
    { label: "Resolution", value: media.resolution || "—" },
    { label: "Frame rate", value: friendlyFrameRateLabel(media.frameRate) || "—" },
    { label: "Duration", value: item.duration || fmtFriendlyDuration(media.durationSeconds) || "—" },
    { label: "Audio", value: media.audioLabel || "—" },
    { label: "File size", value: fmtBytes(media.fileSize) || "—" },
    { label: "QC status", value: niceQcLabel(item.qcStatus), tone: item.qcStatus === "PASSED" ? "success" : "default" },
  ];

  const mediaRows: Array<[string, string]> = [
    ["Filename", String(media.asset?.filename || "")],
    ["Container", media.containerLabel],
    ["Picture size", media.resolution],
    ["Frame rate", friendlyFrameRateLabel(media.frameRate)],
    ["Scan type", media.scanType],
    ["Video codec", String(media.video?.codecLongName || media.video?.codec_long_name || media.video?.codec_name || media.video?.codec || "")],
    ["Audio", media.audioLabel],
    ["Audio sample rate", (media.audio?.sampleRate || media.audio?.sample_rate) ? `${media.audio?.sampleRate || media.audio?.sample_rate} Hz` : ""],
    ["Language", media.languageLabel],
    ["Bitrate", media.bitrate != null && media.bitrate > 0 ? `${fmtRounded(media.bitrate / 1000)} kbps` : ""],
    ["Length", item.duration || fmtFriendlyDuration(media.durationSeconds)],
    ["File size", fmtBytes(media.fileSize)],
  ];

  const libraryRows: Array<[string, string]> = [
    ["Valid", String(item.valid || "")],
    ["Caption", String(item.caption || "")],
    ["Business format", String(item.format || "")],
    ["Languages", Array.isArray(item.languages) ? item.languages.join(", ") : ""],
    ["QC status", niceQcLabel(item.qcStatus)],
    ["Remarks", String(item.remarks || "")],
    ["Updated", formatWhen(item.updatedAt)],
    ["Created", formatWhen(item.createdAt)],
  ];

  const assetRows: Array<[string, string]> = [
    ["Asset type", String(media.asset?.type || streamType || "")],
    ["Upload status", String(media.asset?.uploadStatus || "")],
    ["MIME type", String(media.asset?.mimeType || "")],
    ["Probe tool", String(media.report?.probeTool || media.report?.qcTools?.primaryProbeTool || (media.report?.qcli?.probe ? "qcli" : "ffprobe") || "")],
    ["QC checked at", formatWhen(media.report?.checkedAt)],
  ];

  const mediaInfoGeneralRows: Array<[string, string]> = [
    ["Path", mediaInfoValue(media.miGeneral, "CompleteName")],
    ["Format", mediaInfoValue(media.miGeneral, "Format_Commercial_IfAny", "Format")],
    ["Format profile", mediaInfoValue(media.miGeneral, "Format_Profile")],
    ["Format settings", mediaInfoValue(media.miGeneral, "Format_Settings")],
    ["File size", fmtBytes(numOrNull(mediaInfoValue(media.miGeneral, "FileSize")) ?? media.fileSize)],
    ["Duration", fmtFriendlyDuration(numOrNull(mediaInfoValue(media.miGeneral, "Duration")) ?? media.durationSeconds)],
    ["Overall bitrate", numOrNull(mediaInfoValue(media.miGeneral, "OverallBitRate")) ? `${fmtRounded((numOrNull(mediaInfoValue(media.miGeneral, "OverallBitRate")) || 0) / 1000)} kbps` : ""],
    ["Frame rate", mediaInfoValue(media.miGeneral, "FrameRate") ? `${mediaInfoValue(media.miGeneral, "FrameRate")} FPS` : ""],
    ["Encoded date", mediaInfoValue(media.miGeneral, "Encoded_Date")],
    ["Writing application", mediaInfoValue(media.miGeneral, "Encoded_Application_Name")],
    ["Writing library", mediaInfoValue(media.miGeneral, "Encoded_Library_Name", "Encoded_Library_Version")],
  ];

  const mediaInfoVideoRows: Array<[string, string]> = [
    ["Format", mediaInfoValue(media.miVideo, "Format_Commercial_IfAny", "Format")],
    ["Format profile", [mediaInfoValue(media.miVideo, "Format_Profile"), mediaInfoValue(media.miVideo, "Format_Level")].filter(Boolean).join("@")],
    ["Format settings", [mediaInfoValue(media.miVideo, "Format_Settings_Matrix"), mediaInfoValue(media.miVideo, "Format_Settings_BVOP"), mediaInfoValue(media.miVideo, "Format_Settings_GOP")].filter(Boolean).join(" / ")],
    ["Codec ID", mediaInfoValue(media.miVideo, "CodecID")],
    ["Picture size", media.resolution],
    ["Pixel aspect ratio", mediaInfoValue(media.miVideo, "PixelAspectRatio")],
    ["Display aspect ratio", mediaInfoValue(media.miVideo, "DisplayAspectRatio")],
    ["Frame rate", mediaInfoValue(media.miVideo, "FrameRate") ? `${mediaInfoValue(media.miVideo, "FrameRate")} FPS` : friendlyFrameRateLabel(media.frameRate)],
    ["Scan type", media.scanType],
    ["Scan order", mediaInfoValue(media.miVideo, "ScanOrder")],
    ["Bit depth", mediaInfoValue(media.miVideo, "BitDepth") ? `${mediaInfoValue(media.miVideo, "BitDepth")} bit` : ""],
    ["Bitrate mode", mediaInfoValue(media.miVideo, "BitRate_Mode")],
    ["Bitrate", numOrNull(mediaInfoValue(media.miVideo, "BitRate")) ? `${fmtRounded((numOrNull(mediaInfoValue(media.miVideo, "BitRate")) || 0) / 1000)} kbps` : ""],
    ["Chroma subsampling", mediaInfoValue(media.miVideo, "ChromaSubsampling")],
    ["Color space", mediaInfoValue(media.miVideo, "ColorSpace")],
    ["Color primaries", mediaInfoValue(media.miVideo, "colour_primaries")],
    ["Transfer characteristics", mediaInfoValue(media.miVideo, "transfer_characteristics")],
    ["Stream size", fmtBytes(numOrNull(mediaInfoValue(media.miVideo, "StreamSize")))],
  ];

  const mediaInfoAudioSections = media.miAudioTracks.map((track: any, index: number) => ({
    title: `Audio track ${index + 1}`,
    rows: [
      ["Format", mediaInfoValue(track, "Format")],
      ["Codec ID", mediaInfoValue(track, "CodecID")],
      ["Channels", friendlyChannelLabel(mediaInfoValue(track, "Channels")) || mediaInfoValue(track, "Channels")],
      ["Sample rate", mediaInfoValue(track, "SamplingRate") ? `${mediaInfoValue(track, "SamplingRate")} Hz` : ""],
      ["Bit depth", mediaInfoValue(track, "BitDepth") ? `${mediaInfoValue(track, "BitDepth")} bit` : ""],
      ["Bitrate mode", mediaInfoValue(track, "BitRate_Mode")],
      ["Bitrate", numOrNull(mediaInfoValue(track, "BitRate")) ? `${fmtRounded((numOrNull(mediaInfoValue(track, "BitRate")) || 0) / 1000)} kbps` : ""],
      ["Duration", mediaInfoValue(track, "Duration") ? fmtFriendlyDuration(numOrNull(mediaInfoValue(track, "Duration"))) : ""],
      ["Stream size", fmtBytes(numOrNull(mediaInfoValue(track, "StreamSize")))],
      ["Language", mediaInfoValue(track, "Language", "Language_String3")],
    ] as Array<[string, string]>,
  }));


  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 1000,
        background: "rgba(15, 23, 42, 0.72)",
        backdropFilter: "blur(6px)",
        padding: 20,
        display: "flex",
        alignItems: "stretch",
        justifyContent: "center",
      }}
      onClick={onClose}
    >
      <div
        className="card"
        onClick={(e) => e.stopPropagation()}
        style={{
          width: "min(1320px, 100%)",
          height: "100%",
          background: "#fff",
          borderRadius: 22,
          overflow: "hidden",
          display: "grid",
          gridTemplateRows: "auto 1fr",
          boxShadow: "0 28px 80px rgba(15,23,42,0.35)",
        }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            gap: 8,
            alignItems: "center",
            padding: "16px 18px",
            borderBottom: "1px solid #e7ebf2",
            background: "#fff",
          }}
        >
          <div style={{ minWidth: 0 }}>
            <div style={{ fontWeight: 900, fontSize: 22, lineHeight: 1.2, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
              {item.valid || item.id}
            </div>
            <div style={{ fontSize: 13, opacity: 0.7, marginTop: 2, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
              {item.caption || "Media preview"}
            </div>
          </div>
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap", justifyContent: "flex-end" }}>
            <button onClick={() => setShowSafe((v) => !v)}>{showSafe ? "Hide safe-area" : "Show safe-area"}</button>
            <button onClick={() => setPresetOpen(true)}>Download preset</button>
            <button onClick={onClose}>Close</button>
          </div>
        </div>

        <div style={{ overflow: "auto", padding: 18, background: "#f8fafc" }}>
          <div style={{ width: "min(1160px, 100%)", margin: "0 auto", display: "grid", gap: 14 }}>
            <div style={{ position: "relative" }}>
              {loading ? (
                <div style={{ padding: 24, borderRadius: 16, background: "#f6f7f9", fontSize: 13 }}>Loading preview…</div>
              ) : videoError ? (
                <div style={{ padding: 24, borderRadius: 16, border: "1px solid #ffb3b3", color: "#a10000", fontSize: 13, background: "#fff" }}>
                  {videoError}
                </div>
              ) : (
                <>
                  <video controls autoPlay style={{ width: "100%", borderRadius: 18, background: "#000", display: "block" }} src={videoUrl} />
                  {showSafe ? (
                    <>
                      <div style={{ position: "absolute", inset: "5%", border: "2px dashed rgba(220,38,38,0.95)", pointerEvents: "none" }} />
                      <div style={{ position: "absolute", inset: "10%", border: "2px dashed rgba(220,38,38,0.75)", pointerEvents: "none" }} />
                    </>
                  ) : null}
                </>
              )}
            </div>

            <div
              style={{
                border: "1px solid #e2e8f0",
                borderRadius: 20,
                background: "linear-gradient(180deg, #ffffff 0%, #f8fafc 100%)",
                padding: 16,
                boxShadow: "0 18px 32px rgba(15,23,42,0.06)",
              }}
            >
              <div style={{ display: "flex", justifyContent: "space-between", gap: 10, alignItems: "center", flexWrap: "wrap", marginBottom: 14 }}>
                <div>
                  <div style={{ fontWeight: 900, fontSize: 18, color: "#0f172a" }}>Video metadata</div>
                  <div style={{ fontSize: 13, color: "#64748b", marginTop: 2 }}>Client-friendly details shown directly under the video preview.</div>
                </div>
                <div
                  style={{
                    borderRadius: 999,
                    padding: "7px 12px",
                    border: item.qcStatus === "PASSED" ? "1px solid #bbf7d0" : "1px solid #dbe3ec",
                    background: item.qcStatus === "PASSED" ? "#ecfdf3" : "#f8fafc",
                    color: item.qcStatus === "PASSED" ? "#166534" : "#475569",
                    fontSize: 12,
                    fontWeight: 900,
                  }}
                >
                  {niceQcLabel(item.qcStatus)}
                </div>
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(145px, 1fr))", gap: 10 }}>
                {summaryCards.map((card) => (
                  <StatCard key={card.label} label={card.label} value={card.value} tone={card.tone} />
                ))}
              </div>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(290px, 1fr))", gap: 12 }}>
              <InfoSection title="Media details" subtitle="Technical media information for the previewed file." rows={mediaRows} />
              <InfoSection title="DAM details" subtitle="Business metadata saved with this DAM item." rows={libraryRows} />
              <InfoSection title="Asset details" subtitle="Upload and source details for the current preview." rows={assetRows} />
            </div>

            {media.mediaInfo ? (
              <div style={{ display: "grid", gap: 12 }}>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: 12 }}>
                  <InfoSection title="General" subtitle="Useful container and file-level details." rows={mediaInfoGeneralRows} />
                  <InfoSection title="Video" subtitle="Useful picture-level details." rows={mediaInfoVideoRows} />
                </div>
                {mediaInfoAudioSections.length ? (
                  <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: 12 }}>
                    {mediaInfoAudioSections.map((section: { title: string; rows: Array<[string, string]> }) => (
                      <InfoSection key={section.title} title={section.title} subtitle="Useful sound-track details." rows={section.rows} />
                    ))}
                  </div>
                ) : null}
              </div>
            ) : null}
          </div>
        </div>

        {presetOpen ? (
          <PresetDownloadModal
            title={`Presets — ${item.valid || item.id}`}
            sourceType={item.sourceType === "CREATIVE" || String(item.id || "").startsWith("creative:") ? "CREATIVE" : "DAM"}
            sourceId={item.sourceType === "CREATIVE" || String(item.id || "").startsWith("creative:") ? String(item.sourceCreativeId || item.id).replace(/^creative:/, "") : item.id}
            onClose={() => setPresetOpen(false)}
          />
        ) : null}
      </div>
    </div>
  );
}
