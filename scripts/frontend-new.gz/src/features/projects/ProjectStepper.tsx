import { NavLink } from "react-router-dom";
import type { ProjectAccess } from "./types";

type StepState = { ok: boolean } | undefined;

function okOf(steps: Record<string, StepState>, key: string) {
  return !!steps[key]?.ok;
}

function okAny(steps: Record<string, StepState>, keys: string[]) {
  for (const k of keys) {
    if (typeof steps[k]?.ok === "boolean") return !!steps[k]?.ok;
  }
  return false;
}

export function ProjectStepper({
  projectId,
  steps,
  access,
}: {
  projectId: string;
  steps: Record<string, { ok: boolean } | undefined>;
  access?: ProjectAccess | null;
}) {
  // prefer combined keys if backend sends them, otherwise fallback to split keys
  const plannerCommitOk =
    okAny(steps, ["planner_commit", "plannerCommit"]) || (okOf(steps, "planner") && okOf(steps, "commit"));

  // Backwards compatible:
  // - older backend exposes a single "send_tracking" step
  // - newer backend can expose split steps: "send" and "tracking"
  const sendOk = okAny(steps, ["send", "send_only"]) || okAny(steps, ["send_tracking", "sendTracking"]);
  const trackingOk = okAny(steps, ["tracking"]) || okAny(steps, ["send_tracking", "sendTracking"]);

  const isScopedProjectUser = access?.scope === "PROJECT";
  const s = [
    { key: "creatives", label: "Creatives", to: `/projects/${projectId}/creatives`, ok: okOf(steps, "creatives"), show: !isScopedProjectUser || access?.canViewCreatives },
    { key: "qc", label: "QC", to: `/projects/${projectId}/qc`, ok: okOf(steps, "qc"), show: !isScopedProjectUser || access?.canViewCreatives },
    { key: "planner", label: "Planner + Commit", to: `/projects/${projectId}/planner`, ok: plannerCommitOk, show: !isScopedProjectUser || access?.canPlanner },
    { key: "approvals", label: "Approvals", to: `/projects/${projectId}/approvals`, ok: okOf(steps, "approvals"), show: !isScopedProjectUser || access?.canApprove },
    { key: "transcode", label: "Transcode", to: `/projects/${projectId}/transcode`, ok: okOf(steps, "transcode"), show: !isScopedProjectUser },
    { key: "send", label: "Send", to: `/projects/${projectId}/send`, ok: sendOk, show: !isScopedProjectUser || access?.canSend },
    { key: "tracking", label: "Tracking", to: `/projects/${projectId}/tracking`, ok: trackingOk, show: !isScopedProjectUser || access?.canViewTracking },
  ].filter((step) => step.show);

  return (
    <div style={{ width: "100%", minWidth: 0, overflow: "hidden" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "nowrap", width: "100%", minWidth: 0 }}>
      {s.map((st, idx) => (
        <div key={st.key} style={{ display: "flex", alignItems: "center", gap: 8, flex: "1 1 0", minWidth: 0 }}>
          <NavLink to={st.to} style={{ textDecoration: "none", flex: "1 1 0", minWidth: 0 }}>
            {({ isActive }) => (
              <div
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 8,
                  padding: "10px 10px",
                  borderRadius: 999,
                  background: "white",
                  border: isActive ? "2px solid #ff4fa1" : "1px solid rgba(0,0,0,0.10)",
                  boxShadow: isActive ? "0 6px 16px rgba(255,79,161,0.15)" : undefined,
                  width: "100%",
                  minWidth: 0,
                  justifyContent: "flex-start",
                  boxSizing: "border-box",
                }}
              >
                <span
                  style={{
                    width: 10,
                    height: 10,
                    borderRadius: 999,
                    background: st.ok ? "#22c55e" : "#94a3b8",
                    boxShadow: st.ok ? "0 0 0 3px rgba(34,197,94,0.15)" : undefined,
                    flex: "0 0 auto",
                  }}
                />
                <span style={{ fontSize: 12, fontWeight: 900, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", minWidth: 0 }}>{st.label}</span>
              </div>
            )}
          </NavLink>

          {idx < s.length - 1 ? <span style={{ opacity: 0.42, fontWeight: 900, flex: "0 0 auto" }}>→</span> : null}
        </div>
      ))}
      </div>
    </div>
  );
}