import { useEffect, useMemo, useState, type CSSProperties } from "react";
import type { NotificationAttempt, NotificationEvent } from "./notifications.types";
import { listProjectNotifications, retriggerNotification } from "./notifications.Api";

function fmt(dt: string | Date | null | undefined) {
  if (!dt) return "-";
  const d = typeof dt === "string" ? new Date(dt) : dt;
  if (Number.isNaN(d.getTime())) return "-";
  return d.toLocaleString();
}

const TYPE_LABEL: Record<number, string> = {
  1: "Project created",
  2: "QC result",
  3: "All files uploaded",
  4: "Destinations selected",
  5: "Project committed",
  6: "File to destination",
  7: "File to multiple destinations",
  8: "Project complete",
  9: "File ready for approval",
  10: "File approved",
  11: "File sent",
};

function statusStyles(status?: string | null): CSSProperties {
  const v = String(status || "").toUpperCase();
  if (v === "SENT") return { background: "#ecfdf3", color: "#027a48", border: "1px solid #d1fadf" };
  if (v === "FAILED") return { background: "#fef2f2", color: "#b42318", border: "1px solid #fecdca" };
  return { background: "#eff8ff", color: "#175cd3", border: "1px solid #b2ddff" };
}

function payloadRows(ev: NotificationEvent): Array<{ label: string; value: string }> {
  const p: any = ev.payload || {};
  const rows: Array<{ label: string; value: string }> = [];
  const push = (label: string, value: any) => {
    const v = Array.isArray(value)
      ? value.map((x) => String(x ?? "").trim()).filter(Boolean).join(", ")
      : String(value ?? "").trim();
    if (!v || v === "-") return;
    rows.push({ label, value: v });
  };

  push("Project Name", p.projectName);
  push("Project Number", p.projectNumber || p.projectCode);
  push("Advertiser Group", p.advertiserGroupName);
  push("Advertiser Name", p.advertiserName);
  push("Brand", p.brandName);
  push("Product Category", p.productCategoryName);

  if (ev.type === 1) {
    push("Media Agency", p.mediaAgencyName);
    push("Creative Agency", p.creativeAgencyName);
    push("Production Agency", p.productionHouseName);
    push("Post House", p.postHouseName);
    push("Audio Agency", p.audioAgencyName);
    push("Uploader", p.projectUploaderTeamName ? `${p.projectUploaderName || ""}${p.projectUploaderName ? " / " : ""}${p.projectUploaderTeamName}` : p.projectUploaderName);
    push("Remarks", p.projectRemarks);
    return rows;
  }

  if ([2, 3, 6, 7, 9, 10, 11].includes(ev.type)) {
    push("VALID", p.creativeValid);
    push("Caption", p.creativeCaption || p.creativeTitle);
    push("Format", p.creativeFormat);
    push("Language", p.creativeLanguageText || p.creativeLanguage || p.creativeLanguages);
    push("Duration", p.creativeDuration);
  }

  if (ev.type === 2) {
    push("Status", p.qcStatus);
  }
  if (ev.type === 3) {
    push("Upload Time (IST)", p.latestUploadAtIst);
  }
  if (ev.type === 4) {
    push("Report", p.reportUrl ? "Planner report available" : p.reportRowCount ? `${p.reportRowCount} row(s)` : "Prepared");
  }
  if (ev.type === 5) {
    push("Commit Time", p.commitTimeIst);
    push("Committed By", p.committedByLabel);
    push("Plan Version", p.planVersion);
  }
  if ([6, 7, 9, 10, 11].includes(ev.type)) {
    push("Commit Time", p.commitTimeIst);
    if (ev.type !== 7) push("Committed By", p.committedByLabel);
    push("Destination", p.destinationName || p.destinationNamesLabel);
    push("Channels", Array.isArray(p.channels) ? p.channels.map((x: any) => x?.name).filter(Boolean) : p.channelName);
  }
  if ([6, 9, 10].includes(ev.type)) {
    push("Approval Status", p.approvalStatusLabel || p.approvalStatus);
    push("Approved By", p.approvalApprovedByLabel || p.approvalApprovedByList);
    push("Pending For", p.approvalPendingForLabel || p.approvalPendingForList);
  }
  if (ev.type === 10) {
    push("Final Approval Time", p.approvalCompletedAtIst);
    push("Approval Elapsed", p.approvalElapsedText);
  }
  if (ev.type === 7) {
    push("Destinations Delivered", p.destinations);
  }
  if (ev.type === 8) {
    push("Total Deliveries", p.totalDeliveries);
  }
  return rows;
}

function notesFor(ev: NotificationEvent): string[] {
  const p: any = ev.payload || {};
  const notes: string[] = [];
  if (p.committedProjectNewFileOnly) notes.push("Committed project: only the newly uploaded file is included.");
  if (p.reportUrl) notes.push(`Planner report: ${p.reportUrl}`);
  if (Array.isArray(p.reportPreviewLines)) notes.push(...p.reportPreviewLines.map((x: any) => String(x ?? "").trim()).filter(Boolean));
  if (Array.isArray(p.clientQcIssues) && p.clientQcIssues.length) {
    for (const item of p.clientQcIssues) {
      const line = [item?.label, item?.expected ? `Expected: ${item.expected}` : "", item?.actual ? `Actual: ${item.actual}` : ""]
        .filter(Boolean)
        .join(" • ");
      if (line) notes.push(line);
    }
  }
  if (p.approvalElapsedText && ev.type === 10) notes.push(`Time from project commit to final approval: ${p.approvalElapsedText}`);
  return notes;
}

function latestAttempt(ev: NotificationEvent): NotificationAttempt | null {
  return ev.attempts?.[0] || null;
}

export function ProjectNotificationsPanel({ projectId }: { projectId: string }) {
  const [events, setEvents] = useState<NotificationEvent[]>([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [busyId, setBusyId] = useState<string | null>(null);
  const [openId, setOpenId] = useState<string | null>(null);

  const load = async () => {
    setLoading(true);
    setErr(null);
    try {
      const res = await listProjectNotifications(projectId);
      setEvents(res.events || []);
    } catch (e: any) {
      setErr(e?.message || "Failed to load notifications");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, [projectId]);

  const rows = useMemo(() => events, [events]);

  return (
    <div className="card" style={{ display: "grid", gap: 12, marginTop: 16 }}>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, flexWrap: "wrap" }}>
        <div>
          <div style={{ fontSize: 18, fontWeight: 800 }}>Notification Log</div>
          <div style={{ fontSize: 12, opacity: 0.72 }}>
            Event history, recipients, retry attempts, and rendered notification context for this project.
          </div>
        </div>
        <button className="btn" onClick={load} disabled={loading}>
          {loading ? "Refreshing..." : "Refresh"}
        </button>
      </div>

      {err ? (
        <div className="card" style={{ borderColor: "#fda4af", background: "#fff1f2", color: "#9f1239" }}>
          {err}
        </div>
      ) : null}

      {rows.length === 0 ? (
        <div style={{ fontSize: 13, opacity: 0.72 }}>{loading ? "Loading..." : "No notification events yet."}</div>
      ) : null}

      <div style={{ display: "grid", gap: 12 }}>
        {rows.map((ev) => {
          const attempt = latestAttempt(ev);
          const summary = payloadRows(ev);
          const notes = notesFor(ev);
          const recipients = (ev.to || []).concat((ev.cc || []).map((x) => `CC: ${x}`));
          const isOpen = openId === ev.id;
          return (
            <div key={ev.id} style={{ border: "1px solid #e5e7eb", borderRadius: 16, overflow: "hidden", background: "#fff" }}>
              <div style={{ padding: 14, display: "grid", gap: 10 }}>
                <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "flex-start", flexWrap: "wrap" }}>
                  <div style={{ display: "grid", gap: 6, minWidth: 0 }}>
                    <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
                      <span style={{ ...statusStyles(attempt?.status), borderRadius: 999, padding: "4px 10px", fontSize: 12, fontWeight: 800 }}>
                        {TYPE_LABEL[ev.type] || `Type ${ev.type}`}
                      </span>
                      <span style={{ fontSize: 12, opacity: 0.72 }}>Created {fmt(ev.createdAt)}</span>
                      {attempt ? (
                        <span style={{ ...statusStyles(attempt.status), borderRadius: 999, padding: "4px 10px", fontSize: 12, fontWeight: 800 }}>
                          {attempt.status} #{attempt.attemptNo}
                        </span>
                      ) : null}
                    </div>
                    <div style={{ fontSize: 15, fontWeight: 800, lineHeight: 1.4 }}>{ev.title}</div>
                    <div style={{ fontSize: 12, opacity: 0.6, wordBreak: "break-all" }}>{ev.dedupeKey}</div>
                  </div>

                  <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                    <button className="btn" type="button" onClick={() => setOpenId(isOpen ? null : ev.id)}>
                      {isOpen ? "Hide details" : "Show details"}
                    </button>
                    <button
                      className="btn"
                      disabled={busyId === ev.id}
                      onClick={async () => {
                        const reason = window.prompt("Reason for retrigger (optional):") ?? "";
                        setBusyId(ev.id);
                        setErr(null);
                        try {
                          await retriggerNotification(ev.id, reason);
                          await load();
                          setOpenId(ev.id);
                        } catch (e: any) {
                          setErr(e?.message || "Failed to retrigger");
                        } finally {
                          setBusyId(null);
                        }
                      }}
                    >
                      {busyId === ev.id ? "Working..." : "Retrigger"}
                    </button>
                  </div>
                </div>

                <div style={{ display: "grid", gap: 8 }}>
                  <div style={{ fontSize: 12, opacity: 0.7 }}>
                    Recipients: {recipients.length ? recipients.join(", ") : "-"}
                  </div>
                  {attempt?.error ? <div style={{ fontSize: 12, color: "#b42318" }}>{attempt.error}</div> : null}
                </div>
              </div>

              {isOpen ? (
                <div style={{ borderTop: "1px solid #eef2f7", padding: 14, background: "#fafcff", display: "grid", gap: 14 }}>
                  <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(260px, 1fr))", gap: 12 }}>
                    <div className="card" style={{ padding: 12 }}>
                      <div style={{ fontWeight: 800, marginBottom: 8 }}>Message details</div>
                      {summary.length ? (
                        <div style={{ display: "grid", gap: 6, fontSize: 13 }}>
                          {summary.map((row) => (
                            <div key={row.label} style={{ display: "grid", gridTemplateColumns: "160px minmax(0,1fr)", gap: 10 }}>
                              <div style={{ opacity: 0.7 }}>{row.label}</div>
                              <div style={{ fontWeight: 600, wordBreak: "break-word" }}>{row.value}</div>
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div style={{ fontSize: 13, opacity: 0.65 }}>No extra payload details.</div>
                      )}
                    </div>

                    <div className="card" style={{ padding: 12 }}>
                      <div style={{ fontWeight: 800, marginBottom: 8 }}>Attempt log</div>
                      {ev.attempts?.length ? (
                        <div style={{ display: "grid", gap: 8 }}>
                          {ev.attempts.map((attemptRow) => (
                            <div key={attemptRow.id} style={{ border: "1px solid #e5e7eb", borderRadius: 12, padding: 10, background: "#fff" }}>
                              <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap", marginBottom: 6 }}>
                                <span style={{ ...statusStyles(attemptRow.status), borderRadius: 999, padding: "3px 8px", fontSize: 11, fontWeight: 800 }}>
                                  {attemptRow.status}
                                </span>
                                <span style={{ fontSize: 12, fontWeight: 700 }}>Attempt #{attemptRow.attemptNo}</span>
                                <span style={{ fontSize: 12, opacity: 0.7 }}>{fmt(attemptRow.createdAt)}</span>
                              </div>
                              {attemptRow.reason ? <div style={{ fontSize: 12, opacity: 0.8 }}>Reason: {attemptRow.reason}</div> : null}
                              {attemptRow.error ? <div style={{ fontSize: 12, color: "#b42318" }}>Error: {attemptRow.error}</div> : null}
                            </div>
                          ))}
                        </div>
                      ) : (
                        <div style={{ fontSize: 13, opacity: 0.65 }}>No attempts recorded.</div>
                      )}
                    </div>
                  </div>

                  {notes.length ? (
                    <div className="card" style={{ padding: 12 }}>
                      <div style={{ fontWeight: 800, marginBottom: 8 }}>Log notes</div>
                      <div style={{ display: "grid", gap: 6, fontSize: 13 }}>
                        {notes.map((note, idx) => (
                          <div key={`${ev.id}-note-${idx}`} style={{ lineHeight: 1.45 }}>
                            • {note}
                          </div>
                        ))}
                      </div>
                    </div>
                  ) : null}
                </div>
              ) : null}
            </div>
          );
        })}
      </div>
    </div>
  );
}
