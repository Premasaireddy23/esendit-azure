import { api } from "../../../lib/api";
import type { ListProjectNotificationsResponse, RetriggerNotificationResponse } from "./notifications.types";

export async function listProjectNotifications(projectId: string): Promise<ListProjectNotificationsResponse> {
  return api<ListProjectNotificationsResponse>(`/projects/${projectId}/notifications`);
}

export async function retriggerNotification(eventId: string, reason?: string): Promise<RetriggerNotificationResponse> {
  return api<RetriggerNotificationResponse>(`/notifications/${eventId}/retrigger`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ reason: reason ?? null }),
  });
}
