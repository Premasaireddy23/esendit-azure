export type NotificationAttempt = {
  id: string;
  attemptNo: number;
  status: "QUEUED" | "SENT" | "FAILED";
  error?: string | null;
  reason?: string | null;
  triggeredByUserId?: string | null;
  createdAt: string;
  updatedAt: string;
};

export type NotificationEvent = {
  id: string;
  type: number;
  dedupeKey: string;
  origin?: string | null;
  title: string;
  payload: any;
  to: string[];
  cc: string[];
  projectId?: string | null;
  creativeId?: string | null;
  createdAt: string;
  updatedAt: string;
  attempts: NotificationAttempt[];
};

export type ListProjectNotificationsResponse = {
  events: NotificationEvent[];
};

export type RetriggerNotificationResponse = {
  ok: boolean;
  attemptNo: number;
};
