import { type CSSProperties, useEffect, useMemo, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { api } from "../../../lib/api";
import { getMe, hasAnyPerm, hasPerm, type MeResponse } from "../../../lib/me";
import { ProjectViewDrawer } from "../ProjectViewDrawer";
import { AppModal } from "../../../ui/AppModal";

type ProjectRow = {
  id: string;
  name: string;
  projectNumber: string;
  status: "OPEN" | "CLOSED";
  createdAt: string;
  updatedAt?: string;
  account?: { name: string; type: string };

  // Optional fields (if backend later includes them)
  advertiserGroup?: { id?: string; name?: string } | null;
  advertiser?: { id?: string; name?: string } | null;
  brand?: { id?: string; name?: string } | null;
  productCategory?: { id?: string; name?: string } | null;
  access?: {
    scope: "GLOBAL" | "PROJECT" | "NONE";
    canEditProject?: boolean;
    canCloseProject?: boolean;
    canReopenProject?: boolean;
    canDeleteProject?: boolean;
  } | null;
};

type ProjectsResp = { total: number; items: ProjectRow[] };

function safe(v: any) {
  return v == null || v === "" ? "—" : String(v);
}


const closedProjectRowStyle: CSSProperties = {
  background: "linear-gradient(90deg, rgba(239,68,68,0.10), rgba(255,255,255,0.86) 28%)",
};

const closedProjectAccentCellStyle: CSSProperties = {
  boxShadow: "inset 4px 0 0 rgba(220,38,38,0.55)",
};

const closedProjectBadgeStyle: CSSProperties = {
  display: "inline-flex",
  alignItems: "center",
  gap: 6,
  padding: "4px 10px",
  borderRadius: 999,
  background: "rgba(239,68,68,0.12)",
  border: "1px solid rgba(239,68,68,0.22)",
  color: "#991b1b",
  fontWeight: 700,
  fontSize: 12,
  width: "fit-content",
  backdropFilter: "blur(6px)",
  whiteSpace: "nowrap",
};

function ActionTile(props: {
  title: string;
  subtitle: string;
  tone?: "default" | "danger";
  onClick: () => void;
}) {
  const danger = props.tone === "danger";
  return (
    <button
      type="button"
      onClick={props.onClick}
      style={{
        textAlign: "left",
        borderRadius: 18,
        border: `1px solid ${danger ? "#fecaca" : "#dbe4ee"}`,
        background: danger ? "#fff5f5" : "#f8fafc",
        padding: 16,
        display: "grid",
        gap: 6,
        cursor: "pointer",
      }}
    >
      <div style={{ fontSize: 16, fontWeight: 800, color: danger ? "#b91c1c" : "#0f172a" }}>{props.title}</div>
      <div style={{ fontSize: 13, color: danger ? "#7f1d1d" : "#64748b" }}>{props.subtitle}</div>
    </button>
  );
}

export function ProjectsPage() {
  const nav = useNavigate();
  const [sp] = useSearchParams();

  // URL driven
  const q = sp.get("q") || "";
  const status = sp.get("status") || ""; // OPEN|CLOSED|""
  const sort = (sp.get("sort") as any) || "createdAt";
  const order = (sp.get("order") as any) || "desc";

  // input state (only triggers on Search)
  const [qInput, setQInput] = useState(q);

  const [data, setData] = useState<ProjectsResp>({ total: 0, items: [] });
  const [me, setMe] = useState<MeResponse | null>(null);
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);

  // project actions + drawer
  const [actionFor, setActionFor] = useState<ProjectRow | null>(null);
  const [deleteFor, setDeleteFor] = useState<ProjectRow | null>(null);
  const [viewing, setViewing] = useState<ProjectRow | null>(null);

  useEffect(() => setQInput(q), [q]);

  useEffect(() => {
    getMe().then(setMe).catch(() => setMe(null));
  }, []);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key !== "Escape") return;
      setActionFor(null);
      setDeleteFor(null);
    };
    document.addEventListener("keydown", onKey);
    return () => document.removeEventListener("keydown", onKey);
  }, []);

  const queryString = useMemo(() => {
    const p = new URLSearchParams();
    if (q.trim()) p.set("q", q.trim());
    if (status) p.set("status", status);
    p.set("sort", sort);
    p.set("order", order);
    p.set("take", "50");
    p.set("skip", "0");
    return p.toString();
  }, [q, status, sort, order]);

  async function load() {
    setErr("");
    setLoading(true);
    try {
      const r = await api<ProjectsResp>(`/masters/projects?${queryString}`);
      setData(r);
    } catch (e: any) {
      setErr(e?.message || "Failed to load projects");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [queryString]);

  const setParam = (k: string, v: string) => {
    const p = new URLSearchParams(sp);
    if (!v) p.delete(k);
    else p.set(k, v);
    nav(`/projects?${p.toString()}`);
  };

  const onSearch = () => {
    const p = new URLSearchParams(sp);
    const qq = qInput.trim();
    if (qq) p.set("q", qq);
    else p.delete("q");
    nav(`/projects?${p.toString()}`);
  };


  const canCreateProject = hasAnyPerm(me, ["PROJECT_CREATE", "PROJECT_WIZARD_CREATE", "action:projects:create", "action:projects:wizard:create"]);
  const canEditProjectGlobally = hasPerm(me, "PROJECT_UPDATE");
  const canCloseProjectGlobally = hasPerm(me, "PROJECT_CLOSE");
  const canReopenProjectGlobally = hasPerm(me, "PROJECT_REOPEN");

  const canEditRow = (row?: ProjectRow | null) => row?.access?.scope === "PROJECT" ? !!row.access.canEditProject : canEditProjectGlobally;
  const canCloseRow = (row?: ProjectRow | null) => row?.access?.scope === "PROJECT" ? !!row.access.canCloseProject : canCloseProjectGlobally;
  const canReopenRow = (row?: ProjectRow | null) => row?.access?.scope === "PROJECT" ? !!row.access.canReopenProject : canReopenProjectGlobally;
  const canDeleteRow = (row?: ProjectRow | null) => row?.access?.scope === "PROJECT" ? !!row.access.canDeleteProject : canEditProjectGlobally;
  const canToggleRow = (row?: ProjectRow | null) => row?.status === "OPEN" ? canCloseRow(row) : canReopenRow(row);

  const openProject = (id: string) => nav(`/projects/${id}/creatives`);

  const doCloseToggle = async (row: ProjectRow) => {
    setActionFor(null);
    try {
      if (row.status === "OPEN") {
        await api(`/projects/${row.id}/close`, { method: "POST" });
      } else {
        await api(`/projects/${row.id}/reopen`, { method: "POST" });
      }
      await load();
    } catch (e: any) {
      alert(e?.message || "Action failed");
    }
  };

  const openDeleteConfirm = (row: ProjectRow) => {
    setActionFor(null);
    setDeleteFor(row);
  };

  const doDelete = async (row: ProjectRow) => {
    try {
      await api(`/projects/${row.id}`, { method: "DELETE" });
      setDeleteFor(null);
      if (viewing?.id === row.id) setViewing(null);
      await load();
    } catch (e: any) {
      alert(e?.message || "Delete failed");
    }
  };

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div className="card" style={{ padding: 12 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12 }}>
          <div>
            <div style={{ fontSize: 22, fontWeight: 900 }}>Project</div>
            <div style={{ fontSize: 12, opacity: 0.7 }}>Manage your projects</div>
          </div>

          {canCreateProject ? (
            <button className="btnPrimary" onClick={() => nav("/projects/new")} type="button">
              + Add Project
            </button>
          ) : null}
        </div>

        <div style={{ display: "flex", gap: 12, marginTop: 12, flexWrap: "wrap", alignItems: "center" }}>
          <input
            placeholder="Search..."
            value={qInput}
            onChange={(e) => setQInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") onSearch();
            }}
            style={{ minWidth: 260 }}
          />
          <button onClick={onSearch} type="button">
            Search
          </button>

          <div style={{ marginLeft: "auto", display: "flex", gap: 10, flexWrap: "wrap" }}>
            <select value={status} onChange={(e) => setParam("status", e.target.value)}>
              <option value="">All</option>
              <option value="OPEN">Open</option>
              <option value="CLOSED">Closed</option>
            </select>

            <select value={sort} onChange={(e) => setParam("sort", e.target.value)}>
              <option value="createdAt">Sort: Created</option>
              <option value="name">Sort: Name</option>
              <option value="status">Sort: Status</option>
              <option value="projectNumber">Sort: Project #</option>
            </select>

            <select value={order} onChange={(e) => setParam("order", e.target.value)}>
              <option value="desc">Desc</option>
              <option value="asc">Asc</option>
            </select>
          </div>
        </div>

        {err && <div style={{ marginTop: 10, color: "#a00" }}>{err}</div>}

        <div style={{ marginTop: 10, fontSize: 12, opacity: 0.7 }}>
          {loading ? "Loading..." : `Showing ${data.items.length} of ${data.total}`}
        </div>

        <div style={{ marginTop: 10 }} className="tableWrap">
          <table className="tbl">
            <thead>
              <tr>
                <th>Project Number</th>
                <th>Project Name</th>
                <th>Advertiser Group</th>
                <th>Advertiser</th>
                <th>Brand</th>
                <th>Product Category</th>
                <th style={{ width: 40 }}></th>
              </tr>
            </thead>
            <tbody>
              {data.items.map((r) => {
                const isClosed = r.status === "CLOSED";
                const closedTextColor = isClosed ? "#991b1b" : undefined;
                return (
                  <tr key={r.id} style={isClosed ? closedProjectRowStyle : undefined}>
                    <td style={isClosed ? closedProjectAccentCellStyle : undefined}>
                      <button
                        className="linkBtn"
                        type="button"
                        onClick={() => openProject(r.id)}
                        style={isClosed ? { color: closedTextColor } : undefined}
                      >
                        {safe(r.projectNumber)}
                      </button>
                    </td>
                    <td>
                      <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
                        <button
                          className="linkBtn"
                          type="button"
                          onClick={() => openProject(r.id)}
                          style={isClosed ? { color: closedTextColor } : undefined}
                        >
                          {safe(r.name)}
                        </button>
                        {isClosed ? <span style={closedProjectBadgeStyle}>Closed</span> : null}
                      </div>
                    </td>
                    <td>{safe(r.advertiserGroup?.name)}</td>
                    <td>{safe(r.advertiser?.name)}</td>
                    <td>{safe(r.brand?.name)}</td>
                    <td>{safe(r.productCategory?.name)}</td>
                    <td style={{ textAlign: "right" }}>
                      <button
                        type="button"
                        className="kebabBtn"
                        aria-label="Actions"
                        onClick={() => setActionFor(r)}
                      >
                        ⋮
                      </button>
                    </td>
                  </tr>
                );
              })}
              {!loading && data.items.length === 0 && (
                <tr>
                  <td colSpan={7} style={{ padding: 16, opacity: 0.7 }}>
                    No projects found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      <AppModal
        open={!!actionFor}
        onClose={() => setActionFor(null)}
        title="Project actions"
        subtitle={actionFor ? `${safe(actionFor.name)} • ${safe(actionFor.projectNumber)} • ${actionFor.status}` : undefined}
        width={560}
      >
        <div style={{ display: "grid", gap: 12 }}>
          <div
            style={{
              borderRadius: 18,
              border: "1px solid #e2e8f0",
              background: "#f8fafc",
              padding: 14,
              display: "grid",
              gap: 6,
            }}
          >
            <div style={{ fontSize: 14, fontWeight: 900, color: "#0f172a" }}>{safe(actionFor?.name)}</div>
            <div style={{ fontSize: 13, color: "#64748b" }}>Project number: {safe(actionFor?.projectNumber)}</div>
          </div>

          <div style={{ display: "grid", gap: 10 }}>
            {canEditRow(actionFor) ? (
              <ActionTile
                title="Edit project"
                subtitle="Open the project form and update project details."
                onClick={() => {
                  if (!actionFor) return;
                  setActionFor(null);
                  nav(`/projects/${actionFor.id}/edit`);
                }}
              />
            ) : null}
            <ActionTile
              title="View project"
              subtitle="Open the project summary in a full details drawer."
              onClick={() => {
                if (!actionFor) return;
                setViewing(actionFor);
                setActionFor(null);
              }}
            />
            {canToggleRow(actionFor) ? (
              <ActionTile
                title={actionFor?.status === "OPEN" ? "Close project" : "Reopen project"}
                subtitle={actionFor?.status === "OPEN" ? "Stop new work and mark this project as closed." : "Make this project active again."}
                onClick={() => {
                  if (!actionFor) return;
                  void doCloseToggle(actionFor);
                }}
              />
            ) : null}
            {canDeleteRow(actionFor) ? (
              <ActionTile
                title="Delete project"
                subtitle="Permanently remove the project when it is no longer needed."
                tone="danger"
                onClick={() => {
                  if (!actionFor) return;
                  openDeleteConfirm(actionFor);
                }}
              />
            ) : null}
          </div>
        </div>
      </AppModal>

      <AppModal
        open={!!deleteFor}
        onClose={() => setDeleteFor(null)}
        title="Delete project?"
        subtitle="This action is permanent and cannot be undone."
        width={520}
      >
        <div style={{ display: "grid", gap: 16 }}>
          <div
            style={{
              borderRadius: 18,
              border: "1px solid #fecaca",
              background: "#fff5f5",
              padding: 14,
              color: "#7f1d1d",
              fontSize: 14,
              lineHeight: 1.5,
            }}
          >
            You are deleting <b>{safe(deleteFor?.name)}</b> ({safe(deleteFor?.projectNumber)}).
            Delete only when you are sure the project is no longer needed.
          </div>
          <div style={{ display: "flex", justifyContent: "flex-end", gap: 10 }}>
            <button
              type="button"
              onClick={() => setDeleteFor(null)}
              style={{
                height: 42,
                padding: "0 18px",
                borderRadius: 999,
                border: "1px solid #d7dee8",
                background: "#fff",
                color: "#0f172a",
                fontWeight: 700,
              }}
            >
              Cancel
            </button>
            <button
              type="button"
              onClick={() => {
                if (!deleteFor) return;
                void doDelete(deleteFor);
              }}
              style={{
                height: 42,
                padding: "0 18px",
                borderRadius: 999,
                border: "1px solid #dc2626",
                background: "#dc2626",
                color: "#fff",
                fontWeight: 800,
              }}
            >
              Delete project
            </button>
          </div>
        </div>
      </AppModal>

      <ProjectViewDrawer
        open={!!viewing}
        projectId={viewing?.id || null}
        seed={viewing || undefined}
        onClose={() => setViewing(null)}
      />
    </div>
  );
}
