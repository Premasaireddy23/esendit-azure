import { useEffect } from "react";

import { DestinationsPage } from "../../masters/pages/DestinationsPage";
import { ChannelsPage } from "../../masters/pages/ChannelsPage";
import { DeliveryProfilesPage } from "../../masters/pages/DeliveryProfilesPage";
import { SlasPage } from "../../masters/pages/SlasPage";
import { HotFoldersPage } from "../../masters/pages/HotFoldersPage";

export type DeliverySetupTab =
  | "destinations"
  | "channels"
  | "deliveryProfiles"
  | "slas"
  | "hotFolders";

export function DeliverySetupModal(props: {
  open: boolean;
  tab: DeliverySetupTab;
  onTab: (t: DeliverySetupTab) => void;
  onClose: () => void;
  onReloadMatrix: () => void | Promise<void>;
}) {
  const { open, tab, onTab, onClose, onReloadMatrix } = props;

  // Escape to close
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open, onClose]);

  if (!open) return null;

  const tabs: { key: DeliverySetupTab; label: string }[] = [
    { key: "destinations", label: "Destinations" },
    { key: "channels", label: "Channels" },
    { key: "deliveryProfiles", label: "Delivery Profiles" },
    { key: "slas", label: "SLAs" },
    { key: "hotFolders", label: "Hot Folders" },
  ];

  function renderBody() {
    switch (tab) {
      case "destinations":
        return <DestinationsPage />;
      case "channels":
        return <ChannelsPage />;
      case "deliveryProfiles":
        return <DeliveryProfilesPage />;
      case "slas":
        return <SlasPage />;
      case "hotFolders":
        return <HotFoldersPage />;
      default:
        return null;
    }
  }

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.45)",
        display: "flex",
        alignItems: "flex-start",
        justifyContent: "center",
        padding: 16,
        overflowY: "auto",
        // Keep below nested edit modals inside Masters pages
        zIndex: 40,
      }}
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        style={{
          background: "white",
          borderRadius: 12,
          width: 1180,
          maxWidth: "100%",
          padding: 14,
          marginTop: 16,
          marginBottom: 16,
          maxHeight: "calc(100vh - 32px)",
          display: "flex",
          flexDirection: "column",
          overflow: "hidden",
        }}
      >
        <div className="row" style={{ justifyContent: "space-between", alignItems: "center", gap: 10 }}>
          <div style={{ display: "grid", gap: 4 }}>
            <div style={{ fontWeight: 800 }}>Manage Delivery Setup</div>
            <div style={{ fontSize: 12, opacity: 0.7 }}>
              Update Destinations / Channels / Profiles / SLAs / Hot Folders without leaving the Delivery Matrix.
            </div>
          </div>

          <div className="row" style={{ gap: 8 }}>
            <button onClick={onReloadMatrix} title="Reload destinations/channels in the Delivery Matrix">
              Reload Matrix
            </button>
            <button onClick={onClose}>Close</button>
          </div>
        </div>

        <div className="row" style={{ gap: 8, flexWrap: "wrap", marginTop: 10 }}>
          {tabs.map((t) => (
            <button
              key={t.key}
              onClick={() => onTab(t.key)}
              style={tab === t.key ? { background: "#eef" } : undefined}
            >
              {t.label}
            </button>
          ))}
        </div>

        <div style={{ marginTop: 12, overflow: "auto", paddingRight: 2 }}>
          {renderBody()}
        </div>
      </div>
    </div>
  );
}
