import { useNavigate, useOutletContext, useParams } from "react-router-dom";
import { api, type ApiError } from "../../../lib/api";
import type { OutletCtx } from "../types";
import { useEffect, useMemo, useState } from "react";
import { QcGateBanner } from "./QcGateBanner";
import * as XLSX from "xlsx";
import { getCreativeCodeLabel, getMe, hasPerm, type MeResponse } from "../../../lib/me";

type Creative = {
  id: string;
  valid: string;
  caption?: string;
  duration?: string | null;
  languages?: string[] | null;
  format?: string | null;
  audio?: string | null;
};
type Destination = { id: string; name: string; category?: string | null; receiverAccountId?: string | null; receiverAccountName?: string | null; receiverCategory?: string | null };
type LogoPosition = "LHS" | "RHS" | "BLHS" | "BRHS";
type Channel = { id: string; name: string; destinationId?: string | null; alignment?: LogoPosition | null };
type Sla = { id: string; name: string; code?: string | null };
const LOGO_POSITION_OPTIONS: LogoPosition[] = ["LHS", "RHS", "BLHS", "BRHS"];

type Entry = {
  creativeId: string;
  channelId: string;
  selected: boolean;
  slaId?: string | null;
  locked?: boolean;
};

type PlannerData = {
  creatives: Creative[];
  destinations: Destination[];
  channels: Channel[];
  slas: Sla[];
  entries: Entry[];
};

type SelectedPlannerRow = {
  creative: Creative;
  channel: Channel;
  destinationName: string;
  logoPosition: string;
  slaName: string;
  selectedKey: string;
  locked: boolean;
};

function keyOf(creativeId: string, channelId: string) {
  return `${creativeId}::${channelId}`;
}

function downloadBlob(filename: string, blob: Blob) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  URL.revokeObjectURL(url);
}

function normText(v: any) {
  return String(v ?? "").trim().toLowerCase();
}

function normLookup(v: any) {
  return normText(v).replace(/[^a-z0-9]+/g, "");
}

function normalizeLogoPosition(v: any): LogoPosition | "" {
  const raw = String(v ?? "").trim().toUpperCase();
  return raw === "LHS" || raw === "RHS" || raw === "BLHS" || raw === "BRHS" ? raw : "";
}

function channelLogoLabel(channel?: Channel | null) {
  return normalizeLogoPosition(channel?.alignment) || "";
}

function channelDisplayName(channel?: Channel | null) {
  if (!channel) return "";
  return channel.name;
}

function channelMetaLabel(channel?: Channel | null) {
  const pos = channelLogoLabel(channel);
  return pos ? `Logo: ${pos}` : "";
}

function destinationReceiverLabel(destination?: Destination | null) {
  if (!destination) return "";
  const parts = [String(destination.receiverAccountName || "").trim(), String(destination.receiverCategory || "").trim()].filter(Boolean);
  return parts.length ? `Receiver: ${parts.join(" • ")}` : "";
}

function slaChipLabel(sla?: Sla | null) {
  const code = String(sla?.code ?? "").trim();
  if (code) return code;
  const name = String(sla?.name ?? "").trim();
  return name || "SLA";
}

function slaChipTitle(sla?: Sla | null) {
  const code = String(sla?.code ?? "").trim();
  const name = String(sla?.name ?? "").trim();
  if (code && name && code !== name) return `${code} — ${name}`;
  return code || name || "SLA";
}

function splitMultiValue(v: any) {
  return String(v ?? "")
    .split(/[;,\n]+/)
    .map((part) => part.trim())
    .filter(Boolean);
}

function isSelectedImportCell(v: any) {
  const n = normText(v);
  return n === "yes" || n === "y" || n === "true" || n === "1" || n === "x" || n === "selected";
}

function findImportSheet(wb: XLSX.WorkBook) {
  const skipSheet = (name: string) => {
    const n = normLookup(name);
    return (
      n === "readme" ||
      n === "howtofill" ||
      n === "instructions" ||
      n.startsWith("list") ||
      n.startsWith("reference") ||
      n.startsWith("lookup")
    );
  };

  const getSheetScore = (name: string) => {
    const n = normLookup(name);
    if (n.includes("plannerinput")) return 140;
    if (n.includes("matrixinput")) return 135;
    if (n.includes("easyinput")) return 120;
    if (n.includes("selection")) return 110;
    if (n === "planner" || n.startsWith("planner")) return 100;
    if (n.includes("matrix")) return 95;
    if (n.includes("example")) return 80;
    if (n.includes("destination")) return 70;
    return 10;
  };

  const buildRowsFromHeader = (matrix: any[][], headerRowIndex: number) => {
    const rawHeaders = (matrix[headerRowIndex] || []).map((value) => String(value ?? "").trim());
    const headers = rawHeaders.map((header, idx) => header || `__col_${idx + 1}`);
    const rows: Record<string, any>[] = [];

    for (let rowIdx = headerRowIndex + 1; rowIdx < matrix.length; rowIdx += 1) {
      const values = matrix[rowIdx] || [];
      if (!values.some((value) => normText(value))) continue;

      const row: Record<string, any> = {};
      headers.forEach((header, colIdx) => {
        row[header] = values[colIdx] ?? "";
      });
      rows.push(row);
    }

    return { headers: rawHeaders, rows };
  };

  const controlHeaders = new Set([
    "destination",
    "destinationid",
    "channel",
    "channelid",
    "logoposition",
    "alignment",
    "sla",
    "slaid",
    "defaultsla",
    "notes",
    "action",
    "status",
    "scope",
    "selected",
    "select",
    "include",
  ]);

  const candidates: Array<{ sheetName: string; headers: string[]; rows: Record<string, any>[]; legacyMatrix: boolean; score: number }> = [];

  for (const sheetName of wb.SheetNames) {
    if (skipSheet(sheetName)) continue;

    const sheet = wb.Sheets[sheetName];
    if (!sheet) continue;

    const matrix = XLSX.utils.sheet_to_json<any[]>(sheet, { header: 1, defval: "", raw: false });
    if (!matrix.length) continue;

    for (let headerRowIndex = 0; headerRowIndex < Math.min(matrix.length, 25); headerRowIndex += 1) {
      const rawHeaders = (matrix[headerRowIndex] || []).map((value) => String(value ?? "").trim());
      const normalizedHeaders = rawHeaders.map((header) => normLookup(header)).filter(Boolean);
      if (!normalizedHeaders.length) continue;

      const hasLegacyDestination = normalizedHeaders.includes("destination") || normalizedHeaders.includes("destinationid");
      const hasLegacyChannel = normalizedHeaders.includes("channel") || normalizedHeaders.includes("channelid");
      const hasLegacySla = normalizedHeaders.includes("sla") || normalizedHeaders.includes("slaid") || normalizedHeaders.includes("defaultsla");
      const hasEasyAction = normalizedHeaders.includes("action") || normalizedHeaders.includes("selected") || normalizedHeaders.includes("select") || normalizedHeaders.includes("include");
      const hasEasyCreative =
        normalizedHeaders.includes("creative") ||
        normalizedHeaders.includes("creativeid") ||
        normalizedHeaders.includes("valid");
      const hasEasyTarget = hasLegacyDestination || hasLegacyChannel;
      const hasEasySla = hasLegacySla;

      const extraHeaders = normalizedHeaders.filter((header) => !controlHeaders.has(header));
      const easyFormat = hasEasyAction && hasEasyCreative && hasEasyTarget && hasEasySla;
      const legacyFormat = hasLegacyDestination && hasLegacyChannel && hasLegacySla && extraHeaders.length > 0 && !easyFormat;

      if (!easyFormat && !legacyFormat) continue;

      const parsed = buildRowsFromHeader(matrix, headerRowIndex);
      candidates.push({
        sheetName,
        headers: parsed.headers,
        rows: parsed.rows,
        legacyMatrix: legacyFormat,
        score: getSheetScore(sheetName) + (25 - headerRowIndex) + (legacyFormat ? 5 : 0),
      });
      break;
    }
  }

  if (!candidates.length) return null;
  candidates.sort((a, b) => b.score - a.score);
  return candidates[0];
}

export function PlannerPage() {
  const { id = "" } = useParams();
  const { wf, reload } = useOutletContext<OutletCtx>();
  const nav = useNavigate();

  const [view, setView] = useState<"assistant" | "excel" | "classic" | "tree">(() => {
    try {
      const v = window.localStorage.getItem("planner.view");
      return v === "assistant" || v === "classic" || v === "tree" ? v : "excel";
    } catch {
      return "excel";
    }
  });

  const [creativeSort, setCreativeSort] = useState<"VALID" | "CAPTION" | "NONE">("VALID");
  const [creativeFilterMode, setCreativeFilterMode] = useState<"VALID" | "CAPTION" | "BOTH">("BOTH");
  const [creativeFilterText, setCreativeFilterText] = useState("");
  const [treeModalDestId, setTreeModalDestId] = useState<string | null>(null);
  const [expandedTreeChannels, setExpandedTreeChannels] = useState<Record<string, boolean>>({});

  const [me, setMe] = useState<MeResponse | null>(null);

  const [busy, setBusy] = useState(false);
  const [localErr, setLocalErr] = useState("");
  const [qcGateOk, setQcGateOk] = useState<boolean | null>(null);

  const [savedFlash, setSavedFlash] = useState(false);
  const [initialSelectionCount, setInitialSelectionCount] = useState<number | null>(null);

  // planner data
  const [data, setData] = useState<PlannerData | null>(null);
  const [dirty, setDirty] = useState(false);

  // filter
  const [destFilter, setDestFilter] = useState<"ALL" | "USED" | "UNUSED">("ALL");
  const [q, setQ] = useState("");
  const [expanded, setExpanded] = useState<Record<string, boolean>>({});

  const [editSlaKey, setEditSlaKey] = useState<string | null>(null);
  const [logoBusyChannelIds, setLogoBusyChannelIds] = useState<Record<string, boolean>>({});
  const [assistantCreativeQuery, setAssistantCreativeQuery] = useState("");
  const [assistantChannelQuery, setAssistantChannelQuery] = useState("");
  const [assistantSelectedCreativeIds, setAssistantSelectedCreativeIds] = useState<Record<string, boolean>>({});
  const [assistantSelectedChannelIds, setAssistantSelectedChannelIds] = useState<Record<string, boolean>>({});
  const [assistantSlaId, setAssistantSlaId] = useState("");
  const [assistantFlash, setAssistantFlash] = useState("");
  const [assistantShowSelectedCreativesOnly, setAssistantShowSelectedCreativesOnly] = useState(false);
  const [assistantShowSelectedChannelsOnly, setAssistantShowSelectedChannelsOnly] = useState(false);
  const [assistantExpandedDestinations, setAssistantExpandedDestinations] = useState<Record<string, boolean>>({});

  const disabledCommit = !wf?.actions?.canCommit || busy || qcGateOk === false;
  const commitReasons = wf?.actions?.commitReasons || [];

  async function loadPlanner() {
    setLocalErr("");
    try {
      const d = await api<PlannerData>(`/projects/${id}/planner`);
      setData(d);
      setDirty(false);

      // remember whether this project started with no selections (for Select All/Unselect All)
      const selCount = d.entries.filter((e) => e.selected).length;
      setInitialSelectionCount((prev) => (prev === null ? selCount : prev));

      // expand USED destinations by default (first load)
      setExpanded((prev) => {
        if (Object.keys(prev).length) return prev;
        const used = new Set<string>();
        for (const e of d.entries) {
          if (!e.selected) continue;
          const ch = d.channels.find((c) => c.id === e.channelId);
          used.add(ch?.destinationId || "UNASSIGNED");
        }
        const next: Record<string, boolean> = {};
        for (const destId of used) next[destId] = true;
        // if nothing used, expand first destination (if any)
        if (!Object.keys(next).length) {
          const first = d.destinations[0]?.id;
          if (first) next[first] = true;
          const hasUnassigned = d.channels.some((c) => !c.destinationId);
          if (!first && hasUnassigned) next["UNASSIGNED"] = true;
        }
        return next;
      });
    await reload().catch(() => undefined);
    } catch (e: any) {
      setLocalErr((e as ApiError)?.message || "Failed to load planner");
    }
  }

  useEffect(() => {
    loadPlanner();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  useEffect(() => {
    getMe().then(setMe).catch(() => setMe(null));
  }, []);

  useEffect(() => {
    try {
      window.localStorage.setItem("planner.view", view);
    } catch {
      // ignore
    }
  }, [view]);

  useEffect(() => {
    if (!assistantSlaId && data?.slas?.[0]?.id) setAssistantSlaId(data.slas[0].id);
  }, [data, assistantSlaId]);

  useEffect(() => {
    if (!treeModalDestId) return;
    const onKey = (ev: KeyboardEvent) => {
      if (ev.key === "Escape") setTreeModalDestId(null);
    };
    const prev = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    setExpandedTreeChannels({});
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = prev;
      window.removeEventListener("keydown", onKey);
    };
  }, [treeModalDestId]);

  useEffect(() => {
    try {
      window.localStorage.setItem("planner.creativeSort", creativeSort);
    } catch {
      // ignore
    }
  }, [creativeSort]);

  useEffect(() => {
    // try to restore sort preference
    try {
      const s = window.localStorage.getItem("planner.creativeSort") as any;
      if (s === "VALID" || s === "CAPTION" || s === "NONE") setCreativeSort(s);
    } catch {
      // ignore
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const slasById = useMemo(() => {
    const m = new Map<string, Sla>();
    (data?.slas || []).forEach((s) => m.set(s.id, s));
    return m;
  }, [data]);

  const creativeCollator = useMemo(
    () => new Intl.Collator(undefined, { numeric: true, sensitivity: "base" }),
    [],
  );

  function compareCreatives(a: Creative, b: Creative, mode: "VALID" | "CAPTION" | "NONE") {
    if (mode === "NONE") return 0;

    if (mode === "CAPTION") {
      const aCaption = (a.caption || "").trim();
      const bCaption = (b.caption || "").trim();
      const byCaption = creativeCollator.compare(aCaption || a.valid || a.id, bCaption || b.valid || b.id);
      if (byCaption !== 0) return byCaption;
      return creativeCollator.compare((a.valid || a.id).trim(), (b.valid || b.id).trim());
    }

    const aValid = (a.valid || "").trim();
    const bValid = (b.valid || "").trim();
    const byValid = creativeCollator.compare(aValid || a.caption || a.id, bValid || b.caption || b.id);
    if (byValid !== 0) return byValid;
    return creativeCollator.compare((a.caption || a.id).trim(), (b.caption || b.id).trim());
  }

  const creativesSorted = useMemo(() => {
    const list = [...(data?.creatives || [])];
    if (creativeSort === "NONE") return list;
    list.sort((a, b) => compareCreatives(a, b, creativeSort));
    return list;
  }, [data, creativeSort, creativeCollator]);

  const creativeFilterNorm = creativeFilterText.trim().toLowerCase();

  const visibleCreatives = useMemo(() => {
    if (!creativeFilterNorm) return creativesSorted;
    return creativesSorted.filter((cr) => {
      const valid = (cr.valid || "").toLowerCase();
      const caption = (cr.caption || "").toLowerCase();
      if (creativeFilterMode === "VALID") return valid.includes(creativeFilterNorm);
      if (creativeFilterMode === "CAPTION") return caption.includes(creativeFilterNorm);
      return valid.includes(creativeFilterNorm) || caption.includes(creativeFilterNorm);
    });
  }, [creativesSorted, creativeFilterMode, creativeFilterNorm]);

  const visibleCreativeIds = useMemo(() => new Set(visibleCreatives.map((cr) => cr.id)), [visibleCreatives]);

  const destinationsById = useMemo(() => {
    const m = new Map<string, Destination>();
    (data?.destinations || []).forEach((d) => m.set(d.id, d));
    return m;
  }, [data]);

  const channelsByDest = useMemo(() => {
    const m = new Map<string, Channel[]>();
    for (const c of data?.channels || []) {
      const dId = c.destinationId || "UNASSIGNED";
      const arr = m.get(dId) || [];
      arr.push(c);
      m.set(dId, arr);
    }
    for (const [k, arr] of m.entries()) {
      arr.sort((a, b) => a.name.localeCompare(b.name));
      m.set(k, arr);
    }
    return m;
  }, [data]);

  const entryMap = useMemo(() => {
    const m = new Map<string, Entry>();
    (data?.entries || []).forEach((e) => m.set(keyOf(e.creativeId, e.channelId), e));
    return m;
  }, [data]);


  const usedDestIds = useMemo(() => {
    const used = new Set<string>();
    for (const e of data?.entries || []) {
      if (!e.selected) continue;
      const ch = data?.channels.find((c) => c.id === e.channelId);
      const did = ch?.destinationId || "UNASSIGNED";
      used.add(did);
    }
    return used;
  }, [data]);

  const destinationList = useMemo(() => {
    const list: Destination[] = [];
    for (const d of data?.destinations || []) {
      list.push({
        id: d.id,
        name: d.name,
        category: d.category ?? null,
        receiverAccountId: d.receiverAccountId ?? null,
        receiverAccountName: d.receiverAccountName ?? null,
        receiverCategory: d.receiverCategory ?? null,
      });
    }
    // ensure UNASSIGNED exists if any channels are unassigned
    const hasUnassigned = (data?.channels || []).some((c) => !c.destinationId);
    if (hasUnassigned) list.push({ id: "UNASSIGNED", name: "UNASSIGNED" });
    list.sort((a, b) => a.name.localeCompare(b.name));
    return list;
  }, [data]);

  const visibleDestinations = useMemo(() => {
    if (destFilter === "ALL") return destinationList;
    if (destFilter === "USED") return destinationList.filter((d) => usedDestIds.has(d.id));
    return destinationList.filter((d) => !usedDestIds.has(d.id));
  }, [destFilter, destinationList, usedDestIds]);

  const qNorm = q.trim().toLowerCase();
  const filteredDestinations = useMemo(() => {
    if (!data) return [] as Destination[];
    if (!qNorm) return visibleDestinations;

    // destination matches by name, receiver context, OR any of its channels match
    const keep = new Set<string>();
    for (const d of visibleDestinations) {
      const hay = [d.name, d.receiverAccountName, d.receiverCategory, d.category].filter(Boolean).join(" ").toLowerCase();
      if (hay.includes(qNorm)) keep.add(d.id);
    }
    for (const ch of data.channels) {
      const did = ch.destinationId || "UNASSIGNED";
      if (!visibleDestinations.some((d) => d.id === did)) continue;
      if (ch.name.toLowerCase().includes(qNorm)) keep.add(did);
    }
    return visibleDestinations.filter((d) => keep.has(d.id));
  }, [data, qNorm, visibleDestinations]);

  const visibleChannels = useMemo(() => {
    if (!data) return [] as Channel[];
    const out: Channel[] = [];
    const allowedDestIds = new Set(filteredDestinations.map((d) => d.id));
    for (const ch of data.channels) {
      const did = ch.destinationId || "UNASSIGNED";
      if (!allowedDestIds.has(did)) continue;
      if (!expanded[did]) continue;
      if (qNorm) {
        const destination = destinationsById.get(did);
        const destinationHay = [destination?.name || "UNASSIGNED", destination?.receiverAccountName, destination?.receiverCategory, destination?.category]
          .filter(Boolean)
          .join(" ")
          .toLowerCase();
        if (!ch.name.toLowerCase().includes(qNorm) && !destinationHay.includes(qNorm)) {
          continue;
        }
      }
      out.push(ch);
    }
    out.sort((a, b) => {
      const ad = a.destinationId || "UNASSIGNED";
      const bd = b.destinationId || "UNASSIGNED";
      if (ad !== bd) {
        const an = ad === "UNASSIGNED" ? "ZZZ" : destinationsById.get(ad)?.name || ad;
        const bn = bd === "UNASSIGNED" ? "ZZZ" : destinationsById.get(bd)?.name || bd;
        return an.localeCompare(bn);
      }
      return a.name.localeCompare(b.name);
    });
    return out;
  }, [data, expanded, filteredDestinations, qNorm, destinationsById]);

  function setCell(creativeId: string, channelId: string, patch: Partial<Entry>) {
    if (!data) return;
    const k = keyOf(creativeId, channelId);
    const cur: Entry = entryMap.get(k) ?? { creativeId, channelId, selected: false, slaId: null, locked: false };
    if (cur.locked) return;

    const next: Entry = { ...cur, ...patch };

    // if selecting and no SLA, auto pick first SLA
    if (next.selected && (!next.slaId || next.slaId === null)) {
      next.slaId = data.slas[0]?.id || null;
    }
    // if unselecting, clear SLA
    if (!next.selected) next.slaId = null;

    const nextEntries = (data.entries || []).filter((e) => keyOf(e.creativeId, e.channelId) !== k);
    nextEntries.push(next);

    setData({ ...data, entries: nextEntries });
    setDirty(true);
  }

  async function updateChannelLogoPosition(channelId: string, nextAlignment: "" | LogoPosition) {
    const normalized = normalizeLogoPosition(nextAlignment);
    setLogoBusyChannelIds((prev) => ({ ...prev, [channelId]: true }));
    setLocalErr("");
    try {
      await api(`/masters/channels/${channelId}`, {
        method: "PATCH",
        body: JSON.stringify({ alignment: normalized || null }),
      });
      setData((prev) =>
        prev
          ? {
              ...prev,
              channels: prev.channels.map((channel) =>
                channel.id === channelId ? { ...channel, alignment: normalized || null } : channel,
              ),
            }
          : prev,
      );
    } catch (e: any) {
      setLocalErr((e as ApiError)?.message || "Failed to update logo position");
    } finally {
      setLogoBusyChannelIds((prev) => {
        const next = { ...prev };
        delete next[channelId];
        return next;
      });
    }
  }

  async function savePlanner() {
    if (!data) return;
    setBusy(true);
    setLocalErr("");
    try {
      await api(`/projects/${id}/planner`, {
        method: "PUT",
        body: JSON.stringify({
          entries: data.entries.map((e) => ({
            creativeId: e.creativeId,
            channelId: e.channelId,
            selected: e.selected,
            slaId: e.slaId ?? null,
          })),
        }),
      });
      await loadPlanner();
      setDirty(false);
      setSavedFlash(true);
      window.setTimeout(() => setSavedFlash(false), 1500);
    } catch (e: any) {
      const err = e as ApiError;
      setLocalErr(err?.message || "Save failed");
    } finally {
      setBusy(false);
    }
  }

  async function commit() {
    setBusy(true);
    setLocalErr("");
    try {
      // UX: users often change planner matrix and hit Commit immediately.
      // If there are unsaved changes, persist them first so commit sees the latest selections.
      if (data && dirty) {
        await api(`/projects/${id}/planner`, {
          method: "PUT",
          body: JSON.stringify({
            entries: data.entries.map((e) => ({
              creativeId: e.creativeId,
              channelId: e.channelId,
              selected: e.selected,
              slaId: e.slaId ?? null,
            })),
          }),
        });
        await loadPlanner();
        setDirty(false);
      }

      await api(`/projects/${id}/commit`, {
        method: "POST",
        body: JSON.stringify({ onlyUnsent: true }),
      });
      await reload();
    } catch (e: any) {
      const err = e as ApiError;
      const msg = err?.message || "Commit failed";
      const extra =
        err?.data?.reasons?.length
          ? " — " + err.data.reasons.map((r: any) => r.message).join("; ")
          : "";
      setLocalErr(msg + extra);
    } finally {
      setBusy(false);
    }
  }

  function exportExcel() {
    if (!data) return;

    // one row per selection
    const rows = data.entries
      .filter((e) => e.selected)
      .map((e) => {
        const cr = data.creatives.find((c) => c.id === e.creativeId);
        const ch = data.channels.find((c) => c.id === e.channelId);
        const destName =
          ch?.destinationId ? destinationsById.get(ch.destinationId)?.name : "UNASSIGNED";
        return {
          CreativeId: e.creativeId,
          VALID: cr?.valid || "",
          ChannelId: e.channelId,
          Channel: ch?.name || "",
          LogoPosition: ch?.alignment || "",
          DestinationId: ch?.destinationId || "UNASSIGNED",
          Destination: destName || "UNASSIGNED",
          SlaId: e.slaId || "",
          SLA: e.slaId ? slasById.get(e.slaId)?.name || "" : "",
        };
      });

    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Planner");
    const out = XLSX.write(wb, { bookType: "xlsx", type: "array" });
    downloadBlob(`planner_${id}.xlsx`, new Blob([out], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" }));
  }

  function downloadExampleTemplate() {
    const codeLabel = getCreativeCodeLabel(me);
    const creatives = [...(data?.creatives || [])];
    const channels = [...(data?.channels || [])];
    const slas = [...(data?.slas || [])];
    const defaultSla = slas[0]?.name || "Immediate";
    const defaultSlaId = slas[0]?.id || "";

    const plannerHeader = [
      "Destination",
      "Channel",
      "LogoPosition",
      "SLA",
      ...creatives.map((creative) => creative.valid || creative.id),
      "__DestinationId",
      "__ChannelId",
      "__SlaId",
    ];
    const plannerRows: any[][] = [];

    if (channels.length) {
      for (const channel of channels) {
        const destinationName = channel.destinationId
          ? destinationsById.get(channel.destinationId)?.name || "UNASSIGNED"
          : "UNASSIGNED";
        plannerRows.push([
          destinationName,
          channel.name || "",
          channel.alignment || "",
          defaultSla,
          ...creatives.map(() => ""),
          channel.destinationId || "UNASSIGNED",
          channel.id || "",
          defaultSlaId,
        ]);
      }
    } else {
      plannerRows.push([
        data?.destinations?.[0]?.name || "Example Destination",
        "Example Channel",
        "",
        defaultSla,
        ...creatives.map((_, idx) => (idx === 0 ? "Yes" : "")),
        data?.destinations?.[0]?.id || "",
        "",
        defaultSlaId,
      ]);
    }

    const plannerInputRows = [plannerHeader, ...plannerRows];

    const instructionsRows = [
      ["eSendIT Planner + Commit Matrix Template"],
      ["This is the client-friendly Yes/No format."],
      [],
      ["How to fill"],
      ["1", "Use only the Planner_Input sheet for upload."],
      ["2", "Each row = one destination + channel + logo position + SLA route."],
      [`3`, `The columns after SLA are the ${codeLabel}s / creative columns.`],
      ["4", "Type Yes for required creatives. Type No or leave blank for not required creatives."],
      ["5", "Keep Destination, Channel, LogoPosition and SLA names exactly as given in the reference sheets."],
      ["6", "Do not rename sheet names or column headers."],
      ["7", "The workbook includes hidden system ID columns. Do not unhide or edit them."],
      [],
      ["Required columns"],
      ["Destination", "Destination name"],
      ["Channel", "Channel name"],
      ["LogoPosition", "Optional. LHS / RHS / BLHS / BRHS"],
      ["SLA", "SLA name"],
      [`${codeLabel} columns`, "Yes / No per creative"],
    ];

    const validReferenceRows = [
      [codeLabel, "CreativeId", "Caption", "Format", "Languages", "Duration"],
      ...creatives.map((creative) => [
        creative.valid || "",
        creative.id,
        creative.caption || "",
        creative.format || "",
        (creative.languages || []).join(", "),
        creative.duration || "",
      ]),
    ];

    const routeReferenceRows = [
      ["Destination", "Channel", "LogoPosition", "Default SLA"],
      ...(channels.length
        ? channels.map((channel) => [
            channel.destinationId ? destinationsById.get(channel.destinationId)?.name || "UNASSIGNED" : "UNASSIGNED",
            channel.name || "",
            channel.alignment || "",
            defaultSla,
          ])
        : [[data?.destinations?.[0]?.name || "Example Destination", "Example Channel", "", defaultSla]]),
    ];

    const slaReferenceRows = [
      ["SLA"],
      ...(slas.length ? slas.map((sla) => [sla.name || ""]) : [[defaultSla]]),
    ];

    const wb = XLSX.utils.book_new();
    const plannerWs = XLSX.utils.aoa_to_sheet(plannerInputRows);
    const instructionsWs = XLSX.utils.aoa_to_sheet(instructionsRows);
    const validsWs = XLSX.utils.aoa_to_sheet(validReferenceRows);
    const routesWs = XLSX.utils.aoa_to_sheet(routeReferenceRows);
    const slasWs = XLSX.utils.aoa_to_sheet(slaReferenceRows);

    plannerWs["!cols"] = [
      { wch: 34 },
      { wch: 28 },
      { wch: 16 },
      { wch: 18 },
      ...creatives.map(() => ({ wch: 22 })),
      { hidden: true, wch: 2 },
      { hidden: true, wch: 2 },
      { hidden: true, wch: 2 },
    ];
    instructionsWs["!cols"] = [{ wch: 22 }, { wch: 96 }];
    validsWs["!cols"] = [
      { wch: 34 },
      { wch: 20 },
      { wch: 36 },
      { wch: 14 },
      { wch: 22 },
      { wch: 14 },
    ];
    routesWs["!cols"] = [{ wch: 34 }, { wch: 28 }, { wch: 16 }, { wch: 18 }];
    slasWs["!cols"] = [{ wch: 24 }];

    XLSX.utils.book_append_sheet(wb, plannerWs, "Planner_Input");
    XLSX.utils.book_append_sheet(wb, instructionsWs, "Instructions");
    XLSX.utils.book_append_sheet(wb, validsWs, "Reference_Valids");
    XLSX.utils.book_append_sheet(wb, routesWs, "Reference_Routes");
    XLSX.utils.book_append_sheet(wb, slasWs, "Reference_SLAs");

    const out = XLSX.write(wb, { bookType: "xlsx", type: "array" });
    downloadBlob(
      `planner_commit_template_${id || "example"}.xlsx`,
      new Blob([out], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" }),
    );
  }

  async function importExcel(file: File) {
    if (!data) return;
    setBusy(true);
    setLocalErr("");
    setAssistantFlash("");
    try {
      const buf = await file.arrayBuffer();
      const wb = XLSX.read(buf, { type: "array" });
      const detected = findImportSheet(wb);

      if (!detected || !detected.rows.length) {
        throw new Error("No supported planner sheet found");
      }

      const { sheetName, rows, headers, legacyMatrix } = detected;

      const creativeByLookup = new Map<string, Creative>();
      for (const creative of data.creatives) {
        [creative.id, creative.valid, creative.caption, (creative as any).name]
          .filter(Boolean)
          .forEach((value) => creativeByLookup.set(normLookup(value), creative));
      }

      const destinationByLookup = new Map<string, string>();
      for (const destination of data.destinations) {
        destinationByLookup.set(normLookup(destination.id), destination.id);
        destinationByLookup.set(normLookup(destination.name), destination.id);
      }
      if ((data.channels || []).some((channel) => !channel.destinationId)) destinationByLookup.set("unassigned", "UNASSIGNED");

      const channelById = new Map<string, Channel>();
      const channelsByName = new Map<string, Channel[]>();
      const channelsByDestAndName = new Map<string, Channel[]>();
      const channelsByDestAndNameAndLogo = new Map<string, Channel>();
      for (const channel of data.channels) {
        channelById.set(normLookup(channel.id), channel);
        const byName = channelsByName.get(normLookup(channel.name)) || [];
        byName.push(channel);
        channelsByName.set(normLookup(channel.name), byName);
        const destId = channel.destinationId || "UNASSIGNED";
        const byDestAndName = channelsByDestAndName.get(`${destId}::${normLookup(channel.name)}`) || [];
        byDestAndName.push(channel);
        channelsByDestAndName.set(`${destId}::${normLookup(channel.name)}`, byDestAndName);
        const logo = normalizeLogoPosition(channel.alignment);
        if (logo) channelsByDestAndNameAndLogo.set(`${destId}::${normLookup(channel.name)}::${logo}`, channel);
      }

      const slaByLookup = new Map<string, string>();
      for (const sla of data.slas) {
        slaByLookup.set(normLookup(sla.id), sla.id);
        slaByLookup.set(normLookup(sla.name), sla.id);
        if (sla.code) slaByLookup.set(normLookup(sla.code), sla.id);
      }

      const nextEntries = [...data.entries];
      let applied = 0;
      let skipped = 0;
      let locked = 0;
      const channelAlignmentUpdates = new Map<string, LogoPosition>();

      const upsertEntry = (creative: Creative | null, channel: Channel | null, selected: boolean, rawSla: any) => {
        if (!creative || !channel) {
          skipped += 1;
          return;
        }

        const slaId = rawSla ? slaByLookup.get(normLookup(rawSla)) || String(rawSla) : null;
        const k = keyOf(creative.id, channel.id);
        const idx = nextEntries.findIndex((entry) => keyOf(entry.creativeId, entry.channelId) === k);
        const current: Entry = idx >= 0
          ? nextEntries[idx]
          : entryMap.get(k) ?? { creativeId: creative.id, channelId: channel.id, selected: false, slaId: null, locked: false };

        if (current.locked) {
          locked += 1;
          return;
        }

        const nextEntry: Entry = selected
          ? {
              ...current,
              selected: true,
              slaId: slaId || current.slaId || data.slas[0]?.id || null,
            }
          : {
              ...current,
              selected: false,
              slaId: null,
            };

        if (idx >= 0) nextEntries[idx] = nextEntry;
        else nextEntries.push(nextEntry);
        applied += 1;
      };

      const resolveCreative = (raw: any) => creativeByLookup.get(normLookup(raw)) || null;
      const resolveDestinationId = (row: any) => {
        return destinationByLookup.get(normLookup(
          row.__DestinationId ||
          row.__destinationId ||
          row.DestinationId ||
          row.destinationId ||
          row.Destination ||
          row.destination,
        )) || null;
      };
      const resolveSlaValue = (row: any) => (
        row.__SlaId ||
        row.__slaId ||
        row.SlaId ||
        row.SLA ||
        row.Sla ||
        row.sla ||
        row["Default SLA"] ||
        row.defaultSla
      );
      const resolveChannelsForRow = (row: any) => {
        const destinationId = resolveDestinationId(row);
        const logoPosition = normalizeLogoPosition(
          row.LogoPosition || row.logoPosition || row["Logo Position"] || row["logo position"] || row.Alignment || row.alignment || row.LogPosition || row.logPosition || row["Log Position"] || row["log position"],
        );
        const channelTokens = [
          ...splitMultiValue(row.__ChannelId || row.__channelId || row.ChannelId || row.channelId),
          ...splitMultiValue(row.Channel || row.channel),
        ];

        if (channelTokens.length) {
          const matched: Channel[] = [];
          for (const token of channelTokens) {
            const byId = channelById.get(normLookup(token));
            if (byId) {
              matched.push(byId);
              continue;
            }

            if (destinationId) {
              const byDest = channelsByDestAndName.get(`${destinationId}::${normLookup(token)}`) || [];
              if (byDest.length === 1) {
                matched.push(byDest[0]);
                continue;
              }
              if (byDest.length > 1 && logoPosition) {
                const byDestAndLogo = channelsByDestAndNameAndLogo.get(`${destinationId}::${normLookup(token)}::${logoPosition}`);
                if (byDestAndLogo) {
                  matched.push(byDestAndLogo);
                  continue;
                }
              }
              if (byDest[0]) {
                matched.push(byDest[0]);
                continue;
              }
            }

            const byName = channelsByName.get(normLookup(token)) || [];
            if (byName.length === 1) {
              matched.push(byName[0]);
              continue;
            }
            if (destinationId && byName.length > 1) {
              const inDest = byName.filter((channel) => (channel.destinationId || "UNASSIGNED") === destinationId);
              if (inDest.length === 1) {
                matched.push(inDest[0]);
                continue;
              }
              if (inDest.length > 1 && logoPosition) {
                const exactInDestWithLogo = inDest.find((channel) => normalizeLogoPosition(channel.alignment) === logoPosition);
                if (exactInDestWithLogo) {
                  matched.push(exactInDestWithLogo);
                  continue;
                }
              }
              if (inDest[0]) {
                matched.push(inDest[0]);
                continue;
              }
            }
            if (logoPosition) {
              const byNameWithLogo = byName.find((channel) => normalizeLogoPosition(channel.alignment) === logoPosition);
              if (byNameWithLogo) {
                matched.push(byNameWithLogo);
                continue;
              }
            }
            if (byName[0]) matched.push(byName[0]);
          }
          return Array.from(new Map(matched.map((channel) => [channel.id, channel])).values());
        }

        if (destinationId) {
          return [...(channelsByDest.get(destinationId) || [])];
        }
        return [] as Channel[];
      };

      if (legacyMatrix) {
        const controlKeys = new Set(["destination", "destinationid", "sla", "slaid", "defaultsla", "channel", "channelid", "notes", "action", "logoposition", "alignment", "scope", "status"]);
        const creativeHeaders = headers.filter((header) => !!normLookup(header) && !controlKeys.has(normLookup(header)));

        for (const row of rows) {
          const destinationId = resolveDestinationId(row);
          const logoPosition = normalizeLogoPosition(
            row.LogoPosition || row.logoPosition || row["Logo Position"] || row["logo position"] || row.Alignment || row.alignment || row.LogPosition || row.logPosition || row["Log Position"] || row["log position"],
          );
          const resolvedChannels = resolveChannelsForRow({ ...row, DestinationId: destinationId || row.DestinationId, Destination: row.Destination, Channel: row.Channel, ChannelId: row.ChannelId });
          if (!resolvedChannels.length) {
            skipped += 1;
            continue;
          }
          let rowApplied = false;
          for (const header of creativeHeaders) {
            if (!isSelectedImportCell(row[header])) continue;
            const creative = resolveCreative(header);
            if (!creative) continue;
            for (const channel of resolvedChannels) {
              upsertEntry(creative, channel, true, resolveSlaValue(row));
              if (logoPosition && normalizeLogoPosition(channel.alignment) !== logoPosition) {
                channelAlignmentUpdates.set(channel.id, logoPosition);
              }
              rowApplied = true;
            }
          }
          if (!rowApplied) skipped += 1;
        }
      } else {
        for (const row of rows) {
          const actionValue = normText(row.Action || row.action);
          const selected = !(actionValue === "remove" || actionValue === "delete" || actionValue === "unselect" || actionValue === "clear" || actionValue === "no");
          const creativeTokens = [
            ...splitMultiValue(row.CreativeId || row.creativeId),
            ...splitMultiValue(row.VALID || row.valid),
            ...splitMultiValue(row.Creative || row.creative),
            ...splitMultiValue(row.Caption || row.caption),
          ];
          const creatives: Creative[] = [];
          for (const token of creativeTokens) {
            const creative = resolveCreative(token);
            if (creative && !creatives.some((existing) => existing.id === creative.id)) creatives.push(creative);
          }
          const channels = resolveChannelsForRow(row);
          const logoPosition = normalizeLogoPosition(
            row.LogoPosition || row.logoPosition || row["Logo Position"] || row["logo position"] || row.Alignment || row.alignment || row.LogPosition || row.logPosition || row["Log Position"] || row["log position"],
          );

          if (!creatives.length || !channels.length) {
            skipped += 1;
            continue;
          }

          for (const creative of creatives) {
            for (const channel of channels) {
              upsertEntry(creative, channel, selected, resolveSlaValue(row));
              if (logoPosition && normalizeLogoPosition(channel.alignment) !== logoPosition) {
                channelAlignmentUpdates.set(channel.id, logoPosition);
              }
            }
          }
        }
      }

      let logoUpdated = 0;
      if (channelAlignmentUpdates.size) {
        const logoResults = await Promise.allSettled(
          Array.from(channelAlignmentUpdates.entries()).map(([channelId, alignment]) =>
            api(`/masters/channels/${channelId}`, {
              method: "PATCH",
              body: JSON.stringify({ alignment: alignment || null }),
            }).then(() => ({ channelId, alignment })),
          ),
        );
        for (const result of logoResults) {
          if (result.status !== "fulfilled") continue;
          const { channelId, alignment } = result.value;
          const idx = data.channels.findIndex((channel) => channel.id === channelId);
          if (idx >= 0) {
            data.channels[idx] = { ...data.channels[idx], alignment };
            logoUpdated += 1;
          }
        }
      }

      setData({ ...data, entries: nextEntries, channels: [...data.channels] });
      setDirty(true);
      const formatLabel = legacyMatrix ? "planner matrix" : "easy planner";
      if (!applied) {
        setLocalErr("Import found the sheet, but no rows matched the current planner data. Please use the latest downloaded template from this project.");
      }
      setAssistantFlash(`Imported ${rows.length} row${rows.length === 1 ? "" : "s"} from ${sheetName} (${formatLabel}) • applied ${applied} route${applied === 1 ? "" : "s"}${logoUpdated ? ` • updated ${logoUpdated} logo position${logoUpdated === 1 ? "" : "s"}` : ""}${locked ? ` • skipped ${locked} locked` : ""}${skipped ? ` • skipped ${skipped} unmatched` : ""}`);
    } catch (e: any) {
      const msg = String(e?.message || "");
      setLocalErr(msg === "No supported planner sheet found" ? "Import failed (no supported planner sheet found in the workbook)" : "Import failed (check Excel columns or template format)");
    } finally {
      setBusy(false);
    }
  }

  const fileInputId = "planner-import";
  const selectedPlannerRows = useMemo(() => {
    if (!data) return [] as SelectedPlannerRow[];
    const rows: SelectedPlannerRow[] = [];
    for (const e of data.entries) {
      if (!e.selected || !visibleCreativeIds.has(e.creativeId)) continue;
      const creative = data.creatives.find((c) => c.id === e.creativeId);
      const channel = data.channels.find((c) => c.id === e.channelId);
      if (!creative || !channel) continue;
      const destinationName = channel.destinationId
        ? destinationsById.get(channel.destinationId)?.name || "UNASSIGNED"
        : "UNASSIGNED";
      const slaName = e.slaId ? slasById.get(e.slaId)?.name || "SLA" : "SLA";
      rows.push({
        creative,
        channel,
        destinationName,
        logoPosition: channelLogoLabel(channel),
        slaName,
        selectedKey: keyOf(creative.id, channel.id),
        locked: !!e.locked,
      });
    }
    return rows.sort((a, b) => {
      const byCreative = compareCreatives(a.creative, b.creative, creativeSort === "NONE" ? "VALID" : creativeSort);
      if (byCreative !== 0) return byCreative;
      const byDestination = creativeCollator.compare(a.destinationName, b.destinationName);
      if (byDestination !== 0) return byDestination;
      return creativeCollator.compare(a.channel.name, b.channel.name);
    });
  }, [data, visibleCreativeIds, destinationsById, slasById, creativeSort, creativeCollator]);


  const selectedTreeByDestination = useMemo(() => {
    const groups = new Map<
      string,
      {
        destinationId: string;
        destinationName: string;
        totalRoutes: number;
        selectedCreatives: Set<string>;
        channels: Map<
          string,
          {
            channel: Channel;
            items: SelectedPlannerRow[];
          }
        >;
      }
    >();

    for (const row of selectedPlannerRows) {
      const destinationId = row.channel.destinationId || "UNASSIGNED";
      const destinationName = row.destinationName || "UNASSIGNED";
      let group = groups.get(destinationId);
      if (!group) {
        group = {
          destinationId,
          destinationName,
          totalRoutes: 0,
          selectedCreatives: new Set<string>(),
          channels: new Map(),
        };
        groups.set(destinationId, group);
      }
      group.totalRoutes += 1;
      group.selectedCreatives.add(row.creative.id);
      const existingChannel = group.channels.get(row.channel.id);
      if (existingChannel) existingChannel.items.push(row);
      else group.channels.set(row.channel.id, { channel: row.channel, items: [row] });
    }

    return Array.from(groups.values())
      .map((group) => ({
        destinationId: group.destinationId,
        destinationName: group.destinationName,
        totalRoutes: group.totalRoutes,
        creativeCount: group.selectedCreatives.size,
        channels: Array.from(group.channels.values())
          .map((channelGroup) => ({
            channel: channelGroup.channel,
            items: [...channelGroup.items].sort((a, b) => {
              const byCreative = compareCreatives(
                a.creative,
                b.creative,
                creativeSort === "NONE" ? "VALID" : creativeSort,
              );
              if (byCreative !== 0) return byCreative;
              return creativeCollator.compare(a.slaName, b.slaName);
            }),
          }))
          .sort((a, b) => creativeCollator.compare(a.channel.name, b.channel.name)),
      }))
      .sort((a, b) => creativeCollator.compare(a.destinationName, b.destinationName));
  }, [selectedPlannerRows, creativeSort, creativeCollator]);

  const activeTreeDestination = useMemo(
    () => selectedTreeByDestination.find((group) => group.destinationId === treeModalDestId) || null,
    [selectedTreeByDestination, treeModalDestId],
  );

  const treeDestinationCards = useMemo(
    () =>
      filteredDestinations.map((destination) => {
        const channels = [...(channelsByDest.get(destination.id) || [])];
        const channelIds = new Set(channels.map((channel) => channel.id));
        const selectedEntries = (data?.entries || []).filter(
          (entry) => entry.selected && channelIds.has(entry.channelId) && visibleCreativeIds.has(entry.creativeId),
        );
        return {
          destinationId: destination.id,
          destinationName: destination.name,
          channelCount: channels.length,
          selectedRoutes: selectedEntries.length,
          selectedCreativeCount: new Set(selectedEntries.map((entry) => entry.creativeId)).size,
          channelPreview: channels.slice(0, 4).map((channel) => channel.name),
        };
      }),
    [filteredDestinations, channelsByDest, data, visibleCreativeIds],
  );

  const activeTreeDestinationCard = useMemo(
    () => treeDestinationCards.find((group) => group.destinationId === treeModalDestId) || null,
    [treeDestinationCards, treeModalDestId],
  );

  const activeTreeChannels = useMemo(() => {
    if (!treeModalDestId) return [] as Channel[];
    return [...(channelsByDest.get(treeModalDestId) || [])].sort((a, b) => creativeCollator.compare(a.name, b.name));
  }, [treeModalDestId, channelsByDest, creativeCollator]);

  const creativeLegendItems = useMemo(
    () =>
      visibleCreatives.map((creative, index) => ({
        creative,
        index: index + 1,
        code: (creative.valid || "").trim() || (creative.caption || "").trim() || creative.id,
        caption: (creative.caption || "").trim(),
      })),
    [visibleCreatives],
  );

  const assistantCreativeQueryNorm = assistantCreativeQuery.trim().toLowerCase();
  const assistantChannelQueryNorm = assistantChannelQuery.trim().toLowerCase();

  const assistantVisibleCreatives = useMemo(() => {
    const baseCreatives = assistantShowSelectedCreativesOnly
      ? visibleCreatives.filter((creative) => assistantSelectedCreativeIds[creative.id])
      : visibleCreatives;

    if (!assistantCreativeQueryNorm) return baseCreatives;
    return baseCreatives.filter((creative) => {
      const hay = [
        creative.valid,
        creative.caption,
        creative.duration,
        creative.format,
        creative.audio,
        ...(creative.languages || []),
      ]
        .filter(Boolean)
        .join(" ")
        .toLowerCase();
      return hay.includes(assistantCreativeQueryNorm);
    });
  }, [visibleCreatives, assistantCreativeQueryNorm, assistantShowSelectedCreativesOnly, assistantSelectedCreativeIds]);

  const assistantDestinationCards = useMemo(() => {
    return destinationList
      .map((destination) => {
        const destinationName = destination.name || "UNASSIGNED";
        const destinationMatches = destinationName.toLowerCase().includes(assistantChannelQueryNorm);
        const channels = (channelsByDest.get(destination.id) || []).filter((channel) => {
          const matchesQuery = !assistantChannelQueryNorm || destinationMatches || channel.name.toLowerCase().includes(assistantChannelQueryNorm);
          const matchesSelection = !assistantShowSelectedChannelsOnly || !!assistantSelectedChannelIds[channel.id];
          return matchesQuery && matchesSelection;
        });
        if ((assistantChannelQueryNorm || assistantShowSelectedChannelsOnly) && !destinationMatches && channels.length === 0) return null;
        const totalChannelCount = (channelsByDest.get(destination.id) || []).length;
        const selectedCount = channels.filter((channel) => assistantSelectedChannelIds[channel.id]).length;
        return {
          destinationId: destination.id,
          destinationName,
          channels,
          selectedCount,
          totalChannelCount,
        };
      })
      .filter(Boolean) as Array<{
      destinationId: string;
      destinationName: string;
      channels: Channel[];
      selectedCount: number;
      totalChannelCount: number;
    }>;
  }, [destinationList, channelsByDest, assistantChannelQueryNorm, assistantSelectedChannelIds, assistantShowSelectedChannelsOnly]);

  const assistantSelectedCreatives = useMemo(
    () => (data?.creatives || []).filter((creative) => assistantSelectedCreativeIds[creative.id]),
    [data, assistantSelectedCreativeIds],
  );

  const assistantSelectedChannels = useMemo(() => {
    const selected = new Set<string>();
    Object.entries(assistantSelectedChannelIds).forEach(([channelId, checked]) => {
      if (checked) selected.add(channelId);
    });
    return (data?.channels || []).filter((channel) => selected.has(channel.id));
  }, [data, assistantSelectedChannelIds]);

  const assistantPreview = useMemo(() => {
    const creativeIds = assistantSelectedCreatives.map((creative) => creative.id);
    const channelIds = assistantSelectedChannels.map((channel) => channel.id);
    const totalCombos = creativeIds.length * channelIds.length;
    let locked = 0;
    let alreadySelected = 0;
    let readyToAdd = 0;
    let readyToRemove = 0;

    for (const creativeId of creativeIds) {
      for (const channelId of channelIds) {
        const entry = entryMap.get(keyOf(creativeId, channelId));
        if (entry?.locked) {
          locked += 1;
          continue;
        }
        if (entry?.selected) {
          alreadySelected += 1;
          readyToRemove += 1;
        } else {
          readyToAdd += 1;
        }
      }
    }

    return {
      totalCombos,
      locked,
      alreadySelected,
      readyToAdd,
      readyToRemove,
      selectedDestinationCount: new Set(assistantSelectedChannels.map((channel) => channel.destinationId || "UNASSIGNED")).size,
    };
  }, [assistantSelectedCreatives, assistantSelectedChannels, entryMap]);

  useEffect(() => {
    setAssistantExpandedDestinations((prev) => {
      const keep = Object.fromEntries(Object.entries(prev).filter(([destinationId]) => assistantDestinationCards.some((card) => card.destinationId === destinationId)));
      if (Object.keys(keep).length) return keep;
      const next: Record<string, boolean> = {};
      for (const card of assistantDestinationCards.slice(0, 6)) next[card.destinationId] = true;
      for (const card of assistantDestinationCards) {
        if (card.selectedCount > 0) next[card.destinationId] = true;
      }
      return next;
    });
  }, [assistantDestinationCards]);

  const assistantSelectedCreativeLabels = useMemo(
    () => assistantSelectedCreatives.slice(0, 6).map((creative) => (creative.valid || creative.caption || creative.id || "").trim()),
    [assistantSelectedCreatives],
  );

  const assistantSelectedDestinationLabels = useMemo(
    () => Array.from(new Set(assistantSelectedChannels.map((channel) => destinationsById.get(channel.destinationId || "")?.name || "UNASSIGNED"))).slice(0, 6),
    [assistantSelectedChannels, destinationsById],
  );

  const assistantLargePlanWarning = assistantPreview.totalCombos >= 300;

  const canView = hasPerm(me, "Page_Planner") || hasPerm(me, "page_planner") || hasPerm(me, "page:planner");
  const canEdit = hasPerm(me, "action:planner:edit");
  const canSend = !!wf?.actions?.canSend && hasPerm(me, "ORDER_SEND");

  function toggleAssistantCreative(creativeId: string) {
    setAssistantSelectedCreativeIds((prev) => ({ ...prev, [creativeId]: !prev[creativeId] }));
  }

  function setAllAssistantCreatives(nextSelected: boolean) {
    setAssistantSelectedCreativeIds((prev) => {
      const next = { ...prev };
      for (const creative of assistantVisibleCreatives) next[creative.id] = nextSelected;
      return next;
    });
  }

  function toggleAssistantChannel(channelId: string) {
    setAssistantSelectedChannelIds((prev) => ({ ...prev, [channelId]: !prev[channelId] }));
  }

  function setAssistantDestinationChannels(destinationId: string, nextSelected: boolean) {
    const channels = channelsByDest.get(destinationId) || [];
    setAssistantSelectedChannelIds((prev) => {
      const next = { ...prev };
      for (const channel of channels) {
        if (!assistantChannelQueryNorm || channel.name.toLowerCase().includes(assistantChannelQueryNorm) || (destinationsById.get(destinationId)?.name || destinationId).toLowerCase().includes(assistantChannelQueryNorm)) {
          next[channel.id] = nextSelected;
        }
      }
      return next;
    });
  }

  function setAllAssistantChannels(nextSelected: boolean) {
    setAssistantSelectedChannelIds((prev) => {
      const next = { ...prev };
      for (const card of assistantDestinationCards) {
        for (const channel of card.channels) next[channel.id] = nextSelected;
      }
      return next;
    });
  }

  function toggleAssistantDestinationExpanded(destinationId: string) {
    setAssistantExpandedDestinations((prev) => ({ ...prev, [destinationId]: !prev[destinationId] }));
  }

  function setAllAssistantDestinationPanels(nextOpen: boolean) {
    setAssistantExpandedDestinations(() => {
      const next: Record<string, boolean> = {};
      for (const card of assistantDestinationCards) next[card.destinationId] = nextOpen;
      return next;
    });
  }

  function clearAssistantSelections() {
    setAssistantSelectedCreativeIds({});
    setAssistantSelectedChannelIds({});
    setAssistantFlash("");
  }

  function applyAssistantRoutes(mode: "select" | "remove") {
    if (!data) return;

    const creativeIds = assistantSelectedCreatives.map((creative) => creative.id);
    const channelIds = assistantSelectedChannels.map((channel) => channel.id);

    if (!creativeIds.length || !channelIds.length) {
      setAssistantFlash("Select at least one creative and one channel.");
      return;
    }

    const fallbackSlaId = assistantSlaId || data.slas[0]?.id || "";
    if (mode === "select" && !fallbackSlaId) {
      setAssistantFlash("Select an SLA before applying routes.");
      return;
    }

    const nextEntries = [...data.entries];
    let changed = 0;
    let locked = 0;
    let untouched = 0;

    for (const creativeId of creativeIds) {
      for (const channelId of channelIds) {
        const k = keyOf(creativeId, channelId);
        const idx = nextEntries.findIndex((entry) => keyOf(entry.creativeId, entry.channelId) === k);
        const current: Entry = idx >= 0
          ? nextEntries[idx]
          : { creativeId, channelId, selected: false, slaId: null, locked: false };

        if (current.locked) {
          locked += 1;
          continue;
        }

        const nextEntry: Entry = mode === "select"
          ? {
              ...current,
              selected: true,
              slaId: fallbackSlaId || current.slaId || null,
            }
          : {
              ...current,
              selected: false,
              slaId: null,
            };

        if (current.selected === nextEntry.selected && (current.slaId || null) === (nextEntry.slaId || null)) {
          untouched += 1;
          continue;
        }

        if (idx >= 0) nextEntries[idx] = nextEntry;
        else nextEntries.push(nextEntry);
        changed += 1;
      }
    }

    setData({ ...data, entries: nextEntries });
    setDirty(true);
    setAssistantFlash(
      mode === "select"
        ? `Applied ${changed} route${changed === 1 ? "" : "s"}${locked ? ` • skipped ${locked} locked` : ""}${untouched ? ` • ${untouched} already same` : ""}`
        : `Removed ${changed} route${changed === 1 ? "" : "s"}${locked ? ` • skipped ${locked} locked` : ""}${untouched ? ` • ${untouched} already clear` : ""}`,
    );
  }

  function toggleExpand(destId: string) {
    setExpanded((p) => ({ ...p, [destId]: !p[destId] }));
  }

  function selectAllAllChannels() {
    if (!data) return;
    const nextEntries = [...data.entries];
    const existing = new Map<string, Entry>();
    for (const e of nextEntries) existing.set(keyOf(e.creativeId, e.channelId), e);

    for (const cr of data.creatives) {
      for (const ch of data.channels) {
        const k = keyOf(cr.id, ch.id);
        const cur = existing.get(k) ?? { creativeId: cr.id, channelId: ch.id, selected: false, slaId: null, locked: false };
        if (cur.locked) continue;
        const slaId = cur.slaId || data.slas[0]?.id || null;
        const merged: Entry = { ...cur, selected: true, slaId };
        existing.set(k, merged);
      }
    }
    setData({ ...data, entries: Array.from(existing.values()) });
    setDirty(true);
  }

  function unselectAll() {
    if (!data) return;
    const next = data.entries.map((e) => (e.locked ? e : { ...e, selected: false, slaId: null }));
    setData({ ...data, entries: next });
    setDirty(true);
  }

  const showSelectAll = initialSelectionCount === 0;

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div className="card" style={{ display: "grid", gap: 10 }}>
        <div className="row" style={{ justifyContent: "space-between", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
          <h3 style={{ margin: 0 }}>Planner + Commit</h3>

          <div className="row" style={{ gap: 8, flexWrap: "wrap", justifyContent: "flex-end" }}>
            <button
              onClick={() => setView("assistant")}
              style={view === "assistant" ? { background: "#e9fff1", borderColor: "#39d353" } : undefined}
              title="Fast bulk selection assistant for clients with large planning lists"
            >
              Easy planner
            </button>
            <button
              onClick={() => setView("excel")}
              style={view === "excel" ? { background: "#eef" } : undefined}
              title="Excel-like matrix grouped by destination"
            >
              Excel view
            </button>
            <button
              onClick={() => setView("classic")}
              style={view === "classic" ? { background: "#eef" } : undefined}
              title="Classic view with left destination tree"
            >
              Classic view
            </button>

            <button
              onClick={() => setView("tree")}
              style={view === "tree" ? { background: "#eef" } : undefined}
              title="Destination tree view with popup details"
            >
              Tree view
            </button>

            {/* Creative sort dropdown removed. Excel-view buttons now control the creative label mode/sort. */}
          </div>
        </div>

        <QcGateBanner projectId={id} scope="commit" onGate={(ok) => setQcGateOk(ok)} />

        <div className="row" style={{ alignItems: "center" }}>
          <button
            onClick={savePlanner}
            disabled={busy || !dirty || !data || !canEdit}
            style={dirty && canEdit ? { background: "#e9fff1", borderColor: "#39d353" } : undefined}
            title={!canEdit ? "No permission: action:planner:edit" : undefined}
          >
            {busy ? "Saving..." : dirty ? "Save planner" : "Saved"}
          </button>

          {savedFlash && <span style={{ fontSize: 12, fontWeight: 800, color: "#1a7f37" }}>Changes saved ✓</span>}

          <button onClick={exportExcel} disabled={busy || !data || !canView}>Download report</button>

          <button onClick={downloadExampleTemplate} disabled={busy || !canView}>Planner matrix template</button>

          <label className="row" style={{ gap: 8 }}>
            <input
              id={fileInputId}
              type="file"
              accept=".xlsx,.xls,.csv"
              style={{ display: "none" }}
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) importExcel(f);
                e.currentTarget.value = "";
              }}
            />
            <button
              onClick={() => document.getElementById(fileInputId)?.click()}
              disabled={busy || !data || !canEdit}
              title={!canEdit ? "No permission: action:planner:edit" : undefined}
            >
              Import Excel
            </button>
          </label>

          <button onClick={() => nav(`/projects/${id}/tracking`)} disabled={!canSend} title={!canSend ? "Send not allowed yet" : undefined}>
            Send / Tracking
          </button>

          {showSelectAll && (
            <>
              <button onClick={selectAllAllChannels} disabled={busy || !data || !canEdit}>
                Select All
              </button>
              <button onClick={unselectAll} disabled={busy || !data || !canEdit}>
                Unselect All
              </button>
            </>
          )}

          <button onClick={loadPlanner} disabled={busy}>Refresh</button>
        </div>

        <div className="row">
          <button onClick={commit} disabled={disabledCommit}>
            {busy ? "Committing..." : "Commit snapshot"}
          </button>
        </div>

        {localErr && (
          <div className="card" style={{ borderColor: "#f5a", background: "#fff5fa" }}>
            {localErr}
          </div>
        )}

        {!wf?.actions?.canCommit && commitReasons.length > 0 && (
          <div className="card" style={{ borderColor: "#f5a", background: "#fff5fa" }}>
            <div style={{ fontWeight: 800, marginBottom: 6 }}>Commit blocked</div>
            <ul style={{ margin: 0, paddingLeft: 18 }}>
              {commitReasons.map((r) => (
                <li key={r.code}>{r.message}</li>
              ))}
            </ul>
          </div>
        )}

      </div>

      <div className="card" style={{ padding: 0 }}>
        {!data ? (
          <div style={{ padding: 12, opacity: 0.7 }}>Loading planner…</div>
        ) : !canView ? (
          <div style={{ padding: 12 }}>You don’t have access to Planner (Page_Planner).</div>
        ) : view === "assistant" ? (
          <div style={{ display: "grid", gap: 12, padding: 12 }}>
            <div
              style={{
                border: "1px solid #e8edf5",
                borderRadius: 20,
                background: "linear-gradient(180deg, #f8fbff 0%, #ffffff 100%)",
                padding: 16,
                display: "grid",
                gap: 14,
                boxShadow: "0 8px 24px rgba(15, 23, 42, 0.04)",
              }}
            >
              <div className="row" style={{ justifyContent: "space-between", gap: 12, flexWrap: "wrap" }}>
                <div style={{ display: "grid", gap: 4 }}>
                  <div style={{ fontSize: 18, fontWeight: 900 }}>Easy planner assistant</div>
                  <div style={{ fontSize: 13, color: "#64748b", maxWidth: 900 }}>
                    Faster route planning for clients with large lists. Existing Planner + Commit behavior, save flow, Excel flow, and commit flow stay unchanged.
                  </div>
                </div>
                <div className="row" style={{ gap: 8, flexWrap: "wrap", justifyContent: "flex-end" }}>
                  <button onClick={() => setAllAssistantCreatives(true)} disabled={!assistantVisibleCreatives.length || !canEdit}>Select visible creatives</button>
                  <button onClick={() => setAllAssistantChannels(true)} disabled={!assistantDestinationCards.length || !canEdit}>Select visible channels</button>
                  <button onClick={clearAssistantSelections} disabled={!canEdit}>Clear helper selection</button>
                </div>
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "repeat(4, minmax(0, 1fr))", gap: 10 }}>
                {[
                  ["Step 1", `${assistantSelectedCreatives.length} creatives`, "Choose one or more creatives"],
                  ["Step 2", `${assistantSelectedChannels.length} channels`, "Pick destination channels in bulk"],
                  ["Step 3", assistantSlaId ? (slasById.get(assistantSlaId)?.name || "SLA selected") : "Select SLA", "Set one SLA for the current bulk action"],
                  ["Preview", `${assistantPreview.totalCombos} route combos`, assistantLargePlanWarning ? "Large selection — review once before apply" : "Apply to draft planner only"],
                ].map(([title, value, desc]) => (
                  <div key={String(title)} style={{ border: "1px solid #e8edf5", borderRadius: 16, padding: 12, background: "#fff", display: "grid", gap: 4 }}>
                    <div style={{ fontSize: 11, fontWeight: 800, letterSpacing: 0.4, textTransform: "uppercase", color: "#64748b" }}>{title}</div>
                    <div style={{ fontSize: 16, fontWeight: 900, lineHeight: 1.2 }}>{value}</div>
                    <div style={{ fontSize: 12, color: "#64748b" }}>{desc}</div>
                  </div>
                ))}
              </div>

              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: "minmax(270px, 0.95fr) minmax(420px, 1.25fr) minmax(300px, 0.95fr)",
                  gap: 12,
                  alignItems: "start",
                }}
              >
                <div style={{ border: "1px solid #e8edf5", borderRadius: 16, background: "#fff", overflow: "hidden" }}>
                  <div style={{ padding: 14, borderBottom: "1px solid #eef2f7", display: "grid", gap: 8 }}>
                    <div className="row" style={{ justifyContent: "space-between", gap: 8, flexWrap: "wrap" }}>
                      <div style={{ fontWeight: 800 }}>1. Select creatives</div>
                      <span style={{ fontSize: 12, color: "#64748b" }}>{assistantSelectedCreatives.length} selected</span>
                    </div>
                    <input
                      value={assistantCreativeQuery}
                      onChange={(e) => setAssistantCreativeQuery(e.target.value)}
                      placeholder={`Search ${getCreativeCodeLabel(me)} / caption / format…`}
                    />
                    <div className="row" style={{ gap: 8, flexWrap: "wrap" }}>
                      <button
                        type="button"
                        onClick={() => setAssistantShowSelectedCreativesOnly((prev) => !prev)}
                        style={assistantShowSelectedCreativesOnly ? { background: "#e9fff1", borderColor: "#39d353" } : undefined}
                      >
                        {assistantShowSelectedCreativesOnly ? "Showing selected only" : "Show selected only"}
                      </button>
                      <button type="button" onClick={() => setAllAssistantCreatives(true)} disabled={!assistantVisibleCreatives.length || !canEdit}>Select filtered</button>
                      <button type="button" onClick={() => setAllAssistantCreatives(false)} disabled={!assistantVisibleCreatives.length || !canEdit}>Clear filtered</button>
                    </div>
                    {!!assistantSelectedCreativeLabels.length && (
                      <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                        {assistantSelectedCreativeLabels.map((label) => (
                          <span key={label} style={{ fontSize: 11, padding: "4px 8px", borderRadius: 999, background: "#f0fdf4", border: "1px solid #bbf7d0", color: "#166534" }}>{label}</span>
                        ))}
                        {assistantSelectedCreatives.length > assistantSelectedCreativeLabels.length && (
                          <span style={{ fontSize: 11, padding: "4px 8px", borderRadius: 999, background: "#f8fafc", border: "1px solid #e2e8f0", color: "#475569" }}>
                            +{assistantSelectedCreatives.length - assistantSelectedCreativeLabels.length} more
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                  <div style={{ maxHeight: 560, overflow: "auto", display: "grid" }}>
                    {assistantVisibleCreatives.length === 0 ? (
                      <div style={{ padding: 14, color: "#64748b" }}>No creatives match the current search.</div>
                    ) : (
                      assistantVisibleCreatives.map((creative) => {
                        const checked = !!assistantSelectedCreativeIds[creative.id];
                        const code = (creative.valid || "").trim() || (creative.caption || "").trim() || creative.id;
                        return (
                          <label
                            key={creative.id}
                            style={{
                              display: "grid",
                              gap: 6,
                              padding: 14,
                              borderTop: "1px solid #f1f5f9",
                              background: checked ? "#f0fdf4" : "#fff",
                              cursor: canEdit ? "pointer" : "default",
                            }}
                          >
                            <div className="row" style={{ gap: 10, alignItems: "center", flexWrap: "nowrap" }}>
                              <input type="checkbox" checked={checked} disabled={!canEdit} onChange={() => toggleAssistantCreative(creative.id)} />
                              <div style={{ minWidth: 0 }}>
                                <div style={{ fontWeight: 800, wordBreak: "break-word" }}>{code}</div>
                                {creative.caption && creative.caption !== code && (
                                  <div style={{ fontSize: 12, color: "#64748b", wordBreak: "break-word" }}>{creative.caption}</div>
                                )}
                              </div>
                            </div>
                            <div style={{ display: "flex", gap: 6, flexWrap: "wrap", paddingLeft: 26 }}>
                              {creative.format && <span style={{ fontSize: 11, padding: "4px 8px", borderRadius: 999, background: "#f8fafc", border: "1px solid #e2e8f0" }}>{creative.format}</span>}
                              {creative.duration && <span style={{ fontSize: 11, padding: "4px 8px", borderRadius: 999, background: "#f8fafc", border: "1px solid #e2e8f0" }}>{creative.duration}</span>}
                              {(creative.languages || []).slice(0, 3).map((language) => (
                                <span key={language} style={{ fontSize: 11, padding: "4px 8px", borderRadius: 999, background: "#f8fafc", border: "1px solid #e2e8f0" }}>{language}</span>
                              ))}
                            </div>
                          </label>
                        );
                      })
                    )}
                  </div>
                </div>

                <div style={{ border: "1px solid #e8edf5", borderRadius: 16, background: "#fff", overflow: "hidden" }}>
                  <div style={{ padding: 14, borderBottom: "1px solid #eef2f7", display: "grid", gap: 8 }}>
                    <div className="row" style={{ justifyContent: "space-between", gap: 8, flexWrap: "wrap" }}>
                      <div style={{ fontWeight: 800 }}>2. Select destinations / channels</div>
                      <span style={{ fontSize: 12, color: "#64748b" }}>{assistantSelectedChannels.length} channels selected</span>
                    </div>
                    <input
                      value={assistantChannelQuery}
                      onChange={(e) => setAssistantChannelQuery(e.target.value)}
                      placeholder="Search destination / channel…"
                    />
                    <div className="row" style={{ gap: 8, flexWrap: "wrap" }}>
                      <button
                        type="button"
                        onClick={() => setAssistantShowSelectedChannelsOnly((prev) => !prev)}
                        style={assistantShowSelectedChannelsOnly ? { background: "#e9fff1", borderColor: "#39d353" } : undefined}
                      >
                        {assistantShowSelectedChannelsOnly ? "Showing selected only" : "Show selected only"}
                      </button>
                      <button type="button" onClick={() => setAllAssistantChannels(true)} disabled={!assistantDestinationCards.length || !canEdit}>Select filtered</button>
                      <button type="button" onClick={() => setAllAssistantChannels(false)} disabled={!assistantDestinationCards.length || !canEdit}>Clear filtered</button>
                      <button type="button" onClick={() => setAllAssistantDestinationPanels(true)} disabled={!assistantDestinationCards.length}>Expand all</button>
                      <button type="button" onClick={() => setAllAssistantDestinationPanels(false)} disabled={!assistantDestinationCards.length}>Collapse all</button>
                    </div>
                    {!!assistantSelectedDestinationLabels.length && (
                      <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                        {assistantSelectedDestinationLabels.map((label) => (
                          <span key={label} style={{ fontSize: 11, padding: "4px 8px", borderRadius: 999, background: "#eff6ff", border: "1px solid #bfdbfe", color: "#1d4ed8" }}>{label}</span>
                        ))}
                        {assistantPreview.selectedDestinationCount > assistantSelectedDestinationLabels.length && (
                          <span style={{ fontSize: 11, padding: "4px 8px", borderRadius: 999, background: "#f8fafc", border: "1px solid #e2e8f0", color: "#475569" }}>
                            +{assistantPreview.selectedDestinationCount - assistantSelectedDestinationLabels.length} more
                          </span>
                        )}
                      </div>
                    )}
                  </div>
                  <div style={{ maxHeight: 560, overflow: "auto", display: "grid", gap: 10, padding: 12 }}>
                    {assistantDestinationCards.length === 0 ? (
                      <div style={{ color: "#64748b" }}>No destinations or channels match the current search.</div>
                    ) : (
                      assistantDestinationCards.map((card) => {
                        const isOpen = assistantExpandedDestinations[card.destinationId] ?? false;
                        return (
                          <div key={card.destinationId} style={{ border: "1px solid #e8edf5", borderRadius: 14, overflow: "hidden", background: "#fff" }}>
                            <div style={{ padding: 12, background: "#f8fbff", borderBottom: isOpen ? "1px solid #eef2f7" : "none", display: "grid", gap: 8 }}>
                              <div className="row" style={{ justifyContent: "space-between", gap: 8, flexWrap: "wrap" }}>
                                <button
                                  type="button"
                                  onClick={() => toggleAssistantDestinationExpanded(card.destinationId)}
                                  style={{
                                    display: "grid",
                                    gap: 2,
                                    textAlign: "left",
                                    background: "transparent",
                                    border: "none",
                                    padding: 0,
                                    margin: 0,
                                    cursor: "pointer",
                                    color: "inherit",
                                  }}
                                >
                                  <span style={{ fontWeight: 800, wordBreak: "break-word" }}>{isOpen ? "▾" : "▸"} {card.destinationName}</span>
                                  <span style={{ fontSize: 12, color: "#64748b" }}>{card.selectedCount} selected · {card.channels.length} shown / {card.totalChannelCount} total{destinationReceiverLabel(destinationsById.get(card.destinationId)) ? ` • ${destinationReceiverLabel(destinationsById.get(card.destinationId))}` : ""}</span>
                                </button>
                                <span style={{ fontSize: 12, padding: "6px 10px", borderRadius: 999, background: "#fff", border: "1px solid #e2e8f0" }}>{card.selectedCount} selected</span>
                              </div>
                              <div className="row" style={{ gap: 8, flexWrap: "wrap" }}>
                                <button type="button" onClick={() => setAssistantDestinationChannels(card.destinationId, true)} disabled={!card.channels.length || !canEdit}>Select all</button>
                                <button type="button" onClick={() => setAssistantDestinationChannels(card.destinationId, false)} disabled={!card.channels.length || !canEdit}>Clear</button>
                              </div>
                            </div>
                            {isOpen && (
                              <div style={{ display: "grid", maxHeight: 240, overflow: "auto" }}>
                                {card.channels.map((channel) => {
                                  const checked = !!assistantSelectedChannelIds[channel.id];
                                  const selectedCount = assistantSelectedCreatives.reduce((total, creative) => total + (entryMap.get(keyOf(creative.id, channel.id))?.selected ? 1 : 0), 0);
                                  return (
                                    <div
                                      key={channel.id}
                                      style={{
                                        display: "grid",
                                        gridTemplateColumns: "auto minmax(0, 1fr) minmax(120px, 150px) auto",
                                        gap: 10,
                                        alignItems: "center",
                                        padding: "10px 12px",
                                        borderTop: "1px solid #f1f5f9",
                                        background: checked ? "#f8fafc" : "#fff",
                                      }}
                                    >
                                      <input type="checkbox" checked={checked} disabled={!canEdit} onChange={() => toggleAssistantChannel(channel.id)} />
                                      <div style={{ minWidth: 0, display: "grid", gap: 4 }}>
                                        <div style={{ fontWeight: 600, wordBreak: "break-word" }}>{channelDisplayName(channel)}</div>
                                        {channelMetaLabel(channel) ? (
                                          <div style={{ fontSize: 11, color: "#1d4ed8", fontWeight: 700 }}>{channelMetaLabel(channel)}</div>
                                        ) : (
                                          <div style={{ fontSize: 11, color: "#64748b" }}>Set logo position</div>
                                        )}
                                      </div>
                                      <select
                                        value={channel.alignment || ""}
                                        disabled={!canEdit || !!logoBusyChannelIds[channel.id]}
                                        onChange={(e) => updateChannelLogoPosition(channel.id, (e.target.value as "" | LogoPosition) || "")}
                                        className="plannerLogoSelectCompact"
                                      >
                                        <option value="">Logo…</option>
                                        {LOGO_POSITION_OPTIONS.map((option) => (
                                          <option key={option} value={option}>
                                            {option}
                                          </option>
                                        ))}
                                      </select>
                                      <span style={{ fontSize: 11, padding: "4px 8px", borderRadius: 999, background: "#fff", border: "1px solid #e2e8f0", whiteSpace: "nowrap" }}>
                                        {selectedCount} already
                                      </span>
                                    </div>
                                  );
                                })}
                              </div>
                            )}
                          </div>
                        );
                      })
                    )}
                  </div>
                </div>

                <div style={{ border: "1px solid #e8edf5", borderRadius: 16, background: "#fff", overflow: "hidden", position: "sticky", top: 10 }}>
                  <div style={{ padding: 14, borderBottom: "1px solid #eef2f7", display: "grid", gap: 10 }}>
                    <div style={{ fontWeight: 800 }}>3. Apply to planner</div>
                    <label style={{ display: "grid", gap: 6 }}>
                      <span style={{ fontSize: 12, color: "#64748b" }}>SLA for selected routes</span>
                      <select value={assistantSlaId} onChange={(e) => setAssistantSlaId(e.target.value)} disabled={!canEdit}>
                        <option value="">Select SLA…</option>
                        {data.slas.map((sla) => (
                          <option key={sla.id} value={sla.id}>{sla.name}</option>
                        ))}
                      </select>
                    </label>
                    {assistantLargePlanWarning && (
                      <div style={{ fontSize: 12, lineHeight: 1.5, color: "#92400e", background: "#fff7ed", border: "1px solid #fed7aa", borderRadius: 12, padding: 10 }}>
                        Large selection detected. Review the preview once before applying so the client does not add too many routes by mistake.
                      </div>
                    )}
                    <div style={{ display: "grid", gap: 8 }}>
                      <button type="button" onClick={() => applyAssistantRoutes("select")} disabled={!canEdit || !assistantPreview.totalCombos}>Apply routes</button>
                      <button type="button" onClick={() => applyAssistantRoutes("remove")} disabled={!canEdit || !assistantPreview.totalCombos}>Remove routes</button>
                    </div>
                    {assistantFlash && (
                      <div style={{ fontSize: 12, color: assistantFlash.toLowerCase().includes("select at least") || assistantFlash.toLowerCase().includes("select an sla") ? "#b42318" : "#1a7f37" }}>
                        {assistantFlash}
                      </div>
                    )}
                  </div>

                  <div style={{ padding: 14, display: "grid", gap: 10 }}>
                    <div style={{ fontWeight: 800 }}>Preview</div>
                    <div style={{ display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: 8 }}>
                      {[
                        ["Creatives", assistantSelectedCreatives.length, "#f8fafc"],
                        ["Channels", assistantSelectedChannels.length, "#f8fafc"],
                        ["Destinations", assistantPreview.selectedDestinationCount, "#f8fafc"],
                        ["Route combinations", assistantPreview.totalCombos, "#eef6ff"],
                        ["Ready to add", assistantPreview.readyToAdd, "#f0fdf4"],
                        ["Ready to remove", assistantPreview.readyToRemove, "#fff7ed"],
                        ["Already selected", assistantPreview.alreadySelected, "#f8fafc"],
                        ["Locked", assistantPreview.locked, "#fef2f2"],
                      ].map(([label, value, bg]) => (
                        <div key={String(label)} style={{ border: "1px solid #e8edf5", borderRadius: 14, padding: 10, background: String(bg) }}>
                          <div style={{ fontSize: 12, color: "#64748b" }}>{label}</div>
                          <div style={{ fontSize: 20, fontWeight: 900 }}>{value}</div>
                        </div>
                      ))}
                    </div>
                    {!!assistantSelectedCreativeLabels.length && (
                      <div style={{ display: "grid", gap: 6 }}>
                        <div style={{ fontSize: 12, fontWeight: 800, color: "#475569" }}>Selected creatives</div>
                        <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                          {assistantSelectedCreativeLabels.map((label) => (
                            <span key={label} style={{ fontSize: 11, padding: "4px 8px", borderRadius: 999, background: "#f8fafc", border: "1px solid #e2e8f0" }}>{label}</span>
                          ))}
                        </div>
                      </div>
                    )}
                    {!!assistantSelectedDestinationLabels.length && (
                      <div style={{ display: "grid", gap: 6 }}>
                        <div style={{ fontSize: 12, fontWeight: 800, color: "#475569" }}>Selected destinations</div>
                        <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                          {assistantSelectedDestinationLabels.map((label) => (
                            <span key={label} style={{ fontSize: 11, padding: "4px 8px", borderRadius: 999, background: "#f8fafc", border: "1px solid #e2e8f0" }}>{label}</span>
                          ))}
                        </div>
                      </div>
                    )}
                    <div style={{ fontSize: 12, color: "#64748b", lineHeight: 1.5 }}>
                      Apply routes only updates the draft planner. Save planner and Commit snapshot still work exactly the same as before.
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ) : view === "excel" ? (
          <div className="plannerExcel">
            <div className="plannerExcel__filters" style={{ gap: 10 }}>
              <div className="row" style={{ gap: 8, flexWrap: "wrap", alignItems: "center" }}>
                <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search destination / channel…" />
                <input
                  value={creativeFilterText}
                  onChange={(e) => setCreativeFilterText(e.target.value)}
                  placeholder={`Search ${getCreativeCodeLabel(me)} / caption…`}
                />
              </div>

              <div className="row" style={{ gap: 8, flexWrap: "wrap", alignItems: "center", justifyContent: "space-between" }}>
                <div className="row" style={{ gap: 6, flexWrap: "wrap" }}>
                  <span style={{ fontSize: 12, opacity: 0.72, paddingRight: 4 }}>Creative filter:</span>
                  <button
                    onClick={() => {
                      setCreativeFilterMode("BOTH");
                      setCreativeSort("VALID");
                    }}
                    style={creativeFilterMode === "BOTH" ? { background: "#eef" } : undefined}
                  >
                    Both
                  </button>
                  <button
                    onClick={() => {
                      setCreativeFilterMode("VALID");
                      setCreativeSort("VALID");
                    }}
                    style={creativeFilterMode === "VALID" ? { background: "#eef" } : undefined}
                  >
                    {getCreativeCodeLabel(me)}
                  </button>
                  <button
                    onClick={() => {
                      setCreativeFilterMode("CAPTION");
                      setCreativeSort("CAPTION");
                    }}
                    style={creativeFilterMode === "CAPTION" ? { background: "#eef" } : undefined}
                  >
                    Caption
                  </button>
                </div>

                <div className="row" style={{ gap: 6, flexWrap: "wrap" }}>
                  <button onClick={() => setDestFilter("ALL")} style={destFilter === "ALL" ? { background: "#eef" } : undefined}>
                    All
                  </button>
                  <button onClick={() => setDestFilter("USED")} style={destFilter === "USED" ? { background: "#eef" } : undefined}>
                    Used
                  </button>
                  <button onClick={() => setDestFilter("UNUSED")} style={destFilter === "UNUSED" ? { background: "#eef" } : undefined}>
                    Unused
                  </button>
                </div>
              </div>
            </div>

            {creativeFilterText ? (
              <div className="plannerExcel__summary">
                <div className="plannerExcel__summaryHint">Filter applied: {visibleCreatives.length} creative(s) matched.</div>
              </div>
            ) : null}

            <div className="plannerExcel__sections">
              {filteredDestinations.map((d) => {
                const did = d.id;
                const title = did === "UNASSIGNED" ? "UNASSIGNED" : d.name;
                const allChs = channelsByDest.get(did) || [];
                const destMatches = !!qNorm && title.toLowerCase().includes(qNorm);
                const chs = !qNorm || destMatches ? allChs : allChs.filter((c) => c.name.toLowerCase().includes(qNorm));
                if (!chs.length) return null;
                const isUsed = usedDestIds.has(did);
                const isExpanded = !!expanded[did];

                return (
                  <div key={did} className="plannerExcel__section">
                    <div className="plannerExcel__sectionHdr">
                      <button
                        onClick={() => toggleExpand(did)}
                        title={isExpanded ? "Collapse" : "Expand"}
                        className="plannerExcel__toggle"
                      >
                        {isExpanded ? "–" : "+"}
                      </button>

                      <div className="plannerExcel__sectionTitle">
                        <div className="plannerExcel__sectionTitleMain">
                          <span>{title}</span>
                          {isUsed && <span className="plannerExcel__badgeUsed">USED</span>}
                        </div>
                        <div className="plannerExcel__sectionSub">{chs.length} channel(s){destinationReceiverLabel(d) ? ` • ${destinationReceiverLabel(d)}` : ""}</div>
                      </div>
                    </div>

                    {isExpanded && (
                      <div className="plannerExcel__tableWrap">


                        <table className="plannerExcel__table" style={{ ["--planner-creative-count" as any]: Math.max(creativeLegendItems.length, 1) }}> 
                          <thead>
                            <tr>
                              <th className="plannerExcel__th plannerExcel__thSticky1">Channel</th>

                              {creativeLegendItems.map(({ creative, code, caption }) => {
                                const validLabel = code || creative.id;
                                const captionLabel = caption || validLabel;
                                const headerLabel = creativeFilterMode === "CAPTION"
                                  ? captionLabel
                                  : creativeFilterMode === "VALID"
                                    ? validLabel
                                    : validLabel;
                                const headerTitle = [
                                  `VALID: ${validLabel}`,
                                  caption && caption !== code ? `Creative: ${caption}` : "",
                                  creative.duration ? `Duration: ${creative.duration}` : "",
                                  (creative.languages || []).length ? `Languages: ${(creative.languages || []).join(", ")}` : "",
                                  creative.format ? `Format: ${creative.format}` : "",
                                  creative.audio ? `Audio: ${creative.audio}` : "",
                                ]
                                  .filter(Boolean)
                                  .join("\n");

                                return (
                                  <th key={creative.id} className="plannerExcel__th plannerExcel__thChan" title={headerTitle}>
                                    <div className="plannerExcel__thChanStack" aria-label={headerLabel}>
                                      {headerLabel.split("").map((ch, idx) => (
                                        <span key={`${creative.id}-${idx}`} className="plannerExcel__thChanChar">{ch === " " ? " " : ch}</span>
                                      ))}
                                    </div>
                                  </th>
                                );
                              })}
                            </tr>
                          </thead>

                          <tbody>
                            {chs.map((ch) => (
                              <tr key={`${did}::${ch.id}`} className="plannerExcel__tr">
                                <td className="plannerExcel__td plannerExcel__tdSticky1" title={channelDisplayName(ch)}>
                                  <div style={{ display: "grid", gap: 6, minWidth: 0, width: "100%" }}>
                                    <span>{channelDisplayName(ch)}</span>
                                    {channelMetaLabel(ch) ? <span style={{ fontSize: 11, color: "#1d4ed8", fontWeight: 700 }}>{channelMetaLabel(ch)}</span> : null}
                                    <select
                                      value={ch.alignment || ""}
                                      disabled={busy || !canEdit || !!logoBusyChannelIds[ch.id]}
                                      onChange={(ev) => updateChannelLogoPosition(ch.id, (ev.target.value as "" | LogoPosition) || "")}
                                      className="plannerExcel__channelLogoSelect"
                                    >
                                      <option value="">Logo…</option>
                                      {LOGO_POSITION_OPTIONS.map((option) => (
                                        <option key={option} value={option}>
                                          {option}
                                        </option>
                                      ))}
                                    </select>
                                  </div>
                                </td>

                                {creativeLegendItems.map(({ creative: cr }) => {
                                  const e = entryMap.get(keyOf(cr.id, ch.id));
                                  const selected = !!e?.selected;
                                  const locked = !!e?.locked;
                                  return (
                                    <td
                                      key={cr.id}
                                      className={
                                        "plannerExcel__td plannerExcel__tdCell" +
                                        (locked ? " plannerExcel__tdLocked" : "") +
                                        (selected ? " plannerExcel__tdSelected" : "")
                                      }
                                    >
                                      <div className="plannerExcel__cell">
                                        <label className="plannerExcel__cellSel" title={locked ? "Committed (locked)" : undefined}>
                                          <input
                                            type="checkbox"
                                            checked={selected}
                                            disabled={busy || locked || !canEdit}
                                            onChange={(ev) => setCell(cr.id, ch.id, { selected: ev.target.checked })}
                                          />
                                        </label>

                                        {selected && (() => {
                                          const k = keyOf(cr.id, ch.id);
                                          const sla = e?.slaId ? slasById.get(e.slaId) : null;
                                          const slaName = slaChipLabel(sla);
                                          const short = slaName.length > 10 ? slaName.slice(0, 10) + "…" : slaName;
                                          const editing = editSlaKey === k;
                                          return editing ? (
                                            <select
                                              value={e?.slaId || ""}
                                              disabled={busy || locked || !canEdit}
                                              onBlur={() => setEditSlaKey(null)}
                                              onChange={(ev) => {
                                                const slaId = ev.target.value || null;
                                                setCell(cr.id, ch.id, { selected: true, slaId });
                                                setEditSlaKey(null);
                                              }}
                                              className="plannerExcel__cellSlaEdit"
                                              title={slaChipTitle(sla)}
                                              autoFocus
                                            >
                                              <option value="">SLA…</option>
                                              {data.slas.map((s) => (
                                                <option key={s.id} value={s.id}>
                                                  {String(s.code ?? "").trim() ? `${String(s.code ?? "").trim()} — ${s.name}` : s.name}
                                                </option>
                                              ))}
                                            </select>
                                          ) : (
                                            <button
                                              type="button"
                                              className="plannerExcel__slaChip"
                                              disabled={busy || locked || !canEdit}
                                              onClick={() => setEditSlaKey(k)}
                                              title={slaChipTitle(sla)}
                                            >
                                              {short}
                                            </button>
                                          );
                                        })()}
                                      </div>
                                    </td>
                                  );
                                })}
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
                ) : view === "tree" ? (
          <div style={{ display: "grid", gap: 12, padding: 12 }}>
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
                gap: 10,
                alignItems: "end",
              }}
            >
              <div style={{ display: "grid", gap: 6 }}>
                <div style={{ fontWeight: 800 }}>Flow tree view</div>
                <div style={{ fontSize: 12, opacity: 0.72 }}>
                  Open a destination to select channels and creatives in a flow-style popup instead of a wide matrix.
                </div>
              </div>
              <div className="row" style={{ gap: 8, flexWrap: "wrap", justifyContent: "flex-end" }}>
                <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search destination / channel…" />
                <input
                  value={creativeFilterText}
                  onChange={(e) => setCreativeFilterText(e.target.value)}
                  placeholder={`Search ${getCreativeCodeLabel(me)} / caption…`}
                />
              </div>
            </div>

            <div className="row" style={{ gap: 8, flexWrap: "wrap", justifyContent: "space-between" }}>
              <div className="row" style={{ gap: 6, flexWrap: "wrap" }}>
                <button onClick={() => setDestFilter("ALL")} style={destFilter === "ALL" ? { background: "#eef" } : undefined}>
                  All destinations
                </button>
                <button onClick={() => setDestFilter("USED")} style={destFilter === "USED" ? { background: "#eef" } : undefined}>
                  Used only
                </button>
                <button onClick={() => setDestFilter("UNUSED")} style={destFilter === "UNUSED" ? { background: "#eef" } : undefined}>
                  Unused only
                </button>
              </div>

              <div className="row" style={{ gap: 6, flexWrap: "wrap" }}>
                <button onClick={() => setCreativeFilterMode("BOTH")} style={creativeFilterMode === "BOTH" ? { background: "#eef" } : undefined}>
                  Both
                </button>
                <button onClick={() => setCreativeFilterMode("VALID")} style={creativeFilterMode === "VALID" ? { background: "#eef" } : undefined}>
                  {getCreativeCodeLabel(me)}
                </button>
                <button onClick={() => setCreativeFilterMode("CAPTION")} style={creativeFilterMode === "CAPTION" ? { background: "#eef" } : undefined}>
                  Caption
                </button>
              </div>
            </div>

            {treeDestinationCards.length === 0 ? (
              <div style={{ opacity: 0.7 }}>No destinations match the current filters.</div>
            ) : (
              <div
                style={{
                  border: "1px solid #e8edf5",
                  borderRadius: 18,
                  background: "#fff",
                  overflow: "hidden",
                }}
              >
                <div
                  style={{
                    display: "grid",
                    gridTemplateColumns: "minmax(240px, 1.4fr) minmax(120px, 0.7fr) minmax(140px, 0.8fr) minmax(140px, 0.8fr) auto",
                    gap: 12,
                    padding: "12px 16px",
                    background: "#f8fbff",
                    borderBottom: "1px solid #e8edf5",
                    fontSize: 12,
                    fontWeight: 800,
                    color: "#475569",
                  }}
                >
                  <div>Destination</div>
                  <div>Channels</div>
                  <div>Selected creatives</div>
                  <div>Selected routes</div>
                  <div />
                </div>

                <div style={{ display: "grid" }}>
                  {treeDestinationCards.map((group, idx) => (
                    <div
                      key={group.destinationId}
                      style={{
                        display: "grid",
                        gridTemplateColumns: "minmax(240px, 1.4fr) minmax(120px, 0.7fr) minmax(140px, 0.8fr) minmax(140px, 0.8fr) auto",
                        gap: 12,
                        padding: "14px 16px",
                        alignItems: "center",
                        borderTop: idx === 0 ? "none" : "1px solid #eef2f7",
                      }}
                    >
                      <div style={{ minWidth: 0 }}>
                        <div style={{ fontWeight: 900, fontSize: 16, wordBreak: "break-word" }}>{group.destinationName}</div>
                        <div style={{ fontSize: 12, color: "#64748b", marginTop: 4 }}>
                          {group.channelPreview.length
                            ? group.channelPreview.slice(0, 2).join(" • ") + (group.channelPreview.length > 2 ? ` +${group.channelPreview.length - 2} more` : "")
                            : "No channels"}
                        </div>
                        {destinationReceiverLabel(destinationsById.get(group.destinationId)) ? (
                          <div style={{ fontSize: 11, color: "#1d4ed8", marginTop: 6, fontWeight: 700 }}>
                            {destinationReceiverLabel(destinationsById.get(group.destinationId))}
                          </div>
                        ) : null}
                      </div>

                      <div>
                        <span style={{ fontSize: 12, padding: "6px 10px", borderRadius: 999, background: "#f8fafc", border: "1px solid #e2e8f0" }}>
                          {group.channelCount}
                        </span>
                      </div>

                      <div>
                        <span style={{ fontSize: 12, padding: "6px 10px", borderRadius: 999, background: "#f8fafc", border: "1px solid #e2e8f0" }}>
                          {group.selectedCreativeCount}
                        </span>
                      </div>

                      <div>
                        <span style={{ fontSize: 12, padding: "6px 10px", borderRadius: 999, background: "#f8fafc", border: "1px solid #e2e8f0" }}>
                          {group.selectedRoutes}
                        </span>
                      </div>

                      <div style={{ display: "flex", justifyContent: "flex-end" }}>
                        <button
                          type="button"
                          onClick={() => setTreeModalDestId(group.destinationId)}
                          title={`Open flow tree for ${group.destinationName}`}
                          style={{ whiteSpace: "nowrap" }}
                        >
                          Open
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {treeModalDestId && activeTreeDestinationCard && (
              <div
                onClick={() => setTreeModalDestId(null)}
                style={{
                  position: "fixed",
                  inset: 0,
                  background: "rgba(15, 23, 42, 0.45)",
                  display: "grid",
                  placeItems: "center",
                  padding: 24,
                  zIndex: 1000,
                }}
              >
                <div
                  onClick={(e) => e.stopPropagation()}
                  style={{
                    width: "min(1240px, 96vw)",
                    maxHeight: "90vh",
                    overflow: "auto",
                    background: "#fff",
                    borderRadius: 22,
                    boxShadow: "0 24px 80px rgba(15, 23, 42, 0.22)",
                    padding: 18,
                    display: "grid",
                    gap: 16,
                  }}
                >
                  <div className="row" style={{ justifyContent: "space-between", alignItems: "flex-start", gap: 12, flexWrap: "wrap" }}>
                    <div style={{ display: "grid", gap: 4 }}>
                      <div style={{ fontSize: 22, fontWeight: 900, wordBreak: "break-word" }}>{activeTreeDestinationCard.destinationName}</div>
                      <div style={{ fontSize: 13, opacity: 0.72 }}>
                        Open a channel to see its creatives in flow style. This keeps the popup shorter and easier for clients to scan.
                      </div>
                    </div>
                    <div className="row" style={{ gap: 8, flexWrap: "wrap", alignItems: "center" }}>
                      <span style={{ fontSize: 12, padding: "6px 10px", borderRadius: 999, background: "#f7f9ff", border: "1px solid #dfe5f3" }}>
                        {activeTreeChannels.length} channel{activeTreeChannels.length === 1 ? "" : "s"}
                      </span>
                      <span style={{ fontSize: 12, padding: "6px 10px", borderRadius: 999, background: "#f7f9ff", border: "1px solid #dfe5f3" }}>
                        {visibleCreatives.length} filtered creative{visibleCreatives.length === 1 ? "" : "s"}
                      </span>
                      <span style={{ fontSize: 12, padding: "6px 10px", borderRadius: 999, background: "#f7f9ff", border: "1px solid #dfe5f3" }}>
                        {activeTreeDestinationCard.selectedRoutes} selected route{activeTreeDestinationCard.selectedRoutes === 1 ? "" : "s"}
                      </span>
                      <button
                        type="button"
                        onClick={() =>
                          setExpandedTreeChannels(
                            Object.fromEntries(activeTreeChannels.map((channel) => [`${activeTreeDestinationCard.destinationId}::${channel.id}`, true]))
                          )
                        }
                      >
                        Expand all channels
                      </button>
                      <button type="button" onClick={() => setExpandedTreeChannels({})}>
                        Collapse all channels
                      </button>
                      <button type="button" onClick={() => setTreeModalDestId(null)} aria-label="Close tree popup">
                        Close
                      </button>
                    </div>
                  </div>

                  {activeTreeDestination && activeTreeDestination.totalRoutes > 0 && (
                    <div style={{ fontSize: 12, color: "#475569", background: "#f8fbff", border: "1px solid #e4ebf7", borderRadius: 14, padding: 12 }}>
                      Already selected in this destination: {activeTreeDestination.totalRoutes} route{activeTreeDestination.totalRoutes === 1 ? "" : "s"} across {activeTreeDestination.creativeCount} creative{activeTreeDestination.creativeCount === 1 ? "" : "s"}.
                    </div>
                  )}

                  {activeTreeChannels.length === 0 ? (
                    <div style={{ opacity: 0.7 }}>No channels available for this destination.</div>
                  ) : visibleCreatives.length === 0 ? (
                    <div style={{ opacity: 0.7 }}>No creatives match the current creative filter.</div>
                  ) : (
                    <div style={{ overflowX: "auto", paddingBottom: 4 }}>
                      <div style={{ minWidth: 960, display: "grid", gap: 14 }}>
                        <div style={{ display: "grid", gridTemplateColumns: "280px 1fr", gap: 18, alignItems: "start" }}>
                          <div
                            style={{
                              borderRadius: 22,
                              padding: "20px 18px",
                              background: "linear-gradient(180deg, #eef4ff 0%, #f8fbff 100%)",
                              border: "1px solid #dbe6ff",
                              boxShadow: "0 10px 30px rgba(37, 99, 235, 0.08)",
                              fontWeight: 900,
                              textAlign: "center",
                              minHeight: 88,
                              display: "grid",
                              placeItems: "center",
                            }}
                          >
                            {activeTreeDestinationCard.destinationName}
                          </div>

                          <div style={{ position: "relative", paddingLeft: 34, display: "grid", gap: 14 }}>
                            <div style={{ position: "absolute", left: 14, top: 0, bottom: 0, borderLeft: "2px solid #d5deef" }} />
                            {activeTreeChannels.map((channel) => {
                              const treeKey = `${activeTreeDestinationCard.destinationId}::${channel.id}`;
                              const isOpen = !!expandedTreeChannels[treeKey];
                              const filteredCreativesForChannel = visibleCreatives;
                              const selectedInChannel = filteredCreativesForChannel.filter((creative) => entryMap.get(keyOf(creative.id, channel.id))?.selected).length;

                              return (
                                <div key={channel.id} style={{ position: "relative", display: "grid", gap: 10 }}>
                                  <div style={{ position: "absolute", left: -20, top: 28, width: 20, borderTop: "2px solid #d5deef" }} />
                                  <div style={{ position: "absolute", left: -24, top: 22, width: 12, height: 12, borderRadius: 999, background: isOpen ? "#4f46e5" : "#8fa4d2", boxShadow: "0 0 0 4px #fff" }} />

                                  <button
                                    type="button"
                                    onClick={() =>
                                      setExpandedTreeChannels((prev) => ({
                                        ...prev,
                                        [treeKey]: !prev[treeKey],
                                      }))
                                    }
                                    style={{
                                      width: "100%",
                                      textAlign: "left",
                                      borderRadius: 18,
                                      padding: 14,
                                      background: isOpen ? "#f8faff" : "#ffffff",
                                      border: isOpen ? "1px solid #cfdcff" : "1px solid #dde4f2",
                                      boxShadow: isOpen ? "0 10px 24px rgba(79, 70, 229, 0.08)" : "0 10px 24px rgba(15, 23, 42, 0.04)",
                                      display: "grid",
                                      gap: 6,
                                    }}
                                  >
                                    <div className="row" style={{ justifyContent: "space-between", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
                                      <div style={{ display: "grid", gap: 4, minWidth: 0 }}>
                                        <div style={{ display: "grid", gap: 4 }}>
                                          <div style={{ fontWeight: 800, fontSize: 15, wordBreak: "break-word" }}>{channelDisplayName(channel)}</div>
                                          {channelMetaLabel(channel) ? <div style={{ fontSize: 11, color: "#1d4ed8", fontWeight: 700 }}>{channelMetaLabel(channel)}</div> : null}
                                          <div style={{ fontSize: 12, opacity: 0.72 }}>
                                            {selectedInChannel} of {filteredCreativesForChannel.length} filtered creative{filteredCreativesForChannel.length === 1 ? "" : "s"} selected
                                          </div>
                                        </div>
                                      </div>
                                      <div className="row" style={{ gap: 8, flexWrap: "wrap", alignItems: "center" }}>
                                        <span style={{ fontSize: 11, borderRadius: 999, padding: "4px 8px", background: "#f8fafc", border: "1px solid #e2e8f0" }}>
                                          {isOpen ? "Expanded" : "Collapsed"}
                                        </span>
                                        <span style={{ fontSize: 20, lineHeight: 1 }}>{isOpen ? "▾" : "▸"}</span>
                                      </div>
                                    </div>
                                  </button>

                                  {isOpen && (
                                    <div style={{ position: "relative", marginLeft: 34, paddingLeft: 26, display: "grid", gap: 10 }}>
                                      <div style={{ position: "absolute", left: 0, top: 0, bottom: 0, borderLeft: "2px solid #dde4f2" }} />
                                      {filteredCreativesForChannel.map((creative, creativeIndex) => {
                                        const k = keyOf(creative.id, channel.id);
                                        const entry = entryMap.get(k) ?? { creativeId: creative.id, channelId: channel.id, selected: false, slaId: null, locked: false };
                                        const displayCode = (creative.valid || creative.caption || creative.id || "").trim() || creative.id;
                                        const caption = (creative.caption || "").trim();
                                        const selected = !!entry.selected;
                                        const locked = !!entry.locked;

                                        return (
                                          <div key={k} style={{ position: "relative", display: "grid", gap: 0 }}>
                                            <div style={{ position: "absolute", left: -26, top: 44, width: 26, borderTop: "2px solid #e3e8f4" }} />
                                            <div style={{ position: "absolute", left: -30, top: 38, width: 8, height: 8, borderRadius: 999, background: selected ? "#4f46e5" : "#c7d2e8" }} />
                                            {creativeIndex < filteredCreativesForChannel.length - 1 && (
                                              <div style={{ position: "absolute", left: -26, top: 44, bottom: -10, borderLeft: "2px solid #e3e8f4" }} />
                                            )}

                                            <div
                                              style={{
                                                borderRadius: 18,
                                                padding: 12,
                                                background: selected ? "#f8faff" : "#ffffff",
                                                border: selected ? "1px solid #cfdcff" : "1px solid #e7ebf4",
                                                boxShadow: selected ? "0 8px 20px rgba(79, 70, 229, 0.08)" : "none",
                                                display: "grid",
                                                gap: 10,
                                                minWidth: 0,
                                              }}
                                            >
                                              <div className="plannerChannelCardRow">
                                                <label className="row plannerChannelCardMain" style={{ gap: 10, alignItems: "flex-start", cursor: locked ? "not-allowed" : "pointer" }}>
                                                  <input
                                                    type="checkbox"
                                                    checked={selected}
                                                    disabled={busy || locked || !canEdit}
                                                    onChange={(ev) => setCell(creative.id, channel.id, { selected: ev.target.checked })}
                                                    style={{ marginTop: 3 }}
                                                  />
                                                  <div style={{ display: "grid", gap: 4, minWidth: 0 }}>
                                                    <div style={{ fontWeight: 800, wordBreak: "break-word" }}>{displayCode}</div>
                                                    {caption && caption !== displayCode && (
                                                      <div style={{ fontSize: 13, opacity: 0.78, wordBreak: "break-word" }}>{caption}</div>
                                                    )}
                                                    <div className="row" style={{ gap: 6, flexWrap: "wrap" }}>
                                                      <span style={{ fontSize: 11, borderRadius: 999, padding: "4px 8px", background: "#f1f5f9", border: "1px solid #e2e8f0" }}>
                                                        {getCreativeCodeLabel(me)}
                                                      </span>
                                                      {creative.duration && (
                                                        <span style={{ fontSize: 11, borderRadius: 999, padding: "4px 8px", background: "#f8fafc", border: "1px solid #e2e8f0" }}>
                                                          {creative.duration}
                                                        </span>
                                                      )}
                                                      {locked && (
                                                        <span style={{ fontSize: 11, borderRadius: 999, padding: "4px 8px", background: "#fff7ed", border: "1px solid #fed7aa" }}>
                                                          Committed
                                                        </span>
                                                      )}
                                                    </div>
                                                  </div>
                                                </label>

                                                <div className="plannerChannelCardControls">
                                                  <div className="plannerChannelCardControl plannerChannelCardControl--sla">
                                                    <div style={{ fontSize: 11, opacity: 0.65 }}>SLA</div>
                                                  <select
                                                    value={entry.slaId || ""}
                                                    disabled={busy || locked || !canEdit || !selected}
                                                    onChange={(ev) => setCell(creative.id, channel.id, { selected: true, slaId: ev.target.value || null })}
                                                    style={{ width: "100%" }}
                                                  >
                                                    <option value="">SLA…</option>
                                                    {data?.slas.map((sla) => (
                                                      <option key={sla.id} value={sla.id}>
                                                        {sla.name}
                                                      </option>
                                                    ))}
                                                  </select>
                                                  </div>
                                                  <div className="plannerChannelCardControl plannerChannelCardControl--logo">
                                                    <div style={{ fontSize: 11, opacity: 0.65 }}>Logo</div>
                                                  <select
                                                    value={channel.alignment || ""}
                                                    disabled={busy || !canEdit || !!logoBusyChannelIds[channel.id]}
                                                    onChange={(ev) => updateChannelLogoPosition(channel.id, (ev.target.value as "" | LogoPosition) || "")}
                                                    className="plannerLogoSelectCompact"
                                                  >
                                                    <option value="">Logo…</option>
                                                    {LOGO_POSITION_OPTIONS.map((option) => (
                                                      <option key={option} value={option}>
                                                        {option}
                                                      </option>
                                                    ))}
                                                  </select>
                                                  </div>
                                                </div>
                                              </div>
                                            </div>
                                          </div>
                                        );
                                      })}
                                    </div>
                                  )}
                                </div>
                              );
                            })}
                          </div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>

        ) : (
          <div style={{ display: "grid", gridTemplateColumns: "300px 1fr", minHeight: 420 }}>
            {/* Left: destination tree */}
            <div style={{ borderRight: "1px solid #eee", padding: 12, display: "grid", gap: 10 }}>
              <div style={{ display: "grid", gap: 6 }}>
                <div style={{ fontWeight: 800 }}>Destinations</div>
                <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search destination / channel…" />
              </div>

              <div className="row" style={{ gap: 6, flexWrap: "wrap" }}>
                <button onClick={() => setDestFilter("ALL")} style={destFilter === "ALL" ? { background: "#eef" } : undefined}>
                  All
                </button>
                <button onClick={() => setDestFilter("USED")} style={destFilter === "USED" ? { background: "#eef" } : undefined}>
                  Used
                </button>
                <button onClick={() => setDestFilter("UNUSED")} style={destFilter === "UNUSED" ? { background: "#eef" } : undefined}>
                  Unused
                </button>
              </div>

              <div style={{ display: "grid", gap: 6, overflowY: "auto", maxHeight: 520 }}>
                {filteredDestinations.map((d) => {
                  const did = d.id;
                  const title = did === "UNASSIGNED" ? "UNASSIGNED" : d.name;
                  const chs = channelsByDest.get(did) || [];
                  if (!chs.length) return null;
                  const isUsed = usedDestIds.has(did);
                  const isExpanded = !!expanded[did];
                  return (
                    <div key={did} style={{ border: "1px solid #eee", borderRadius: 10, padding: 8 }}>
                      <div className="row" style={{ justifyContent: "space-between", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
                        <button onClick={() => toggleExpand(did)} title={isExpanded ? "Collapse" : "Expand"} style={{ width: 34, height: 28, padding: 0 }}>
                          {isExpanded ? "–" : "+"}
                        </button>

                        <div style={{ flex: 1, marginLeft: 8 }}>
                          <div style={{ fontWeight: 800, display: "flex", gap: 8, alignItems: "center" }}>
                            <span>{title}</span>
                            {isUsed && (
                              <span
                                style={{
                                  fontSize: 11,
                                  padding: "2px 6px",
                                  borderRadius: 999,
                                  background: "#e9fff1",
                                  border: "1px solid #39d353",
                                }}
                              >
                                USED
                              </span>
                            )}
                          </div>
                          <div style={{ fontSize: 12, opacity: 0.7 }}>{chs.length} channel(s)</div>
                        </div>
                      </div>

                      {isExpanded && (
                        <div style={{ marginTop: 8, display: "grid", gap: 6 }}>
                          {chs
                            .filter((c) => (!qNorm ? true : c.name.toLowerCase().includes(qNorm)))
                            .map((c) => (
                              <div key={c.id} style={{ fontSize: 13, opacity: 0.9, paddingLeft: 10, display: "grid", gap: 2 }}>
                                <div>• {c.name}</div>
                                {channelMetaLabel(c) ? <div style={{ fontSize: 11, color: "#1d4ed8", fontWeight: 700, paddingLeft: 12 }}>{channelMetaLabel(c)}</div> : null}
                              </div>
                            ))}
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Right: selection grid */}
            <div style={{ padding: 12, overflowX: "auto" }}>
              {visibleChannels.length === 0 ? (
                <div style={{ opacity: 0.7 }}>Expand a destination on the left to show channels.</div>
              ) : (
                <table style={{ width: "100%", borderCollapse: "collapse" }}>
                  <thead>
                    <tr>
                      <th style={{ textAlign: "left", padding: 8, minWidth: 140 }}>{getCreativeCodeLabel(me)}</th>

                      {visibleChannels.map((ch) => (
                        <th key={ch.id} style={{ textAlign: "left", padding: 8, minWidth: 240 }}>
                          <div style={{ display: "grid", gap: 6 }}>
                            <div style={{ fontWeight: 800 }}>{channelDisplayName(ch)}</div>
                            {channelMetaLabel(ch) ? <div style={{ fontSize: 11, color: "#1d4ed8", fontWeight: 700 }}>{channelMetaLabel(ch)}</div> : null}
                            <div style={{ fontSize: 11, opacity: 0.7 }}>
                              {(ch.destinationId ? destinationsById.get(ch.destinationId)?.name : "UNASSIGNED") || "UNASSIGNED"}
                            </div>
                            <select
                              value={ch.alignment || ""}
                              disabled={busy || !canEdit || !!logoBusyChannelIds[ch.id]}
                              onChange={(ev) => updateChannelLogoPosition(ch.id, (ev.target.value as "" | LogoPosition) || "")}
                              className="plannerLogoSelectCompact"
                            >
                              <option value="">Logo…</option>
                              {LOGO_POSITION_OPTIONS.map((option) => (
                                <option key={option} value={option}>
                                  {option}
                                </option>
                              ))}
                            </select>
                          </div>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {visibleCreatives.map((cr) => (
                      <tr key={cr.id} style={{ borderTop: "1px solid #eee" }}>
                        <td style={{ padding: 8, fontWeight: 800 }}>{cr.valid}</td>

                        {visibleChannels.map((ch) => {
                          const e = entryMap.get(keyOf(cr.id, ch.id));
                          const selected = !!e?.selected;
                          const locked = !!e?.locked;

                          return (
                            <td key={ch.id} style={{ padding: 8, verticalAlign: "top", opacity: locked ? 0.7 : 1 }}>
                              <div style={{ display: "grid", gap: 6 }}>
                                <label className="row" style={{ gap: 8 }}>
                                  <input
                                    type="checkbox"
                                    checked={selected}
                                    disabled={busy || locked || !canEdit}
                                    onChange={(ev) => setCell(cr.id, ch.id, { selected: ev.target.checked })}
                                  />
                                  <span style={{ fontSize: 12 }}>{locked ? "Committed (locked)" : selected ? "Selected" : "Select"}</span>
                                </label>

                                {selected && (() => {
                                  const k = keyOf(cr.id, ch.id);
                                  const sla = e?.slaId ? slasById.get(e.slaId) : null;
                                  const slaName = slaChipLabel(sla);
                                  const short = slaName.length > 18 ? slaName.slice(0, 18) + "…" : slaName;
                                  const editing = editSlaKey === k;
                                  return editing ? (
                                    <select
                                      value={e?.slaId || ""}
                                      disabled={busy || locked || !canEdit}
                                      onBlur={() => setEditSlaKey(null)}
                                      onChange={(ev) => {
                                        const slaId = ev.target.value || null;
                                        setCell(cr.id, ch.id, { selected: true, slaId });
                                        setEditSlaKey(null);
                                      }}
                                      autoFocus
                                    >
                                      <option value="">SLA…</option>
                                      {data.slas.map((s) => (
                                        <option key={s.id} value={s.id}>
                                          {s.name}
                                        </option>
                                      ))}
                                    </select>
                                  ) : (
                                    <button
                                      type="button"
                                      disabled={busy || locked || !canEdit}
                                      onClick={() => setEditSlaKey(k)}
                                      title={slaChipTitle(sla)}
                                      style={{
                                        textAlign: "left",
                                        padding: "6px 10px",
                                        borderRadius: 999,
                                        border: "1px solid #ddd",
                                        background: "#fff",
                                        fontSize: 12,
                                        cursor: busy || locked || !canEdit ? "not-allowed" : "pointer",
                                      }}
                                    >
                                      {short}
                                    </button>
                                  );
                                })()}
                              </div>
                            </td>
                          );
                        })}
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
