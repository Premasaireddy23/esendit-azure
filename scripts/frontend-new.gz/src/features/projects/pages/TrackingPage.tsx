import { useEffect, useMemo, useRef, useState } from "react";
import { useOutletContext, useParams } from "react-router-dom";
import { api } from "../../../lib/api";
import { getMe, hasPerm, type MeResponse } from "../../../lib/me";
import { StatusPill } from "../../../ui/StatusPill";
import { AppModal } from "../../../ui/AppModal";
import { PresetDownloadModal } from "../../presets/PresetDownloadModal";
import { getAssetStreamUrl } from "../creatives/creativesApi";
import { ProjectNotificationsPanel } from "../notifications/ProjectNotificationsPanel";

type RawRow = {
  taskId: string;
  orderId: string;
  projectId: string;
  planLineId: string;
  creativeId: string;
  creativeName: string;

  projectNumber?: string;
  projectName?: string;

  advertiserGroup?: string | null;
  advertiser?: string | null;
  brand?: string | null;
  productCategory?: string | null;

  mediaAgency?: string | null;
  mediaAgencyTeam?: string | null;
  creativeAgency?: string | null;
  creativeAgencyTeam?: string | null;
  productionHouse?: string | null;
  productionHouseTeam?: string | null;
  postHouse?: string | null;
  postHouseTeam?: string | null;
  audioAgency?: string | null;
  audioAgencyTeam?: string | null;

  billableParty?: string | null;

  destinationId: string | null;
  destinationName: string;
  receiverAccountId?: string | null;
  receiverAccountName?: string | null;
  receiverCategory?: string | null;
  channelId: string;
  channelName: string;
  channelServerStatus?: string | null;
  channelServerMessage?: string | null;

  slaId: string | null;
  slaName: string | null;

  status: string;
  attempts: number;
  maxAttempts: number;
  forceBackup: boolean;
  failoverUsed: boolean;

  runAfter: string | null;
  startedAt: string | null;
  endedAt: string | null;
  createdAt: string;
  updatedAt: string;

  remotePath: string | null;
  bytesSent: string | null;
  lastError: string | null;

  uploaderEmail?: string | null;
  uploadedAt?: string | null;

  caption?: string | null;
  duration?: string | null;
  languages?: string[];
  format?: string | null;
  audio?: string | null;
  filename?: string | null;
  mimeType?: string | null;
  fileSizeBytes?: string | null;
  sourceAssetType?: string | null;
  sourceAssetFilename?: string | null;

  qcStatus?: string | null;
  qcFailureReasons?: string[];

  approvalStatus?: string | null;
  approvalStep1Label?: string | null;
  approvalStep1Status?: string | null;
  approvalStep1DecidedBy?: string | null;
  approvalStep2Label?: string | null;
  approvalStep2Status?: string | null;
  approvalStep2DecidedBy?: string | null;

  deliveryApprovalRequired?: boolean;
  deliveryApprovalStatus?: string | null;
  deliveryHouseId?: string | null;
  deliveryStagingRemotePath?: string | null;
  deliveryFinalRemotePath?: string | null;
};

type GroupRow = {
  key: string;
  orderId: string;
  projectId: string;
  projectNumber?: string;
  projectName?: string;

  creativeId: string;
  valid: string;
  caption?: string | null;
  duration?: string | null;
  languages: string[];
  format?: string | null;
  audio?: string | null;
  filename?: string | null;
  mimeType?: string | null;
  fileSizeBytes?: number | null;
  sourceAssetType?: string | null;
  sourceAssetFilename?: string | null;
  uploaderEmail?: string | null;
  uploadedAt?: string | null;

  qcStatus?: string | null;
  qcFailureReasons?: string[];

  approvalStatus?: string | null;
  approvalStep1Label?: string | null;
  approvalStep1Status?: string | null;
  approvalStep1DecidedBy?: string | null;
  approvalStep2Label?: string | null;
  approvalStep2Status?: string | null;
  approvalStep2DecidedBy?: string | null;

  deliveryApprovalRequired?: boolean;
  deliveryApprovalStatus?: string | null;
  deliveryHouseId?: string | null;
  deliveryStagingRemotePath?: string | null;
  deliveryFinalRemotePath?: string | null;

  advertiserGroup?: string | null;
  advertiser?: string | null;
  brand?: string | null;
  productCategory?: string | null;

  mediaAgency?: string | null;
  mediaAgencyTeam?: string | null;
  creativeAgency?: string | null;
  creativeAgencyTeam?: string | null;
  productionHouse?: string | null;
  productionHouseTeam?: string | null;
  postHouse?: string | null;
  postHouseTeam?: string | null;
  audioAgency?: string | null;
  audioAgencyTeam?: string | null;

  billableParty?: string | null;

  destinationId: string | null;
  destinationName: string;
  receiverAccountId?: string | null;
  receiverAccountName?: string | null;
  receiverCategory?: string | null;
  slaName: string | null;

  channels: { id: string; name: string; serverStatus?: string | null; serverMessage?: string | null }[];
  taskIds: string[];
  tasks: RawRow[];

  status: string;
  attempts: number;
  maxAttempts: number;
  sentAt: string | null;
  startedAt: string | null;
  deliveredAt: string | null;
  progressPct: number | null;
  timeToDeliverSec: number | null;
};

type Rule = {
  id: string;
  field:
    | "status"
    | "destinationName"
    | "slaName"
    | "channels"
    | "valid"
    | "projectName"
    | "advertiser"
    | "brand";
  op: "contains" | "equals";
  value: string;
  color: string;
};

type OnDemandTranscodeRow = Pick<GroupRow, "valid" | "creativeId" | "destinationId">;

type TrackingActionItem = {
  label: string;
  onClick?: () => void | Promise<void>;
  disabled?: boolean;
  danger?: boolean;
};

type TrackingActionsModalState = {
  title: string;
  subtitle?: string;
  items: TrackingActionItem[];
};

type ColKey =
  | "projectName"
  | "projectNumber"
  | "valid"
  | "caption"
  | "duration"
  | "languages"
  | "format"
  | "audio"
  | "productCategory"
  | "advertiserGroup"
  | "advertiser"
  | "brand"
  | "mediaAgency"
  | "creativeAgency"
  | "postHouse"
  | "audioAgency"
  | "productionHouse"
  | "slaName"
  | "destinationName"
  | "channels"
  | "uploadedAt"
  | "sentAt"
  | "deliveredAt"
  | "status"
  | "progress"
  | "timeToDeliver"
  | "fileSize"
  | "filename"
  | "qc"
  | "qcAction"
  | "approvals"
  | "serverStatus"
  | "billableParty"
  | "actions";

const PAGE_KEY = "tracking";
const LS_KEY_COLS = "esendit_pref_tracking_columns_v1";
const LS_KEY_RULES = "esendit_pref_tracking_rules_v1";
const LS_KEY_VIEWMODE = "esendit_pref_tracking_view_mode_v1";
const ENFORCED_VIEW_MODE: "CHANNELS" = "CHANNELS";

const COLORS = [
  "#fff7ed", // orange-50
  "#ecfeff", // cyan-50
  "#f0fdf4", // green-50
  "#fdf2f8", // pink-50
  "#eef2ff", // indigo-50
  "#fef9c3", // yellow-100
  "#fee2e2", // red-100
];

function fmtDateTime(iso?: string | null) {
  if (!iso) return "";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "";
  return d.toLocaleString();
}

function fmtSeconds(sec: number | null) {
  if (sec == null || !Number.isFinite(sec)) return "";
  const s = Math.max(0, Math.floor(sec));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const r = s % 60;
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${pad(h)}:${pad(m)}:${pad(r)}`;
}

function fmtBytes(n?: number | null) {
  if (n == null || !Number.isFinite(n)) return "";
  const u = ["B", "KB", "MB", "GB", "TB"];
  let i = 0;
  let x = n;
  while (x >= 1024 && i < u.length - 1) {
    x /= 1024;
    i += 1;
  }
  return `${x.toFixed(x >= 10 || i === 0 ? 0 : 1)} ${u[i]}`;
}

function numOrNull(value: any) {
  const n = Number(value);
  return Number.isFinite(n) ? n : null;
}

function fmtRounded(value: number, digits = 1) {
  return value.toFixed(digits).replace(/\.0+$/, "").replace(/(\.\d*[1-9])0+$/, "$1");
}

function fmtFriendlyDuration(sec?: number | null) {
  if (sec == null || !Number.isFinite(sec)) return "";
  const whole = Math.max(0, Math.round(sec));
  const mins = Math.floor(whole / 60);
  const secs = whole % 60;
  if (mins > 0 && secs > 0) return `${mins} min ${secs} sec`;
  if (mins > 0) return `${mins} min`;
  return `${secs} sec`;
}

function fmtFriendlyBitrate(bps?: number | null) {
  if (bps == null || !Number.isFinite(bps) || bps <= 0) return "";
  if (bps >= 1000 * 1000) return `${fmtRounded(bps / (1000 * 1000))} Mbps`;
  if (bps >= 1000) return `${fmtRounded(bps / 1000)} kbps`;
  return `${fmtRounded(bps)} bps`;
}

function resolutionLabel(width?: number | null, height?: number | null) {
  if (!width || !height) return "";
  const w = Number(width);
  const h = Number(height);
  if (w >= 3840 || h >= 2160) return "4K";
  if (w >= 1920 || h >= 1080) return "Full HD";
  if (w >= 1280 || h >= 720) return "HD";
  if (w >= 720 || h >= 576) return "SD";
  return "Custom size";
}

function friendlyFrameRateLabel(frameRate?: any) {
  const fps = numOrNull(frameRate);
  if (fps == null || fps <= 0) return "";
  if (Math.abs(fps - 25) < 0.2) return "25 fps (standard broadcast speed)";
  if (Math.abs(fps - 24) < 0.2) return "24 fps (cinema-style motion)";
  if (Math.abs(fps - 30) < 0.2 || Math.abs(fps - 29.97) < 0.05) return "30 fps (standard video motion)";
  if (Math.abs(fps - 50) < 0.2 || Math.abs(fps - 60) < 0.2 || Math.abs(fps - 59.94) < 0.05) return `${fmtRounded(fps, 2)} fps (smooth motion)`;
  return `${fmtRounded(fps, 2)} fps`;
}

function friendlyChannelLabel(channels?: any) {
  const n = numOrNull(channels);
  if (n == null || n <= 0) return "";
  if (n === 1) return "Mono (single audio channel)";
  if (n === 2) return "Stereo (left and right audio)";
  if (n === 6) return "5.1 surround sound";
  if (n === 8) return "7.1 surround sound";
  return `${n} audio channels`;
}

function friendlyScanType(scanType?: string | null) {
  const v = String(scanType || "").toLowerCase();
  if (!v) return "";
  if (v.includes("progressive")) return "Progressive (cleaner on modern screens)";
  if (v.includes("interlaced")) return "Interlaced (older broadcast style)";
  return scanType || "";
}

function simpleCodecName(codec?: string | null, codecLongName?: string | null) {
  return String(codecLongName || codec || "").replace(/\s*\([^)]*\)\s*/g, " ").replace(/\s+/g, " ").trim();
}

function buildClientFriendlySummary(deliveredFormat: any, videoStreams: any[], audioStreams: any[]) {
  const video = videoStreams[0] || null;
  const audio = audioStreams[0] || null;
  const formatName = deliveredFormat?.containerLongName || deliveredFormat?.container || "Video file";
  const duration = fmtFriendlyDuration(numOrNull(deliveredFormat?.durationSeconds) ?? numOrNull(video?.durationSeconds) ?? numOrNull(audio?.durationSeconds));
  const resolution = video?.width && video?.height ? `${video.width} × ${video.height}${resolutionLabel(video.width, video.height) ? ` (${resolutionLabel(video.width, video.height)})` : ""}` : "";
  const frameRate = friendlyFrameRateLabel(video?.frameRate);
  const aspect = video?.displayAspectRatio ? `${video.displayAspectRatio} widescreen` : "";
  const sound = friendlyChannelLabel(audio?.channels) || audio?.channelLayout || "";
  const bitrate = fmtFriendlyBitrate(numOrNull(deliveredFormat?.bitRate) ?? numOrNull(video?.bitRate));

  return [
    ["File type", formatName],
    ["Length", duration],
    ["Picture size", resolution],
    ["Motion", frameRate],
    ["Screen shape", aspect],
    ["Sound", sound],
    ["Quality / data rate", bitrate],
  ].filter(([, value]) => String(value || "").trim() !== "");
}

function mediaInfoTracks(mediaInfo: any, type?: string) {
  const tracks = Array.isArray(mediaInfo?.media?.track) ? mediaInfo.media.track : [];
  if (!type) return tracks;
  const want = String(type || "").toLowerCase();
  return tracks.filter((track: any) => String(track?.["@type"] || track?.["@Type"] || track?.type || "").toLowerCase() === want);
}

function mediaInfoTrack(mediaInfo: any, type: string, index = 0) {
  return mediaInfoTracks(mediaInfo, type)[index] || null;
}

function mediaInfoValue(track: any, ...keys: string[]) {
  for (const key of keys) {
    const value = track?.[key];
    if (value === 0 || value === "0") return String(value);
    if (value !== null && value !== undefined) {
      const str = String(value).trim();
      if (str) return str;
    }
  }
  return "";
}

function mediaInfoRows(track: any, defs: Array<[string, string[]]>): Array<[string, string]> {
  return defs
    .map(([label, keys]) => [label, mediaInfoValue(track, ...keys)] as [string, string])
    .filter(([, value]) => String(value || "").trim() !== "");
}

function mediaInfoAllRows(track: any): Array<[string, string]> {
  if (!track || typeof track !== "object") return [];
  const rows: Array<[string, string]> = [];
  for (const [key, value] of Object.entries(track)) {
    if (key === "extra") continue;
    if (value === null || value === undefined) continue;
    if (typeof value === "object") continue;
    const str = String(value).trim();
    if (!str) continue;
    rows.push([key, str]);
  }
  if (track?.extra && typeof track.extra === "object") {
    for (const [key, value] of Object.entries(track.extra)) {
      if (value === null || value === undefined) continue;
      const str = String(value).trim();
      if (!str) continue;
      rows.push([`extra.${key}`, str]);
    }
  }
  return rows;
}

type StreamAssetType = "SOURCE" | "PROXY" | "OUTPUT";

function normalizeStreamAssetType(value?: string | null): StreamAssetType | null {
  const v = String(value || "").toUpperCase();
  return v === "SOURCE" || v === "PROXY" || v === "OUTPUT" ? (v as StreamAssetType) : null;
}

function isProbablyBrowserPlayable(type: StreamAssetType, mimeType?: string | null, filename?: string | null) {
  if (type === "PROXY") return true;
  const mt = String(mimeType || "").toLowerCase();
  const name = String(filename || "").toLowerCase();
  if (mt.includes("mp4") || mt.includes("webm") || mt.includes("ogg")) return true;
  return /\.(mp4|m4v|mov|webm|ogv|ogg)$/i.test(name);
}

function inferPreviewAssetType(row: Pick<GroupRow, "sourceAssetType" | "filename" | "mimeType">): StreamAssetType {
  const explicit = normalizeStreamAssetType(row.sourceAssetType);
  if (explicit) return explicit;
  const name = String(row.filename || "").toLowerCase();
  if (name.includes(".proxy.")) return "PROXY";
  if (isProbablyBrowserPlayable("OUTPUT", row.mimeType, row.filename)) return "OUTPUT";
  return "OUTPUT";
}

function previewAssetLabel(row: Pick<GroupRow, "sourceAssetType" | "filename" | "mimeType">) {
  return `Sent file (${inferPreviewAssetType(row)})`;
}

function sortTaskRows(tasks: RawRow[]) {
  return [...(Array.isArray(tasks) ? tasks : [])].sort((a, b) =>
    String(a?.channelName || "").localeCompare(String(b?.channelName || ""))
  );
}

function toSingleGroupRow(r: RawRow): GroupRow {
  const fileSizeBytes = r.fileSizeBytes ? Number(r.fileSizeBytes) : null;
  const bytesSent = r.bytesSent ? Number(r.bytesSent) : null;

  return {
    key: `task:${r.taskId}`,
    orderId: r.orderId,
    projectId: r.projectId,
    projectNumber: r.projectNumber,
    projectName: r.projectName,

    creativeId: r.creativeId,
    valid: r.creativeName,
    caption: r.caption,
    duration: r.duration,
    languages: Array.isArray(r.languages) ? r.languages : [],
    format: r.format,
    audio: r.audio,
    filename: r.filename,
    mimeType: r.mimeType,
    fileSizeBytes,
    sourceAssetType: r.sourceAssetType,
    sourceAssetFilename: r.sourceAssetFilename,
    uploaderEmail: r.uploaderEmail,
    uploadedAt: r.uploadedAt,

    qcStatus: r.qcStatus,
    qcFailureReasons: r.qcFailureReasons,

    approvalStatus: r.approvalStatus,
    approvalStep1Label: r.approvalStep1Label,
    approvalStep1Status: r.approvalStep1Status,
    approvalStep1DecidedBy: r.approvalStep1DecidedBy,
    approvalStep2Label: r.approvalStep2Label,
    approvalStep2Status: r.approvalStep2Status,
    approvalStep2DecidedBy: r.approvalStep2DecidedBy,

    deliveryApprovalRequired: r.deliveryApprovalRequired,
    deliveryApprovalStatus: r.deliveryApprovalStatus,
    deliveryHouseId: r.deliveryHouseId,
    deliveryStagingRemotePath: r.deliveryStagingRemotePath,
    deliveryFinalRemotePath: r.deliveryFinalRemotePath,

    advertiserGroup: r.advertiserGroup,
    advertiser: r.advertiser,
    brand: r.brand,
    productCategory: r.productCategory,

    mediaAgency: r.mediaAgency,
    mediaAgencyTeam: r.mediaAgencyTeam,
    creativeAgency: r.creativeAgency,
    creativeAgencyTeam: r.creativeAgencyTeam,
    productionHouse: r.productionHouse,
    productionHouseTeam: r.productionHouseTeam,
    postHouse: r.postHouse,
    postHouseTeam: r.postHouseTeam,
    audioAgency: r.audioAgency,
    audioAgencyTeam: r.audioAgencyTeam,

    billableParty: r.billableParty,

    destinationId: r.destinationId,
    destinationName: r.destinationName,
    receiverAccountId: r.receiverAccountId,
    receiverAccountName: r.receiverAccountName,
    receiverCategory: r.receiverCategory,
    slaName: r.slaName,

    channels: [
      {
        id: r.channelId,
        name: r.channelName,
        serverStatus: r.channelServerStatus,
        serverMessage: r.channelServerMessage,
      },
    ],
    taskIds: [r.taskId],
    tasks: [r],

    status: effectiveTaskStatus(r),
    attempts: r.attempts,
    maxAttempts: r.maxAttempts,

    sentAt: r.createdAt || null,
    startedAt: r.startedAt,
    deliveredAt: r.endedAt,

    progressPct:
      fileSizeBytes && bytesSent != null ? Math.min(100, Math.round((bytesSent / fileSizeBytes) * 100)) : null,
    timeToDeliverSec:
      r.startedAt && r.endedAt ? (new Date(r.endedAt).getTime() - new Date(r.startedAt).getTime()) / 1000 : null,
  };
}

// --- Delivery task status helpers ---
// In our worker, a task may remain QUEUED even after a failed attempt (it will retry later).
// For Tracking UX, show this as FAILED so operators immediately see the error.
function effectiveTaskStatus(t: { status?: string | null; lastError?: string | null; attempts?: number; maxAttempts?: number; runAfter?: string | null; deliveryApprovalStatus?: string | null; deliveryApprovalRequired?: boolean }) {
  const s = String(t?.status || "UNKNOWN").toUpperCase();
  const approvalStatus = String((t as any)?.deliveryApprovalStatus || "").toUpperCase();
  const approvalRequired = (t as any)?.deliveryApprovalRequired === true;
  const hasErr = !!(t as any)?.lastError;
  const attempts = typeof (t as any)?.attempts === "number" ? (t as any).attempts : 0;
  const max = typeof (t as any)?.maxAttempts === "number" ? (t as any).maxAttempts : 0;

  if (approvalRequired && s === "PAUSED" && approvalStatus === "WAITING") return "WAITING_APPROVAL";
  if (s === "QUEUED" && hasErr && attempts > 0) return "FAILED";
  if ((s === "UNKNOWN" || !s) && hasErr) return "FAILED";
  if (hasErr && max > 0 && attempts >= max && !["SUCCESS", "CANCELLED"].includes(s)) return "FAILED";
  return s;
}

function taskStatusTitle(t: { status?: string | null; lastError?: string | null; runAfter?: string | null; attempts?: number; maxAttempts?: number; deliveryApprovalStatus?: string | null; deliveryApprovalRequired?: boolean; deliveryHouseId?: string | null; deliveryStagingRemotePath?: string | null; deliveryFinalRemotePath?: string | null }) {
  const s = String(t?.status || "").toUpperCase();
  const eff = effectiveTaskStatus(t as any);
  const err = (t as any)?.lastError ? String((t as any).lastError) : "";
  const ra = (t as any)?.runAfter ? fmtDateTime((t as any).runAfter) : "";
  const attempts = typeof (t as any)?.attempts === "number" ? (t as any).attempts : 0;
  const max = typeof (t as any)?.maxAttempts === "number" ? (t as any).maxAttempts : 0;

  if (eff === "WAITING_APPROVAL") {
    return [
      (t as any)?.deliveryStagingRemotePath ? `Staging path: ${(t as any).deliveryStagingRemotePath}` : "Waiting for receiver approval",
      (t as any)?.deliveryFinalRemotePath ? `Final path: ${(t as any).deliveryFinalRemotePath}` : "",
      (t as any)?.deliveryHouseId ? `House ID: ${(t as any).deliveryHouseId}` : "",
    ].filter(Boolean).join("\n");
  }

  if (eff === "FAILED" && s === "QUEUED" && err) {
    const retryHint = ra ? `Next retry: ${ra}` : "";
    const attHint = max ? `Attempts: ${attempts}/${max}` : "";
    return [err, retryHint, attHint].filter(Boolean).join("\n");
  }
  return err || "";
}

function applyRules(row: GroupRow, rules: Rule[]) {
  const val = (k: Rule["field"]) => {
    if (k === "channels") return row.channels.map((c) => c.name).join(", ");
    return String((row as any)[k] ?? "");
  };
  for (const r of rules) {
    const left = val(r.field).toLowerCase();
    const right = (r.value || "").toLowerCase();
    if (!right) continue;
    if (r.op === "equals" && left === right) return r.color;
    if (r.op === "contains" && left.includes(right)) return r.color;
  }
  return "";
}

async function tryGetPref(key: string, lsKey: string) {
  try {
    const res: any = await api(`/auth/me/preferences/${key}`);
    const payload = res?.payload ?? res?.data ?? res;
    if (payload) return payload;
  } catch {
    // ignore
  }
  try {
    const raw = localStorage.getItem(lsKey);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

async function trySetPref(key: string, lsKey: string, payload: any) {
  try {
    localStorage.setItem(lsKey, JSON.stringify(payload));
  } catch {
    // ignore
  }
  try {
    await api(`/auth/me/preferences/${key}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ payload }),
    });
  } catch {
    // ignore
  }
}

function downloadText(filename: string, text: string, mime = "text/csv;charset=utf-8") {
  const blob = new Blob([text], { type: mime });
  const url = URL.createObjectURL(blob);
  try {
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
  } finally {
    URL.revokeObjectURL(url);
  }
}

function csvEscape(v: any) {
  const s = String(v ?? "");
  if (/[^\w .:\/-]/.test(s) || /[\n\r,\"]/g.test(s)) return `"${s.replace(/\"/g, '""')}"`;
  return s;
}

function TrackingInfoRow({ label, value }: { label: string; value: string }) {
  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "170px 1fr",
        gap: 12,
        padding: "11px 0",
        borderBottom: "1px solid #eef2f7",
        alignItems: "start",
      }}
    >
      <div style={{ fontSize: 12, fontWeight: 800, color: "#64748b", textTransform: "uppercase", letterSpacing: 0.3 }}>{label}</div>
      <div style={{ fontSize: 14, color: "#0f172a", wordBreak: "break-word" }}>{value || "—"}</div>
    </div>
  );
}

function TrackingInfoSection({ title, subtitle, rows }: { title: string; subtitle?: string; rows: Array<[string, string]> }) {
  const cleanRows = rows.filter(([, value]) => String(value || "").trim());
  if (!cleanRows.length) return null;

  return (
    <div
      style={{
        border: "1px solid #e2e8f0",
        borderRadius: 18,
        background: "linear-gradient(180deg, #ffffff 0%, #f8fafc 100%)",
        padding: 16,
        boxShadow: "0 14px 30px rgba(15,23,42,0.05)",
      }}
    >
      <div style={{ marginBottom: 10 }}>
        <div style={{ fontWeight: 900, fontSize: 16, color: "#0f172a" }}>{title}</div>
        {subtitle ? <div style={{ fontSize: 12, color: "#64748b", marginTop: 3 }}>{subtitle}</div> : null}
      </div>
      <div>
        {cleanRows.map(([label, value]) => (
          <TrackingInfoRow key={label} label={label} value={value} />
        ))}
      </div>
    </div>
  );
}

function ColumnsModal(props: {
  title: string;
  all: { key: ColKey; label: string }[];
  order: ColKey[];
  hidden: Set<ColKey>;
  onClose: () => void;
  onChange: (order: ColKey[], hidden: Set<ColKey>) => void;
}) {
  const ordered = useMemo(() => {
    const map = new Map(props.all.map((c) => [c.key, c]));
    const arr: { key: ColKey; label: string }[] = [];
    for (const k of props.order) {
      const c = map.get(k);
      if (c) arr.push(c);
    }
    for (const c of props.all) if (!arr.find((x) => x.key === c.key)) arr.push(c);
    return arr;
  }, [props.all, props.order]);

  function move(key: ColKey, dir: -1 | 1) {
    const idx = ordered.findIndex((c) => c.key === key);
    const next = ordered.map((c) => c.key);
    const j = idx + dir;
    if (idx < 0 || j < 0 || j >= next.length) return;
    const tmp = next[idx];
    next[idx] = next[j];
    next[j] = tmp;
    props.onChange(next, new Set(props.hidden));
  }

  function toggle(key: ColKey) {
    const next = new Set(props.hidden);
    if (next.has(key)) next.delete(key);
    else next.add(key);
    props.onChange([...ordered.map((c) => c.key)], next);
  }

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.35)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: 1000,
      }}
      onClick={props.onClose}
    >
      <div
        style={{ background: "#fff", width: 840, maxWidth: "95vw", borderRadius: 12, padding: 16 }}
        onClick={(e) => e.stopPropagation()}
      >
        <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "center" }}>
          <div style={{ fontWeight: 900, fontSize: 18 }}>{props.title}</div>
          <button className="btn" onClick={props.onClose}>
            Close
          </button>
        </div>

        <div style={{ marginTop: 12, opacity: 0.8 }}>
          Reorder columns and hide/show. (Saved to your user preferences.)
        </div>

        <div style={{ marginTop: 12, display: "grid", gap: 8, maxHeight: "70vh", overflow: "auto" }}>
          {ordered.map((c, idx) => (
            <div
              key={c.key}
              className="card"
              style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12 }}
            >
              <label style={{ display: "flex", gap: 10, alignItems: "center", cursor: "pointer" }}>
                <input type="checkbox" checked={!props.hidden.has(c.key)} onChange={() => toggle(c.key)} />
                <span style={{ fontWeight: 800 }}>{c.label}</span>
                <span style={{ opacity: 0.6, fontSize: 12 }}>({c.key})</span>
              </label>
              <div style={{ display: "flex", gap: 8 }}>
                <button className="btn" disabled={idx === 0} onClick={() => move(c.key, -1)}>
                  ↑
                </button>
                <button className="btn" disabled={idx === ordered.length - 1} onClick={() => move(c.key, 1)}>
                  ↓
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function RulesModal(props: {
  rules: Rule[];
  onClose: () => void;
  onSave: (rules: Rule[]) => void;
}) {
  const [rules, setRules] = useState<Rule[]>(props.rules || []);

  function add() {
    setRules((r) => [
      ...r,
      {
        id: String(Date.now()) + Math.random().toString(16).slice(2),
        field: "status",
        op: "contains",
        value: "FAILED",
        color: COLORS[Math.floor(Math.random() * COLORS.length)],
      },
    ]);
  }

  function remove(id: string) {
    setRules((r) => r.filter((x) => x.id !== id));
  }

  function update(id: string, patch: Partial<Rule>) {
    setRules((r) => r.map((x) => (x.id === id ? { ...x, ...patch } : x)));
  }

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.35)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: 1000,
      }}
      onClick={props.onClose}
    >
      <div
        style={{ background: "#fff", width: 980, maxWidth: "95vw", borderRadius: 12, padding: 16 }}
        onClick={(e) => e.stopPropagation()}
      >
        <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "center" }}>
          <div style={{ fontWeight: 900, fontSize: 18 }}>Row highlight rules</div>
          <div style={{ display: "flex", gap: 8 }}>
            <button className="btn" onClick={add}>
              + Add rule
            </button>
            <button className="btn" onClick={() => props.onSave(rules)}>
              Save
            </button>
            <button className="btn" onClick={props.onClose}>
              Close
            </button>
          </div>
        </div>

        <div style={{ marginTop: 12, display: "grid", gap: 10 }}>
          {rules.length === 0 ? (
            <div className="card" style={{ opacity: 0.75 }}>
              No rules yet. Add one.
            </div>
          ) : null}

          {rules.map((r) => (
            <div
              key={r.id}
              className="card"
              style={{ display: "grid", gridTemplateColumns: "1.2fr 1fr 1.4fr 1fr auto", gap: 10, alignItems: "center" }}
            >
              <div>
                <div style={{ fontWeight: 800, fontSize: 12, opacity: 0.7 }}>Field</div>
                <select
                  value={r.field}
                  onChange={(e) => update(r.id, { field: e.target.value as any })}
                  style={{ width: "100%", padding: 8 }}
                >
                  <option value="status">Status</option>
                  <option value="destinationName">Destination</option>
                  <option value="slaName">SLA</option>
                  <option value="channels">Channels</option>
                  <option value="valid">VALiD</option>
                  <option value="projectName">Project name</option>
                  <option value="advertiser">Advertiser</option>
                  <option value="brand">Brand</option>
                </select>
              </div>
              <div>
                <div style={{ fontWeight: 800, fontSize: 12, opacity: 0.7 }}>Operator</div>
                <select
                  value={r.op}
                  onChange={(e) => update(r.id, { op: e.target.value as any })}
                  style={{ width: "100%", padding: 8 }}
                >
                  <option value="contains">contains</option>
                  <option value="equals">equals</option>
                </select>
              </div>
              <div>
                <div style={{ fontWeight: 800, fontSize: 12, opacity: 0.7 }}>Value</div>
                <input
                  value={r.value}
                  onChange={(e) => update(r.id, { value: e.target.value })}
                  placeholder="Text to match"
                  style={{ width: "100%", padding: 8 }}
                />
              </div>
              <div>
                <div style={{ fontWeight: 800, fontSize: 12, opacity: 0.7 }}>Highlight</div>
                <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                  <select
                    value={r.color}
                    onChange={(e) => update(r.id, { color: e.target.value })}
                    style={{ width: "100%", padding: 8 }}
                  >
                    {COLORS.map((c) => (
                      <option key={c} value={c}>
                        {c}
                      </option>
                    ))}
                  </select>
                  <div style={{ width: 26, height: 26, borderRadius: 8, background: r.color, border: "1px solid #ddd" }} />
                </div>
              </div>
              <div style={{ display: "flex", justifyContent: "flex-end" }}>
                <button className="btn" onClick={() => remove(r.id)}>
                  Remove
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function DetailsModal(props: {
  row: GroupRow;
  canDownload: boolean;
  initialTab: "preview" | "qc";
  onClose: () => void;
}) {
  const [showDownload, setShowDownload] = useState(false);
  const [activeTab, setActiveTab] = useState<"preview" | "qc">(props.initialTab || "preview");
  const [previewUrl, setPreviewUrl] = useState<string>("");
  const [previewError, setPreviewError] = useState<string>("");
  const [previewHint, setPreviewHint] = useState<string>("");
  const [previewLoading, setPreviewLoading] = useState(false);
  const [detailsLoading, setDetailsLoading] = useState(false);
  const [detailsError, setDetailsError] = useState<string>("");
  const [detailsData, setDetailsData] = useState<any>(null);

  useEffect(() => {
    setActiveTab(props.initialTab || "preview");
  }, [props.initialTab, props.row.key]);

  const assetType = inferPreviewAssetType(props.row);
  const sentFilename = props.row.sourceAssetFilename || props.row.filename || "";
  const sentAssetLabel = previewAssetLabel(props.row);
  const detailsTaskId = useMemo(() => {
    const tasks = (props.row.tasks || []).slice().sort((a: any, b: any) => {
      const ak = String((a as any)?.updatedAt || (a as any)?.endedAt || (a as any)?.createdAt || "");
      const bk = String((b as any)?.updatedAt || (b as any)?.endedAt || (b as any)?.createdAt || "");
      return bk.localeCompare(ak);
    });

    const byStatus = (wanted: string[]) =>
      tasks.find((t: any) => wanted.includes(String(effectiveTaskStatus(t) || "").toUpperCase()));

    const preferred =
      byStatus(["SUCCESS"]) ??
      byStatus(["RUNNING", "QUEUED", "PAUSED"]) ??
      byStatus(["FAILED", "CANCELLED"]) ??
      tasks[0] ??
      null;

    return (preferred as any)?.taskId || props.row.taskIds?.[0] || null;
  }, [props.row]);

  useEffect(() => {
    setPreviewUrl("");
    setPreviewError("");
    setPreviewHint("");
    setDetailsData(null);
    setDetailsError("");
    setDetailsLoading(false);
  }, [props.row.key]);

  useEffect(() => {
    let cancelled = false;

    async function loadPreview() {
      setPreviewLoading(true);
      setPreviewError("");
      setPreviewHint("");

      try {
        if (!isProbablyBrowserPlayable(assetType, props.row.mimeType, sentFilename)) {
          try {
            const proxyUrl = await getAssetStreamUrl(props.row.creativeId, "PROXY");
            if (cancelled) return;
            setPreviewUrl(proxyUrl);
            setPreviewHint(
              `Actual sent file: ${sentFilename || assetType}. That delivery file is not directly browser-playable, so this preview is using the browser-safe proxy/reference video.`
            );
            return;
          } catch {
            if (cancelled) return;
            setPreviewUrl("");
            setPreviewHint(
              `Actual sent file: ${sentFilename || assetType}. That delivery file is not directly browser-playable, and no browser-safe preview is available for this row.`
            );
            return;
          }
        }

        const url = await getAssetStreamUrl(props.row.creativeId, assetType);
        if (cancelled) return;
        setPreviewUrl(url);
      } catch (e: any) {
        if (cancelled) return;
        setPreviewUrl("");
        setPreviewError(e?.message || String(e));
      } finally {
        if (!cancelled) setPreviewLoading(false);
      }
    }

    loadPreview();
    return () => {
      cancelled = true;
    };
  }, [assetType, props.row.creativeId, props.row.mimeType, sentFilename]);

  useEffect(() => {
    if (activeTab !== "qc") {
      setDetailsLoading(false);
      return;
    }
    if (!props.row.projectId || !detailsTaskId) {
      setDetailsData(null);
      setDetailsLoading(false);
      setDetailsError("No delivery task was available for media inspection.");
      return;
    }

    let cancelled = false;
    setDetailsLoading(true);
    setDetailsError("");
    setDetailsData(null);

    (async () => {
      try {
        const res = await api<any>(`/projects/${props.row.projectId}/tracking/${detailsTaskId}?includeDeliveredMedia=1`);
        if (cancelled) return;
        setDetailsData(
          res ?? {
            deliveredMedia: {
              error: "The server returned no media-inspection payload for this delivery task.",
            },
          }
        );
      } catch (e: any) {
        if (!cancelled) setDetailsError(e?.message || String(e));
      } finally {
        if (!cancelled) setDetailsLoading(false);
      }
    })();

    return () => {
      cancelled = true;
    };
  }, [activeTab, props.row.projectId, detailsTaskId]);

  const deliveredAsset = detailsData?.deliveredAsset || null;
  const deliveredMedia = detailsData?.deliveredMedia || null;
  const deliveredFormat = deliveredMedia?.format || null;
  const videoStreams = Array.isArray(deliveredMedia?.videoStreams) ? deliveredMedia.videoStreams : [];
  const audioStreams = Array.isArray(deliveredMedia?.audioStreams) ? deliveredMedia.audioStreams : [];
  const otherStreams = Array.isArray(deliveredMedia?.otherStreams) ? deliveredMedia.otherStreams : [];
  const mediaInfoJson = deliveredMedia?.mediaInfoJson || null;

  const miGeneral = mediaInfoTrack(mediaInfoJson, "General");
  const miVideoTracks = mediaInfoTracks(mediaInfoJson, "Video");
  const miAudioTracks = mediaInfoTracks(mediaInfoJson, "Audio");
  const miOtherTracks = mediaInfoTracks(mediaInfoJson).filter((track: any) => !["general", "video", "audio"].includes(String(track?.["@type"] || track?.["@Type"] || track?.type || "").toLowerCase()));
  const mediaInfoGeneralRows = mediaInfoRows(miGeneral, [
    ["Path", ["CompleteName", "FileNameExtension"]],
    ["Format", ["Format_Commercial_IfAny", "Format"]],
    ["Format version", ["Format_Version"]],
    ["Format profile", ["Format_Profile"]],
    ["Format settings", ["Format_Settings"]],
    ["File size", ["FileSize"]],
    ["Duration", ["Duration"]],
    ["Overall bitrate", ["OverallBitRate"]],
    ["Frame rate", ["FrameRate"]],
    ["Encoded date", ["Encoded_Date"]],
    ["Writing application", ["Encoded_Application_Name"]],
    ["Writing library", ["Encoded_Library_Name", "Encoded_Library_Version"]],
  ]);
  const mediaInfoVideoSections = miVideoTracks.map((track: any, idx: number) => ({
    title: `Video track ${idx + 1}`,
    rows: mediaInfoRows(track, [
      ["Format", ["Format_Commercial_IfAny", "Format"]],
      ["Format version", ["Format_Version"]],
      ["Format profile", ["Format_Profile", "Format_Level"]],
      ["Codec ID", ["CodecID"]],
      ["Bitrate mode", ["BitRate_Mode"]],
      ["Bitrate", ["BitRate"]],
      ["Width", ["Width"]],
      ["Height", ["Height"]],
      ["Pixel aspect ratio", ["PixelAspectRatio"]],
      ["Display aspect ratio", ["DisplayAspectRatio"]],
      ["Frame rate", ["FrameRate"]],
      ["Bit depth", ["BitDepth"]],
      ["Scan type", ["ScanType"]],
      ["Scan order", ["ScanOrder"]],
      ["Chroma subsampling", ["ChromaSubsampling"]],
      ["Color space", ["ColorSpace"]],
      ["Color primaries", ["colour_primaries"]],
      ["Transfer characteristics", ["transfer_characteristics"]],
      ["Stream size", ["StreamSize"]],
      ["Timecode first frame", ["TimeCode_FirstFrame"]],
    ]),
    allRows: mediaInfoAllRows(track),
  }));
  const mediaInfoAudioSections = miAudioTracks.map((track: any, idx: number) => ({
    title: `Audio track ${idx + 1}`,
    rows: mediaInfoRows(track, [
      ["Format", ["Format"]],
      ["Codec ID", ["CodecID"]],
      ["Duration", ["Duration"]],
      ["Bitrate mode", ["BitRate_Mode"]],
      ["Bitrate", ["BitRate"]],
      ["Channels", ["Channels"]],
      ["Sample rate", ["SamplingRate"]],
      ["Bit depth", ["BitDepth"]],
      ["Stream size", ["StreamSize"]],
      ["Language", ["Language", "Language_String3"]],
    ]),
    allRows: mediaInfoAllRows(track),
  }));
  const mediaInfoOtherSections = miOtherTracks.map((track: any, idx: number) => ({
    title: `Other track ${idx + 1}`,
    rows: mediaInfoAllRows(track),
  }));

  const meta = [
    ["Project", `${props.row.projectName || ""} (${props.row.projectNumber || ""})`],
    ["VALiD", props.row.valid],
    ["Caption", props.row.caption || ""],
    ["Duration", props.row.duration || ""],
    ["Languages", props.row.languages?.join(", ") || ""],
    ["Format", props.row.format || ""],
    ["Audio", props.row.audio || ""],
    ["Sent asset", sentAssetLabel],
    ["Filename", sentFilename],
    ["File size", fmtBytes(props.row.fileSizeBytes ?? null)],
    ["Destination", props.row.destinationName],
    ["Receiver", [props.row.receiverAccountName, props.row.receiverCategory].filter(Boolean).join(" • ")],
    ["Channels", props.row.channels.map((c) => c.name).join(", ")],
    ["SLA", props.row.slaName || ""],
    ["Uploader", props.row.uploaderEmail || ""],
  ] as const;

  const clientSummaryPairs = buildClientFriendlySummary(deliveredFormat, videoStreams, audioStreams);
  const latestTask = sortTaskRows(props.row.tasks || [])[0] || null;
  const primaryVideo = videoStreams[0] || null;
  const primaryAudio = audioStreams[0] || null;
  const mediaFilename = deliveredAsset?.filename || sentFilename || "";
  const mediaContainerLabel = [deliveredFormat?.containerLongName || deliveredFormat?.container || "", deliveredAsset?.mimeType || props.row.mimeType || ""]
    .map((v) => String(v || "").trim())
    .filter(Boolean)
    .filter((value, index, arr) => arr.indexOf(value) === index)
    .join(" • ");
  const mediaResolution = primaryVideo?.width && primaryVideo?.height
    ? `${primaryVideo.width} × ${primaryVideo.height}${resolutionLabel(primaryVideo.width, primaryVideo.height) ? ` (${resolutionLabel(primaryVideo.width, primaryVideo.height)})` : ""}`
    : "";
  const mediaAudioLabel = [friendlyChannelLabel(primaryAudio?.channels) || primaryAudio?.channelLayout || "", simpleCodecName(primaryAudio?.codec, primaryAudio?.codecLongName)]
    .map((v) => String(v || "").trim())
    .filter(Boolean)
    .filter((value, index, arr) => arr.indexOf(value) === index)
    .join(" • ");
  const mediaLanguageLabel = (Array.isArray(props.row.languages) && props.row.languages.length
    ? props.row.languages.join(", ")
    : String(primaryAudio?.language && primaryAudio?.language !== "und" ? primaryAudio.language : "").trim().toUpperCase());
  const mediaBitrate = fmtFriendlyBitrate(numOrNull(deliveredFormat?.bitRate) ?? numOrNull(primaryVideo?.bitRate) ?? numOrNull(primaryAudio?.bitRate));
  const durationLabel = props.row.duration || fmtFriendlyDuration(numOrNull(deliveredFormat?.durationSeconds) ?? numOrNull(primaryVideo?.durationSeconds) ?? numOrNull(primaryAudio?.durationSeconds));
  const qcStatusLabel = String(props.row.qcStatus || "").trim();
  const titleCase = (value?: string | null) => {
    const v = String(value || "").trim();
    if (!v) return "";
    return v.charAt(0).toUpperCase() + v.slice(1).toLowerCase();
  };
  const mediaSummaryRows: Array<[string, string]> = [
    ["Filename", mediaFilename],
    ["Container", mediaContainerLabel],
    ["Picture size", mediaResolution],
    ["Frame rate", friendlyFrameRateLabel(primaryVideo?.frameRate)],
    ["Scan type", friendlyScanType(primaryVideo?.scanType)],
    ["Video codec", simpleCodecName(primaryVideo?.codec, primaryVideo?.codecLongName)],
    ["Audio", mediaAudioLabel],
    ["Audio sample rate", primaryAudio?.sampleRate ? `${primaryAudio.sampleRate} Hz` : ""],
    ["Language", mediaLanguageLabel],
    ["Bitrate", mediaBitrate],
    ["Length", durationLabel],
    ["File size", fmtBytes(deliveredAsset?.sizeBytes ?? props.row.fileSizeBytes ?? null)],
  ];
  const librarySummaryRows: Array<[string, string]> = [
    ["VALiD", props.row.valid],
    ["Caption", props.row.caption || ""],
    ["Business format", props.row.format || ""],
    ["Languages", Array.isArray(props.row.languages) ? props.row.languages.join(", ") : ""],
    ["QC status", titleCase(qcStatusLabel)],
    ["Updated", fmtDateTime(latestTask?.updatedAt || props.row.deliveredAt || props.row.sentAt)],
    ["Created", fmtDateTime(latestTask?.createdAt || props.row.startedAt || props.row.uploadedAt)],
  ];
  const assetSummaryRows: Array<[string, string]> = [
    ["Asset type", deliveredAsset?.type || assetType || ""],
    ["Upload status", deliveredAsset?.uploadStatus || (deliveredAsset?.filename ? "UPLOADED" : "")],
    ["MIME type", deliveredAsset?.mimeType || props.row.mimeType || ""],
    ["QC checked at", fmtDateTime(latestTask?.updatedAt || deliveredAsset?.uploadEndedAt || props.row.uploadedAt)],
  ];

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.35)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: 1000,
      }}
      onClick={props.onClose}
    >
      <div
        style={{ background: "#fff", width: 1180, maxWidth: "98vw", borderRadius: 12, padding: 16 }}
        onClick={(e) => e.stopPropagation()}
      >
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12 }}>
          <div>
            <div style={{ fontWeight: 900, fontSize: 18 }}>{activeTab === "preview" ? "Preview" : "Delivered file details"} · {props.row.valid}</div>
            <div style={{ marginTop: 4, opacity: 0.7, fontSize: 12 }}>
              Showing the actual delivered asset for this tracking row: <b>{sentAssetLabel}</b>
            </div>
          </div>
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <button className="btn" onClick={() => setActiveTab("preview")} disabled={activeTab === "preview"}>
              Preview
            </button>
            <button className="btn" onClick={() => setActiveTab("qc")} disabled={activeTab === "qc"}>
              Details
            </button>
            {props.canDownload ? (
              <button className="btn btn-primary" onClick={() => setShowDownload(true)}>
                On-demand transcode
              </button>
            ) : null}
            <button className="btn" onClick={props.onClose}>
              Close
            </button>
          </div>
        </div>

        <div style={{ marginTop: 12, display: "grid", gridTemplateColumns: activeTab === "preview" ? "1.35fr 1fr" : "1fr", gap: 12 }}>
          {activeTab === "preview" ? (
            <div className="card" style={{ minHeight: 360 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 10, marginBottom: 8 }}>
                <div style={{ fontWeight: 900 }}>Video preview</div>
                <div style={{ fontSize: 12, opacity: 0.75 }}>{sentFilename || sentAssetLabel}</div>
              </div>

              <>
                {previewHint ? (
                  <div style={{ marginBottom: 10, padding: 10, borderRadius: 10, background: "#f8fafc", color: "#334155", fontSize: 13 }}>
                    {previewHint}
                  </div>
                ) : null}

                {previewLoading ? (
                  <div style={{ opacity: 0.8 }}>Loading preview…</div>
                ) : previewError ? (
                  <div style={{ color: "#a10000", whiteSpace: "pre-wrap" }}>{previewError}</div>
                ) : previewUrl ? (
                  <video controls style={{ width: "100%", borderRadius: 10, background: "#000" }} src={previewUrl} />
                ) : (
                  <div style={{ opacity: 0.75 }}>No browser preview available.</div>
                )}
              </>
            </div>
          ) : null}

          <div className="card" style={{ display: "grid", gap: 10, maxHeight: 700, overflow: activeTab === "qc" ? "auto" : undefined }}>
            {activeTab === "preview" ? (
              <>
                <div style={{ fontWeight: 900 }}>Metadata</div>
                <div style={{ display: "grid", gap: 6 }}>
                  {meta.map(([k, v]) => (
                    <div key={k} style={{ display: "grid", gridTemplateColumns: "160px 1fr", gap: 10 }}>
                      <div style={{ opacity: 0.7, fontWeight: 700 }}>{k}</div>
                      <div style={{ fontWeight: 700, wordBreak: "break-word" }}>{v}</div>
                    </div>
                  ))}
                </div>

                <div style={{ marginTop: 6, display: "grid", gap: 8 }}>
                  <div style={{ fontWeight: 900 }}>Statuses</div>
                  <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
                    <span style={{ opacity: 0.7, fontWeight: 700 }}>Delivery</span>
                    <StatusPill status={props.row.status || "UNKNOWN"} />
                  </div>
                  <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
                    <span style={{ opacity: 0.7, fontWeight: 700 }}>QC</span>
                    <StatusPill status={props.row.qcStatus || "UNKNOWN"} />
                    {props.row.qcFailureReasons && props.row.qcFailureReasons.length ? (
                      <span style={{ opacity: 0.8, fontSize: 12 }}>{props.row.qcFailureReasons.join(", ")}</span>
                    ) : null}
                  </div>
                  <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
                    <span style={{ opacity: 0.7, fontWeight: 700 }}>Approvals</span>
                    <StatusPill status={props.row.approvalStatus || "N/A"} />
                  </div>
                </div>
              </>
            ) : (
              <>
                <div style={{ fontWeight: 900 }}>Media inspection</div>

                {detailsLoading ? <div style={{ opacity: 0.75 }}>Loading delivered file details…</div> : null}
                {detailsError ? <div style={{ color: "#a10000", whiteSpace: "pre-wrap" }}>{detailsError}</div> : null}
                {!detailsLoading && !detailsError && deliveredMedia?.error ? (
                  <div style={{ padding: 10, borderRadius: 10, background: "#f8fafc", color: "#334155" }}>{deliveredMedia.error}</div>
                ) : null}

                {!detailsLoading && !detailsError && !deliveredMedia ? (
                  <div style={{ padding: 10, borderRadius: 10, background: "#f8fafc", color: "#334155" }}>
                    No media-inspection details were returned for this delivery task.
                  </div>
                ) : null}

                {!detailsLoading && !detailsError && deliveredMedia && !deliveredMedia?.error ? (
                  <>
                    {(mediaSummaryRows.length || librarySummaryRows.length || assetSummaryRows.length || clientSummaryPairs.length) ? (
                      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: 12 }}>
                        <TrackingInfoSection title="Media details" subtitle="Technical media information for the delivered file." rows={mediaSummaryRows} />
                        <TrackingInfoSection title="DAM details" subtitle="Business metadata saved with this DAM item." rows={librarySummaryRows} />
                        <TrackingInfoSection title="Asset details" subtitle="Upload and source details for the delivered file." rows={assetSummaryRows} />
                      </div>
                    ) : null}

                    {(videoStreams.length || audioStreams.length || mediaInfoGeneralRows.length || mediaInfoVideoSections.length || mediaInfoAudioSections.length || mediaInfoOtherSections.length || otherStreams.length) ? (
                      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: 12 }}>
                        {videoStreams.map((stream: any, idx: number) => (
                          <TrackingInfoSection
                            key={`v-${idx}-${stream.index ?? idx}`}
                            title={`Video track ${idx + 1}`}
                            rows={[
                              ["Video format", simpleCodecName(stream.codec, stream.codecLongName)],
                              ["Picture size", stream.width && stream.height ? `${stream.width} × ${stream.height}${resolutionLabel(stream.width, stream.height) ? ` (${resolutionLabel(stream.width, stream.height)})` : ""}` : ""],
                              ["Motion", friendlyFrameRateLabel(stream.frameRate)],
                              ["Screen shape", stream.displayAspectRatio ? `${stream.displayAspectRatio} widescreen` : ""],
                              ["Playback style", friendlyScanType(stream.scanType)],
                              ["Data rate", fmtFriendlyBitrate(numOrNull(stream.bitRate))],
                              ["Length", fmtFriendlyDuration(numOrNull(stream.durationSeconds))],
                              ["Color profile", [stream.colorSpace, stream.colorTransfer, stream.colorPrimaries].filter(Boolean).join(" / ")],
                            ]}
                          />
                        ))}

                        {audioStreams.map((stream: any, idx: number) => (
                          <TrackingInfoSection
                            key={`a-${idx}-${stream.index ?? idx}`}
                            title={`Audio track ${idx + 1}`}
                            rows={[
                              ["Audio format", simpleCodecName(stream.codec, stream.codecLongName)],
                              ["Sound setup", friendlyChannelLabel(stream.channels) || stream.channelLayout],
                              ["Sample rate", stream.sampleRate ? `${stream.sampleRate} Hz` : ""],
                              ["Data rate", fmtFriendlyBitrate(numOrNull(stream.bitRate))],
                              ["Length", fmtFriendlyDuration(numOrNull(stream.durationSeconds))],
                              ["Language", stream.language && stream.language !== "und" ? stream.language : "Not specified"],
                            ]}
                          />
                        ))}

                        {mediaInfoGeneralRows.length ? (
                          <TrackingInfoSection title="General details" rows={mediaInfoGeneralRows.map(([k, v]) => [String(k), String(v ?? "")])} />
                        ) : null}

                        {mediaInfoVideoSections.map((section: { title: string; rows: Array<[string, string]> }) => (
                          <TrackingInfoSection
                            key={section.title}
                            title={section.title}
                            rows={section.rows.map(([k, v]: [string, string]) => [String(k), String(v ?? "")])}
                          />
                        ))}

                        {mediaInfoAudioSections.map((section: { title: string; rows: Array<[string, string]> }) => (
                          <TrackingInfoSection
                            key={section.title}
                            title={section.title}
                            rows={section.rows.map(([k, v]: [string, string]) => [String(k), String(v ?? "")])}
                          />
                        ))}

                        {mediaInfoOtherSections.map((section: { title: string; rows: Array<[string, string]> }) => (
                          <TrackingInfoSection
                            key={section.title}
                            title={section.title}
                            rows={section.rows.map(([k, v]: [string, string]) => [String(k), String(v ?? "")])}
                          />
                        ))}

                        {otherStreams.map((stream: any, idx: number) => (
                          <TrackingInfoSection
                            key={`o-${idx}-${stream.index ?? idx}`}
                            title={`Other track ${idx + 1}`}
                            rows={[
                              ["Type", stream.type || ""],
                              ["Codec", stream.codecLongName || stream.codec || ""],
                            ]}
                          />
                        ))}
                      </div>
                    ) : null}

                  </>
                ) : null}
              </>
            )}
          </div>
        </div>

        {showDownload ? (
          <PresetDownloadModal
            title={`On-demand transcode · ${props.row.valid}`}
            sourceType="CREATIVE"
            sourceId={props.row.creativeId}
            destinationId={props.row.destinationId || undefined}
            lockDestination
            onClose={() => setShowDownload(false)}
          />
        ) : null}
      </div>
    </div>
  );
}

function getTrackingRowDate(row: Pick<GroupRow, "deliveredAt" | "sentAt" | "startedAt" | "uploadedAt">) {
  return row.deliveredAt || row.sentAt || row.startedAt || row.uploadedAt || null;
}

function isSameLocalDay(iso: string, now = new Date()) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return false;
  return d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth() && d.getDate() === now.getDate();
}

function isWithinLastDays(iso: string, days: number, now = new Date()) {
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return false;
  const diff = now.getTime() - d.getTime();
  return diff >= 0 && diff <= days * 24 * 60 * 60 * 1000;
}

function isInProgressStatus(status?: string | null) {
  const s = String(status || "").toUpperCase();
  return ["RUNNING", "QUEUED", "PAUSED", "PARTIAL"].includes(s);
}

export default function TrackingPage() {
  // Route is /projects/:id/tracking (see router.tsx). Keep local var name as projectId.
  const { id: projectId = "" } = useParams();
  const ctx = useOutletContext() as any;
  const project = ctx?.project;

  const [me, setMe] = useState<MeResponse | null>(null);
  const [raw, setRaw] = useState<RawRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string>("");

  const [q, setQ] = useState("");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [deliveryQuickFilter, setDeliveryQuickFilter] = useState<"ALL" | "FAILED" | "DELIVERED" | "IN_PROGRESS">("ALL");
  const [qcQuickFilter, setQcQuickFilter] = useState<"ALL" | "PASSED">("ALL");
  const [dateQuickFilter, setDateQuickFilter] = useState<"ALL" | "TODAY" | "LAST_7_DAYS">("ALL");
  const [showMoreFilters, setShowMoreFilters] = useState(false);
  const [assetModal, setAssetModal] = useState<{ row: GroupRow; initialTab: "preview" | "qc" } | null>(null);
  const [transcodeModalRow, setTranscodeModalRow] = useState<OnDemandTranscodeRow | null>(null);
  const [actionsModal, setActionsModal] = useState<TrackingActionsModalState | null>(null);

  const [showCols, setShowCols] = useState(false);
  const [showRules, setShowRules] = useState(false);
  const [rules, setRules] = useState<Rule[]>([]);

  const allColumns: { key: ColKey; label: string }[] = useMemo(
    () => [
      { key: "projectName", label: "Project" },
      { key: "projectNumber", label: "Project #" },
      { key: "valid", label: "VALiD" },
      { key: "caption", label: "Caption" },
      { key: "duration", label: "Duration" },
      { key: "languages", label: "Language" },
      { key: "format", label: "Type" },
      { key: "audio", label: "Audio" },
      { key: "productCategory", label: "Product category" },
      { key: "advertiserGroup", label: "Advertiser group" },
      { key: "advertiser", label: "Advertiser" },
      { key: "brand", label: "Brand" },
      { key: "mediaAgency", label: "Media agency" },
      { key: "creativeAgency", label: "Creative agency" },
      { key: "productionHouse", label: "Production house" },
      { key: "postHouse", label: "Post house" },
      { key: "audioAgency", label: "Audio agency" },
      { key: "slaName", label: "SLA" },
      { key: "destinationName", label: "Destination" },
      { key: "channels", label: "Channels" },
      { key: "uploadedAt", label: "Uploaded" },
      { key: "sentAt", label: "Sent" },
      { key: "deliveredAt", label: "Delivered" },
      { key: "status", label: "Status" },
      { key: "progress", label: "%" },
      { key: "timeToDeliver", label: "Time" },
      { key: "fileSize", label: "Size" },
      { key: "filename", label: "Filename" },
      { key: "qc", label: "QC Status" },
      { key: "qcAction", label: "Details" },
      { key: "approvals", label: "Approvals" },
      { key: "serverStatus", label: "Server" },
      { key: "billableParty", label: "Billable" },
      { key: "actions", label: "Action" },
    ],
    []
  );

  const [colOrder, setColOrder] = useState<ColKey[]>(allColumns.map((c) => c.key));
  const [colHidden, setColHidden] = useState<Set<ColKey>>(new Set());

  const [viewMode, setViewMode] = useState<"GROUPED" | "CHANNELS">(ENFORCED_VIEW_MODE);

  // Details modal
  const [detailsOpen, setDetailsOpen] = useState(false);
  const [detailsTaskId, setDetailsTaskId] = useState<string | null>(null);
  const [detailsRow, setDetailsRow] = useState<GroupRow | null>(null);
  const [detailsData, setDetailsData] = useState<any>(null);
  const [detailsLoading, setDetailsLoading] = useState(false);
  const [detailsError, setDetailsError] = useState<string>("");
  const detailsCacheRef = useRef<Record<string, any>>({});

  const canActions = hasPerm(me, "ORDER_SEND");
  const canDownload = hasPerm(me, "action:media:download") && hasPerm(me, "action:presets:request") && hasPerm(me, "action:presets:download");
  const canViewBilling = hasPerm(me, "BILLING_READ") || hasPerm(me, "BILLING_CREATE") || hasPerm(me, "BILLING_UPDATE");

  // Load me
  useEffect(() => {
    getMe()
      .then(setMe)
      .catch(() => setMe(null));
  }, []);

  // Load preferences (columns + rules)
  useEffect(() => {
    (async () => {
      const cols = await tryGetPref(`${PAGE_KEY}-columns`, LS_KEY_COLS);
      if (cols?.order) setColOrder(cols.order);
      if (cols?.hidden) setColHidden(new Set(cols.hidden));

      const rs = await tryGetPref(`${PAGE_KEY}-rules`, LS_KEY_RULES);
      if (Array.isArray(rs?.rules)) setRules(rs.rules);

      const vm = await tryGetPref(`${PAGE_KEY}-viewMode`, LS_KEY_VIEWMODE);
      const mode = String(vm?.mode ?? vm ?? ENFORCED_VIEW_MODE).toUpperCase();
      setViewMode(mode === "CHANNELS" ? "CHANNELS" : ENFORCED_VIEW_MODE);
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function load() {
    setLoading(true);
    setError("");
    try {
      const endpoint = projectId ? `/projects/${projectId}/tracking` : `/tracking`;
      const res = await api<{ rows: RawRow[] }>(endpoint);
      setRaw(res?.rows || []);
    } catch (e: any) {
      setError(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }

  function pickDetailsTaskId(r: GroupRow): string | null {
    const tasks = (r.tasks || []).slice().sort((a: any, b: any) => {
      const ak = String((a as any)?.updatedAt || (a as any)?.endedAt || (a as any)?.createdAt || "");
      const bk = String((b as any)?.updatedAt || (b as any)?.endedAt || (b as any)?.createdAt || "");
      return bk.localeCompare(ak);
    });
    const byStatus = (wanted: string[]) =>
      tasks.find((t: any) => wanted.includes(String(effectiveTaskStatus(t) || "").toUpperCase()));
    const preferred =
      byStatus(["SUCCESS"]) ??
      byStatus(["RUNNING", "QUEUED", "PAUSED"]) ??
      byStatus(["FAILED", "CANCELLED"]) ??
      tasks[0] ??
      null;
    return (preferred as any)?.taskId || r.taskIds[0] || null;
  }

  async function openDetails(taskId: string, pid?: string, row?: GroupRow | null) {
    setDetailsRow(row || null);
    const usePid = (pid || projectId || "").trim();
    if (!usePid) return;

    const cacheKey = `${usePid}:${taskId}`;
    const cached = detailsCacheRef.current[cacheKey] ?? null;

    setDetailsOpen(true);
    setDetailsTaskId(taskId);
    setDetailsData(cached);
    setDetailsError("");
    setDetailsLoading(!cached);
    try {
      const res = await api<any>(`/projects/${usePid}/tracking/${taskId}?includeDeliveredMedia=0`);
      detailsCacheRef.current[cacheKey] = res;
      setDetailsData(res);
    } catch (e: any) {
      if (!cached) setDetailsError(e?.message || String(e));
    } finally {
      setDetailsLoading(false);
    }
  }

  function closeDetails() {
    setDetailsOpen(false);
    setDetailsTaskId(null);
    setDetailsRow(null);
    setDetailsData(null);
    setDetailsError("");
    setDetailsLoading(false);
  }

  function openActionsModal(title: string, subtitle: string | undefined, items: TrackingActionItem[]) {
    setActionsModal({
      title,
      subtitle,
      items: (items || []).filter(Boolean),
    });
  }

  async function approveAndReleaseTask(taskId: string, currentHouseId?: string | null) {
    const entered = window.prompt("Enter House ID for final delivery", currentHouseId || "");
    if (entered == null) return;
    const houseId = String(entered || "").trim();
    if (!houseId) {
      setError("House ID is required");
      return;
    }

    setError("");
    setDetailsError("");
    try {
      await api(`/delivery/tasks/${taskId}/release`, {
        method: "POST",
        body: JSON.stringify({ houseId }),
      });
      setActionsModal(null);
      await load();
      if (detailsOpen && detailsTaskId && detailsRow?.projectId) {
        await openDetails(detailsTaskId, detailsRow.projectId, detailsRow);
      }
    } catch (e: any) {
      const msg = e?.message || "Failed to approve and release";
      setError(msg);
      setDetailsError(msg);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [projectId]);

  const perChannel: GroupRow[] = useMemo(() => {
    return (raw || []).map((r) => toSingleGroupRow(r));
  }, [raw]);

  const viewRows: GroupRow[] = useMemo(() => {
    // Tracking must stay one row per channel/task to avoid mixing multiple
    // deliveries from the same commit into a single confusing row.
    return perChannel;
  }, [perChannel]);

  const filtered: GroupRow[] = useMemo(() => {
    const qq = q.trim().toLowerCase();
    const now = new Date();
    return viewRows.filter((r) => {
      const normalizedStatus = String(r.status || "").toUpperCase();
      const normalizedQc = String(r.qcStatus || "").toUpperCase();
      const relevantDate = getTrackingRowDate(r);

      if (statusFilter !== "ALL" && normalizedStatus !== statusFilter) return false;
      if (deliveryQuickFilter === "FAILED" && normalizedStatus !== "FAILED") return false;
      if (deliveryQuickFilter === "DELIVERED" && normalizedStatus !== "SUCCESS") return false;
      if (deliveryQuickFilter === "IN_PROGRESS" && !isInProgressStatus(normalizedStatus)) return false;
      if (qcQuickFilter === "PASSED" && normalizedQc !== "PASSED") return false;
      if (dateQuickFilter === "TODAY" && (!relevantDate || !isSameLocalDay(relevantDate, now))) return false;
      if (dateQuickFilter === "LAST_7_DAYS" && (!relevantDate || !isWithinLastDays(relevantDate, 7, now))) return false;

      if (!qq) return true;
      const hay = [
        r.projectName,
        r.projectNumber,
        r.valid,
        r.caption,
        r.destinationName,
        r.receiverAccountName,
        r.receiverCategory,
        r.slaName,
        r.advertiser,
        r.brand,
        r.filename,
        r.channels.map((c) => c.name).join(", "),
      ]
        .filter(Boolean)
        .join(" | ")
        .toLowerCase();
      return hay.includes(qq);
    });
  }, [viewRows, q, statusFilter, deliveryQuickFilter, qcQuickFilter, dateQuickFilter]);

  const visibleOrder = useMemo(() => {
    // Ensure all columns exist
    const all = new Set(allColumns.map((c) => c.key));
    const order = (colOrder || []).filter((k) => all.has(k));
    for (const k of all) if (!order.includes(k)) order.push(k as ColKey);

    // Apply permission-driven hides
    const hidden = new Set(colHidden);
    // Keep "actions" column visible so we can show "Details" even for read-only users.
    if (!canViewBilling) hidden.add("billableParty");
    if (!canActions) hidden.add("serverStatus");

    return order.filter((k) => !hidden.has(k));
  }, [allColumns, colOrder, colHidden, canActions, canViewBilling]);

  function renderCell(col: ColKey, r: GroupRow) {
    switch (col) {
      case "projectName":
        return r.projectName || project?.name || "";
      case "projectNumber":
        return r.projectNumber || "";
      case "valid":
        return r.valid;
      case "caption":
        return r.caption || "";
      case "duration":
        return r.duration || "";
      case "languages":
        return r.languages?.join(", ") || "";
      case "format":
        return r.format || "";
      case "audio":
        return r.audio || "";
      case "productCategory":
        return r.productCategory || "";
      case "advertiserGroup":
        return r.advertiserGroup || "";
      case "advertiser":
        return r.advertiser || "";
      case "brand":
        return r.brand || "";
      case "mediaAgency":
        return [r.mediaAgency, r.mediaAgencyTeam].filter(Boolean).join(" / ");
      case "creativeAgency":
        return [r.creativeAgency, r.creativeAgencyTeam].filter(Boolean).join(" / ");
      case "productionHouse":
        return [r.productionHouse, r.productionHouseTeam].filter(Boolean).join(" / ");
      case "postHouse":
        return [r.postHouse, r.postHouseTeam].filter(Boolean).join(" / ");
      case "audioAgency":
        return [r.audioAgency, r.audioAgencyTeam].filter(Boolean).join(" / ");
      case "slaName":
        return r.slaName || "";
      case "destinationName":
        return (
          <div style={{ display: "grid", gap: 4 }}>
            <span>{r.destinationName || ""}</span>
            {r.receiverAccountName ? (
              <span style={{ fontSize: 11, color: "#1d4ed8", fontWeight: 700 }}>
                Receiver: {[r.receiverAccountName, r.receiverCategory].filter(Boolean).join(" • ")}
              </span>
            ) : null}
          </div>
        );
      case "channels":
        if (r.tasks?.length) {
          const list = r.tasks
            .slice()
            .sort((a: any, b: any) => (a?.channelName || "").localeCompare(b?.channelName || ""));
          return (
            <div style={{ display: "grid", gap: 4 }}>
              {list.map((t: any) => (
                <div key={t.taskId} style={{ display: "flex", gap: 8, alignItems: "center" }}>
                  <span style={{ fontWeight: 600, whiteSpace: "nowrap" }}>{t.channelName}</span>
                  <StatusPill status={effectiveTaskStatus(t)} title={taskStatusTitle(t)} />
                </div>
              ))}
            </div>
          );
        }
        return r.channels.map((c) => c.name).join(", ");
      case "uploadedAt":
        return fmtDateTime(r.uploadedAt);
      case "sentAt":
        return fmtDateTime(r.sentAt);
      case "deliveredAt":
        return fmtDateTime(r.deliveredAt);
      case "status":
        return <StatusPill status={r.status} title={(() => {
          const ts = r.tasks || [];
          if (!ts.length) return "";
          const counts: Record<string, number> = {};
          for (const t of ts) {
            const s = effectiveTaskStatus(t);
            counts[s] = (counts[s] || 0) + 1;
          }
          return Object.entries(counts)
            .sort((a, b) => b[1] - a[1])
            .map(([k, v]) => `${k}: ${v}`)
            .join("\n");
        })()} />;
      case "progress":
        return r.progressPct == null ? "" : `${r.progressPct}%`;
      case "timeToDeliver":
        return fmtSeconds(r.timeToDeliverSec);
      case "fileSize":
        return fmtBytes(r.fileSizeBytes ?? null);
      case "filename":
        return r.filename || "";
      case "qc":
        return <StatusPill status={r.qcStatus || "UNKNOWN"} />;
      case "qcAction":
        return (
          <div style={{ display: "flex", justifyContent: "center" }}>
            <button className="btn" onClick={() => setAssetModal({ row: r, initialTab: "qc" })}>
              Details
            </button>
          </div>
        );
      case "approvals":
        return <StatusPill status={r.approvalStatus || "N/A"} />;
      case "serverStatus": {
        const s = r.channels.find((c) => c.serverStatus)?.serverStatus;
        return s ? <StatusPill status={s} title={r.channels.find((c) => c.serverMessage)?.serverMessage || ""} /> : "";
      }
      case "billableParty":
        return r.billableParty || "";
      case "actions":
        return (
          <div style={{ display: "flex", justifyContent: "center" }}>
            {(() => {
              const tasks: any[] = Array.isArray(r.tasks) ? r.tasks : [];
              const isGroupedRow = viewMode === "GROUPED" && r.taskIds.length > 1 && !String(r.key || "").startsWith("task:");

              const rawStatus = (t: any) => String(t?.status || "UNKNOWN").toUpperCase();
              const retryIds = tasks
                .filter((t) => {
                  const s = rawStatus(t);
                  if (s === "FAILED") return true;
                  if (s === "QUEUED" && t?.lastError && (t?.attempts ?? 0) > 0) return true;
                  return false;
                })
                .map((t) => t.taskId)
                .filter(Boolean);

              const sendAgainIds = tasks
                .filter((t) => rawStatus(t) === "SUCCESS")
                .map((t) => t.taskId)
                .filter(Boolean);

              const pauseIds = tasks
                .filter((t) => ["RUNNING", "QUEUED"].includes(rawStatus(t)))
                .map((t) => t.taskId)
                .filter(Boolean);

              const resumeIds = tasks
                .filter((t) => rawStatus(t) === "PAUSED" && effectiveTaskStatus(t) !== "WAITING_APPROVAL")
                .map((t) => t.taskId)
                .filter(Boolean);

              const approvalReleaseTasks = tasks.filter((t) => effectiveTaskStatus(t) === "WAITING_APPROVAL");
              const approvalReleaseIds = approvalReleaseTasks.map((t) => t.taskId).filter(Boolean);

              const stopIds = tasks
                .filter((t) => !["SUCCESS", "FAILED", "CANCELLED"].includes(rawStatus(t)))
                .map((t) => t.taskId)
                .filter(Boolean);

              const safeRun = async (ids: string[], action: string, errMsg: string) => {
                if (!ids.length) return;
                setError("");
                try {
                  for (const id of ids) await api(`/delivery/tasks/${id}/${action}`, { method: "POST" });
                } catch (e: any) {
                  setError(e?.message || errMsg);
                }
                await load();
              };

              const actionItems: TrackingActionItem[] = [
                {
                  label: "Details",
                  onClick: () => {
                    const id = pickDetailsTaskId(r);
                    if (id) openDetails(id, r.projectId, r);
                  },
                },
                {
                  label: "On-demand transcode",
                  disabled: !canDownload,
                  onClick: () => setTranscodeModalRow({ valid: r.valid, creativeId: r.creativeId, destinationId: r.destinationId }),
                },

                {
                  label: isGroupedRow ? `Pause active (${pauseIds.length})` : "Pause",
                  disabled: !canActions || pauseIds.length === 0,
                  onClick: async () => safeRun(pauseIds, "pause", "Failed to pause"),
                },
                {
                  label: isGroupedRow ? `Resume paused (${resumeIds.length})` : "Resume",
                  disabled: !canActions || resumeIds.length === 0,
                  onClick: async () => safeRun(resumeIds, "resume", "Failed to resume"),
                },
                {
                  label: isGroupedRow ? `Approve & release (${approvalReleaseIds.length})` : "Approve & release",
                  disabled: !canActions || approvalReleaseIds.length !== 1,
                  onClick: async () => {
                    const task = approvalReleaseTasks[0] as any;
                    if (!task?.taskId) return;
                    await approveAndReleaseTask(task.taskId, task?.deliveryHouseId || null);
                  },
                },
                {
                  label: isGroupedRow ? `Stop active (${stopIds.length})` : "Stop",
                  danger: true,
                  disabled: !canActions || stopIds.length === 0,
                  onClick: async () => safeRun(stopIds, "cancel", "Failed to stop"),
                },
                {
                  label: isGroupedRow ? `Retry failed (${retryIds.length})` : "Retry",
                  disabled: !canActions || retryIds.length === 0,
                  onClick: async () => safeRun(retryIds, "retry", "Failed to retry"),
                },
                {
                  label: isGroupedRow ? `Send again (${sendAgainIds.length})` : "Send again",
                  disabled: !canActions || sendAgainIds.length === 0,
                  onClick: async () => safeRun(sendAgainIds, "send-again", "Failed to send again"),
                },
              ];

              const channelLabel = (r.channels || []).map((c) => c.name).filter(Boolean).join(", ");

              return (
                <button
                  className="btn"
                  type="button"
                  style={{ minWidth: 40, padding: "6px 10px", fontWeight: 900 }}
                  onClick={(e) => {
                    e.stopPropagation();
                    openActionsModal(
                      "Tracking actions",
                      [r.valid, r.destinationName, channelLabel].filter(Boolean).join(" • "),
                      actionItems,
                    );
                  }}
                >
                  ⋯
                </button>
              );
            })()}
          </div>
        );
      default:
        return "";
    }
  }

  function exportCsv() {
    const cols = visibleOrder.filter((c) => !["actions", "qcAction"].includes(c));
    const header = cols.map((c) => csvEscape(allColumns.find((x) => x.key === c)?.label || c)).join(",");
    const lines = filtered.map((r) => {
      return cols
        .map((c) => {
          if (c === "status") return csvEscape(r.status);
          if (c === "qc") return csvEscape(r.qcStatus || "");
          if (c === "approvals") return csvEscape(r.approvalStatus || "");
          if (c === "progress") return csvEscape(r.progressPct == null ? "" : `${r.progressPct}%`);
          if (c === "timeToDeliver") return csvEscape(fmtSeconds(r.timeToDeliverSec));
          if (c === "uploadedAt") return csvEscape(fmtDateTime(r.uploadedAt));
          if (c === "sentAt") return csvEscape(fmtDateTime(r.sentAt));
          if (c === "deliveredAt") return csvEscape(fmtDateTime(r.deliveredAt));
          if (c === "channels") return csvEscape(r.channels.map((x) => x.name).join(", "));
          if (c === "fileSize") return csvEscape(fmtBytes(r.fileSizeBytes ?? null));
          return csvEscape((r as any)[c] ?? "");
        })
        .join(",");
    });
    downloadText(`tracking_${project?.name || projectId || "all"}.csv`, [header, ...lines].join("\n"));
  }

  async function saveCols(nextOrder: ColKey[], nextHidden: Set<ColKey>) {
    setColOrder(nextOrder);
    setColHidden(nextHidden);
    await trySetPref(`${PAGE_KEY}-columns`, LS_KEY_COLS, { order: nextOrder, hidden: Array.from(nextHidden) });
  }

  async function saveRules(nextRules: Rule[]) {
    setRules(nextRules);
    await trySetPref(`${PAGE_KEY}-rules`, LS_KEY_RULES, { rules: nextRules });
    setShowRules(false);
  }

  async function saveViewMode(mode: "GROUPED" | "CHANNELS") {
    const nextMode = mode === "CHANNELS" ? "CHANNELS" : ENFORCED_VIEW_MODE;
    setViewMode(nextMode);
    await trySetPref(`${PAGE_KEY}-viewMode`, LS_KEY_VIEWMODE, { mode: nextMode });
  }

  const statusOptions = useMemo(() => {
    const s = new Set<string>(viewRows.map((x) => (x.status || "").toUpperCase()).filter(Boolean));
    return ["ALL", ...Array.from(s.values()).sort()];
  }, [viewRows]);


  const searchSuggestions = useMemo(() => {
    const values = new Set<string>();
    for (const row of viewRows) {
      [row.filename, row.valid, row.destinationName, row.receiverAccountName, row.receiverCategory, row.projectName, row.brand].forEach((value) => {
        const v = String(value || "").trim();
        if (v) values.add(v);
      });
      for (const channel of row.channels || []) {
        const v = String(channel?.name || "").trim();
        if (v) values.add(v);
      }
      if (values.size >= 12) break;
    }
    return Array.from(values).slice(0, 12);
  }, [viewRows]);

  const activeFilterLabels = useMemo(() => {
    const labels: string[] = [];
    if (deliveryQuickFilter === "FAILED") labels.push("Failed only");
    if (deliveryQuickFilter === "DELIVERED") labels.push("Delivered only");
    if (deliveryQuickFilter === "IN_PROGRESS") labels.push("In progress");
    if (qcQuickFilter === "PASSED") labels.push("QC passed");
    if (dateQuickFilter === "TODAY") labels.push("Today");
    if (dateQuickFilter === "LAST_7_DAYS") labels.push("Last 7 days");
    if (statusFilter !== "ALL") labels.push(`Exact status: ${statusFilter}`);
    if (q.trim()) labels.push(`Search: ${q.trim()}`);
    return labels;
  }, [deliveryQuickFilter, qcQuickFilter, dateQuickFilter, statusFilter, q]);

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "center" }}>
        <div>
          <div style={{ fontWeight: 900, fontSize: 20 }}>Tracking</div>
          <div style={{ opacity: 0.7 }}>{projectId ? `Project: ${project?.name || projectId}` : "All projects"}</div>
        </div>
        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
          <button className="btn" onClick={load} disabled={loading}>
            Refresh
          </button>
          <button className="btn" onClick={() => setShowCols(true)}>
            Columns
          </button>
          <button className="btn" onClick={() => setShowRules(true)}>
            Rules
          </button>
          <button className="btn" onClick={exportCsv}>
            Export CSV
          </button>
        </div>
      </div>

      <div className="card" style={{ display: "grid", gap: 12 }}>
        <div style={{ display: "flex", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
          <div
            style={{
              flex: "1 1 420px",
              minWidth: 280,
              display: "flex",
              alignItems: "center",
              gap: 8,
              border: "1px solid #d7dde5",
              borderRadius: 12,
              padding: "10px 12px",
              background: "#fff",
            }}
          >
            <input
              list="tracking-search-suggestions"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="Search by file name, destination, channel or project"
              style={{ border: 0, outline: 0, width: "100%", minWidth: 0, background: "transparent" }}
            />
            {q ? (
              <button className="btn" type="button" onClick={() => setQ("")}>
                Clear
              </button>
            ) : null}
            <datalist id="tracking-search-suggestions">
              {searchSuggestions.map((value) => (
                <option key={value} value={value} />
              ))}
            </datalist>
          </div>

          <button className="btn" type="button" onClick={() => setShowMoreFilters((v) => !v)}>
            {showMoreFilters ? "Hide filters" : "More filters"}
          </button>

          {(q.trim() || deliveryQuickFilter !== "ALL" || qcQuickFilter !== "ALL" || dateQuickFilter !== "ALL" || statusFilter !== "ALL") ? (
            <button
              className="btn"
              type="button"
              onClick={() => {
                setQ("");
                setStatusFilter("ALL");
                setDeliveryQuickFilter("ALL");
                setQcQuickFilter("ALL");
                setDateQuickFilter("ALL");
              }}
            >
              Clear all
            </button>
          ) : null}

          <div style={{ marginLeft: "auto", opacity: 0.7, fontWeight: 700 }}>
            {loading ? "Loading..." : `${filtered.length} of ${viewRows.length} rows`}
          </div>
        </div>

        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
          <span style={{ opacity: 0.72, fontWeight: 700, fontSize: 13 }}>Quick filters</span>
          {[
            { label: "Failed", active: deliveryQuickFilter === "FAILED", onClick: () => { setDeliveryQuickFilter((v) => (v === "FAILED" ? "ALL" : "FAILED")); setStatusFilter("ALL"); } },
            { label: "Delivered", active: deliveryQuickFilter === "DELIVERED", onClick: () => { setDeliveryQuickFilter((v) => (v === "DELIVERED" ? "ALL" : "DELIVERED")); setStatusFilter("ALL"); } },
            { label: "In progress", active: deliveryQuickFilter === "IN_PROGRESS", onClick: () => { setDeliveryQuickFilter((v) => (v === "IN_PROGRESS" ? "ALL" : "IN_PROGRESS")); setStatusFilter("ALL"); } },
            { label: "QC passed", active: qcQuickFilter === "PASSED", onClick: () => setQcQuickFilter((v) => (v === "PASSED" ? "ALL" : "PASSED")) },
            { label: "Today", active: dateQuickFilter === "TODAY", onClick: () => setDateQuickFilter((v) => (v === "TODAY" ? "ALL" : "TODAY")) },
            { label: "Last 7 days", active: dateQuickFilter === "LAST_7_DAYS", onClick: () => setDateQuickFilter((v) => (v === "LAST_7_DAYS" ? "ALL" : "LAST_7_DAYS")) },
          ].map((chip) => (
            <button
              key={chip.label}
              type="button"
              onClick={chip.onClick}
              style={{
                border: chip.active ? "1px solid #2563eb" : "1px solid #d7dde5",
                background: chip.active ? "#eff6ff" : "#fff",
                color: chip.active ? "#1d4ed8" : "#1f2937",
                borderRadius: 999,
                padding: "8px 12px",
                fontWeight: 700,
                cursor: "pointer",
              }}
            >
              {chip.label}
            </button>
          ))}
        </div>

        {showMoreFilters ? (
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))",
              gap: 10,
              paddingTop: 4,
              borderTop: "1px solid #eef2f7",
            }}
          >
            <label style={{ display: "grid", gap: 6 }}>
              <span style={{ opacity: 0.72, fontWeight: 700, fontSize: 13 }}>View</span>
              <select
                value={viewMode}
                onChange={(e) => saveViewMode((e.target.value as any) === "CHANNELS" ? "CHANNELS" : ENFORCED_VIEW_MODE)}
                style={{ padding: 10, borderRadius: 10, border: "1px solid #d7dde5" }}
              >
                <option value="CHANNELS">Per channel</option>
              </select>
              <span style={{ fontSize: 12, color: "#64748b" }}>
                Each selected channel is shown in a separate tracking row.
              </span>
            </label>

            <label style={{ display: "grid", gap: 6 }}>
              <span style={{ opacity: 0.72, fontWeight: 700, fontSize: 13 }}>Exact status</span>
              <select
                value={statusFilter}
                onChange={(e) => {
                  setStatusFilter(e.target.value);
                  setDeliveryQuickFilter("ALL");
                }}
                style={{ padding: 10, borderRadius: 10, border: "1px solid #d7dde5" }}
              >
                {statusOptions.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
            </label>
          </div>
        ) : null}

        {activeFilterLabels.length ? (
          <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
            <span style={{ opacity: 0.72, fontWeight: 700, fontSize: 13 }}>Active</span>
            {activeFilterLabels.map((label) => (
              <span
                key={label}
                style={{
                  border: "1px solid #d7dde5",
                  background: "#f8fafc",
                  borderRadius: 999,
                  padding: "6px 10px",
                  fontSize: 12,
                  fontWeight: 700,
                }}
              >
                {label}
              </span>
            ))}
          </div>
        ) : null}
      </div>

      {error ? (
        <div className="card" style={{ border: "1px solid #a10000", color: "#a10000" }}>
          {error}
        </div>
      ) : null}

      <div className="card table-scroll-x trackingTableWrap" style={{ overflowY: "hidden", padding: 0 }}>
        <table className="trackingTable" style={{ border: "1px solid #d7dde5" }}>
          <thead>
            <tr style={{ textAlign: "left" }}>
              {visibleOrder.map((k) => (
                <th
                  key={k}
                  style={{
                    padding: "10px 8px",
                    border: "1px solid #d7dde5",
                    background: "#f8fafc",
                    whiteSpace: "nowrap",
                    textAlign: k === "actions" ? "center" : undefined,
                    width: k === "actions" ? 1 : undefined,
                  }}
                >
                  {allColumns.find((c) => c.key === k)?.label || k}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {filtered.length === 0 ? (
              <tr>
                <td colSpan={visibleOrder.length} style={{ padding: 16, opacity: 0.7, border: "1px solid #d7dde5" }}>
                  No tracking rows yet.
                </td>
              </tr>
            ) : null}
            {filtered.map((r) => {
              const bg = applyRules(r, rules);
              return (
                <tr
                  key={r.key}
                  style={{ background: bg || undefined }}
                >
                  {visibleOrder.map((k) => (
                    <td
                      key={k}
                      style={{
                        padding: "10px 8px",
                        border: "1px solid #d7dde5",
                        verticalAlign: "top",
                        textAlign: k === "actions" ? "center" : undefined,
                        width: k === "actions" ? 1 : undefined,
                        whiteSpace: k === "actions" ? "nowrap" : undefined,
                      }}
                    >
                      {renderCell(k, r)}
                    </td>
                  ))}
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {showCols ? (
        <ColumnsModal
          title="Tracking columns"
          all={allColumns}
          order={colOrder}
          hidden={colHidden}
          onClose={() => setShowCols(false)}
          onChange={saveCols}
        />
      ) : null}

      {showRules ? (
        <RulesModal rules={rules} onClose={() => setShowRules(false)} onSave={saveRules} />
      ) : null}

      {assetModal ? (
        <DetailsModal row={assetModal.row} initialTab={assetModal.initialTab} canDownload={canDownload} onClose={() => setAssetModal(null)} />
      ) : null}
      {transcodeModalRow ? (
        <PresetDownloadModal
          title={`On-demand transcode · ${transcodeModalRow.valid}`}
          sourceType="CREATIVE"
          sourceId={transcodeModalRow.creativeId}
          destinationId={transcodeModalRow.destinationId || undefined}
          lockDestination
          onClose={() => setTranscodeModalRow(null)}
        />
      ) : null}

      <AppModal
        open={!!actionsModal}
        title={actionsModal?.title || "Tracking actions"}
        subtitle={actionsModal?.subtitle}
        width="sm"
        onClose={() => setActionsModal(null)}
      >
        <div style={{ display: "grid", gap: 10 }}>
          {(actionsModal?.items || []).map((item, idx) => (
            <button
              key={`${item.label}-${idx}`}
              type="button"
              disabled={!!item.disabled}
              onClick={async () => {
                if (item.disabled) return;
                const run = item.onClick;
                setActionsModal(null);
                try {
                  await run?.();
                } catch (err) {
                  console.error(err);
                }
              }}
              style={{
                width: "100%",
                textAlign: "left",
                borderRadius: 14,
                border: `1px solid ${item.danger ? "rgba(161,0,0,0.18)" : "#d7dde5"}`,
                background: "#ffffff",
                padding: "12px 14px",
                fontWeight: 800,
                color: item.danger ? "#a10000" : "#0f172a",
                opacity: item.disabled ? 0.45 : 1,
                cursor: item.disabled ? "not-allowed" : "pointer",
              }}
            >
              {item.label}
            </button>
          ))}
        </div>
      </AppModal>

      {detailsOpen ? (
        <div
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: "rgba(0,0,0,0.35)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            padding: 20,
            zIndex: 1000,
          }}
          onClick={() => closeDetails()}
        >
          <div
            className="card"
            style={{ width: "min(1100px, 95vw)", maxHeight: "90vh", overflow: "auto", padding: 16 }}
            onClick={(e) => e.stopPropagation()}
          >
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12 }}>
              <div style={{ fontWeight: 900, fontSize: 18 }}>Delivery task details</div>
              <button className="btn" onClick={() => closeDetails()}>
                Close
              </button>
            </div>

            <div style={{ marginTop: 10 }}>
              {detailsLoading ? (
                <div style={{ opacity: 0.7 }}>Loading…</div>
              ) : detailsError ? (
                <div style={{ border: "1px solid #a10000", color: "#a10000", padding: 10, borderRadius: 10 }}>
                  {detailsError}
                </div>
              ) : null}
            </div>

            {!detailsLoading && !detailsError && detailsData ? (
              (() => {
                const t = (detailsData as any)?.task || (detailsData as any)?.deliveryTask || null;
                const planLine = (detailsData as any)?.planLine || null;
                const deliveredAsset = (detailsData as any)?.deliveredAsset || null;
                const transcript = t?.transcript || null;
                const steps = Array.isArray(transcript?.steps) ? transcript.steps : [];

                // Recompute per-channel tasks from latest list data so statuses/actions stay fresh
                const channelTasks: any[] = (() => {
                  const dr = detailsRow as any;
                  if (!dr) return [];
                  const key = String(dr.key || "");
                  if (key.startsWith("task:")) {
                    const id = dr.taskIds?.[0] || detailsTaskId;
                    return (raw || []).filter((x: any) => x.taskId === id);
                  }
                  const parts = key.split(":");
                  if (parts.length >= 4) {
                    const [orderId, creativeId, destinationId, slaId] = parts;
                    return (raw || []).filter((x: any) => {
                      return (
                        x.orderId === orderId &&
                        x.creativeId === creativeId &&
                        String(x.destinationId || "") === String(destinationId || "") &&
                        String(x.slaId || "") === String(slaId || "")
                      );
                    });
                  }
                  return Array.isArray(dr.tasks) ? dr.tasks : [];
                })();
                const deliveredCount = channelTasks.filter((x: any) => effectiveTaskStatus(x) === "SUCCESS").length;

                const runSingle = async (id: string, action: string, errMsg: string) => {
                  if (!id) return;
                  setError("");
                  setDetailsError("");
                  try {
                    await api(`/delivery/tasks/${id}/${action}`, { method: "POST" });
                  } catch (e: any) {
                    setDetailsError(e?.message || errMsg);
                  }
                  await load();
                  // refresh the details view for the same task
                  if (detailsRow?.projectId) await openDetails(id, detailsRow.projectId, detailsRow);
                };

                return (
                  <div style={{ display: "grid", gap: 12, marginTop: 10 }}>
                    <div className="card" style={{ padding: 12 }}>
                      <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "center" }}>
                        <div style={{ fontWeight: 900 }}>Channel deliveries</div>
                        {channelTasks.length ? (
                          <div style={{ opacity: 0.75, fontSize: 13 }}>
                            {deliveredCount}/{channelTasks.length} delivered
                          </div>
                        ) : null}
                      </div>

                      {channelTasks.length ? (
                        <div className="table-scroll-x" style={{ marginTop: 8 }}>
                          <table style={{ width: "100%", borderCollapse: "collapse" }}>
                            <thead>
                              <tr style={{ textAlign: "left" }}>
                                <th style={{ padding: "8px 6px", borderBottom: "1px solid #eee" }}>Channel</th>
                                <th style={{ padding: "8px 6px", borderBottom: "1px solid #eee" }}>Status</th>
                                <th style={{ padding: "8px 6px", borderBottom: "1px solid #eee" }}>Attempts</th>
                                <th style={{ padding: "8px 6px", borderBottom: "1px solid #eee" }}>Started</th>
                                <th style={{ padding: "8px 6px", borderBottom: "1px solid #eee" }}>Ended</th>
                                <th style={{ padding: "8px 6px", borderBottom: "1px solid #eee" }}>Remote path</th>
                                <th style={{ padding: "8px 6px", borderBottom: "1px solid #eee" }}>Last error</th>
                                <th style={{ padding: "8px 6px", borderBottom: "1px solid #eee" }}></th>
                              </tr>
                            </thead>
                            <tbody>
                              {channelTasks
                                .slice()
                                .sort((a: any, b: any) => (a?.channelName || "").localeCompare(b?.channelName || ""))
                                .map((x: any) => {
                                  const isSel = (x?.taskId || "") === (detailsTaskId || "");
                                  const rs = String(x?.status || "UNKNOWN").toUpperCase();
                                  const retryable = rs === "FAILED" || (rs === "QUEUED" && x?.lastError && (x?.attempts ?? 0) > 0);
                                  const sendAgainable = rs === "SUCCESS";
                                  const waitingApproval = effectiveTaskStatus(x) === "WAITING_APPROVAL";
                                  const pauseable = ["RUNNING", "QUEUED"].includes(rs);
                                  const resumeable = rs === "PAUSED" && !waitingApproval;
                                  const stoppable = !["SUCCESS", "FAILED", "CANCELLED"].includes(rs);
                                  return (
                                    <tr key={x.taskId} style={{ background: isSel ? "rgba(0,0,0,0.03)" : undefined }}>
                                      <td style={{ padding: "8px 6px", whiteSpace: "nowrap", fontWeight: isSel ? 900 : 600 }}>{x.channelName}</td>
                                      <td style={{ padding: "8px 6px" }}><StatusPill status={effectiveTaskStatus(x)} title={taskStatusTitle(x)} /></td>
                                      <td style={{ padding: "8px 6px", whiteSpace: "nowrap" }}>{x.attempts}{x.maxAttempts ? ` / ${x.maxAttempts}` : ""}</td>
                                      <td style={{ padding: "8px 6px", whiteSpace: "nowrap" }}>{fmtDateTime(x.startedAt)}</td>
                                      <td style={{ padding: "8px 6px", whiteSpace: "nowrap" }}>{fmtDateTime(x.endedAt)}</td>
                                      <td style={{ padding: "8px 6px", maxWidth: 220, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }} title={x.remotePath || ""}>{x.remotePath || ""}</td>
                                      <td style={{ padding: "8px 6px", maxWidth: 260, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }} title={x.lastError || ""}>{x.lastError || ""}</td>
                                      <td style={{ padding: "8px 6px", textAlign: "right", whiteSpace: "nowrap" }}>
                                        {(() => {
                                          const taskActionItems: TrackingActionItem[] = [
                                            {
                                              label: "Details",
                                              onClick: () => openDetails(x.taskId, (detailsRow as any)?.projectId || projectId, detailsRow),
                                            },
                                            {
                                              label: "On-demand transcode",
                                              disabled: !canDownload,
                                              onClick: () => setTranscodeModalRow({ valid: x.valid || detailsRow?.valid || "", creativeId: x.creativeId || detailsRow?.creativeId || "", destinationId: x.destinationId || detailsRow?.destinationId || null }),
                                            },
                                            {
                                              label: "Retry",
                                              disabled: !canActions || !retryable,
                                              onClick: async () => runSingle(x.taskId, "retry", "Failed to retry"),
                                            },
                                            {
                                              label: "Send again",
                                              disabled: !canActions || !sendAgainable,
                                              onClick: async () => runSingle(x.taskId, "send-again", "Failed to send again"),
                                            },
                                            {
                                              label: "Pause",
                                              disabled: !canActions || !pauseable,
                                              onClick: async () => runSingle(x.taskId, "pause", "Failed to pause"),
                                            },
                                            {
                                              label: "Resume",
                                              disabled: !canActions || !resumeable,
                                              onClick: async () => runSingle(x.taskId, "resume", "Failed to resume"),
                                            },
                                            {
                                              label: "Approve & release",
                                              disabled: !canActions || !waitingApproval,
                                              onClick: async () => approveAndReleaseTask(x.taskId, x.deliveryHouseId || null),
                                            },
                                            {
                                              label: "Stop",
                                              danger: true,
                                              disabled: !canActions || !stoppable,
                                              onClick: async () => runSingle(x.taskId, "cancel", "Failed to stop"),
                                            },
                                          ];

                                          return (
                                            <button
                                              className="btn"
                                              type="button"
                                              style={{ minWidth: 40, padding: "6px 10px", fontWeight: 900 }}
                                              onClick={(e) => {
                                                e.stopPropagation();
                                                openActionsModal(
                                                  "Channel delivery actions",
                                                  [x.channelName || x.channel || "", x.valid || detailsRow?.valid || "", x.status || ""].filter(Boolean).join(" • "),
                                                  taskActionItems,
                                                );
                                              }}
                                            >
                                              ⋯
                                            </button>
                                          );
                                        })()}
                                      </td>
                                    </tr>
                                  );
                                })}
                            </tbody>
                          </table>
                        </div>
                      ) : (
                        <div style={{ opacity: 0.7, fontSize: 13, marginTop: 6 }}>No channel tasks loaded for this row.</div>
                      )}
                    </div>
                    <div style={{ display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: 12 }}>
                      <div className="card" style={{ padding: 12 }}>
                        <div style={{ fontWeight: 900, marginBottom: 8 }}>Summary</div>
                        <div style={{ display: "grid", gap: 4, fontSize: 13 }}>
                          <div><b>Task ID:</b> {t?.id || detailsTaskId}</div>
                          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                            <b>Status:</b>
                            <StatusPill
                              status={effectiveTaskStatus({
                                status: t?.status,
                                lastError: t?.lastError,
                                attempts: t?.attempts,
                                maxAttempts: t?.maxAttempts,
                                runAfter: t?.runAfter,
                              })}
                              title={taskStatusTitle({
                                status: t?.status,
                                lastError: t?.lastError,
                                attempts: t?.attempts,
                                maxAttempts: t?.maxAttempts,
                                runAfter: t?.runAfter,
                              })}
                            />
                          </div>
                          <div><b>Attempts:</b> {t?.attempts}{t?.maxAttempts ? ` / ${t.maxAttempts}` : ""}</div>
                          <div><b>Run after:</b> {t?.runAfter ? new Date(t.runAfter).toLocaleString() : ""}</div>
                          <div><b>Started:</b> {t?.startedAt ? new Date(t.startedAt).toLocaleString() : ""}</div>
                          <div><b>Ended:</b> {t?.endedAt ? new Date(t.endedAt).toLocaleString() : ""}</div>
                          <div><b>Bytes sent:</b> {t?.bytesSent ? String(t.bytesSent) : ""}</div>
                          <div><b>Remote path:</b> {t?.remotePath || ""}</div>
                          <div><b>Last error:</b> {t?.lastError || ""}</div>
                        </div>
                      </div>
                      <div className="card" style={{ padding: 12 }}>
                        <div style={{ fontWeight: 900, marginBottom: 8 }}>Context</div>
                        <div style={{ display: "grid", gap: 4, fontSize: 13 }}>
                          <div><b>Channel:</b> {planLine?.channel?.name || ""}</div>
                          <div><b>Destination:</b> {planLine?.channel?.destination?.name || ""}</div>
                          <div><b>Creative:</b> {planLine?.creative?.name || planLine?.creative?.valid || ""}</div>
                          <div><b>File:</b> {deliveredAsset?.filename || t?.transcript?.deliveredAsset?.filename || t?.sourceAsset?.filename || (() => {
                            const assets: any[] = Array.isArray(planLine?.creative?.assets) ? planLine.creative.assets : [];
                            const best =
                              assets.find((a) => a?.type === "OUTPUT" && a?.uploadStatus === "UPLOADED") ??
                              assets.find((a) => a?.type === "SOURCE" && a?.uploadStatus === "UPLOADED") ??
                              assets[0] ??
                              null;
                            return best?.filename || "";
                          })()}</div>
<div><b>Protocol:</b> {t?.receipt?.protocol || ""}</div>

{(() => {
  const xml = t?.receipt?.xml || null;
  const viewUrl = t?.receipt?.xmlViewUrl || (xml as any)?.viewUrl || "";
  const downloadUrl = t?.receipt?.xmlDownloadUrl || (xml as any)?.downloadUrl || "";
  if (!viewUrl && !downloadUrl) return null;

  return (
    <div style={{ marginTop: 10, paddingTop: 10, borderTop: "1px solid rgba(0,0,0,0.08)" }}>
      <div style={{ fontWeight: 900, marginBottom: 6 }}>Metadata XML</div>

      <div className="row" style={{ gap: 10, flexWrap: "wrap" }}>
        {viewUrl ? (
          <a href={viewUrl} target="_blank" rel="noreferrer">
            View XML
          </a>
        ) : null}

        {downloadUrl ? (
          <a href={downloadUrl} target="_blank" rel="noreferrer">
            Download XML
          </a>
        ) : null}
      </div>

      <div style={{ marginTop: 6, fontSize: 12, opacity: 0.85 }}>
        {(xml as any)?.status ? (
          <div>
            <b>Status:</b> {(xml as any).status}
          </div>
        ) : null}

        {(xml as any)?.fileName ? (
          <div>
            <b>File:</b> {(xml as any).fileName}
          </div>
        ) : null}

        {(xml as any)?.remotePath ? (
          <div>
            <b>Remote:</b> {(xml as any).remotePath}
          </div>
        ) : null}

        {(xml as any)?.error ? <div style={{ color: "#a00" }}>{(xml as any).error}</div> : null}
      </div>
    </div>
  );
})()}
                        </div>
                      </div>
                    </div>

                    <div className="card" style={{ padding: 12 }}>
                      <div style={{ fontWeight: 900, marginBottom: 8 }}>Steps</div>
                      {steps.length === 0 ? (
                        <div style={{ opacity: 0.7 }}>No detailed steps yet (task created before step-logging was enabled).</div>
                      ) : (
                        <div style={{ display: "grid", gap: 6 }}>
                          {steps.map((s: any, idx: number) => (
                            <div key={idx} style={{ display: "grid", gridTemplateColumns: "180px 70px 1fr", gap: 10, fontSize: 13 }}>
                              <div style={{ opacity: 0.8 }}>{s.ts ? new Date(s.ts).toLocaleString() : ""}</div>
                              <div style={{ fontWeight: 900 }}>{s.level || "INFO"}</div>
                              <div>
                                {s.message}
                                {s.meta ? (
                                  <div style={{ opacity: 0.8, marginTop: 2 }}>
                                    <pre style={{ margin: 0, whiteSpace: "pre-wrap" }}>{JSON.stringify(s.meta, null, 2)}</pre>
                                  </div>
                                ) : null}
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                    <div style={{ display: "grid", gridTemplateColumns: "repeat(2, minmax(0, 1fr))", gap: 12 }}>
                      <div className="card" style={{ padding: 12 }}>
                        <div style={{ fontWeight: 900, marginBottom: 8 }}>Receipt</div>
                        <pre style={{ margin: 0, whiteSpace: "pre-wrap", fontSize: 12, opacity: 0.9 }}>
                          {JSON.stringify(t?.receipt || {}, null, 2)}
                        </pre>
                      </div>
                      <div className="card" style={{ padding: 12 }}>
                        <div style={{ fontWeight: 900, marginBottom: 8 }}>Transcript (raw)</div>
                        <pre style={{ margin: 0, whiteSpace: "pre-wrap", fontSize: 12, opacity: 0.9 }}>
                          {JSON.stringify(t?.transcript || {}, null, 2)}
                        </pre>
                      </div>
                    </div>
                  </div>
                );
              })()
            ) : null}
          </div>
        </div>
      ) : null}

      {projectId ? <ProjectNotificationsPanel projectId={projectId} /> : null}
    </div>
  );
}
