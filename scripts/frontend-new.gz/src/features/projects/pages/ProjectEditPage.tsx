import { useEffect, useMemo, useState, type CSSProperties } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { api } from "../../../lib/api";
import { getMe, hasPerm, type MeResponse } from "../../../lib/me";
import { SearchSelect } from "../../../ui/SearchSelect";

const NOTIFICATION_TYPES = [
  { id: 1, label: "Project Creation" },
  { id: 2, label: "Auto QC Passed/Failed" },
  { id: 3, label: "All Files Uploaded / Final Save" },
  { id: 4, label: "Destination Selection Done" },
  { id: 5, label: "Project Committed" },
  { id: 6, label: "File To Destination" },
  { id: 7, label: "File To Multiple Destinations" },
  { id: 8, label: "Project Complete" },
  { id: 9, label: "File Ready For Approval" },
  { id: 10, label: "File Approved" },
  { id: 11, label: "File Sent" },
] as const;

type NotificationGroupKey =
  | "notifyAdvertiserGroup"
  | "notifyAdvertiser"
  | "notifyBrand"
  | "notifyMediaAgency"
  | "notifyCreativeAgency"
  | "notifyPostHouse"
  | "notifyAudioAgency"
  | "notifyProductionHouse";

const NOTIFICATION_GROUPS: Array<{ key: NotificationGroupKey; label: string }> = [
  { key: "notifyAdvertiserGroup", label: "Advertiser Group" },
  { key: "notifyAdvertiser", label: "Advertiser" },
  { key: "notifyBrand", label: "Brand" },
  { key: "notifyMediaAgency", label: "Media Agency" },
  { key: "notifyCreativeAgency", label: "Creative Agency" },
  { key: "notifyPostHouse", label: "Post House" },
  { key: "notifyAudioAgency", label: "Audio Agency" },
  { key: "notifyProductionHouse", label: "Production House" },
];

function uniqEmails(input: string): string[] {
  const parts = input
    .split(/[\n,]/g)
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean);
  return Array.from(new Set(parts));
}

function formatBillingTeamValue(agencyName?: string | null, teamName?: string | null) {
  const team = String(teamName || "").trim();
  if (!team) return "";
  const agency = String(agencyName || "").trim();
  return agency ? `${agency} / ${team}` : team;
}

function isBillingTeamKey(key: string) {
  return key.endsWith("_TEAM");
}

type AgencyType = "MEDIA" | "CREATIVE" | "POST_HOUSE" | "PRODUCTION_HOUSE" | "AUDIO" | "UPLOADER";

type RateCardSummary = {
  id: string;
  name: string;
  billablePartyId?: string | null;
  effectiveFrom?: string;
  effectiveTo?: string | null;
  status?: string;
};

type Named = {
  id: string;
  name: string;
  type?: AgencyType;
  agencyId?: string;
};


type PartnerAccountSummary = {
  id: string;
  name: string;
  accountType?: "SENDER" | "RECEIVER";
  receiverCategory?: string | null;
  emails?: string[];
};

function normalizeSenderLookup(value: any) {
  return String(value ?? "")
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "");
}

function deriveSenderMatches(
  senderAccounts: PartnerAccountSummary[] | undefined,
  sources: Array<{ label: string; value: string }>,
) {
  const normalizedSources = sources
    .map((source) => ({
      label: source.label,
      value: source.value,
      normalized: normalizeSenderLookup(source.value),
    }))
    .filter((source) => source.normalized);

  if (!normalizedSources.length || !Array.isArray(senderAccounts) || !senderAccounts.length) return [];

  return senderAccounts
    .map((account) => {
      const normalizedName = normalizeSenderLookup(account?.name);
      if (!normalizedName) return null;
      let score = 0;
      const matchedBy: string[] = [];
      for (const source of normalizedSources) {
        if (normalizedName === source.normalized) {
          score += 300;
          matchedBy.push(source.label);
          continue;
        }
        if (source.normalized.length >= 4 && (normalizedName.includes(source.normalized) || source.normalized.includes(normalizedName))) {
          score += 120;
          matchedBy.push(source.label);
        }
      }
      if (!score) return null;
      return { id: account.id, name: account.name, matchedBy: Array.from(new Set(matchedBy)), score };
    })
    .filter((item): item is { id: string; name: string; matchedBy: string[]; score: number } => !!item)
    .sort((a, b) => b.score - a.score || a.name.localeCompare(b.name))
    .slice(0, 5);
}

function SenderAccountContextCard(props: { matches: Array<{ id: string; name: string; matchedBy: string[] }> }) {
  if (!props.matches.length) {
    return (
      <div style={{ padding: 14, borderRadius: 14, background: "#f8fafc", border: "1px dashed rgba(148,163,184,0.45)", fontSize: 13, color: "#64748b" }}>
        No sender account currently matches the selected advertiser group, advertiser, or brand.
      </div>
    );
  }

  return (
    <div style={{ display: "grid", gap: 10 }}>
      {props.matches.map((match) => (
        <div
          key={match.id}
          style={{
            padding: "12px 14px",
            borderRadius: 14,
            background: "#f8fafc",
            border: "1px solid rgba(148,163,184,0.18)",
            display: "grid",
            gap: 6,
          }}
        >
          <div style={{ fontWeight: 800, color: "#0f172a" }}>{match.name}</div>
          <div style={{ fontSize: 12, color: "#475569" }}>Matched from: {match.matchedBy.join(", ")}</div>
        </div>
      ))}
    </div>
  );
}

type ProjectNotificationConfig = {
  notifyAdvertiserGroup?: boolean;
  notifyAdvertiser?: boolean;
  notifyBrand?: boolean;
  notifyMediaAgency?: boolean;
  notifyCreativeAgency?: boolean;
  notifyPostHouse?: boolean;
  notifyAudioAgency?: boolean;
  notifyProductionHouse?: boolean;
  extraEmails?: string[];
  enabledTypes?: number[];
};

type ProjectEditModel = {
  id: string;
  name: string;
  projectNumber?: string;
  projectCode?: string | null;
  approvalsEnabled?: boolean;
  status?: "OPEN" | "CLOSED";
  remarks?: string | null;

  advertiserGroup?: Named | null;
  advertiser?: Named | null;
  brand?: Named | null;
  productCategory?: Named | null;
  senderAccount?: Named | null;
  billableParty?: Named | null;

  mediaAgency?: Named | null;
  mediaAgencyTeam?: Named | null;
  creativeAgency?: Named | null;
  creativeAgencyTeam?: Named | null;
  productionHouse?: Named | null;
  productionHouseTeam?: Named | null;
  postHouse?: Named | null;
  postHouseTeam?: Named | null;
  audioAgency?: Named | null;
  audioAgencyTeam?: Named | null;

  uploaderAgency?: Named | null;
  uploaderAgencyTeam?: Named | null;

  notificationConfig?: ProjectNotificationConfig | null;
};

type ProjectEditMeta = {
  advertiserGroups: Named[];
  advertisers: Named[];
  brands: Named[];
  productCategories: Named[];
  agencies: Named[];
  agencyTeams: Named[];
  senderAccounts: PartnerAccountSummary[];
  billableParties: Named[];
};

type BillingAgencyKey = "MEDIA" | "MEDIA_TEAM" | "CREATIVE" | "CREATIVE_TEAM" | "PRODUCTION_HOUSE" | "PRODUCTION_HOUSE_TEAM" | "POST_HOUSE" | "POST_HOUSE_TEAM" | "AUDIO" | "AUDIO_TEAM" | "UPLOADER" | "UPLOADER_TEAM";
type BillingAgencyChoice = { key: BillingAgencyKey; label: string; value: string };
type BillingSourceKey = "ADVERTISER_GROUP" | "ADVERTISER" | "BRAND" | BillingAgencyKey;
type SelectedBillingSourceKey = BillingSourceKey | "";
type BillingSourceChoice = { key: BillingSourceKey; label: string; value: string };

const PROJECT_BILLING_AGENCY_STORAGE_PREFIX = "projects.billingApplicableAgencies.";
const PROJECT_BILLING_SOURCE_STORAGE_PREFIX = "projects.billingSource.";
const PROJECT_RATE_CARD_STORAGE_PREFIX = "projects.rateCard.";
const BILLING_AGENCY_KEY_SET = new Set<BillingAgencyKey>(["MEDIA", "MEDIA_TEAM", "CREATIVE", "CREATIVE_TEAM", "PRODUCTION_HOUSE", "PRODUCTION_HOUSE_TEAM", "POST_HOUSE", "POST_HOUSE_TEAM", "AUDIO", "AUDIO_TEAM", "UPLOADER", "UPLOADER_TEAM"]);
const BILLING_SOURCE_KEY_SET = new Set<BillingSourceKey>(["ADVERTISER_GROUP", "ADVERTISER", "BRAND", "MEDIA", "MEDIA_TEAM", "CREATIVE", "CREATIVE_TEAM", "PRODUCTION_HOUSE", "PRODUCTION_HOUSE_TEAM", "POST_HOUSE", "POST_HOUSE_TEAM", "AUDIO", "AUDIO_TEAM", "UPLOADER", "UPLOADER_TEAM"]);

function safeLocalStorageGet(key: string) {
  try {
    if (typeof window === "undefined") return "";
    return window.localStorage.getItem(key) || "";
  } catch {
    return "";
  }
}

function safeLocalStorageSet(key: string, value: string) {
  try {
    if (typeof window === "undefined") return;
    if (value) window.localStorage.setItem(key, value);
    else window.localStorage.removeItem(key);
  } catch {
    // ignore local storage failures
  }
}

function normalizeBillingAgencyKeys(value: unknown): BillingAgencyKey[] {
  if (!Array.isArray(value)) return [];
  const out: BillingAgencyKey[] = [];
  for (const item of value) {
    const key = String(item || "").trim().toUpperCase() as BillingAgencyKey;
    if (BILLING_AGENCY_KEY_SET.has(key) && !out.includes(key)) out.push(key);
  }
  return out;
}

function loadProjectBillingAgencyKeys(projectId: string): BillingAgencyKey[] {
  const id = String(projectId || "").trim();
  if (!id) return [];
  try {
    return normalizeBillingAgencyKeys(JSON.parse(safeLocalStorageGet(`${PROJECT_BILLING_AGENCY_STORAGE_PREFIX}${id}`) || "[]"));
  } catch {
    return [];
  }
}

function saveProjectBillingAgencyKeys(projectId: string, keys: BillingAgencyKey[]) {
  const id = String(projectId || "").trim();
  if (!id) return;
  safeLocalStorageSet(`${PROJECT_BILLING_AGENCY_STORAGE_PREFIX}${id}`, JSON.stringify(normalizeBillingAgencyKeys(keys)));
}

function normalizeBillingSourceKey(value: unknown): SelectedBillingSourceKey {
  const key = String(value || "").trim().toUpperCase() as BillingSourceKey;
  return BILLING_SOURCE_KEY_SET.has(key) ? key : "";
}

function loadProjectBillingSourceKey(projectId: string): SelectedBillingSourceKey {
  const id = String(projectId || "").trim();
  if (!id) return "";
  return normalizeBillingSourceKey(safeLocalStorageGet(`${PROJECT_BILLING_SOURCE_STORAGE_PREFIX}${id}`));
}

function saveProjectBillingSourceKey(projectId: string, key: SelectedBillingSourceKey) {
  const id = String(projectId || "").trim();
  if (!id) return;
  safeLocalStorageSet(`${PROJECT_BILLING_SOURCE_STORAGE_PREFIX}${id}`, normalizeBillingSourceKey(key));
}

function loadProjectRateCardId(projectId: string): string {
  const id = String(projectId || "").trim();
  if (!id) return "";
  return String(safeLocalStorageGet(`${PROJECT_RATE_CARD_STORAGE_PREFIX}${id}`) || "").trim();
}

function saveProjectRateCardId(projectId: string, rateCardId: string) {
  const id = String(projectId || "").trim();
  if (!id) return;
  safeLocalStorageSet(`${PROJECT_RATE_CARD_STORAGE_PREFIX}${id}`, String(rateCardId || "").trim());
}


function BillingSummaryTile({ label, value, tone = "blue" }: { label: string; value?: string; tone?: "blue" | "emerald" }) {
  const active = Boolean(String(value || "").trim());
  const palette = tone === "emerald"
    ? {
        background: active ? "linear-gradient(180deg, #ecfdf5 0%, #f7fee7 100%)" : "#f8fafc",
        border: active ? "1px solid rgba(16,185,129,0.24)" : "1px solid rgba(148,163,184,0.18)",
        accent: "#047857",
      }
    : {
        background: active ? "linear-gradient(180deg, #eff6ff 0%, #f8fafc 100%)" : "#f8fafc",
        border: active ? "1px solid rgba(37,99,235,0.18)" : "1px solid rgba(148,163,184,0.18)",
        accent: "#1d4ed8",
      };

  return (
    <div
      style={{
        display: "grid",
        gap: 6,
        padding: "12px 14px",
        borderRadius: 14,
        background: palette.background,
        border: palette.border,
        minHeight: 72,
      }}
    >
      <span style={{ fontSize: 11, fontWeight: 800, letterSpacing: 0.3, textTransform: "uppercase", color: "#64748b" }}>{label}</span>
      <span style={{ fontSize: 14, fontWeight: 800, color: active ? "#0f172a" : "#94a3b8", lineHeight: 1.35 }}>{value || "Not selected"}</span>
      <span style={{ width: 32, height: 4, borderRadius: 999, background: active ? palette.accent : "rgba(148,163,184,0.3)" }} />
    </div>
  );
}

function BillingAgencySelector(props: {
  options: BillingAgencyChoice[];
  selectedKeys: BillingAgencyKey[];
  onToggle: (key: BillingAgencyKey) => void;
}) {
  if (!props.options.length) return null;
  const selected = new Set(props.selectedKeys);
  return (
    <div style={{ display: "grid", gap: 10, padding: 14, borderRadius: 14, background: "#ffffff", border: "1px solid rgba(148,163,184,0.18)" }}>
      <div style={{ display: "grid", gap: 4 }}>
        <div style={{ fontSize: 12, fontWeight: 800, color: "#334155", textTransform: "uppercase", letterSpacing: 0.3 }}>Billing agency scope</div>
      </div>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
        {props.options.map((item) => {
          const active = selected.has(item.key);
          return (
            <button
              key={item.key}
              type="button"
              onClick={() => props.onToggle(item.key)}
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: 6,
                padding: "8px 12px",
                borderRadius: 999,
                border: active ? "1px solid #2563eb" : "1px solid rgba(148,163,184,0.28)",
                background: active ? "#eff6ff" : "#ffffff",
                color: active ? "#1d4ed8" : "#334155",
                fontSize: 12,
                fontWeight: 700,
                cursor: "pointer",
                boxShadow: active ? "0 4px 12px rgba(37,99,235,0.12)" : "none",
              }}
            >
              {item.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}

function BillingSourceSelector(props: {
  options: BillingSourceChoice[];
  selectedKey: SelectedBillingSourceKey;
  onChange: (key: SelectedBillingSourceKey) => void;
}) {
  if (!props.options.length) return null;
  return (
    <div style={{ display: "grid", gap: 8, padding: 14, borderRadius: 14, background: "#ffffff", border: "1px solid rgba(148,163,184,0.18)" }}>
      <SearchSelect
        label="Billable Party"
        value={props.selectedKey}
        onChange={(next) => props.onChange(normalizeBillingSourceKey(next))}
        options={props.options.map((item) => ({ id: item.key, name: item.value || item.label }))}
        placeholder="Search billable party"
      />
      <div style={{ fontSize: 12, color: "#64748b" }}>
        Choose which selected project party should flow into invoice bill-to details.
      </div>
    </div>
  );
}

function SectionCard(props: { title: string; subtitle?: string; children: any }) {
  return (
    <div
      style={{
        border: "1px solid rgba(15,23,42,0.08)",
        borderRadius: 18,
        padding: 18,
        background: "linear-gradient(180deg, #ffffff 0%, #fbfdff 100%)",
        boxShadow: "0 8px 24px rgba(15,23,42,0.05)",
      }}
    >
      <div style={{ marginBottom: 14 }}>
        <div style={{ fontSize: 16, fontWeight: 800, color: "#0f172a" }}>{props.title}</div>
        {props.subtitle ? <div style={{ fontSize: 13, color: "#64748b", marginTop: 4 }}>{props.subtitle}</div> : null}
      </div>
      {props.children}
    </div>
  );
}

function parseDateValue(value?: string | null) {
  if (!value) return 0;
  const ts = new Date(value).getTime();
  return Number.isFinite(ts) ? ts : 0;
}

function pickLatestRateCard(rateCards: RateCardSummary[], billablePartyId?: string | null) {
  const linkedId = String(billablePartyId || "").trim();
  if (!linkedId) return null;
  const matches = rateCards.filter((card) => String(card.billablePartyId || "").trim() === linkedId);
  if (!matches.length) return null;
  return [...matches].sort((a, b) => {
    const statusA = String(a.status || "").toUpperCase() === "ACTIVE" ? 1 : 0;
    const statusB = String(b.status || "").toUpperCase() === "ACTIVE" ? 1 : 0;
    if (statusA !== statusB) return statusB - statusA;
    return parseDateValue(b.effectiveFrom) - parseDateValue(a.effectiveFrom);
  })[0] || null;
}


function gridStyle(min = 240): CSSProperties {
  return {
    display: "grid",
    gridTemplateColumns: `repeat(auto-fit, minmax(${min}px, 1fr))`,
    gap: 14,
  };
}

export function ProjectEditPage() {
  const nav = useNavigate();
  const { id } = useParams();

  const [me, setMe] = useState<MeResponse | null>(null);
  const [model, setModel] = useState<ProjectEditModel | null>(null);
  const [meta, setMeta] = useState<ProjectEditMeta | null>(null);
  const [rateCards, setRateCards] = useState<RateCardSummary[]>([]);

  const [name, setName] = useState("");
  const [projectCode, setProjectCode] = useState("");
  const [approvalsEnabled, setApprovalsEnabled] = useState(false);
  const [remarks, setRemarks] = useState("");

  const [advertiserGroupId, setAdvertiserGroupId] = useState("");
  const [advertiserId, setAdvertiserId] = useState("");
  const [brandId, setBrandId] = useState("");
  const [productCategoryId, setProductCategoryId] = useState("");
  const [senderAccountId, setSenderAccountId] = useState("");
  const [billablePartyId, setBillablePartyId] = useState("");
  const [selectedRateCardId, setSelectedRateCardId] = useState("");
  const [billingAgencyKeys, setBillingAgencyKeys] = useState<BillingAgencyKey[]>([]);
  const [billingSourceKey, setBillingSourceKey] = useState<SelectedBillingSourceKey>("");

  const [mediaAgencyId, setMediaAgencyId] = useState("");
  const [mediaAgencyTeamId, setMediaAgencyTeamId] = useState("");
  const [creativeAgencyId, setCreativeAgencyId] = useState("");
  const [creativeAgencyTeamId, setCreativeAgencyTeamId] = useState("");
  const [productionHouseId, setProductionHouseId] = useState("");
  const [productionHouseTeamId, setProductionHouseTeamId] = useState("");
  const [postHouseId, setPostHouseId] = useState("");
  const [postHouseTeamId, setPostHouseTeamId] = useState("");
  const [audioAgencyId, setAudioAgencyId] = useState("");
  const [audioAgencyTeamId, setAudioAgencyTeamId] = useState("");
  const [uploaderAgencyId, setUploaderAgencyId] = useState("");
  const [uploaderAgencyTeamId, setUploaderAgencyTeamId] = useState("");

  const [enabledNotificationTypes, setEnabledNotificationTypes] = useState<number[]>([]);
  const [notifyAdvertiserGroup, setNotifyAdvertiserGroup] = useState(true);
  const [notifyAdvertiser, setNotifyAdvertiser] = useState(true);
  const [notifyBrand, setNotifyBrand] = useState(true);
  const [notifyMediaAgency, setNotifyMediaAgency] = useState(true);
  const [notifyCreativeAgency, setNotifyCreativeAgency] = useState(true);
  const [notifyPostHouse, setNotifyPostHouse] = useState(true);
  const [notifyAudioAgency, setNotifyAudioAgency] = useState(true);
  const [notifyProductionHouse, setNotifyProductionHouse] = useState(true);
  const [extraEmailsText, setExtraEmailsText] = useState("");

  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState("");

  const canManualProjectCode = hasPerm(me, "PROJECT_NUMBER_MANUAL");
  const toggleBillingAgencyKey = (key: BillingAgencyKey) => {
    setBillingAgencyKeys((prev) => (prev.includes(key) ? prev.filter((item) => item !== key) : [...prev, key]));
  };

  useEffect(() => {
    let alive = true;
    if (!id) return;

    setLoading(true);
    setErr("");

    Promise.all([
      api<ProjectEditModel>(`/projects/${id}`),
      api<ProjectEditMeta>(`/projects/meta`),
      api<RateCardSummary[]>(`/masters/rate-cards`).catch(() => []),
      getMe().catch(() => null),
    ])
      .then(([project, editMeta, rateCardRows, meRes]) => {
        if (!alive) return;
        setModel(project);
        setMeta(editMeta);
        setRateCards(Array.isArray(rateCardRows) ? rateCardRows : []);
        setMe(meRes);

        setName(project.name || "");
        setProjectCode(project.projectCode || "");
        setApprovalsEnabled(!!project.approvalsEnabled);
        setRemarks(project.remarks || "");

        setAdvertiserGroupId(project.advertiserGroup?.id || "");
        setAdvertiserId(project.advertiser?.id || "");
        setBrandId(project.brand?.id || "");
        setProductCategoryId(project.productCategory?.id || "");
        setSenderAccountId(project.senderAccount?.id || "");
        setBillablePartyId(project.billableParty?.id || "");
        setSelectedRateCardId(loadProjectRateCardId(project.id));
        setBillingAgencyKeys(loadProjectBillingAgencyKeys(project.id));
        const storedBillingSourceKey = loadProjectBillingSourceKey(project.id);
        if (safeLocalStorageGet(`${PROJECT_BILLING_SOURCE_STORAGE_PREFIX}${project.id}`)) {
          setBillingSourceKey(storedBillingSourceKey);
        }

        setMediaAgencyId(project.mediaAgency?.id || "");
        setMediaAgencyTeamId(project.mediaAgencyTeam?.id || "");
        setCreativeAgencyId(project.creativeAgency?.id || "");
        setCreativeAgencyTeamId(project.creativeAgencyTeam?.id || "");
        setProductionHouseId(project.productionHouse?.id || "");
        setProductionHouseTeamId(project.productionHouseTeam?.id || "");
        setPostHouseId(project.postHouse?.id || "");
        setPostHouseTeamId(project.postHouseTeam?.id || "");
        setAudioAgencyId(project.audioAgency?.id || "");
        setAudioAgencyTeamId(project.audioAgencyTeam?.id || "");
        setUploaderAgencyId(project.uploaderAgency?.id || "");
        setUploaderAgencyTeamId(project.uploaderAgencyTeam?.id || "");

        const notif = project.notificationConfig || {};
        const loadedTypes = Array.isArray(notif.enabledTypes) ? notif.enabledTypes.filter((n) => Number.isInteger(n)) : [];
        setEnabledNotificationTypes(loadedTypes.length ? loadedTypes : NOTIFICATION_TYPES.map((item) => item.id));
        setNotifyAdvertiserGroup(notif.notifyAdvertiserGroup ?? true);
        setNotifyAdvertiser(notif.notifyAdvertiser ?? true);
        setNotifyBrand(notif.notifyBrand ?? true);
        setNotifyMediaAgency(notif.notifyMediaAgency ?? true);
        setNotifyCreativeAgency(notif.notifyCreativeAgency ?? true);
        setNotifyPostHouse(notif.notifyPostHouse ?? true);
        setNotifyAudioAgency(notif.notifyAudioAgency ?? true);
        setNotifyProductionHouse(notif.notifyProductionHouse ?? true);
        setExtraEmailsText(Array.isArray(notif.extraEmails) ? notif.extraEmails.join("\n") : "");
      })
      .catch((e: any) => {
        if (!alive) return;
        setErr(e?.message || "Failed to load project");
      })
      .finally(() => {
        if (!alive) return;
        setLoading(false);
      });

    return () => {
      alive = false;
    };
  }, [id]);

  const agencies = meta?.agencies || [];
  const teams = meta?.agencyTeams || [];

  const agenciesOf = (type: AgencyType) => agencies.filter((a) => a.type === type);
  const teamsOf = (agencyId: string) => teams.filter((t) => t.agencyId === agencyId);

  const mediaAgencies = useMemo(() => agenciesOf("MEDIA"), [meta]);
  const creativeAgencies = useMemo(() => agenciesOf("CREATIVE"), [meta]);
  const productionHouses = useMemo(() => agenciesOf("PRODUCTION_HOUSE"), [meta]);
  const postHouses = useMemo(() => agenciesOf("POST_HOUSE"), [meta]);
  const audioAgencies = useMemo(() => agenciesOf("AUDIO"), [meta]);
  const uploaderAgencies = useMemo(() => agenciesOf("UPLOADER"), [meta]);

  const senderSources = useMemo(
    () => [
      { label: "Advertiser Group", value: meta?.advertiserGroups.find((item) => item.id === advertiserGroupId)?.name || "" },
      { label: "Advertiser", value: meta?.advertisers.find((item) => item.id === advertiserId)?.name || "" },
      { label: "Brand", value: meta?.brands.find((item) => item.id === brandId)?.name || "" },
    ],
    [meta, advertiserGroupId, advertiserId, brandId],
  );
  const senderMatches = useMemo(() => deriveSenderMatches(meta?.senderAccounts, senderSources), [meta, senderSources]);
  const senderAccountOptions = useMemo(() => {
    const base = (meta?.senderAccounts || []).map((item) => ({ id: item.id, name: item.name }));
    const current = model?.senderAccount?.id && model?.senderAccount?.name ? { id: model.senderAccount.id, name: model.senderAccount.name } : null;
    if (current && !base.some((item) => item.id === current.id)) return [current, ...base];
    return base;
  }, [meta, model]);

  const selectedRateCard = useMemo(
    () => rateCards.find((item) => item.id === selectedRateCardId) || null,
    [rateCards, selectedRateCardId],
  );
  const linkedRateCard = useMemo(() => pickLatestRateCard(rateCards, billablePartyId), [rateCards, billablePartyId]);
  const billingAgencyOptions = useMemo<BillingAgencyChoice[]>(
    () => ([
      { key: "MEDIA" as BillingAgencyKey, label: "Media", value: agencies.find((row) => row.id === mediaAgencyId)?.name || "" },
      { key: "MEDIA_TEAM" as BillingAgencyKey, label: "Media Team", value: formatBillingTeamValue(agencies.find((row) => row.id === mediaAgencyId)?.name, teams.find((row) => row.id === mediaAgencyTeamId)?.name) },
      { key: "CREATIVE" as BillingAgencyKey, label: "Creative", value: agencies.find((row) => row.id === creativeAgencyId)?.name || "" },
      { key: "CREATIVE_TEAM" as BillingAgencyKey, label: "Creative Team", value: formatBillingTeamValue(agencies.find((row) => row.id === creativeAgencyId)?.name, teams.find((row) => row.id === creativeAgencyTeamId)?.name) },
      { key: "PRODUCTION_HOUSE" as BillingAgencyKey, label: "Production", value: agencies.find((row) => row.id === productionHouseId)?.name || "" },
      { key: "PRODUCTION_HOUSE_TEAM" as BillingAgencyKey, label: "Production Team", value: formatBillingTeamValue(agencies.find((row) => row.id === productionHouseId)?.name, teams.find((row) => row.id === productionHouseTeamId)?.name) },
      { key: "POST_HOUSE" as BillingAgencyKey, label: "Post House", value: agencies.find((row) => row.id === postHouseId)?.name || "" },
      { key: "POST_HOUSE_TEAM" as BillingAgencyKey, label: "Post House Team", value: formatBillingTeamValue(agencies.find((row) => row.id === postHouseId)?.name, teams.find((row) => row.id === postHouseTeamId)?.name) },
      { key: "AUDIO" as BillingAgencyKey, label: "Audio", value: agencies.find((row) => row.id === audioAgencyId)?.name || "" },
      { key: "AUDIO_TEAM" as BillingAgencyKey, label: "Audio Team", value: formatBillingTeamValue(agencies.find((row) => row.id === audioAgencyId)?.name, teams.find((row) => row.id === audioAgencyTeamId)?.name) },
      { key: "UPLOADER" as BillingAgencyKey, label: "Uploader", value: agencies.find((row) => row.id === uploaderAgencyId)?.name || "" },
      { key: "UPLOADER_TEAM" as BillingAgencyKey, label: "Uploader Team", value: formatBillingTeamValue(agencies.find((row) => row.id === uploaderAgencyId)?.name, teams.find((row) => row.id === uploaderAgencyTeamId)?.name) },
    ] as BillingAgencyChoice[]).filter((item) => Boolean(item.value)),
    [agencies, teams, mediaAgencyId, mediaAgencyTeamId, creativeAgencyId, creativeAgencyTeamId, productionHouseId, productionHouseTeamId, postHouseId, postHouseTeamId, audioAgencyId, audioAgencyTeamId, uploaderAgencyId, uploaderAgencyTeamId],
  );
  const billingAgencyOptionsSignature = useMemo(() => billingAgencyOptions.map((item) => `${item.key}:${item.value}`).join("|"), [billingAgencyOptions]);
  useEffect(() => {
    const available = new Set(billingAgencyOptions.map((item) => item.key));
    setBillingAgencyKeys((prev) => prev.filter((key) => available.has(key)));
  }, [billingAgencyOptionsSignature]);
  const billingAgencySummary = useMemo(
    () => billingAgencyOptions.filter((item) => billingAgencyKeys.includes(item.key)).map(({ label, value }) => ({ label, value })),
    [billingAgencyOptions, billingAgencyKeys],
  );
  const billingSourceOptions = useMemo<BillingSourceChoice[]>(
    () => ([
      { key: "ADVERTISER_GROUP" as BillingSourceKey, label: "Advertiser Group", value: meta?.advertiserGroups.find((item) => item.id === advertiserGroupId)?.name || "" },
      { key: "ADVERTISER" as BillingSourceKey, label: "Advertiser", value: meta?.advertisers.find((item) => item.id === advertiserId)?.name || "" },
      { key: "BRAND" as BillingSourceKey, label: "Brand", value: meta?.brands.find((item) => item.id === brandId)?.name || "" },
      ...billingAgencyOptions
        .filter((item) => billingAgencyKeys.includes(item.key))
        .map((item) => ({ key: item.key as BillingSourceKey, label: item.label, value: item.value })),
    ] as BillingSourceChoice[]).filter((item) => Boolean(item.value)),
    [meta, advertiserGroupId, advertiserId, brandId, billingAgencyOptions, billingAgencyKeys],
  );
  const billingSourceOptionsSignature = useMemo(() => billingSourceOptions.map((item) => `${item.key}:${item.value}`).join("|"), [billingSourceOptions]);
  useEffect(() => {
    if (!billingSourceKey) return;
    const currentAvailable = billingSourceOptions.find((item) => item.key === billingSourceKey);
    if (!currentAvailable) setBillingSourceKey("");
  }, [billingSourceOptionsSignature, billingSourceKey]);
  const selectedBillingSource = useMemo(
    () => billingSourceOptions.find((item) => item.key === billingSourceKey) || null,
    [billingSourceOptions, billingSourceKey],
  );

  useEffect(() => {
    if (!billingSourceKey) return;
    if (isBillingTeamKey(billingSourceKey)) return;
    const nextBillablePartyId = billingSourceKey === "ADVERTISER_GROUP"
      ? advertiserGroupId
      : billingSourceKey === "ADVERTISER"
      ? advertiserId
      : billingSourceKey === "BRAND"
      ? brandId
      : billingSourceKey === "MEDIA"
      ? mediaAgencyId
      : billingSourceKey === "CREATIVE"
      ? creativeAgencyId
      : billingSourceKey === "PRODUCTION_HOUSE"
      ? productionHouseId
      : billingSourceKey === "POST_HOUSE"
      ? postHouseId
      : billingSourceKey === "AUDIO"
      ? audioAgencyId
      : billingSourceKey === "UPLOADER"
      ? uploaderAgencyId
      : "";
    setBillablePartyId(nextBillablePartyId || "");
  }, [billingSourceKey, advertiserGroupId, advertiserId, brandId, mediaAgencyId, creativeAgencyId, productionHouseId, postHouseId, audioAgencyId, uploaderAgencyId]);

  const rateCardOptions = useMemo(() => {
    const base = (rateCards || []).map((item) => ({ id: item.id, name: item.name }));
    const current = selectedRateCard?.id && selectedRateCard?.name ? { id: selectedRateCard.id, name: selectedRateCard.name } : null;
    if (current && !base.some((item) => item.id === current.id)) return [current, ...base];
    return base;
  }, [rateCards, selectedRateCard]);

  const statusTone = (model?.status || "").toUpperCase() === "CLOSED" ? "#b91c1c" : "#166534";
  const statusBg = (model?.status || "").toUpperCase() === "CLOSED" ? "#fef2f2" : "#f0fdf4";

  const extraEmails = useMemo(() => uniqEmails(extraEmailsText), [extraEmailsText]);
  const selectedNotificationLabels = useMemo(
    () => NOTIFICATION_TYPES.filter((item) => enabledNotificationTypes.includes(item.id)).map((item) => item.label),
    [enabledNotificationTypes],
  );

  const notificationGroupsSummary = useMemo(() => {
    const selected: Partial<Record<NotificationGroupKey, boolean>> = {
      notifyAdvertiserGroup,
      notifyAdvertiser,
      notifyBrand,
      notifyMediaAgency,
      notifyCreativeAgency,
      notifyPostHouse,
      notifyAudioAgency,
      notifyProductionHouse,
    };
    return NOTIFICATION_GROUPS.filter((group) => !!selected[group.key]).map((group) => group.label);
  }, [
    notifyAdvertiserGroup,
    notifyAdvertiser,
    notifyBrand,
    notifyMediaAgency,
    notifyCreativeAgency,
    notifyPostHouse,
    notifyAudioAgency,
    notifyProductionHouse,
  ]);

  const save = async () => {
    if (!id) return;
    setSaving(true);
    setErr("");
    try {
      await api(`/projects/${id}`, {
        method: "PATCH",
        body: JSON.stringify({
          name: name.trim(),
          projectCode: canManualProjectCode ? (projectCode.trim() || null) : undefined,
          approvalsEnabled,
          remarks: remarks.trim() || null,
          advertiserGroupId: advertiserGroupId || null,
          advertiserId: advertiserId || null,
          brandId: brandId || null,
          productCategoryId: productCategoryId || null,
          senderAccountId: senderAccountId || null,
          billablePartyId: billablePartyId || null,
          mediaAgencyId: mediaAgencyId || null,
          mediaAgencyTeamId: mediaAgencyTeamId || null,
          creativeAgencyId: creativeAgencyId || null,
          creativeAgencyTeamId: creativeAgencyTeamId || null,
          productionHouseId: productionHouseId || null,
          productionHouseTeamId: productionHouseTeamId || null,
          postHouseId: postHouseId || null,
          postHouseTeamId: postHouseTeamId || null,
          audioAgencyId: audioAgencyId || null,
          audioAgencyTeamId: audioAgencyTeamId || null,
          uploaderAgencyId: uploaderAgencyId || null,
          uploaderAgencyTeamId: uploaderAgencyTeamId || null,
          notification: {
            notifyAdvertiserGroup,
            notifyAdvertiser,
            notifyBrand,
            notifyMediaAgency,
            notifyCreativeAgency,
            notifyPostHouse,
            notifyAudioAgency,
            notifyProductionHouse,
            extraEmails,
            enabledTypes: enabledNotificationTypes.slice().sort((a, b) => a - b),
          },
        }),
      });
      saveProjectBillingAgencyKeys(id, billingAgencyKeys);
      saveProjectBillingSourceKey(id, billingSourceKey);
      saveProjectRateCardId(id, selectedRateCardId);
      nav("/projects");
    } catch (e: any) {
      setErr(e?.message || "Save failed");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="card" style={{ maxWidth: 1120, margin: "0 auto", display: "grid", gap: 16 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 12 }}>
        <div>
          <div style={{ fontSize: 28, fontWeight: 900, color: "#0f172a" }}>Edit Project</div>
          <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginTop: 8 }}>
            <span style={{ padding: "6px 10px", borderRadius: 999, background: "#f8fafc", border: "1px solid rgba(15,23,42,0.08)", fontSize: 12, fontWeight: 700 }}>
              Project # {model?.projectNumber || "—"}
            </span>
            <span style={{ padding: "6px 10px", borderRadius: 999, background: statusBg, border: `1px solid ${statusTone}22`, color: statusTone, fontSize: 12, fontWeight: 800 }}>
              {model?.status || "OPEN"}
            </span>
          </div>
        </div>
        <button type="button" onClick={() => nav("/projects")}>Back</button>
      </div>

      {loading && <div style={{ opacity: 0.72 }}>Loading project details…</div>}
      {err && <div style={{ color: "#b91c1c", fontWeight: 700 }}>{err}</div>}

      {!loading && model && meta && (
        <>
          <SectionCard title="Basic Details" subtitle="Main project details and approval setting.">
            <div style={gridStyle()}>
              <div className="mastersFilters__field">
                <div className="mastersFilters__label">Project Name *</div>
                <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Project Name" />
              </div>

              <div className="mastersFilters__field">
                <div className="mastersFilters__label">Project Number *</div>
                <input value={model.projectNumber || ""} readOnly disabled />
              </div>

              <div className="mastersFilters__field">
                <div className="mastersFilters__label">Project Code</div>
                <input
                  value={projectCode}
                  onChange={(e) => setProjectCode(e.target.value)}
                  placeholder={canManualProjectCode ? "Project Code" : "Auto / read only"}
                  disabled={!canManualProjectCode}
                />
                {!canManualProjectCode ? (
                  <div style={{ marginTop: 4, fontSize: 12, color: "#64748b" }}>You do not have permission to change project code.</div>
                ) : null}
              </div>

              <div className="mastersFilters__field">
                <div className="mastersFilters__label">Status</div>
                <input value={model.status || "OPEN"} readOnly disabled />
              </div>
            </div>

            <div style={{ marginTop: 14, display: "flex", alignItems: "center", gap: 10 }}>
              <input
                type="checkbox"
                checked={approvalsEnabled}
                onChange={(e) => setApprovalsEnabled(e.target.checked)}
                style={{ width: 18, height: 18 }}
              />
              <span style={{ fontWeight: 800 }}>Approvals enabled</span>
            </div>

            <div style={{ marginTop: 14 }}>
              <div className="mastersFilters__label">Remarks</div>
              <textarea
                value={remarks}
                onChange={(e) => setRemarks(e.target.value)}
                placeholder="Remarks"
                rows={4}
                style={{ width: "100%", resize: "vertical" }}
              />
            </div>
          </SectionCard>

          <SectionCard title="Advertiser & Brand" subtitle="Project business details.">
            <div style={{ display: "grid", gap: 14 }}>
              <div style={gridStyle()}>
                <SearchSelect label="Advertiser Group *" value={advertiserGroupId} onChange={setAdvertiserGroupId} options={meta.advertiserGroups} placeholder="Search advertiser group" />
                <SearchSelect label="Advertiser *" value={advertiserId} onChange={setAdvertiserId} options={meta.advertisers} placeholder="Search advertiser" />
                <SearchSelect label="Brand *" value={brandId} onChange={setBrandId} options={meta.brands} placeholder="Search brand" />
                <SearchSelect label="Sector / Product Category *" value={productCategoryId} onChange={setProductCategoryId} options={meta.productCategories} placeholder="Search product category" />
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 10 }}>
                <BillingSummaryTile label="Project Billable Party" value={selectedBillingSource?.value || model?.billableParty?.name || ""} tone="blue" />
                <BillingSummaryTile label="Project Rate Card" value={selectedRateCard?.name || linkedRateCard?.name || ""} tone="emerald" />
              </div>
            </div>
          </SectionCard>

          <SectionCard
            title="Sender Account Context"
            subtitle="Pick the official sender account when needed. Derived matches remain visible for old or unlinked projects."
          >
            <div style={{ display: "grid", gap: 12 }}>
              <SearchSelect label="Sender Account" value={senderAccountId} onChange={setSenderAccountId} options={senderAccountOptions} placeholder="Search sender account" />
              <SenderAccountContextCard matches={senderMatches} />
            </div>
          </SectionCard>

          <SectionCard title="Optional assignments" subtitle="Billable Party, Rate Card, and billing scope can stay empty and be updated later.">
            <div style={{ display: "grid", gap: 12 }}>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: 14, alignItems: "start" }}>
                <div style={{ display: "grid", gap: 12 }}>
                  <BillingSourceSelector
                  options={billingSourceOptions}
                  selectedKey={billingSourceKey}
                  onChange={(next) => {
                    setBillingSourceKey(next);
                    if (!next) setBillablePartyId("");
                  }}
                />
                  <SearchSelect label="Rate Card" value={selectedRateCardId} onChange={setSelectedRateCardId} options={rateCardOptions} placeholder="Search rate card" />
                </div>
                <div style={{ display: "grid", gap: 12 }}>
                  <BillingAgencySelector options={billingAgencyOptions} selectedKeys={billingAgencyKeys} onToggle={toggleBillingAgencyKey} />
                  <div style={{ fontSize: 12, color: "#64748b" }}>
                    {billingAgencySummary.length ? `Billing agency scope: ${billingAgencySummary.map((item) => item.value).join(", ")}` : null}
                  </div>
                </div>
              </div>
            </div>
          </SectionCard>

          <SectionCard title="Agencies" subtitle="Assign agencies and their teams without changing other workflows.">
            <div style={gridStyle()}>
              <SearchSelect label="Media Agency" value={mediaAgencyId} onChange={(next) => { setMediaAgencyId(next); setMediaAgencyTeamId(""); }} options={mediaAgencies} placeholder="Search media agency" />
              <SearchSelect label="Media Agency Team" value={mediaAgencyTeamId} onChange={setMediaAgencyTeamId} options={teamsOf(mediaAgencyId)} placeholder="Search media team" disabled={!mediaAgencyId} />

              <SearchSelect label="Creative Agency" value={creativeAgencyId} onChange={(next) => { setCreativeAgencyId(next); setCreativeAgencyTeamId(""); }} options={creativeAgencies} placeholder="Search creative agency" />
              <SearchSelect label="Creative Agency Team" value={creativeAgencyTeamId} onChange={setCreativeAgencyTeamId} options={teamsOf(creativeAgencyId)} placeholder="Search creative team" disabled={!creativeAgencyId} />

              <SearchSelect label="Production House" value={productionHouseId} onChange={(next) => { setProductionHouseId(next); setProductionHouseTeamId(""); }} options={productionHouses} placeholder="Search production house" />
              <SearchSelect label="Production House Team" value={productionHouseTeamId} onChange={setProductionHouseTeamId} options={teamsOf(productionHouseId)} placeholder="Search production team" disabled={!productionHouseId} />

              <SearchSelect label="Post House" value={postHouseId} onChange={(next) => { setPostHouseId(next); setPostHouseTeamId(""); }} options={postHouses} placeholder="Search post house" />
              <SearchSelect label="Post House Team" value={postHouseTeamId} onChange={setPostHouseTeamId} options={teamsOf(postHouseId)} placeholder="Search post team" disabled={!postHouseId} />

              <SearchSelect label="Audio Agency" value={audioAgencyId} onChange={(next) => { setAudioAgencyId(next); setAudioAgencyTeamId(""); }} options={audioAgencies} placeholder="Search audio agency" />
              <SearchSelect label="Audio Agency Team" value={audioAgencyTeamId} onChange={setAudioAgencyTeamId} options={teamsOf(audioAgencyId)} placeholder="Search audio team" disabled={!audioAgencyId} />
            </div>
          </SectionCard>

          <SectionCard title="Uploader" subtitle="Uploader agency details for this project.">
            <div style={gridStyle()}>
              <SearchSelect label="Uploader Agency" value={uploaderAgencyId} onChange={(next) => { setUploaderAgencyId(next); setUploaderAgencyTeamId(""); }} options={uploaderAgencies} placeholder="Search uploader agency" />
              <SearchSelect label="Uploader Agency Team" value={uploaderAgencyTeamId} onChange={setUploaderAgencyTeamId} options={teamsOf(uploaderAgencyId)} placeholder="Search uploader team" disabled={!uploaderAgencyId} />
            </div>
          </SectionCard>

          <SectionCard title="Notifications" subtitle="Edit project notification types, recipient groups, and extra recipient emails.">
            <div style={{ display: "grid", gap: 16 }}>
              <div>
                <div
                  style={{
                    marginBottom: 12,
                    padding: "12px 14px",
                    borderRadius: 12,
                    border: "1px solid rgba(37,99,235,0.18)",
                    background: "#eff6ff",
                    fontSize: 12,
                    color: "#1e3a8a",
                    lineHeight: 1.5,
                  }}
                >
                  Types <b>9</b>, <b>10</b>, and <b>11</b> use the linked receiver account emails from selected destination receiver accounts.
                  Type <b>9</b> is sent only for approval-required destinations, type <b>10</b> after approval, and type <b>11</b>
                  when the file is sent for delivery for non-approval destinations.
                </div>
                <div className="mastersFilters__label" style={{ marginBottom: 8 }}>Enabled Notification Types</div>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 10 }}>
                  {NOTIFICATION_TYPES.map((item) => {
                    const checked = enabledNotificationTypes.includes(item.id);
                    return (
                      <label
                        key={item.id}
                        style={{
                          display: "inline-flex",
                          alignItems: "center",
                          gap: 8,
                          padding: "10px 12px",
                          borderRadius: 999,
                          border: checked ? "1px solid #86efac" : "1px solid rgba(148,163,184,0.35)",
                          background: checked ? "#f0fdf4" : "#ffffff",
                          cursor: "pointer",
                          fontSize: 13,
                          fontWeight: 700,
                          color: checked ? "#166534" : "#334155",
                        }}
                      >
                        <input
                          type="checkbox"
                          checked={checked}
                          onChange={(e) => {
                            const next = e.target.checked;
                            setEnabledNotificationTypes((prev) =>
                              next ? Array.from(new Set([...prev, item.id])).sort((a, b) => a - b) : prev.filter((id) => id !== item.id),
                            );
                          }}
                          style={{ width: 16, height: 16 }}
                        />
                        <span>{item.id}. {item.label}</span>
                      </label>
                    );
                  })}
                </div>
                <div style={{ marginTop: 8, fontSize: 12, color: "#64748b" }}>
                  Selected: {selectedNotificationLabels.length ? selectedNotificationLabels.join(", ") : "No notification types selected"}
                </div>
              </div>

              <div>
                <div className="mastersFilters__label" style={{ marginBottom: 8 }}>Recipient Groups</div>
                <div style={{ ...gridStyle(220), gap: 10 }}>
                  {[
                    { key: "notifyAdvertiserGroup", label: "Advertiser Group", checked: notifyAdvertiserGroup, setChecked: setNotifyAdvertiserGroup },
                    { key: "notifyAdvertiser", label: "Advertiser", checked: notifyAdvertiser, setChecked: setNotifyAdvertiser },
                    { key: "notifyBrand", label: "Brand", checked: notifyBrand, setChecked: setNotifyBrand },
                    { key: "notifyMediaAgency", label: "Media Agency", checked: notifyMediaAgency, setChecked: setNotifyMediaAgency },
                    { key: "notifyCreativeAgency", label: "Creative Agency", checked: notifyCreativeAgency, setChecked: setNotifyCreativeAgency },
                    { key: "notifyPostHouse", label: "Post House", checked: notifyPostHouse, setChecked: setNotifyPostHouse },
                    { key: "notifyAudioAgency", label: "Audio Agency", checked: notifyAudioAgency, setChecked: setNotifyAudioAgency },
                    { key: "notifyProductionHouse", label: "Production House", checked: notifyProductionHouse, setChecked: setNotifyProductionHouse },
                  ].map((item) => (
                    <label
                      key={item.key}
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: 10,
                        padding: "12px 14px",
                        borderRadius: 14,
                        border: "1px solid rgba(148,163,184,0.22)",
                        background: "#f8fafc",
                        cursor: "pointer",
                        fontSize: 13,
                        fontWeight: 700,
                        color: "#0f172a",
                      }}
                    >
                      <input
                        type="checkbox"
                        checked={item.checked}
                        onChange={(e) => item.setChecked(e.target.checked)}
                        style={{ width: 16, height: 16 }}
                      />
                      <span>{item.label}</span>
                    </label>
                  ))}
                </div>
                <div style={{ marginTop: 8, fontSize: 12, color: "#64748b" }}>
                  Active groups: {notificationGroupsSummary.length ? notificationGroupsSummary.join(", ") : "None"}
                </div>
              </div>

              <div>
                <div className="mastersFilters__label">Extra Notification Emails</div>
                <textarea
                  value={extraEmailsText}
                  onChange={(e) => setExtraEmailsText(e.target.value)}
                  placeholder="person1@example.com, person2@example.com"
                  rows={5}
                  style={{ width: "100%", resize: "vertical" }}
                />
                <div style={{ marginTop: 8, fontSize: 12, color: "#64748b" }}>
                  Unique extra emails: {extraEmails.length}
                </div>
              </div>
            </div>
          </SectionCard>

          <div className="row" style={{ justifyContent: "flex-end", gap: 10 }}>
            <button type="button" onClick={() => nav("/projects")} disabled={saving}>
              Cancel
            </button>
            <button className="btnPrimary" type="button" onClick={save} disabled={saving || !name.trim()}>
              {saving ? "Saving…" : "Save"}
            </button>
          </div>
        </>
      )}
    </div>
  );
}
