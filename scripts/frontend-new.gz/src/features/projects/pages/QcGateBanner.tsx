import { useEffect, useState } from "react";
import { getQcGate, type QcGateResult } from "../creatives/creativesApi";
import { useNavigate } from "react-router-dom";

export function QcGateBanner(props: {
  projectId: string;
  scope: "commit" | "send";
  onGate?: (ok: boolean) => void;
}) {
  const nav = useNavigate();
  const [gate, setGate] = useState<QcGateResult | null>(null);
  const [err, setErr] = useState("");

  async function load() {
    setErr("");
    try {
      const res = await getQcGate(props.projectId, props.scope);
      setGate(res);
      props.onGate?.(!!res?.ok);
    } catch (e: any) {
      const msg = e?.message || "QC gate check failed";
      setErr(msg);
      // safer default: block action until we can verify gate
      setGate({ ok: false, blockers: [] });
      props.onGate?.(false);
    }
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [props.projectId, props.scope]);

  if (!gate) return null;
  if (gate.ok) return null;

  return (
    <div className="card" style={{ border: "1px solid #ffb3b3" }}>
      <div style={{ display: "flex", justifyContent: "space-between", gap: 8, alignItems: "center" }}>
        <b style={{ color: "#a10000" }}>
          {props.scope === "commit" ? "Commit blocked" : "Send blocked"} — fix QC/uploads
        </b>

        <div style={{ display: "flex", gap: 8 }}>
          <button onClick={() => load()}>Recheck</button>
          <button onClick={() => nav(`/projects/${props.projectId}/qc`)}>Go to QC</button>
        </div>
      </div>

      {err ? (
        <div style={{ marginTop: 8, fontSize: 13, color: "#a10000" }}>
          Gate check failed: {err}
        </div>
      ) : null}

      <div style={{ marginTop: 8, fontSize: 13 }}>
        {(gate.blockers || []).length === 0 && !err ? (
          <div style={{ opacity: 0.85 }}>Blocked by QC gate (no blockers listed). Recheck or open QC step.</div>
        ) : null}

        {(gate.blockers || []).map((b: any) => {
          const reasons = Array.isArray(b.qcFailureReasons) ? b.qcFailureReasons : [];
          return (
            <div key={b.creativeId} style={{ padding: "6px 0", borderTop: "1px solid rgba(0,0,0,0.06)" }}>
              <b>{b.valid || b.creativeId}</b> — {b.missingSource ? "SOURCE missing" : `QC=${b.qcStatus}`}
              {reasons.length ? (
                <div style={{ opacity: 0.8, marginTop: 4 }}>Reasons: {reasons.join(", ")}</div>
              ) : b.qcNotes ? (
                <div style={{ opacity: 0.8, marginTop: 4 }}>Notes: {b.qcNotes}</div>
              ) : null}
            </div>
          );
        })}
      </div>
    </div>
  );
}
