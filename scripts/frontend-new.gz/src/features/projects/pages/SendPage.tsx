import { useEffect, useMemo, useState } from "react";
import { useNavigate, useOutletContext, useParams } from "react-router-dom";
import { api } from "../../../lib/api";
import { getMe, hasPerm, type MeResponse } from "../../../lib/me";
import type { OutletCtx } from "../types";

type SendQueueRow = {
  planLineId: string;
  creativeId: string;
  valid: string;
  caption?: string | null;
  duration?: string | null;
  languages?: string[];
  format?: string | null;
  audio?: string | null;
  destinationName: string;
  channelName: string;
  slaName?: string | null;
  autoSendAt?: string | null;
  uploadedAt?: string | null;
  filename?: string | null;
  fileSizeBytes?: string | null;
  qcStatus?: string | null;
  approvalStatus?: string | null;
  lastApprovalAt?: string | null;
  presetLabel?: string | null;
  presetKey?: string | null;
  presetStatus?: string | null;
  channelServerStatus?: string | null;
};

type SendQueueResponse = {
  activePlan: { id: string; version: number } | null;
  unsentLines: number;
  rows: SendQueueRow[];
};

function fmtDateTime(v?: string | null) {
  if (!v) return "Manual send";
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) return "";
  return d.toLocaleString([], {
    year: "numeric",
    month: "short",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
  });
}

function fmtBytes(v?: string | null) {
  const n = v ? Number(v) : 0;
  if (!Number.isFinite(n) || n <= 0) return "";
  const kb = n / 1024;
  if (kb < 1024) return `${Math.round(kb)} KB`;
  const mb = kb / 1024;
  if (mb < 1024) return `${mb.toFixed(1)} MB`;
  const gb = mb / 1024;
  return `${gb.toFixed(2)} GB`;
}

const headerCellStyle: React.CSSProperties = {
  border: "1px solid #d9e2ec",
  background: "#f6f8fb",
  padding: "10px 12px",
  textAlign: "left",
  fontSize: 12,
  fontWeight: 800,
  letterSpacing: 0.2,
  whiteSpace: "nowrap",
  position: "sticky",
  top: 0,
  zIndex: 1,
};

const bodyCellStyle: React.CSSProperties = {
  border: "1px solid #d9e2ec",
  padding: "10px 12px",
  fontSize: 13,
  verticalAlign: "middle",
  background: "#fff",
};

export function SendPage() {
  const { id: projectId = "" } = useParams();
  const nav = useNavigate();
  const { wf, reload } = useOutletContext<OutletCtx>();

  const [me, setMe] = useState<MeResponse | null>(null);
  const [rows, setRows] = useState<SendQueueRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [sending, setSending] = useState(false);
  const [err, setErr] = useState<string>("");

  const canSend = !!wf?.actions?.canSend && hasPerm(me, "ORDER_SEND") && rows.length > 0 && !sending;

  async function loadMe() {
    try {
      setMe(await getMe());
    } catch {
      setMe(null);
    }
  }

  async function load() {
    if (!projectId) return;
    setErr("");
    setLoading(true);
    try {
      const res = await api<SendQueueResponse>(`/projects/${projectId}/send-queue`);
      setRows(Array.isArray(res?.rows) ? res.rows : []);
    } catch (e: any) {
      setErr(e?.message || "Failed to load send queue");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadMe();
  }, []);

  useEffect(() => {
    load();
  }, [projectId]);

  const blockedMsg = useMemo(() => {
    const reasons = wf?.actions?.sendReasons || [];
    if (!reasons.length) return "";
    return reasons.map((r: any) => r?.message || r?.code).filter(Boolean).join(" · ");
  }, [wf?.actions?.sendReasons]);

  async function doSend() {
    if (!projectId) return;
    setErr("");
    setSending(true);
    try {
      const created: any = await api(`/projects/${projectId}/orders`, { method: "POST" });
      const orderId = created?.id;
      if (!orderId) throw new Error("Order create failed (missing id)");

      await api(`/orders/${orderId}/send`, { method: "POST" });

      await reload?.();
      await load();
      nav(`/projects/${projectId}/tracking`);
    } catch (e: any) {
      setErr(e?.message || "Send failed");
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="card" style={{ display: "grid", gap: 10 }}>
      <div className="row" style={{ justifyContent: "space-between", alignItems: "center" }}>
        <div>
          <div style={{ fontSize: 20, fontWeight: 800 }}>Send</div>
        </div>

        <div className="row" style={{ gap: 8, flexWrap: "wrap" }}>
          <button className="btn" onClick={() => load()} disabled={loading || sending}>
            Refresh
          </button>
          <button className="btn" onClick={() => nav(`/projects/${projectId}/tracking`)} disabled={sending}>
            Tracking
          </button>
          <button
            className="btn"
            onClick={doSend}
            disabled={!canSend}
            title={!hasPerm(me, "ORDER_SEND") ? "Missing permission: ORDER_SEND" : blockedMsg || ""}
          >
            {sending ? "Sending..." : `Send (${rows.length})`}
          </button>
        </div>
      </div>

      {blockedMsg && (
        <div className="card" style={{ borderColor: "#f5a", background: "#fff5fa" }}>
          {blockedMsg}
        </div>
      )}
      {err && (
        <div className="card" style={{ borderColor: "#f5a", background: "#fff5fa" }}>
          {err}
        </div>
      )}

      <div style={{ fontSize: 12, opacity: 0.7 }}>
        {loading ? "Loading..." : `${rows.length} line(s) in send queue`}
      </div>

      <div
        style={{
          overflowX: "auto",
          border: "1px solid #d9e2ec",
          borderRadius: 16,
          background: "#fff",
          boxShadow: "0 10px 24px rgba(15, 23, 42, 0.04)",
        }}
      >
        <table
          style={{
            minWidth: 1600,
            width: "100%",
            borderCollapse: "collapse",
            tableLayout: "auto",
          }}
        >
          <thead>
            <tr>
              <th style={headerCellStyle}>VALID</th>
              <th style={headerCellStyle}>Caption</th>
              <th style={headerCellStyle}>Duration</th>
              <th style={headerCellStyle}>Lang</th>
              <th style={headerCellStyle}>Type</th>
              <th style={headerCellStyle}>SLA</th>
              <th style={headerCellStyle}>ETA</th>
              <th style={headerCellStyle}>Destination</th>
              <th style={headerCellStyle}>Channel</th>
              <th style={headerCellStyle}>Preset</th>
              <th style={headerCellStyle}>Preset status</th>
              <th style={headerCellStyle}>Uploaded</th>
              <th style={headerCellStyle}>Size</th>
              <th style={headerCellStyle}>Filename</th>
              <th style={headerCellStyle}>QC</th>
              <th style={headerCellStyle}>Approvals</th>
              <th style={headerCellStyle}>Last approval</th>
              <th style={headerCellStyle}>Server</th>
            </tr>
          </thead>
          <tbody>
            {rows.length === 0 ? (
              <tr>
                <td colSpan={18} style={{ ...bodyCellStyle, opacity: 0.7 }}>
                  Nothing to send.
                </td>
              </tr>
            ) : (
              rows.map((r, idx) => (
                <tr key={r.planLineId} style={idx % 2 === 1 ? { background: "#fbfdff" } : undefined}>
                  <td style={{ ...bodyCellStyle, fontWeight: 700, background: idx % 2 === 1 ? "#fbfdff" : "#fff" }}>
                    {r.valid}
                  </td>
                  <td style={{ ...bodyCellStyle, background: idx % 2 === 1 ? "#fbfdff" : "#fff" }}>{r.caption || ""}</td>
                  <td style={{ ...bodyCellStyle, background: idx % 2 === 1 ? "#fbfdff" : "#fff" }}>{r.duration || ""}</td>
                  <td style={{ ...bodyCellStyle, background: idx % 2 === 1 ? "#fbfdff" : "#fff" }}>{(r.languages || []).join(", ")}</td>
                  <td style={{ ...bodyCellStyle, background: idx % 2 === 1 ? "#fbfdff" : "#fff" }}>{r.format || ""}</td>
                  <td style={{ ...bodyCellStyle, background: idx % 2 === 1 ? "#fbfdff" : "#fff" }}>{r.slaName || ""}</td>
                  <td style={{ ...bodyCellStyle, background: idx % 2 === 1 ? "#fbfdff" : "#fff" }} title={r.autoSendAt || ""}>
                    {fmtDateTime(r.autoSendAt)}
                  </td>
                  <td style={{ ...bodyCellStyle, background: idx % 2 === 1 ? "#fbfdff" : "#fff" }}>{r.destinationName}</td>
                  <td style={{ ...bodyCellStyle, background: idx % 2 === 1 ? "#fbfdff" : "#fff" }}>{r.channelName}</td>
                  <td style={{ ...bodyCellStyle, background: idx % 2 === 1 ? "#fbfdff" : "#fff" }} title={r.presetKey || ""}>
                    {r.presetLabel || r.presetKey || "—"}
                  </td>
                  <td style={{ ...bodyCellStyle, background: idx % 2 === 1 ? "#fbfdff" : "#fff" }}>{r.presetStatus || (r.presetKey ? "NOT_REQUESTED" : "DIRECT")}</td>
                  <td style={{ ...bodyCellStyle, background: idx % 2 === 1 ? "#fbfdff" : "#fff" }}>
                    {r.uploadedAt ? new Date(r.uploadedAt).toLocaleString() : ""}
                  </td>
                  <td style={{ ...bodyCellStyle, background: idx % 2 === 1 ? "#fbfdff" : "#fff" }}>{fmtBytes(r.fileSizeBytes)}</td>
                  <td
                    style={{
                      ...bodyCellStyle,
                      background: idx % 2 === 1 ? "#fbfdff" : "#fff",
                      maxWidth: 260,
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                      whiteSpace: "nowrap",
                    }}
                    title={r.filename || ""}
                  >
                    {r.filename || ""}
                  </td>
                  <td style={{ ...bodyCellStyle, background: idx % 2 === 1 ? "#fbfdff" : "#fff" }}>{r.qcStatus || ""}</td>
                  <td style={{ ...bodyCellStyle, background: idx % 2 === 1 ? "#fbfdff" : "#fff" }}>{r.approvalStatus || "Not required"}</td>
                  <td style={{ ...bodyCellStyle, background: idx % 2 === 1 ? "#fbfdff" : "#fff" }}>{fmtDateTime(r.lastApprovalAt)}</td>
                  <td style={{ ...bodyCellStyle, background: idx % 2 === 1 ? "#fbfdff" : "#fff" }}>{r.channelServerStatus || ""}</td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
