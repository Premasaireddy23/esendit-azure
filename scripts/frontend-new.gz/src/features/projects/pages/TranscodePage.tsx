import { useEffect, useMemo, useRef, useState } from "react";
import { useParams } from "react-router-dom";
import { api, apiUrl, getToken } from "../../../lib/api";
import { getMe, hasPerm, type MeResponse } from "../../../lib/me";
import { listCreatives, type CreativeLine } from "../services/creativesApi";
import { presetDisplayName, presetExtBadge } from "../../presets/presetDisplay";
import * as XLSX from "xlsx";

type Preset = { key: string; label?: string; ext: string; mimeType: string; args: string[] };

type PresetJob = {
  id: string;
  status: "QUEUED" | "PENDING" | "RUNNING" | "SUCCEEDED" | "FAILED" | string;
  error?: string | null;
  payload?: any;
  result?: any;
  createdAt?: string;
  startedAt?: string | null;
  endedAt?: string | null;
};

function fmtBytes(v: any) {
  const n = typeof v === "string" ? Number(v) : typeof v === "number" ? v : 0;
  if (!Number.isFinite(n) || n <= 0) return "0 B";
  const units = ["B", "KB", "MB", "GB", "TB"];
  let i = 0;
  let x = n;
  while (x >= 1024 && i < units.length - 1) {
    x /= 1024;
    i++;
  }
  const v2 = i === 0 ? String(Math.round(x)) : x.toFixed(x >= 10 ? 1 : 2);
  return `${v2} ${units[i]}`;
}

function QcPill({ status }: { status?: string | null }) {
  const s = (status || "NOT_STARTED").toUpperCase();

  let bg = "#f1f5f9";
  let border = "#cbd5e1";
  let dot = "#64748b";

  if (s === "PASSED") {
    bg = "#ecfdf5";
    border = "#34d399";
    dot = "#10b981";
  } else if (s === "FAILED") {
    bg = "#fff1f2";
    border = "#fb7185";
    dot = "#ef4444";
  } else if (s === "IN_PROGRESS") {
    bg = "#eff6ff";
    border = "#93c5fd";
    dot = "#3b82f6";
  } else if (s === "NOT_STARTED") {
    bg = "#f8fafc";
    border = "#e2e8f0";
    dot = "#94a3b8";
  }

  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 6,
        padding: "2px 10px",
        borderRadius: 999,
        fontSize: 12,
        fontWeight: 700,
        background: bg,
        border: `1px solid ${border}`,
      }}
      title={s}
    >
      <span style={{ width: 8, height: 8, borderRadius: 999, background: dot }} />
      {s}
    </span>
  );
}

function getSourceAsset(r: CreativeLine) {
  return r.assets?.find((a) => a.type === "SOURCE");
}

function hasSourceAsset(r: CreativeLine) {
  const a = getSourceAsset(r) as any;
  return !!a && (String(a?.uploadStatus || "").toUpperCase() === "UPLOADED" || !!a?.filename);
}

function openNewTab(url: string) {
  const u = url.startsWith("http") ? url : apiUrl(url);
  window.open(u, "_blank", "noopener,noreferrer");
}

function normToken(v: any) {
  return String(v ?? "")
    .trim()
    .toLowerCase()
    .replace(/[\s_\-]+/g, "");
}

function rowValue(row: any, aliases: string[]) {
  if (!row || typeof row !== "object") return "";
  const entries = Object.entries(row as Record<string, any>);
  const want = new Set(aliases.map(normToken));
  for (const [k, v] of entries) {
    if (want.has(normToken(k))) return String(v ?? "").trim();
  }
  return "";
}

export function TranscodePage() {
  const params = useParams();
  const projectId = String((params as any).id || (params as any).projectId || "");

  const [me, setMe] = useState<MeResponse | null>(null);
  const [rows, setRows] = useState<CreativeLine[]>([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [q, setQ] = useState("");

  // Presets
  const [presetQuery, setPresetQuery] = useState("");
  const [presetVisibilityFilter, setPresetVisibilityFilter] = useState<"NOT_TRANSCODED" | "TRANSCODED" | "ALL">("NOT_TRANSCODED");
  const [presets, setPresets] = useState<Preset[]>([]);
  const [presetsLoading, setPresetsLoading] = useState(false);
  const [presetsErr, setPresetsErr] = useState<string>("");
  const [showTechnical, setShowTechnical] = useState(false);

  // Selection
  const [selectedCreativeIds, setSelectedCreativeIds] = useState<Record<string, boolean>>({});
  const [selectedPresetKeys, setSelectedPresetKeys] = useState<Record<string, boolean>>({});
  const canDownloadMedia = hasPerm(me, "action:media:download");
  const [jobStatusSort, setJobStatusSort] = useState<"NONE" | "ASC" | "DESC">("NONE");
  const [activeStep, setActiveStep] = useState<1 | 2 | 3>(1);
  const [step3Unlocked, setStep3Unlocked] = useState(false);

  // Jobs keyed by `${creativeId}::${presetKey}` (latest per combination)
  const [jobs, setJobs] = useState<
    Record<string, { creativeId: string; presetKey: string; jobId: string; job: PresetJob | null }>
  >({});
  const [jobsLoading, setJobsLoading] = useState(false);
  const [jobsErr, setJobsErr] = useState<string>("");

  const [actionErr, setActionErr] = useState<string>("");
  const [importInfo, setImportInfo] = useState<string>("");
  const [importPairs, setImportPairs] = useState<Record<string, { creativeId: string; presetKey: string }>>({});

  async function apiText(p: string) {
    const token = getToken();
    const res = await fetch(apiUrl(p), {
      headers: token ? { Authorization: `Bearer ${token}` } : undefined,
    });
    if (!res.ok) {
      const t = await res.text().catch(() => "");
      throw new Error(t || `Request failed (${res.status})`);
    }
    return res.text();
  }

  const pollTimer = useRef<number | null>(null);
  const jobsRef = useRef(jobs);
  useEffect(() => {
    jobsRef.current = jobs;
  }, [jobs]);

  async function refresh() {
    if (!projectId) return;
    setLoading(true);
    setErr(null);
    try {
      const data = await listCreatives(projectId);
      setRows(data);
    } catch (e: any) {
      setErr(e?.message || "Failed to load creatives");
    } finally {
      setLoading(false);
    }
  }



  async function refreshPresets() {
    setPresetsLoading(true);
    setPresetsErr("");
    try {
      const r = await api<{ presets: Preset[] }>(`/presets`);
      setPresets(r?.presets || []);
    } catch (e: any) {
      setPresetsErr(e?.message || String(e));
    } finally {
      setPresetsLoading(false);
    }
  }

  const selectedCreatives = useMemo(() => {
    return Object.keys(selectedCreativeIds).filter((k) => selectedCreativeIds[k]);
  }, [selectedCreativeIds]);

  async function refreshJobs() {
    setJobsErr("");
    if (!selectedCreatives.length) {
      setJobs({});
      return;
    }
    setJobsLoading(true);
    try {
      const sourceIds = encodeURIComponent(selectedCreatives.join(","));
      const r = await api<{ jobs: PresetJob[] }>(`/presets/jobs?sourceType=CREATIVE&sourceIds=${sourceIds}`);

      // Backend returns newest first; keep only latest per (creativeId,presetKey)
      const next: Record<string, { creativeId: string; presetKey: string; jobId: string; job: PresetJob | null }> = {};
      for (const j of r?.jobs || []) {
        const srcId = String((j as any).sourceId || "");
        const pk = String((j as any).presetKey || "");
        if (!srcId || !pk) continue;
        const key = `${srcId}::${pk}`;
        if (next[key]) continue;
        next[key] = { creativeId: srcId, presetKey: pk, jobId: String((j as any).id || ""), job: j };
      }
      setJobs(next);
    } catch (e: any) {
      setJobsErr(e?.message || String(e));
    } finally {
      setJobsLoading(false);
    }
  }

  useEffect(() => {
    getMe().then(setMe).catch(() => setMe(null));
  }, []);

  useEffect(() => {
    refresh();
    refreshPresets();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [projectId]);


  // auto-clear selections for creatives no longer present
  useEffect(() => {
    setSelectedCreativeIds((prev) => {
      const next: Record<string, boolean> = { ...prev };
      const keep = new Set(rows.map((r) => r.id));
      Object.keys(next).forEach((k) => {
        if (!keep.has(k)) delete next[k];
      });
      return next;
    });
  }, [rows]);

  // Whenever selected creatives changes, refresh jobs for those creatives
  useEffect(() => {
    refreshJobs();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [selectedCreatives.join("|")]);

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return rows;
    return rows.filter((r) => {
      const hay = [r.valid, r.caption, r.format, r.remarks, r.id].filter(Boolean).join(" ").toLowerCase();
      return hay.includes(s);
    });
  }, [rows, q]);

  const filteredPresets = useMemo(() => {
    const s = presetQuery.trim().toLowerCase();
    return presets.filter((p) => {
      const hay = [presetDisplayName(p), p.label, p.key, p.ext, p.mimeType].filter(Boolean).join(" ").toLowerCase();
      const matchesQuery = !s || hay.includes(s);
      if (!matchesQuery) return false;

      let succeededCount = 0;
      for (const creativeId of selectedCreatives) {
        const item = jobs[`${creativeId}::${p.key}`];
        const st = String(item?.job?.status || "").toUpperCase();
        if (st === "SUCCEEDED") succeededCount += 1;
      }
      const isDoneForSelected = selectedCreatives.length > 0 && succeededCount === selectedCreatives.length;

      if (presetVisibilityFilter === "TRANSCODED") return isDoneForSelected;
      if (presetVisibilityFilter === "NOT_TRANSCODED") return !isDoneForSelected;
      return true;
    });
  }, [presets, presetQuery, presetVisibilityFilter, jobs, selectedCreatives]);

  const groupedPresets = useMemo(() => {
    const groups: Record<string, Preset[]> = {};
    for (const p of filteredPresets) {
      const g = presetExtBadge(p) || "OTHER";
      (groups[g] ||= []).push(p);
    }
    const keys = Object.keys(groups).sort((a, b) => a.localeCompare(b));
    return keys.map((k) => {
      const items = [...groups[k]].sort((a, b) => presetDisplayName(a).localeCompare(presetDisplayName(b)));
      return { group: k, items };
    });
  }, [filteredPresets]);

  const selectedPresetsArr = useMemo(() => {
    return Object.keys(selectedPresetKeys).filter((k) => selectedPresetKeys[k]);
  }, [selectedPresetKeys]);

  // Poll active jobs (only those shown for selected creatives)
  useEffect(() => {
    const hasActive = Object.values(jobs).some((x) => {
      const st = String(x.job?.status || "").toUpperCase();
      return !!st && st !== "SUCCEEDED" && st !== "FAILED";
    });

    if (!hasActive) {
      if (pollTimer.current) {
        window.clearInterval(pollTimer.current);
        pollTimer.current = null;
      }
      return;
    }

    if (pollTimer.current) return;
    pollTimer.current = window.setInterval(async () => {
      const entries = Object.entries(jobsRef.current);
      const active = entries.filter(([, x]) => {
        const st = String(x.job?.status || "").toUpperCase();
        return !!st && st !== "SUCCEEDED" && st !== "FAILED";
      });
      if (!active.length) return;

      for (const [k, x] of active) {
        try {
          const j = await api<any>(`/presets/jobs/${x.jobId}`);
          setJobs((prev) => ({ ...prev, [k]: { ...prev[k], job: j } }));
        } catch {
          // ignore
        }
      }
    }, 2000);

    return () => {
      if (pollTimer.current) {
        window.clearInterval(pollTimer.current);
        pollTimer.current = null;
      }
    };
  }, [jobs]);

  function toggleAllCreatives(value: boolean) {
    clearImportedPairs();
    const next: Record<string, boolean> = { ...selectedCreativeIds };
    filtered.forEach((r) => {
      next[r.id] = value;
    });
    setSelectedCreativeIds(next);
  }

  function toggleAllPresets(value: boolean) {
    clearImportedPairs();
    const next: Record<string, boolean> = { ...selectedPresetKeys };
    filteredPresets.forEach((p) => {
      next[p.key] = value;
    });
    setSelectedPresetKeys(next);
  }

  const creativeLabel = useMemo(() => {
    return new Map(rows.map((r) => [r.id, r.valid || r.caption || r.id]));
  }, [rows]);

  const presetByKey = useMemo(() => new Map(presets.map((p) => [p.key, p])), [presets]);

  const importedPairArr = useMemo(() => Object.values(importPairs), [importPairs]);
  const hasAnyJobs = Object.keys(jobs).length > 0;
  const canOpenStep2 = selectedCreatives.length > 0;
  const canOpenStep3 = step3Unlocked || hasAnyJobs;
  const presetCompletionByKey = useMemo(() => {
    const totalCreatives = selectedCreatives.length;
    const next: Record<string, { total: number; jobCount: number; succeededCount: number }> = {};

    if (!totalCreatives) return next;

    for (const preset of presets) {
      let jobCount = 0;
      let succeededCount = 0;
      for (const creativeId of selectedCreatives) {
        const item = jobs[`${creativeId}::${preset.key}`];
        const st = String(item?.job?.status || "").toUpperCase();
        if (item?.jobId || item?.job) jobCount += 1;
        if (st === "SUCCEEDED") succeededCount += 1;
      }
      next[preset.key] = { total: totalCreatives, jobCount, succeededCount };
    }

    return next;
  }, [jobs, presets, selectedCreatives]);

  const stepCards = [
    { id: 1 as const, title: "Creatives", locked: false, complete: selectedCreatives.length > 0 },
    { id: 2 as const, title: "Transcode options", locked: !canOpenStep2, complete: canOpenStep2 && selectedPresetsArr.length > 0 },
    { id: 3 as const, title: "Transcode jobs", locked: !canOpenStep3, complete: hasAnyJobs },
  ];
  function clearImportedPairs() {
    if (Object.keys(importPairs).length) {
      setImportPairs({});
      setImportInfo("");
    }
  }

  useEffect(() => {
    if (hasAnyJobs) setStep3Unlocked(true);
  }, [hasAnyJobs]);

  useEffect(() => {
    if (activeStep === 3 && !canOpenStep3) {
      setActiveStep(canOpenStep2 ? 2 : 1);
      return;
    }
    if (activeStep === 2 && !canOpenStep2) {
      setActiveStep(1);
    }
  }, [activeStep, canOpenStep2, canOpenStep3]);

  const jobRows = useMemo(() => {
    const list = Object.entries(jobs).map(([k, x]) => ({ key: k, ...x }));
    return list.sort((a, b) => {
      if (jobStatusSort !== "NONE") {
        const aStatus = String(a.job?.status || "UNKNOWN").toUpperCase();
        const bStatus = String(b.job?.status || "UNKNOWN").toUpperCase();
        const byStatus = aStatus.localeCompare(bStatus);
        if (byStatus !== 0) return jobStatusSort === "ASC" ? byStatus : -byStatus;
      }
      return a.key < b.key ? 1 : -1;
    });
  }, [jobs, jobStatusSort]);

  async function importExcel(file: File) {
    setActionErr("");
    setImportInfo("");
    try {
      const buf = await file.arrayBuffer();
      const wb = XLSX.read(buf, { type: "array" });
      const sheet = wb.Sheets[wb.SheetNames[0]];
      const excelRows = XLSX.utils.sheet_to_json<any>(sheet, { defval: "" });

      const creativeById = new Map<string, CreativeLine>();
      const creativeByValid = new Map<string, CreativeLine>();
      const creativeByCaption = new Map<string, CreativeLine>();
      const creativeBySource = new Map<string, CreativeLine>();
      for (const r of rows) {
        const idKey = normToken(r.id);
        const validKey = normToken(r.valid);
        const captionKey = normToken(r.caption);
        const sourceNameKey = normToken((getSourceAsset(r) as any)?.filename);
        if (idKey && !creativeById.has(idKey)) creativeById.set(idKey, r);
        if (validKey && !creativeByValid.has(validKey)) creativeByValid.set(validKey, r);
        if (captionKey && !creativeByCaption.has(captionKey)) creativeByCaption.set(captionKey, r);
        if (sourceNameKey && !creativeBySource.has(sourceNameKey)) creativeBySource.set(sourceNameKey, r);
      }

      const presetByKeyNorm = new Map<string, Preset>();
      const presetByLabel = new Map<string, Preset>();
      for (const p of presets) {
        const keyKey = normToken(p.key);
        const labelKey = normToken(p.label);
        const displayKey = normToken(presetDisplayName(p));
        if (keyKey && !presetByKeyNorm.has(keyKey)) presetByKeyNorm.set(keyKey, p);
        if (labelKey && !presetByLabel.has(labelKey)) presetByLabel.set(labelKey, p);
        if (displayKey && !presetByLabel.has(displayKey)) presetByLabel.set(displayKey, p);
      }

      const nextCreativeIds: Record<string, boolean> = {};
      const nextPresetKeys: Record<string, boolean> = {};
      const nextPairs: Record<string, { creativeId: string; presetKey: string }> = {};
      let ignoredRows = 0;

      for (const row of excelRows) {
        const creativeRaw =
          rowValue(row, ["CreativeId", "Creative ID", "VALID", "Valid", "Caption", "Creative", "Creative Name", "Source", "Source Filename", "Filename"]) ||
          "";
        const presetRaw =
          rowValue(row, ["PresetKey", "Preset Key", "Preset", "Preset Name", "Preset Label", "Label"]) ||
          "";

        if (!creativeRaw && !presetRaw) continue;
        if (!creativeRaw || !presetRaw) {
          ignoredRows += 1;
          continue;
        }

        const creativeKey = normToken(creativeRaw);
        const presetKey = normToken(presetRaw);

        const creative =
          creativeById.get(creativeKey) ||
          creativeByValid.get(creativeKey) ||
          creativeByCaption.get(creativeKey) ||
          creativeBySource.get(creativeKey) ||
          null;

        const preset = presetByKeyNorm.get(presetKey) || presetByLabel.get(presetKey) || null;

        if (!creative || !preset) {
          ignoredRows += 1;
          continue;
        }

        const pairKey = `${creative.id}::${preset.key}`;
        nextPairs[pairKey] = { creativeId: creative.id, presetKey: preset.key };
        nextCreativeIds[creative.id] = true;
        nextPresetKeys[preset.key] = true;
      }

      const pairCount = Object.keys(nextPairs).length;
      setSelectedCreativeIds(nextCreativeIds);
      setSelectedPresetKeys(nextPresetKeys);
      setImportPairs(nextPairs);

      const creativeCount = Object.keys(nextCreativeIds).length;
      const presetCount = Object.keys(nextPresetKeys).length;
      setImportInfo(
        `Imported ${excelRows.length} row(s). Selected ${creativeCount} creative(s). Selected ${presetCount} preset(s). Ready combinations from sheet: ${pairCount}.${ignoredRows ? ` Ignored rows: ${ignoredRows}.` : ""}`
      );

      if (!pairCount) {
        setActionErr("No valid Creative + Preset pairs were found in the Excel file. Check columns like VALID / CreativeId and Preset / PresetKey.");
      }
    } catch (e: any) {
      setActionErr("Import failed (check Excel columns)");
    }
  }

  function downloadImportTemplate() {
    const templateRows = [
      {
        VALID: "",
        CreativeId: "",
        Caption: "",
        Preset: "",
        PresetKey: "",
        "Source Filename": "",
        Notes: "Fill either VALID or CreativeId. Fill either Preset or PresetKey.",
      },
    ];

    const exampleRows = [
      {
        VALID: "TVC_30_MASTER",
        CreativeId: "",
        Caption: "Summer campaign 30s",
        Preset: "HD 1080p MP4",
        PresetKey: "",
        "Source Filename": "tvc_30_master.mov",
        Notes: "Example using VALID + Preset label",
      },
      {
        VALID: "",
        CreativeId: "creative_123",
        Caption: "",
        Preset: "",
        PresetKey: "mp4_hd_1080p",
        "Source Filename": "summer_social_master.mov",
        Notes: "Example using CreativeId + PresetKey",
      },
    ];

    const tipsRows = [
      { Tip: "Use the first sheet named Template for your upload." },
      { Tip: "Keep one Creative + Preset combination per row." },
      { Tip: "The importer matches CreativeId, VALID, Caption, or Source Filename." },
      { Tip: "The importer matches Preset or PresetKey." },
      { Tip: "Blank rows are ignored." },
    ];

    const wb = XLSX.utils.book_new();
    const templateWs = XLSX.utils.json_to_sheet(templateRows);
    const examplesWs = XLSX.utils.json_to_sheet(exampleRows);
    const tipsWs = XLSX.utils.json_to_sheet(tipsRows);

    templateWs["!cols"] = [
      { wch: 24 },
      { wch: 20 },
      { wch: 28 },
      { wch: 24 },
      { wch: 22 },
      { wch: 28 },
      { wch: 52 },
    ];
    examplesWs["!cols"] = templateWs["!cols"];
    tipsWs["!cols"] = [{ wch: 90 }];

    XLSX.utils.book_append_sheet(wb, templateWs, "Template");
    XLSX.utils.book_append_sheet(wb, examplesWs, "Examples");
    XLSX.utils.book_append_sheet(wb, tipsWs, "How to use");

    XLSX.writeFile(wb, "transcode-import-template.xlsx");
  }

  const fileInputId = "transcode-import";

async function createJob(creativeId: string, presetKey: string) {
  const body: any = {
    sourceType: "CREATIVE",
    sourceId: creativeId,
    presetKey,
  };

  const j = await api<any>(`/presets/jobs`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  const id = j?.id || j?.jobId;
  if (!id) throw new Error("Preset job created but no job id returned.");

  const key = `${creativeId}::${presetKey}`;
  setJobs((prev) => ({
    ...prev,
    [key]: { creativeId, presetKey, jobId: String(id), job: j },
  }));
}



  async function startBatch() {
    setActionErr("");
    if (!selectedCreatives.length) {
      setActionErr("Select at least one Creative.");
      return false;
    }
    if (!selectedPresetsArr.length) {
      setActionErr("Select at least one Preset.");
      return false;
    }

    // Only start for creatives that have SOURCE
    const creativeMap = new Map(rows.map((r) => [r.id, r]));
    const toRun: Array<{ creativeId: string; presetKey: string }> = [];
    if (importedPairArr.length) {
      for (const item of importedPairArr) {
        const r = creativeMap.get(item.creativeId);
        if (!r || !hasSourceAsset(r)) continue;
        toRun.push(item);
      }
    } else {
      for (const cid of selectedCreatives) {
        const r = creativeMap.get(cid);
        if (!r || !hasSourceAsset(r)) continue;
        for (const pk of selectedPresetsArr) toRun.push({ creativeId: cid, presetKey: pk });
      }
    }
    if (!toRun.length) {
      setActionErr("No selected creatives have a SOURCE file. Upload SOURCE first.");
      return false;
    }

    for (const item of toRun) {
      const key = `${item.creativeId}::${item.presetKey}`;

      const existing = jobs[key]?.job;
      const st = String(existing?.status || "").toUpperCase();
      // Allow retry when FAILED; otherwise avoid duplicate creation
      if (jobs[key]?.jobId && st && st !== "FAILED") continue;
      try {
        await createJob(item.creativeId, item.presetKey);
      } catch (e: any) {
        setJobs((prev) => ({
          ...prev,
          [key]: {
            creativeId: item.creativeId,
            presetKey: item.presetKey,
            jobId: "",
            job: { id: "", status: "FAILED", error: e?.message || String(e) },
          },
        }));
      }
    }

    // Pull latest (in case jobs were created elsewhere)
    setStep3Unlocked(true);
    setActiveStep(3);
    refreshJobs().catch(() => undefined);
    return true;
  }

  async function openOutput(jobId: string) {
    setActionErr("");
    try {
      if (!canDownloadMedia) throw new Error("Unauthorised");
      const r = await api<{ url: string | null }>(`/presets/jobs/${jobId}/stream-url`);
      const u = r?.url;
      if (!u) throw new Error("Output not available yet.");
      openNewTab(u);
    } catch (e: any) {
      setActionErr(e?.message || String(e));
    }
  }

  async function openSourceDownload(creativeId: string) {
    setActionErr("");
    try {
      if (!canDownloadMedia) throw new Error("Unauthorised");
      openNewTab(`/creatives/${creativeId}/assets/SOURCE/stream`);
    } catch (e: any) {
      setActionErr(e?.message || String(e));
    }
  }

  async function openLog(jobId: string) {
    setActionErr("");
    try {
      const r = await api<{ url: string | null }>(`/presets/jobs/${jobId}/log-url`);
      const u = r?.url;
      if (u) {
        openNewTab(u);
        return;
      }
    } catch {
      // ignore and fallback
    }

    // fallback: fetch the log text via API, then open in a new tab as a Blob URL
    try {
      const t = await apiText(`/presets/jobs/${jobId}/log?maxBytes=200000`);
      const blobUrl = URL.createObjectURL(new Blob([t], { type: "text/plain" }));
      window.open(blobUrl, "_blank", "noopener,noreferrer");
      window.setTimeout(() => URL.revokeObjectURL(blobUrl), 60_000);
    } catch (e: any) {
      setActionErr(e?.message || String(e));
    }
  }

  return (
    <div className="p-4">
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div>
          <h2 className="text-xl font-semibold">Transcode</h2>
          <div style={{ opacity: 0.75, fontSize: 13, marginTop: 2 }}>
            Convert each uploaded <b>SOURCE</b> creative using your Account presets (FFmpeg profiles).
          </div>
        </div>

        <div className="row" style={{ gap: 10, alignItems: "center", flexWrap: "wrap" }}>
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search creatives" style={{ padding: 8, width: 260 }} />
          <input
            id={fileInputId}
            type="file"
            accept=".xlsx,.xls"
            style={{ display: "none" }}
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) importExcel(f);
              e.currentTarget.value = "";
            }}
          />
          <button className="btn" onClick={downloadImportTemplate}>
            Download template
          </button>
          <button className="btn" onClick={() => document.getElementById(fileInputId)?.click()}>
            Import Excel
          </button>
          <button className="btn" onClick={refresh} disabled={loading}>
            {loading ? "Loading…" : "Refresh"}
          </button>
        </div>
      </div>

      {err ? (
        <div className="card" style={{ marginTop: 12, borderColor: "#f5a", background: "#fff5fa" }}>
          {err}
        </div>
      ) : null}

      <div className="card" style={{ marginTop: 12, borderColor: "#e2e8f0", background: "#f8fafc" }}>
        <div style={{ fontWeight: 800, fontSize: 13 }}>Excel import</div>
        <div style={{ fontSize: 12, opacity: 0.78, marginTop: 4 }}>
          Download the template to get the accepted columns and sample rows. Upload the filled <b>Template</b> sheet after replacing the example values with your own creative and preset combinations.
        </div>
      </div>

      {importInfo ? (
        <div className="card" style={{ marginTop: 12, borderColor: "#bfdbfe", background: "#eff6ff", display: "flex", justifyContent: "space-between", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
          <div style={{ fontSize: 13 }}>{importInfo}</div>
          <button className="btn" onClick={clearImportedPairs}>
            Clear imported pairs
          </button>
        </div>
      ) : null}

      <div className="card" style={{ marginTop: 12, borderColor: "#e2e8f0", background: "#fff" }}>
        <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
          <div>
            <div style={{ fontWeight: 800, fontSize: 14 }}>Transcode steps</div>
            <div style={{ fontSize: 12, opacity: 0.7, marginTop: 4 }}>Move in order: pick creatives, choose presets, then review jobs.</div>
          </div>
          <div style={{ fontSize: 12, opacity: 0.75 }}>Step {activeStep} of 3</div>
        </div>


        <div style={{ marginTop: 14, display: "grid", gridTemplateColumns: "repeat(3, minmax(0, 1fr))", gap: 10 }}>
          {stepCards.map((step) => {
            const isActive = activeStep === step.id;
            return (
              <button
                key={step.id}
                type="button"
                onClick={() => {
                  if (step.locked) return;
                  setActiveStep(step.id);
                }}
                disabled={step.locked}
                style={{
                  textAlign: "left",
                  border: isActive ? "1px solid #60a5fa" : "1px solid #e2e8f0",
                  borderRadius: 14,
                  padding: 12,
                  background: step.locked ? "#f8fafc" : isActive ? "#eff6ff" : "#fff",
                  opacity: step.locked ? 0.6 : 1,
                  cursor: step.locked ? "not-allowed" : "pointer",
                }}
              >
                <div style={{ display: "flex", justifyContent: "space-between", gap: 8, alignItems: "center" }}>
                  <span
                    style={{
                      width: 26,
                      height: 26,
                      borderRadius: 999,
                      display: "inline-flex",
                      alignItems: "center",
                      justifyContent: "center",
                      fontWeight: 800,
                      fontSize: 12,
                      background: step.complete ? "#dcfce7" : isActive ? "#dbeafe" : "#f1f5f9",
                      color: step.complete ? "#166534" : "#0f172a",
                    }}
                  >
                    {step.complete ? "✓" : step.id}
                  </span>
                  <span style={{ fontSize: 11, fontWeight: 700, opacity: 0.75 }}>
                    {step.locked ? "Locked" : step.complete ? "Ready" : "Open"}
                  </span>
                </div>
                <div style={{ marginTop: 10, fontWeight: 800 }}>{step.title}</div>
              </button>
            );
          })}
        </div>
      </div>

      {activeStep === 1 ? (
        <div className="card" style={{ marginTop: 12, overflowX: "auto" }}>
          <div style={{ display: "flex", justifyContent: "space-between", gap: 10, flexWrap: "wrap" }}>
            <div style={{ fontWeight: 800 }}>Step 1 · Creatives</div>
            <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
              <button className="btn" onClick={() => toggleAllCreatives(true)}>
                Select all
              </button>
              <button className="btn" onClick={() => toggleAllCreatives(false)}>
                Clear
              </button>
            </div>
          </div>
          <div style={{ opacity: 0.75, fontSize: 12, marginTop: 6 }}>
            Only creatives with <b>SOURCE</b> uploaded can be transcoded.
          </div>

          <table className="table" style={{ width: "100%", marginTop: 10 }}>
            <thead>
              <tr>
                <th style={{ textAlign: "left", width: 42 }} />
                <th style={{ textAlign: "left" }}>Creative</th>
                <th style={{ textAlign: "left" }}>QC</th>
                <th style={{ textAlign: "left" }}>Source</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((r) => {
                const label = r.valid || r.caption || r.id;
                const src = getSourceAsset(r) as any;
                const srcOk = hasSourceAsset(r);

                return (
                  <tr key={r.id}>
                    <td>
                      <input
                        type="checkbox"
                        checked={!!selectedCreativeIds[r.id]}
                        onChange={(e) => { clearImportedPairs(); setSelectedCreativeIds((prev) => ({ ...prev, [r.id]: e.target.checked })); }}
                        disabled={!srcOk}
                        title={!srcOk ? "Upload SOURCE file first" : ""}
                      />
                    </td>
                    <td style={{ fontWeight: 700 }}>{label}</td>
                    <td>
                      <QcPill status={r.qcStatus} />
                    </td>
                    <td style={{ opacity: 0.95 }}>
                      {srcOk ? (
                        <div style={{ display: "grid", gap: 2 }}>
                          <div style={{ fontWeight: 800 }}>{src?.filename || "SOURCE"}</div>
                          <div style={{ fontSize: 12, opacity: 0.75 }}>
                            {fmtBytes(src?.sizeBytes)}
                            {src?.uploadEndedAt ? ` · ${new Date(src.uploadEndedAt).toLocaleString()}` : ""}
                          </div>
                          <div style={{ fontSize: 12, display: "flex", gap: 12 }}>
                            <button className="btn" type="button" onClick={() => openSourceDownload(r.id)} disabled={!canDownloadMedia}>
                              Download source
                            </button>
                          </div>
                        </div>
                      ) : (
                        <span style={{ opacity: 0.75 }}>Missing</span>
                      )}
                    </td>
                  </tr>
                );
              })}

              {!filtered.length ? (
                <tr>
                  <td colSpan={4} style={{ opacity: 0.7, padding: 14 }}>
                    No creatives found.
                  </td>
                </tr>
              ) : null}
            </tbody>
          </table>

          <div style={{ marginTop: 12, display: "flex", justifyContent: "space-between", gap: 10, flexWrap: "wrap", alignItems: "center" }}>
            <div style={{ fontSize: 12, opacity: 0.75 }}>
              Selected creatives: <b>{selectedCreatives.length}</b>
            </div>
            <button className="btn" onClick={() => canOpenStep2 && setActiveStep(2)} disabled={!canOpenStep2}>
              Next: Transcode options
            </button>
          </div>
        </div>
      ) : null}

      {activeStep === 2 ? (
        <div className="card" style={{ marginTop: 12 }}>
          <div style={{ display: "flex", justifyContent: "space-between", gap: 10, flexWrap: "wrap" }}>
            <div style={{ fontWeight: 800 }}>Step 2 · Transcode options</div>
            <button className="btn" onClick={refreshPresets} disabled={presetsLoading}>
              {presetsLoading ? "Loading…" : "Refresh presets"}
            </button>
          </div>

          {presetsErr ? (
            <div className="card" style={{ marginTop: 10, borderColor: "#f5a", background: "#fff5fa" }}>
              {presetsErr}
            </div>
          ) : null}

          <div style={{ marginTop: 12, display: "flex", justifyContent: "space-between", gap: 10, alignItems: "center", flexWrap: "wrap" }}>
            <div style={{ fontWeight: 800 }}>Presets</div>
            <div style={{ display: "flex", gap: 8 }}>
              <button className="btn" onClick={() => toggleAllPresets(true)}>
                Select all
              </button>
              <button className="btn" onClick={() => toggleAllPresets(false)}>
                Clear
              </button>
            </div>
          </div>

          <div style={{ marginTop: 8, display: "grid", gap: 8 }}>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
              <span style={{ fontSize: 12, fontWeight: 700, opacity: 0.75 }}>Show</span>
              {[
                { key: "NOT_TRANSCODED" as const, label: "Not transcoded" },
                { key: "TRANSCODED" as const, label: "Transcoded" },
                { key: "ALL" as const, label: "All" },
              ].map((item) => {
                const active = presetVisibilityFilter === item.key;
                return (
                  <button
                    key={item.key}
                    type="button"
                    className="btn"
                    onClick={() => setPresetVisibilityFilter(item.key)}
                    style={{
                      padding: "6px 12px",
                      borderRadius: 999,
                      fontWeight: 800,
                      background: active ? "#e2e8f0" : "#fff",
                      border: active ? "1px solid #94a3b8" : undefined,
                    }}
                  >
                    {item.label}
                  </button>
                );
              })}
            </div>
            <input value={presetQuery} onChange={(e) => setPresetQuery(e.target.value)} placeholder="Search presets" style={{ padding: 8, width: "100%" }} />
            <label style={{ display: "flex", gap: 8, alignItems: "center", fontSize: 12, opacity: 0.8 }}>
              <input type="checkbox" checked={showTechnical} onChange={(e) => setShowTechnical(e.target.checked)} />
              Show technical details (preset key)
            </label>
          </div>

          <div style={{ marginTop: 10, maxHeight: 380, overflow: "auto", border: "1px solid rgba(0,0,0,0.08)", borderRadius: 10 }}>
            {groupedPresets.map((g) => (
              <div key={g.group}>
                <div
                  style={{
                    fontSize: 12,
                    fontWeight: 800,
                    opacity: 0.75,
                    padding: "8px 10px",
                    background: "rgba(0,0,0,0.03)",
                    display: "flex",
                    justifyContent: "space-between",
                  }}
                >
                  <span>{g.group}</span>
                  <span style={{ fontWeight: 700 }}>{g.items.length}</span>
                </div>
                {g.items.map((p) => {
                  const label = presetDisplayName(p);
                  const completion = presetCompletionByKey[p.key];
                  const isDoneForSelected = !!completion && completion.total > 0 && completion.succeededCount === completion.total;
                  const hasJobsForSelected = !!completion && completion.jobCount > 0;
                  return (
                    <label
                      key={p.key}
                      style={{
                        display: "grid",
                        gridTemplateColumns: "24px 1fr auto",
                        gap: 10,
                        alignItems: "center",
                        padding: "8px 10px",
                        borderTop: "1px solid rgba(0,0,0,0.06)",
                        cursor: "pointer",
                        background: isDoneForSelected ? "#f1f5f9" : "#fff",
                        opacity: isDoneForSelected ? 0.72 : 1,
                      }}
                      title={isDoneForSelected ? "Already completed for the selected creative(s)" : undefined}
                    >
                      <input
                        type="checkbox"
                        checked={!!selectedPresetKeys[p.key]}
                        onChange={(e) => { clearImportedPairs(); setSelectedPresetKeys((prev) => ({ ...prev, [p.key]: e.target.checked })); }}
                      />
                      <div style={{ display: "grid", gap: 2 }}>
                        <div style={{ display: "flex", gap: 8, alignItems: "center", flexWrap: "wrap" }}>
                          <div style={{ fontWeight: 700 }}>{label}</div>
                          {isDoneForSelected ? (
                            <span style={{ fontSize: 11, padding: "2px 8px", borderRadius: 999, background: "#e2e8f0", fontWeight: 800, color: "#334155" }}>
                              Already done
                            </span>
                          ) : hasJobsForSelected ? (
                            <span style={{ fontSize: 11, padding: "2px 8px", borderRadius: 999, background: "#eef2ff", fontWeight: 800, color: "#4338ca" }}>
                              In jobs {completion?.succeededCount || 0}/{completion?.total || 0}
                            </span>
                          ) : null}
                        </div>
                        {showTechnical ? <div style={{ fontSize: 12, opacity: 0.65 }}>{p.key}</div> : null}
                      </div>
                      <span style={{ fontSize: 11, padding: "2px 8px", borderRadius: 999, background: isDoneForSelected ? "#cbd5e1" : "rgba(0,0,0,0.05)", fontWeight: 800 }}>
                        {presetExtBadge(p)}
                      </span>
                    </label>
                  );
                })}
              </div>
            ))}

            {!groupedPresets.length ? (
              <div style={{ padding: 12, fontSize: 12, opacity: 0.7 }}>No presets.</div>
            ) : null}
          </div>

          {actionErr ? (
            <div className="card" style={{ marginTop: 10, borderColor: "#f5a", background: "#fff5fa" }}>
              {actionErr}
            </div>
          ) : null}

          <div style={{ marginTop: 10, fontSize: 12, opacity: 0.75 }}>
            Selected creatives: <b>{selectedCreatives.length}</b> · Selected presets: <b>{selectedPresetsArr.length}</b> · Jobs to start:{" "}
            <b>{importedPairArr.length || selectedCreatives.length * selectedPresetsArr.length}</b>
            {importedPairArr.length ? <span> · Using exact Excel pairs</span> : null}
          </div>

          <div style={{ marginTop: 12, display: "flex", gap: 10, justifyContent: "space-between", flexWrap: "wrap", alignItems: "center" }}>
            <button className="btn" onClick={() => setActiveStep(1)}>
              Back to creatives
            </button>
            <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
              <button className="btn" onClick={async () => { const ok = await startBatch(); if (ok) setActiveStep(3); }}>
                Start transcode
              </button>
              <button className="btn" onClick={() => canOpenStep3 && setActiveStep(3)} disabled={!canOpenStep3}>
                Next: Transcode jobs
              </button>
            </div>
          </div>
        </div>
      ) : null}

      {activeStep === 3 ? (
        <div className="card" style={{ marginTop: 12, overflowX: "auto" }}>
          <div style={{ display: "flex", justifyContent: "space-between", gap: 10, flexWrap: "wrap" }}>
            <div style={{ fontWeight: 800 }}>Step 3 · Transcode jobs</div>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              <button className="btn" onClick={() => setActiveStep(2)}>
                Back to transcode options
              </button>
              <button className="btn" onClick={refreshJobs} disabled={jobsLoading}>
                {jobsLoading ? "Loading…" : "Refresh jobs"}
              </button>
            </div>
          </div>

          {jobsErr ? (
            <div className="card" style={{ marginTop: 10, borderColor: "#f5a", background: "#fff5fa" }}>
              {jobsErr}
            </div>
          ) : null}

          {!selectedCreatives.length ? (
            <div style={{ opacity: 0.7, padding: 14 }}>Select a creative to view its jobs.</div>
          ) : null}

          {selectedCreatives.length ? (
            <table className="table" style={{ width: "100%", marginTop: 10 }}>
              <thead>
                <tr>
                  <th style={{ textAlign: "left" }}>Creative</th>
                  <th style={{ textAlign: "left" }}>Preset</th>
                  <th style={{ textAlign: "left" }}>
                    <div style={{ display: "inline-flex", alignItems: "center", gap: 8 }}>
                      <span>Status</span>
                      <span style={{ display: "inline-flex", gap: 4 }}>
                        <button
                          type="button"
                          onClick={() => setJobStatusSort((prev) => (prev === "ASC" ? "NONE" : "ASC"))}
                          title="Sort status ascending"
                          style={{
                            border: "1px solid rgba(0,0,0,0.12)",
                            borderRadius: 6,
                            padding: "0 6px",
                            background: jobStatusSort === "ASC" ? "#e2e8f0" : "#fff",
                            fontWeight: 800,
                            lineHeight: 1.4,
                          }}
                        >
                          ▲
                        </button>
                        <button
                          type="button"
                          onClick={() => setJobStatusSort((prev) => (prev === "DESC" ? "NONE" : "DESC"))}
                          title="Sort status descending"
                          style={{
                            border: "1px solid rgba(0,0,0,0.12)",
                            borderRadius: 6,
                            padding: "0 6px",
                            background: jobStatusSort === "DESC" ? "#e2e8f0" : "#fff",
                            fontWeight: 800,
                            lineHeight: 1.4,
                          }}
                        >
                          ▼
                        </button>
                      </span>
                    </div>
                  </th>
                  <th style={{ textAlign: "left" }}>Progress</th>
                  <th style={{ textAlign: "left" }}>Output</th>
                  <th style={{ textAlign: "left" }}>Logs</th>
                </tr>
              </thead>
              <tbody>
                {jobRows.map((x) => {
                  const preset = presetByKey.get(x.presetKey);
                  const label = preset ? presetDisplayName(preset) : x.presetKey;
                  const st = String(x.job?.status || "UNKNOWN").toUpperCase();
                  const hasJobError = !!String(x.job?.error || "").trim();
                  const isRetryable =
                    st === "FAILED" ||
                    st === "CANCELLED" ||
                    st === "CANCELED" ||
                    (((st === "PENDING" || st === "QUEUED" || st === "RUNNING") && hasJobError));
                  const isSucceeded = st === "SUCCEEDED";

                  const prog = (x.job as any)?.result?.progress || (x.job as any)?.result?.ffmpeg?.progress;
                  const progText =
                    typeof prog === "number" ? `${Math.round(prog)}%` : typeof prog === "string" ? prog : st === "RUNNING" ? "…" : "";

                  const out = (x.job as any)?.result || {};
                  const outName = out?.filename || out?.outputFileName || out?.outFileName || "";

                  return (
                    <tr key={x.key}>
                      <td style={{ fontWeight: 700 }}>{creativeLabel.get(x.creativeId) || x.creativeId}</td>
                      <td>
                        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                          <span style={{ fontWeight: 700 }}>{label}</span>
                          {preset ? (
                            <span
                              style={{
                                fontSize: 11,
                                padding: "2px 8px",
                                borderRadius: 999,
                                background: "rgba(0,0,0,0.05)",
                                fontWeight: 800,
                              }}
                            >
                              {presetExtBadge(preset)}
                            </span>
                          ) : null}
                        </div>
                        <div style={{ fontSize: 12, opacity: 0.65 }}>{showTechnical ? x.presetKey : ""}</div>
                      </td>
                      <td>
                        <div style={{ display: "grid", gap: 2 }}>
                          <b>{st}</b>
                          {x.job?.error ? <span style={{ fontSize: 12, color: "#b91c1c" }}>{x.job.error}</span> : null}
                          {isRetryable ? (
                            <button
                              className="btn"
                              style={{ width: "fit-content", marginTop: 6 }}
                              onClick={() => createJob(x.creativeId, x.presetKey).catch((e: any) => setActionErr(e?.message || String(e)))}
                              title={hasJobError && st !== "FAILED" ? "Retry now without waiting for the next automatic attempt" : "Retry this failed transcode"}
                            >
                              Retry
                            </button>
                          ) : null}
                        </div>
                      </td>
                      <td style={{ opacity: 0.9 }}>{progText}</td>
                      <td style={{ opacity: 0.95 }}>
                        {isSucceeded ? (
                          <div style={{ display: "grid", gap: 4 }}>
                            <button className="btn" style={{ width: "fit-content" }} onClick={() => openOutput(x.jobId)} disabled={!canDownloadMedia}>
                              Download output
                            </button>
                            <div style={{ fontSize: 12, opacity: 0.7 }}>
                              {outName ? `${outName} · ` : ""}
                              {out?.bytes ? fmtBytes(out.bytes) : ""}
                            </div>
                          </div>
                        ) : (
                          <span style={{ opacity: 0.7 }}>—</span>
                        )}
                      </td>
                      <td>
                        <button className="btn" style={{ width: "fit-content" }} onClick={() => openLog(x.jobId)} disabled={!x.jobId}>
                          View log
                        </button>
                      </td>
                    </tr>
                  );
                })}

                {!jobRows.length ? (
                  <tr>
                    <td colSpan={6} style={{ opacity: 0.7, padding: 14 }}>
                      No transcode jobs yet for the selected creative(s).
                    </td>
                  </tr>
                ) : null}
              </tbody>
            </table>
          ) : null}
        </div>
      ) : null}
      <div style={{ fontSize: 12, opacity: 0.65, marginTop: 8, textAlign: "right" }}>
        Jobs are created per Creative × Preset combination, or per exact row pair when imported from Excel.
      </div>
    </div>
  );
}
