import { useEffect, useMemo, useState } from "react";
import { useOutletContext, useParams } from "react-router-dom";
import { api } from "../../../lib/api";
import { getCreativeCodeLabel, getMe, hasPerm, type MeResponse } from "../../../lib/me";
import { KebabMenu } from "../../../ui/KebabMenu";
import {
  approveStep,
  getApprovalsTracker,
  listApprovalTemplates,
  patchProjectApprovalsConfig,
  rejectStep,
  resetRequest,
} from "../approvals/approvalsApi";
import type { ApprovalTemplate, ApprovalTracker, ApprovalTrackerRow } from "../approvals/approvals.types";

type ColDef = {
  key: string;
  label: string;
  exportLabel?: string;
  exportable?: boolean;
  get: (row: ApprovalTrackerRow) => string;
};

const PAGE_KEY = "approval-tracker";
const LS_KEY = "esendit_pref_approval_tracker_columns_v1";

function csvEscape(v: any) {
  const s = String(v ?? "");
  if (/[\n\r,\"]/g.test(s)) return `"${s.replace(/\"/g, '""')}"`;
  return s;
}

function downloadText(filename: string, text: string, mime = "text/csv;charset=utf-8") {
  const blob = new Blob([text], { type: mime });
  const url = URL.createObjectURL(blob);
  try {
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
  } finally {
    URL.revokeObjectURL(url);
  }
}

async function tryGetPref(): Promise<{ order?: string[]; hidden?: string[] } | null> {
  // Try server first; fall back to localStorage.
  try {
    const res: any = await api(`/auth/me/preferences/${PAGE_KEY}`);
    const payload = res?.payload ?? res?.data ?? res;
    if (payload && (payload.order || payload.hidden)) return payload;
  } catch {
    // ignore
  }
  try {
    const raw = localStorage.getItem(LS_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

async function trySetPref(payload: { order?: string[]; hidden?: string[] }) {
  // Best-effort server save; always write localStorage.
  try {
    localStorage.setItem(LS_KEY, JSON.stringify(payload));
  } catch {
    // ignore
  }
  try {
    await api(`/auth/me/preferences/${PAGE_KEY}`, { method: "PUT", body: JSON.stringify({ payload }) });
  } catch {
    // ignore
  }
}

async function resetRequestToStep(projectId: string, requestId: string, stepOrder: number) {
  return api(`/projects/${projectId}/approvals/requests/${requestId}/reset-to-step`, {
    method: "POST",
    body: JSON.stringify({ stepOrder }),
  });
}

function ColumnsModal({
  title,
  columns,
  order,
  hidden,
  onClose,
  onChange,
}: {
  title: string;
  columns: { key: string; label: string }[];
  order: string[];
  hidden: Set<string>;
  onClose: () => void;
  onChange: (nextOrder: string[], nextHidden: Set<string>) => void;
}) {
  const ordered = useMemo(() => {
    const map = new Map(columns.map((c) => [c.key, c]));
    const arr: { key: string; label: string }[] = [];
    for (const k of order) {
      const c = map.get(k);
      if (c) arr.push(c);
    }
    for (const c of columns) if (!arr.find((x) => x.key === c.key)) arr.push(c);
    return arr;
  }, [columns, order]);

  function move(key: string, dir: -1 | 1) {
    const idx = ordered.findIndex((c) => c.key === key);
    const next = ordered.map((c) => c.key);
    const j = idx + dir;
    if (idx < 0 || j < 0 || j >= next.length) return;
    const tmp = next[idx];
    next[idx] = next[j];
    next[j] = tmp;
    onChange(next, new Set(hidden));
  }

  function toggle(key: string) {
    const nh = new Set(hidden);
    if (nh.has(key)) nh.delete(key);
    else nh.add(key);
    onChange(ordered.map((c) => c.key), nh);
  }

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        background: "rgba(0,0,0,0.45)",
        display: "grid",
        placeItems: "center",
        padding: 16,
        zIndex: 60,
      }}
      onClick={onClose}
    >
      <div
        className="card"
        style={{ width: "min(820px, 95vw)", maxHeight: "85vh", overflow: "auto" }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="row" style={{ justifyContent: "space-between", alignItems: "center" }}>
          <h3 style={{ margin: 0 }}>{title}</h3>
          <button onClick={onClose}>Close</button>
        </div>

        <div style={{ fontSize: 12, opacity: 0.75, marginTop: 6 }}>
          Drag is not required — use ▲ ▼ to reorder. Uncheck to hide columns. Your settings are saved per user.
        </div>

        <div style={{ display: "grid", gap: 8, marginTop: 12 }}>
          {ordered.map((c) => (
            <div
              key={c.key}
              style={{
                display: "grid",
                gridTemplateColumns: "auto auto 1fr",
                gap: 10,
                alignItems: "center",
                padding: "8px 10px",
                border: "1px solid rgba(0,0,0,0.08)",
                borderRadius: 10,
              }}
            >
              <input type="checkbox" checked={!hidden.has(c.key)} onChange={() => toggle(c.key)} />
              <div className="row" style={{ gap: 6 }}>
                <button type="button" onClick={() => move(c.key, -1)} title="Move up">
                  ▲
                </button>
                <button type="button" onClick={() => move(c.key, 1)} title="Move down">
                  ▼
                </button>
              </div>
              <div style={{ fontWeight: 700 }}>{c.label}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}


const APPROVAL_GRID_BORDER = "#d9e2ec";
const approvalGridHeaderCellStyle: React.CSSProperties = {
  border: `1px solid ${APPROVAL_GRID_BORDER}`,
  background: "#f6f8fb",
  padding: "10px 12px",
  textAlign: "left",
  fontSize: 12,
  fontWeight: 800,
  letterSpacing: 0.2,
  whiteSpace: "nowrap",
  position: "sticky",
  top: 0,
  zIndex: 1,
};
const approvalGridBodyCellStyle: React.CSSProperties = {
  border: `1px solid ${APPROVAL_GRID_BORDER}`,
  padding: "10px 12px",
  fontSize: 13,
  verticalAlign: "top",
  background: "#fff",
};

export function ApprovalsPage() {
  const { id, projectId } = useParams();
  const pid = (id || projectId || "").trim();

  const outlet: any = useOutletContext();
  const reloadWorkflow = typeof outlet?.reload === "function" ? outlet.reload : null;

  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");

  const [me, setMe] = useState<MeResponse | null>(null);

  const [templates, setTemplates] = useState<ApprovalTemplate[]>([]);
  const [tracker, setTracker] = useState<ApprovalTracker | null>(null);

  const [jsonModal, setJsonModal] = useState<any>(null);

  // column prefs
  const [colOrder, setColOrder] = useState<string[]>([]);
  const [colHidden, setColHidden] = useState<Set<string>>(new Set());
  const [colsOpen, setColsOpen] = useState(false);

  async function loadAll() {
    if (!pid) return;
    setErr("");
    setLoading(true);
    try {
      const m = await getMe();
      setMe(m);

      const t = await getApprovalsTracker(pid);
      setTracker(t);

      // Load column preferences (best-effort)
      const pref = await tryGetPref();
      if (pref?.order) setColOrder(pref.order);
      if (pref?.hidden) setColHidden(new Set(pref.hidden));

      // Only Admin/Config users can manage templates; don't hard-fail the page for approvers.
      if (hasPerm(m, "APPROVALS_TEMPLATES_MANAGE")) {
        const tpls = await listApprovalTemplates();
        setTemplates(tpls || []);
      } else {
        setTemplates([]);
      }
    } catch (e: any) {
      setErr(e?.message || "Failed to load approvals");
      setTracker(null);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    loadAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [pid]);

  const enabled = Boolean(tracker?.enabled);

  const approvalsPhase = ((tracker as any)?.phase || "PRE") as "PRE" | "POST";
  const phaseLabel = approvalsPhase === "POST" ? "Post-send" : "Pre-send";

  const canWriteConfig = hasPerm(me, "APPROVALS_CONFIG_WRITE");
  const canManageTemplates = hasPerm(me, "APPROVALS_TEMPLATES_MANAGE");
  const canDecide = hasPerm(me, "approvals.decide");
  
  const isAdminOverride = (me?.user?.userType || "").toUpperCase() === "ADMIN" || hasPerm(me, "APPROVALS_CONFIG_WRITE");
const canReset = hasPerm(me, "approvals.reset");

  const selectedTemplate = useMemo(() => {
    if (tracker?.template?.id) return tracker.template;
    return null;
  }, [tracker]);

  async function toggleEnabled(next: boolean) {
    if (!pid) return;
    if (!canWriteConfig) {
      setErr("You don't have permission to change approvals config.");
      return;
    }
    setErr("");
    try {
      await patchProjectApprovalsConfig(pid, { approvalsEnabled: next });
      await loadAll();
      await reloadWorkflow?.();
    } catch (e: any) {
      setErr(e?.message || "Failed to update approvals");
    }
  }

  async function setTemplate(tid: string) {
    if (!pid) return;
    if (!canWriteConfig) {
      setErr("You don't have permission to change approvals config.");
      return;
    }
    setErr("");
    try {
      await patchProjectApprovalsConfig(pid, { approvalTemplateId: tid || null });
      await loadAll();
      await reloadWorkflow?.();
    } catch (e: any) {
      setErr(e?.message || "Failed to set template");
    }
  }


  async function setApprovalsPhase(next: "PRE" | "POST") {
    if (!pid) return;
    if (!canWriteConfig) {
      setErr("You don't have permission to change approvals config.");
      return;
    }
    setErr("");
    try {
      await patchProjectApprovalsConfig(pid, { approvalsPhase: next });
      await loadAll();
      await reloadWorkflow?.();
    } catch (e: any) {
      setErr(e?.message || "Failed to update approvals phase");
    }
  }

  function normEmail(v?: string | null) {
    return String(v ?? "").trim().toLowerCase();
  }

  function canActOnStepByEmail(step: any) {
    // Admin (or approvals config writer) can act even if not explicitly listed
    if (isAdminOverride) return true;

    const my = normEmail(me?.user?.email);
    if (!my) return false;

    const approvers = (step?.approverEmails || []).map(normEmail).filter(Boolean);

    // If template step has no explicit list, backend will enforce team membership
    if (!approvers.length) return true;

    return approvers.includes(my);
  }

  function getActionableStep(row: ApprovalTrackerRow) {
    const req = (row as any).request;
    if (!req) return null;
    const steps = (req.steps || []).slice().sort((a: any, b: any) => a.order - b.order);

    const mode = (tracker as any)?.template?.mode || "SEQUENTIAL";

    if (mode === "PARALLEL") {
      const mine = steps.find((s: any) => s.required && s.status === "PENDING" && canActOnStepByEmail(s));
      return mine || null;
    }

    const next = steps.find((s: any) => s.required && s.status === "PENDING");
    if (!next) return null;
    // For admin override we allow acting on the next pending step (backend will still enforce final rules)
    if (isAdminOverride) return next;
    return canActOnStepByEmail(next) ? next : null;
  }

  // Build dynamic step columns based on template/first row
  const stepMeta = useMemo(() => {
    const tpls: any[] = ((tracker as any)?.template?.steps || []) as any[];
    if (tpls.length) {
      return tpls
        .slice()
        .sort((a: any, b: any) => a.order - b.order)
        .map((s) => ({ order: s.order, label: s.label || s.teamName || `Step ${s.order}` }));
    }
    const first = (tracker?.rows || [])[0] as any;
    const steps: any[] = first?.request?.steps || [];
    return steps
      .slice()
      .sort((a: any, b: any) => a.order - b.order)
      .map((s) => ({ order: s.order, label: s.label || `Step ${s.order}` }));
  }, [tracker]);

  const baseCols: ColDef[] = useMemo(() => {
    const p: any = (tracker as any)?.project || {};
    const phase = String((tracker as any)?.phase || "PRE");

    const cols: ColDef[] = [
      { key: "phase", label: "Pre/Post", exportable: true, get: () => phase },
      { key: "projectNumber", label: "Project Number", exportable: true, get: () => String(p?.projectNumber || "-") },
      { key: "projectName", label: "Project Name", exportable: true, get: () => String(p?.name || "-") },
      { key: "advertiserGroup", label: "Advertiser Group", exportable: true, get: () => String(p?.advertiserGroup?.name || "-") },
      { key: "advertiser", label: "Advertiser", exportable: true, get: () => String(p?.advertiser?.name || "-") },
      { key: "brand", label: "Brand", exportable: true, get: () => String(p?.brand?.name || "-") },
      { key: "mediaAgency", label: "Media Agency", exportable: true, get: () => String(p?.mediaAgency?.name || "-") },
      { key: "mediaAgencyTeam", label: "Media Agency Team", exportable: true, get: () => String(p?.mediaAgencyTeam?.name || "-") },
      { key: "creativeAgency", label: "Creative Agency", exportable: true, get: () => String(p?.creativeAgency?.name || "-") },
      { key: "creativeAgencyTeam", label: "Creative Agency Team", exportable: true, get: () => String(p?.creativeAgencyTeam?.name || "-") },
      { key: "productionHouse", label: "Production House", exportable: true, get: () => String(p?.productionHouse?.name || "-") },
      { key: "productionHouseTeam", label: "Production House Team", exportable: true, get: () => String(p?.productionHouseTeam?.name || "-") },
      { key: "postHouse", label: "Post House", exportable: true, get: () => String(p?.postHouse?.name || "-") },
      { key: "postHouseTeam", label: "Post House Team", exportable: true, get: () => String(p?.postHouseTeam?.name || "-") },
      { key: "audioAgency", label: "Audio Agency", exportable: true, get: () => String(p?.audioAgency?.name || "-") },
      { key: "audioAgencyTeam", label: "Audio Agency Team", exportable: true, get: () => String(p?.audioAgencyTeam?.name || "-") },
      { key: "productCategory", label: "Sector/Product Category", exportable: true, get: () => String(p?.productCategory?.name || "-") },
      { key: "billableParty", label: "Billable Party", exportable: true, get: () => String(p?.billableParty?.name || "-") },
      { key: "valid", label: getCreativeCodeLabel(me), exportLabel: "VALID", exportable: true, get: (r) => String((r as any).creative?.valid || "-") },
      { key: "creativeName", label: "Creative", exportable: true, get: (r) => String((r as any).creative?.name || "-") },
      { key: "qc", label: "QC", exportable: true, get: (r) => String((r as any).creative?.qcStatus || "-") },
      {
        key: "approval",
        label: "Approval",
        exportable: true,
        get: (r) => String((r as any).request?.status || (r as any).creative?.approvals || "-")
      },
      {
        key: "caption",
        label: "Caption",
        exportable: true,
        get: (r) => String(((r as any).creative as any)?.caption || "-")
      },
      {
        key: "format",
        label: "Format",
        exportable: true,
        get: (r) => String(((r as any).creative as any)?.format || "-")
      },
      {
        key: "audio",
        label: "Audio",
        exportable: true,
        get: (r) => String(((r as any).creative as any)?.audio || "-")
      },
      {
        key: "language",
        label: "Language",
        exportable: true,
        get: (r) => {
          const v: any = ((r as any).creative as any)?.languages;
          return Array.isArray(v) ? v.join(", ") : String(v || "-");
        },
      },
      {
        key: "duration",
        label: "Duration",
        exportable: true,
        get: (r) => String(((r as any).creative as any)?.duration || "-")
      },
      {
        key: "filename",
        label: "Filename",
        exportable: true,
        get: (r) => String(((r as any).creative as any)?.sourceFilename || ((r as any).creative as any)?.filename || "-")
      },
      {
        key: "fileSize",
        label: "File Size (bytes)",
        exportable: true,
        get: (r) => String(((r as any).creative as any)?.sourceSizeBytes ?? "-")
      },
      {
        key: "mimeType",
        label: "MIME Type",
        exportable: true,
        get: (r) => String(((r as any).creative as any)?.sourceMimeType ?? "-")
      },
      {
        key: "uploader",
        label: "Uploader",
        exportable: true,
        get: (r) => {
          const u: any = ((r as any).creative as any)?.uploadedByUser || ((r as any).creative as any)?.uploader;
          return String(u?.displayName || u?.email || "-");
        },
      },
      {
        key: "qcNotes",
        label: "QC Notes",
        exportable: true,
        get: (r) => String(((r as any).creative as any)?.qcNotes || "-")
      },
      {
        key: "qcFailures",
        label: "QC Failure Reasons",
        exportable: true,
        get: (r) => {
          const v: any = ((r as any).creative as any)?.qcFailureReasons;
          return Array.isArray(v) ? (v.length ? v.join("; ") : "-") : String(v || "-");
        }
      },
      {
        key: "autoQcWindow",
        label: "Auto QC Window",
        exportable: true,
        get: (r) => {
          const a: any = ((r as any).creative as any)?.autoQcStartedAt;
          const b: any = ((r as any).creative as any)?.autoQcEndedAt;
          if (!a && !b) return "-";
          return `${a || "?"} → ${b || "?"}`;
        }
      },
    ];
    return cols;
  }, [tracker]);

  const stepCols: ColDef[] = useMemo(() => {
    return stepMeta.map((s) => ({
      key: `step_${s.order}`,
      label: s.label,
      exportable: true,
      get: (r) => {
        const steps: any[] = ((r as any).request?.steps || []) as any[];
        const st = steps.find((x) => x.order === s.order);
        if (!st) return "-";
        const who = st?.decidedByUser?.displayName || st?.decidedByUser?.email || "";
        if (st.status === "APPROVED" && who) return `APPROVED (${who})`;
        if (st.status === "REJECTED" && who) return `REJECTED (${who})`;
        return String(st.status || "-");
      },
    }));
  }, [stepMeta]);

  const actionCol: ColDef = useMemo(
    () => ({ key: "actions", label: "Actions", exportable: false, get: () => "" }),
    [],
  );

  const allCols = useMemo(() => [...baseCols, ...stepCols, actionCol], [baseCols, stepCols, actionCol]);

  const visibleCols = useMemo(() => {
    const map = new Map(allCols.map((c) => [c.key, c] as const));
    const ordered: ColDef[] = [];

    const order = colOrder?.length ? colOrder : allCols.map((c) => c.key);

    for (const k of order) {
      const c = map.get(k);
      if (!c) continue;
      if (colHidden.has(k)) continue;
      ordered.push(c);
    }
    // Add any new columns not in saved order
    for (const c of allCols) {
      if (ordered.find((x) => x.key === c.key)) continue;
      if (colHidden.has(c.key)) continue;
      ordered.push(c);
    }

    return ordered;
  }, [allCols, colOrder, colHidden]);

  async function act(row: ApprovalTrackerRow, action: "APPROVE" | "REJECT") {
    if (!pid) return;
    if (!(row as any).request) return;

    const step = getActionableStep(row);
    if (!step) return;

    const notes = window.prompt(`${action} note (optional):`) || undefined;

    setErr("");
    try {
      if (action === "APPROVE") await approveStep(pid, (row as any).request.id, step.id, notes);
      else await rejectStep(pid, (row as any).request.id, step.id, notes);

      await loadAll();
      await reloadWorkflow?.();
    } catch (e: any) {
      setErr(e?.message || "Approval action failed");
    }
  }

  async function reset(row: ApprovalTrackerRow) {
    if (!pid) return;
    if (!(row as any).request) return;

    const ok = window.confirm("Reset approvals for this creative?");
    if (!ok) return;

    setErr("");
    try {
      await resetRequest(pid, (row as any).request.id);
      await loadAll();
      await reloadWorkflow?.();
    } catch (e: any) {
      setErr(e?.message || "Reset failed");
    }
  }

  async function resetToStep(row: ApprovalTrackerRow) {
    if (!pid) return;
    if (!(row as any).request) return;

    const req: any = (row as any).request;
    const steps: any[] = (req.steps || []).slice().sort((a: any, b: any) => a.order - b.order);
    if (!steps.length) {
      setErr("No steps found on this request");
      return;
    }

    const menu = steps.map((s) => `${s.order}: ${s.label || `Step ${s.order}`}`).join("\n");
    const raw = window.prompt(`Reset to which step?\n\n${menu}`, String(steps[0].order));
    if (!raw) return;
    const n = parseInt(raw, 10);
    if (!Number.isFinite(n) || n < 1) {
      setErr("Invalid step number");
      return;
    }

    const ok = window.confirm(`Reset approval process to step ${n}?`);
    if (!ok) return;

    setErr("");
    try {
      await resetRequestToStep(pid, req.id, n);
      await loadAll();
      await reloadWorkflow?.();
    } catch (e: any) {
      setErr(e?.message || "Reset-to-step failed");
    }
  }

  function exportCsv() {
    if (!tracker) return;
    const cols = visibleCols.filter((c) => c.exportable !== false && c.key !== "actions");
    const header = cols.map((c) => csvEscape((c as any).exportLabel ?? c.label)).join(",");
    const lines = [header];
    for (const r of tracker.rows || []) {
      const row = cols.map((c) => csvEscape(c.get(r))).join(",");
      lines.push(row);
    }
    const filename = `approval-tracker-${pid || "project"}.csv`;
    downloadText(filename, lines.join("\n"));
  }

  async function saveColumns(nextOrder: string[], nextHidden: Set<string>) {
    setColOrder(nextOrder);
    setColHidden(new Set(nextHidden));
    await trySetPref({ order: nextOrder, hidden: Array.from(nextHidden) });
  }

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div className="card" style={{ display: "grid", gap: 10 }}>
        <div className="row" style={{ justifyContent: "space-between" }}>
          <h3 style={{ margin: 0 }}>Approvals ({phaseLabel})</h3>
          <div className="row" style={{ gap: 8 }}>
            <button onClick={() => setColsOpen(true)} disabled={!tracker || loading}>
              Columns
            </button>
            <button onClick={exportCsv} disabled={!tracker || loading}>
              Export CSV
            </button>
            <button onClick={loadAll} disabled={loading}>
              Refresh
            </button>
          </div>
        </div>

        {err && (
          <div className="card" style={{ borderColor: "#f5a", background: "#fff5fa" }}>
            {err}
          </div>
        )}

        <div className="row" style={{ gap: 12, alignItems: "center", flexWrap: "wrap" }}>
          {canWriteConfig ? (
            <label className="row" style={{ gap: 8 }}>
              <input
                type="checkbox"
                checked={enabled}
                onChange={(e) => toggleEnabled(e.target.checked)}
                disabled={loading}
              />
              <span style={{ fontWeight: 700 }}>Approvals enabled</span>
            </label>
          ) : (
            <div style={{ fontWeight: 700 }}>Approvals enabled: {enabled ? "Yes" : "No"}</div>
          )}

          {canWriteConfig ? (
            <div className="row" style={{ gap: 8, alignItems: "center" }}>
              <div style={{ fontSize: 12, opacity: 0.7 }}>Phase</div>
              <select
                value={approvalsPhase}
                onChange={(e) => setApprovalsPhase(e.target.value as any)}
                disabled={loading || !enabled}
              >
                <option value="PRE">Pre-send</option>
                <option value="POST">Post-send</option>
              </select>
            </div>
          ) : (
            <div style={{ fontSize: 12, opacity: 0.75 }}>Phase: {phaseLabel}</div>
          )}

          {canWriteConfig && canManageTemplates ? (
            <div className="row" style={{ gap: 8, alignItems: "center" }}>
              <div style={{ fontSize: 12, opacity: 0.7 }}>Template</div>
              <select
                value={selectedTemplate?.id || ""}
                onChange={(e) => setTemplate(e.target.value)}
                disabled={loading || !enabled}
              >
                <option value="">(none)</option>
                {templates.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.name} — {t.mode}
                  </option>
                ))}
              </select>
            </div>
          ) : (
            <div style={{ fontSize: 12, opacity: 0.75 }}>
              Template: {selectedTemplate ? `${selectedTemplate.name} — ${selectedTemplate.mode}` : "(none)"}
            </div>
          )}

        </div>
      </div>

      <div
        className="card"
        style={{
          overflowX: "auto",
          border: `1px solid ${APPROVAL_GRID_BORDER}`,
          borderRadius: 16,
          background: "#fff",
          boxShadow: "0 10px 24px rgba(15, 23, 42, 0.04)",
        }}
      >
        <table style={{ width: "100%", minWidth: Math.max(1450, visibleCols.length * 140), borderCollapse: "collapse", fontSize: 13 }}>
          <thead>
            <tr>
              {visibleCols.map((c) => (
                <th
                  key={c.key}
                  style={c.key === "actions" ? { ...approvalGridHeaderCellStyle, textAlign: "center", width: 1 } : approvalGridHeaderCellStyle}
                >
                  {c.label}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {(tracker?.rows || []).map((row, rowIdx) => {
              const req: any = (row as any).request;
              const actionable = req ? getActionableStep(row) : null;

              const decideDisabled = !enabled || !req || !actionable || loading || !canDecide;
              const resetDisabled = !enabled || !req || loading || !canReset;
              const rowBg = rowIdx % 2 === 1 ? "#fbfdff" : "#fff";

              return (
                <tr key={(row as any).creative?.id}>
                  {visibleCols.map((c) => {
                    if (c.key !== "actions") {
                      return (
                        <td key={c.key} style={{ ...approvalGridBodyCellStyle, background: rowBg, whiteSpace: "nowrap" }}>
                          {c.get(row)}
                        </td>
                      );
                    }

                    return (
                      <td
                        key={c.key}
                        style={{ ...approvalGridBodyCellStyle, background: rowBg, width: 1, whiteSpace: "nowrap", textAlign: "center" }}
                      >
                        <KebabMenu
                          items={[
                            { label: "Approve", disabled: decideDisabled, onClick: () => act(row, "APPROVE") },
                            { label: "Reject", disabled: decideDisabled, danger: true, onClick: () => act(row, "REJECT") },
                            { label: "Reset", disabled: resetDisabled, onClick: () => reset(row) },
                            { label: "Reset to step", disabled: resetDisabled, onClick: () => resetToStep(row) },
                            {
                              label: "Request JSON",
                              // allow opening even when approvals are disabled / request missing (shows a helpful message)
                              disabled: false,
                              onClick: () => {
                                if (!req) {
                                  setErr("No approval request yet. Select a template (and enable approvals) to create requests.");
                                  return;
                                }
                                setJsonModal(req);
                              },
                            },
                            {
                              label: "QC JSON",
                              // QC info comes from the creative; don't depend on an approval request existing.
                              disabled: !(row as any).creative,
                              onClick: () =>
                                setJsonModal({
                                  kind: "QC",
                                  creativeId: (row as any).creative?.id,
                                  valid: (row as any).creative?.valid,
                                  qcStatus: (row as any).creative?.qcStatus,
                                  qcNotes: (row as any).creative?.qcNotes,
                                  qcFailureReasons: (row as any).creative?.qcFailureReasons,
                                  autoQcStartedAt: (row as any).creative?.autoQcStartedAt,
                                  autoQcEndedAt: (row as any).creative?.autoQcEndedAt,
                                  qcReport: (row as any).creative?.qcReport,
                                }),
                            },
                          ]}
                        />
                      </td>
                    );
                  })}
                </tr>
              );
            })}

            {!loading && (tracker?.rows?.length || 0) === 0 && (
              <tr>
                <td colSpan={visibleCols.length} style={{ ...approvalGridBodyCellStyle, padding: 12, opacity: 0.7, textAlign: "center" }}>
                  No creatives found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {colsOpen && (
        <ColumnsModal
          title="Customize columns"
          columns={allCols.map((c) => ({ key: c.key, label: c.label }))}
          order={colOrder?.length ? colOrder : allCols.map((c) => c.key)}
          hidden={colHidden}
          onClose={() => setColsOpen(false)}
          onChange={(o, h) => saveColumns(o, h)}
        />
      )}

      {jsonModal && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(0,0,0,0.45)",
            display: "grid",
            placeItems: "center",
            padding: 16,
            zIndex: 50,
          }}
          onClick={() => setJsonModal(null)}
        >
          <div
            className="card"
            style={{ width: "min(900px, 95vw)", maxHeight: "85vh", overflow: "auto" }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="row" style={{ justifyContent: "space-between", alignItems: "center" }}>
              <h3 style={{ margin: 0 }}>JSON Viewer</h3>
              <button onClick={() => setJsonModal(null)}>Close</button>
            </div>

            <pre style={{ fontSize: 12, background: "#0b1020", color: "#d7e1ff", padding: 12, borderRadius: 8 }}>
              {JSON.stringify(jsonModal, null, 2)}
            </pre>
          </div>
        </div>
      )}
    </div>
  );
}
