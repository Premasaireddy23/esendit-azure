import { useEffect, useMemo, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { useParams } from "react-router-dom";
import { getToken } from "../../../lib/api";
import deleteCreativeIcon from "../../../assets/icons/delete-creative.png";
import { getCreativeCodeLabel, getCreativeValidConfig, getMe, type MeResponse } from "../../../lib/me";
import {
  bulkImportCreatives,
  createCreative,
  deleteCreative,
  listCreatives,
  updateCreative,
  type CreativeLine,
} from "../services/creativesApi";

/**
 * Section 6 — Creatives (VALID) upgrades
 *
 * This page is designed to be drop-in and backwards compatible:
 * - Save line without file ✅
 * - Copy previous line fields ✅
 * - Drag-drop (single/multi) ✅
 * - Upload status & speed column ✅ (client-side XHR progress)
 * - Proxy download button ✅
 * - DAM add-to-line ✅ (enforces uniqueEdit rules server-side)
 * - Excel import ✅ (XLSX via dynamic import; CSV fallback)
 */
const API_BASE = import.meta.env.VITE_API_BASE ?? "/api";
const EXCEL_ICON_DATA_URL = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAB4AAAAeCAYAAAA7MK6iAAAACXBIWXMAAAsTAAALEwEAmpwYAAACiElEQVR4nGNgGAWDAcw9k2Y+53Tq5tmnU27NPpN6Fxve8qzq7fGf3W/P/J9wFx2f/j/h9un/E+Zf+N/NTbSls06nRM4+k/pnzpnU/7jw8hv5/8/8n0AE7q8kytJplzIF55xOeYfPUhBed7+UKItBvibWt/6ELKWJxXPOpCRQ0+LdH9rWD4jFsy4V3SbK4q490QXEWLzmTjFRFk86lXONKIvzl3pPIcbieefS/x/+1oHX0gNfOv57dFhvIMrirIWec0AG9x2K/5+03Pd/8Hz3/8HzPLBinwn2/0MnO//36rTFwG5tNv9V09X+S8cpEJe4shd6z2ncE/XfY5HHf+cF7jix9RSH/9LxCiCDCeH5RFmctMhrne9SL7yWgrBJhyUxlhK2WK/a2Ea3xnCicZPpbfNuq//o2KLf5r/jPDeExe0WlFusX69voFtj+Fuv1ug/PmzUakZdi/VqjStghifNS/2ftSgXzDZttPhfsqLsv++EQLjljnNdqWexbq1hA8zgmrV1/0EgdlbC//6dE/9//fn1v3OXO8LiOS5gi/XrTahrsUGdyf8rT67+P//wwv9P3z/9n7BrEkpw281w/G/eY/NfNkmJuhbr1Rr9z16cB/b1x28f/5s0WqBYLEe8haRbvPH85v9P3j35/+/fv/95SwvpY3H8nCSwhQlzkv/vvbbv/+N3T8CJjCYW69UY1cMMXnxs6f9FR5eA2QGTQv4fv3Pif/biXNpYrF9jFEYoD4OwbrUhqZYSKLnqGZh0aw2n6dUYfcZlqXalwX8FSKFPRYvRgFSsQrh0nPxvMizBxLHyFQykAJk4RTPpOPlNUrHyt6RiFe6SjuVvSccpzBWPESe+eTsKGKgMAFXqg8B2fE6OAAAAAElFTkSuQmCC";

const creativeCellStyle = { minHeight: 96, display: "flex", alignItems: "center", width: "100%", minWidth: 0 } as const;
const creativeCenterCellStyle = { minHeight: 96, width: "100%", minWidth: 0, display: "grid", placeItems: "center" } as const;

function numOrNull(v: any): number | null {
  if (v === null || v === undefined) return null;
  const n = typeof v === "number" ? v : Number(String(v).trim());
  return Number.isFinite(n) ? n : null;
}

function creativeFrameRate(row: any): number | null {
  return numOrNull(
    row?.qcReport?.metadata?.video?.frameRate
    ?? row?.qcReport?.clientMetadata?.video?.FrameRate
    ?? row?.qcReport?.mediainfo?.media?.track?.find?.((t: any) => String(t?.['@type'] || t?.type || '').toLowerCase() === 'video')?.FrameRate,
  );
}

function creativeBroadcastStandard(row: any): { label: string; fps: number } | null {
  const fps = creativeFrameRate(row);
  if (fps == null) return null;
  if (Math.abs(fps - 25) <= 0.05) return { label: 'PAL', fps: 25 };
  if (Math.abs(fps - 29.97) <= 0.05 || Math.abs(fps - (30000 / 1001)) <= 0.05) return { label: 'NTSC', fps: 29.97 };
  return { label: `${Number(fps.toFixed(3))} fps`, fps };
}

export function CreativesPage() {
  const params = useParams();
  const projectId = String((params as any).id || (params as any).projectId || "");
  const [me, setMe] = useState<MeResponse | null>(null);
  const [rows, setRows] = useState<CreativeLine[]>([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [info, setInfo] = useState<string | null>(null);

  // upload state keyed by creativeId
  const [uploading, setUploading] = useState<Record<string, { pct: number; speedBps: number; status: string }>>({});
  const lastProgRef = useRef<Record<string, { t: number; b: number }>>({});
  const [previewUrls, setPreviewUrls] = useState<Record<string, { url: string; type: "PROXY" | "SOURCE" }>>({});
  const [activePreview, setActivePreview] = useState<{
    url: string;
    title: string;
    kind: "image" | "video";
  } | null>(null);

  const [deleteTarget, setDeleteTarget] = useState<CreativeLine | null>(null);
  const [deleting, setDeleting] = useState(false);
  const [importing, setImporting] = useState(false);
  const importInputRef = useRef<HTMLInputElement | null>(null);

  const codeLabel = useMemo(() => getCreativeCodeLabel(me, null), [me]);
  const validCfg = useMemo(() => getCreativeValidConfig(me, null), [me]);

  async function refresh() {
    if (!projectId) return;
    setLoading(true);
    setErr(null);
    try {
      const data = await listCreatives(projectId);
      setRows(data);
    } catch (e: any) {
      setErr(e?.message || "Failed to load creatives");
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    getMe(true)
      .then(setMe)
      .catch(() => setMe(null));
  }, []);

  useEffect(() => {
    refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [projectId]);

  useEffect(() => {
    let cancelled = false;

    async function loadPreviewUrls() {
      const token = getToken();
      const candidates = rows.filter((r) => {
        const type = bestPreviewType(r);
        if (!type) return false;
        const current = previewUrls[r.id];
        if (current?.url && current.type === type) return false;
        return hasBrowserPreview(r);
      });
      if (!candidates.length) return;

      const loaded: Record<string, { url: string; type: "PROXY" | "SOURCE" }> = {};
      await Promise.all(
        candidates.map(async (r) => {
          try {
            const type = bestPreviewType(r);
            if (!type) return;
            const res = await fetch(`${API_BASE}/creatives/${r.id}/assets/${type}/stream-url`, {
              headers: token ? { Authorization: `Bearer ${token}` } : {},
            });
            if (!res.ok) return;
            const data = (await res.json()) as { url?: string };
            if (data?.url && type) loaded[r.id] = { url: data.url, type };
          } catch {
            // ignore and keep placeholder
          }
        })
      );

      if (!cancelled && Object.keys(loaded).length) {
        setPreviewUrls((prev) => ({ ...prev, ...loaded }));
      }
    }

    loadPreviewUrls();
    return () => {
      cancelled = true;
    };
  }, [rows, previewUrls]);

  useEffect(() => {
    const ids = new Set(rows.map((r) => r.id));
    setPreviewUrls((prev) => {
      const next = Object.fromEntries(Object.entries(prev).filter(([id]) => ids.has(id)));
      return Object.keys(next).length === Object.keys(prev).length ? prev : next;
    });
  }, [rows]);

  useEffect(() => {
    function onKeyDown(e: KeyboardEvent) {
      if (e.key === "Escape") setActivePreview(null);
    }
    if (activePreview) {
      window.addEventListener("keydown", onKeyDown);
      const prevOverflow = document.body.style.overflow;
      document.body.style.overflow = "hidden";
      return () => {
        window.removeEventListener("keydown", onKeyDown);
        document.body.style.overflow = prevOverflow;
      };
    }
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [activePreview]);

  function openPreview(r: CreativeLine, idx: number) {
    const preview = previewUrls[r.id];
    const url = preview?.url;
    if (!url || !hasBrowserPreview(r)) return;
    const title = r.valid || r.caption || sourceFileName(r) || `Creative ${idx + 1}`;
    setActivePreview({ url, title, kind: previewKind(r) });
  }

  function rowStatus(r: CreativeLine): { text: string; sub?: string } {
    const u = uploading[r.id];

    if (u) {
      if (u.status === "init") return { text: "Preparing..." };
      if (u.status === "uploading") return { text: "Uploading", sub: `${Math.round(u.pct)}%` };
      if (u.status === "finalizing") return { text: "Finalizing..." };
      if (u.status === "done") return { text: "Uploaded" };
      if (u.status === "failed") return { text: "Upload failed" };
    }

    const src = r.assets?.find((a) => a.type === "SOURCE");
    if (!src || !src.filename) return { text: "No file" };

    return { text: "Uploaded" };
  }


  function fmtBps(bps?: number | null) {
    if (!bps || bps <= 0) return "—";
    const kb = bps / 1024;
    if (kb < 1024) return `${kb.toFixed(1)} KB/s`;
    const mb = kb / 1024;
    return `${mb.toFixed(1)} MB/s`;
  }

  function sourceFileName(r: CreativeLine) {
    return r.assets?.find((a) => a.type === "SOURCE")?.filename || "";
  }

  function bestPreviewType(r: CreativeLine): "PROXY" | "SOURCE" | null {
    const proxy = r.assets?.find((a) => String(a.type || "").toUpperCase() === "PROXY" && a.filename);
    if (proxy) return "PROXY";
    const source = r.assets?.find((a) => String(a.type || "").toUpperCase() === "SOURCE" && a.filename);
    if (source) return "SOURCE";
    return null;
  }

  function previewMimeType(r: CreativeLine): string {
    const type = bestPreviewType(r);
    const asset = r.assets?.find((a) => String(a.type || "").toUpperCase() === type);
    return String(asset?.mimeType || "").toLowerCase();
  }

  function hasBrowserPreview(r: CreativeLine) {
    const mime = previewMimeType(r);
    return !mime || mime.startsWith("video/") || mime.startsWith("image/");
  }

  function previewKind(r: CreativeLine): "image" | "video" {
    const mime = previewMimeType(r);
    return mime.startsWith("image/") ? "image" : "video";
  }

  function fileExtLabel(filename?: string | null) {
    if (!filename) return "File";
    const part = filename.split(".").pop()?.trim();
    return part ? part.toUpperCase() : "File";
  }



  async function confirmDeleteCreative() {
    if (!deleteTarget) return;
    setDeleting(true);
    setErr(null);
    try {
      await deleteCreative(deleteTarget.id);
      setDeleteTarget(null);
      await refresh();
    } catch (e: any) {
      setErr(e?.message || "Delete failed");
    } finally {
      setDeleting(false);
    }
  }

  async function addLine(copyPrev = true) {
    setErr(null);
    try {
      const last = rows[rows.length - 1];
      const payload: any = {};
      if (copyPrev && last) payload.copyFromCreativeId = last.id;

      // apply per-country defaults for languages if none
      if (!payload.languages && validCfg?.defaultLanguages?.length) payload.languages = validCfg.defaultLanguages;

      const created = await createCreative(projectId, payload);
      setRows((prev) => [...prev, created]);
    } catch (e: any) {
      setErr(e?.message || "Failed to add line");
    }
  }

  async function patchRow(id: string, patch: any) {
    setErr(null);
    try {
      const updated = await updateCreative(id, patch);
      setRows((prev) => prev.map((r) => (r.id === id ? updated : r)));
    } catch (e: any) {
      setErr(e?.message || "Update failed");
    }
  }

  async function uploadSource(creativeId: string, file: File) {
  // Phase 1: browser -> Blob (SAS) upload
  setErr(null);
  setInfo(null);
  setUploading((p) => ({ ...p, [creativeId]: { pct: 0, speedBps: 0, status: "init" } }));
  lastProgRef.current[creativeId] = { t: Date.now(), b: 0 };

  const token = getToken();

  const parseErr = async (res: Response) => {
    let msg = `${res.status} ${res.statusText}`;
    try {
      const j = await res.json();
      msg = (j as any)?.message || (j as any)?.error || msg;
    } catch {
      try {
        const t = await res.text();
        if (t) msg = t.slice(0, 400);
      } catch {
        // ignore
      }
    }
    return msg;
  };

  // 1) init -> get SAS URL + blobKey
  const initRes = await fetch(`${API_BASE}/creatives/${creativeId}/upload-source/init`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: JSON.stringify({
      filename: file.name,
      contentType: file.type || "application/octet-stream",
      sizeBytes: file.size,
    }),
  });

  if (!initRes.ok) {
    setUploading((p) => ({ ...p, [creativeId]: { pct: 0, speedBps: 0, status: "failed" } }));
    throw new Error(await parseErr(initRes));
  }

  const initJson = (await initRes.json()) as {
    blobKey: string;
    sasUrl: string;
    requiredHeaders?: Record<string, string>;
  };

  if (!initJson?.sasUrl || !initJson?.blobKey) {
    setUploading((p) => ({ ...p, [creativeId]: { pct: 0, speedBps: 0, status: "failed" } }));
    throw new Error("Upload init did not return sasUrl/blobKey");
  }

  // 2) PUT to Blob SAS URL (progress via XHR)
  await new Promise<void>((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("PUT", initJson.sasUrl, true);

    // Set headers exactly once (avoid duplicates like "BlockBlob, BlockBlob")
    const headerMap = new Map<string, string>();

    // Prefer server-provided headers (they may include rsct / blob-type etc.)
    if (initJson.requiredHeaders) {
      for (const [k, v] of Object.entries(initJson.requiredHeaders)) {
        if (!k) continue;
        headerMap.set(String(k).toLowerCase(), String(v));
      }
    }

    // Ensure required Azure header is present
    if (!headerMap.has("x-ms-blob-type")) headerMap.set("x-ms-blob-type", "BlockBlob");

    // If server didn't provide a content-type, set it from the file
    if (!headerMap.has("content-type")) {
      headerMap.set("content-type", file.type || "application/octet-stream");
    }

    for (const [kLower, v] of headerMap.entries()) {
      const name = kLower === "content-type" ? "Content-Type" : kLower;
      try {
        xhr.setRequestHeader(name, v);
      } catch {
        // Some headers can't be set by the browser; ignore
      }
    }

    xhr.upload.onprogress = (ev) => {
      if (!ev.lengthComputable) return;

      const pct = (ev.loaded / ev.total) * 100;
      const now = Date.now();
      const last = lastProgRef.current[creativeId];
      let speedBps = 0;
      if (last) {
        const dt = (now - last.t) / 1000;
        const db = ev.loaded - last.b;
        if (dt > 0.2 && db >= 0) speedBps = db / dt;
      }
      lastProgRef.current[creativeId] = { t: now, b: ev.loaded };

      setUploading((p) => ({
        ...p,
        [creativeId]: { pct, speedBps, status: "uploading" },
      }));
    };

    xhr.onerror = () => {
      setUploading((p) => ({ ...p, [creativeId]: { pct: 0, speedBps: 0, status: "failed" } }));
      reject(new Error("Blob upload failed"));
    };

    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) return resolve();

      setUploading((p) => ({ ...p, [creativeId]: { pct: 0, speedBps: 0, status: "failed" } }));
      reject(new Error(`Blob PUT failed: ${xhr.status} ${xhr.responseText || ""}`));
    };

    xhr.send(file);
  });

  // 3) complete -> API verifies blob exists + marks UPLOADED + enqueues jobs
  setUploading((p) => ({ ...p, [creativeId]: { pct: 100, speedBps: 0, status: "finalizing" } }));

  const completeRes = await fetch(`${API_BASE}/creatives/${creativeId}/upload-source/complete`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: JSON.stringify({ blobKey: initJson.blobKey }),
  });

  if (!completeRes.ok) {
    setUploading((p) => ({ ...p, [creativeId]: { pct: 0, speedBps: 0, status: "failed" } }));
    throw new Error(await parseErr(completeRes));
  }

  setUploading((p) => ({ ...p, [creativeId]: { pct: 100, speedBps: 0, status: "done" } }));
  setPreviewUrls((prev) => {
    const { [creativeId]: _removed, ...rest } = prev;
    return rest;
  });
  await refresh();
  setInfo(`Uploaded: ${file.name}`);
  // Clear the transient upload state after a few seconds (UI will rely on r.assets filename)
  setTimeout(() => {
    setUploading((p) => {
      const { [creativeId]: _omit, ...rest } = p;
      return rest;
    });
    setInfo(null);
  }, 4000);
}


  async function handleFilesDropped(creativeId: string, files: FileList | File[]) {
    const arr = Array.from(files as any);
    if (!arr.length) return;

    // Section 6B: single/multi supported — for now we upload first file as SOURCE
    // (If you want multi-assets per line, we can extend endpoint + schema later.)
    const f = arr[0] as File;
    try {
      await uploadSource(creativeId, f as File);
    } catch (e: any) {
      setErr(e?.message || "Upload failed");
    }
  }

  async function handleExcelImport(file: File) {
    setErr(null);
    setImporting(true);
    try {
      const rows = await parseExcelLike(file);
      await bulkImportCreatives(projectId, rows);
      await refresh();
    } catch (e: any) {
      setErr(e?.message || "Import failed");
    } finally {
      setImporting(false);
    }
  }

  async function parseExcelLike(file: File): Promise<any[]> {
    const name = file.name.toLowerCase();
    const buf = await file.arrayBuffer();

    // CSV fallback
    if (name.endsWith(".csv")) {
      const text = new TextDecoder("utf-8").decode(buf);
      const lines = text.split(/\r?\n/).filter((l) => l.trim());
      if (!lines.length) return [];
      const headers = lines[0].split(",").map((h) => h.trim().toLowerCase());
      return lines.slice(1).map((line) => {
        const cols = line.split(",");
        const obj: any = {};
        for (let i = 0; i < headers.length; i++) obj[headers[i]] = cols[i]?.trim();
        return normalizeImportRow(obj);
      });
    }

    // XLSX via dynamic import (keeps bundle lean)
    let XLSX: any;
    try {
      XLSX = await import("xlsx");
    } catch {
      throw new Error("xlsx library not found. Upload CSV or install 'xlsx' dependency.");
    }

    const wb = XLSX.read(buf, { type: "array" });
    const wsName = wb.SheetNames?.[0];
    const ws = wb.Sheets[wsName];
    const json = XLSX.utils.sheet_to_json(ws, { defval: "" });
    return (json as any[]).map(normalizeImportRow);
  }

  function normalizeImportRow(raw: any) {
    const get = (k: string) => raw?.[k] ?? raw?.[k.toUpperCase()] ?? raw?.[k.toLowerCase()];
    return {
      id: get("id") || undefined,
      valid: get("valid") || get(codeLabel) || undefined,
      caption: get("caption") || undefined,
      format: get("format") || undefined,
      languages: get("languages") || undefined,
      duration: get("duration") || undefined,
      remarks: get("remarks") || undefined,
      countryId: get("countryid") || get("country_id") || undefined,
    };
  }

return (
    <div className="p-4">
      <div className="mb-4">
        <h2 className="text-2xl font-semibold tracking-tight">Creatives</h2>

        <div
          className="mt-3"
          style={{
            display: "flex",
            alignItems: "center",
            gap: 12,
            width: "100%",
            flexWrap: "wrap",
            marginBottom: 8,
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
            <button className="h-10 rounded-xl border bg-white px-4 text-sm font-medium shadow-sm" onClick={() => addLine(true)}>
              Duplicate row
            </button>
            <button className="h-10 rounded-xl border bg-white px-4 text-sm font-medium shadow-sm" onClick={() => addLine(false)}>
              New row
            </button>

            <div style={{ display: "flex", alignItems: "center", flexShrink: 0 }}>
            <button
              type="button"
              className={`flex h-10 w-10 items-center justify-center rounded-xl border bg-white shadow-sm transition ${importing ? "cursor-default opacity-70" : "hover:bg-emerald-50"}`}
              title={importing ? "Importing..." : "Import Excel / CSV"}
              aria-label={importing ? "Importing spreadsheet" : "Import Excel or CSV"}
              onClick={() => {
                if (!importing) importInputRef.current?.click();
              }}
            >
              {importing ? (
                <span className="text-xs font-semibold text-slate-600">…</span>
              ) : (
                <img
                  src={EXCEL_ICON_DATA_URL}
                  alt=""
                  aria-hidden="true"
                  style={{ width: 24, height: 24, objectFit: "contain", display: "block" }}
                />
              )}
            </button>
            <input
              ref={importInputRef}
              type="file"
              accept=".xlsx,.xls,.csv"
              style={{ display: "none" }}
              onChange={(e) => {
                const f = e.target.files?.[0];
                if (f) handleExcelImport(f);
                e.target.value = "";
              }}
            />
            </div>
          </div>
        </div>
      </div>

      {err ? <div className="mt-3 text-sm text-red-600">{err}</div> : null}
      {info ? <div className="mt-3 text-sm text-green-700">{info}</div> : null}
      <div className="mt-4 table-scroll-x overflow-y-visible rounded-2xl border bg-white shadow-sm creativesTableWrap">
        <table className="w-full text-sm creativesTable" style={{ tableLayout: "fixed" }}>
          <colgroup>
            <col style={{ width: 120 }} />
            <col style={{ width: 220 }} />
            <col style={{ width: 200 }} />
            <col style={{ width: 110 }} />
            <col style={{ width: 130 }} />
            <col style={{ width: 120 }} />
            <col style={{ width: 150 }} />
            <col style={{ width: 170 }} />
            <col style={{ width: 140 }} />
            <col style={{ width: 100 }} />
            <col style={{ width: 64 }} />
          </colgroup>
          <thead className="bg-slate-50 text-slate-700">
            <tr>
              <th className="text-left p-3" style={{ width: 120 }} />
              <th className="text-left p-3" style={{ width: 220 }}>{codeLabel}</th>
              <th className="text-left p-3" style={{ width: 200 }}>Caption</th>
              <th className="text-left p-3" style={{ width: 110 }}>Format</th>
              <th className="text-left p-3" style={{ width: 130 }}>Languages</th>
              <th className="text-left p-3" style={{ width: 120 }}>Duration</th>
              <th className="text-left p-3" style={{ width: 150 }}>System</th>
              <th className="text-left p-3" style={{ width: 170 }}>Remarks</th>
              <th className="p-3 text-center" style={{ width: 140, textAlign: "center" }}>Source</th>
              <th className="p-3 text-center" style={{ width: 100, textAlign: "center" }}>QC Status</th>
              <th className="text-center p-3" style={{ width: 64 }} title="Actions" />
            </tr>
          </thead>

          <tbody>
            {rows.map((r, idx) => {
              const status = rowStatus(r);
              const u = uploading[r.id];
              const speed = u?.speedBps ?? r.assets?.find((a) => a.type === "SOURCE")?.speedBps ?? null;
              const previewTitle = sourceFileName(r) || r.valid || r.caption || `Creative ${idx + 1}`;

              return (
                <tr
                  key={r.id}
                  className="border-t align-top hover:bg-slate-50/60"
                  onDragOver={(e) => e.preventDefault()}
                  onDrop={(e) => {
                    e.preventDefault();
                    const files = e.dataTransfer.files;
                    if (files && files.length) handleFilesDropped(r.id, files);
                  }}
                >
                  <td className="px-3 py-3 align-middle">
                    <div style={creativeCenterCellStyle}>
                    <button
                      type="button"
                      title={previewTitle}
                      onClick={() => openPreview(r, idx)}
                      disabled={!previewUrls[r.id]?.url || !hasBrowserPreview(r)}
                      style={{
                        position: "relative",
                        width: 96,
                        height: 60,
                        minWidth: 96,
                        overflow: "hidden",
                        borderRadius: 12,
                        border: sourceFileName(r) ? "1px solid #d7dee8" : "1px dashed #cbd5e1",
                        background: sourceFileName(r)
                          ? "linear-gradient(135deg, #1e293b 0%, #334155 60%, #0f172a 100%)"
                          : "linear-gradient(135deg, #f1f5f9 0%, #e2e8f0 100%)",
                        boxShadow: "inset 0 0 0 1px rgba(255,255,255,0.04)",
                        cursor: previewUrls[r.id]?.url && hasBrowserPreview(r) ? "pointer" : "default",
                        padding: 0,
                        appearance: "none",
                      }}
                    >
                      {previewUrls[r.id]?.url && hasBrowserPreview(r) ? (
                        previewKind(r) === "image" ? (
                          <img
                            src={previewUrls[r.id]!.url}
                            alt={previewTitle}
                            style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover" }}
                          />
                        ) : (
                          <video
                            src={previewUrls[r.id]!.url}
                            muted
                            playsInline
                            preload="metadata"
                            style={{ position: "absolute", inset: 0, width: "100%", height: "100%", objectFit: "cover" }}
                          />
                        )
                      ) : null}
                      <div
                        style={{
                          position: "absolute",
                          inset: 0,
                          background: previewUrls[r.id]?.url ? "linear-gradient(180deg, rgba(15,23,42,0.06), rgba(15,23,42,0.22))" : "transparent",
                        }}
                      />
                      <div
                        style={{
                          position: "absolute",
                          inset: 0,
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                        }}
                      >
                        <div
                          style={{
                            width: 34,
                            height: 34,
                            borderRadius: 999,
                            border: sourceFileName(r) ? "1px solid rgba(255,255,255,0.28)" : "1px solid #cbd5e1",
                            background: sourceFileName(r) ? "rgba(255,255,255,0.16)" : "#ffffff",
                            color: sourceFileName(r) ? "#ffffff" : "#64748b",
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center",
                            fontSize: 14,
                            backdropFilter: "blur(2px)",
                          }}
                        >
                          ▶
                        </div>
                      </div>
                      <div
                        style={{
                          position: "absolute",
                          left: 8,
                          right: 8,
                          bottom: 6,
                          whiteSpace: "nowrap",
                          overflow: "hidden",
                          textOverflow: "ellipsis",
                          fontSize: 11,
                          fontWeight: 600,
                          color: sourceFileName(r) ? "rgba(255,255,255,0.92)" : "#64748b",
                          textShadow: sourceFileName(r) ? "0 1px 2px rgba(0,0,0,0.4)" : "none",
                        }}
                      >
                        {sourceFileName(r) ? fileExtLabel(sourceFileName(r)) : "No preview"}
                      </div>
                    </button>
                    </div>
                  </td>

                  <td className="px-3 py-3 align-middle">
                    <div style={creativeCellStyle}>
                    <div className="w-full space-y-2">
                      <input
                        className="creativeInput w-full rounded-xl border px-3 py-2 shadow-sm"
                        value={r.valid || ""}
                        placeholder={codeLabel}
                        onChange={(e) => setRows((prev) => prev.map((x) => (x.id === r.id ? { ...x, valid: e.target.value } : x)))}
                        onBlur={(e) => patchRow(r.id, { valid: e.target.value || null })}
                      />
                      {(u?.status === "uploading" || u?.status === "finalizing" || u?.status === "failed") ? (
                        <div className="flex items-center gap-2 flex-wrap">
                          <span
                            className={`inline-flex items-center rounded-full px-2.5 py-1 text-xs font-medium ${
                              u?.status === "failed"
                                ? "bg-red-100 text-red-700"
                                : "bg-sky-100 text-sky-700"
                            }`}
                          >
                            {u?.status === "failed" ? "Failed" : u?.status === "finalizing" ? "Finalizing" : `Uploading ${Math.round(u?.pct || 0)}%`}
                          </span>
                          {speed ? <span className="text-xs text-slate-500">{fmtBps(speed)}</span> : null}
                        </div>
                      ) : null}
                    </div>
                    </div>
                  </td>


                  <td className="px-3 py-3 align-middle">
                    <div style={creativeCellStyle}>
                    <input
                      className="creativeInput w-full rounded-xl border px-3 py-2 shadow-sm"
                      value={r.caption || ""}
                      placeholder="Caption"
                      onChange={(e) => setRows((prev) => prev.map((x) => (x.id === r.id ? { ...x, caption: e.target.value } : x)))}
                      onBlur={(e) => patchRow(r.id, { caption: e.target.value || null })}
                    />
                    </div>
                  </td>

                  <td className="px-3 py-3 align-middle">
                    <div style={creativeCellStyle}>
                    <input
                      className="creativeInput w-full rounded-xl border px-3 py-2 shadow-sm"
                      value={r.format || ""}
                      placeholder="HD/SD"
                      onChange={(e) => setRows((prev) => prev.map((x) => (x.id === r.id ? { ...x, format: e.target.value } : x)))}
                      onBlur={(e) => patchRow(r.id, { format: e.target.value || null })}
                    />
                    </div>
                  </td>

                  <td className="px-3 py-3 align-middle">
                    <div style={creativeCellStyle}>
                    <input
                      className="creativeInput w-full rounded-xl border px-2.5 py-1.5 text-[13px] shadow-sm"
                      value={(r.languages || []).join(", ")}
                      placeholder="ENG, HIN"
                      onChange={(e) =>
                        setRows((prev) =>
                          prev.map((x) => (x.id === r.id ? { ...x, languages: e.target.value.split(/[,; ]+/).filter(Boolean) } : x)),
                        )
                      }
                      onBlur={(e) => patchRow(r.id, { languages: e.target.value.split(/[,; ]+/).filter(Boolean) })}
                    />
                    </div>
                  </td>

                  <td className="px-3 py-3 align-middle">
                    <div style={creativeCellStyle}>
                    <input
                      className="creativeInput w-full rounded-xl border px-3 py-2 shadow-sm"
                      value={r.duration || ""}
                      placeholder="00:00:10:00"
                      onChange={(e) => setRows((prev) => prev.map((x) => (x.id === r.id ? { ...x, duration: e.target.value } : x)))}
                      onBlur={(e) => patchRow(r.id, { duration: e.target.value || null })}
                    />
                    </div>
                  </td>

                  <td className="px-3 py-3 align-middle">
                    <div style={creativeCellStyle}>
                      {(() => {
                        const standard = creativeBroadcastStandard(r);
                        const title = standard
                          ? (standard.label === "PAL" || standard.label === "NTSC"
                              ? `${standard.label} · ${Number(standard.fps.toFixed(2))} fps`
                              : standard.label)
                          : "Run QC after upload to detect PAL / NTSC";
                        return (
                          <span
                            className="inline-flex items-center rounded-full px-3 py-1.5 text-xs font-semibold"
                            style={{
                              background: standard?.label === "PAL" ? "#dcfce7" : standard?.label === "NTSC" ? "#dbeafe" : "#f8fafc",
                              color: standard?.label === "PAL" ? "#166534" : standard?.label === "NTSC" ? "#1d4ed8" : "#64748b",
                              border: "1px solid #e2e8f0",
                              whiteSpace: "nowrap",
                            }}
                            title={title}
                          >
                            {standard ? standard.label : "—"}
                          </span>
                        );
                      })()}
                    </div>
                  </td>

                  <td className="px-3 py-3 align-middle">
                    <div style={creativeCellStyle}>
                    <div className="w-full space-y-2">
                      <input
                        className="creativeInput w-full rounded-xl border px-3 py-2 shadow-sm"
                        value={r.remarks || ""}
                        placeholder="Remarks"
                        onChange={(e) => setRows((prev) => prev.map((x) => (x.id === r.id ? { ...x, remarks: e.target.value } : x)))}
                        onBlur={(e) => patchRow(r.id, { remarks: e.target.value || null })}
                      />
                    </div>
                    </div>
                  </td>

                  <td className="px-3 py-3 align-middle text-center" style={{ verticalAlign: "middle", textAlign: "center" }}>
                    <input
                      id={`upload-${r.id}`}
                      type="file"
                      style={{ display: "none" }}
                      onChange={(e) => {
                        const f = e.target.files?.[0];
                        if (f) handleFilesDropped(r.id, [f] as any);
                        e.target.value = "";
                      }}
                    />

                    <div style={{ ...creativeCenterCellStyle, maxWidth: 124, marginInline: "auto" }}>
                      <button
                        type="button"
                        className="creativeActionBtn inline-flex h-10 items-center justify-center rounded-xl border bg-white px-3 text-sm font-medium shadow-sm whitespace-nowrap"
                        style={{ marginInline: "auto" }}
                        title="Upload source"
                        onClick={() => {
                          const el = document.getElementById(`upload-${r.id}`) as HTMLInputElement | null;
                          el?.click();
                        }}
                      >
                        {sourceFileName(r) ? "Replace file" : "Upload file"}
                      </button>
                    </div>

                    {status.text === "Upload failed" ? (
                      <div className="mt-2 rounded-xl bg-red-50 px-3 py-2 text-xs text-red-700 text-center">Upload failed. Try replacing the file again.</div>
                    ) : null}
                  </td>

                  <td className="px-3 py-3 align-middle text-center" style={{ verticalAlign: "middle", textAlign: "center" }}>
                    <div style={{ ...creativeCenterCellStyle, maxWidth: 84, marginInline: "auto" }}>
                      {(() => {
                        const qc = String((r as any).qcStatus || "NOT_STARTED").toUpperCase();
                        const isPassed = qc === "PASSED";
                        const isFailed = qc === "FAILED";
                        const qcLabel = isPassed ? "PASS" : isFailed ? "FAIL" : qc.replace(/_/g, " ");
                        const qcColor = isPassed ? "#15803d" : isFailed ? "#b91c1c" : "#475569";
                        return (
                          <span
                            className="text-xs font-semibold tracking-wide"
                            style={{ color: qcColor, display: "inline-block", minWidth: 44, textAlign: "center", marginInline: "auto" }}
                            title={qcLabel}
                            aria-label={qcLabel}
                          >
                            {qcLabel}
                          </span>
                        );
                      })()}
                    </div>
                  </td>

                  <td className="px-3 py-3 align-middle" style={{ width: 72 }}>
                    <div style={{ ...creativeCenterCellStyle, maxWidth: 56, marginInline: "auto" }}>
                      <button
                        type="button"
                        title="Delete creative"
                        aria-label="Delete creative"
                        onClick={() => setDeleteTarget(r)}
                        style={{
                          width: 42,
                          height: 42,
                          borderRadius: 14,
                          border: "1px solid rgba(239,68,68,0.18)",
                          background: "#ffffff",
                          boxShadow: "0 6px 18px rgba(15,23,42,0.08)",
                          display: "inline-flex",
                          alignItems: "center",
                          justifyContent: "center",
                          padding: 0,
                          cursor: "pointer",
                        }}
                      >
                        <img src={deleteCreativeIcon} alt="Delete" style={{ width: 22, height: 22, display: "block" }} />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}

            {!rows.length && !loading ? (
              <tr>
                <td colSpan={10} className="p-6 text-center opacity-70">
                  No lines yet. Click “Add line”.
                </td>
              </tr>
            ) : null}
          </tbody>
        </table>
      </div>

      {loading ? <div className="mt-3 text-sm opacity-70">Loading...</div> : null}


      {typeof document !== "undefined" && deleteTarget
        ? createPortal(
            <div
              onClick={() => !deleting && setDeleteTarget(null)}
              style={{
                position: "fixed",
                inset: 0,
                zIndex: 9998,
                display: "grid",
                placeItems: "center",
                padding: 24,
                background: "rgba(15, 23, 42, 0.42)",
              }}
            >
              <div
                role="dialog"
                aria-modal="true"
                onClick={(e) => e.stopPropagation()}
                style={{
                  width: "min(460px, calc(100vw - 32px))",
                  borderRadius: 24,
                  background: "#ffffff",
                  border: "1px solid rgba(15,23,42,0.08)",
                  boxShadow: "0 24px 80px rgba(15,23,42,0.28)",
                  padding: 24,
                  display: "grid",
                  gap: 16,
                }}
              >
                <div>
                  <div style={{ fontSize: 22, fontWeight: 900, color: "#0f172a" }}>Delete creative</div>
                  <div style={{ fontSize: 14, color: "#64748b", marginTop: 8, lineHeight: 1.5 }}>
                    Delete <b style={{ color: "#0f172a" }}>{deleteTarget.valid || deleteTarget.caption || sourceFileName(deleteTarget) || "this creative"}</b>? This cannot be undone.
                  </div>
                </div>

                <div style={{ display: "flex", justifyContent: "flex-end", gap: 10, flexWrap: "wrap" }}>
                  <button
                    type="button"
                    onClick={() => setDeleteTarget(null)}
                    disabled={deleting}
                    style={{ borderRadius: 12, padding: "10px 16px", background: "#fff", border: "1px solid rgba(15,23,42,0.12)" }}
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={confirmDeleteCreative}
                    disabled={deleting}
                    style={{
                      borderRadius: 12,
                      padding: "10px 16px",
                      background: deleting ? "rgba(239,68,68,0.5)" : "#dc2626",
                      color: "#fff",
                      border: "1px solid rgba(220,38,38,0.45)",
                      fontWeight: 700,
                    }}
                  >
                    {deleting ? "Deleting..." : "Delete"}
                  </button>
                </div>
              </div>
            </div>,
            document.body,
          )
        : null}


            {typeof document !== "undefined" && activePreview
        ? createPortal(
            <div
              onClick={() => setActivePreview(null)}
              style={{
                position: "fixed",
                inset: 0,
                zIndex: 9999,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                padding: 24,
                background: "rgba(2, 6, 23, 0.82)",
                backdropFilter: "blur(2px)",
              }}
            >
              <div
                onClick={(e) => e.stopPropagation()}
                style={{
                  position: "relative",
                  width: "min(1100px, 100%)",
                  maxHeight: "calc(100vh - 48px)",
                  borderRadius: 20,
                  background: "#0f172a",
                  boxShadow: "0 30px 80px rgba(0,0,0,0.45)",
                  border: "1px solid rgba(255,255,255,0.08)",
                  padding: 18,
                  overflow: "hidden",
                }}
              >
                <button
                  type="button"
                  onClick={() => setActivePreview(null)}
                  aria-label="Close preview"
                  style={{
                    position: "absolute",
                    top: 12,
                    right: 12,
                    width: 36,
                    height: 36,
                    borderRadius: 999,
                    border: "1px solid rgba(255,255,255,0.18)",
                    background: "rgba(255,255,255,0.10)",
                    color: "#fff",
                    fontSize: 22,
                    lineHeight: 1,
                    cursor: "pointer",
                    display: "grid",
                    placeItems: "center",
                  }}
                >
                  ×
                </button>

                <div
                  style={{
                    marginBottom: 12,
                    paddingRight: 44,
                    color: "rgba(255,255,255,0.92)",
                    fontSize: 15,
                    fontWeight: 600,
                    whiteSpace: "nowrap",
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                  }}
                  title={activePreview.title}
                >
                  {activePreview.title}
                </div>

                <div
                  style={{
                    width: "100%",
                    maxHeight: "calc(100vh - 120px)",
                    overflow: "hidden",
                    borderRadius: 16,
                    background: "#000",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  {activePreview.kind === "image" ? (
                    <img
                      src={activePreview.url}
                      alt={activePreview.title}
                      style={{
                        display: "block",
                        width: "100%",
                        maxHeight: "calc(100vh - 120px)",
                        objectFit: "contain",
                        background: "#000",
                      }}
                    />
                  ) : (
                    <video
                      src={activePreview.url}
                      controls
                      autoPlay
                      playsInline
                      style={{
                        display: "block",
                        width: "100%",
                        maxHeight: "calc(100vh - 120px)",
                        background: "#000",
                      }}
                    />
                  )}
                </div>
              </div>
            </div>,
            document.body,
          )
        : null}
    </div>
  );

}