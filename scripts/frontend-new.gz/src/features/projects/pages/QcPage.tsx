import { useEffect, useMemo, useState } from "react";
import { useOutletContext, useParams } from "react-router-dom";
import { getCreativeCodeLabel, getMe, type MeResponse } from "../../../lib/me";
import type { OutletCtx } from "../types";

import type { Creative, MediaJob } from "../creatives/creatives.types";
import {
  generateQcVisuals,
  getAssetStreamUrl,
  getQcArtifactStreamUrl,
  getCreativeQcReport,
  listCreatives,
  listCreativeJobs,
  startAutoQc,
  startProxy,
} from "../creatives/creativesApi";

import { QcOverlayPlayer } from "../qc/QcOverlayPlayer";

import qcIcon from "../../../assets/icons/qc.png";
import previewIcon from "../../../assets/icons/preview.png";
import repeatIcon from "../../../assets/icons/repeat.png";
import qcPassIcon from "../../../assets/icons/qc-pass.png";
import qcFailIcon from "../../../assets/icons/qc-fail.png";

function getSourceAsset(c: Creative) {
  return (c.assets || []).find((x) => x.type === "SOURCE");
}
function getProxyAsset(c: Creative) {
  return (c.assets || []).find((x) => x.type === "PROXY");
}
function hasUploadedSource(c: Creative) {
  const a = getSourceAsset(c);
  return a && String(a.uploadStatus || "") === "UPLOADED";
}
function secondsSince(iso?: string | null) {
  if (!iso) return null;
  const t = new Date(iso).getTime();
  if (Number.isNaN(t)) return null;
  return Math.max(0, Math.floor((Date.now() - t) / 1000));
}

function findActiveJob(jobs: MediaJob[] | undefined, type: "AUTO_QC" | "PROXY_GEN") {
  if (!jobs?.length) return null;
  return jobs.find((j) => j.type === type && (j.status === "PENDING" || j.status === "RUNNING")) || null;
}



export function QcPage() {
  const params = useParams();
  // IMPORTANT: support both param names
  const projectId = (params as any).id || (params as any).projectId || "";

  const [me, setMe] = useState<MeResponse | null>(null);
  useEffect(() => {
    getMe().then(setMe).catch(() => setMe(null));
  }, []);

  const ctx = useOutletContext<OutletCtx>();

  const [creatives, setCreatives] = useState<Creative[]>([]);
  const [jobsByCreative, setJobsByCreative] = useState<Record<string, MediaJob[]>>({});
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");

  const [qcModal, setQcModal] = useState<
    | {
        creativeId: string;
        title: string;

        mode: "qc" | "preview";

        reportLoading?: boolean;
        reportError?: string;
        report?: any;

        // Main preview (Proxy/Source)
        previewLoading?: boolean;
        previewError?: string;
        previewUrl?: string;
        previewLabel?: string;
        previewKind?: "video" | "image";

        // QC tool output (waveform/vectorscope/filmstrip etc.)
        toolLoading?: boolean;
        toolError?: string;
        toolUrl?: string;
        toolLabel?: string;
        toolKind?: "video" | "image" | "text" | "qctools";
        showQctoolsDetails?: boolean;
        toolFilmstripFrames?: string[];
        toolFilmstripIndex?: number;
        visualsLoading?: boolean;
        visualsError?: string;
      }
    | null
  >(null);

  // Modal-only UI preference: show only issues (FAIL/WARN) in the checks table.
  const [checksView, setChecksView] = useState<"issues" | "all">("all");

  const tdBase: React.CSSProperties = { padding: 8, verticalAlign: "top", overflow: "hidden" };
  const tdBaseCenter: React.CSSProperties = { ...tdBase, textAlign: "center", verticalAlign: "middle" };
  const failedRowStyle: React.CSSProperties = {
    background: "linear-gradient(90deg, rgba(239,68,68,0.10), rgba(255,255,255,0.86) 28%)",
    boxShadow: "inset 4px 0 0 rgba(220,38,38,0.55)",
  };

  const failedBadgeStyle: React.CSSProperties = {
    display: "inline-flex",
    alignItems: "center",
    gap: 6,
    padding: "4px 10px",
    borderRadius: 999,
    background: "rgba(239,68,68,0.12)",
    border: "1px solid rgba(239,68,68,0.22)",
    color: "#991b1b",
    fontWeight: 700,
    width: "fit-content",
    backdropFilter: "blur(6px)",
  };

  const qcModalStatus = String((qcModal as any)?.report?.qcStatus || "").toUpperCase();
  const qcModalTone = qcModalStatus === "PASSED" ? "pass" : qcModalStatus === "FAILED" ? "fail" : "";

  async function reload() {
    if (!projectId) return;
    setErr("");
    setLoading(true);
    try {
      const data = await listCreatives(projectId);
      setCreatives(data);
      ctx.reload?.();

      // Only fetch jobs for creatives that are in-progress (keeps calls low)
      const needJobIds = data
        .filter((c) => {
          const qc = (c as any).qcStatus;
          const proxy = getProxyAsset(c);
          const proxySt = String(proxy?.uploadStatus || "");
          return qc === "IN_PROGRESS" || proxySt === "UPLOADING" || proxySt === "PENDING";
        })
        .map((c) => c.id);

      if (needJobIds.length) {
        const entries = await Promise.all(
          needJobIds.map(async (cid) => [cid, await listCreativeJobs(cid)] as const),
        );
        const next: Record<string, MediaJob[]> = {};
        for (const [cid, jobs] of entries) next[cid] = jobs;
        setJobsByCreative((prev) => ({ ...prev, ...next }));
      }
    } catch (e: any) {
      setErr(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    reload();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [projectId]);

  const needsPoll = useMemo(() => {
    return creatives.some((c) => {
      const qc = (c as any).qcStatus;
      if (qc === "IN_PROGRESS") return true;
      const proxy = getProxyAsset(c);
      const st = String(proxy?.uploadStatus || "");
      return st === "UPLOADING" || st === "PENDING";
    });
  }, [creatives]);

  useEffect(() => {
    if (!needsPoll) return;
    const t = window.setInterval(() => reload(), 2000);
    return () => window.clearInterval(t);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [needsPoll, projectId]);

  // Clean up objectURL when modal closes
  useEffect(() => {
    return () => {
      if (qcModal?.previewUrl && qcModal.previewUrl.startsWith("blob:")) URL.revokeObjectURL(qcModal.previewUrl);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [qcModal?.previewUrl]);

  async function forceQc(creativeId: string) {
    setErr("");

    const c = creatives.find((x) => x.id === creativeId);
    const srcOk = c ? hasUploadedSource(c) : false;
    const qc = (c as any)?.qcStatus || "NOT_STARTED";

    if (!srcOk) {
      setErr("Upload SOURCE first to run QC.");
      return;
    }
    if (qc === "IN_PROGRESS") return;

    try {
      // Force rerun (used when the same SOURCE is still valid but rules/expectations changed)
      await startAutoQc(creativeId, true);
      await reload();
    } catch (e: any) {
      setErr(e?.message || String(e));
    }
  }

  // kept for fallback/debug (not shown as button)
  async function genProxy(creativeId: string) {
    setErr("");
    try {
      // Do NOT force by default (backend prevents duplicate PENDING/RUNNING jobs)
      await startProxy(creativeId, false);
      await reload();
    } catch (e: any) {
      setErr(e?.message || String(e));
    }
  }
  void genProxy;

  function closeModal() {
    if (qcModal?.previewUrl && qcModal.previewUrl.startsWith("blob:")) URL.revokeObjectURL(qcModal.previewUrl);
    setQcModal(null);
  }

  async function loadQcToolUrl(
    creativeId: string,
    name: string,
    label: string,
    kind: "video" | "image" | "text",
    preserveFilmstripState: boolean,
  ) {
    // Loads QC tool artifact into the tool result panel (keeps main preview intact).
    // NOTE: For Filmstrip, we must preserve frames/index across async state updates (avoid race conditions).
    setQcModal((prev) => {
      if (!prev) return prev;
      return {
        ...prev,
        toolLoading: true,
        toolError: undefined,
        toolLabel: label,
        toolKind: kind,
        ...(preserveFilmstripState ? {} : { toolFilmstripFrames: undefined, toolFilmstripIndex: undefined }),
      };
    });

    try {
      const url = await getQcArtifactStreamUrl(creativeId, name);
      setQcModal((prev) =>
        prev
          ? {
              ...prev,
              toolLoading: false,
              toolError: undefined,
              toolUrl: url,
              toolLabel: label,
              toolKind: kind,
            }
          : prev,
      );
    } catch (e: any) {
      setQcModal((prev) => (prev ? { ...prev, toolLoading: false, toolError: e?.message || String(e) } : prev));
    }
  }

  async function previewQcArtifact(creativeId: string, name: string, label: string) {
    const lower = String(name || "").toLowerCase();
    const kind: "video" | "image" | "text" =
      lower.endsWith(".log") || lower.endsWith(".txt") || lower.endsWith(".json")
        ? "text"
        : lower.endsWith(".jpg") || lower.endsWith(".jpeg") || lower.endsWith(".png")
          ? "image"
          : "video";

    await loadQcToolUrl(creativeId, name, label, kind, label === "Filmstrip");
  }

  async function openFilmstrip(creativeId: string, frames: string[]) {
    if (!frames?.length) return;

    // Set frames/index first, then load the first frame URL.
    // IMPORTANT: do not rely on state being updated before awaiting the URL load.
    setQcModal((prev) =>
      prev
        ? {
            ...prev,
            toolFilmstripFrames: frames,
            toolFilmstripIndex: 0,
            toolUrl: undefined,
            toolError: undefined,
            toolLabel: "Filmstrip",
            toolKind: "image",
          }
        : prev,
    );

    await loadQcToolUrl(creativeId, frames[0], "Filmstrip", "image", true);
  }

  async function setFilmstripFrame(creativeId: string, frames: string[], idx: number) {
    if (!frames?.length) return;
    const nextIdx = Math.max(0, Math.min(frames.length - 1, idx));

    // Update index immediately, then load URL for that frame.
    setQcModal((prev) => (prev ? { ...prev, toolFilmstripIndex: nextIdx, toolLabel: "Filmstrip", toolKind: "image" } : prev));

    await loadQcToolUrl(creativeId, frames[nextIdx], "Filmstrip", "image", true);
  }


  function v(x: any) {
    if (x === null || x === undefined) return "—";
    if (typeof x === "number") return String(x);
    if (typeof x === "string") return x || "—";
    return String(x);
  }

  function pickStream(ffprobe: any, codecType: "video" | "audio") {
    const streams = Array.isArray(ffprobe?.streams) ? ffprobe.streams : [];
    return streams.find((s: any) => s?.codec_type === codecType) || null;
  }

  function buildQcSummaryRows(report: any) {
    const qc = report || {};
    const qcReport = qc.qcReport || {};
    const primaryProbe = qcReport.primaryProbe || qcReport?.qcli?.probe || qcReport.ffprobe || {};
    const primaryProbeTool = String(qcReport.probeTool || qcReport?.qcTools?.primaryProbeTool || (qcReport?.qcli?.probe ? "qcli" : "ffprobe"));
    const metadata = qcReport.metadata || {};
    const clientMetadata = qcReport.clientMetadata || {};
    const fmt = metadata?.format || primaryProbe.format || {};
    const vs: any = (Array.isArray(metadata?.videoStreams) && metadata.videoStreams[0]) || pickStream(primaryProbe, "video");
    const as: any = (Array.isArray(metadata?.audioStreams) && metadata.audioStreams[0]) || pickStream(primaryProbe, "audio");
    const clientGeneral = clientMetadata?.general || {};
    const clientVideo = clientMetadata?.video || {};
    const clientAudio = clientMetadata?.audioSummary || (Array.isArray(clientMetadata?.audio) ? clientMetadata.audio[0] : {}) || {};

    // QC tools (expand-only) audio measurements if present
    const measures = (qcReport.qcTools || {})?.measures || {};
    const volumeDetect = measures.volumeDetect || {};
    const loudness = measures.loudness || {};
    const audioStats = measures.audioStats || {};

    const fmtDb = (n: any) => (typeof n === "number" && Number.isFinite(n) ? `${n} dB` : "—");
    const fmtDbfs = (n: any) => (typeof n === "number" && Number.isFinite(n) ? `${n} dBFS` : "—");
    const fmtLufs = (n: any) => (typeof n === "number" && Number.isFinite(n) ? `${n} LUFS` : "—");

    const volumeText = (() => {
      const mean = volumeDetect.mean_volume_db;
      const max = volumeDetect.max_volume_db;
      if (typeof mean === "number" && typeof max === "number") return `mean ${mean} dB, max ${max} dB`;
      if (typeof mean === "number") return `mean ${mean} dB`;
      if (typeof max === "number") return `max ${max} dB`;
      return "—";
    })();

    const fps = vs?.frameRate || (vs?.avg_frame_rate && vs.avg_frame_rate !== "0/0" ? vs.avg_frame_rate : vs?.r_frame_rate);

    return [
      ["QC Status", v(qc.qcStatus)],
      ["Reasons", Array.isArray(qc.qcFailureReasons) && qc.qcFailureReasons.length ? qc.qcFailureReasons.join(", ") : "—"],
      ["Probe Tool", v(primaryProbeTool)],
      ["Checked At", v(qcReport.checkedAt)],
      ["Container", v(clientGeneral?.Format || fmt.containerLongName || fmt.format_long_name || fmt.format_name || fmt.container)],
      ["Duration (sec)", v(clientGeneral?.Duration ?? fmt.durationSeconds ?? fmt.duration)],
      ["Size (bytes)", v(clientGeneral?.Size ?? fmt.sizeBytes ?? fmt.size)],
      ["Bitrate", v(clientGeneral?.BitRate ?? fmt.bitRate ?? fmt.bit_rate)],
      ["Video Codec", v(clientVideo?.Format || vs?.codecLongName || vs?.codec_long_name || vs?.codec_name || vs?.codec)],
      ["Resolution", clientVideo?.Width && clientVideo?.Height ? `${clientVideo.Width}x${clientVideo.Height}` : (vs?.width && vs?.height ? `${vs.width}x${vs.height}` : "—")],
      ["FPS", v(clientVideo?.FrameRate ?? fps)],
      ["Audio Codec", v(clientAudio?.Format || as?.codecLongName || as?.codec_long_name || as?.codec_name || as?.codec)],
      ["Audio Channels", v(clientAudio?.Channels ?? as?.channels)],
      ["Audio Sample Rate", v(clientAudio?.SampleRate ?? as?.sampleRate ?? as?.sample_rate)],
      ["Audio Language", v(as?.language ? String(as.language).toUpperCase() : as?.tags?.language ? String(as.tags.language).toUpperCase() : null)],

      // Additional audio QC measurements (if available)
      ["RMS Trough", fmtDb(audioStats.rms_trough_db ?? audioStats.rms_level_db)],
      ["RMS Peak", fmtDb(audioStats.rms_peak_db)],
      ["Peak Level", fmtDbfs(audioStats.peak_level_db)],
      ["Loudness", fmtLufs(loudness.integrated_lufs)],
      ["Volume", volumeText],
    ] as Array<[string, string]>;
  }

  function numOrNull(x: any): number | null {
    if (typeof x === "number" && Number.isFinite(x)) return x;
    if (typeof x === "string") {
      const cleaned = x.replace(/,/g, "").trim();
      if (!cleaned) return null;
      const n = Number(cleaned);
      return Number.isFinite(n) ? n : null;
    }
    return null;
  }

  function formatBytesHuman(x: any) {
    const n = numOrNull(x);
    if (n === null || n < 0) return v(x);
    const units = ["B", "KB", "MB", "GB", "TB"];
    let value = n;
    let idx = 0;
    while (value >= 1024 && idx < units.length - 1) {
      value /= 1024;
      idx += 1;
    }
    const digits = value >= 100 || idx === 0 ? 0 : value >= 10 ? 1 : 2;
    return `${value.toFixed(digits)} ${units[idx]}`;
  }

  function formatDurationHuman(x: any) {
    const n = numOrNull(x);
    if (n === null || n < 0) return v(x);
    const total = Math.round(n);
    const h = Math.floor(total / 3600);
    const m = Math.floor((total % 3600) / 60);
    const s = total % 60;
    if (h > 0) return `${h}h ${String(m).padStart(2, "0")}m ${String(s).padStart(2, "0")}s`;
    if (m > 0) return `${m}m ${String(s).padStart(2, "0")}s`;
    return `${s}s`;
  }

  function formatDateTimeHuman(x: any) {
    if (!x) return "—";
    const dt = new Date(x);
    if (Number.isNaN(dt.getTime())) return v(x);
    return dt.toLocaleString();
  }

  function formatElapsed(start?: any, end?: any) {
    if (!start || !end) return "—";
    const s = new Date(start).getTime();
    const e = new Date(end).getTime();
    if (Number.isNaN(s) || Number.isNaN(e) || e < s) return "—";
    return formatDurationHuman((e - s) / 1000);
  }


  function parseQcliStages(logText: string) {
    const text = String(logText || "");
    if (!text.trim()) return [] as Array<[string, string]>;

    const has = (pattern: RegExp) => pattern.test(text);
    const outputMatch = text.match(/done,\s*in\s+([^\n\r]+)/i);

    const rows: Array<[string, string]> = [];
    rows.push(["Analyze input", has(/analyzing completed/i) ? "Completed" : has(/analyzing input file/i) ? "Started" : "—"]);
    rows.push(["QCTools report", has(/generating QCTools report\.\.\. done/i) || has(/done,\s*in/i) ? "Generated" : has(/generating QCTools report/i) ? "Started" : "—"]);
    rows.push(["Thumbnails", has(/adding thumbnails to QCTools report/i) ? "Added" : "—"]);
    rows.push(["Panels", has(/adding panels to QCTools report/i) ? "Added" : "—"]);
    if (outputMatch?.[1]) rows.push(["Output file", outputMatch[1].trim()]);
    return rows;
  }

  function buildQctoolsDetails(report: any) {
    const qc = report || {};
    const qcReport = qc.qcReport || {};
    const qcTools = (qcReport.qcTools || {}) as any;
    const art = (qcTools?.artifacts || {}) as any;
    const qcli = (qcTools?.qcli || qcReport?.qcli || {}) as any;

    const getArtifactPath = (k: string): string | null => {
      const v: any = art?.[k];
      if (typeof v === "string" && v) return v;
      const p = v?.path ?? v?.name ?? v?.blobKey ?? v?.blobPath ?? v?.file ?? v?.key;
      return typeof p === "string" && p ? p : null;
    };

    const qctoolsPreview = getArtifactPath("qctoolsPreview") || getArtifactPath("qctools_preview") || getArtifactPath("qctools_preview.jpg");
    const qctoolsMkv = getArtifactPath("qctoolsMkv") || getArtifactPath("qctools.mkv") || getArtifactPath("qctools_mkv");
    const filmFrames: string[] = Array.isArray(art?.filmstrip?.frames) ? art.filmstrip.frames : [];
    const visualsCount = [
      art?.waveform, art?.vectorscope, art?.oscilloscope, art?.ciescope, art?.pixscope, art?.audioGraph, filmFrames.length ? true : null,
    ].filter(Boolean).length;

    const summary = [
      ["Primary tool", v(qcTools?.primaryProbeTool || qcReport?.probeTool || "QCTools")],
      ["Report file", qctoolsMkv ? "Generated" : "Not available"],
      ["Preview image", qctoolsPreview ? "Ready" : "Not available yet"],
      ["Generated at", formatDateTimeHuman(qcTools?.generatedAt || qcReport?.checkedAt)],
      ["Visual outputs", visualsCount ? `${visualsCount} available` : "Not generated yet"],
    ] as Array<[string, string]>;

    return {
      summary,
      stages: parseQcliStages(String(qcli?.log || "")),
      reportReady: Boolean(qctoolsMkv),
      previewReady: Boolean(qctoolsPreview),
    };
  }

  function buildClientFacingSummaries(report: any) {
    const d = report || {};
    const qcReport = d.qcReport || {};
    const primaryProbe = qcReport.primaryProbe || qcReport?.qcli?.probe || qcReport.ffprobe || {};
    const metadata = qcReport.metadata || {};
    const clientMetadata = qcReport.clientMetadata || {};
    const fmt = metadata?.format || primaryProbe.format || {};
    const vs: any = (Array.isArray(metadata?.videoStreams) && metadata.videoStreams[0]) || pickStream(primaryProbe, "video") || {};
    const audioStreams: any[] = Array.isArray(metadata?.audioStreams)
      ? metadata.audioStreams
      : Array.isArray(primaryProbe?.streams)
        ? primaryProbe.streams.filter((s: any) => s?.codec_type === "audio")
        : [];
    const as: any = (audioStreams && audioStreams[0]) || {};
    const clientGeneral = clientMetadata?.general || {};
    const clientVideo = clientMetadata?.video || {};
    const clientAudioList = Array.isArray(clientMetadata?.audio) ? clientMetadata.audio : [];
    const clientAudioSummary = clientMetadata?.audioSummary || clientAudioList[0] || {};
    const checks: any[] = Array.isArray(qcReport.checks) ? qcReport.checks : [];
    const summary: any = qcReport.checkSummary || {};
    const qcTools = (qcReport.qcTools || {}) as any;
    const art = (qcTools?.artifacts || {}) as any;

    const width = clientVideo?.Width ?? vs?.width;
    const height = clientVideo?.Height ?? vs?.height;
    const resolution = width && height ? `${width} × ${height}` : "—";
    const fps = clientVideo?.FrameRate || vs?.frameRate || (vs?.avg_frame_rate && vs.avg_frame_rate !== "0/0" ? vs.avg_frame_rate : vs?.r_frame_rate) || "—";
    const dar = clientVideo?.DisplayAspectRatio || clientVideo?.DisplayAspectRatio_String || clientVideo?.DisplayAspectRatioString || vs?.displayAspectRatio || vs?.display_aspect_ratio || "—";
    const videoCodec = clientVideo?.Format || vs?.codecLongName || vs?.codec_long_name || vs?.codec_name || vs?.codec || "—";
    const audioCodec = clientAudioSummary?.Format || as?.codecLongName || as?.codec_long_name || as?.codec_name || as?.codec || "—";
    const audioTrackCount = clientAudioList.length || audioStreams.length || (clientAudioSummary ? 1 : 0);
    const audioChannels = clientAudioSummary?.Channels ?? as?.channels;

    const fileSummary = [
      ["Container", v(clientGeneral?.Format || fmt.containerLongName || fmt.format_long_name || fmt.format_name || fmt.container)],
      ["Duration", formatDurationHuman(clientGeneral?.Duration ?? fmt.durationSeconds ?? fmt.duration)],
      ["File size", formatBytesHuman(clientGeneral?.Size ?? fmt.sizeBytes ?? fmt.size)],
      ["Video", v(videoCodec)],
      ["Resolution", resolution],
      ["Frame rate", v(fps)],
      ["Aspect ratio", v(dar)],
      ["Audio", audioTrackCount ? `${audioTrackCount} track${audioTrackCount === 1 ? "" : "s"} • ${audioCodec}${audioChannels ? ` • ${audioChannels} ch` : ""}` : "—"],
    ] as Array<[string, string]>;

    const issueChecks = checks.filter((c: any) => {
      const st = String(c?.status || "").toUpperCase();
      return st === "FAIL" || st === "WARN";
    });
    const issueSummary = issueChecks.slice(0, 4).map((c: any) => ({
      name: String(c?.name || "Check"),
      status: String(c?.status || "NA").toUpperCase(),
      message: String(c?.message || c?.expected || c?.value || "").trim(),
    }));

    const qctoolsReady = Boolean(art?.qctoolsMkv || art?.["qctools.mkv"] || art?.qctools_mkv);
    const qctoolsPreviewReady = Boolean(art?.qctoolsPreview || art?.qctools_preview || art?.["qctools_preview.jpg"]);
    const visualsReady = Boolean(
      art?.waveform || art?.waveformVideo || art?.waveform_mp4 ||
      art?.vectorscope || art?.vectorScope || art?.vectorscopeVideo || art?.vectorscope_mp4 ||
      art?.oscilloscope || art?.oscilloScope || art?.oscilloscopeVideo || art?.oscilloscope_mp4 ||
      art?.ciescope || art?.cieScope || art?.cie_scope || art?.ciescopeVideo || art?.ciescope_mp4 ||
      art?.pixscope || art?.pixelScope || art?.pixScope || art?.pixel_scope || art?.pixscopeVideo || art?.pixscope_mp4 ||
      art?.audioGraph || art?.audio_graph || art?.audiograph || art?.audioGraphVideo ||
      (Array.isArray(art?.filmstrip?.frames) && art.filmstrip.frames.length)
    );

    const runSummary = [
      ["QC started", formatDateTimeHuman(d.autoQcStartedAt || qcReport.checkedAt)],
      ["QC finished", formatDateTimeHuman(d.autoQcEndedAt)],
      ["Time taken", formatElapsed(d.autoQcStartedAt || qcReport.checkedAt, d.autoQcEndedAt)],
      ["Metadata read", clientMetadata && Object.keys(clientMetadata).length ? "Ready" : "Not available"],
      ["QCTools report", qctoolsReady ? "Generated" : "Not generated"],
      ["QCTools preview", qctoolsPreviewReady ? "Ready" : "Not available yet"],
      ["Visual outputs", visualsReady ? "Generated" : "Generate when needed"],
    ] as Array<[string, string]>;

    return {
      fileSummary,
      qcSummary: {
        status: String(d.qcStatus || "—"),
        total: Number(summary.total ?? checks.length ?? 0),
        pass: Number(summary.pass ?? 0),
        fail: Number(summary.fail ?? 0),
        warn: Number(summary.warn ?? 0),
        na: Number(summary.na ?? 0),
        issues: issueSummary,
      },
      runSummary,
    };
  }

  async function generateVisualsForModal(creativeId: string) {
    setQcModal((prev) => (prev ? { ...prev, visualsLoading: true, visualsError: undefined } : prev));
    try {
      await generateQcVisuals(creativeId);
      const data = await getCreativeQcReport(creativeId);
      setQcModal((prev) =>
        prev
          ? {
              ...prev,
              visualsLoading: false,
              visualsError: undefined,
              report: data,
            }
          : prev,
      );
    } catch (e: any) {
      setQcModal((prev) =>
        prev ? { ...prev, visualsLoading: false, visualsError: e?.message || String(e) } : prev,
      );
    }
  }

  async function openQcModal(c: Creative, mode: "qc" | "preview") {
    setErr("");
    setChecksView("all");
    const title = `${mode === "qc" ? "QC" : "Preview"} — ${c.valid || c.id}`;
    setQcModal({ creativeId: c.id, title, mode, reportLoading: true, previewLoading: mode === "preview" });

    // 1) Load QC report
    getCreativeQcReport(c.id)
      .then((data) => {
        setQcModal((prev) => (prev ? { ...prev, reportLoading: false, report: data } : prev));
      })
      .catch((e: any) => {
        setQcModal((prev) => (prev ? { ...prev, reportLoading: false, reportError: e?.message || String(e) } : prev));
      });

    // 2) Load a preview video URL (prefer PROXY if uploaded, else SOURCE)
    if (mode === "preview") {
      try {
        const proxy = getProxyAsset(c);
        const proxyOk = String(proxy?.uploadStatus || "") === "UPLOADED";

        let label: string = proxyOk ? "Proxy" : "Source";
        const url = await getAssetStreamUrl(c.id, proxyOk ? "PROXY" : "SOURCE");

        setQcModal((prev) => {
          if (!prev) return prev;
          if (prev.previewUrl && prev.previewUrl.startsWith("blob:")) URL.revokeObjectURL(prev.previewUrl);
          return { ...prev, previewLoading: false, previewUrl: url, previewLabel: label, previewKind: "video" };
        });
      } catch (e: any) {
        setQcModal((prev) => (prev ? { ...prev, previewLoading: false, previewError: e?.message || String(e) } : prev));
      }
    }
  }

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div className="card" style={{ display: "flex", gap: 8, alignItems: "center", justifyContent: "space-between" }}>
        <div>
          <h3 style={{ margin: 0 }}>QC</h3>
        </div>
        <button onClick={reload} disabled={loading}>Refresh</button>
      </div>

      {err ? (
        <div className="card" style={{ border: "1px solid #ffb3b3" }}>
          <div style={{ fontSize: 13, color: "#a10000" }}>{err}</div>
        </div>
      ) : null}

      <div className="card" style={{ overflowX: "auto" }}>
        <table
          style={{
            width: "100%",
            // Important: table-layout is fixed and we use an explicit colgroup.
            // If the number of <col> entries doesn't match the number of columns,
            // trailing columns may collapse / look missing in some browsers.
            minWidth: 1220,
            tableLayout: "fixed",
            fontSize: 13,
          }}
        >
          <colgroup>
            <col style={{ width: 170 }} />
            <col style={{ width: 260 }} />
            <col style={{ width: 160 }} />
            <col style={{ width: 240 }} />
            <col style={{ width: 150 }} />
            <col style={{ width: 120 }} />
            <col style={{ width: 120 }} />
          </colgroup>

          <thead>
            <tr style={{ textAlign: "left", borderBottom: "1px solid rgba(0,0,0,0.1)" }}>
              <th style={tdBase}>{getCreativeCodeLabel(me)}</th>
              <th style={tdBase}>Caption</th>
              <th style={tdBase}>QC Status</th>
              <th style={tdBase}>QC Reasons</th>
              <th style={tdBase}>Proxy</th>
              <th style={tdBaseCenter}>QC</th>
              <th style={tdBaseCenter}>Preview</th>
            </tr>
          </thead>

          <tbody>
            {creatives.map((c) => {
              const qc = (c as any).qcStatus || "NOT_STARTED";
              const reasonsArr: string[] = (c as any).qcFailureReasons || [];
              const reasons = reasonsArr.join(", ");
              const srcOk = hasUploadedSource(c);

              const qcElapsed = qc === "IN_PROGRESS" ? secondsSince((c as any).autoQcStartedAt) : null;

              const proxy = getProxyAsset(c);
              const proxySt = String(proxy?.uploadStatus || "—");
              const proxyElapsed =
                proxySt === "UPLOADING" ? secondsSince((proxy as any)?.uploadStartedAt) : null;

              const jobs = jobsByCreative[c.id];
              const activeQcJob = findActiveJob(jobs, "AUTO_QC");
              const activeProxyJob = findActiveJob(jobs, "PROXY_GEN");
              // QC runs automatically after SOURCE upload. Manual action is only Force QC on FAILED.
              // const qcBlockedUntilUpload = qc === "FAILED";

              // ✅ Rule for View QC & Preview:
              // Enabled if there is something to view:
              // - QC has already run (PASSED/FAILED) OR
              // - proxy exists/started OR
              // - source exists (so we can at least preview SOURCE)
              const qcHasRun = qc === "PASSED" || qc === "FAILED";
              const proxyExistsOrStarted = proxySt !== "—" && proxySt !== "PENDING";
              const canViewQcReport = qcHasRun;
              const canPreview = proxyExistsOrStarted || srcOk;

              const isFailed = qc === "FAILED";

              return (
                <tr
                  key={c.id}
                  style={{
                    borderBottom: "1px solid rgba(0,0,0,0.06)",
                    ...(isFailed ? failedRowStyle : {}),
                  }}
                >
                  <td style={tdBase}><b>{c.valid || "—"}</b></td>
                  <td style={tdBase}>{c.caption || "—"}</td>

                  <td style={tdBase}>
                    <div style={{ display: "grid", gap: 4 }}>
                      {isFailed ? <span style={failedBadgeStyle}>{qc}</span> : <b>{qc}</b>}
                      {qc === "IN_PROGRESS" && qcElapsed != null ? (
                        <span style={{ fontSize: 12, opacity: 0.75 }}>Running… {qcElapsed}s</span>
                      ) : null}
                      {activeQcJob ? (
                        <span style={{ fontSize: 12, opacity: 0.75 }}>
                          Job: {activeQcJob.status} (attempts {activeQcJob.attempts ?? 0})
                        </span>
                      ) : null}
                    </div>
                  </td>

                  <td style={tdBase} title={reasons}>
                    {qc === "FAILED" ? (
                      <span style={{ ...failedBadgeStyle, borderRadius: 12, fontWeight: 600 }}>{reasons || "—"}</span>
                    ) : (
                      "—"
                    )}
                  </td>

                  <td style={tdBase}>
                    <div style={{ display: "grid", gap: 4 }}>
                      <b>{proxySt}</b>
                      {proxySt === "UPLOADING" && proxyElapsed != null ? (
                        <span style={{ fontSize: 12, opacity: 0.75 }}>Generating… {proxyElapsed}s</span>
                      ) : null}
                      {proxySt === "FAILED" && (proxy as any)?.error ? (
                        <span style={{ fontSize: 12, color: "#a10000" }}>{(proxy as any).error}</span>
                      ) : null}
                      {activeProxyJob ? (
                        <span style={{ fontSize: 12, opacity: 0.75 }}>
                          Job: {activeProxyJob.status} (attempts {activeProxyJob.attempts ?? 0})
                        </span>
                      ) : null}
                    </div>
                  </td>

                  <td style={tdBaseCenter}>
                    <div className="qcActionCell qcActionCell--center">
                      <div className="qcActionRow">
                        <button
                          className="qcActionBtn qcIconBtn qcIconBtn--qc"
                          onClick={() => openQcModal(c, "qc")}
                          disabled={!canViewQcReport}
                          title={!canViewQcReport ? "QC report not available yet" : "Open QC report"}
                          aria-label="QC report"
                        >
                          <img className="qcIconImg" src={qcIcon} alt="" />
                        </button>
                        {qc === "FAILED" && srcOk ? (
                          <button
                            className="qcActionBtn qcIconBtn qcIconBtn--force"
                            onClick={() => forceQc(c.id)}
                            disabled={qc === "IN_PROGRESS"}
                            title="Force QC (rerun on the same SOURCE)"
                            aria-label="Force QC"
                          >
                            <img className="qcIconImg" src={repeatIcon} alt="" />
                          </button>
                        ) : null}
                      </div>

                      {!srcOk ? <span className="qcActionHint">Upload SOURCE first</span> : null}
                    </div>
                  </td>

                  <td style={tdBaseCenter}>
                    <div className="qcActionCell qcActionCell--center">
                      <button
                        className="qcActionBtn qcIconBtn qcIconBtn--preview"
                        onClick={() => openQcModal(c, "preview")}
                        disabled={!canPreview}
                        title={!canPreview ? "Upload SOURCE first to preview" : "Open preview + QC tools"}
                        aria-label="Preview"
                      >
                        <img className="qcIconImg" src={previewIcon} alt="" />
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}

            {!creatives.length && !loading ? (
              <tr>
                <td colSpan={7} style={{ padding: 12, opacity: 0.7, textAlign: "center" }}>
                  No creatives found. (If Creatives step has rows, this usually means route param name mismatch;
                  this page now supports both id/projectId.)
                </td>
              </tr>
            ) : null}
          </tbody>
        </table>
      </div>

      {qcModal ? (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(0,0,0,0.35)",
            display: "grid",
            placeItems: "center",
            padding: 16,
            zIndex: 1000,
          }}
          onClick={closeModal}
        >
          <div
            className={`card qc-modal ${qcModalTone ? "qc-modal--" + qcModalTone : ""}`}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="qc-modal__header">
              <b>{qcModal.title}</b>
              <button className="qc-modal__close" onClick={closeModal}>Close</button>
            </div>

            <div className="qc-modal__grid" style={qcModal.mode === "preview" ? { gridTemplateColumns: "1fr" } : undefined}>
              {qcModal.mode === "qc" ? (
                <>
                  {/* QC Report (left) */}
                  <div className="card qc-modal__panel">
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                      <b>QC Report</b>
                    </div>

                    {qcModal.reportLoading ? (
                      <div style={{ marginTop: 10, opacity: 0.8 }}>Loading QC report…</div>
                    ) : qcModal.reportError ? (
                      <div style={{ marginTop: 10, color: "#a10000" }}>{qcModal.reportError}</div>
                    ) : (
                      (() => {
                        const d = qcModal.report || {};
                        const rows = buildQcSummaryRows(d);
                        return (
                          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13, marginTop: 10 }}>
                            <tbody>
                              <tr>
                                <td style={{ padding: 6, opacity: 0.75, width: 160 }}>Started</td>
                                <td style={{ padding: 6 }}>
                                  {d.autoQcStartedAt ? new Date(d.autoQcStartedAt).toLocaleString() : "—"}
                                </td>
                              </tr>
                              <tr>
                                <td style={{ padding: 6, opacity: 0.75 }}>Ended</td>
                                <td style={{ padding: 6 }}>
                                  {d.autoQcEndedAt ? new Date(d.autoQcEndedAt).toLocaleString() : "—"}
                                </td>
                              </tr>
                              {rows.map(([k, val]) => (
                                <tr key={k} style={{ borderTop: "1px solid rgba(0,0,0,0.06)" }}>
                                  <td style={{ padding: 6, opacity: 0.75 }}>{k}</td>
                                  <td style={{ padding: 6 }}>{val}</td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        );
                      })()
                    )}
                  </div>

                  {/* Checks (right) */}
                  <div className="card qc-modal__panel">
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 10 }}>
                      <b>Checks</b>
                      <label style={{ fontSize: 12, opacity: 0.85, display: "flex", alignItems: "center", gap: 6 }}>
                        <input
                          type="checkbox"
                          checked={checksView === "issues"}
                          onChange={(e) => setChecksView(e.target.checked ? "issues" : "all")}
                        />
                        Issues only
                      </label>
                    </div>

                    {qcModal.reportLoading ? (
                      <div style={{ marginTop: 10, opacity: 0.8 }}>Loading checks…</div>
                    ) : qcModal.reportError ? (
                      <div style={{ marginTop: 10, color: "#a10000" }}>{qcModal.reportError}</div>
                    ) : (
                      (() => {
                        const d = qcModal.report || {};
                        const qcEval: any = d.qcReport || {};
                        const checks: any[] = Array.isArray(qcEval.checks) ? qcEval.checks : [];
                        const summary: any = qcEval.checkSummary || {};

                        if (!checks.length) {
                          return <div style={{ marginTop: 10, opacity: 0.75 }}>No checks available.</div>;
                        }

                        const filtered =
                          checksView === "issues"
                            ? checks.filter(
                                (c: any) =>
                                  String(c?.status || "").toUpperCase() === "FAIL" ||
                                  String(c?.status || "").toUpperCase() === "WARN",
                              )
                            : checks;

                        const statusColor = (st: string) => {
                          const s = String(st || "").toUpperCase();
                          if (s === "FAIL") return "#a10000";
                          if (s === "WARN") return "#9a6b00";
                          if (s === "PASS") return "#0a6b2f";
                          return "rgba(0,0,0,0.6)";
                        };

                        return (
                          <>
                            <div style={{ fontSize: 12, opacity: 0.75, marginTop: 6 }}>
                              total {summary.total ?? checks.length} • pass {summary.pass ?? 0} • fail {summary.fail ?? 0} • warn {summary.warn ?? 0} • n/a {summary.na ?? 0}
                            </div>

                            <div
                              style={{
                                maxHeight: 520,
                                overflow: "auto",
                                marginTop: 10,
                                border: "1px solid rgba(0,0,0,0.08)",
                                borderRadius: 10,
                              }}
                            >
                              <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12 }}>
                                <thead>
                                  <tr style={{ textAlign: "left", borderBottom: "1px solid rgba(0,0,0,0.06)" }}>
                                    <th style={{ padding: 6, width: 220 }}>Property Name</th>
                                    <th style={{ padding: 6 }}>Property Value</th>
                                    <th style={{ padding: 6, width: 90 }}>QC Status</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {filtered.map((c: any, idx: number) => {
                                    const st = String(c?.status || "NA").toUpperCase();
                                    const group = String(c?.group || "—");
                                    const name = String(c?.name || "—");
                                    const value = String(c?.value ?? "—");
                                    const expected =
                                      c?.expected != null && String(c.expected).trim() !== "" ? String(c.expected) : "";
                                    const message =
                                      c?.message != null && String(c.message).trim() !== "" ? String(c.message) : "";

                                    return (
                                      <tr key={`${group}-${name}-${idx}`} style={{ borderTop: "1px solid rgba(0,0,0,0.04)" }}>
                                        <td style={{ padding: 6 }}>
                                          <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
                                            <span
                                              style={{
                                                fontSize: 11,
                                                padding: "2px 8px",
                                                borderRadius: 999,
                                                background: "rgba(0,0,0,0.05)",
                                                opacity: 0.85,
                                              }}
                                            >
                                              {group}
                                            </span>
                                            <span style={{ fontWeight: 600 }}>{name}</span>
                                          </div>
                                        </td>

                                        <td style={{ padding: 6, whiteSpace: "pre-wrap", wordBreak: "break-word" }}>
                                          <div>{value}</div>
                                          {expected ? (
                                            <div style={{ marginTop: 4, fontSize: 11, opacity: 0.75 }}>
                                              Expected: <span style={{ opacity: 0.9 }}>{expected}</span>
                                            </div>
                                          ) : null}
                                          {message ? (
                                            <div
                                              style={{
                                                marginTop: 2,
                                                fontSize: 11,
                                                color: st === "FAIL" ? "#a10000" : "rgba(0,0,0,0.75)",
                                              }}
                                            >
                                              {message}
                                            </div>
                                          ) : null}
                                        </td>

                                        <td style={{ padding: 6 }}>
                                          <div className="qc-check-status" title={st}>
                                            {st === "PASS" ? (
                                              <img className="qc-check-status__icon" src={qcPassIcon} alt="PASS" />
                                            ) : st === "FAIL" ? (
                                              <img className="qc-check-status__icon" src={qcFailIcon} alt="FAIL" />
                                            ) : (
                                              <span style={{ color: statusColor(st), fontWeight: 800 }}>{st}</span>
                                            )}
                                          </div>
                                        </td>
                                      </tr>
                                    );
                                  })}
                                  {!filtered.length ? (
                                    <tr>
                                      <td colSpan={3} style={{ padding: 10, opacity: 0.7 }}>
                                        No checks to show.
                                      </td>
                                    </tr>
                                  ) : null}
                                </tbody>
                              </table>
                            </div>
                          </>
                        );
                      })()
                    )}
                  </div>
                </>
              ) : null}

              {qcModal.mode === "preview" ? (
                <>
              {/* Right: video preview */}
              <div className="card qc-modal__panel">
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
                  <b>Preview</b>
                </div>

                {qcModal.previewLoading ? (
                  <div style={{ marginTop: 10, opacity: 0.8 }}>Loading preview…</div>
                ) : qcModal.previewError ? (
                  <div style={{ marginTop: 10, color: "#a10000" }}>{qcModal.previewError}</div>
                ) : qcModal.previewUrl ? (
                  <div style={{ marginTop: 10 }}>
                    {qcModal.previewKind === "image" ? (
                      <div style={{ display: "grid", gap: 8 }}>
                        <div style={{ fontSize: 12, opacity: 0.75 }}>{qcModal.previewLabel || ""}</div>
                        <img
                          src={qcModal.previewUrl}
                          alt={qcModal.previewLabel || "Preview"}
                          style={{ maxWidth: "100%", height: "auto", borderRadius: 6 }}
                        />
                      </div>
                    ) : (
                      <QcOverlayPlayer src={qcModal.previewUrl} label={qcModal.previewLabel} />
                    )}
                  </div>
                ) : (
                  <div style={{ marginTop: 10, opacity: 0.75 }}>No preview available.</div>
                )}

                {(() => {
                  const d = qcModal.report || {};
                  const qcTools = (d.qcReport || {})?.qcTools;
                  const art = qcTools?.artifacts || {};

                  const visualButtons: Array<{ key: string; label: string; path: string; kind: "video" | "image" }> = [];
                  const technicalButtons: Array<{ key: string; label: string; path: string; kind: "video" | "image" | "text" }> = [];

                  const getArtifactPath = (k: string): string | null => {
                    const v: any = (art as any)?.[k];
                    if (typeof v === "string" && v) return v;
                    const p = v?.path ?? v?.name ?? v?.blobKey ?? v?.blobPath ?? v?.file ?? v?.key;
                    if (typeof p === "string" && p) return p;
                    return null;
                  };

                  const addVisual = (keys: string[] | string, label: string, kind: "video" | "image" = "video") => {
                    const ks = Array.isArray(keys) ? keys : [keys];
                    for (const k of ks) {
                      const p = getArtifactPath(k);
                      if (p) {
                        visualButtons.push({ key: ks[0], label, path: p, kind });
                        break;
                      }
                    }
                  };

                  const addTechnical = (keys: string[] | string, label: string, kind: "video" | "image" | "text") => {
                    const ks = Array.isArray(keys) ? keys : [keys];
                    for (const k of ks) {
                      const p = getArtifactPath(k);
                      if (p) {
                        technicalButtons.push({ key: ks[0], label, path: p, kind });
                        break;
                      }
                    }
                  };

                  const qctoolsPreview = getArtifactPath("qctoolsPreview") || getArtifactPath("qctools_preview") || getArtifactPath("qctools_preview.jpg");
                  const qctoolsMkv = getArtifactPath("qctoolsMkv") || getArtifactPath("qctools.mkv") || getArtifactPath("qctools_mkv");

                  addVisual(["waveform", "waveformVideo", "waveform_mp4"], "Waveform");
                  addVisual(["vectorscope", "vectorScope", "vectorscopeVideo", "vectorscope_mp4"], "Vectorscope");
                  addVisual(["oscilloscope", "oscilloScope", "oscilloscopeVideo", "oscilloscope_mp4"], "Oscilloscope");
                  addVisual(["ciescope", "cieScope", "cie_scope", "ciescopeVideo", "ciescope_mp4"], "CIE Scope");
                  addVisual(["pixscope", "pixelScope", "pixScope", "pixel_scope", "pixscopeVideo", "pixscope_mp4"], "Pixel Scope");
                  addVisual(["audioGraph", "audio_graph", "audiograph", "audioGraphVideo"], "Audio Graph");

                  addTechnical(["qcLog", "qc_log", "qclog"], "Detailed QC Log", "text");
                  addTechnical(["qcliLog", "qcli.log", "qcli_log"], "QCTools Processing Log", "text");
                  addTechnical(["mediainfoJson", "mediainfo.json", "mediainfo", "mediainfo_json"], "Full Metadata JSON", "text");
                  addTechnical(["qcEvalJson", "qc_eval.json", "qcEval", "qc_eval_json"], "Full QC Results JSON", "text");
                  addTechnical(["qcToolsJson", "qc_tools.json", "qcTools", "qc_tools_json"], "Visual Outputs JSON", "text");

                  const filmFrames: string[] = Array.isArray(art.filmstrip?.frames) ? art.filmstrip.frames : [];
                  const hasVisuals = visualButtons.length > 0 || filmFrames.length > 0;
                  const hasQctoolsOutput = Boolean(qctoolsPreview || qctoolsMkv);
                  const hasTechnical = technicalButtons.length > 0;
                  const clientFacing = buildClientFacingSummaries(d);

                  if (!clientFacing.fileSummary.length && !hasQctoolsOutput && !hasVisuals && !hasTechnical) return null;

                  return (
                    <div style={{ marginTop: 14, display: "grid", gap: 12 }}>
                      <hr style={{ margin: "12px 0 0" }} />

                      <div style={{ display: "grid", gap: 12, gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))" }}>
                        <div className="card" style={{ padding: 12, display: "grid", gap: 8 }}>
                          <div>
                            <b>File Summary</b>
                            <div style={{ fontSize: 12, opacity: 0.75, marginTop: 4 }}>
                              A simple summary of the uploaded source file.
                            </div>
                          </div>
                          <div style={{ display: "grid", gap: 8 }}>
                            {clientFacing.fileSummary.map(([label, value]) => (
                              <div key={label} style={{ display: "grid", gap: 2 }}>
                                <div style={{ fontSize: 11, opacity: 0.65 }}>{label}</div>
                                <div style={{ fontSize: 13, fontWeight: 600 }}>{value}</div>
                              </div>
                            ))}
                          </div>
                        </div>

                        <div className="card" style={{ padding: 12, display: "grid", gap: 8 }}>
                          <div>
                            <b>QC Summary</b>
                            <div style={{ fontSize: 12, opacity: 0.75, marginTop: 4 }}>
                              A client-friendly view of what passed and what needs attention.
                            </div>
                          </div>
                          <div className="row" style={{ flexWrap: "wrap", gap: 8 }}>
                            <span style={{ padding: "6px 10px", borderRadius: 999, background: "rgba(15,23,42,0.06)", fontSize: 12, fontWeight: 700 }}>
                              Status: {clientFacing.qcSummary.status}
                            </span>
                            <span style={{ padding: "6px 10px", borderRadius: 999, background: "rgba(16,185,129,0.10)", fontSize: 12 }}>
                              Pass {clientFacing.qcSummary.pass}
                            </span>
                            <span style={{ padding: "6px 10px", borderRadius: 999, background: "rgba(239,68,68,0.10)", fontSize: 12 }}>
                              Fail {clientFacing.qcSummary.fail}
                            </span>
                            <span style={{ padding: "6px 10px", borderRadius: 999, background: "rgba(245,158,11,0.10)", fontSize: 12 }}>
                              Warn {clientFacing.qcSummary.warn}
                            </span>
                          </div>
                          {clientFacing.qcSummary.issues.length ? (
                            <div style={{ display: "grid", gap: 8 }}>
                              {clientFacing.qcSummary.issues.map((issue) => (
                                <div key={`${issue.status}-${issue.name}`} style={{ border: "1px solid rgba(15,23,42,0.08)", borderRadius: 12, padding: 10, background: issue.status === "FAIL" ? "rgba(239,68,68,0.05)" : "rgba(245,158,11,0.06)" }}>
                                  <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 8 }}>
                                    <b style={{ fontSize: 13 }}>{issue.name}</b>
                                    <span style={{ fontSize: 11, fontWeight: 700, color: issue.status === "FAIL" ? "#a10000" : "#9a6b00" }}>{issue.status}</span>
                                  </div>
                                  <div style={{ fontSize: 12, opacity: 0.8, marginTop: 4 }}>{issue.message || "Needs review."}</div>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <div style={{ fontSize: 13, color: "#0a6b2f", fontWeight: 600 }}>No client-facing issues found.</div>
                          )}
                        </div>

                        <div className="card" style={{ padding: 12, display: "grid", gap: 8 }}>
                          <div>
                            <b>Run Summary</b>
                            <div style={{ fontSize: 12, opacity: 0.75, marginTop: 4 }}>
                              What the system generated during this QC run.
                            </div>
                          </div>
                          <div style={{ display: "grid", gap: 8 }}>
                            {clientFacing.runSummary.map(([label, value]) => (
                              <div key={label} style={{ display: "grid", gap: 2 }}>
                                <div style={{ fontSize: 11, opacity: 0.65 }}>{label}</div>
                                <div style={{ fontSize: 13, fontWeight: 600 }}>{value}</div>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>

                      {hasQctoolsOutput ? (
                        <div className="card" style={{ padding: 12, display: "grid", gap: 8 }}>
                          <div>
                            <b>QCTools Output</b>
                            <div style={{ fontSize: 12, opacity: 0.75, marginTop: 4 }}>
                              The native QCTools desktop window cannot be opened inside the browser. Use this web view instead.
                            </div>
                          </div>
                          <div className="row" style={{ flexWrap: "wrap", gap: 8 }}>
                            {qctoolsPreview ? (
                              <button
                                type="button"
                                onClick={() => {
                                  setQcModal((prev) =>
                                    prev ? { ...prev, toolLabel: "QCTools Preview", toolKind: "image", toolError: undefined, showQctoolsDetails: false } : prev,
                                  );
                                  previewQcArtifact(qcModal.creativeId, qctoolsPreview, "QCTools Preview");
                                }}
                              >
                                Preview
                              </button>
                            ) : null}
                            <button
                              type="button"
                              onClick={() => {
                                setQcModal((prev) =>
                                  prev
                                    ? {
                                        ...prev,
                                        toolUrl: undefined,
                                        toolLabel: undefined,
                                        toolKind: undefined,
                                        toolError: undefined,
                                        toolFilmstripFrames: undefined,
                                        toolFilmstripIndex: undefined,
                                        showQctoolsDetails: !prev.showQctoolsDetails,
                                      }
                                    : prev,
                                );
                              }}
                            >
                              {qcModal.showQctoolsDetails ? "Hide QCTools Details" : "Show QCTools Details"}
                            </button>
                          </div>
                        </div>
                      ) : null}

                      {qcModal.showQctoolsDetails ? (() => {
                        const qctoolsDetails = buildQctoolsDetails(d);
                        return (
                          <div className="card" style={{ padding: 12, display: "grid", gap: 10 }}>
                            <div>
                              <b>QCTools Details</b>
                              <div style={{ fontSize: 12, opacity: 0.75, marginTop: 4 }}>
                                Web-friendly summary of the generated QCTools run.
                              </div>
                            </div>
                            <div style={{ display: "grid", gap: 12, gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))" }}>
                              <div style={{ display: "grid", gap: 8 }}>
                                {qctoolsDetails.summary.map(([label, value]) => (
                                  <div key={label} style={{ display: "grid", gap: 2 }}>
                                    <div style={{ fontSize: 11, opacity: 0.65 }}>{label}</div>
                                    <div style={{ fontSize: 13, fontWeight: 600 }}>{value}</div>
                                  </div>
                                ))}
                              </div>
                              <div style={{ display: "grid", gap: 8 }}>
                                <div style={{ fontSize: 11, opacity: 0.65 }}>Processing stages</div>
                                {qctoolsDetails.stages.length ? qctoolsDetails.stages.map(([label, value]) => (
                                  <div key={label} style={{ display: "flex", justifyContent: "space-between", gap: 8, border: "1px solid rgba(15,23,42,0.08)", borderRadius: 10, padding: "8px 10px" }}>
                                    <span style={{ fontSize: 12 }}>{label}</span>
                                    <span style={{ fontSize: 12, fontWeight: 700 }}>{value}</span>
                                  </div>
                                )) : (
                                  <div style={{ fontSize: 13, opacity: 0.8 }}>Detailed stage information is not available for this run yet.</div>
                                )}
                              </div>
                            </div>
                          </div>
                        );
                      })() : null}

                      <div className="card" style={{ padding: 12, display: "grid", gap: 8 }}>
                        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
                          <div>
                            <b>Visual Outputs</b>
                            <div style={{ fontSize: 12, opacity: 0.75, marginTop: 4 }}>
                              Generate waveform, scopes, audio graph and filmstrip separately from fast auto-QC.
                            </div>
                          </div>
                          <button
                            type="button"
                            onClick={() => generateVisualsForModal(qcModal.creativeId)}
                            disabled={qcModal.visualsLoading}
                          >
                            {qcModal.visualsLoading ? "Generating…" : hasVisuals ? "Regenerate Visuals" : "Generate Visuals"}
                          </button>
                        </div>

                        {qcModal.visualsError ? (
                          <div style={{ fontSize: 12, color: "#a10000" }}>{qcModal.visualsError}</div>
                        ) : null}

                        {hasVisuals ? (
                          <div className="row" style={{ flexWrap: "wrap", gap: 8 }}>
                            {visualButtons.map((b) => (
                              <button
                                key={b.key}
                                type="button"
                                onClick={() => {
                                  setQcModal((prev) =>
                                    prev ? { ...prev, toolLabel: b.label, toolKind: b.kind, toolError: undefined, showQctoolsDetails: false } : prev,
                                  );
                                  previewQcArtifact(qcModal.creativeId, b.path, b.label);
                                }}
                              >
                                {b.label}
                              </button>
                            ))}

                            {filmFrames.length ? (
                              <button
                                type="button"
                                onClick={() => {
                                  setQcModal((prev) =>
                                    prev ? { ...prev, toolLabel: "Filmstrip", toolKind: "image", toolError: undefined, showQctoolsDetails: false } : prev,
                                  );
                                  openFilmstrip(qcModal.creativeId, filmFrames);
                                }}
                              >
                                Filmstrip
                              </button>
                            ) : null}
                          </div>
                        ) : (
                          <div style={{ fontSize: 12, opacity: 0.75 }}>No visuals generated yet.</div>
                        )}
                      </div>

                      {hasTechnical ? (
                        <details style={{ border: "1px solid rgba(15,23,42,0.08)", borderRadius: 14, padding: 12, background: "rgba(15,23,42,0.02)" }}>
                          <summary style={{ cursor: "pointer", fontWeight: 700, listStyle: "none", display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12 }}>
                            <span>Advanced Technical Details</span>
                            <span style={{ fontSize: 12, opacity: 0.7 }}>{technicalButtons.length} item{technicalButtons.length === 1 ? "" : "s"}</span>
                          </summary>
                          <div style={{ fontSize: 12, opacity: 0.72, marginTop: 8 }}>
                            These are detailed technical files for engineering or support teams.
                          </div>
                          <div className="row" style={{ flexWrap: "wrap", gap: 8, marginTop: 10 }}>
                            {technicalButtons.map((b) => (
                              <button
                                key={b.key}
                                type="button"
                                onClick={() => {
                                  setQcModal((prev) =>
                                    prev ? { ...prev, toolLabel: b.label, toolKind: b.kind, toolError: undefined, showQctoolsDetails: false } : prev,
                                  );
                                  previewQcArtifact(qcModal.creativeId, b.path, b.label);
                                }}
                              >
                                {b.label}
                              </button>
                            ))}
                          </div>
                        </details>
                      ) : null}

                      {qcModal.toolLoading ? (
                        <div className="card" style={{ marginTop: 2, padding: 10, background: "rgba(0,0,0,0.02)" }}>
                          <div style={{ fontSize: 13, opacity: 0.8 }}>Loading {qcModal.toolLabel || "output"}…</div>
                        </div>
                      ) : qcModal.toolError ? (
                        <div className="card" style={{ marginTop: 2, padding: 10, border: "1px solid #ffb3b3" }}>
                          <div style={{ fontSize: 13, color: "#a10000" }}>{qcModal.toolError}</div>
                        </div>
                      ) : qcModal.toolUrl ? (
                        <div style={{ marginTop: 2, display: "grid", gap: 8 }}>
                          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 8 }}>
                            <b style={{ fontSize: 13 }}>{qcModal.toolLabel || "Output"}</b>
                            <button
                              type="button"
                              onClick={() =>
                                setQcModal((prev) =>
                                  prev
                                    ? {
                                        ...prev,
                                        toolUrl: undefined,
                                        toolLabel: undefined,
                                        toolKind: undefined,
                                        toolError: undefined,
                                        toolFilmstripFrames: undefined,
                                        toolFilmstripIndex: undefined,
                                        showQctoolsDetails: false,
                                      }
                                    : prev,
                                )
                              }
                            >
                              Clear
                            </button>
                          </div>

                          {qcModal.toolKind === "video" ? (
                            <video controls src={qcModal.toolUrl} style={{ width: "100%", borderRadius: 12, background: "#000" }} />
                          ) : qcModal.toolKind === "text" ? (
                            <div style={{ display: "grid", gap: 6 }}>
                              <a href={qcModal.toolUrl} target="_blank" rel="noreferrer" style={{ fontSize: 13 }}>
                                Open {qcModal.toolLabel || "file"}
                              </a>
                              <div style={{ fontSize: 12, opacity: 0.75 }}>
                                (Opens in a new tab — best for log/JSON artifacts stored on Blob with SAS URLs.)
                              </div>
                            </div>
                          ) : (
                            <div style={{ display: "grid", gap: 8 }}>
                              {(() => {
                                const frames = qcModal.toolFilmstripFrames || [];
                                const idx = qcModal.toolFilmstripIndex ?? 0;
                                const isFilmstrip = qcModal.toolLabel === "Filmstrip" && frames.length > 1;
                                if (!isFilmstrip) return null;
                                return (
                                  <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
                                    <button
                                      type="button"
                                      onClick={() => setFilmstripFrame(qcModal.creativeId, frames, idx - 1)}
                                      disabled={idx <= 0}
                                    >
                                      Prev
                                    </button>
                                    <button
                                      type="button"
                                      onClick={() => setFilmstripFrame(qcModal.creativeId, frames, idx + 1)}
                                      disabled={idx >= frames.length - 1}
                                    >
                                      Next
                                    </button>
                                    <div style={{ fontSize: 12, opacity: 0.75 }}>
                                      Frame {idx + 1} / {frames.length}
                                    </div>
                                    <input
                                      type="range"
                                      min={1}
                                      max={frames.length}
                                      value={Math.min(frames.length, Math.max(1, idx + 1))}
                                      onChange={(e) =>
                                        setFilmstripFrame(
                                          qcModal.creativeId,
                                          frames,
                                          Number((e.target as HTMLInputElement).value) - 1,
                                        )
                                      }
                                      style={{ flex: "1 1 200px" }}
                                    />
                                  </div>
                                );
                              })()}
                              <img
                                src={qcModal.toolUrl}
                                alt={qcModal.toolLabel || "QC tool output"}
                                style={{ maxWidth: "100%", height: "auto", borderRadius: 10 }}
                              />
                            </div>
                          )}
                        </div>
                      ) : null}
                    </div>
                  );
                })()}
              </div>                </>
              ) : null}

            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
