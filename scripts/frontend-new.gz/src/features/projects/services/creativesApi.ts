import { api, apiDownload } from "../../../lib/api";

export type CreativeAsset = {
  id: string;
  type: "SOURCE" | "PROXY" | "OUTPUT" | string;
  filename?: string | null;
  mimeType?: string | null;
  sizeBytes?: string | number | null;
  uploadStatus?: string | null;
  bytesTotal?: string | number | null;
  bytesReceived?: string | number | null;
  speedBps?: number | null;
  uploadStartedAt?: string | null;
  uploadEndedAt?: string | null;
  error?: string | null;
};

export type CreativeLine = {
  id: string;
  projectId: string;
  valid: string | null;
  caption: string | null;
  format: string | null;
  languages: string[];
  duration: string | null;
  remarks: string | null;
  countryId?: string | null;
  qcStatus?: string | null;
  qcNotes?: string | null;
  qcFailureReasons?: string[];
  qcReport?: any;
  primaryDamItemId?: string | null;
  uniqueEditKey?: string | null;
  assets: CreativeAsset[];
  createdAt?: string;
  updatedAt?: string;
};

export type CreativesMeta = {
  label: string;
  strategy: "FILENAME_DRIVEN" | "SPEC_DRIVEN" | string;
  defaults: {
    stereoRequired: boolean | null;
    defaultLanguages: string[];
  };
  raw?: any;
};

export async function listCreatives(projectId: string) {
  return api<CreativeLine[]>(`/projects/${projectId}/creatives`);
}

export async function creativesMeta(projectId: string, countryId?: string | null) {
  const qs = countryId ? `?countryId=${encodeURIComponent(countryId)}` : "";
  return api<CreativesMeta>(`/projects/${projectId}/creatives/meta${qs}`);
}

export async function createCreative(projectId: string, payload: any) {
  return api<CreativeLine>(`/projects/${projectId}/creatives`, { method: "POST", body: JSON.stringify(payload) });
}

export async function updateCreative(creativeId: string, payload: any) {
  return api<CreativeLine>(`/creatives/${creativeId}`, { method: "PATCH", body: JSON.stringify(payload) });
}

export async function deleteCreative(creativeId: string) {
  return api<{ ok: boolean }>(`/creatives/${creativeId}`, { method: "DELETE" });
}

export async function bulkImportCreatives(projectId: string, rows: any[]) {
  return api<{ ok: boolean; results: any[] }>(`/projects/${projectId}/creatives/import`, {
    method: "POST",
    body: JSON.stringify({ rows }),
  });
}

export async function downloadProxy(creativeId: string) {
  return apiDownload(`/creatives/${creativeId}/proxy`, {}, `proxy-${creativeId}`);
}

export async function applyDam(creativeId: string, damItemId: string) {
  return api<CreativeLine>(`/creatives/${creativeId}/apply-dam/${damItemId}`, { method: "POST" });
}
