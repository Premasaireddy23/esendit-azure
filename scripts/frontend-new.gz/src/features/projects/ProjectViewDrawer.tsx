import { useEffect, useMemo, useState } from "react";
import { api } from "../../lib/api";

type Named = { id?: string; name?: string };

type ProjectDetail = {
  id: string;
  projectNumber?: string;
  name?: string;
  status?: "OPEN" | "CLOSED";
  senderAccountMatches?: Array<{ id?: string; name?: string; matchSources?: string[] }>;
  receiverAccountsUsed?: Array<{ id?: string; name?: string; receiverCategory?: string | null }>;

  advertiserGroup?: Named | null;
  advertiser?: Named | null;
  brand?: Named | null;
  productCategory?: Named | null;
  senderAccount?: Named | null;
  billableParty?: Named | null;

  mediaAgency?: Named | null;
  mediaAgencyTeam?: Named | null;
  creativeAgency?: Named | null;
  creativeAgencyTeam?: Named | null;
  productionHouse?: Named | null;
  productionHouseTeam?: Named | null;
  postHouse?: Named | null;
  postHouseTeam?: Named | null;
  audioAgency?: Named | null;
  audioAgencyTeam?: Named | null;

  uploaderAgency?: Named | null;
  uploaderAgencyTeam?: Named | null;
  remarks?: string | null;

  createdAt?: string;
  updatedAt?: string;
};

type FieldDef = {
  key: string;
  label: string;
  get: (d: ProjectDetail) => string;
};

function safe(v: any) {
  return v == null || v === "" ? "—" : String(v);
}

const PREF_KEY = "project:view:fields";

export function ProjectViewDrawer(props: {
  open: boolean;
  projectId: string | null;
  onClose: () => void;
  seed?: any;
}) {
  const { open, projectId, onClose, seed } = props;

  const seedDetail: ProjectDetail | null = useMemo(() => {
    if (!seed) return null;
    return {
      id: seed.id,
      projectNumber: seed.projectNumber,
      name: seed.name,
      status: seed.status,
      advertiserGroup: seed.advertiserGroup,
      advertiser: seed.advertiser,
      brand: seed.brand,
      productCategory: seed.productCategory,
      billableParty: seed.billableParty,
    };
  }, [seed]);

  const [data, setData] = useState<ProjectDetail | null>(seedDetail);
  const [err, setErr] = useState("");
  const [loading, setLoading] = useState(false);

  const [order, setOrder] = useState<string[] | null>(null);
  const [prefOpen, setPrefOpen] = useState(false);
  const [prefSaving, setPrefSaving] = useState(false);
  const [prefErr, setPrefErr] = useState("");

  const defaultFields: FieldDef[] = useMemo(
    () => [
      { key: "projectNumber", label: "Project Number", get: (d) => safe(d.projectNumber) },
      { key: "projectName", label: "Project Name", get: (d) => safe(d.name) },

      { key: "advertiserGroup", label: "Advertiser Group", get: (d) => safe(d.advertiserGroup?.name) },
      { key: "advertiser", label: "Advertiser", get: (d) => safe(d.advertiser?.name) },
      { key: "brand", label: "Brand", get: (d) => safe(d.brand?.name) },
      { key: "productCategory", label: "Sector/Product Category", get: (d) => safe(d.productCategory?.name) },
      { key: "senderAccount", label: "Sender Account", get: (d) => safe(d.senderAccount?.name) },
      { key: "billableParty", label: "Billable Party", get: (d) => safe(d.billableParty?.name) },
      {
        key: "senderAccounts",
        label: "Sender Account Match",
        get: (d) =>
          Array.isArray(d.senderAccountMatches) && d.senderAccountMatches.length
            ? d.senderAccountMatches
                .map((item) => {
                  const name = String(item?.name || "").trim();
                  const sources = Array.isArray(item?.matchSources) ? item.matchSources.filter(Boolean).join(", ") : "";
                  return sources ? `${name} (${sources})` : name;
                })
                .filter(Boolean)
                .join(" • ")
            : "—",
      },
      {
        key: "receiverAccounts",
        label: "Receivers Used",
        get: (d) =>
          Array.isArray(d.receiverAccountsUsed) && d.receiverAccountsUsed.length
            ? d.receiverAccountsUsed
                .map((item) => {
                  const name = String(item?.name || "").trim();
                  const category = String(item?.receiverCategory || "").trim();
                  return category ? `${name} (${category})` : name;
                })
                .filter(Boolean)
                .join(" • ")
            : "—",
      },

      { key: "mediaAgency", label: "Media Agency", get: (d) => safe(d.mediaAgency?.name) },
      { key: "mediaAgencyTeam", label: "Media Agency Team", get: (d) => safe(d.mediaAgencyTeam?.name) },

      { key: "creativeAgency", label: "Creative Agency", get: (d) => safe(d.creativeAgency?.name) },
      { key: "creativeAgencyTeam", label: "Creative Agency Team", get: (d) => safe(d.creativeAgencyTeam?.name) },

      { key: "productionHouse", label: "Production House", get: (d) => safe(d.productionHouse?.name) },
      { key: "productionHouseTeam", label: "Production House Team", get: (d) => safe(d.productionHouseTeam?.name) },

      { key: "postHouse", label: "Post House", get: (d) => safe(d.postHouse?.name) },
      { key: "postHouseTeam", label: "Post House Team", get: (d) => safe(d.postHouseTeam?.name) },

      { key: "audioAgency", label: "Audio Agency", get: (d) => safe(d.audioAgency?.name) },
      { key: "audioAgencyTeam", label: "Audio Agency Team", get: (d) => safe(d.audioAgencyTeam?.name) },

      { key: "uploaderAgency", label: "Uploader Agency", get: (d) => safe(d.uploaderAgency?.name) },
      { key: "uploaderAgencyTeam", label: "Uploader Agency Team", get: (d) => safe(d.uploaderAgencyTeam?.name) },
      { key: "remarks", label: "Remarks", get: (d) => safe(d.remarks) },
    ],
    []
  );

  const fieldsByKey = useMemo(() => {
    const m = new Map<string, FieldDef>();
    defaultFields.forEach((f) => m.set(f.key, f));
    return m;
  }, [defaultFields]);

  const orderedFields = useMemo(() => {
    if (!order?.length) return defaultFields;
    const out: FieldDef[] = [];
    for (const k of order) {
      const f = fieldsByKey.get(k);
      if (f) out.push(f);
    }
    // include any newly-added fields that are not in pref yet
    for (const f of defaultFields) {
      if (!order.includes(f.key)) out.push(f);
    }
    return out;
  }, [order, defaultFields, fieldsByKey]);

  async function loadPref() {
    try {
      const res: any = await api(`/auth/me/preferences/${PREF_KEY}`);
      const payload = res?.payload ?? res?.data ?? res;
      if (payload?.order && Array.isArray(payload.order)) setOrder(payload.order);
      else setOrder(null);
    } catch {
      setOrder(null);
    }
  }

  useEffect(() => {
    if (!open) return;
    loadPref();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open]);

  useEffect(() => {
    if (!open) return;
    if (!projectId) return;

    // Pre-fill with seed if we have it
    setData(seedDetail);
    setErr("");
    setLoading(true);

    api<ProjectDetail>(`/projects/${projectId}`)
      .then((r) => setData(r))
      .catch((e: any) => {
        // Backend might not have this endpoint yet; keep seed visible.
        setErr(e?.message || "Failed to load project details");
      })
      .finally(() => setLoading(false));

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, projectId]);

  useEffect(() => {
    const onEsc = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    if (open) document.addEventListener("keydown", onEsc);
    return () => document.removeEventListener("keydown", onEsc);
  }, [open, onClose]);

  if (!open) return null;

  const d = data || ({ id: projectId || "" } as ProjectDetail);

  return (
    <div className="drawerOverlay" onMouseDown={onClose}>
      <div className="drawer" onMouseDown={(e) => e.stopPropagation()} role="dialog" aria-modal="true">
        <div className="drawerHeader">
          <div className="drawerTitle">Project View</div>
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            <button className="drawerClose" type="button" onClick={() => setPrefOpen(true)} title="Reorder fields">
              ⚙
            </button>
            <button className="drawerClose" type="button" onClick={onClose} aria-label="Close">
              ✕
            </button>
          </div>
        </div>

        <div className="drawerBody">
          {loading && <div style={{ opacity: 0.7, marginBottom: 10 }}>Loading...</div>}
          {err && <div className="drawerError">{err}</div>}

          <div className="kvGrid">
            {orderedFields.map((f) => (
              <div key={f.key}>
                <div className="kvLabel">{f.label}</div>
                <div className="kvValue">{f.get(d)}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {prefOpen && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(0,0,0,0.35)",
            display: "grid",
            placeItems: "center",
            zIndex: 9999,
          }}
          onMouseDown={() => setPrefOpen(false)}
        >
          <div
            className="card"
            style={{ width: 560, maxWidth: "92vw", padding: 12, background: "white" }}
            onMouseDown={(e) => e.stopPropagation()}
          >
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <div style={{ fontWeight: 800 }}>Reorder fields</div>
              <button onClick={() => setPrefOpen(false)}>Close</button>
            </div>

            <div style={{ fontSize: 12, opacity: 0.7, marginTop: 6 }}>
              Move up/down and Save. This preference is per-user.
            </div>

            {prefErr ? (
              <div className="card" style={{ marginTop: 10, border: "1px solid #ffb3b3", color: "#a10000" }}>
                {prefErr}
              </div>
            ) : null}

            <FieldOrderEditor
              fields={defaultFields}
              order={order || defaultFields.map((f) => f.key)}
              onChange={(next) => setOrder(next)}
            />

            <div style={{ display: "flex", justifyContent: "space-between", marginTop: 12 }}>
              <button
                onClick={() => {
                  setOrder(null);
                  setPrefErr("");
                }}
                disabled={prefSaving}
              >
                Reset
              </button>

              <div style={{ display: "flex", gap: 8 }}>
                <button onClick={() => setPrefOpen(false)} disabled={prefSaving}>
                  Cancel
                </button>
                <button
                  onClick={async () => {
                    setPrefSaving(true);
                    setPrefErr("");
                    try {
                      const nextOrder = order || defaultFields.map((f) => f.key);
                      await api(`/auth/me/preferences/${PREF_KEY}`, {
                        method: "PUT",
                        body: JSON.stringify({ payload: { order: nextOrder } }),
                      });
                      setPrefOpen(false);
                    } catch (e: any) {
                      setPrefErr(e?.message || "Failed to save");
                    } finally {
                      setPrefSaving(false);
                    }
                  }}
                  disabled={prefSaving}
                >
                  {prefSaving ? "Saving..." : "Save"}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function FieldOrderEditor(props: {
  fields: FieldDef[];
  order: string[];
  onChange: (next: string[]) => void;
}) {
  const { fields, order, onChange } = props;
  const byKey = useMemo(() => new Map(fields.map((f) => [f.key, f])), [fields]);

  function move(from: number, to: number) {
    if (to < 0 || to >= order.length) return;
    const next = [...order];
    const [it] = next.splice(from, 1);
    next.splice(to, 0, it);
    onChange(next);
  }

  return (
    <div style={{ marginTop: 10, maxHeight: 420, overflow: "auto", border: "1px solid #eee", borderRadius: 10 }}>
      {order.map((k, idx) => {
        const f = byKey.get(k);
        if (!f) return null;
        return (
          <div key={k} style={{ display: "flex", alignItems: "center", gap: 8, padding: 10, borderTop: idx ? "1px solid #eee" : "none" }}>
            <div style={{ flex: 1 }}>
              <div style={{ fontWeight: 700 }}>{f.label}</div>
              <div style={{ fontSize: 11, opacity: 0.6 }}>{f.key}</div>
            </div>
            <div style={{ display: "flex", gap: 6 }}>
              <button onClick={() => move(idx, idx - 1)} disabled={idx === 0} title="Move up">
                ↑
              </button>
              <button onClick={() => move(idx, idx + 1)} disabled={idx === order.length - 1} title="Move down">
                ↓
              </button>
            </div>
          </div>
        );
      })}
    </div>
  );
}
