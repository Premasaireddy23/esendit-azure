export type Workflow = {
  steps: Record<string, { ok: boolean }>;
  actions: {
    canCommit: boolean;
    commitReasons: { code: string; message: string }[];
    canSend: boolean;
    sendReasons: { code: string; message: string }[];
  };
  activePlan: null | { id: string; version: number; unsentLines: number };
};

export type OutletCtx = {
  wf: Workflow | null;
  access?: ProjectAccess | null;
  reload: () => Promise<void>;
};


export type ProjectAccess = {
  scope: "GLOBAL" | "PROJECT" | "NONE";
  roleLabels: string[];
  receiverOnly?: boolean;
  receiverAccountIds?: string[];
  stakeholderTypes?: string[];
  stakeholderActions?: Record<string, string[]>;
  usesSpecificStakeholderPermissions?: boolean;
  canUpdateHouseId?: boolean;
  canViewProject: boolean;
  canViewCreatives: boolean;
  canViewDam: boolean;
  canStreamDam: boolean;
  canViewTracking: boolean;
  canUploadCreatives: boolean;
  canEditProject: boolean;
  canPlanner: boolean;
  canCommit: boolean;
  canApprove: boolean;
  canSend: boolean;
  canCloseProject: boolean;
  canReopenProject: boolean;
  canDeleteProject: boolean;
};
