import { Outlet, useNavigate, useParams } from "react-router-dom";
import { HomeRefreshBar } from "../../ui/HomeRefreshBar";
import { useEffect, useMemo, useState } from "react";
import { api } from "../../lib/api";
import { ProjectStepper } from "./ProjectStepper";
import type { OutletCtx, ProjectAccess, Workflow } from "./types";

type ProjectHeader = {
  id: string;
  name: string;
  projectNumber?: string;
};


export function ProjectLayout() {
  const { id = "" } = useParams();
  const nav = useNavigate();
  const [wf, setWf] = useState<Workflow | null>(null);
  const [project, setProject] = useState<ProjectHeader | null>(null);
  const [access, setAccess] = useState<ProjectAccess | null>(null);
  const [err, setErr] = useState<string>("");

  async function load() {
    setErr("");
    try {
      const [wfRes, projRes, accessRes] = await Promise.allSettled([
        api<Workflow>(`/projects/${id}/workflow`),
        api<ProjectHeader>(`/projects/${id}`),
        api<ProjectAccess>(`/projects/${id}/access`),
      ]);

      if (projRes.status === "fulfilled") {
        setProject(projRes.value);
      } else {
        // keep existing header fallback (UUID)
        setProject(null);
      }

      setAccess(accessRes.status === "fulfilled" ? accessRes.value : null);

      if (wfRes.status === "fulfilled") {
        setWf(wfRes.value);
      } else {
        setWf(null);
        throw wfRes.reason;
      }
    } catch (e: any) {
      setErr(e?.message || "Failed to load workflow");
    }
  }

  useEffect(() => {
    load();
  }, [id]);

  const ctx: OutletCtx = { wf, access, reload: load };

  const plan = wf?.activePlan;
  const pending = plan?.unsentLines ?? 0;

  const planBadge = useMemo(() => {
    if (!plan) return null;

    const title =
      "Plan is the latest committed delivery plan version for this project. Unsent lines are planned deliveries not yet queued for sending.";

    const cls = pending > 0 ? "badge badge--warn" : "badge badge--ok";
    const text =
      pending > 0
        ? `Plan v${plan.version} • ${pending} pending`
        : `Plan v${plan.version}`;

    return (
      <span className={cls} title={title}>
        {text}
      </span>
    );
  }, [plan, pending]);

  const projectName = project?.name?.trim();
  const canOpenPlanner = access?.scope === "PROJECT" ? access.canPlanner : true;


  return (
    <div style={{ padding: 16, display: "grid", gridTemplateColumns: "minmax(0, 1fr)", gap: 12, width: "100%", maxWidth: "100%", minWidth: 0 }}>
      <HomeRefreshBar title="Project" onRefresh={() => window.location.reload()} flat />

      <div style={{ display: "grid", gap: 6, minWidth: 0 }}>
        <div style={{ fontSize: 12, opacity: 0.6 }}>Project</div>

        {/* Title row: keep this clean */}
        <div
          className="row"
          style={{ gap: 10, alignItems: "baseline", flexWrap: "wrap", minWidth: 0 }}
        >
          <div style={{ fontWeight: 900, fontSize: 18, minWidth: 0 }}>
            {projectName || id}
          </div>
          {planBadge}
        </div>


      </div>

      {err && (
        <div className="card" style={{ borderColor: "#f5a", background: "#fff5fa" }}>
          {err}
        </div>
      )}

      <div style={{ minWidth: 0, maxWidth: "100%" }}>
        <ProjectStepper projectId={id} steps={wf?.steps || ({} as any)} access={access} />
      </div>

      {/* Only show the plan banner when there is something actionable */}
      {plan && pending > 0 && canOpenPlanner && (
        <div style={{ minWidth: 0, maxWidth: "100%" }}>
          <div
          className="card card--soft"
          style={{
            borderColor: "#fde68a",
            background: "#fffbeb",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            gap: 12,
          }}
        >
          <div style={{ display: "grid", gap: 4 }}>
            <div style={{ fontWeight: 800 }}>Delivery plan needs sending</div>
            <div style={{ fontSize: 13, opacity: 0.9 }}>
              Plan v{plan.version} has <b>{pending}</b> unsent line
              {pending === 1 ? "" : "s"}. Unsent lines are planned deliveries not yet queued for send.
            </div>
            <div style={{ fontSize: 12, opacity: 0.75 }}>
              Go to <b>Planner + Commit</b> to review and send them.
            </div>
          </div>

          <button
            className="btn btn--primary"
            type="button"
            onClick={() => nav(`/projects/${id}/planner`)}
          >
            Open Planner + Commit
          </button>
          </div>
        </div>
      )}

      <div style={{ minWidth: 0, maxWidth: "100%" }}>
        <Outlet context={ctx} />
      </div>
    </div>
  );
}
