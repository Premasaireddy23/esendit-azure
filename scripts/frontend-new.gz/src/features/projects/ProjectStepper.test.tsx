import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import { ProjectStepper } from "./ProjectStepper";

describe("ProjectStepper", () => {
  it("renders all 5 steps", () => {
    render(
      <MemoryRouter>
        <ProjectStepper
          projectId="p1"
          steps={{
            creatives: { ok: false },
            qc: { ok: false },
            approvals: { ok: false },
            planner: { ok: false },
            commit: { ok: false },
            send: { ok: false },
          }}
        />
      </MemoryRouter>,
    );

    expect(screen.getByText(/1\) Creatives/i)).toBeInTheDocument();
    expect(screen.getByText(/2\) QC/i)).toBeInTheDocument();
    expect(screen.getByText(/3\) Approvals/i)).toBeInTheDocument();
    expect(screen.getByText(/4\) Planner \+ Commit/i)).toBeInTheDocument();
    expect(screen.getByText(/5\) Send \+ Tracking/i)).toBeInTheDocument();
  });
});
