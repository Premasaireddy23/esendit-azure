import { api } from "../../../lib/api";
import type { ApprovalTemplate, ApprovalTracker } from "./approvals.types";

export async function listApprovalTemplates() {
  return api<ApprovalTemplate[]>("/approval-templates");
}

export async function getApprovalsTracker(projectId: string) {
  return api<ApprovalTracker>(`/projects/${projectId}/approvals/tracker`);
}

export async function patchProjectApprovalsConfig(
  projectId: string,
  body: { approvalsEnabled?: boolean; approvalsPhase?: "PRE" | "POST"; approvalTemplateId?: string | null },
) {
  return api<{ ok: true; project: any }>(`/projects/${projectId}/approvals/config`, {
    method: "PATCH",
    body: JSON.stringify(body),
  });
}

export async function approveStep(projectId: string, requestId: string, stepId: string, notes?: string) {
  return api<any>(`/projects/${projectId}/approvals/requests/${requestId}/steps/${stepId}/approve`, {
    method: "POST",
    body: JSON.stringify({ notes }),
  });
}

export async function rejectStep(projectId: string, requestId: string, stepId: string, notes?: string) {
  return api<any>(`/projects/${projectId}/approvals/requests/${requestId}/steps/${stepId}/reject`, {
    method: "POST",
    body: JSON.stringify({ notes }),
  });
}

export async function resetRequest(projectId: string, requestId: string) {
  return api<any>(`/projects/${projectId}/approvals/requests/${requestId}/reset`, {
    method: "POST",
  });
}
