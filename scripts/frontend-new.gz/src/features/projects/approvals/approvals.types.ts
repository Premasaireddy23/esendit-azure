export type ApprovalMode = "SEQUENTIAL" | "PARALLEL";

export type ApprovalTemplate = {
  id: string;
  accountId?: string;
  name: string;
  mode: ApprovalMode;
  steps: any;
  isActive: boolean;
};

export type ApprovalStep = {
  id: string;
  key: string;
  label: string;
  order: number;
  required: boolean;
  approverEmails: string[];
  status: "PENDING" | "APPROVED" | "REJECTED";
  decidedAt?: string | null;
  notes?: string | null;
};

export type ApprovalRequest = {
  id: string;
  creativeId: string;
  projectId: string;
  status: "PENDING" | "IN_PROGRESS" | "APPROVED" | "REJECTED";
  template?: ApprovalTemplate;
  steps: ApprovalStep[];
};

export type ApprovalTrackerRow = {
  creative: {
    id: string;
    name: string;
    qcStatus: string;
    approvals: string;
    updatedAt: string;
    valid?: string | null;
    caption?: string | null;
    format?: string | null;
    audio?: string | null;
    languages?: string[] | string | null;
    duration?: string | null;
    sourceFilename?: string | null;
    filename?: string | null;
    uploadedByUser?: { id: string; email: string; displayName?: string | null } | null;
    uploader?: { id: string; email: string; displayName?: string | null } | null;

    qcNotes?: string | null;
    qcFailureReasons?: string[];
    qcReport?: any;
    autoQcStartedAt?: string | null;
    autoQcEndedAt?: string | null;

    sourceMimeType?: string | null;
    sourceSizeBytes?: string | number | null;
  };
  request: ApprovalRequest | null;
};

export type ApprovalTracker = {
  enabled: boolean;
  projectId: string;
  phase?: "PRE" | "POST" | string;
  project?: {
    projectNumber?: string;
    name?: string;
    advertiserGroup?: { id: string; name: string } | null;
    advertiser?: { id: string; name: string } | null;
    brand?: { id: string; name: string } | null;
    productCategory?: { id: string; name: string } | null;
    billableParty?: { id: string; name: string } | null;
    mediaAgency?: { id: string; name: string } | null;
    mediaAgencyTeam?: { id: string; name: string } | null;
    creativeAgency?: { id: string; name: string } | null;
    creativeAgencyTeam?: { id: string; name: string } | null;
    productionHouse?: { id: string; name: string } | null;
    productionHouseTeam?: { id: string; name: string } | null;
    postHouse?: { id: string; name: string } | null;
    postHouseTeam?: { id: string; name: string } | null;
    audioAgency?: { id: string; name: string } | null;
    audioAgencyTeam?: { id: string; name: string } | null;
  };
  template: ApprovalTemplate | null;
  templateSteps: Array<{ key: string; label: string; order: number; required: boolean; approverEmails: string[] }>;
  rows: ApprovalTrackerRow[];
};
