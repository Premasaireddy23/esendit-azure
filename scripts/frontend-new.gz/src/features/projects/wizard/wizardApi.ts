import { api, apiUrl, clearToken, getToken } from "../../../lib/api";
import type { CreateWizardProjectPayload, WizardMeta, CreatedProjectResponse } from "./wizard.types";

export function fetchWizardMeta() {
  return api<WizardMeta>("/projects/wizard/meta");
}

export function createWizardProject(payload: CreateWizardProjectPayload) {
  return api<CreatedProjectResponse>("/projects/wizard", {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

export function validateWizardProjectName(name: string) {
  const qs = new URLSearchParams({ name: String(name ?? "").trim() });
  return api<{ available: boolean; message?: string }>(`/projects/wizard/validate-name?${qs.toString()}`);
}

function safeParseJson(text: string) {
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}

function normalizeProjectCodePayload(payload: any): string {
  if (payload == null) return "";
  if (typeof payload === "string") return payload.trim();
  if (typeof payload === "number") return String(payload);
  if (Array.isArray(payload)) {
    for (const item of payload) {
      const nested = normalizeProjectCodePayload(item);
      if (nested) return nested;
    }
    return "";
  }
  if (typeof payload === "object") {
    const candidates = [
      payload.projectCode,
      payload.projectNumber,
      payload.nextProjectCode,
      payload.nextProjectNumber,
      payload.code,
      payload.nextCode,
      payload.value,
      payload.data,
      payload.result,
    ];
    for (const value of candidates) {
      const nested = normalizeProjectCodePayload(value);
      if (nested) return nested;
    }
  }
  return "";
}

async function fetchProjectCodeFrom(path: string): Promise<{ projectCode: string }> {
  const token = getToken();
  const res = await fetch(apiUrl(path), {
    headers: token ? { Authorization: `Bearer ${token}` } : undefined,
  });

  const text = await res.text();
  const data = text ? safeParseJson(text) : null;

  if (!res.ok) {
    const errMsg = (data && (data.message || data.error)) || text || `${res.status} ${res.statusText}`;
    const err: any = Object.assign(new Error(errMsg), { status: res.status, data: data || text || null });
    if (res.status === 401) clearToken();
    throw err;
  }

  const projectCode = normalizeProjectCodePayload(data ?? text);
  if (!projectCode) {
    throw new Error("Project number preview response was empty");
  }

  return { projectCode };
}

export async function fetchNextProjectCode() {
  try {
    return await fetchProjectCodeFrom("/projects/wizard/next-code");
  } catch {
    return fetchProjectCodeFrom("/projects/next-code");
  }
}


export async function createInlineAdvertiserGroup(input: { name: string }) {
  return api<{ id: string; name: string }>(`/projects/wizard/inline/advertiser-groups`, {
    method: "POST",
    body: JSON.stringify(input),
  });
}

export async function createInlineAdvertiser(input: { name: string; advertiserGroupId?: string }) {
  return api<{ id: string; name: string; advertiserGroupId?: string | null }>(`/projects/wizard/inline/advertisers`, {
    method: "POST",
    body: JSON.stringify(input),
  });
}

export async function createInlineBrand(input: { name: string; advertiserId: string }) {
  return api<{ id: string; name: string; advertiserId: string }>(`/projects/wizard/inline/brands`, {
    method: "POST",
    body: JSON.stringify(input),
  });
}

export async function createInlineProductCategory(input: { name: string }) {
  return api<{ id: string; name: string }>(`/projects/wizard/inline/product-categories`, {
    method: "POST",
    body: JSON.stringify(input),
  });
}

export async function createInlineAgency(input: { type: string; name: string }) {
  return api<{ id: string; name: string; type: string }>(`/projects/wizard/inline/agencies`, {
    method: "POST",
    body: JSON.stringify(input),
  });
}

export async function createInlineAgencyTeam(input: { agencyId: string; name: string }) {
  return api<{ id: string; name: string; agencyId: string }>(`/projects/wizard/inline/agency-teams`, {
    method: "POST",
    body: JSON.stringify(input),
  });
}
