import { useCallback, useEffect, useState } from "react";
import { fetchWizardMeta } from "./wizardApi";
import type { WizardMeta } from "./wizard.types";

export function useWizardMeta() {
  const [data, setData] = useState<WizardMeta | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string>("");

  const reload = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const d = await fetchWizardMeta();
      setData(d);
    } catch (e: any) {
      setError(e?.message || "Failed to load wizard meta");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    let alive = true;
    setLoading(true);
    setError("");

    fetchWizardMeta()
      .then((d) => {
        if (!alive) return;
        setData(d);
      })
      .catch((e: any) => {
        if (!alive) return;
        setError(e?.message || "Failed to load wizard meta");
      })
      .finally(() => {
        if (!alive) return;
        setLoading(false);
      });

    return () => {
      alive = false;
    };
  }, []);

  return { data, loading, error, reload };
}
