export const NOTIF_TYPES = [
  { id: 1, label: "Project Creation" },
  { id: 2, label: "Auto QC Passed/Failed" },
  { id: 3, label: "All Files Uploaded / Final Save" },
  { id: 4, label: "Destination Selection Done" },
  { id: 5, label: "Project Committed" },
  { id: 6, label: "File To Destination" },
  { id: 7, label: "File To Multiple Destinations" },
  { id: 8, label: "Project Complete" },
  { id: 9, label: "File Ready For Approval" },
  { id: 10, label: "File Approved" },
  { id: 11, label: "File Sent" },
] as const;
