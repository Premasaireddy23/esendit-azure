import { useEffect, useMemo, useRef, useState } from "react";
import { HomeRefreshBar } from "../../../ui/HomeRefreshBar";
import { useNavigate } from "react-router-dom";
import { NOTIF_TYPES } from "./notificationTypes";
import { useWizardMeta } from "./useWizardMeta";
import { createWizardProject, fetchNextProjectCode, validateWizardProjectName, createInlineAdvertiserGroup, createInlineAdvertiser, createInlineBrand, createInlineProductCategory, createInlineAgency, createInlineAgencyTeam } from "./wizardApi";
import type { CreateWizardProjectPayload, AgencyType, Agency, AgencyTeam, PartnerAccountSummary } from "./wizard.types";
import { getMe, hasPerm, type MeResponse } from "../../../lib/me";
import { SearchSelect } from "../../../ui/SearchSelect";
import { AppModal } from "../../../ui/AppModal";
import { api } from "../../../lib/api";

function uniqEmails(input: string): string[] {
  const parts = input
    .split(/[\n,]/g)
    .map((s) => s.trim().toLowerCase())
    .filter(Boolean);
  return Array.from(new Set(parts));
}

function findName(list: { id: string; name: string }[] | undefined, id: string) {
  if (!id) return "";
  return (list || []).find((x) => x.id === id)?.name || "";
}

function formatBillingTeamValue(agencyName?: string | null, teamName?: string | null) {
  const team = String(teamName || "").trim();
  if (!team) return "";
  const agency = String(agencyName || "").trim();
  return agency ? `${agency} / ${team}` : team;
}


type RateCardSummary = {
  id: string;
  name: string;
};

function normalizeSenderLookup(value: any) {
  return String(value ?? "")
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "");
}

function deriveSenderMatches(
  senderAccounts: PartnerAccountSummary[] | undefined,
  sources: Array<{ label: string; value: string }>,
) {
  const normalizedSources = sources
    .map((source) => ({
      label: source.label,
      value: source.value,
      normalized: normalizeSenderLookup(source.value),
    }))
    .filter((source) => source.normalized);

  if (!normalizedSources.length || !Array.isArray(senderAccounts) || !senderAccounts.length) return [];

  return senderAccounts
    .map((account) => {
      const normalizedName = normalizeSenderLookup(account?.name);
      if (!normalizedName) return null;

      let score = 0;
      const matchedBy: string[] = [];
      for (const source of normalizedSources) {
        if (normalizedName === source.normalized) {
          score += 300;
          matchedBy.push(source.label);
          continue;
        }
        if (source.normalized.length >= 4 && (normalizedName.includes(source.normalized) || source.normalized.includes(normalizedName))) {
          score += 120;
          matchedBy.push(source.label);
        }
      }

      if (!score) return null;
      return {
        id: account.id,
        name: account.name,
        matchedBy: Array.from(new Set(matchedBy)),
        score,
      };
    })
    .filter((item): item is { id: string; name: string; matchedBy: string[]; score: number } => !!item)
    .sort((a, b) => b.score - a.score || a.name.localeCompare(b.name))
    .slice(0, 5);
}

function SenderAccountContextCard(props: { matches: Array<{ id: string; name: string; matchedBy: string[] }>; emptyHint?: string }) {
  if (!props.matches.length) {
    if (props.emptyHint === "") return null;
    return (
      <div style={{ padding: 14, borderRadius: 14, background: "#f8fafc", border: "1px dashed rgba(148,163,184,0.45)", fontSize: 13, color: "#64748b" }}>
        {props.emptyHint || "No matching sender account found from the current advertiser selections."}
      </div>
    );
  }

  return (
    <div style={{ display: "grid", gap: 10 }}>
      {props.matches.map((match) => (
        <div
          key={match.id}
          style={{
            padding: "12px 14px",
            borderRadius: 14,
            background: "#f8fafc",
            border: "1px solid rgba(148,163,184,0.18)",
            display: "grid",
            gap: 6,
          }}
        >
          <div style={{ fontWeight: 800, color: "#0f172a" }}>{match.name}</div>
          <div style={{ fontSize: 12, color: "#475569" }}>Matched from: {match.matchedBy.join(", ")}</div>
        </div>
      ))}
    </div>
  );
}


function EmailsHint({ emails }: { emails?: string[] | null }) {
  const list = Array.isArray(emails) ? emails.filter(Boolean) : [];
  if (list.length === 0) return null;

  const text = list.join(", ");
  return (
    <div
      style={{
        marginTop: 4,
        fontSize: 12,
        opacity: 0.75,
        whiteSpace: "nowrap",
        overflow: "hidden",
        textOverflow: "ellipsis",
      }}
      title={text}
    >
      Emails: {text}
    </div>
  );
}

type ToggleSwitchProps = {
  checked: boolean;
  onChange: (next: boolean) => void;
  disabled?: boolean;
  title?: string;
  size?: "sm" | "md";
};

function ToggleSwitch({ checked, onChange, disabled, title, size = "md" }: ToggleSwitchProps) {
  const w = size === "sm" ? 34 : 42;
  const h = size === "sm" ? 18 : 22;
  const pad = 2;
  const knob = h - pad * 2;
  const leftOn = w - pad - knob;
  const leftOff = pad;

  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      disabled={disabled}
      title={title}
      onClick={() => onChange(!checked)}
      style={{
        width: w,
        height: h,
        borderRadius: 999,
        border: `1px solid ${checked ? "#1f8a2d" : "#d0d0d0"}`,
        background: checked ? "#d7f5dd" : "#fff",
        position: "relative",
        padding: 0,
        cursor: disabled ? "not-allowed" : "pointer",
        opacity: disabled ? 0.6 : 1,
        verticalAlign: "middle",
      }}
    >
      <span
        style={{
          position: "absolute",
          top: pad,
          left: checked ? leftOn : leftOff,
          width: knob,
          height: knob,
          borderRadius: 999,
          background: checked ? "#1f8a2d" : "#bdbdbd",
          transition: "left 120ms ease",
        }}
      />
    </button>
  );
}

type NotifyGroupKey =
  | "notifyAdvertiserGroup"
  | "notifyAdvertiser"
  | "notifyBrand"
  | "notifyMediaAgency"
  | "notifyCreativeAgency"
  | "notifyPostHouse"
  | "notifyAudioAgency"
  | "notifyProductionHouse";

const NOTIFY_GROUPS: { key: NotifyGroupKey; label: string }[] = [
  { key: "notifyAdvertiserGroup", label: "Advertiser Group" },
  { key: "notifyAdvertiser", label: "Advertiser" },
  { key: "notifyBrand", label: "Brand" },
  { key: "notifyMediaAgency", label: "Media Agency" },
  { key: "notifyCreativeAgency", label: "Creative Agency" },
  { key: "notifyPostHouse", label: "Post House" },
  { key: "notifyAudioAgency", label: "Audio Agency" },
  { key: "notifyProductionHouse", label: "Production House" },
];

type NotifMatrix = Record<number, Record<NotifyGroupKey, boolean>>;

function makeInitialMatrix(defaults: Record<NotifyGroupKey, boolean>): NotifMatrix {
  const m: Record<number, Record<NotifyGroupKey, boolean>> = {} as any;
  for (const t of NOTIF_TYPES) {
    m[t.id] = { ...defaults };
  }
  return m;
}

function StepBadge({ children, tone = "neutral" }: { children: any; tone?: "neutral" | "success" | "soft" }) {
  const styles =
    tone === "success"
      ? { background: "#e7f8eb", border: "1px solid #b8e0c0", color: "#1f6f34" }
      : tone === "soft"
        ? { background: "#f4f7fb", border: "1px solid #dbe5f0", color: "#28435c" }
        : { background: "#fff", border: "1px solid rgba(0,0,0,0.08)", color: "#334155" };

  return (
    <span
      style={{
        display: "inline-flex",
        alignItems: "center",
        borderRadius: 999,
        padding: "6px 10px",
        fontSize: 12,
        fontWeight: 700,
        lineHeight: 1,
        ...styles,
      }}
    >
      {children}
    </span>
  );
}

function SectionCard(props: { title: string; subtitle?: string; children: any; right?: any }) {
  return (
    <div
      style={{
        border: "1px solid rgba(15,23,42,0.08)",
        borderRadius: 18,
        padding: 18,
        background: "linear-gradient(180deg, #ffffff 0%, #fbfdff 100%)",
        boxShadow: "0 8px 24px rgba(15,23,42,0.05)",
      }}
    >
      <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 12, marginBottom: 14 }}>
        <div>
          <div style={{ fontSize: 16, fontWeight: 800, color: "#0f172a" }}>{props.title}</div>
          {props.subtitle ? (
            <div style={{ fontSize: 13, color: "#64748b", marginTop: 4, lineHeight: 1.4 }}>{props.subtitle}</div>
          ) : null}
        </div>
        {props.right ? <div>{props.right}</div> : null}
      </div>
      {props.children}
    </div>
  );
}

type BillingAgencyKey = "ADVERTISER_GROUP" | "ADVERTISER" | "BRAND" | "MEDIA" | "MEDIA_TEAM" | "CREATIVE" | "CREATIVE_TEAM" | "PRODUCTION_HOUSE" | "PRODUCTION_HOUSE_TEAM" | "POST_HOUSE" | "POST_HOUSE_TEAM" | "AUDIO" | "AUDIO_TEAM" | "UPLOADER" | "UPLOADER_TEAM";
type BillingAgencyChoice = { key: BillingAgencyKey; label: string; value: string };
type BillingSourceKey = BillingAgencyKey;
type SelectedBillingSourceKey = BillingSourceKey | "";
type BillingSourceChoice = { key: BillingSourceKey; label: string; value: string };

const PROJECT_BILLING_AGENCY_STORAGE_PREFIX = "projects.billingApplicableAgencies.";
const PROJECT_BILLING_SOURCE_STORAGE_PREFIX = "projects.billingSource.";
const PROJECT_RATE_CARD_STORAGE_PREFIX = "projects.rateCard.";
const BILLING_AGENCY_KEY_SET = new Set<BillingAgencyKey>(["ADVERTISER_GROUP", "ADVERTISER", "BRAND", "MEDIA", "MEDIA_TEAM", "CREATIVE", "CREATIVE_TEAM", "PRODUCTION_HOUSE", "PRODUCTION_HOUSE_TEAM", "POST_HOUSE", "POST_HOUSE_TEAM", "AUDIO", "AUDIO_TEAM", "UPLOADER", "UPLOADER_TEAM"]);
const BILLING_SOURCE_KEY_SET = new Set<BillingSourceKey>(["ADVERTISER_GROUP", "ADVERTISER", "BRAND", "MEDIA", "MEDIA_TEAM", "CREATIVE", "CREATIVE_TEAM", "PRODUCTION_HOUSE", "PRODUCTION_HOUSE_TEAM", "POST_HOUSE", "POST_HOUSE_TEAM", "AUDIO", "AUDIO_TEAM", "UPLOADER", "UPLOADER_TEAM"]);

function safeLocalStorageSet(key: string, value: string) {
  try {
    if (typeof window === "undefined") return;
    if (value) window.localStorage.setItem(key, value);
    else window.localStorage.removeItem(key);
  } catch {
    // ignore local storage failures
  }
}

function normalizeBillingAgencyKeys(value: unknown): BillingAgencyKey[] {
  if (!Array.isArray(value)) return [];
  const out: BillingAgencyKey[] = [];
  for (const item of value) {
    const key = String(item || "").trim().toUpperCase() as BillingAgencyKey;
    if (BILLING_AGENCY_KEY_SET.has(key) && !out.includes(key)) out.push(key);
  }
  return out;
}

function saveProjectBillingAgencyKeys(projectId: string, keys: BillingAgencyKey[]) {
  const id = String(projectId || "").trim();
  if (!id) return;
  safeLocalStorageSet(`${PROJECT_BILLING_AGENCY_STORAGE_PREFIX}${id}`, JSON.stringify(normalizeBillingAgencyKeys(keys)));
}

function normalizeBillingSourceKey(value: unknown): SelectedBillingSourceKey {
  const key = String(value || "").trim().toUpperCase() as BillingSourceKey;
  return BILLING_SOURCE_KEY_SET.has(key) ? key : "";
}

function saveProjectBillingSourceKey(projectId: string, key: SelectedBillingSourceKey) {
  const id = String(projectId || "").trim();
  if (!id) return;
  safeLocalStorageSet(`${PROJECT_BILLING_SOURCE_STORAGE_PREFIX}${id}`, normalizeBillingSourceKey(key));
}

function saveProjectRateCardId(projectId: string, rateCardId: string) {
  const id = String(projectId || "").trim();
  if (!id) return;
  safeLocalStorageSet(`${PROJECT_RATE_CARD_STORAGE_PREFIX}${id}`, String(rateCardId || "").trim());
}


function BillingSummaryTile({ label, value, tone = "blue" }: { label: string; value?: string; tone?: "blue" | "emerald" }) {
  const active = Boolean(String(value || "").trim());
  const palette = tone === "emerald"
    ? {
        background: active ? "linear-gradient(180deg, #ecfdf5 0%, #f7fee7 100%)" : "#f8fafc",
        border: active ? "1px solid rgba(16,185,129,0.24)" : "1px solid rgba(148,163,184,0.18)",
        accent: "#047857",
      }
    : {
        background: active ? "linear-gradient(180deg, #eff6ff 0%, #f8fafc 100%)" : "#f8fafc",
        border: active ? "1px solid rgba(37,99,235,0.18)" : "1px solid rgba(148,163,184,0.18)",
        accent: "#1d4ed8",
      };

  return (
    <div
      style={{
        display: "grid",
        gap: 6,
        padding: "12px 14px",
        borderRadius: 14,
        background: palette.background,
        border: palette.border,
        minHeight: 72,
      }}
    >
      <span style={{ fontSize: 11, fontWeight: 800, letterSpacing: 0.3, textTransform: "uppercase", color: "#64748b" }}>{label}</span>
      <span style={{ fontSize: 14, fontWeight: 800, color: active ? "#0f172a" : "#94a3b8", lineHeight: 1.35 }}>{value || "Not selected"}</span>
      <span style={{ width: 32, height: 4, borderRadius: 999, background: active ? palette.accent : "rgba(148,163,184,0.3)" }} />
    </div>
  );
}

function BillingAgencySelector(props: {
  options: BillingAgencyChoice[];
  selectedKeys: BillingAgencyKey[];
  onToggle: (key: BillingAgencyKey) => void;
}) {
  if (!props.options.length) return null;
  const selected = new Set(props.selectedKeys);
  return (
    <div style={{ display: "grid", gap: 10, padding: 14, borderRadius: 14, background: "#ffffff", border: "1px solid rgba(148,163,184,0.18)" }}>
      <div style={{ display: "grid", gap: 4 }}>
        <div style={{ fontSize: 12, fontWeight: 800, color: "#334155", textTransform: "uppercase", letterSpacing: 0.3 }}>Billing scope</div>
      </div>
      <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
        {props.options.map((item) => {
          const active = selected.has(item.key);
          return (
            <button
              key={item.key}
              type="button"
              onClick={() => props.onToggle(item.key)}
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: 6,
                padding: "8px 12px",
                borderRadius: 999,
                border: active ? "1px solid #2563eb" : "1px solid rgba(148,163,184,0.28)",
                background: active ? "#eff6ff" : "#ffffff",
                color: active ? "#1d4ed8" : "#334155",
                fontSize: 12,
                fontWeight: 700,
                cursor: "pointer",
                boxShadow: active ? "0 4px 12px rgba(37,99,235,0.12)" : "none",
              }}
            >
              {item.label}
            </button>
          );
        })}
      </div>
    </div>
  );
}

function BillingSourceSelector(props: {
  options: BillingSourceChoice[];
  selectedKey: SelectedBillingSourceKey;
  onChange: (key: SelectedBillingSourceKey) => void;
}) {
  if (!props.options.length) return null;
  return (
    <div style={{ display: "grid", gap: 8, padding: 14, borderRadius: 14, background: "#ffffff", border: "1px solid rgba(148,163,184,0.18)" }}>
      <SearchSelect
        label="Billing Source"
        value={props.selectedKey}
        onChange={(next) => props.onChange(normalizeBillingSourceKey(next))}
        options={props.options.map((item) => ({ id: item.key, name: item.value || item.label }))}
        placeholder="Search billing source"
      />
    </div>
  );
}

function InlineAddButton({ onClick, title = "Add" }: { onClick: () => void; title?: string }) {
  return (
    <button
      type="button"
      title={title}
      onClick={onClick}
      style={{
        minWidth: 38,
        height: 38,
        borderRadius: 12,
        border: "1px solid #cfe3d3",
        background: "#edf9ef",
        color: "#1f6f34",
        fontSize: 20,
        fontWeight: 700,
        lineHeight: 1,
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        padding: 0,
      }}
    >
      +
    </button>
  );
}

function SelectionSummary({ label, value }: { label: string; value: string }) {
  return (
    <div
      style={{
        display: "flex",
        justifyContent: "space-between",
        gap: 12,
        padding: "10px 12px",
        borderRadius: 12,
        background: "#f8fafc",
        border: "1px solid rgba(148,163,184,0.18)",
      }}
    >
      <span style={{ fontSize: 12, fontWeight: 700, color: "#475569" }}>{label}</span>
      <span style={{ fontSize: 13, fontWeight: 700, color: value ? "#0f172a" : "#94a3b8", textAlign: "right" }}>
        {value || "Not selected"}
      </span>
    </div>
  );
}


function InlineNamePrompt(props: {
  open: boolean;
  title: string;
  value: string;
  onChange: (next: string) => void;
  onCancel: () => void;
  onConfirm: () => void;
}) {
  return (
    <AppModal
      open={props.open}
      title={props.title}
      subtitle="Enter the name and save it directly into masters."
      onClose={props.onCancel}
      width="sm"
      footer={
        <>
          <button
            type="button"
            onClick={props.onCancel}
            style={{
              height: 42,
              padding: "0 18px",
              borderRadius: 999,
              border: "1px solid #d7dee8",
              background: "#fff",
              color: "#0f172a",
              fontWeight: 700,
            }}
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={props.onConfirm}
            disabled={!props.value.trim()}
            style={{
              height: 42,
              padding: "0 18px",
              borderRadius: 999,
              border: "1px solid rgba(31,138,45,0.42)",
              background: props.value.trim() ? "#1f8a2d" : "#cbd5e1",
              color: "#fff",
              fontWeight: 700,
              cursor: props.value.trim() ? "pointer" : "not-allowed",
            }}
          >
            Save
          </button>
        </>
      }
    >
      <form
        onSubmit={(e) => {
          e.preventDefault();
          props.onConfirm();
        }}
        style={{ display: "grid", gap: 14 }}
      >
        <input
          autoFocus
          value={props.value}
          onChange={(e) => props.onChange(e.target.value)}
          placeholder="Type name"
          style={{
            width: "100%",
            height: 50,
            borderRadius: 14,
            border: "1px solid #cbd5e1",
            padding: "0 14px",
            fontSize: 15,
            outline: "none",
            background: "#fff",
            boxSizing: "border-box",
          }}
        />
      </form>
    </AppModal>
  );
}

export default function ProjectCreateWizardPage() {
  const nav = useNavigate();
  const { data, loading, error, reload } = useWizardMeta();
  const [rateCards, setRateCards] = useState<RateCardSummary[]>([]);

  const [me, setMe] = useState<MeResponse | null>(null);
  const [meErr, setMeErr] = useState<string>("");

  useEffect(() => {
    getMe()
      .then(setMe)
      .catch((e: any) => setMeErr(e?.message || "Failed to load permissions"));
  }, []);

  useEffect(() => {
    api<RateCardSummary[]>(`/masters/rate-cards`).then(setRateCards).catch(() => setRateCards([]));
  }, []);

  const canManual = hasPerm(me, "PROJECT_NUMBER_MANUAL");
  const canAuto = hasPerm(me, "PROJECT_NUMBER_AUTO");

  const canAddAdvGroup = hasPerm(me, "PROJECT_MASTER_ADD_ADVERTISER_GROUP");
  const canAddAdvertiser = hasPerm(me, "PROJECT_MASTER_ADD_ADVERTISER");
  const canAddBrand = hasPerm(me, "PROJECT_MASTER_ADD_BRAND");
  const canAddProductCategory = hasPerm(me, "PROJECT_MASTER_ADD_PRODUCT_CATEGORY");
  const canAddAgency = hasPerm(me, "PROJECT_MASTER_ADD_AGENCY");
  const canAddAgencyTeam = hasPerm(me, "PROJECT_MASTER_ADD_AGENCY_TEAM");

  const [step, setStep] = useState<1 | 2 | 3>(1);
  const [showOptionalAssignments, setShowOptionalAssignments] = useState(false);

  // Step 2: notifications
  // Default approval + delivery receiver notifications ON.
  const [enabledTypes, setEnabledTypes] = useState<number[]>([9, 10, 11]);
  const [notifMatrix, setNotifMatrix] = useState<NotifMatrix>(() =>
    makeInitialMatrix({
      notifyAdvertiserGroup: false,
      notifyAdvertiser: false,
      notifyBrand: false,
      notifyMediaAgency: false,
      notifyCreativeAgency: false,
      notifyPostHouse: false,
      notifyAudioAgency: false,
      notifyProductionHouse: false,
    })
  );
  const [extraRecipients, setExtraRecipients] = useState<Array<{ id: string; name: string; email: string }>>([]);
  const [extraEmailsText, setExtraEmailsText] = useState("");

  // Step 1: details
  const [name, setName] = useState("");
  const [projectCode, setProjectCode] = useState(""); // optional manual
  const [autoPreview, setAutoPreview] = useState<string>("");
  const [autoPreviewLoading, setAutoPreviewLoading] = useState(false);
  const [autoPreviewErr, setAutoPreviewErr] = useState("");
  const [projectNameCheck, setProjectNameCheck] = useState<{ loading: boolean; available: boolean | null; message: string; checkedValue: string }>({ loading: false, available: null, message: "", checkedValue: "" });

  const [advertiserGroupId, setAdvertiserGroupId] = useState("");
  const [advertiserId, setAdvertiserId] = useState("");
  const [brandId, setBrandId] = useState("");
  const [productCategoryId, setProductCategoryId] = useState("");
  const [senderAccountId, setSenderAccountId] = useState("");
  const [selectedRateCardId, setSelectedRateCardId] = useState("");
  const [billingAgencyKeys, setBillingAgencyKeys] = useState<BillingAgencyKey[]>([]);
  const [billingSourceKey, setBillingSourceKey] = useState<SelectedBillingSourceKey>("");

  // ✅ NEW: optional assignments
  const [approvalsEnabled, setApprovalsEnabled] = useState(false);

  const [mediaAgencyId, setMediaAgencyId] = useState("");
  const [mediaAgencyTeamId, setMediaAgencyTeamId] = useState("");

  const [creativeAgencyId, setCreativeAgencyId] = useState("");
  const [creativeAgencyTeamId, setCreativeAgencyTeamId] = useState("");

  const [productionHouseId, setProductionHouseId] = useState("");
  const [productionHouseTeamId, setProductionHouseTeamId] = useState("");

  const [postHouseId, setPostHouseId] = useState("");
  const [postHouseTeamId, setPostHouseTeamId] = useState("");

  const [audioAgencyId, setAudioAgencyId] = useState("");
  const [audioAgencyTeamId, setAudioAgencyTeamId] = useState("");

  // NEW: uploader (Agency + Team) + remarks
  const [uploaderAgencyId, setUploaderAgencyId] = useState("");
  const [uploaderAgencyTeamId, setUploaderAgencyTeamId] = useState("");
  const [remarks, setRemarks] = useState("");

  const [submitErr, setSubmitErr] = useState<string>("");
  const [submitting, setSubmitting] = useState(false);
  const [inlinePromptTitle, setInlinePromptTitle] = useState("");
  const [inlinePromptValue, setInlinePromptValue] = useState("");
  const [inlinePromptOpen, setInlinePromptOpen] = useState(false);
  const inlinePromptResolverRef = useRef<((value: string | null) => void) | null>(null);

  useEffect(() => {
    return () => {
      if (inlinePromptResolverRef.current) {
        inlinePromptResolverRef.current(null);
        inlinePromptResolverRef.current = null;
      }
    };
  }, []);

  useEffect(() => {
    const trimmed = name.trim();
    if (!trimmed) {
      setProjectNameCheck({ loading: false, available: null, message: "", checkedValue: "" });
      return;
    }

    let cancelled = false;
    const timer = window.setTimeout(async () => {
      setProjectNameCheck((prev) => ({
        loading: true,
        available: prev.checkedValue === trimmed ? prev.available : null,
        message: prev.checkedValue === trimmed ? prev.message : "",
        checkedValue: prev.checkedValue,
      }));
      try {
        const result = await validateWizardProjectName(trimmed);
        if (cancelled) return;
        setProjectNameCheck({
          loading: false,
          available: result.available,
          message: result.message || (result.available ? "Project name is available." : "Project name already exists in this account."),
          checkedValue: trimmed,
        });
      } catch (e: any) {
        if (cancelled) return;
        setProjectNameCheck({
          loading: false,
          available: null,
          message: e?.message || "Unable to validate project name right now.",
          checkedValue: trimmed,
        });
      }
    }, 350);

    return () => {
      cancelled = true;
      window.clearTimeout(timer);
    };
  }, [name]);

  const emails = useMemo(() => {
    const fromText = uniqEmails(extraEmailsText);
    const fromTable = extraRecipients
      .map((r) => (r.email || "").trim().toLowerCase())
      .filter(Boolean);
    return Array.from(new Set([...fromText, ...fromTable]));
  }, [extraEmailsText, extraRecipients]);

  const derivedNotify = useMemo(() => {
    const enabled = new Set(enabledTypes);
    const out = Object.fromEntries(NOTIFY_GROUPS.map((g) => [g.key, false])) as Record<NotifyGroupKey, boolean>;
    for (const t of NOTIF_TYPES) {
      if (!enabled.has(t.id)) continue;
      const row = notifMatrix[t.id];
      if (!row) continue;
      for (const g of NOTIFY_GROUPS) {
        out[g.key] = out[g.key] || !!row[g.key];
      }
    }
    return out;
  }, [enabledTypes, notifMatrix]);

  const trimmedProjectName = name.trim();
  const projectNameCheckSettledForCurrentValue = !!trimmedProjectName && projectNameCheck.checkedValue === trimmedProjectName;
  const projectNameAlreadyExists = projectNameCheckSettledForCurrentValue && projectNameCheck.available === false;
  const projectNameReady = projectNameCheckSettledForCurrentValue && !projectNameCheck.loading && !projectNameAlreadyExists;

  const requiredDoneCount = [
    projectNameReady ? 1 : 0,
    advertiserGroupId ? 1 : 0,
    advertiserId ? 1 : 0,
    brandId ? 1 : 0,
    productCategoryId ? 1 : 0,
    (canAuto || (canManual && projectCode.trim().length > 0) || (canManual && canAuto)) ? 1 : 0,
  ].reduce((a, b) => a + b, 0);

  const setupSummaryCount = [
    mediaAgencyId,
    creativeAgencyId,
    productionHouseId,
    postHouseId,
    audioAgencyId,
    uploaderAgencyId,
    remarks.trim(),
  ].filter(Boolean).length;

  const canGoStep2 =
    projectNameReady &&
    advertiserGroupId &&
    advertiserId &&
    brandId &&
    productCategoryId &&
    (canAuto || (canManual && projectCode.trim().length > 0) || (canManual && canAuto));

  const canGoStep3 = enabledTypes.length > 0;

  function allAgencies(): Agency[] {
    return (data?.agencies || []) as Agency[];
  }

  function agenciesOf(type: AgencyType): Agency[] {
    const list = (data?.agencies || []) as Agency[];
    return list.filter((a) => a.type === type);
  }

  function teamsOf(agencyId: string): AgencyTeam[] {
    const list = (data?.agencyTeams || []) as AgencyTeam[];
    return list.filter((t) => t.agencyId === agencyId);
  }

  function agencyById(id: string): Agency | null {
    if (!id) return null;
    return ((data?.agencies || []) as Agency[]).find((a) => a.id === id) || null;
  }

  function teamById(id: string): AgencyTeam | null {
    if (!id) return null;
    return ((data?.agencyTeams || []) as AgencyTeam[]).find((t) => t.id === id) || null;
  }


  async function promptName(title: string): Promise<string | null> {
    return new Promise((resolve) => {
      inlinePromptResolverRef.current = resolve;
      setInlinePromptTitle(title);
      setInlinePromptValue("");
      setInlinePromptOpen(true);
    });
  }

  function closeInlinePrompt(result: string | null) {
    const resolver = inlinePromptResolverRef.current;
    inlinePromptResolverRef.current = null;
    setInlinePromptOpen(false);
    setInlinePromptTitle("");
    setInlinePromptValue("");
    resolver?.(result);
  }

  function confirmInlinePrompt() {
    const value = inlinePromptValue.trim();
    if (!value) return;
    closeInlinePrompt(value);
  }

  async function inlineCreateAdvertiserGroup() {
    const n = await promptName("New Advertiser Group name");
    if (!n) return;
    const created = await createInlineAdvertiserGroup({ name: n });
    await reload();
    setAdvertiserGroupId(created.id);
  }

  async function inlineCreateAdvertiser() {
    if (!advertiserGroupId) {
      alert("Select Advertiser Group first");
      return;
    }
    const n = await promptName("New Advertiser name");
    if (!n) return;
    const created = await createInlineAdvertiser({ name: n, advertiserGroupId });
    await reload();
    setAdvertiserId(created.id);
  }

  async function inlineCreateBrand() {
    if (!advertiserId) {
      alert("Select Advertiser first");
      return;
    }
    const n = await promptName("New Brand name");
    if (!n) return;
    const created = await createInlineBrand({ name: n, advertiserId });
    await reload();
    setBrandId(created.id);
  }

  async function inlineCreateProductCategory() {
    const n = await promptName("New Product Category name");
    if (!n) return;
    const created = await createInlineProductCategory({ name: n });
    await reload();
    setProductCategoryId(created.id);
  }

  async function inlineCreateAgency(type: AgencyType, setId: (id: string) => void) {
    const n = await promptName(`New ${type.replace("_", " ")} name`);
    if (!n) return;
    const created = await createInlineAgency({ type, name: n });
    await reload();
    setId(created.id);
  }

  async function inlineCreateAgencyTeam(agencyId: string, setTeamId: (id: string) => void) {
    if (!agencyId) {
      alert("Select Agency first");
      return;
    }
    const n = await promptName("New Team name");
    if (!n) return;
    const created = await createInlineAgencyTeam({ agencyId, name: n });
    await reload();
    setTeamId(created.id);
  }

  async function onPreviewAuto() {
    setSubmitErr("");
    setAutoPreviewErr("");
    setAutoPreviewLoading(true);
    try {
      const r = await fetchNextProjectCode();
      setAutoPreview(r.projectCode);
    } catch (e: any) {
      setAutoPreview("");
      const msg = e?.message || "Failed to preview project number";
      setAutoPreviewErr(msg);
      setSubmitErr(msg);
    } finally {
      setAutoPreviewLoading(false);
    }
  }

  async function onCreate() {
    const currentProjectName = name.trim();
    if (!currentProjectName) {
      setSubmitErr("Project name is required");
      return;
    }
    if (projectNameCheck.loading || projectNameCheck.checkedValue !== currentProjectName) {
      setSubmitErr("Please wait until the project name check completes.");
      return;
    }
    if (projectNameCheck.available === false) {
      setSubmitErr(projectNameCheck.message || "Project name already exists in this account.");
      return;
    }

    setSubmitErr("");
    setSubmitting(true);
    try {
      const payload: CreateWizardProjectPayload = {
        name: name.trim(),
        projectCode: projectCode.trim() || undefined,

        advertiserGroupId,
        advertiserId,
        brandId,
        productCategoryId,
        senderAccountId: senderAccountId || undefined,

        approvalsEnabled,

        mediaAgencyId: mediaAgencyId || undefined,
        mediaAgencyTeamId: mediaAgencyTeamId || undefined,

        creativeAgencyId: creativeAgencyId || undefined,
        creativeAgencyTeamId: creativeAgencyTeamId || undefined,

        productionHouseId: productionHouseId || undefined,
        productionHouseTeamId: productionHouseTeamId || undefined,

        postHouseId: postHouseId || undefined,
        postHouseTeamId: postHouseTeamId || undefined,

        audioAgencyId: audioAgencyId || undefined,
        audioAgencyTeamId: audioAgencyTeamId || undefined,

        uploaderAgencyId: uploaderAgencyId || undefined,
        uploaderAgencyTeamId: uploaderAgencyTeamId || undefined,
        remarks: remarks.trim() || undefined,

        notification: {
          notifyAdvertiserGroup: derivedNotify.notifyAdvertiserGroup,
          notifyAdvertiser: derivedNotify.notifyAdvertiser,
          notifyBrand: derivedNotify.notifyBrand,
          notifyMediaAgency: derivedNotify.notifyMediaAgency,
          notifyCreativeAgency: derivedNotify.notifyCreativeAgency,
          notifyPostHouse: derivedNotify.notifyPostHouse,
          notifyAudioAgency: derivedNotify.notifyAudioAgency,
          notifyProductionHouse: derivedNotify.notifyProductionHouse,
          extraEmails: emails,
          enabledTypes,
        },
      };

      const created = await createWizardProject(payload);
      saveProjectBillingAgencyKeys(created.id, billingAgencyKeys);
      saveProjectBillingSourceKey(created.id, billingSourceKey);
      saveProjectRateCardId(created.id, selectedRateCardId);
      nav(`/projects/${created.id}/planner`);
    } catch (e: any) {
      setSubmitErr(e?.message || "Failed to create project");
    } finally {
      setSubmitting(false);
    }
  }

  const senderSources = useMemo(
    () => [
      { label: "Advertiser Group", value: findName(data?.advertiserGroups, advertiserGroupId) },
      { label: "Advertiser", value: findName(data?.advertisers, advertiserId) },
      { label: "Brand", value: findName(data?.brands, brandId) },
    ],
    [data, advertiserGroupId, advertiserId, brandId],
  );

  const senderMatches = useMemo(
    () => deriveSenderMatches(data?.senderAccounts, senderSources),
    [data, senderSources],
  );

  const senderAccountOptions = useMemo(
    () => (data?.senderAccounts || []).map((item) => ({ id: item.id, name: item.name })),
    [data],
  );

  const rateCardOptions = useMemo(
    () => (rateCards || []).map((item) => ({ id: item.id, name: item.name })),
    [rateCards],
  );

  const selectedRateCard = useMemo(
    () => rateCards.find((item) => item.id === selectedRateCardId) || null,
    [rateCards, selectedRateCardId],
  );

  const billingAgencyOptions = useMemo<BillingAgencyChoice[]>(
    () => ([
      { key: "ADVERTISER_GROUP" as BillingAgencyKey, label: "Advertiser Group", value: findName(data?.advertiserGroups, advertiserGroupId) },
      { key: "ADVERTISER" as BillingAgencyKey, label: "Advertiser", value: findName(data?.advertisers, advertiserId) },
      { key: "BRAND" as BillingAgencyKey, label: "Brand", value: findName(data?.brands, brandId) },
      { key: "MEDIA" as BillingAgencyKey, label: "Media", value: agencyById(mediaAgencyId)?.name || "" },
      { key: "MEDIA_TEAM" as BillingAgencyKey, label: "Media Team", value: formatBillingTeamValue(agencyById(mediaAgencyId)?.name, teamById(mediaAgencyTeamId)?.name) },
      { key: "CREATIVE" as BillingAgencyKey, label: "Creative", value: agencyById(creativeAgencyId)?.name || "" },
      { key: "CREATIVE_TEAM" as BillingAgencyKey, label: "Creative Team", value: formatBillingTeamValue(agencyById(creativeAgencyId)?.name, teamById(creativeAgencyTeamId)?.name) },
      { key: "PRODUCTION_HOUSE" as BillingAgencyKey, label: "Production", value: agencyById(productionHouseId)?.name || "" },
      { key: "PRODUCTION_HOUSE_TEAM" as BillingAgencyKey, label: "Production Team", value: formatBillingTeamValue(agencyById(productionHouseId)?.name, teamById(productionHouseTeamId)?.name) },
      { key: "POST_HOUSE" as BillingAgencyKey, label: "Post House", value: agencyById(postHouseId)?.name || "" },
      { key: "POST_HOUSE_TEAM" as BillingAgencyKey, label: "Post House Team", value: formatBillingTeamValue(agencyById(postHouseId)?.name, teamById(postHouseTeamId)?.name) },
      { key: "AUDIO" as BillingAgencyKey, label: "Audio", value: agencyById(audioAgencyId)?.name || "" },
      { key: "AUDIO_TEAM" as BillingAgencyKey, label: "Audio Team", value: formatBillingTeamValue(agencyById(audioAgencyId)?.name, teamById(audioAgencyTeamId)?.name) },
      { key: "UPLOADER" as BillingAgencyKey, label: "Uploader", value: agencyById(uploaderAgencyId)?.name || "" },
      { key: "UPLOADER_TEAM" as BillingAgencyKey, label: "Uploader Team", value: formatBillingTeamValue(agencyById(uploaderAgencyId)?.name, teamById(uploaderAgencyTeamId)?.name) },
    ] as BillingAgencyChoice[]).filter((item) => Boolean(item.value)),
    [data, advertiserGroupId, advertiserId, brandId, mediaAgencyId, mediaAgencyTeamId, creativeAgencyId, creativeAgencyTeamId, productionHouseId, productionHouseTeamId, postHouseId, postHouseTeamId, audioAgencyId, audioAgencyTeamId, uploaderAgencyId, uploaderAgencyTeamId],
  );
  const billingAgencyOptionsSignature = useMemo(() => billingAgencyOptions.map((item) => `${item.key}:${item.value}`).join("|"), [billingAgencyOptions]);
  useEffect(() => {
    const available = new Set(billingAgencyOptions.map((item) => item.key));
    setBillingAgencyKeys((prev) => prev.filter((key) => available.has(key)));
  }, [billingAgencyOptionsSignature]);
  const billingSourceOptions = useMemo<BillingSourceChoice[]>(
    () => billingAgencyOptions
      .filter((item) => billingAgencyKeys.includes(item.key))
      .map((item) => ({ key: item.key as BillingSourceKey, label: item.label, value: item.value }))
      .filter((item) => Boolean(item.value)),
    [billingAgencyOptions, billingAgencyKeys],
  );
  const billingSourceOptionsSignature = useMemo(() => billingSourceOptions.map((item) => `${item.key}:${item.value}`).join("|"), [billingSourceOptions]);
  useEffect(() => {
    if (!billingSourceKey) return;
    const currentAvailable = billingSourceOptions.find((item) => item.key === billingSourceKey);
    if (!currentAvailable) setBillingSourceKey("");
  }, [billingSourceOptionsSignature, billingSourceKey]);
  const selectedBillingSource = useMemo(
    () => billingSourceOptions.find((item) => item.key === billingSourceKey) || null,
    [billingSourceOptions, billingSourceKey],
  );

  const toggleBillingAgencyKey = (key: BillingAgencyKey) => {
    setBillingAgencyKeys((prev) => (prev.includes(key) ? prev.filter((item) => item !== key) : [...prev, key]));
  };


  if (loading) return <div style={{ padding: 16 }}>Loading wizard…</div>;
  if (error) return <div style={{ padding: 16, color: "#b00" }}>{error}</div>;
  if (!data) return <div style={{ padding: 16 }}>No wizard meta</div>;

  const mediaA = agencyById(mediaAgencyId);
  const mediaT = teamById(mediaAgencyTeamId);

  const creativeA = agencyById(creativeAgencyId);
  const creativeT = teamById(creativeAgencyTeamId);

  const productionA = agencyById(productionHouseId);
  const productionT = teamById(productionHouseTeamId);

  const postA = agencyById(postHouseId);
  const postT = teamById(postHouseTeamId);

  const audioA = agencyById(audioAgencyId);
  const audioT = teamById(audioAgencyTeamId);

  const uploaderA = agencyById(uploaderAgencyId);
  const uploaderT = teamById(uploaderAgencyTeamId);

  return (
    <div
      style={{
        padding: 16,
        width: "100%",
        maxWidth: "100%",
        boxSizing: "border-box",
        margin: "0 auto",
      }}
    >
      <HomeRefreshBar
        title="Create Project"
        right={<div style={{ fontSize: 12, opacity: 0.75 }}>Step {step} / 3</div>}
      />

      {meErr && (
        <div className="card" style={{ borderColor: "#f5a", background: "#fff5fa" }}>
          {meErr}
        </div>
      )}

      {/* Step 2 */}
      {step === 2 && (
        <div className="card">
          <div style={{ fontSize: 15, fontWeight: 800, marginBottom: 8 }}>2) Notifications</div>

          <div
            style={{
              marginBottom: 12,
              padding: "12px 14px",
              borderRadius: 12,
              border: "1px solid rgba(37,99,235,0.18)",
              background: "#eff6ff",
              fontSize: 12,
              color: "#1e3a8a",
              lineHeight: 1.5,
            }}
          >
            Types <b>9</b>, <b>10</b>, and <b>11</b> use the linked receiver account emails from the selected destination(s).
            Type <b>9</b> is sent only for approval-required destinations, type <b>10</b> after approval, and type <b>11</b>
            when the file is sent for delivery for non-approval destinations.
          </div>

          <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: 10 }}>
            <button
              type="button"
              onClick={() => setEnabledTypes(NOTIF_TYPES.map((t) => t.id))}
              title="Enable all notification types"
            >
              Enable all types
            </button>
            <button type="button" onClick={() => setEnabledTypes([])} title="Disable all notification types">
              Disable all types
            </button>
            <button
              type="button"
              onClick={() => {
                setNotifMatrix((prev) => {
                  const next: NotifMatrix = { ...prev };
                  for (const t of NOTIF_TYPES) {
                    next[t.id] = { ...next[t.id] };
                    for (const g of NOTIFY_GROUPS) next[t.id][g.key] = true;
                  }
                  return next;
                });
              }}
              title="Select all recipient groups for all types"
            >
              Select all groups
            </button>
            <button
              type="button"
              onClick={() => {
                setNotifMatrix((prev) => {
                  const next: NotifMatrix = { ...prev };
                  for (const t of NOTIF_TYPES) {
                    next[t.id] = { ...next[t.id] };
                    for (const g of NOTIFY_GROUPS) next[t.id][g.key] = false;
                  }
                  return next;
                });
              }}
              title="Clear all recipient groups for all types"
            >
              Clear groups
            </button>
          </div>

          <div style={{ overflowX: "auto", border: "1px solid #eee", borderRadius: 12 }}>
            <table style={{ width: "100%", borderCollapse: "collapse", minWidth: 1200, fontSize: 13 }}>
              <thead>
                <tr style={{ background: "#f8fafc" }}>
                  <th style={{ textAlign: "center", padding: 12, borderBottom: "1px solid #eee", width: 80 }}>On</th>
                  <th style={{ textAlign: "left", padding: 12, borderBottom: "1px solid #eee", minWidth: 300 }}>
                    Notification type
                  </th>
                  {NOTIFY_GROUPS.map((g) => (
                    <th key={g.key} style={{ textAlign: "center", padding: 12, borderBottom: "1px solid #eee", minWidth: 140 }}>
                      <div style={{ fontSize: 13, fontWeight: 800 }}>{g.label}</div>
                      <div
                        style={{
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          gap: 8,
                          marginTop: 6,
                          fontSize: 12,
                          fontWeight: 600,
                          opacity: 0.8,
                        }}
                        title="Apply to all types"
                      >
                        <ToggleSwitch
                          size="sm"
                          checked={NOTIF_TYPES.every((t) => !!notifMatrix[t.id]?.[g.key])}
                          onChange={(v) => {
                            setNotifMatrix((prev) => {
                              const next: NotifMatrix = { ...prev };
                              for (const t of NOTIF_TYPES) {
                                next[t.id] = { ...next[t.id], [g.key]: v };
                              }
                              return next;
                            });
                          }}
                        />
                        <span>all</span>
                      </div>
                    </th>
                  ))}
                  <th style={{ textAlign: "center", padding: 12, borderBottom: "1px solid #eee", width: 80 }}>All</th>
                </tr>
              </thead>
              <tbody>
                {NOTIF_TYPES.map((t) => {
                  const on = enabledTypes.includes(t.id);
                  const row = notifMatrix[t.id] || ({} as any);
                  const rowAll = NOTIFY_GROUPS.every((g) => !!row[g.key]);
                  const rowBg = on ? "#fff" : "#fcfcfc";

                  return (
                    <tr key={t.id} style={{ background: rowBg }}>
                      <td style={{ textAlign: "center", padding: 12, borderBottom: "1px solid #f1f1f1" }}>
                        <ToggleSwitch
                          checked={on}
                          onChange={(v) => {
                            setEnabledTypes((prev) =>
                              v ? Array.from(new Set([...prev, t.id])) : prev.filter((x) => x !== t.id)
                            );
                          }}
                        />
                      </td>
                      <td style={{ padding: 12, borderBottom: "1px solid #f1f1f1" }}>
                        <div style={{ fontSize: 14, fontWeight: 800 }}>
                          {t.id}. {t.label}
                        </div>
                      </td>
                      {NOTIFY_GROUPS.map((g) => (
                        <td key={g.key} style={{ textAlign: "center", padding: 12, borderBottom: "1px solid #f1f1f1" }}>
                          <ToggleSwitch
                            checked={!!row[g.key]}
                            onChange={(v) => {
                              setNotifMatrix((prev) => {
                                const next: NotifMatrix = { ...prev };
                                next[t.id] = { ...next[t.id], [g.key]: v };
                                return next;
                              });
                              if (v) {
                                setEnabledTypes((prev) => (prev.includes(t.id) ? prev : [...prev, t.id]));
                              }
                            }}
                          />
                        </td>
                      ))}
                      <td style={{ textAlign: "center", padding: 12, borderBottom: "1px solid #f1f1f1" }}>
                        <ToggleSwitch
                          checked={rowAll}
                          title="Toggle all groups for this type"
                          onChange={(v) => {
                            setNotifMatrix((prev) => {
                              const next: NotifMatrix = { ...prev };
                              const nrow = { ...next[t.id] };
                              for (const g of NOTIFY_GROUPS) nrow[g.key] = v;
                              next[t.id] = nrow;
                              return next;
                            });
                            if (v) {
                              setEnabledTypes((prev) => (prev.includes(t.id) ? prev : [...prev, t.id]));
                            }
                          }}
                        />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <div style={{ marginTop: 12, padding: "10px 12px", border: "1px solid #eee", borderRadius: 12, background: "#fafafa" }}>
            <div style={{ fontSize: 12, fontWeight: 800, marginBottom: 6 }}>Will be saved</div>
            <div style={{ fontSize: 12, opacity: 0.85, lineHeight: 1.4 }}>
              <div>
                <b>Enabled types:</b>{" "}
                {enabledTypes.length === 0 ? "None" : enabledTypes.slice().sort((a, b) => a - b).join(", ")}
              </div>
              <div style={{ marginTop: 4 }}>
                <b>Recipient groups:</b>{" "}
                {NOTIFY_GROUPS.filter((g) => derivedNotify[g.key]).map((g) => g.label).join(", ") || "None"}
              </div>
              <div style={{ marginTop: 4 }} title={emails.join(", ") || undefined}>
                <b>Extra emails:</b> {emails.length}
              </div>
            </div>
          </div>

          <div style={{ fontWeight: 800, marginTop: 14, marginBottom: 6 }}>Extra recipients (name + email)</div>

          <div style={{ overflowX: "auto", border: "1px solid #eee", borderRadius: 12 }}>
            <table style={{ width: "100%", borderCollapse: "collapse", minWidth: 620 }}>
              <thead>
                <tr style={{ background: "#f8fafc" }}>
                  <th style={{ textAlign: "left", padding: 12, borderBottom: "1px solid #eee" }}>Name</th>
                  <th style={{ textAlign: "left", padding: 12, borderBottom: "1px solid #eee" }}>Email</th>
                  <th style={{ textAlign: "center", padding: 12, borderBottom: "1px solid #eee", width: 90 }}>Remove</th>
                </tr>
              </thead>
              <tbody>
                {extraRecipients.length === 0 && (
                  <tr>
                    <td colSpan={3} style={{ padding: 12, opacity: 0.7 }}>
                      No extra recipients added.
                    </td>
                  </tr>
                )}
                {extraRecipients.map((r) => (
                  <tr key={r.id}>
                    <td style={{ padding: 12, borderBottom: "1px solid #f1f1f1" }}>
                      <input
                        style={{ width: "100%", boxSizing: "border-box" }}
                        value={r.name}
                        onChange={(e) => {
                          const v = e.target.value;
                          setExtraRecipients((prev) => prev.map((x) => (x.id === r.id ? { ...x, name: v } : x)));
                        }}
                        placeholder="Name"
                      />
                    </td>
                    <td style={{ padding: 12, borderBottom: "1px solid #f1f1f1" }}>
                      <input
                        style={{ width: "100%", boxSizing: "border-box" }}
                        value={r.email}
                        onChange={(e) => {
                          const v = e.target.value;
                          setExtraRecipients((prev) => prev.map((x) => (x.id === r.id ? { ...x, email: v } : x)));
                        }}
                        placeholder="person@example.com"
                      />
                    </td>
                    <td style={{ textAlign: "center", padding: 12, borderBottom: "1px solid #f1f1f1" }}>
                      <button
                        type="button"
                        onClick={() => setExtraRecipients((prev) => prev.filter((x) => x.id !== r.id))}
                        title="Remove"
                      >
                        ✕
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div style={{ marginTop: 8, display: "flex", gap: 8, flexWrap: "wrap" }}>
            <button
              type="button"
              onClick={() =>
                setExtraRecipients((prev) => [...prev, { id: `r_${Math.random().toString(36).slice(2)}_${Date.now()}`, name: "", email: "" }])
              }
            >
              + Add recipient
            </button>
            {extraRecipients.length > 0 && (
              <button type="button" onClick={() => setExtraRecipients([])}>
                Clear recipients
              </button>
            )}
          </div>

          <div style={{ fontWeight: 800, marginTop: 14, marginBottom: 6 }}>Or paste extra emails</div>
          <textarea
            style={{ width: "100%", maxWidth: "100%", minHeight: 90, boxSizing: "border-box", display: "block" }}
            value={extraEmailsText}
            onChange={(e) => setExtraEmailsText(e.target.value)}
            placeholder="person1@example.com, person2@example.com"
          />

          <div style={{ marginTop: 14, display: "flex", gap: 8 }}>
            <button type="button" onClick={() => setStep(1)}>
              Back
            </button>
            <button disabled={!canGoStep3} onClick={() => setStep(3)}>
              Next
            </button>
          </div>
        </div>
      )}

      {/* Step 1 */}
      {step === 1 && (
        <div className="card" style={{ padding: 18 }}>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "flex-start",
              gap: 16,
              flexWrap: "wrap",
              marginBottom: 18,
            }}
          >
            <div>
              <div style={{ fontSize: 18, fontWeight: 900, color: "#0f172a" }}>1) Project details</div>
            </div>

            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              <StepBadge tone={requiredDoneCount === 6 ? "success" : "soft"}>{requiredDoneCount}/6 required done</StepBadge>
              <StepBadge tone="neutral">{setupSummaryCount} optional added</StepBadge>
            </div>
          </div>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(340px, 1fr))",
              gap: 16,
              alignItems: "stretch",
            }}
          >
            <SectionCard
              title="Basic information"
              right={<StepBadge tone="soft">Required</StepBadge>}
            >
              <div style={{ display: "grid", gap: 14 }}>
                <div>
                  <div style={{ fontSize: 12, fontWeight: 800, color: "#0f172a", marginBottom: 4 }}>Project name *</div>
                  <input
                    style={{ width: "100%", maxWidth: "100%", boxSizing: "border-box", display: "block" }}
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="Enter project name"
                  />
                  {trimmedProjectName ? (
                    <div
                      style={{
                        marginTop: 8,
                        fontSize: 12,
                        fontWeight: 700,
                        color: projectNameCheck.loading
                          ? "#475569"
                          : projectNameAlreadyExists
                            ? "#b91c1c"
                            : projectNameCheckSettledForCurrentValue && projectNameCheck.available === true
                              ? "#166534"
                              : "#64748b",
                      }}
                    >
                      {projectNameCheck.loading
                        ? "Checking project name..."
                        : projectNameCheckSettledForCurrentValue
                          ? projectNameCheck.message
                          : "Project name will be checked automatically."}
                    </div>
                  ) : null}
                </div>

                <div
                  style={{
                    padding: 14,
                    borderRadius: 14,
                    background: "#f8fafc",
                    border: "1px solid rgba(148,163,184,0.18)",
                    display: "grid",
                    gap: 10,
                  }}
                >
                  <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
                    <div style={{ fontSize: 12, fontWeight: 800, color: "#0f172a" }}>Project number *</div>
                    <StepBadge tone={projectCode || autoPreview ? "success" : "neutral"}>
                      {projectCode ? "Manual" : autoPreview ? "Auto preview ready" : canAuto ? "Auto available" : "Manual only"}
                    </StepBadge>
                  </div>

                  <input
                    style={{ width: "100%", maxWidth: "100%", boxSizing: "border-box", display: "block" }}
                    value={projectCode}
                    onChange={(e) => {
                      setProjectCode(e.target.value);
                      if (autoPreviewErr) setAutoPreviewErr("");
                    }}
                    placeholder={canManual ? "Leave blank to auto-generate" : "Manual disabled (no permission)"}
                    disabled={!canManual}
                  />


                  <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
                    <button
                      type="button"
                      onClick={onPreviewAuto}
                      disabled={!canAuto || autoPreviewLoading}
                      style={{ borderRadius: 12, padding: "9px 14px" }}
                    >
                      {autoPreviewLoading ? "Previewing…" : "Preview auto number"}
                    </button>
                    {autoPreview ? (
                      <div style={{ fontSize: 13, color: "#0f172a" }}>
                        Next number: <b>{autoPreview}</b>
                      </div>
                    ) : null}
                  </div>

                  {autoPreviewErr ? (
                    <div style={{ fontSize: 12, color: "#b42318", fontWeight: 700 }}>
                      {autoPreviewErr}
                    </div>
                  ) : null}
                </div>
              </div>
            </SectionCard>

            <SectionCard
              title="Client structure"
              right={<StepBadge tone="soft">Required</StepBadge>}
            >
              <div style={{ display: "grid", gap: 14 }}>
                <SearchSelect
                  label="Advertiser Group *"
                  value={advertiserGroupId}
                  onChange={(id) => setAdvertiserGroupId(id)}
                  options={data.advertiserGroups}
                  placeholder="Search advertiser group"
                  rightElement={
                    canAddAdvGroup ? <InlineAddButton title="Add advertiser group" onClick={inlineCreateAdvertiserGroup} /> : null
                  }
                />

                <SearchSelect
                  label="Advertiser *"
                  value={advertiserId}
                  onChange={setAdvertiserId}
                  options={data.advertisers}
                  placeholder="Search advertiser"
                  rightElement={
                    canAddAdvertiser ? <InlineAddButton title="Add advertiser" onClick={inlineCreateAdvertiser} /> : null
                  }
                />

                <SearchSelect
                  label="Brand *"
                  value={brandId}
                  onChange={setBrandId}
                  options={data.brands}
                  placeholder="Search brand"
                  rightElement={
                    canAddBrand ? <InlineAddButton title="Add brand" onClick={inlineCreateBrand} /> : null
                  }
                />

                <SearchSelect
                  label="Product Category *"
                  value={productCategoryId}
                  onChange={setProductCategoryId}
                  options={data.productCategories}
                  placeholder="Search product category"
                  rightElement={
                    canAddProductCategory ? (
                      <InlineAddButton title="Add product category" onClick={inlineCreateProductCategory} />
                    ) : null
                  }
                />

                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 10, marginTop: 8 }}>
                  <BillingSummaryTile label="Billing Source" value={selectedBillingSource?.value || ""} tone="blue" />
                  <BillingSummaryTile label="Project Rate Card" value={selectedRateCard?.name || ""} tone="emerald" />
                </div>
              </div>
            </SectionCard>

            <SectionCard
              title="Sender account"
              right={<StepBadge tone="neutral">{senderMatches.length ? `${senderMatches.length} match${senderMatches.length === 1 ? "" : "es"}` : "No match"}</StepBadge>}
            >
              <div style={{ display: "grid", gap: 12 }}>
                <SearchSelect
                  label="Sender Account"
                  value={senderAccountId}
                  onChange={setSenderAccountId}
                  options={senderAccountOptions}
                  placeholder="Search sender account"
                />
                <SenderAccountContextCard
                  matches={senderMatches}
                  emptyHint=""
                />
              </div>
            </SectionCard>
          </div>

          <div
            style={{
              marginTop: 16,
              border: "1px solid rgba(15,23,42,0.08)",
              borderRadius: 18,
              overflow: "hidden",
              background: "#fff",
            }}
          >
            <button
              type="button"
              onClick={() => setShowOptionalAssignments((v) => !v)}
              style={{
                width: "100%",
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                gap: 12,
                padding: "16px 18px",
                border: 0,
                background: "linear-gradient(180deg, #ffffff 0%, #f8fafc 100%)",
                cursor: "pointer",
                fontWeight: 800,
                fontSize: 15,
              }}
            >
              <span style={{ display: "grid", gap: 4, textAlign: "left" }}>
                <span>Optional assignments</span>
                <span style={{ fontSize: 12, color: "#64748b", fontWeight: 500 }}>
                  
                </span>
              </span>
              <span style={{ display: "inline-flex", alignItems: "center", gap: 8 }}>
                <StepBadge tone="neutral">{setupSummaryCount} filled</StepBadge>
                <span aria-hidden="true" style={{ fontSize: 18 }}>{showOptionalAssignments ? "−" : "+"}</span>
              </span>
            </button>

            {showOptionalAssignments && (
              <div style={{ padding: 18, borderTop: "1px solid rgba(15,23,42,0.08)", display: "grid", gap: 16 }}>
                <div
                  style={{
                    padding: 14,
                    borderRadius: 14,
                    background: "#f8fafc",
                    border: "1px solid rgba(148,163,184,0.18)",
                  }}
                >
                  <label style={{ display: "flex", gap: 10, alignItems: "center" }}>
                    <input
                      type="checkbox"
                      checked={approvalsEnabled}
                      onChange={(e) => setApprovalsEnabled(e.target.checked)}
                    />
                    <span style={{ fontWeight: 700, color: "#0f172a" }}>Enable approvals for this project</span>
                  </label>
                  
                </div>

                <SectionCard title="Project billing" right={<StepBadge tone="soft">Optional</StepBadge>}>
                  <div style={{ display: "grid", gap: 12 }}>
                    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: 14, alignItems: "start" }}>
                      <div style={{ display: "grid", gap: 12 }}>
                        <BillingSourceSelector options={billingSourceOptions} selectedKey={billingSourceKey} onChange={(next) => { setBillingSourceKey(next); }} />
                        <SearchSelect
                          label="Rate Card"
                          value={selectedRateCardId}
                          onChange={setSelectedRateCardId}
                          options={rateCardOptions}
                          placeholder="Search rate card"
                        />
                      </div>
                      <div style={{ display: "grid", gap: 12 }}>
                        <BillingAgencySelector options={billingAgencyOptions} selectedKeys={billingAgencyKeys} onToggle={toggleBillingAgencyKey} />
                      </div>
                    </div>
                  </div>
                </SectionCard>

                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: 16 }}>
                  <SectionCard title="Media">
                    <div style={{ display: "grid", gap: 8 }}>
                      <SearchSelect
                        label="Media Agency"
                        value={mediaAgencyId}
                        onChange={(id) => {
                          setMediaAgencyId(id);
                          setMediaAgencyTeamId("");
                        }}
                        options={agenciesOf("MEDIA")}
                        placeholder="Search media agency"
                        allowClear
                        rightElement={
                          canAddAgency ? (
                            <InlineAddButton
                              title="Add media agency"
                              onClick={() =>
                                inlineCreateAgency("MEDIA", (id) => {
                                  setMediaAgencyId(id);
                                  setMediaAgencyTeamId("");
                                })
                              }
                            />
                          ) : null
                        }
                      />
                      <EmailsHint emails={mediaA?.emails} />
                      <SearchSelect
                        label="Media Agency Team"
                        value={mediaAgencyTeamId}
                        onChange={setMediaAgencyTeamId}
                        options={teamsOf(mediaAgencyId)}
                        placeholder="Search media team"
                        disabled={!mediaAgencyId}
                        allowClear
                        rightElement={
                          canAddAgencyTeam ? (
                            <InlineAddButton
                              title="Add media team"
                              onClick={() => inlineCreateAgencyTeam(mediaAgencyId, setMediaAgencyTeamId)}
                            />
                          ) : null
                        }
                      />
                      <EmailsHint emails={mediaT?.emails} />
                    </div>
                  </SectionCard>

                  <SectionCard title="Creative">
                    <div style={{ display: "grid", gap: 8 }}>
                      <SearchSelect
                        label="Creative Agency"
                        value={creativeAgencyId}
                        onChange={(id) => {
                          setCreativeAgencyId(id);
                          setCreativeAgencyTeamId("");
                        }}
                        options={agenciesOf("CREATIVE")}
                        placeholder="Search creative agency"
                        allowClear
                        rightElement={
                          canAddAgency ? (
                            <InlineAddButton
                              title="Add creative agency"
                              onClick={() =>
                                inlineCreateAgency("CREATIVE", (id) => {
                                  setCreativeAgencyId(id);
                                  setCreativeAgencyTeamId("");
                                })
                              }
                            />
                          ) : null
                        }
                      />
                      <EmailsHint emails={creativeA?.emails} />
                      <SearchSelect
                        label="Creative Agency Team"
                        value={creativeAgencyTeamId}
                        onChange={setCreativeAgencyTeamId}
                        options={teamsOf(creativeAgencyId)}
                        placeholder="Search creative team"
                        disabled={!creativeAgencyId}
                        allowClear
                        rightElement={
                          canAddAgencyTeam ? (
                            <InlineAddButton
                              title="Add creative team"
                              onClick={() => inlineCreateAgencyTeam(creativeAgencyId, setCreativeAgencyTeamId)}
                            />
                          ) : null
                        }
                      />
                      <EmailsHint emails={creativeT?.emails} />
                    </div>
                  </SectionCard>

                  <SectionCard title="Production">
                    <div style={{ display: "grid", gap: 8 }}>
                      <SearchSelect
                        label="Production House"
                        value={productionHouseId}
                        onChange={(id) => {
                          setProductionHouseId(id);
                          setProductionHouseTeamId("");
                        }}
                        options={agenciesOf("PRODUCTION_HOUSE")}
                        placeholder="Search production house"
                        allowClear
                        rightElement={
                          canAddAgency ? (
                            <InlineAddButton
                              title="Add production house"
                              onClick={() =>
                                inlineCreateAgency("PRODUCTION_HOUSE", (id) => {
                                  setProductionHouseId(id);
                                  setProductionHouseTeamId("");
                                })
                              }
                            />
                          ) : null
                        }
                      />
                      <EmailsHint emails={productionA?.emails} />
                      <SearchSelect
                        label="Production House Team"
                        value={productionHouseTeamId}
                        onChange={setProductionHouseTeamId}
                        options={teamsOf(productionHouseId)}
                        placeholder="Search production team"
                        disabled={!productionHouseId}
                        allowClear
                        rightElement={
                          canAddAgencyTeam ? (
                            <InlineAddButton
                              title="Add production team"
                              onClick={() => inlineCreateAgencyTeam(productionHouseId, setProductionHouseTeamId)}
                            />
                          ) : null
                        }
                      />
                      <EmailsHint emails={productionT?.emails} />
                    </div>
                  </SectionCard>

                  <SectionCard title="Post house">
                    <div style={{ display: "grid", gap: 8 }}>
                      <SearchSelect
                        label="Post House"
                        value={postHouseId}
                        onChange={(id) => {
                          setPostHouseId(id);
                          setPostHouseTeamId("");
                        }}
                        options={agenciesOf("POST_HOUSE")}
                        placeholder="Search post house"
                        allowClear
                        rightElement={
                          canAddAgency ? (
                            <InlineAddButton
                              title="Add post house"
                              onClick={() =>
                                inlineCreateAgency("POST_HOUSE", (id) => {
                                  setPostHouseId(id);
                                  setPostHouseTeamId("");
                                })
                              }
                            />
                          ) : null
                        }
                      />
                      <EmailsHint emails={postA?.emails} />
                      <SearchSelect
                        label="Post House Team"
                        value={postHouseTeamId}
                        onChange={setPostHouseTeamId}
                        options={teamsOf(postHouseId)}
                        placeholder="Search post team"
                        disabled={!postHouseId}
                        allowClear
                        rightElement={
                          canAddAgencyTeam ? (
                            <InlineAddButton
                              title="Add post team"
                              onClick={() => inlineCreateAgencyTeam(postHouseId, setPostHouseTeamId)}
                            />
                          ) : null
                        }
                      />
                      <EmailsHint emails={postT?.emails} />
                    </div>
                  </SectionCard>

                  <SectionCard title="Audio">
                    <div style={{ display: "grid", gap: 8 }}>
                      <SearchSelect
                        label="Audio Agency"
                        value={audioAgencyId}
                        onChange={(id) => {
                          setAudioAgencyId(id);
                          setAudioAgencyTeamId("");
                        }}
                        options={agenciesOf("AUDIO")}
                        placeholder="Search audio agency"
                        allowClear
                        rightElement={
                          canAddAgency ? (
                            <InlineAddButton
                              title="Add audio agency"
                              onClick={() =>
                                inlineCreateAgency("AUDIO", (id) => {
                                  setAudioAgencyId(id);
                                  setAudioAgencyTeamId("");
                                })
                              }
                            />
                          ) : null
                        }
                      />
                      <EmailsHint emails={audioA?.emails} />
                      <SearchSelect
                        label="Audio Agency Team"
                        value={audioAgencyTeamId}
                        onChange={setAudioAgencyTeamId}
                        options={teamsOf(audioAgencyId)}
                        placeholder="Search audio team"
                        disabled={!audioAgencyId}
                        allowClear
                        rightElement={
                          canAddAgencyTeam ? (
                            <InlineAddButton
                              title="Add audio team"
                              onClick={() => inlineCreateAgencyTeam(audioAgencyId, setAudioAgencyTeamId)}
                            />
                          ) : null
                        }
                      />
                      <EmailsHint emails={audioT?.emails} />
                    </div>
                  </SectionCard>

                  <SectionCard title="Uploader + remarks">
                    <div style={{ display: "grid", gap: 8 }}>
                      <SearchSelect
                        label="Uploader Agency"
                        value={uploaderAgencyId}
                        onChange={(id) => {
                          setUploaderAgencyId(id);
                          setUploaderAgencyTeamId("");
                        }}
                        options={allAgencies()}
                        placeholder="Search uploader agency"
                        allowClear
                        rightElement={
                          canAddAgency ? (
                            <InlineAddButton
                              title="Add uploader agency"
                              onClick={() =>
                                inlineCreateAgency("UPLOADER", (id) => {
                                  setUploaderAgencyId(id);
                                  setUploaderAgencyTeamId("");
                                })
                              }
                            />
                          ) : null
                        }
                      />
                      <EmailsHint emails={uploaderA?.emails} />
                      <SearchSelect
                        label="Uploader Agency Team"
                        value={uploaderAgencyTeamId}
                        onChange={setUploaderAgencyTeamId}
                        options={teamsOf(uploaderAgencyId)}
                        placeholder="Search uploader team"
                        disabled={!uploaderAgencyId}
                        allowClear
                        rightElement={
                          canAddAgencyTeam ? (
                            <InlineAddButton
                              title="Add uploader team"
                              onClick={() => inlineCreateAgencyTeam(uploaderAgencyId, setUploaderAgencyTeamId)}
                            />
                          ) : null
                        }
                      />
                      <EmailsHint emails={uploaderT?.emails} />
                      <div style={{ display: "grid", gap: 4, marginTop: 6 }}>
                        <div style={{ fontSize: 12, fontWeight: 800, color: "#0f172a" }}>Remarks</div>
                        <textarea
                          value={remarks}
                          onChange={(e) => setRemarks(e.target.value)}
                          placeholder="Any notes for this project…"
                          rows={3}
                          style={{ width: "100%" }}
                        />
                      </div>
                    </div>
                  </SectionCard>
                </div>
              </div>
            )}
          </div>

          <div style={{ marginTop: 18, display: "flex", justifyContent: "space-between", gap: 10, flexWrap: "wrap", alignItems: "center" }}>
            <button disabled={!canGoStep2} onClick={() => setStep(2)} style={{ minWidth: 140 }}>
              Next
            </button>
          </div>
        </div>
      )}

      {/* Step 3 */}
      {step === 3 && (
        <div className="card" style={{ padding: 18 }}>
          <div
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "flex-start",
              gap: 16,
              flexWrap: "wrap",
              marginBottom: 18,
            }}
          >
            <div>
              <div style={{ fontSize: 18, fontWeight: 900, color: "#0f172a" }}>3) Review & create</div>
            </div>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              <StepBadge tone="soft">Final check</StepBadge>
              <StepBadge tone="neutral">Ready to create</StepBadge>
            </div>
          </div>

          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))",
              gap: 16,
              alignItems: "start",
            }}
          >
            <SectionCard title="Project summary" right={<StepBadge tone="soft">Core</StepBadge>}>
              <div style={{ display: "grid", gap: 10 }}>
                <SelectionSummary label="Project name" value={name || ""} />
                <SelectionSummary label="Manual project number" value={projectCode || "(auto)"} />
                <SelectionSummary
                  label="Approvals"
                  value={approvalsEnabled ? "Enabled" : "Disabled"}
                />
                <SelectionSummary
                  label="Sender Account"
                  value={senderAccountOptions.find((item) => item.id === senderAccountId)?.name || "(not linked)"}
                />
                <SelectionSummary
                  label="Billing Source"
                  value={selectedBillingSource?.value || "(not linked)"}
                />
                <SelectionSummary
                  label="Rate Card"
                  value={selectedRateCard?.name || "(not linked)"}
                />
              </div>
            </SectionCard>

            <SectionCard title="Client structure" right={<StepBadge tone="soft">Classification</StepBadge>}>
              <div style={{ display: "grid", gap: 10 }}>
                <SelectionSummary label="Advertiser Group" value={findName(data.advertiserGroups, advertiserGroupId)} />
                <SelectionSummary label="Advertiser" value={findName(data.advertisers, advertiserId)} />
                <SelectionSummary label="Brand" value={findName(data.brands, brandId)} />
                <SelectionSummary label="Product Category" value={findName(data.productCategories, productCategoryId)} />
              </div>
            </SectionCard>

            <SectionCard title="Agency assignments" right={<StepBadge tone="soft">Optional</StepBadge>}>
              <div style={{ display: "grid", gap: 10 }}>
                <SelectionSummary label="Media" value={`${mediaA?.name || "(none)"}${mediaT ? ` / ${mediaT.name}` : ""}`} />
                <SelectionSummary label="Creative" value={`${creativeA?.name || "(none)"}${creativeT ? ` / ${creativeT.name}` : ""}`} />
                <SelectionSummary label="Production House" value={`${productionA?.name || "(none)"}${productionT ? ` / ${productionT.name}` : ""}`} />
                <SelectionSummary label="Post House" value={`${postA?.name || "(none)"}${postT ? ` / ${postT.name}` : ""}`} />
                <SelectionSummary label="Audio" value={`${audioA?.name || "(none)"}${audioT ? ` / ${audioT.name}` : ""}`} />
                <SelectionSummary label="Uploader" value={`${uploaderA?.name || "(none)"}${uploaderT ? ` / ${uploaderT.name}` : ""}`} />
              </div>
            </SectionCard>

            <SectionCard title="Notifications" right={<StepBadge tone="soft">Step 2</StepBadge>}>
              <div style={{ display: "grid", gap: 10 }}>
                <SelectionSummary
                  label="Enabled types"
                  value={enabledTypes.length ? enabledTypes.slice().sort((a, b) => a - b).join(", ") : "(none)"}
                />
                <SelectionSummary
                  label="Recipient groups"
                  value={NOTIFY_GROUPS.filter((g) => derivedNotify[g.key]).map((g) => g.label).join(", ") || "(none)"}
                />
                <SelectionSummary label="Extra emails" value={emails.join(", ") || "(none)"} />
              </div>
            </SectionCard>

            <div style={{ gridColumn: "1 / -1" }}>
              <SectionCard title="Additional details" right={<StepBadge tone="soft">Notes</StepBadge>}>
                <div style={{ display: "grid", gap: 10 }}>
                  <SelectionSummary
                    label="Sender Account matches"
                    value={senderMatches.length ? senderMatches.map((item) => `${item.name} (${item.matchedBy.join(", ")})`).join(" • ") : "(none)"}
                  />
                  <div
                    style={{
                      padding: "12px 14px",
                      borderRadius: 14,
                      background: "#f8fafc",
                      border: "1px solid rgba(148,163,184,0.18)",
                    }}
                  >
                    <div style={{ fontSize: 12, fontWeight: 700, color: "#475569", marginBottom: 6 }}>Remarks</div>
                    <div style={{ fontSize: 13, color: remarks?.trim() ? "#0f172a" : "#94a3b8", whiteSpace: "pre-wrap", lineHeight: 1.5 }}>
                      {remarks?.trim() || "(none)"}
                    </div>
                  </div>
                </div>
              </SectionCard>
            </div>
          </div>

          {submitErr && (
            <div className="card" style={{ borderColor: "#f5a", background: "#fff5fa", marginTop: 16 }}>
              {submitErr}
            </div>
          )}

          <div style={{ marginTop: 16, display: "flex", justifyContent: "flex-end", gap: 10, flexWrap: "wrap", alignItems: "center" }}>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              <button onClick={() => setStep(2)} disabled={submitting}>
                Back
              </button>
              <button onClick={onCreate} disabled={submitting || projectNameCheck.loading || projectNameAlreadyExists}>
                {submitting ? "Creating…" : "Create project"}
              </button>
            </div>
          </div>
        </div>
      )}

      <InlineNamePrompt
        open={inlinePromptOpen}
        title={inlinePromptTitle}
        value={inlinePromptValue}
        onChange={setInlinePromptValue}
        onCancel={() => closeInlinePrompt(null)}
        onConfirm={confirmInlinePrompt}
      />
    </div>
  );
}
