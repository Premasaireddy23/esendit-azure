export type IdName = { id: string; name: string; code?: string | null };

export type AgencyType = "MEDIA" | "CREATIVE" | "POST_HOUSE" | "PRODUCTION_HOUSE" | "AUDIO" | "UPLOADER";

export type Agency = {
  id: string;
  name: string;
  type: AgencyType;
  emails?: string[];
  status?: string;
};

export type AgencyTeam = {
  id: string;
  agencyId: string;
  name: string;
  emails?: string[];
  status?: string;
};

export type PartnerAccountSummary = {
  id: string;
  name: string;
  accountType?: "SENDER" | "RECEIVER";
  receiverCategory?: string | null;
  emails?: string[];
};

export type WizardMeta = {
  advertiserGroups: IdName[];
  advertisers: IdName[];
  brands: IdName[];
  productCategories: IdName[];

  // ✅ backend supports these in /projects/wizard/meta
  agencies: Agency[];
  agencyTeams: AgencyTeam[];
  senderAccounts: PartnerAccountSummary[];
  billableParties: IdName[];
};

export type WizardNotification = {
  notifyAdvertiserGroup?: boolean;
  notifyAdvertiser?: boolean;
  notifyBrand?: boolean;
  notifyMediaAgency?: boolean;
  notifyCreativeAgency?: boolean;
  notifyPostHouse?: boolean;
  notifyAudioAgency?: boolean;
  notifyProductionHouse?: boolean;
  extraEmails?: string[];
  enabledTypes?: number[];
};

export type CreateWizardProjectPayload = {
  projectCode?: string;

  name: string;
  advertiserGroupId: string;
  advertiserId: string;
  brandId: string;
  productCategoryId: string;
  senderAccountId?: string;
  billablePartyId?: string;

  // ✅ backend supports these in POST /projects/wizard
  approvalsEnabled?: boolean;

  mediaAgencyId?: string;
  mediaAgencyTeamId?: string;

  creativeAgencyId?: string;
  creativeAgencyTeamId?: string;

  productionHouseId?: string;
  productionHouseTeamId?: string;

  postHouseId?: string;
  postHouseTeamId?: string;

  audioAgencyId?: string;
  audioAgencyTeamId?: string;

  // NEW: uploader + remarks
  uploaderAgencyId?: string;
  uploaderAgencyTeamId?: string;
  remarks?: string;

  notification: WizardNotification;
};

export type CreatedProjectResponse = {
  id: string;
  name: string;
  projectCode?: string | null;
  projectNumber: string;
};
