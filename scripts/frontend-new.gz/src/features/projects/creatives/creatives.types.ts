export type CreativeQcStatus = "NOT_STARTED" | "IN_PROGRESS" | "PASSED" | "FAILED";

export type CreativeAssetType = "SOURCE" | "PROXY" | "OUTPUT";

// keep loose: your backend enum may include more values over time
export type CreativeAssetUploadStatus =
  | "PENDING"
  | "UPLOADING"
  | "UPLOADED"
  | "FAILED"
  | string;

export type CreativeAsset = {
  id: string;
  type: CreativeAssetType;
  path?: string | null;

  filename?: string | null;
  mimeType?: string | null;

  // BigInt often serializes as string
  sizeBytes?: number | string | null;
  bytesTotal?: number | string | null;
  bytesReceived?: number | string | null;

  uploadStatus?: CreativeAssetUploadStatus | null;
  speedBps?: number | null;

  uploadStartedAt?: string | null;
  uploadEndedAt?: string | null;

  error?: string | null;

  createdAt?: string;
  updatedAt?: string;
};

export type Creative = {
  id: string;
  projectId: string;

  name: string;

  valid?: string | null;
  caption?: string | null;
  format?: string | null;
  languages?: string[];
  duration?: string | null;
  remarks?: string | null;

  qcStatus?: CreativeQcStatus | null;
  qcNotes?: string | null;

  // P1.8
  qcFailureReasons?: string[];
  qcReport?: any;
  autoQcStartedAt?: string | null;
  autoQcEndedAt?: string | null;

  assets?: CreativeAsset[];

  createdAt?: string;
  updatedAt?: string;
};

export type CreativeUpsertItem = {
  id?: string;
  name?: string;
  valid?: string | null;
  caption?: string | null;
  format?: string | null;
  languages?: string[];
  duration?: string | null;
  remarks?: string | null;
};

export type MediaJob = {
  id: string;
  type: "AUTO_QC" | "PROXY_GEN" | string;
  status: "PENDING" | "RUNNING" | "SUCCEEDED" | "FAILED" | string;
  attempts?: number;
  error?: string | null;
  createdAt?: string;
  startedAt?: string | null;
  endedAt?: string | null;
};
