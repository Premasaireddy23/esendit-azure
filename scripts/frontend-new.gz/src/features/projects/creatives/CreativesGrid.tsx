import { useEffect, useRef, useState } from "react";
import { useParams } from "react-router-dom";
import { getCreativeCodeLabel, getMe, type MeResponse } from "../../../lib/me";

import type { Creative, CreativeAsset, CreativeUpsertItem } from "./creatives.types";
import {
  bulkUpsertCreatives,
  deleteCreative,
  listCreatives,
  removeCreativeSource,
  uploadCreativeSourceWithProgress,
} from "./creativesApi";

type RowModel = {
  _tmpId: string;
  id?: string;

  name?: string;
  valid?: string | null;
  caption?: string | null;
  format?: string | null;
  languagesText?: string;
  duration?: string | null;
  remarks?: string | null;

  // read-only
  audioText?: string | null;

  // kept for backend state, but not shown here (QC is a separate page)
  qcStatus?: string | null;

  assets?: CreativeAsset[];
};

function audioToText(c: Creative): string | null {
  const a: any = (c as any).audio;
  if (!a) return null;

  const ch = a.channels != null ? `${a.channels}ch` : null;
  const codec = a.codec ? String(a.codec) : null;
  const lang = a.language ? String(a.language).toUpperCase() : null;

  const base = [ch, codec].filter(Boolean).join(" ");
  return lang ? `${base} (${lang})`.trim() : base || null;
}

function toRowModel(c: Creative): RowModel {
  return {
    _tmpId: c.id,
    id: c.id,

    name: c.name,
    valid: c.valid ?? null,
    caption: c.caption ?? null,
    format: c.format ?? null,
    languagesText: (c.languages || []).join(", "),
    duration: c.duration ?? null,
    remarks: c.remarks ?? null,

    audioText: audioToText(c),

    qcStatus: (c as any).qcStatus ?? null,
    assets: c.assets || [],
  };
}

function parseLanguages(text: string | undefined): string[] {
  if (!text) return [];
  return text
    .split(",")
    .map((s) => s.trim())
    .filter(Boolean);
}

function getAsset(row: RowModel, type: "SOURCE" | "PROXY" | "OUTPUT") {
  return (row.assets || []).find((a) => a.type === type);
}

function makeTmpId() {
  const c: any = (globalThis as any).crypto;
  if (c?.randomUUID) return c.randomUUID();
  return `tmp_${Date.now().toString(16)}_${Math.random().toString(16).slice(2)}`;
}

export function CreativesGrid(props: { projectId?: string; onChanged?: () => void }) {
  const params = useParams();
  const projectId = props.projectId || (params as any).id || "";

  const [rows, setRows] = useState<RowModel[]>([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState<string>("");
  const [me, setMe] = useState<MeResponse | null>(null);

  useEffect(() => {
    getMe().then(setMe).catch(() => setMe(null));
  }, []);

  const [flash, setFlash] = useState<{ kind: "success" | "error"; message: string } | null>(null);
  const [rowSaving, setRowSaving] = useState<Record<string, boolean>>({});
  const [uploadPctByTmpId, setUploadPctByTmpId] = useState<Record<string, number>>({});
  const [uploadingByTmpId, setUploadingByTmpId] = useState<Record<string, boolean>>({});
  const [uploadErrByTmpId, setUploadErrByTmpId] = useState<Record<string, string>>({});

  const selectedFilesRef = useRef<Record<string, File | null>>({});

  const tdBase: React.CSSProperties = { padding: 8, verticalAlign: "top", overflow: "hidden" };

  const inputBase: React.CSSProperties = {
    width: "100%",
    maxWidth: "100%",
    minWidth: 0,
    boxSizing: "border-box",
    display: "block",
  };

  async function reload() {
    if (!projectId) return;
    setErr("");
    setLoading(true);
    try {
      const data = await listCreatives(projectId);
      setRows((prev) => {
        const unsaved = prev.filter((r) => !r.id);
        return [...data.map(toRowModel), ...unsaved];
      });
    } catch (e: any) {
      setErr(e?.message || String(e));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    reload();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [projectId]);

  function updateRow(tmpId: string, patch: Partial<RowModel>) {
    setRows((prev) => prev.map((r) => (r._tmpId === tmpId ? { ...r, ...patch } : r)));
  }

  function addRow() {
    const tmp = makeTmpId();
    setRows((prev) => [
      ...prev,
      {
        _tmpId: tmp,
        name: "",
        valid: "",
        caption: "",
        format: "",
        languagesText: "",
        duration: "",
        remarks: "",
        audioText: null,
        qcStatus: "NOT_STARTED",
        assets: [],
      },
    ]);
  }

  function showFlash(kind: "success" | "error", message: string) {
    setFlash({ kind, message });
    window.setTimeout(() => setFlash(null), 2500);
  }

  async function saveRow(row: RowModel) {
  setErr("");
  setRowSaving((p) => ({ ...p, [row._tmpId]: true }));

  // Snapshot existing ids to detect the new id when saving a brand-new row.
  const beforeIds = new Set(rows.filter((r) => r.id).map((r) => String(r.id)));

  try {
    const item: CreativeUpsertItem = {
      id: row.id,
      name: row.name || undefined,
      valid: row.valid ?? null,
      caption: row.caption ?? null,
      format: row.format ?? null,
      languages: parseLanguages(row.languagesText),
      duration: row.duration ?? null,
      remarks: row.remarks ?? null,
    };

    const data = await bulkUpsertCreatives(projectId, [item]);

    // Determine savedId (especially for new rows where id was empty)
    let savedId: string | undefined = row.id;

    if (!savedId) {
      if (Array.isArray(data) && data.length === 1 && (data[0] as any)?.id) {
        savedId = String((data[0] as any).id);
      } else if (Array.isArray(data)) {
        const newOnes = data.filter((c: any) => c?.id && !beforeIds.has(String(c.id)));
        if (newOnes.length === 1) savedId = String(newOnes[0].id);
      }
    }

    if (!savedId) {
      // Fallback: rebuild from server (may clear file input selection, but avoids broken state)
      setRows(data.map(toRowModel));
      props.onChanged?.();
      showFlash("success", "Saved");
      return;
    }

    // ✅ Update the SAME row (_tmpId stays the same) so the file input + upload progress state stay attached.
    // Also drop any duplicate row that already has this savedId.
    setRows((prev) =>
      prev
        .map((r) => (r._tmpId === row._tmpId ? { ...r, id: savedId } : r))
        .filter((r) => !(r._tmpId !== row._tmpId && r.id && String(r.id) === String(savedId))),
    );

    props.onChanged?.();
    showFlash("success", "Saved");
  } catch (e: any) {
    const msg = e?.message || String(e);
    setErr(msg);
    showFlash("error", msg);
  } finally {
    setRowSaving((p) => {
      const next = { ...p };
      delete next[row._tmpId];
      return next;
    });
  }
}

  async function saveAll() {
  setErr("");
  setSaving(true);
  try {
    const items: CreativeUpsertItem[] = rows.map((r) => ({
      id: r.id,
      name: r.name || undefined,
      valid: r.valid ?? null,
      caption: r.caption ?? null,
      format: r.format ?? null,
      languages: parseLanguages(r.languagesText),
      duration: r.duration ?? null,
      remarks: r.remarks ?? null,
    }));

    const data = await bulkUpsertCreatives(projectId, items);

    // ✅ After save-all, rebuild from backend (prevents duplicates).
    setRows(data.map(toRowModel));

    // Clear any per-row upload UI state (safe)
    setUploadPctByTmpId({});
    setUploadingByTmpId({});
    setUploadErrByTmpId({});
    selectedFilesRef.current = {};

    props.onChanged?.();
    showFlash("success", "Saved");
  } catch (e: any) {
    const msg = e?.message || String(e);
    setErr(msg);
    showFlash("error", msg);
  } finally {
    setSaving(false);
  }
}

  async function doUploadSource(row: RowModel) {
    setErr("");
    if (!row.id) {
      setErr("Save the row first (no id yet), then upload.");
      return;
    }
    const f = selectedFilesRef.current[row._tmpId];
    if (!f) {
      setErr("Select a file first.");
      return;
    }
    try {
      setUploadingByTmpId((p) => ({ ...p, [row._tmpId]: true }));
      setUploadErrByTmpId((p) => {
        const next = { ...p };
        delete next[row._tmpId];
        return next;
      });
      setUploadPctByTmpId((p) => ({ ...p, [row._tmpId]: 0 }));

      await uploadCreativeSourceWithProgress(row.id, f, (pct) => {
        setUploadPctByTmpId((p) => ({ ...p, [row._tmpId]: pct }));
      });

      selectedFilesRef.current[row._tmpId] = null;
      await reload();
      props.onChanged?.();
      showFlash("success", "Uploaded");
    } catch (e: any) {
      const msg = e?.message || String(e);
      setErr(msg);
      setUploadErrByTmpId((p) => ({ ...p, [row._tmpId]: msg }));
      showFlash("error", msg);
    } finally {
      setUploadingByTmpId((p) => {
        const next = { ...p };
        delete next[row._tmpId];
        return next;
      });
    }
  }

  async function doRemoveSource(row: RowModel) {
    setErr("");
    if (!row.id) return;
    try {
      await removeCreativeSource(row.id);
      await reload();
      props.onChanged?.();
    } catch (e: any) {
      setErr(e?.message || String(e));
    }
  }

  async function doDeleteRow(row: RowModel) {
    setErr("");
    if (!row.id) {
      setRows((prev) => prev.filter((r) => r._tmpId !== row._tmpId));
      return;
    }
    try {
      await deleteCreative(row.id);
      await reload();
      props.onChanged?.();
    } catch (e: any) {
      setErr(e?.message || String(e));
    }
  }

  return (
    <div style={{ display: "grid", gap: 12 }}>
      <div className="card" style={{ display: "flex", gap: 8, alignItems: "center", justifyContent: "space-between" }}>
        <div>
          <h3 style={{ margin: 0 }}>Creatives</h3>
          <div style={{ fontSize: 13, opacity: 0.8 }}>
            Add/update creative metadata and upload SOURCE. Use the QC step for Auto QC + Proxy.
          </div>
        </div>

        <div style={{ display: "flex", gap: 8 }}>
          <button onClick={reload} disabled={loading}>Refresh</button>
          <button onClick={addRow} disabled={loading}>Add row</button>
          <button onClick={saveAll} disabled={saving || loading}>
            {saving ? "Saving..." : "Save all"}
          </button>
        </div>
      </div>

      {err ? (
        <div className="card" style={{ border: "1px solid #ffb3b3" }}>
          <div style={{ fontSize: 13, color: "#a10000" }}>{err}</div>
        </div>
      ) : null}

      {flash ? (
        <div className="card" style={{ border: `1px solid ${flash.kind === "success" ? "rgba(0,150,0,0.25)" : "#ffb3b3"}` }}>
          <div style={{ fontSize: 13, color: flash.kind === "success" ? "#0b5" : "#a10000" }}>{flash.message}</div>
        </div>
      ) : null}

      <div className="card" style={{ overflowX: "auto" }}>
        <table style={{ width: "100%", minWidth: 1500, tableLayout: "fixed", borderCollapse: "collapse", fontSize: 13 }}>
          <colgroup>
            <col style={{ width: 160 }} />
            <col style={{ width: 260 }} />
            <col style={{ width: 140 }} />
            <col style={{ width: 170 }} />
            <col style={{ width: 220 }} />
            <col style={{ width: 150 }} />
            <col style={{ width: 260 }} />
            <col style={{ width: 420 }} />
            <col style={{ width: 200 }} />
          </colgroup>

          <thead>
            <tr style={{ textAlign: "left", borderBottom: "1px solid rgba(0,0,0,0.1)" }}>
              <th style={tdBase}>{getCreativeCodeLabel(me)}</th>
              <th style={tdBase}>Caption</th>
              <th style={tdBase}>Format</th>
              <th style={tdBase}>Audio</th>
              <th style={tdBase}>Languages</th>
              <th style={tdBase}>Duration</th>
              <th style={tdBase}>Remarks</th>
              <th style={tdBase}>Source</th>
              <th style={tdBase}>Actions</th>
            </tr>
          </thead>

          <tbody>
            {rows.map((r) => {
              const source = getAsset(r, "SOURCE");
              const uploading = !!uploadingByTmpId[r._tmpId];
              const pct = uploadPctByTmpId[r._tmpId] ?? 0;
              const uploadErr = uploadErrByTmpId[r._tmpId];
              const isRowSaving = !!rowSaving[r._tmpId];

              return (
                <tr key={r._tmpId} style={{ borderBottom: "1px solid rgba(0,0,0,0.06)" }}>
                  <td style={tdBase}>
                    <input value={r.valid ?? ""} onChange={(e) => updateRow(r._tmpId, { valid: e.target.value })} style={inputBase} />
                  </td>
                  <td style={tdBase}>
                    <input value={r.caption ?? ""} onChange={(e) => updateRow(r._tmpId, { caption: e.target.value })} style={inputBase} />
                  </td>
                  <td style={tdBase}>
                    <input value={r.format ?? ""} onChange={(e) => updateRow(r._tmpId, { format: e.target.value })} style={inputBase} />
                  </td>
                  <td style={tdBase}><span style={{ opacity: r.audioText ? 1 : 0.6 }}>{r.audioText || "—"}</span></td>
                  <td style={tdBase}>
                    <input value={r.languagesText ?? ""} onChange={(e) => updateRow(r._tmpId, { languagesText: e.target.value })} placeholder="EN, HI" style={inputBase} />
                  </td>
                  <td style={tdBase}>
                    <input value={r.duration ?? ""} onChange={(e) => updateRow(r._tmpId, { duration: e.target.value })} placeholder="00:00:10:00" style={inputBase} />
                  </td>
                  <td style={tdBase}>
                    <input value={r.remarks ?? ""} onChange={(e) => updateRow(r._tmpId, { remarks: e.target.value })} style={inputBase} />
                  </td>

                  <td style={tdBase}>
                    <div style={{ display: "grid", gap: 6 }}>
                      <div style={{ opacity: 0.8 }}>
                        {source?.filename ? (
                          <span>✅ {source.filename} <span style={{ opacity: 0.7 }}>({String(source.uploadStatus || "")})</span></span>
                        ) : (
                          <span>—</span>
                        )}
                      </div>

                      {uploading ? (
                        <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                          <progress value={pct} max={100} style={{ width: 160 }} />
                          <span style={{ fontSize: 12, opacity: 0.85 }}>{pct}%</span>
                        </div>
                      ) : null}

                      {uploadErr ? <div style={{ fontSize: 12, color: "#a10000" }}>{uploadErr}</div> : null}

                      <div style={{ display: "flex", gap: 6, alignItems: "center" }}>
                        <input
                          type="file"
                          style={inputBase}
                          onChange={(e) => {
                            const f = e.target.files?.[0] || null;
                            selectedFilesRef.current[r._tmpId] = f;
                          }}
                        />
                        <button onClick={() => doUploadSource(r)} disabled={!r.id || uploading}>
                          {uploading ? "Uploading..." : "Upload"}
                        </button>
                        <button onClick={() => doRemoveSource(r)} disabled={!r.id || !source || uploading}>
                          Remove
                        </button>
                      </div>

                      {!r.id ? <div style={{ fontSize: 12, opacity: 0.7 }}>Save first to upload</div> : null}
                    </div>
                  </td>

                  <td style={tdBase}>
                    <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                      <button onClick={() => saveRow(r)} disabled={loading || saving || uploading || isRowSaving}>
                        {isRowSaving ? "Saving..." : "Save"}
                      </button>
                      <button onClick={() => doDeleteRow(r)} disabled={loading || saving || uploading}>
                        {r.id ? "Delete" : "Remove"}
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}

            {!rows.length && !loading ? (
              <tr>
                <td colSpan={9} style={{ padding: 12, opacity: 0.7 }}>
                  No creatives yet. Click “Add row”.
                </td>
              </tr>
            ) : null}
          </tbody>
        </table>
      </div>
    </div>
  );
}
