import { api, apiUrl, getToken } from "../../../lib/api";
import type { Creative, CreativeUpsertItem, MediaJob } from "./creatives.types";

// Returned by GET /creatives/:id/qc-report
export type CreativeQcReport = {
  id: string;
  projectId: string;
  qcStatus?: string | null;
  qcFailureReasons?: string[];
  qcNotes?: string | null;
  autoQcStartedAt?: string | null;
  autoQcEndedAt?: string | null;
  qcReport?: any;
};

export async function getCreativeQcReport(creativeId: string): Promise<CreativeQcReport> {
  return api<CreativeQcReport>(`/creatives/${creativeId}/qc-report`);
}

export async function listCreatives(projectId: string): Promise<Creative[]> {
  return api<Creative[]>(`/projects/${projectId}/creatives`);
}

export async function bulkUpsertCreatives(projectId: string, items: CreativeUpsertItem[]): Promise<Creative[]> {
  return api<Creative[]>(`/projects/${projectId}/creatives/bulk`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ items }),
  });
}

/**
 * Upload SOURCE with optional progress callback.
 * Uses XHR because fetch does not support upload progress.
 */
export async function uploadCreativeSourceWithProgress(
  creativeId: string,
  file: File,
  onProgress: (pct: number) => void,
): Promise<any> {
  // Phase-1: browser -> Blob (SAS), then notify API
  const init = await api<{
    blobKey: string;
    sasUrl: string;
    requiredHeaders: Record<string, string>;
  }>(`/creatives/${creativeId}/source/init`, {
    method: "POST",
    body: JSON.stringify({
      filename: file.name,
      contentType: file.type || "application/octet-stream",
      sizeBytes: file.size,
    }),
  });

  await new Promise<void>((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("PUT", init.sasUrl, true);

    // Required by Azure Blob PUT (SAS)
    for (const [k, v] of Object.entries(init.requiredHeaders || {})) {
      try {
        xhr.setRequestHeader(k, v);
      } catch {
        // ignore
      }
    }

    xhr.upload.onprogress = (evt) => {
      if (!evt.lengthComputable) return;
      const pct = Math.round((evt.loaded / evt.total) * 100);
      onProgress(pct);
    };

    xhr.onload = () => {
      if (xhr.status >= 200 && xhr.status < 300) resolve();
      else reject(new Error(`Blob upload failed: ${xhr.status}`));
    };

    xhr.onerror = () => reject(new Error("Blob upload failed (network)"));
    xhr.send(file);
  });

  const done = await api(`/creatives/${creativeId}/source/complete`, {
    method: "POST",
    body: JSON.stringify({ blobKey: init.blobKey }),
  });

  onProgress(100);
  return done;
}

export async function removeCreativeSource(creativeId: string): Promise<any> {
  return api<any>(`/creatives/${creativeId}/source`, { method: "DELETE" });
}

export async function deleteCreative(creativeId: string): Promise<any> {
  return api<any>(`/creatives/${creativeId}`, { method: "DELETE" });
}

// -------- P1.8 processing --------

export async function startAutoQc(creativeId: string, force = false): Promise<any> {
  return api<any>(`/creatives/${creativeId}/auto-qc`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ force }),
  });
}

export async function startProxy(creativeId: string, force = false): Promise<any> {
  return api<any>(`/creatives/${creativeId}/proxy`, {
    method: "POST",
    headers: { "content-type": "application/json" },
    body: JSON.stringify({ force }),
  });
}

export async function generateQcVisuals(creativeId: string): Promise<any> {
  return api<any>(`/creatives/${creativeId}/qc-visuals`, {
    method: "POST",
  });
}

export async function listCreativeJobs(creativeId: string): Promise<MediaJob[]> {
  return api<MediaJob[]>(`/creatives/${creativeId}/jobs`);
}

/**
 * IMPORTANT:
 * <video src> cannot send Authorization header, so we download as Blob with JWT header,
 * then play via objectURL.
 *
 * API base is configurable via VITE_API_BASE (local: /api; ACA: https://backend...).
 */
export async function downloadAssetBlob(creativeId: string, type: "SOURCE" | "PROXY" | "OUTPUT"): Promise<Blob> {
  const token = getToken();
  const res = await fetch(apiUrl(`/creatives/${creativeId}/assets/${type}/stream`), {
    headers: { authorization: `Bearer ${token}` },
  });

  if (!res.ok) {
    const text = await res.text().catch(() => "");
    throw new Error(text || `${res.status} ${res.statusText}`);
  }

  return res.blob();
}

/**
 * Preferred for ACA/Blob storage:
 * Request a signed/redirect URL from the API and assign it directly to <video src> / <img src>.
 * This avoids CORS issues caused by `fetch()` following a 302 redirect to Azure Blob.
 */
export async function getAssetStreamUrl(
  creativeId: string,
  type: "SOURCE" | "PROXY" | "OUTPUT",
): Promise<string> {
  const res = await api<{ url: string }>(`/creatives/${creativeId}/assets/${type}/stream-url`);
  return res.url;
}

// QC artifacts generated alongside SOURCE (scopes/filmstrip/audio graphs)
//
// Supports:
//   - Legacy:  /creatives/:creativeId/qc/*
//   - Current: /creatives/:creativeId/qc-artifacts/*
//   - Scoped:  /accounts/:accountId/projects/:projectId/creatives/:creativeId/qc-artifacts/*
type QcScope = { creativeId: string; accountId?: string; projectId?: string };

function qcArtifactCandidates(scope: QcScope, name: string, kind: "stream" | "stream-url"): string[] {
  // We want nested paths like "filmstrip/frame_001.jpg" to stay as nested paths in the URL
  // (so they hit the backend wildcard route), but we must still encode each segment safely.
  // Also handle callers that already pass an encoded string like "filmstrip%2Fframe_001.jpg".
  let norm = String(name ?? "");
  try {
    norm = decodeURIComponent(norm);
  } catch {
    // ignore
  }
  norm = norm.replace(/^\/+/, "");
  const encName = norm.split("/").map(encodeURIComponent).join("/");

  const baseUnscoped = `/creatives/${scope.creativeId}`;
  const baseScoped =
    scope.accountId && scope.projectId
      ? `/accounts/${scope.accountId}/projects/${scope.projectId}/creatives/${scope.creativeId}`
      : null;

  const suffixNew = `/qc-artifacts/${encName}/${kind}`;
  const suffixOld = `/qc/${encName}/${kind}`;

  const paths: string[] = [];
  if (baseScoped) paths.push(`${baseScoped}${suffixNew}`);
  paths.push(`${baseUnscoped}${suffixNew}`);
  paths.push(`${baseUnscoped}${suffixOld}`);
  return paths;
}

async function fetchFirstOk(paths: string[], token: string): Promise<Response> {
  let last: Response | null = null;

  for (const path of paths) {
    const res = await fetch(apiUrl(path), {
      headers: { authorization: `Bearer ${token}` },
    });

    if (res.ok) return res;

    last = res;

    // Only fall back on 404 (path mismatch). For auth/500/etc, stop and surface the error.
    if (res.status !== 404) break;
  }

  const status = last ? `${last.status} ${last.statusText}` : "request failed";
  const body = last ? await last.text().catch(() => "") : "";
  throw new Error(body || status);
}

export async function downloadQcArtifactBlob(creativeId: string, name: string): Promise<Blob>;
export async function downloadQcArtifactBlob(
  accountId: string,
  projectId: string,
  creativeId: string,
  name: string
): Promise<Blob>;
export async function downloadQcArtifactBlob(a: string, b: string, c?: string, d?: string): Promise<Blob> {
  const token = getToken();

  const scope: QcScope = d
    ? { accountId: a, projectId: b, creativeId: c as string }
    : { creativeId: a };

  const name = d ?? b;
  const paths = qcArtifactCandidates(scope, name, "stream");

  const res = await fetchFirstOk(paths, token);
  return res.blob();
}

export async function getQcArtifactStreamUrl(creativeId: string, name: string): Promise<string>;
export async function getQcArtifactStreamUrl(
  accountId: string,
  projectId: string,
  creativeId: string,
  name: string
): Promise<string>;
export async function getQcArtifactStreamUrl(a: string, b: string, c?: string, d?: string): Promise<string> {
  const scope: QcScope = d
    ? { accountId: a, projectId: b, creativeId: c as string }
    : { creativeId: a };

  const name = d ?? b;
  const paths = qcArtifactCandidates(scope, name, "stream-url");

  let lastErr: unknown;

  // api() doesn't expose status codes cleanly, so we try candidates in order.
  for (const path of paths) {
    try {
      const res = await api<{ url: string }>(path);
      return res.url;
    } catch (e) {
      lastErr = e;
    }
  }

  throw lastErr instanceof Error ? lastErr : new Error("Failed to get QC artifact stream URL");
}

// -------- QC gate (Commit/Send) --------

export type QcGateBlocker = {
  creativeId: string;
  valid: string | null;
  caption: string | null;
  missingSource: boolean;
  qcStatus: string | null;
  qcNotes?: string | null;
  qcFailureReasons?: string[];
};

export type QcGateResult = { ok: boolean; blockers: QcGateBlocker[] };

export async function getQcGate(projectId: string, scope: "commit" | "send" = "commit"): Promise<QcGateResult> {
  return api<QcGateResult>(`/projects/${projectId}/qc-gate?scope=${scope}`);
}
