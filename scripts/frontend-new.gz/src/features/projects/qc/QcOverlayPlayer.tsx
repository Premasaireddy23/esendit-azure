import { useMemo, useState } from "react";
import "./QcOverlayPlayer.css";

type QcOverlayPlayerProps = {
  /** Object URL or remote URL */
  src: string;
  /** Displayed next to "Preview" heading (optional) */
  label?: string;
};

/**
 * QC-style preview player overlays (frontend-only):
 * - Action Safe (90%)
 * - Title Safe (80%)
 * - Center cross
 * - 4:3 safe/cut (center cut)
 */
export function QcOverlayPlayer(props: QcOverlayPlayerProps) {
  const [safeVisible, setSafeVisible] = useState(false);
  const [crossVisible, setCrossVisible] = useState(false);
  const [safe43Visible, setSafe43Visible] = useState(false);

  const containerClass = useMemo(() => {
    const classes = ["qcPlayer"];
    if (safe43Visible) classes.push("qcPlayer--safe43");
    return classes.join(" ");
  }, [safe43Visible]);

  return (
    <div style={{ display: "grid", gap: 10 }}>
      <div className={containerClass}>
        <video controls src={props.src} />

        {/* overlays */}
        <div className={`qcOverlay qcOverlay--actionSafe ${safeVisible ? "" : "qcOverlay--hidden"}`} />
        <div className={`qcOverlay qcOverlay--titleSafe ${safeVisible ? "" : "qcOverlay--hidden"}`} />

        <div className={`qcOverlay qcOverlay--centerCross ${crossVisible ? "" : "qcOverlay--hidden"}`}>
          <div className="qcCenterLine qcCenterLine--h" />
          <div className="qcCenterLine qcCenterLine--v" />
        </div>

        <div className="qcOverlay qcOverlay--safe43" />
      </div>

      <div className="row" style={{ justifyContent: "space-between" }}>
        <div style={{ fontSize: 12, opacity: 0.75 }}>{props.label ? `Source: ${props.label}` : ""}</div>

        <div className="row" style={{ gap: 8 }}>
          <button type="button" onClick={() => setSafeVisible((v) => !v)}>
            Safe Areas
          </button>
          <button type="button" onClick={() => setCrossVisible((v) => !v)}>
            Center
          </button>
          <button type="button" onClick={() => setSafe43Visible((v) => !v)}>
            4:3 Safe
          </button>
        </div>
      </div>
    </div>
  );
}
